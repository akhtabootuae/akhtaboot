require('dotenv').config();

const express = require('express');
const { MongoClient, ObjectId } = require('mongodb');
const request = require('supertest');
const jwt = require('jsonwebtoken');

// Create a test app
const createTestApp = async () => {
  const app = express();
  
  // Connect to test database
  const client = new MongoClient(process.env.MONGO_URI);
  await client.connect();
  const db = client.db();
  app.locals.db = db;
  
  app.use(express.json());
  
  // Add user routes
  const userRoutes = require('./routes/userRoutes');
  app.use('/api/users', userRoutes);
  
  return { app, db, client };
};

// Helper function to generate a test JWT token
const generateTestToken = (user) => {
  const payload = {
    user: {
      id: user._id,
      role: user.role_name
    }
  };
  
  return jwt.sign(
    payload,
    process.env.JWT_SECRET,
    { expiresIn: '1h' }
  );
};

// Main test function
const testMannerEvaluations = async () => {
  console.log('🚀 Starting Manner Evaluations API Tests...\n');
  
  let app, db, client;
  
  try {
    // Setup test environment
    const { app: testApp, db: testDb, client: testClient } = await createTestApp();
    app = testApp;
    db = testDb;
    client = testClient;
    
    // Find an admin user for authentication
    const adminUser = await db.collection('users').findOne({ 
      role_name: 'Admin' 
    });
    
    if (!adminUser) {
      console.log('❌ No admin user found. Please run the database seeder first.');
      return;
    }
    
    console.log(`✅ Found admin user: ${adminUser.email}`);
    
    // Find a test user to add evaluations to
    const testUser = await db.collection('users').findOne({ 
      role_name: 'Technician' 
    });
    
    if (!testUser) {
      console.log('❌ No technician user found for testing. Please run the database seeder first.');
      return;
    }
    
    console.log(`✅ Found test user: ${testUser.email}`);
    
    // Generate auth token for admin
    const authToken = generateTestToken(adminUser);
    
    // Test 1: Get evaluations for user (should be empty initially)
    console.log('\n📋 Test 1: Get existing manner evaluations');
    const getResponse1 = await request(app)
      .get(`/api/users/${testUser._id}/manner-evaluations`)
      .set('Authorization', `Bearer ${authToken}`);
    
    console.log(`Status: ${getResponse1.status}`);
    console.log(`Initial evaluations count: ${getResponse1.body.total_evaluations || 0}`);
    
    // Test 2: Add a new manner evaluation
    console.log('\n📋 Test 2: Add new manner evaluation');
    const newEvaluation = {
      category: 'Customer Service',
      rating: 4,
      notes: 'Good interaction with customers, polite and helpful',
      work_order_id: null  // Optional field
    };
    
    const addResponse = await request(app)
      .post(`/api/users/${testUser._id}/manner-evaluations`)
      .set('Authorization', `Bearer ${authToken}`)
      .send(newEvaluation);
    
    console.log(`Status: ${addResponse.status}`);
    console.log(`Response: ${JSON.stringify(addResponse.body, null, 2)}`);
    
    if (addResponse.status !== 201) {
      console.log('❌ Failed to add evaluation');
      return;
    }
    
    const evaluationId = addResponse.body.evaluation_id;
    console.log(`✅ Added evaluation with ID: ${evaluationId}`);
    
    // Test 3: Get evaluations again (should have 1 now)
    console.log('\n📋 Test 3: Get evaluations after adding one');
    const getResponse2 = await request(app)
      .get(`/api/users/${testUser._id}/manner-evaluations`)
      .set('Authorization', `Bearer ${authToken}`);
    
    console.log(`Status: ${getResponse2.status}`);
    console.log(`Evaluations count: ${getResponse2.body.total_evaluations}`);
    console.log(`Evaluation details: ${JSON.stringify(getResponse2.body.manner_evaluations[0], null, 2)}`);
    
    // Test 4: Update the evaluation
    console.log('\n📋 Test 4: Update manner evaluation');
    const updateData = {
      category: 'Customer Service',
      rating: 5,
      notes: 'Excellent customer service skills, went above and beyond'
    };
    
    const updateResponse = await request(app)
      .put(`/api/users/${testUser._id}/manner-evaluations/${evaluationId}`)
      .set('Authorization', `Bearer ${authToken}`)
      .send(updateData);
    
    console.log(`Status: ${updateResponse.status}`);
    console.log(`Response: ${JSON.stringify(updateResponse.body, null, 2)}`);
    
    // Test 5: Get evaluation logs
    console.log('\n📋 Test 5: Get evaluation logs');
    const logsResponse = await request(app)
      .get(`/api/users/${testUser._id}/manner-evaluation-logs`)
      .set('Authorization', `Bearer ${authToken}`);
    
    console.log(`Status: ${logsResponse.status}`);
    console.log(`Logs count: ${logsResponse.body.total_logs}`);
    if (logsResponse.body.logs && logsResponse.body.logs.length > 0) {
      console.log(`First log: ${JSON.stringify(logsResponse.body.logs[0], null, 2)}`);
    }
    
    // Test 6: Delete the evaluation
    console.log('\n📋 Test 6: Delete manner evaluation');
    const deleteResponse = await request(app)
      .delete(`/api/users/${testUser._id}/manner-evaluations/${evaluationId}`)
      .set('Authorization', `Bearer ${authToken}`);
    
    console.log(`Status: ${deleteResponse.status}`);
    console.log(`Response: ${JSON.stringify(deleteResponse.body, null, 2)}`);
    
    // Test 7: Verify deletion
    console.log('\n📋 Test 7: Verify evaluation was deleted');
    const getResponse3 = await request(app)
      .get(`/api/users/${testUser._id}/manner-evaluations`)
      .set('Authorization', `Bearer ${authToken}`);
    
    console.log(`Status: ${getResponse3.status}`);
    console.log(`Evaluations count after deletion: ${getResponse3.body.total_evaluations}`);
    
    // Test 8: Check logs after deletion
    console.log('\n📋 Test 8: Check logs after deletion');
    const logsResponse2 = await request(app)
      .get(`/api/users/${testUser._id}/manner-evaluation-logs`)
      .set('Authorization', `Bearer ${authToken}`);
    
    console.log(`Status: ${logsResponse2.status}`);
    console.log(`Logs count after deletion: ${logsResponse2.body.total_logs}`);
    
    console.log('\n✅ All tests completed successfully!');
    
  } catch (error) {
    console.error('❌ Test failed:', error);
  } finally {
    if (client) {
      await client.close();
    }
  }
};

// Run the tests
if (require.main === module) {
  testMannerEvaluations().catch(console.error);
}

module.exports = { testMannerEvaluations };
