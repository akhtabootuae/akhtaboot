# Work Order QA API Documentation

## Overview

The Work Order QA system provides comprehensive quality assurance tracking for work orders with multi-image support and AWS S3 integration. This collection allows QA personnel to document work quality with pass/fail status, detailed descriptions, and 3-5 supporting images per assessment.

## Collection Schema

### MongoDB Collection: `workordersqa`

```javascript
{
  _id: ObjectId,
  WO_ID: String,              // Work Order ID reference
  person_name: String,        // QA inspector name (2-100 chars)
  passed: Boolean,            // Pass/Fail status
  images: [                   // Array of 3-5 image objects
    {
      s3_key: String,         // S3 file key
      original_name: String,  // Original filename
      size: Number,           // File size in bytes
      mime_type: String,      // MIME type (image/*)
      upload_date: Date       // Upload timestamp
    }
  ],
  description: String,        // QA notes (10-1000 chars)
  created_at: Date,
  updated_at: Date
}
```

### Validation Rules
- **WO_ID**: Required string reference to work order
- **person_name**: 2-100 characters, required
- **passed**: Boolean, required
- **images**: Array with 3-5 image objects, required
- **description**: 10-1000 characters, required
- **Image files**: Only image types (jpg, png, gif, webp), max 10MB each

### Database Indexes
- `WO_ID` - Query by work order
- `person_name` - Query by QA inspector
- `passed` - Filter by pass/fail status
- `created_at` - Sort by date
- Compound indexes for optimized filtering

## API Endpoints

### Base URL: `/api/workorder-qa`

### 1. Create QA Record
```http
POST /api/workorder-qa
Content-Type: multipart/form-data
```

**Form Data:**
```javascript
{
  WO_ID: "WO-2024-001",
  person_name: "John Smith",
  passed: true,              // or "true"/"false" as string
  description: "Work completed to specifications...",
  images: [File, File, File] // 3-5 image files
}
```

**Response:**
```javascript
{
  "success": true,
  "message": "Work order QA record created successfully",
  "data": {
    "_id": "507f1f77bcf86cd799439011",
    "WO_ID": "WO-2024-001",
    "person_name": "John Smith",
    "passed": true,
    "images": [
      {
        "s3_key": "qa-images/1640995200000-uuid.jpg",
        "original_name": "qa_photo_1.jpg",
        "size": 1024000,
        "mime_type": "image/jpeg",
        "upload_date": "2024-01-01T10:00:00.000Z"
      }
      // ... more images
    ],
    "description": "Work completed to specifications...",
    "created_at": "2024-01-01T10:00:00.000Z",
    "updated_at": "2024-01-01T10:00:00.000Z"
  }
}
```

### 2. Get All QA Records (Paginated)
```http
GET /api/workorder-qa?page=1&limit=10&wo_id=WO-2024-001&passed=true
```

**Query Parameters:**
- `page` (optional): Page number, default 1
- `limit` (optional): Records per page, default 10
- `wo_id` (optional): Filter by work order ID
- `passed` (optional): Filter by pass/fail status (true/false)

**Response:**
```javascript
{
  "success": true,
  "data": [/* QA records with signed URLs */],
  "pagination": {
    "page": 1,
    "limit": 10,
    "total": 25,
    "pages": 3
  }
}
```

### 3. Get QA Records for Specific Work Order
```http
GET /api/workorder-qa/work-order/WO-2024-001
```

**Response:**
```javascript
{
  "success": true,
  "data": [/* QA records for this work order */],
  "count": 2
}
```

### 4. Get Single QA Record
```http
GET /api/workorder-qa/507f1f77bcf86cd799439011
```

### 5. Update QA Record (No Image Changes)
```http
PUT /api/workorder-qa/507f1f77bcf86cd799439011
Content-Type: application/json
```

**Body:**
```javascript
{
  "person_name": "Jane Doe",
  "passed": false,
  "description": "Updated description..."
}
```

### 6. Delete QA Record
```http
DELETE /api/workorder-qa/507f1f77bcf86cd799439011
```

**Note:** Automatically deletes associated S3 images.

### 7. Get QA Statistics
```http
GET /api/workorder-qa/stats/overview
```

**Response:**
```javascript
{
  "success": true,
  "data": {
    "total": 100,
    "passed": 85,
    "failed": 15,
    "pass_rate": "85.00"
  }
}
```

### 8. Get Image Download URL
```http
GET /api/workorder-qa/507f1f77bcf86cd799439011/images/0/download
```

**Response:**
```javascript
{
  "success": true,
  "data": {
    "download_url": "https://s3.amazonaws.com/...",
    "filename": "qa_photo_1.jpg",
    "size": 1024000,
    "mime_type": "image/jpeg"
  }
}
```

## Frontend Implementation Guide

### 1. File Upload Component (React)

```jsx
import React, { useState } from 'react';

const QAForm = ({ workOrderId, onSuccess }) => {
  const [formData, setFormData] = useState({
    WO_ID: workOrderId,
    person_name: '',
    passed: true,
    description: '',
    images: []
  });
  const [uploading, setUploading] = useState(false);

  const handleImageChange = (e) => {
    const files = Array.from(e.target.files);
    
    // Validate file count
    if (files.length < 3 || files.length > 5) {
      alert('Please select 3-5 images');
      return;
    }
    
    // Validate file types and sizes
    const validFiles = files.filter(file => {
      const isImage = file.type.startsWith('image/');
      const isValidSize = file.size <= 10 * 1024 * 1024; // 10MB
      return isImage && isValidSize;
    });
    
    if (validFiles.length !== files.length) {
      alert('Only image files under 10MB are allowed');
      return;
    }
    
    setFormData(prev => ({ ...prev, images: validFiles }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setUploading(true);
    
    const submitData = new FormData();
    submitData.append('WO_ID', formData.WO_ID);
    submitData.append('person_name', formData.person_name);
    submitData.append('passed', formData.passed);
    submitData.append('description', formData.description);
    
    // Append all images
    formData.images.forEach(image => {
      submitData.append('images', image);
    });
    
    try {
      const response = await fetch('/api/workorder-qa', {
        method: 'POST',
        body: submitData
      });
      
      const result = await response.json();
      
      if (result.success) {
        onSuccess(result.data);
      } else {
        alert(result.error);
      }
    } catch (error) {
      alert('Upload failed: ' + error.message);
    } finally {
      setUploading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="qa-form">
      <div>
        <label>Inspector Name:</label>
        <input
          type="text"
          value={formData.person_name}
          onChange={(e) => setFormData(prev => ({...prev, person_name: e.target.value}))}
          required
          minLength={2}
          maxLength={100}
        />
      </div>
      
      <div>
        <label>QA Result:</label>
        <select
          value={formData.passed}
          onChange={(e) => setFormData(prev => ({...prev, passed: e.target.value === 'true'}))}
        >
          <option value={true}>Pass</option>
          <option value={false}>Fail</option>
        </select>
      </div>
      
      <div>
        <label>Images (3-5 required):</label>
        <input
          type="file"
          multiple
          accept="image/*"
          onChange={handleImageChange}
          required
        />
        {formData.images.length > 0 && (
          <p>{formData.images.length} images selected</p>
        )}
      </div>
      
      <div>
        <label>Description:</label>
        <textarea
          value={formData.description}
          onChange={(e) => setFormData(prev => ({...prev, description: e.target.value}))}
          required
          minLength={10}
          maxLength={1000}
          rows={4}
        />
      </div>
      
      <button type="submit" disabled={uploading}>
        {uploading ? 'Uploading...' : 'Submit QA'}
      </button>
    </form>
  );
};
```

### 2. QA Records Display Component

```jsx
const QARecordsList = ({ workOrderId }) => {
  const [qaRecords, setQaRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState({});

  useEffect(() => {
    fetchQARecords();
  }, [workOrderId]);

  const fetchQARecords = async (page = 1) => {
    try {
      const url = workOrderId 
        ? `/api/workorder-qa/work-order/${workOrderId}`
        : `/api/workorder-qa?page=${page}`;
        
      const response = await fetch(url);
      const result = await response.json();
      
      if (result.success) {
        setQaRecords(result.data);
        if (result.pagination) {
          setPagination(result.pagination);
        }
      }
    } catch (error) {
      console.error('Failed to fetch QA records:', error);
    } finally {
      setLoading(false);
    }
  };

  const QACard = ({ qa }) => (
    <div className={`qa-card ${qa.passed ? 'passed' : 'failed'}`}>
      <div className="qa-header">
        <h3>Work Order: {qa.WO_ID}</h3>
        <span className={`status ${qa.passed ? 'pass' : 'fail'}`}>
          {qa.passed ? 'PASS' : 'FAIL'}
        </span>
      </div>
      
      <div className="qa-details">
        <p><strong>Inspector:</strong> {qa.person_name}</p>
        <p><strong>Date:</strong> {new Date(qa.created_at).toLocaleDateString()}</p>
        <p><strong>Description:</strong> {qa.description}</p>
      </div>
      
      <div className="qa-images">
        <h4>Images ({qa.images.length})</h4>
        <div className="image-grid">
          {qa.images.map((image, index) => (
            <div key={index} className="image-item">
              <img 
                src={image.signed_url} 
                alt={image.original_name}
                onClick={() => window.open(image.signed_url, '_blank')}
              />
              <p>{image.original_name}</p>
              <small>{(image.size / 1024 / 1024).toFixed(2)} MB</small>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  if (loading) return <div>Loading QA records...</div>;

  return (
    <div className="qa-records-list">
      {qaRecords.map(qa => (
        <QACard key={qa._id} qa={qa} />
      ))}
      
      {pagination.pages > 1 && (
        <div className="pagination">
          {Array.from({ length: pagination.pages }, (_, i) => (
            <button 
              key={i + 1}
              onClick={() => fetchQARecords(i + 1)}
              className={pagination.page === i + 1 ? 'active' : ''}
            >
              {i + 1}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
```

### 3. QA Statistics Dashboard

```jsx
const QAStatsDashboard = () => {
  const [stats, setStats] = useState(null);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const response = await fetch('/api/workorder-qa/stats/overview');
      const result = await response.json();
      
      if (result.success) {
        setStats(result.data);
      }
    } catch (error) {
      console.error('Failed to fetch stats:', error);
    }
  };

  if (!stats) return <div>Loading stats...</div>;

  return (
    <div className="qa-stats-dashboard">
      <div className="stat-card">
        <h3>Total QA Records</h3>
        <p className="stat-value">{stats.total}</p>
      </div>
      
      <div className="stat-card success">
        <h3>Passed</h3>
        <p className="stat-value">{stats.passed}</p>
      </div>
      
      <div className="stat-card failure">
        <h3>Failed</h3>
        <p className="stat-value">{stats.failed}</p>
      </div>
      
      <div className="stat-card percentage">
        <h3>Pass Rate</h3>
        <p className="stat-value">{stats.pass_rate}%</p>
      </div>
    </div>
  );
};
```

## Error Handling

### Common Error Responses

```javascript
// Validation errors
{
  "success": false,
  "error": "At least 3 images are required for QA submission"
}

// File type errors
{
  "success": false,
  "error": "Invalid file type. Allowed types: /jpeg|jpg|png|gif|webp/"
}

// Database errors
{
  "success": false,
  "error": "Failed to create work order QA record",
  "details": "Validation error message"
}
```

## Security Considerations

### AWS S3 Integration
- **Private Storage**: All images stored with `acl: 'private'`
- **Signed URLs**: Temporary access (1 hour expiry)
- **Cost Optimization**: Uses `ONEZONE_IA` storage class
- **Metadata**: Includes uploader info and original filename

### File Validation
- **Type Checking**: Only image MIME types allowed
- **Size Limits**: 10MB per file maximum
- **Count Validation**: Enforced 3-5 images per QA record

### Database Security
- **Schema Validation**: MongoDB enforces all constraints
- **Indexed Queries**: Optimized for performance
- **Audit Trail**: Automatic timestamps for all records

## Testing with Sample Data

The database seeder creates sample QA records with mock S3 keys. For development:

1. **Sample Records**: 5 QA records linked to existing work orders
2. **Mock Images**: Placeholder S3 keys (won't display actual images)
3. **Mixed Results**: 2/3 pass rate for realistic testing
4. **Realistic Data**: Proper descriptions and inspector names

## Performance Optimization

### Database Indexes
- Compound indexes for common query patterns
- Optimized for filtering by work order and status
- Sorted by creation date for chronological display

### S3 Optimization
- Automatic cleanup on record deletion
- Batch operations for multiple file handling
- Cost-effective storage class selection

### Frontend Optimization
- Lazy load images with signed URLs
- Pagination for large datasets
- Client-side file validation before upload

## Integration Points

### Work Order System
- Link QA records to existing work orders via `WO_ID`
- Display QA status in work order details
- Filter work orders by QA pass/fail status

### User Management
- Track QA inspector by name (expandable to user IDs)
- Role-based access to QA functionality
- Audit trail for QA submissions

### Reporting System
- QA statistics for management dashboards
- Pass/fail trends over time
- Inspector performance metrics