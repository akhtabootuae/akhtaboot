# Manner Evaluations Frontend Implementation Guide

## Overview
This document outlines the frontend implementation requirements for the Manner Evaluations feature. This system allows administrators and supervisors to evaluate and track the professional behavior and customer service skills of technicians.

## Table of Contents
- [API Endpoints](#api-endpoints)
- [Data Structures](#data-structures)
- [User Interface Components](#user-interface-components)
- [User Roles & Permissions](#user-roles--permissions)
- [Frontend Features](#frontend-features)
- [Implementation Examples](#implementation-examples)
- [Testing Scenarios](#testing-scenarios)

## API Endpoints

### Base URL: `/api/users/{userId}/manner-evaluations`

| Method | Endpoint | Description | Required Permission |
|--------|----------|-------------|-------------------|
| `GET` | `/api/users/{userId}/manner-evaluations` | Get all evaluations for a user | `view_manner_evaluations` |
| `POST` | `/api/users/{userId}/manner-evaluations` | Add new evaluation | `manage_manner_evaluations` |
| `PUT` | `/api/users/{userId}/manner-evaluations/{evaluationId}` | Update evaluation | `manage_manner_evaluations` |
| `DELETE` | `/api/users/{userId}/manner-evaluations/{evaluationId}` | Delete evaluation | `manage_manner_evaluations` |
| `GET` | `/api/users/{userId}/manner-evaluation-logs` | Get evaluation history/logs | `view_manner_evaluations` |

## Data Structures

### Manner Evaluation Object
```javascript
{
  "_id": "ObjectId",
  "category": "string",           // Required: e.g., "Customer Service", "Punctuality", "Teamwork"
  "rating": "integer",            // Required: 1-5 scale
  "notes": "string",              // Required: Additional comments/feedback
  "work_order_id": "ObjectId",    // Optional: Related work order
  "created_at": "Date",
  "updated_at": "Date"
}
```

### Evaluation Log Object
```javascript
{
  "log_id": "string",             // Unique log identifier
  "action": "string",             // "added", "updated", "deleted"
  "category": "string",
  "rating": "integer",
  "work_order_id": "ObjectId",    // Optional
  "evaluator_id": "ObjectId",     // Who performed the action
  "notes": "string",
  "created_at": "Date"
}
```

### API Response Examples

#### Get Evaluations Response
```javascript
{
  "manner_evaluations": [
    {
      "_id": "64a7b8c9d1e2f3a4b5c6d7e8",
      "category": "Customer Service",
      "rating": 4,
      "notes": "Polite and helpful with customers",
      "created_at": "2025-06-07T10:30:00Z",
      "updated_at": "2025-06-07T10:30:00Z"
    }
  ],
  "total_evaluations": 1,
  "user": {
    "name": "Mohammed Ali",
    "email": "technician1@example.com",
    "role": "Technician"
  }
}
```

#### Get Logs Response
```javascript
{
  "logs": [
    {
      "log_id": "1733577824212-5678",
      "action": "added",
      "category": "Customer Service",
      "rating": 4,
      "evaluator_id": "64a7b8c9d1e2f3a4b5c6d7e9",
      "notes": "Polite and helpful with customers",
      "created_at": "2025-06-07T10:30:00Z"
    }
  ],
  "total_logs": 1
}
```

## User Roles & Permissions

### Admin
- **Permissions**: Full access (all permissions by default)
- **Can**: View, add, update, delete evaluations for all users
- **Access**: All technicians and supervisors

### Supervisor
- **Permissions**: 
  - `view_manner_evaluations`
  - `manage_manner_evaluations`
- **Can**: View, add, update, delete evaluations for technicians
- **Access**: Technicians in their branch/team

### Technician
- **Permissions**: 
  - `view_manner_evaluations` (read-only)
- **Can**: View their own evaluations only
- **Access**: Own evaluation records only

## User Interface Components

### 1. Evaluations Dashboard
**Location**: User Profile Page or dedicated Evaluations section

**Features**:
- List view of all evaluations for a user
- Filtering by date range, category, rating
- Sorting by date, rating, category
- Search functionality
- Export to PDF/Excel

**Layout**:
```
┌─────────────────────────────────────────────────────┐
│ 📊 Manner Evaluations - Mohammed Ali               │
├─────────────────────────────────────────────────────┤
│ Filters: [Category ▼] [Rating ▼] [Date Range ▼]    │
│ Actions: [+ Add Evaluation] [📄 Export]             │
├─────────────────────────────────────────────────────┤
│ ⭐⭐⭐⭐⭐ Customer Service    2025-06-07     [Edit] │
│ "Excellent customer interaction skills"             │
│                                                     │
│ ⭐⭐⭐⭐☆ Punctuality         2025-06-05     [Edit] │
│ "Always on time, reliable"                         │
│                                                     │
│ ⭐⭐⭐☆☆ Teamwork             2025-06-03     [Edit] │
│ "Needs improvement in team collaboration"          │
└─────────────────────────────────────────────────────┘
```

### 2. Add/Edit Evaluation Modal
**Trigger**: "Add Evaluation" button or "Edit" link

**Form Fields**:
- **Category** (Required): Dropdown or text input
  - Suggested values: "Customer Service", "Punctuality", "Teamwork", "Technical Skills", "Communication"
- **Rating** (Required): 1-5 star selector or radio buttons
- **Work Order** (Optional): Dropdown of recent work orders
- **Notes** (Required): Textarea for comments

**Layout**:
```
┌─────────────────────────────────────────┐
│ 📝 Add Manner Evaluation               │
├─────────────────────────────────────────┤
│ Category*: [Customer Service    ▼]      │
│                                         │
│ Rating*:   ⭐⭐⭐⭐☆ (4/5)              │
│                                         │
│ Work Order: [Select Work Order  ▼]      │
│                                         │
│ Notes*:                                 │
│ ┌─────────────────────────────────────┐ │
│ │ Employee showed excellent customer  │ │
│ │ service skills during vehicle       │ │
│ │ inspection...                       │ │
│ └─────────────────────────────────────┘ │
│                                         │
│           [Cancel] [Save Evaluation]    │
└─────────────────────────────────────────┘
```

### 3. Evaluation History/Logs
**Location**: Separate tab or expandable section

**Features**:
- Chronological log of all evaluation activities
- Show evaluator name and timestamp
- Display action type (added, updated, deleted)
- Filter by action type, evaluator, date range

**Layout**:
```
┌─────────────────────────────────────────────────────┐
│ 📋 Evaluation History                               │
├─────────────────────────────────────────────────────┤
│ 🟢 ADDED - Customer Service (Rating: 5/5)          │
│    By: Sarah Ahmed (Supervisor)                     │
│    Date: 2025-06-07 10:30 AM                      │
│    Notes: "Outstanding customer interaction"       │
│                                                     │
│ 🔵 UPDATED - Punctuality (Rating: 4/5 → 5/5)      │
│    By: Sarah Ahmed (Supervisor)                     │
│    Date: 2025-06-05 02:15 PM                      │
│    Notes: "Improved significantly"                  │
│                                                     │
│ 🔴 DELETED - Teamwork (Rating: 2/5)                │
│    By: Admin User                                   │
│    Date: 2025-06-03 09:45 AM                      │
│    Notes: "Deleted evaluation: Outdated data"      │
└─────────────────────────────────────────────────────┘
```

### 4. Statistics & Analytics
**Location**: Dashboard or separate analytics page

**Features**:
- Average rating over time
- Rating distribution by category
- Performance trends
- Comparison with team averages

**Charts/Widgets**:
- Line chart: Rating trends over time
- Bar chart: Ratings by category
- Pie chart: Evaluation distribution
- KPI cards: Average rating, total evaluations, improvement rate

## Frontend Features

### 1. Real-time Updates
- Use WebSocket or polling to update evaluations in real-time
- Show notifications when new evaluations are added
- Update counts and averages automatically

### 2. Responsive Design
- Mobile-friendly evaluation forms
- Touch-friendly star rating component
- Responsive tables with horizontal scrolling
- Collapsible sections for mobile

### 3. User Experience
- **Confirmation dialogs** for delete operations
- **Loading states** during API calls
- **Error handling** with user-friendly messages
- **Success notifications** after operations
- **Auto-save** for evaluation drafts

### 4. Accessibility
- Keyboard navigation support
- Screen reader compatibility
- High contrast mode support
- Focus indicators
- ARIA labels for interactive elements

### 5. Validation
- Client-side validation for required fields
- Rating range validation (1-5)
- Character limits for text fields
- Real-time validation feedback

## Implementation Examples

### React Component Structure
```
MannerEvaluations/
├── MannerEvaluationsPage.jsx       // Main page component
├── EvaluationsList.jsx             // List of evaluations
├── EvaluationCard.jsx              // Individual evaluation display
├── EvaluationForm.jsx              // Add/Edit form modal
├── EvaluationHistory.jsx           // History/logs component
├── StarRating.jsx                  // Star rating component
├── EvaluationFilters.jsx           // Filter controls
├── EvaluationStats.jsx             // Statistics dashboard
└── hooks/
    ├── useEvaluations.js           // Custom hook for API calls
    ├── useEvaluationLogs.js        // Custom hook for logs
    └── usePermissions.js           // Permission checking hook
```

### API Service Example (JavaScript)
```javascript
class MannerEvaluationService {
  static async getEvaluations(userId) {
    const response = await fetch(`/api/users/${userId}/manner-evaluations`, {
      headers: {
        'Authorization': `Bearer ${getToken()}`,
        'Content-Type': 'application/json'
      }
    });
    return response.json();
  }

  static async addEvaluation(userId, evaluationData) {
    const response = await fetch(`/api/users/${userId}/manner-evaluations`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${getToken()}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(evaluationData)
    });
    return response.json();
  }

  static async updateEvaluation(userId, evaluationId, updateData) {
    const response = await fetch(`/api/users/${userId}/manner-evaluations/${evaluationId}`, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${getToken()}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(updateData)
    });
    return response.json();
  }

  static async deleteEvaluation(userId, evaluationId) {
    const response = await fetch(`/api/users/${userId}/manner-evaluations/${evaluationId}`, {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${getToken()}`
      }
    });
    return response.json();
  }

  static async getEvaluationLogs(userId) {
    const response = await fetch(`/api/users/${userId}/manner-evaluation-logs`, {
      headers: {
        'Authorization': `Bearer ${getToken()}`,
        'Content-Type': 'application/json'
      }
    });
    return response.json();
  }
}
```

### Permission Checking Hook
```javascript
const usePermissions = () => {
  const { user } = useAuth();
  
  const canViewEvaluations = () => {
    return user?.role === 'Admin' || 
           user?.permissions?.includes('view_manner_evaluations');
  };
  
  const canManageEvaluations = () => {
    return user?.role === 'Admin' || 
           user?.permissions?.includes('manage_manner_evaluations');
  };
  
  return {
    canViewEvaluations,
    canManageEvaluations
  };
};
```

## Testing Scenarios

### 1. Functional Testing
- **Add Evaluation**: Test form validation, API integration, success feedback
- **Update Evaluation**: Test edit form, data persistence, history logging
- **Delete Evaluation**: Test confirmation dialog, soft delete, log creation
- **View Evaluations**: Test list display, filtering, sorting, pagination
- **View History**: Test log display, chronological order, evaluator information

### 2. Permission Testing
- **Admin**: Should have full access to all users' evaluations
- **Supervisor**: Should be able to manage technician evaluations
- **Technician**: Should only view their own evaluations (read-only)
- **Unauthorized**: Should receive 403 errors for restricted actions

### 3. User Experience Testing
- **Responsive Design**: Test on mobile, tablet, desktop
- **Loading States**: Test with slow network connections
- **Error Handling**: Test with invalid data, network errors
- **Accessibility**: Test with screen readers, keyboard navigation
- **Performance**: Test with large datasets, multiple evaluations

### 4. Data Validation Testing
- **Required Fields**: Test form submission without required data
- **Rating Range**: Test ratings outside 1-5 range
- **Text Limits**: Test long notes, category names
- **Special Characters**: Test with various text inputs

## Error Handling

### Common Error Scenarios
1. **403 Forbidden**: User lacks permission
2. **404 Not Found**: User or evaluation not found
3. **400 Bad Request**: Invalid input data
4. **500 Server Error**: Database or server issues

### User-Friendly Error Messages
```javascript
const errorMessages = {
  403: "You don't have permission to perform this action.",
  404: "The evaluation or user was not found.",
  400: "Please check your input and try again.",
  500: "Something went wrong. Please try again later.",
  network: "Please check your internet connection."
};
```

## Deployment Considerations

### Environment Variables
- API base URL configuration
- Authentication token storage
- Permission configuration

### Performance Optimization
- Lazy loading for evaluation lists
- Pagination for large datasets
- Caching for frequently accessed data
- Image optimization for user avatars

### Security
- Input sanitization
- XSS prevention
- CSRF protection
- Secure token storage

---

## Quick Start Checklist

- [ ] Set up API service layer
- [ ] Implement authentication and permission checking
- [ ] Create evaluation list component
- [ ] Build add/edit form modal
- [ ] Implement star rating component
- [ ] Add evaluation history/logs view
- [ ] Create responsive layouts
- [ ] Add error handling and loading states
- [ ] Implement filtering and sorting
- [ ] Add statistics dashboard
- [ ] Test all user roles and permissions
- [ ] Perform accessibility testing
- [ ] Optimize for mobile devices

This implementation guide provides a complete roadmap for building the manner evaluations frontend feature with proper user experience, security, and maintainability considerations.
