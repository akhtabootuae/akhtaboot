const express = require('express');
const router = express.Router();
const { ObjectId, Int32 } = require('mongodb');
const path = require('path');

// Import middleware
const auth = require('../middleware/auth');
const { createS3Upload, uploadConfigs, getSignedUrl } = require('../middleware/s3Upload');

// Import models
const { WorkOrder } = require('../models');

// Configure S3 upload for QC approval photos
const uploadQCPhoto = createS3Upload({
  folderName: 'qc-photos',
  ...uploadConfigs.images,
  fieldName: 'employeePhoto'
});

// Upload QC approval photo endpoint
router.post('/work-orders/:workOrderId/parts/:partIndex/stages/:stageIndex/qc-approval', 
  auth, 
  uploadQCPhoto, 
  async (req, res) => {
    try {
      const { workOrderId, partIndex, stageIndex } = req.params;
      const { approvalType } = req.body;

      // Validate parameters
      if (!workOrderId || partIndex === undefined || stageIndex === undefined) {
        return res.status(400).json({ 
          message: 'Missing required parameters',
          required: ['workOrderId', 'partIndex', 'stageIndex']
        });
      }

      // Validate image upload
      if (!req.file) {
        return res.status(400).json({ message: 'Employee photo is required for QC approval' });
      }

      // Create QC approval record
      const qcApprovalData = {
        workOrderId: new ObjectId(workOrderId),
        partIndex: new Int32(parseInt(partIndex)),
        stageIndex: new Int32(parseInt(stageIndex)),
        approvalType: approvalType || 'qc_acceptance',
        approvedBy: new ObjectId(req.user.id),
        approvedAt: new Date(),
        employeePhotoS3Key: req.file.key,
        employeePhotoUrl: req.file.location,
        employeePhotoName: req.file.originalname,
        employeePhotoSize: new Int32(req.file.size)
      };

      // Store QC approval in database
      const db = req.app.locals.db;
      const qcApprovalsCollection = db.collection('qc_approvals');
      
      const result = await qcApprovalsCollection.insertOne({
        ...qcApprovalData,
        created_at: new Date(),
        updated_at: new Date()
      });

      // Update work order to indicate QC approval
      const workOrdersCollection = db.collection('work_orders');
      await workOrdersCollection.updateOne(
        { 
          _id: new ObjectId(workOrderId),
          [`parts.${partIndex}.stages.${stageIndex}`]: { $exists: true }
        },
        {
          $set: {
            [`parts.${partIndex}.stages.${stageIndex}.qcApproved`]: true,
            [`parts.${partIndex}.stages.${stageIndex}.qcApprovalId`]: result.insertedId,
            [`parts.${partIndex}.stages.${stageIndex}.qcApprovedAt`]: new Date(),
            updated_at: new Date()
          }
        }
      );

      res.status(201).json({
        success: true,
        message: 'QC approval photo uploaded successfully',
        qcApprovalId: result.insertedId,
        photoUrl: req.file.location
      });

    } catch (error) {
      console.error('Error uploading QC approval photo:', error);
      res.status(500).json({ 
        success: false,
        message: 'Failed to upload QC approval photo', 
        error: error.message 
      });
    }
  }
);

// Get QC approval record
router.get('/qc-approvals/:id', auth, async (req, res) => {
  try {
    const { id } = req.params;
    
    const db = req.app.locals.db;
    const qcApprovalsCollection = db.collection('qc_approvals');
    
    const qcApproval = await qcApprovalsCollection.findOne({
      _id: new ObjectId(id)
    });

    if (!qcApproval) {
      return res.status(404).json({ 
        success: false,
        message: 'QC approval record not found' 
      });
    }

    // Generate signed URL for the photo if needed
    if (qcApproval.employeePhotoS3Key) {
      qcApproval.signedPhotoUrl = await getSignedUrl(qcApproval.employeePhotoS3Key);
    }

    res.json({
      success: true,
      qcApproval
    });

  } catch (error) {
    console.error('Error fetching QC approval:', error);
    res.status(500).json({ 
      success: false,
      message: 'Failed to fetch QC approval', 
      error: error.message 
    });
  }
});

// Get all QC approvals for a work order
router.get('/work-orders/:workOrderId/qc-approvals', auth, async (req, res) => {
  try {
    const { workOrderId } = req.params;
    
    const db = req.app.locals.db;
    const qcApprovalsCollection = db.collection('qc_approvals');
    
    const qcApprovals = await qcApprovalsCollection.find({
      workOrderId: new ObjectId(workOrderId)
    }).sort({ approvedAt: -1 }).toArray();

    // Generate signed URLs for photos
    for (const approval of qcApprovals) {
      if (approval.employeePhotoS3Key) {
        approval.signedPhotoUrl = await getSignedUrl(approval.employeePhotoS3Key);
      }
    }

    res.json({
      success: true,
      qcApprovals
    });

  } catch (error) {
    console.error('Error fetching QC approvals:', error);
    res.status(500).json({ 
      success: false,
      message: 'Failed to fetch QC approvals', 
      error: error.message 
    });
  }
});

module.exports = router;