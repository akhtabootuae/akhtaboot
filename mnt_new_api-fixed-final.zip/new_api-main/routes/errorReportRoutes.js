const express = require('express');
const router = express.Router();
const { ObjectId, Int32 } = require('mongodb');
const multer = require('multer');
const path = require('path');

// Import middleware
const auth = require('../middleware/auth');
const adminAuth = require('../middleware/adminAuth');
const permissionAuth = require('../middleware/permissionAuth');
const { createS3Upload, uploadConfigs, deleteFromS3, getSignedUrl } = require('../middleware/s3Upload');

// Import models
const { ErrorReport, WorkOrder, User } = require('../models');

// Configure S3 upload for error report images
const uploadErrorReportImage = createS3Upload({
  folderName: 'error-reports',
  ...uploadConfigs.images,
  fieldName: 'image'
});

// Create a new error report
router.post('/', auth, uploadErrorReportImage, async (req, res) => {
  try {
    const {
      workOrderId,
      partIndex,
      stageIndex,
      reportedStageId,
      problematicStageIndex,
      problematicTechnicianId,
      reportType,
      issueDescription,
      stagesToRedo,
      requiresVerification,
      verifyingTechnicianId,
      revertToStageIndex
    } = req.body;

    // Validate required fields
    if (!workOrderId || partIndex === undefined || stageIndex === undefined || 
        !reportedStageId || problematicStageIndex === undefined || 
        !problematicTechnicianId || !reportType || !issueDescription) {
      return res.status(400).json({ 
        message: 'Missing required fields',
        required: ['workOrderId', 'partIndex', 'stageIndex', 'reportedStageId', 
                   'problematicStageIndex', 'problematicTechnicianId', 'reportType', 
                   'issueDescription']
      });
    }

    // Validate image upload
    if (!req.file) {
      return res.status(400).json({ message: 'Evidence image is required' });
    }

    // Create error report data with S3 file information
    const errorReportData = {
      workOrderId: new ObjectId(workOrderId),
      partIndex: new Int32(parseInt(partIndex)),
      stageIndex: new Int32(parseInt(stageIndex)),
      reportedStageId: new ObjectId(reportedStageId),
      problematicStageIndex: new Int32(parseInt(problematicStageIndex)),
      reportingTechnicianId: new ObjectId(req.user.id),
      problematicTechnicianId: new ObjectId(problematicTechnicianId),
      reportType,
      issueDescription,
      imageS3Key: req.file.key,
      imageUrl: req.file.location,
      imageName: req.file.originalname,
      imageSize: new Int32(req.file.size),
      status: 'pending',
      stagesToRedo: stagesToRedo ? JSON.parse(stagesToRedo).map(s => new Int32(parseInt(s))) : [],
      requiresVerification: requiresVerification === 'true' || requiresVerification === true
    };

    // Only add optional fields if they have values
    if (verifyingTechnicianId) {
      errorReportData.verifyingTechnicianId = new ObjectId(verifyingTechnicianId);
    }
    if (revertToStageIndex !== undefined && revertToStageIndex !== null) {
      errorReportData.revertToStageIndex = new Int32(parseInt(revertToStageIndex));
    }

    // Create the error report
    const errorReport = await ErrorReport.create(req.app.locals.db, errorReportData);

    // If stages need to be redone, mark them
    if (errorReportData.stagesToRedo.length > 0) {
      await ErrorReport.markStagesForRedo(
        req.app.locals.db, 
        workOrderId, 
        parseInt(partIndex), 
        errorReportData.stagesToRedo.map(s => s.value) // Extract the actual integer value from Int32 objects
      );
    }

    // Send notification to supervisors and admins
    // TODO: Implement notification sending

    res.status(201).json({
      message: 'Error report created successfully',
      errorReport
    });

  } catch (err) {
    console.error('Error creating error report:', err);
    
    // Log detailed MongoDB validation error
    if (err.code === 121) {
      console.error('MongoDB Validation Error Details:', JSON.stringify(err, null, 2));
      if (err.errInfo && err.errInfo.details) {
        console.error('Validation Details:', JSON.stringify(err.errInfo.details, null, 2));
      }
    }
    
    // Clean up uploaded file from S3 if there was an error
    if (req.file && req.file.key) {
      try {
        await deleteFromS3(req.file.key);
      } catch (deleteError) {
        console.error('Error deleting S3 file:', deleteError);
      }
    }
    
    // Return more detailed error info for validation errors
    if (err.code === 121) {
      return res.status(400).json({ 
        message: 'Validation error', 
        error: err.message,
        details: err.errInfo ? err.errInfo.details : null
      });
    }
    
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// Get error report by ID
router.get('/:id', auth, async (req, res) => {
  try {
    const errorReport = await ErrorReport.getById(req.app.locals.db, req.params.id);
    
    if (!errorReport) {
      return res.status(404).json({ message: 'Error report not found' });
    }

    // Generate signed URL for the error report image if it has an S3 key
    if (errorReport.imageS3Key) {
      try {
        const signedUrl = await getSignedUrl(errorReport.imageS3Key, 3600); // 1 hour expiry
        errorReport.imageSignedUrl = signedUrl;
      } catch (urlError) {
        console.error('Error generating signed URL:', urlError);
        // Continue without the signed URL if there's an error
      }
    }

    res.json(errorReport);
  } catch (err) {
    console.error('Error fetching error report:', err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// Get all error reports for a work order
router.get('/work-order/:workOrderId', auth, async (req, res) => {
  try {
    const errorReports = await ErrorReport.getByWorkOrder(
      req.app.locals.db, 
      req.params.workOrderId
    );
    
    // Generate signed URLs for all error reports that have S3 keys
    const errorReportsWithSignedUrls = await Promise.all(
      errorReports.map(async (errorReport) => {
        if (errorReport.imageS3Key) {
          try {
            const signedUrl = await getSignedUrl(errorReport.imageS3Key, 3600); // 1 hour expiry
            errorReport.imageSignedUrl = signedUrl;
          } catch (urlError) {
            console.error('Error generating signed URL for error report:', errorReport._id, urlError);
            // Continue without the signed URL if there's an error
          }
        }
        return errorReport;
      })
    );
    
    res.json(errorReportsWithSignedUrls);
  } catch (err) {
    console.error('Error fetching error reports:', err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// Get error reports by technician
router.get('/technician/:technicianId', auth, async (req, res) => {
  try {
    const { type = 'reported' } = req.query;
    
    const errorReports = await ErrorReport.getByTechnician(
      req.app.locals.db, 
      req.params.technicianId,
      type
    );
    
    // Generate signed URLs for all error reports that have S3 keys
    const errorReportsWithSignedUrls = await Promise.all(
      errorReports.map(async (errorReport) => {
        if (errorReport.imageS3Key) {
          try {
            const signedUrl = await getSignedUrl(errorReport.imageS3Key, 3600); // 1 hour expiry
            errorReport.imageSignedUrl = signedUrl;
          } catch (urlError) {
            console.error('Error generating signed URL for error report:', errorReport._id, urlError);
            // Continue without the signed URL if there's an error
          }
        }
        return errorReport;
      })
    );
    
    res.json(errorReportsWithSignedUrls);
  } catch (err) {
    console.error('Error fetching technician error reports:', err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// Acknowledge an error report
router.put('/:id/acknowledge', auth, permissionAuth('acknowledge_error_reports'), async (req, res) => {
  try {
    const success = await ErrorReport.acknowledge(
      req.app.locals.db, 
      req.params.id,
      req.user.id
    );
    
    if (!success) {
      return res.status(404).json({ message: 'Error report not found' });
    }

    res.json({ message: 'Error report acknowledged successfully' });
  } catch (err) {
    console.error('Error acknowledging error report:', err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// Resolve an error report
router.put('/:id/resolve', auth, permissionAuth('resolve_error_reports'), async (req, res) => {
  try {
    const { resolution } = req.body;
    
    if (!resolution) {
      return res.status(400).json({ message: 'Resolution description is required' });
    }

    const success = await ErrorReport.resolve(
      req.app.locals.db, 
      req.params.id,
      req.user.id,
      resolution
    );
    
    if (!success) {
      return res.status(404).json({ message: 'Error report not found' });
    }

    res.json({ message: 'Error report resolved successfully' });
  } catch (err) {
    console.error('Error resolving error report:', err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// Get error summary for a work order
router.get('/work-order/:workOrderId/summary', auth, async (req, res) => {
  try {
    const summary = await ErrorReport.getErrorSummary(
      req.app.locals.db, 
      req.params.workOrderId
    );
    
    res.json(summary);
  } catch (err) {
    console.error('Error fetching error summary:', err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// Mark stages for redo
router.post('/mark-redo', auth, permissionAuth('mark_stage_redo'), async (req, res) => {
  try {
    const { workOrderId, partIndex, stageIndices } = req.body;
    
    if (!workOrderId || partIndex === undefined || !stageIndices || !Array.isArray(stageIndices)) {
      return res.status(400).json({ 
        message: 'Missing required fields',
        required: ['workOrderId', 'partIndex', 'stageIndices (array)']
      });
    }

    await ErrorReport.markStagesForRedo(
      req.app.locals.db,
      workOrderId,
      parseInt(partIndex),
      stageIndices.map(s => parseInt(s))
    );

    res.json({ message: 'Stages marked for redo successfully' });
  } catch (err) {
    console.error('Error marking stages for redo:', err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// Start verification process for an error report
router.post('/:id/start-verification', auth, async (req, res) => {
  try {
    const { verifyingTechnicianId } = req.body;
    
    if (!verifyingTechnicianId) {
      return res.status(400).json({ 
        message: 'Missing required field: verifyingTechnicianId' 
      });
    }

    // Check if error report exists and requires verification
    const errorReport = await ErrorReport.getById(req.app.locals.db, req.params.id);
    if (!errorReport) {
      return res.status(404).json({ message: 'Error report not found' });
    }

    if (!errorReport.requiresVerification) {
      return res.status(400).json({ 
        message: 'Error report does not require verification' 
      });
    }

    if (errorReport.verificationStatus !== 'pending') {
      return res.status(400).json({ 
        message: 'Error report verification has already been started or completed' 
      });
    }

    const success = await ErrorReport.startVerification(
      req.app.locals.db,
      req.params.id,
      verifyingTechnicianId
    );

    if (!success) {
      return res.status(404).json({ message: 'Failed to start verification' });
    }

    res.json({ message: 'Verification process started successfully' });
  } catch (err) {
    console.error('Error starting verification:', err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// Complete verification with verdict
router.post('/:id/complete-verification', auth, async (req, res) => {
  try {
    const { verdict, notes, revertToStageIndex } = req.body;
    
    if (!verdict) {
      return res.status(400).json({ 
        message: 'Missing required field: verdict' 
      });
    }

    if (!['good_standard', 'not_good_standard'].includes(verdict)) {
      return res.status(400).json({ 
        message: 'Invalid verdict. Must be "good_standard" or "not_good_standard"' 
      });
    }

    // Check if error report exists and is in verification
    const errorReport = await ErrorReport.getById(req.app.locals.db, req.params.id);
    if (!errorReport) {
      return res.status(404).json({ message: 'Error report not found' });
    }

    if (!errorReport.requiresVerification) {
      return res.status(400).json({ 
        message: 'Error report does not require verification' 
      });
    }

    if (errorReport.verificationStatus !== 'in_progress') {
      return res.status(400).json({ 
        message: 'Error report verification is not in progress' 
      });
    }

    // Ensure the current user is the assigned verifying technician
    if (errorReport.verifyingTechnicianId.toString() !== req.user.id) {
      return res.status(403).json({ 
        message: 'Only the assigned verifying technician can complete this verification' 
      });
    }

    const verificationData = {
      verdict,
      notes: notes || '',
      verifiedBy: req.user.id,
      revertToStageIndex: verdict === 'not_good_standard' ? revertToStageIndex : undefined
    };

    const success = await ErrorReport.completeVerification(
      req.app.locals.db,
      req.params.id,
      verificationData
    );

    if (!success) {
      return res.status(404).json({ message: 'Failed to complete verification' });
    }

    res.json({ 
      message: 'Verification completed successfully',
      verdict: verdict 
    });
  } catch (err) {
    console.error('Error completing verification:', err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// Get pending verifications for a technician
router.get('/pending-verifications', auth, async (req, res) => {
  try {
    const { technicianId } = req.query;
    
    // If technicianId is provided, get verifications for that technician
    // Otherwise, get all pending verifications
    let verifications;
    
    if (technicianId) {
      // Get in-progress verifications for specific technician
      verifications = await ErrorReport.getVerificationInProgress(
        req.app.locals.db,
        technicianId
      );
    } else {
      // Get all pending verifications that haven't been assigned yet
      verifications = await ErrorReport.getVerificationPending(req.app.locals.db);
    }

    res.json(verifications);
  } catch (err) {
    console.error('Error fetching pending verifications:', err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// Admin verification endpoint (for when no technician is available)
router.post('/:id/admin-verification', auth, adminAuth, async (req, res) => {
  try {
    const { verdict, notes, reason, revertToStageIndex } = req.body;
    
    if (!verdict || !reason) {
      return res.status(400).json({ 
        message: 'Missing required fields: verdict and reason' 
      });
    }

    if (!['good_standard', 'not_good_standard'].includes(verdict)) {
      return res.status(400).json({ 
        message: 'Invalid verdict. Must be "good_standard" or "not_good_standard"' 
      });
    }

    // Check if error report exists and requires verification
    const errorReport = await ErrorReport.getById(req.app.locals.db, req.params.id);
    if (!errorReport) {
      return res.status(404).json({ message: 'Error report not found' });
    }

    if (!errorReport.requiresVerification) {
      return res.status(400).json({ 
        message: 'Error report does not require verification' 
      });
    }

    if (errorReport.verificationStatus && 
        ['verified_good', 'verified_bad', 'admin_verified'].includes(errorReport.verificationStatus)) {
      return res.status(400).json({ 
        message: 'Error report verification has already been completed' 
      });
    }

    const verificationData = {
      verdict,
      notes: notes || '',
      revertToStageIndex: verdict === 'not_good_standard' ? revertToStageIndex : undefined
    };

    const success = await ErrorReport.adminVerification(
      req.app.locals.db,
      req.params.id,
      req.user.id,
      reason,
      verificationData
    );

    if (!success) {
      return res.status(404).json({ message: 'Failed to complete admin verification' });
    }

    res.json({ 
      message: 'Admin verification completed successfully',
      verdict: verdict 
    });
  } catch (err) {
    console.error('Error completing admin verification:', err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

module.exports = router;