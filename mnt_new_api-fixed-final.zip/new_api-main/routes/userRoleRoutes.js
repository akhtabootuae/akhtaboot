const express = require('express');
const router = express.Router();
const { ObjectId } = require('mongodb');
const auth = require('../middleware/auth');
const adminAuth = require('../middleware/adminAuth');
const permissionAuth = require('../middleware/permissionAuth');

/**
 * @route   PUT /api/users/:userId/role
 * @desc    Assign a role to a user
 * @access  Admin only
 */
router.put('/:userId/role', auth, adminAuth, async (req, res) => {
  try {
    const { roleId } = req.body;

    if (!roleId) {
      return res.status(400).json({ message: 'Role ID is required' });
    }

    // Check if user exists
    const user = await req.app.locals.db.collection('users').findOne({
      _id: new ObjectId(req.params.userId)
    });

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Check if role exists
    const role = await req.app.locals.db.collection('roles').findOne({
      _id: new ObjectId(roleId)
    });

    if (!role) {
      return res.status(404).json({ message: 'Role not found' });
    }

    // Update user's role
    await req.app.locals.db.collection('users').updateOne(
      { _id: new ObjectId(req.params.userId) },
      {
        $set: {
          role_id: new ObjectId(roleId),
          role_name: role.role_name,
          role_description: role.description,
          updated_at: new Date()
        }
      }
    );

    res.json({ message: 'User role updated successfully' });
  } catch (error) {
    console.error('Error updating user role:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

/**
 * @route   GET /api/users/role/:roleId
 * @desc    Get all users with a specific role
 * @access  Admin or users with view_users_by_role permission
 */
router.get('/role/:roleId', auth, permissionAuth('view_users_by_role'), async (req, res) => {
  try {
    const users = await req.app.locals.db.collection('users').find({
      role_id: new ObjectId(req.params.roleId)
    }).toArray();

    res.json(users);
  } catch (error) {
    console.error('Error fetching users by role:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
