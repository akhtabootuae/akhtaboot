const express = require('express');
const router = express.Router();
const { ObjectId } = require('mongodb');
const auth = require('../middleware/auth');
const adminAuth = require('../middleware/adminAuth');
const permissionAuth = require('../middleware/permissionAuth');

/**
 * @route   GET /api/branches
 * @desc    Get all branches
 * @access  Authenticated users
 */
router.get('/', auth, async (req, res) => {
  try {
    const branches = await req.app.locals.db.collection('branches').find({}).toArray();
    res.json(branches);
  } catch (error) {
    console.error('Error fetching branches:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

/**
 * @route   GET /api/branches/:id
 * @desc    Get branch by ID
 * @access  Authenticated users
 */
router.get('/:id', auth, async (req, res) => {
  try {
    const branch = await req.app.locals.db.collection('branches').findOne({
      _id: new ObjectId(req.params.id)
    });
    
    if (!branch) {
      return res.status(404).json({ message: 'Branch not found' });
    }
    
    res.json(branch);
  } catch (error) {
    console.error('Error fetching branch:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

/**
 * @route   POST /api/branches
 * @desc    Create a new branch
 * @access  Admin only
 */
router.post('/', auth, adminAuth, async (req, res) => {
  try {
    const { branch_name, branch_code, location } = req.body;
    
    // Validate required fields
    if (!branch_name || !branch_code) {
      return res.status(400).json({ 
        message: 'Branch name and code are required' 
      });
    }
    
    // Check if branch with the same code already exists
    const existingBranch = await req.app.locals.db.collection('branches').findOne({ branch_code });
    if (existingBranch) {
      return res.status(400).json({ message: 'A branch with this code already exists' });
    }
    
    const now = new Date();
    
    const newBranch = {
      branch_name,
      branch_code,
      location: location || "",
      created_at: now,
      updated_at: now
    };
    
    const result = await req.app.locals.db.collection('branches').insertOne(newBranch);
    
    res.status(201).json({
      _id: result.insertedId,
      ...newBranch
    });
  } catch (error) {
    console.error('Error creating branch:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

/**
 * @route   PUT /api/branches/:id
 * @desc    Update a branch
 * @access  Admin only
 */
router.put('/:id', auth, adminAuth, async (req, res) => {
  try {
    const { branch_name, branch_code, location } = req.body;
    
    // Validate required fields
    if (!branch_name && !branch_code && !location) {
      return res.status(400).json({ 
        message: 'Please provide at least one field to update' 
      });
    }
    
    // Check if branch exists
    const branch = await req.app.locals.db.collection('branches').findOne({
      _id: new ObjectId(req.params.id)
    });
    
    if (!branch) {
      return res.status(404).json({ message: 'Branch not found' });
    }
    
    // If branch_code is being updated, check that it's unique
    if (branch_code && branch_code !== branch.branch_code) {
      const existingBranch = await req.app.locals.db.collection('branches').findOne({ 
        branch_code,
        _id: { $ne: new ObjectId(req.params.id) }
      });
      
      if (existingBranch) {
        return res.status(400).json({ message: 'A branch with this code already exists' });
      }
    }
    
    // Build update object
    const updateObj = {
      updated_at: new Date()
    };
    
    if (branch_name) updateObj.branch_name = branch_name;
    if (branch_code) updateObj.branch_code = branch_code;
    if (location !== undefined) updateObj.location = location;
    
    // Update the branch
    await req.app.locals.db.collection('branches').updateOne(
      { _id: new ObjectId(req.params.id) },
      { $set: updateObj }
    );
    
    // Return the updated branch
    const updatedBranch = await req.app.locals.db.collection('branches').findOne({
      _id: new ObjectId(req.params.id)
    });
    
    res.json(updatedBranch);
  } catch (error) {
    console.error('Error updating branch:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

/**
 * @route   DELETE /api/branches/:id
 * @desc    Delete a branch
 * @access  Admin only
 */
router.delete('/:id', auth, adminAuth, async (req, res) => {
  try {
    // Check if branch exists
    const branch = await req.app.locals.db.collection('branches').findOne({
      _id: new ObjectId(req.params.id)
    });
    
    if (!branch) {
      return res.status(404).json({ message: 'Branch not found' });
    }
    
    // Check if any users are assigned to this branch
    const usersInBranch = await req.app.locals.db.collection('users').countDocuments({
      'branch.branch_id': new ObjectId(req.params.id)
    });
    
    if (usersInBranch > 0) {
      return res.status(400).json({ 
        message: 'Cannot delete branch that has users assigned to it',
        usersCount: usersInBranch 
      });
    }
    
    // Delete the branch
    await req.app.locals.db.collection('branches').deleteOne({ 
      _id: new ObjectId(req.params.id) 
    });
    
    res.json({ message: 'Branch deleted successfully' });
  } catch (error) {
    console.error('Error deleting branch:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

/**
 * @route   GET /api/branches/:id/users
 * @desc    Get all users assigned to a specific branch
 * @access  Admin or user with view_all_users permission
 */
router.get('/:id/users', auth, permissionAuth('view_all_users'), async (req, res) => {
  try {
    // Check if branch exists
    const branch = await req.app.locals.db.collection('branches').findOne({
      _id: new ObjectId(req.params.id)
    });
    
    if (!branch) {
      return res.status(404).json({ message: 'Branch not found' });
    }
    
    // Find users in the branch
    const users = await req.app.locals.db.collection('users').find({
      'branch.branch_id': new ObjectId(req.params.id)
    }).toArray();
    
    res.json(users);
  } catch (error) {
    console.error('Error fetching branch users:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

/**
 * @route   POST /api/branches/:id/assign-users
 * @desc    Assign multiple users to a branch
 * @access  Admin only
 */
router.post('/:id/assign-users', auth, adminAuth, async (req, res) => {
  try {
    const { userIds } = req.body;
    
    if (!userIds || !Array.isArray(userIds) || userIds.length === 0) {
      return res.status(400).json({ 
        message: 'Please provide an array of user IDs to assign to this branch' 
      });
    }
    
    // Check if branch exists
    const branch = await req.app.locals.db.collection('branches').findOne({
      _id: new ObjectId(req.params.id)
    });
    
    if (!branch) {
      return res.status(404).json({ message: 'Branch not found' });
    }
    
    // Convert string IDs to ObjectIds
    const objectUserIds = userIds.map(id => new ObjectId(id));
    
    // Update all specified users
    const result = await req.app.locals.db.collection('users').updateMany(
      { _id: { $in: objectUserIds } },
      {
        $set: {
          "branch.branch_id": branch._id,
          "branch.branch_name": branch.branch_name,
          "branch.branch_code": branch.branch_code,
          "branch.location": branch.location,
          updated_at: new Date()
        }
      }
    );
    
    res.json({ 
      message: 'Users assigned to branch successfully',
      matchedCount: result.matchedCount,
      modifiedCount: result.modifiedCount,
      branch: {
        branch_id: branch._id,
        branch_name: branch.branch_name,
        branch_code: branch.branch_code,
        location: branch.location
      }
    });
  } catch (error) {
    console.error('Error assigning users to branch:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
