const express = require('express');
const router = express.Router();

// Import deduction route modules
const deductionTypeRoutes = require('./deductionTypes');
const employeeDeductionRoutes = require('./employeeDeductions');
const deductionHistoryRoutes = require('./deductionHistory');

// Import Phase 3 route modules
const timesheetRoutes = require('./timesheets');
const payPeriodRoutes = require('./payPeriods');
const calculationRoutes = require('./calculations');

// Import Phase 4 route modules
const reportRoutes = require('./reports');
const paystubRoutes = require('./paystubs');

// Import Phase 5 route modules
const alertRoutes = require('./alerts');
const budgetRoutes = require('./budgets');

// Mount deduction routes
router.use('/deduction-types', deductionTypeRoutes);
router.use('/employees', employeeDeductionRoutes);
router.use('/employees', deductionHistoryRoutes);

// Mount non-employee specific routes from deductionHistory
router.use('/', deductionHistoryRoutes);

// Mount Phase 3 routes
router.use('/timesheets', timesheetRoutes);
router.use('/pay-periods', payPeriodRoutes);
router.use('/calculations', calculationRoutes);

// Mount Phase 4 routes
router.use('/reports', reportRoutes);
router.use('/paystubs', paystubRoutes);

// Mount Phase 5 routes
router.use('/alerts', alertRoutes);
router.use('/budgets', budgetRoutes);

module.exports = router;