const express = require('express');
const router = express.Router();
const { ObjectId } = require('mongodb');
const PayrollEmployeeDeduction = require('../../models/PayrollEmployeeDeduction');
const PayrollAuditLog = require('../../models/PayrollAuditLog');
const User = require('../../models/User');
const permissionAuth = require('../../middleware/permissionAuth');

// GET /api/payroll/employees/:employeeId/deductions - Get employee's deductions
router.get('/:employeeId/deductions',
  permissionAuth(['payroll_manage_deductions', 'payroll_view_deductions']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { status, active_only } = req.query;
      
      const filters = {};
      if (status) filters.status = status;
      if (active_only === 'true') filters.active_only = true;
      
      const deductions = await PayrollEmployeeDeduction.findByEmployee(db, req.params.employeeId, filters);
      
      res.json({
        message: 'Employee deductions retrieved successfully',
        deductions: deductions
      });
    } catch (error) {
      console.error('Error fetching employee deductions:', error);
      res.status(500).json({
        message: 'Failed to retrieve employee deductions',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/deductions/:id - Get specific deduction
router.get('/deductions/:id',
  permissionAuth(['payroll_manage_deductions', 'payroll_view_deductions']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const deduction = await PayrollEmployeeDeduction.findById(db, req.params.id);
      
      if (!deduction) {
        return res.status(404).json({
          message: 'Deduction not found'
        });
      }
      
      res.json({
        message: 'Deduction retrieved successfully',
        deduction: deduction
      });
    } catch (error) {
      console.error('Error fetching deduction:', error);
      res.status(500).json({
        message: 'Failed to retrieve deduction',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/employees/:employeeId/deductions - Create new deduction
router.post('/:employeeId/deductions',
  permissionAuth('payroll_manage_deductions'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      const deductionData = {
        ...req.body,
        employee_id: req.params.employeeId,
        created_by: req.user._id
      };
      
      const deduction = await PayrollEmployeeDeduction.create(db, deductionData);
      
      // Log the audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'create_deduction',
        entity_type: 'employee_deduction',
        entity_id: deduction._id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          employee_id: req.params.employeeId,
          deduction_type_id: deductionData.deduction_type_id,
          amount: deductionData.amount,
          frequency: deductionData.frequency
        },
        severity: 'medium',
        category: 'data_modification'
      });
      
      res.status(201).json({
        message: 'Employee deduction created successfully',
        deduction: deduction
      });
    } catch (error) {
      console.error('Error creating employee deduction:', error);
      res.status(400).json({
        message: 'Failed to create employee deduction',
        error: error.message
      });
    }
  }
);

// PUT /api/payroll/deductions/:id - Update deduction
router.put('/deductions/:id',
  permissionAuth('payroll_manage_deductions'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      // Get existing deduction for audit
      const existingDeduction = await PayrollEmployeeDeduction.findById(db, req.params.id);
      if (!existingDeduction) {
        return res.status(404).json({
          message: 'Deduction not found'
        });
      }
      
      const success = await PayrollEmployeeDeduction.update(db, req.params.id, req.body);
      
      if (!success) {
        return res.status(404).json({
          message: 'Deduction not found or no changes made'
        });
      }
      
      // Log the audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'update_deduction',
        entity_type: 'employee_deduction',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          old_values: existingDeduction,
          new_values: req.body
        },
        severity: 'medium',
        category: 'data_modification'
      });
      
      const updatedDeduction = await PayrollEmployeeDeduction.findById(db, req.params.id);
      
      res.json({
        message: 'Deduction updated successfully',
        deduction: updatedDeduction
      });
    } catch (error) {
      console.error('Error updating deduction:', error);
      res.status(500).json({
        message: 'Failed to update deduction',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/deductions/:id/approve - Approve deduction
router.post('/deductions/:id/approve',
  permissionAuth('payroll_approve_deductions'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      const success = await PayrollEmployeeDeduction.approve(db, req.params.id, req.user._id);
      
      if (!success) {
        return res.status(404).json({
          message: 'Deduction not found or not pending approval'
        });
      }
      
      // Log the audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'approve_deduction',
        entity_type: 'employee_deduction',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          approval_notes: req.body.notes
        },
        severity: 'high',
        category: 'authorization'
      });
      
      const approvedDeduction = await PayrollEmployeeDeduction.findById(db, req.params.id);
      
      res.json({
        message: 'Deduction approved successfully',
        deduction: approvedDeduction
      });
    } catch (error) {
      console.error('Error approving deduction:', error);
      res.status(500).json({
        message: 'Failed to approve deduction',
        error: error.message
      });
    }
  }
);

// PUT /api/payroll/deductions/:id/status - Update deduction status
router.put('/deductions/:id/status',
  permissionAuth('payroll_manage_deductions'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { status, reason } = req.body;
      
      if (!['active', 'paused', 'cancelled'].includes(status)) {
        return res.status(400).json({
          message: 'Invalid status. Must be active, paused, or cancelled'
        });
      }
      
      const updateData = { status };
      if (status === 'cancelled') {
        updateData.end_date = new Date();
      }
      
      const success = await PayrollEmployeeDeduction.update(db, req.params.id, updateData);
      
      if (!success) {
        return res.status(404).json({
          message: 'Deduction not found'
        });
      }
      
      // Log the audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'update_deduction_status',
        entity_type: 'employee_deduction',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          new_status: status,
          reason: reason
        },
        severity: 'medium',
        category: 'data_modification'
      });
      
      const updatedDeduction = await PayrollEmployeeDeduction.findById(db, req.params.id);
      
      res.json({
        message: 'Deduction status updated successfully',
        deduction: updatedDeduction
      });
    } catch (error) {
      console.error('Error updating deduction status:', error);
      res.status(500).json({
        message: 'Failed to update deduction status',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/deductions/pending-approvals - Get pending approvals
router.get('/deductions/pending-approvals',
  permissionAuth('payroll_approve_deductions'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { page = 1, limit = 50 } = req.query;
      
      const options = {
        limit: parseInt(limit),
        skip: (parseInt(page) - 1) * parseInt(limit)
      };
      
      const pendingDeductions = await PayrollEmployeeDeduction.getPendingApprovals(db, options);
      
      res.json({
        message: 'Pending approvals retrieved successfully',
        pending_deductions: pendingDeductions,
        pagination: {
          current_page: parseInt(page),
          limit: parseInt(limit)
        }
      });
    } catch (error) {
      console.error('Error fetching pending approvals:', error);
      res.status(500).json({
        message: 'Failed to retrieve pending approvals',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/employees/count - Get count of employees (non-admin users)
router.get('/count',
  permissionAuth(['payroll_view_employees', 'payroll_manage_deductions']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { 
        active_only = 'true', 
        branch_id, 
        role_name,
        payroll_eligible_only = 'false',
        include_terminated = 'false'
      } = req.query;
      
      // Build filter for non-admin users
      const filter = {
        role_name: { $ne: 'Admin' } // Exclude admin users
      };
      
      // Add active status filter
      if (active_only === 'true') {
        filter.is_active = true;
      }
      
      // Add branch filter if specified
      if (branch_id) {
        filter['branch.branch_id'] = new ObjectId(branch_id);
      }
      
      // Add role filter if specified
      if (role_name) {
        filter.role_name = role_name;
      }
      
      // Add payroll eligibility filter if specified
      if (payroll_eligible_only === 'true') {
        filter['payroll_info.eligible'] = true;
      }
      
      // Exclude terminated employees unless specifically requested
      if (include_terminated !== 'true') {
        filter.$or = [
          { 'payroll_info.hire_date': { $exists: false } },
          { 'payroll_info.termination_date': { $exists: false } },
          { 'payroll_info.termination_date': null }
        ];
      }
      
      // Get total count
      const totalCount = await db.collection('users').countDocuments(filter);
      
      // Get breakdown by role
      const roleBreakdown = await db.collection('users').aggregate([
        { $match: filter },
        { 
          $group: {
            _id: '$role_name',
            count: { $sum: 1 }
          }
        },
        { $sort: { count: -1 } }
      ]).toArray();
      
      // Get breakdown by branch if user has admin privileges
      let branchBreakdown = null;
      if (req.user.role_name === 'Admin' || User.hasPermission(req.user, 'view_all_employees')) {
        branchBreakdown = await db.collection('users').aggregate([
          { $match: filter },
          { 
            $group: {
              _id: {
                branch_id: '$branch.branch_id',
                branch_name: '$branch.branch_name'
              },
              count: { $sum: 1 }
            }
          },
          { $sort: { count: -1 } }
        ]).toArray();
      }
      
      // Get payroll eligibility breakdown
      const payrollBreakdown = await db.collection('users').aggregate([
        { $match: { role_name: { $ne: 'Admin' } } }, // All non-admin users for comparison
        {
          $group: {
            _id: '$payroll_info.eligible',
            count: { $sum: 1 }
          }
        }
      ]).toArray();
      
      const response = {
        message: 'Employee count retrieved successfully',
        total_employees: totalCount,
        breakdown: {
          by_role: roleBreakdown,
          by_payroll_eligibility: payrollBreakdown.map(item => ({
            eligible: item._id === true ? 'Yes' : item._id === false ? 'No' : 'Unknown',
            count: item.count
          }))
        },
        filters_applied: {
          active_only: active_only === 'true',
          branch_id: branch_id || null,
          role_name: role_name || null,
          payroll_eligible_only: payroll_eligible_only === 'true',
          include_terminated: include_terminated === 'true'
        }
      };
      
      // Add branch breakdown if available
      if (branchBreakdown) {
        response.breakdown.by_branch = branchBreakdown.map(item => ({
          branch_id: item._id.branch_id,
          branch_name: item._id.branch_name,
          count: item.count
        }));
      }
      
      res.json(response);
    } catch (error) {
      console.error('Error fetching employee count:', error);
      res.status(500).json({
        message: 'Failed to retrieve employee count',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/employees/summary - Get employee summary statistics
router.get('/summary',
  permissionAuth(['payroll_view_employees', 'payroll_manage_deductions']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { branch_id } = req.query;
      
      const matchFilter = {
        role_name: { $ne: 'Admin' } // Exclude admin users
      };
      
      if (branch_id) {
        matchFilter['branch.branch_id'] = new ObjectId(branch_id);
      }
      
      const summary = await db.collection('users').aggregate([
        { $match: matchFilter },
        {
          $group: {
            _id: null,
            total_employees: { $sum: 1 },
            active_employees: {
              $sum: { $cond: [{ $eq: ['$is_active', true] }, 1, 0] }
            },
            inactive_employees: {
              $sum: { $cond: [{ $eq: ['$is_active', false] }, 1, 0] }
            },
            payroll_eligible: {
              $sum: { $cond: [{ $eq: ['$payroll_info.eligible', true] }, 1, 0] }
            },
            payroll_ineligible: {
              $sum: { $cond: [{ $eq: ['$payroll_info.eligible', false] }, 1, 0] }
            },
            with_deductions: {
              $sum: { $cond: [{ $gt: [{ $size: { $ifNull: ['$deductions', []] } }, 0] }, 1, 0] }
            }
          }
        }
      ]).toArray();
      
      const result = summary[0] || {
        total_employees: 0,
        active_employees: 0,
        inactive_employees: 0,
        payroll_eligible: 0,
        payroll_ineligible: 0,
        with_deductions: 0
      };
      
      // Calculate percentages
      const total = result.total_employees;
      const statistics = {
        ...result,
        percentages: total > 0 ? {
          active: Math.round((result.active_employees / total) * 100),
          payroll_eligible: Math.round((result.payroll_eligible / total) * 100),
          with_deductions: Math.round((result.with_deductions / total) * 100)
        } : {
          active: 0,
          payroll_eligible: 0,
          with_deductions: 0
        }
      };
      
      res.json({
        message: 'Employee summary retrieved successfully',
        summary: statistics,
        filters_applied: {
          branch_id: branch_id || null,
          excludes_admin: true
        }
      });
    } catch (error) {
      console.error('Error fetching employee summary:', error);
      res.status(500).json({
        message: 'Failed to retrieve employee summary',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/employees/list - Get list of employees (non-admin users) with basic info
router.get('/list',
  permissionAuth(['payroll_view_employees', 'payroll_manage_deductions']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { 
        page = 1, 
        limit = 50, 
        active_only = 'true',
        branch_id,
        role_name,
        payroll_eligible_only = 'false',
        include_rates = 'false',
        search 
      } = req.query;
      
      // Build filter for non-admin users
      const filter = {
        role_name: { $ne: 'Admin' } // Exclude admin users
      };
      
      // Add active status filter
      if (active_only === 'true') {
        filter.is_active = true;
      }
      
      // Add branch filter if specified
      if (branch_id) {
        filter['branch.branch_id'] = new ObjectId(branch_id);
      }
      
      // Add role filter if specified
      if (role_name) {
        filter.role_name = role_name;
      }
      
      // Add payroll eligibility filter if specified
      if (payroll_eligible_only === 'true') {
        filter['payroll_info.eligible'] = true;
      }
      
      // Add search filter if specified
      if (search) {
        const searchRegex = new RegExp(search, 'i');
        filter.$or = [
          { first_name: { $regex: searchRegex } },
          { last_name: { $regex: searchRegex } },
          { email: { $regex: searchRegex } },
          { staff_code: { $regex: searchRegex } },
          { 'payroll_info.employee_id': { $regex: searchRegex } }
        ];
      }
      
      const options = {
        limit: parseInt(limit),
        skip: (parseInt(page) - 1) * parseInt(limit),
        sort: { last_name: 1, first_name: 1 } // Sort by last name, then first name
      };
      
      // Get employees with basic information
      const employees = await db.collection('users')
        .find(filter, {
          projection: {
            password_hash: 0, // Exclude sensitive data
            permission_logs: 0,
            permissions: 0
          }
        })
        .sort(options.sort)
        .skip(options.skip)
        .limit(options.limit)
        .toArray();
      
      // Get total count for pagination
      const totalCount = await db.collection('users').countDocuments(filter);
      
      let formattedEmployees;
      
      // If include_rates is true, fetch daily rate information for each employee
      if (include_rates === 'true') {
        const employeeIds = employees.map(emp => emp._id);
        
        // Get current rates for all employees in batch
        const currentRates = await db.collection('payroll_rates').aggregate([
          {
            $match: {
              employee_id: { $in: employeeIds },
              effective_date: { $lte: new Date() },
              $or: [
                { end_date: null },
                { end_date: { $gt: new Date() } }
              ]
            }
          },
          {
            $sort: { employee_id: 1, effective_date: -1 }
          },
          {
            $group: {
              _id: '$employee_id',
              current_rate: { $first: '$$ROOT' }
            }
          }
        ]).toArray();
        
        // Create a map for quick lookup
        const ratesMap = new Map();
        currentRates.forEach(item => {
          ratesMap.set(item._id.toString(), item.current_rate);
        });
        
        // Format employee data with rate information
        formattedEmployees = employees.map(employee => {
          const currentRate = ratesMap.get(employee._id.toString());
          
          return {
            _id: employee._id,
            employee_id: employee.payroll_info?.employee_id || null,
            first_name: employee.first_name,
            last_name: employee.last_name,
            full_name: `${employee.first_name} ${employee.last_name}`,
            email: employee.email,
            phone: employee.phone || null,
            staff_code: employee.staff_code || null,
            speciality: employee.speciality || null,
            role_name: employee.role_name,
            is_active: employee.is_active,
            branch: {
              branch_id: employee.branch?.branch_id || null,
              branch_name: employee.branch?.branch_name || null,
              branch_code: employee.branch?.branch_code || null
            },
            payroll_info: {
              eligible: employee.payroll_info?.eligible || false,
              employee_id: employee.payroll_info?.employee_id || null,
              hire_date: employee.payroll_info?.hire_date || null,
              employment_type: employee.payroll_info?.employment_type || null
            },
            daily_rate: currentRate ? {
              rate_id: currentRate._id,
              daily_rate: currentRate.daily_rate,
              rate_type: currentRate.rate_type,
              effective_date: currentRate.effective_date,
              end_date: currentRate.end_date,
              created_at: currentRate.created_at,
              notes: currentRate.notes || null
            } : null,
            created_at: employee.created_at,
            updated_at: employee.updated_at
          };
        });
      } else {
        // Format employee data without rate information (original logic)
        formattedEmployees = employees.map(employee => ({
          _id: employee._id,
          employee_id: employee.payroll_info?.employee_id || null,
          first_name: employee.first_name,
          last_name: employee.last_name,
          full_name: `${employee.first_name} ${employee.last_name}`,
          email: employee.email,
          phone: employee.phone || null,
          staff_code: employee.staff_code || null,
          speciality: employee.speciality || null,
          role_name: employee.role_name,
          is_active: employee.is_active,
          branch: {
            branch_id: employee.branch?.branch_id || null,
            branch_name: employee.branch?.branch_name || null,
            branch_code: employee.branch?.branch_code || null
          },
          payroll_info: {
            eligible: employee.payroll_info?.eligible || false,
            employee_id: employee.payroll_info?.employee_id || null,
            hire_date: employee.payroll_info?.hire_date || null,
            employment_type: employee.payroll_info?.employment_type || null
          },
          created_at: employee.created_at,
          updated_at: employee.updated_at
        }));
      }
      
      res.json({
        message: 'Employee list retrieved successfully',
        employees: formattedEmployees,
        pagination: {
          current_page: parseInt(page),
          total_pages: Math.ceil(totalCount / parseInt(limit)),
          total_records: totalCount,
          limit: parseInt(limit),
          has_next: parseInt(page) < Math.ceil(totalCount / parseInt(limit)),
          has_prev: parseInt(page) > 1
        },
        filters_applied: {
          active_only: active_only === 'true',
          branch_id: branch_id || null,
          role_name: role_name || null,
          payroll_eligible_only: payroll_eligible_only === 'true',
          include_rates: include_rates === 'true',
          search: search || null,
          excludes_admin: true
        }
      });
    } catch (error) {
      console.error('Error fetching employee list:', error);
      res.status(500).json({
        message: 'Failed to retrieve employee list',
        error: error.message
      });
    }
  }
);

module.exports = router;