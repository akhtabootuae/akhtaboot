const express = require('express');
const router = express.Router();
const Budget = require('../../models/Budget');
const Alert = require('../../models/Alert');
const PayrollAuditLog = require('../../models/PayrollAuditLog');
const permissionAuth = require('../../middleware/permissionAuth');

// GET /api/payroll/budgets - Get all budgets
router.get('/',
  permissionAuth(['payroll_view_budgets', 'payroll_manage_budgets']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { 
        budget_type, 
        status, 
        active_only, 
        year, 
        scope_type,
        page = 1, 
        limit = 50 
      } = req.query;

      const criteria = {};
      if (budget_type) criteria.budget_type = budget_type;
      if (status) criteria.status = status;
      if (active_only === 'true') criteria.active_only = true;
      if (year) criteria.year = parseInt(year);
      if (scope_type) criteria.scope_type = scope_type;

      const options = {
        limit: parseInt(limit),
        skip: (parseInt(page) - 1) * parseInt(limit)
      };

      const budgets = await Budget.find(db, criteria, options);
      
      // Get total count for pagination
      const allBudgets = await Budget.find(db, criteria);
      const total = allBudgets.length;

      res.json({
        message: 'Budgets retrieved successfully',
        budgets: budgets,
        pagination: {
          current_page: parseInt(page),
          total_pages: Math.ceil(total / parseInt(limit)),
          total_records: total,
          limit: parseInt(limit)
        }
      });
    } catch (error) {
      console.error('Error fetching budgets:', error);
      res.status(500).json({
        message: 'Failed to retrieve budgets',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/budgets/:id - Get specific budget
router.get('/:id',
  permissionAuth(['payroll_view_budgets', 'payroll_manage_budgets']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const budget = await Budget.findById(db, req.params.id);

      if (!budget) {
        return res.status(404).json({
          message: 'Budget not found'
        });
      }

      res.json({
        message: 'Budget retrieved successfully',
        budget: budget
      });
    } catch (error) {
      console.error('Error fetching budget:', error);
      res.status(500).json({
        message: 'Failed to retrieve budget',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/budgets - Create new budget
router.post('/',
  permissionAuth('payroll_manage_budgets'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      const budgetData = {
        ...req.body,
        created_by: req.user._id
      };

      const budget = await Budget.create(db, budgetData);

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'create_budget',
        entity_type: 'budget',
        entity_id: budget._id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          budget_name: budget.name,
          budget_type: budget.budget_type,
          amount: budget.amount,
          period_start: budget.period_start,
          period_end: budget.period_end
        },
        severity: 'medium',
        category: 'data_modification'
      });

      res.status(201).json({
        message: 'Budget created successfully',
        budget: budget
      });
    } catch (error) {
      console.error('Error creating budget:', error);
      res.status(400).json({
        message: 'Failed to create budget',
        error: error.message
      });
    }
  }
);

// PUT /api/payroll/budgets/:id - Update budget
router.put('/:id',
  permissionAuth('payroll_manage_budgets'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      const updateData = {
        ...req.body,
        updated_by: req.user._id
      };

      const success = await Budget.update(db, req.params.id, updateData);

      if (!success) {
        return res.status(404).json({
          message: 'Budget not found or cannot be updated'
        });
      }

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'update_budget',
        entity_type: 'budget',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          updated_fields: Object.keys(req.body)
        },
        severity: 'medium',
        category: 'data_modification'
      });

      const updatedBudget = await Budget.findById(db, req.params.id);

      res.json({
        message: 'Budget updated successfully',
        budget: updatedBudget
      });
    } catch (error) {
      console.error('Error updating budget:', error);
      res.status(400).json({
        message: 'Failed to update budget',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/budgets/:id/calculate-spending - Calculate actual spending
router.post('/:id/calculate-spending',
  permissionAuth(['payroll_view_budgets', 'payroll_manage_budgets']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      const result = await Budget.calculateActualSpending(db, req.params.id);

      // Check thresholds and create alerts if needed
      const alerts = await Budget.checkThresholds(db, req.params.id);
      
      for (const alertInfo of alerts) {
        if (alertInfo.type === 'critical' || alertInfo.type === 'warning') {
          const budget = await Budget.findById(db, req.params.id);
          await Alert.createBudgetExceededAlert(db, budget, budget.actual_spending.total_spent, req.user._id);
        }
      }

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'calculate_budget_spending',
        entity_type: 'budget',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          total_spent: result.actual_spending.total_spent,
          variance_percentage: result.variance_analysis.variance_percentage,
          alerts_created: alerts.length
        },
        severity: 'low',
        category: 'calculation'
      });

      res.json({
        message: 'Budget spending calculated successfully',
        result: result,
        alerts_created: alerts.length
      });
    } catch (error) {
      console.error('Error calculating budget spending:', error);
      res.status(500).json({
        message: 'Failed to calculate budget spending',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/budgets/:id/approve - Approve budget
router.post('/:id/approve',
  permissionAuth('payroll_manage_budgets'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { approval_notes } = req.body;
      
      // Only allow admin to approve budgets
      if (req.user.role_name !== 'Admin') {
        return res.status(403).json({
          message: 'Only administrators can approve budgets'
        });
      }

      const success = await Budget.approve(db, req.params.id, req.user._id, approval_notes);

      if (!success) {
        return res.status(404).json({
          message: 'Budget not found or cannot be approved'
        });
      }

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'approve_budget',
        entity_type: 'budget',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          approval_notes: approval_notes
        },
        severity: 'high',
        category: 'authorization'
      });

      const budget = await Budget.findById(db, req.params.id);

      res.json({
        message: 'Budget approved successfully',
        budget: budget
      });
    } catch (error) {
      console.error('Error approving budget:', error);
      res.status(500).json({
        message: 'Failed to approve budget',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/budgets/summary - Get budget summary for period
router.get('/summary',
  permissionAuth(['payroll_view_budgets', 'payroll_manage_budgets']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { start_date, end_date, budget_type, status } = req.query;

      if (!start_date || !end_date) {
        return res.status(400).json({
          message: 'Start date and end date are required'
        });
      }

      const options = {};
      if (budget_type) options.budget_type = budget_type;
      if (status) options.status = status;

      const summary = await Budget.getSummary(db, start_date, end_date, options);

      res.json({
        message: 'Budget summary retrieved successfully',
        summary: summary
      });
    } catch (error) {
      console.error('Error fetching budget summary:', error);
      res.status(500).json({
        message: 'Failed to retrieve budget summary',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/budgets/requiring-attention - Get budgets requiring attention
router.get('/requiring-attention',
  permissionAuth(['payroll_view_budgets', 'payroll_manage_budgets']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      const budgets = await Budget.getRequiringAttention(db);

      res.json({
        message: 'Budgets requiring attention retrieved successfully',
        budgets: budgets,
        count: budgets.length
      });
    } catch (error) {
      console.error('Error fetching budgets requiring attention:', error);
      res.status(500).json({
        message: 'Failed to retrieve budgets requiring attention',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/budgets/batch-calculate - Calculate spending for all active budgets
router.post('/batch-calculate',
  permissionAuth('payroll_manage_budgets'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      // Only allow admin to run batch calculation
      if (req.user.role_name !== 'Admin') {
        return res.status(403).json({
          message: 'Only administrators can run batch budget calculations'
        });
      }

      // Get all active budgets
      const activeBudgets = await Budget.find(db, { 
        status: { $in: ['active', 'exceeded'] } 
      });

      const results = {
        successful: [],
        failed: [],
        alerts_created: 0
      };

      for (const budget of activeBudgets) {
        try {
          const result = await Budget.calculateActualSpending(db, budget._id.toString());
          
          // Check thresholds and create alerts if needed
          const alerts = await Budget.checkThresholds(db, budget._id.toString());
          
          for (const alertInfo of alerts) {
            if (alertInfo.type === 'critical' || alertInfo.type === 'warning') {
              await Alert.createBudgetExceededAlert(db, budget, result.actual_spending.total_spent, req.user._id);
              results.alerts_created++;
            }
          }

          results.successful.push({
            budget_id: budget._id.toString(),
            budget_name: budget.name,
            total_spent: result.actual_spending.total_spent,
            variance_percentage: result.variance_analysis.variance_percentage
          });

        } catch (error) {
          results.failed.push({
            budget_id: budget._id.toString(),
            budget_name: budget.name,
            error: error.message
          });
        }
      }

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'batch_calculate_budget_spending',
        entity_type: 'budget',
        entity_id: null,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          total_budgets: activeBudgets.length,
          successful: results.successful.length,
          failed: results.failed.length,
          alerts_created: results.alerts_created
        },
        severity: 'medium',
        category: 'batch_operation'
      });

      res.json({
        message: 'Batch budget calculation completed',
        results: results,
        summary: {
          total_budgets: activeBudgets.length,
          successful: results.successful.length,
          failed: results.failed.length,
          alerts_created: results.alerts_created
        }
      });
    } catch (error) {
      console.error('Error running batch budget calculation:', error);
      res.status(500).json({
        message: 'Failed to run batch budget calculation',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/budgets/:id/variance-analysis - Get detailed variance analysis
router.get('/:id/variance-analysis',
  permissionAuth(['payroll_view_budgets', 'payroll_manage_budgets']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const budget = await Budget.findById(db, req.params.id);

      if (!budget) {
        return res.status(404).json({
          message: 'Budget not found'
        });
      }

      // Calculate fresh spending data
      const result = await Budget.calculateActualSpending(db, req.params.id);

      // Prepare detailed variance analysis
      const analysis = {
        budget_info: {
          name: budget.name,
          type: budget.budget_type,
          amount: budget.amount,
          period: {
            start: budget.period_start,
            end: budget.period_end
          }
        },
        spending_analysis: result.actual_spending,
        variance_analysis: result.variance_analysis,
        threshold_status: {
          warning_threshold: budget.thresholds.warning_threshold,
          critical_threshold: budget.thresholds.critical_threshold,
          current_percentage: budget.amount > 0 ? 
            (result.actual_spending.total_spent / budget.amount) * 100 : 0
        },
        category_breakdown: result.actual_spending.category_spending || []
      };

      res.json({
        message: 'Budget variance analysis retrieved successfully',
        analysis: analysis
      });
    } catch (error) {
      console.error('Error fetching budget variance analysis:', error);
      res.status(500).json({
        message: 'Failed to retrieve budget variance analysis',
        error: error.message
      });
    }
  }
);

// DELETE /api/payroll/budgets/:id - Delete budget (draft only)
router.delete('/:id',
  permissionAuth('payroll_manage_budgets'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      const success = await Budget.delete(db, req.params.id);

      if (!success) {
        return res.status(404).json({
          message: 'Budget not found or cannot be deleted (only draft budgets can be deleted)'
        });
      }

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'delete_budget',
        entity_type: 'budget',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          action: 'budget_deleted'
        },
        severity: 'high',
        category: 'data_modification'
      });

      res.json({
        message: 'Budget deleted successfully'
      });
    } catch (error) {
      console.error('Error deleting budget:', error);
      res.status(500).json({
        message: 'Failed to delete budget',
        error: error.message
      });
    }
  }
);

module.exports = router;