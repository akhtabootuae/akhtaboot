const express = require('express');
const router = express.Router();
const TimeSheet = require('../../models/TimeSheet');
const PayrollAuditLog = require('../../models/PayrollAuditLog');
const permissionAuth = require('../../middleware/permissionAuth');

// GET /api/payroll/timesheets - Get all timesheets (with filtering)
router.get('/',
  permissionAuth(['payroll_view_timesheets', 'payroll_manage_timesheets']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { 
        employee_id, 
        start_date, 
        end_date, 
        status, 
        page = 1, 
        limit = 50 
      } = req.query;

      const options = {
        limit: parseInt(limit),
        skip: (parseInt(page) - 1) * parseInt(limit)
      };

      if (start_date) options.startDate = start_date;
      if (end_date) options.endDate = end_date;
      if (status) options.status = status;

      let timesheets;
      let total;

      if (employee_id) {
        timesheets = await TimeSheet.findByEmployee(db, employee_id, options);
        // Get count for pagination
        const countOptions = { ...options };
        delete countOptions.limit;
        delete countOptions.skip;
        const allTimesheets = await TimeSheet.findByEmployee(db, employee_id, countOptions);
        total = allTimesheets.length;
      } else {
        // Get all timesheets with employee info
        const pipeline = [
          {
            $lookup: {
              from: 'users',
              localField: 'employee_id',
              foreignField: '_id',
              as: 'employee'
            }
          },
          { $unwind: '$employee' },
          {
            $project: {
              work_date: 1,
              total_hours: 1,
              total_pay: 1,
              status: 1,
              submitted_at: 1,
              approved_at: 1,
              'employee.email': 1,
              'employee.first_name': 1,
              'employee.last_name': 1
            }
          },
          { $sort: { work_date: -1 } },
          { $skip: options.skip },
          { $limit: options.limit }
        ];

        // Add filters to pipeline
        const matchStage = {};
        if (start_date || end_date) {
          matchStage.work_date = {};
          if (start_date) matchStage.work_date.$gte = new Date(start_date);
          if (end_date) matchStage.work_date.$lte = new Date(end_date);
        }
        if (status) matchStage.status = status;

        if (Object.keys(matchStage).length > 0) {
          pipeline.unshift({ $match: matchStage });
        }

        timesheets = await db.collection('timesheets').aggregate(pipeline).toArray();
        
        // Get total count
        const countPipeline = pipeline.slice();
        countPipeline.pop(); // Remove limit
        countPipeline.pop(); // Remove skip
        countPipeline.push({ $count: 'total' });
        const countResult = await db.collection('timesheets').aggregate(countPipeline).toArray();
        total = countResult[0]?.total || 0;
      }

      res.json({
        message: 'Timesheets retrieved successfully',
        timesheets: timesheets,
        pagination: {
          current_page: parseInt(page),
          total_pages: Math.ceil(total / parseInt(limit)),
          total_records: total,
          limit: parseInt(limit)
        }
      });
    } catch (error) {
      console.error('Error fetching timesheets:', error);
      res.status(500).json({
        message: 'Failed to retrieve timesheets',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/timesheets/:id - Get specific timesheet
router.get('/:id',
  permissionAuth(['payroll_view_timesheets', 'payroll_manage_timesheets']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const timesheet = await TimeSheet.findById(db, req.params.id);

      if (!timesheet) {
        return res.status(404).json({
          message: 'Timesheet not found'
        });
      }

      res.json({
        message: 'Timesheet retrieved successfully',
        timesheet: timesheet
      });
    } catch (error) {
      console.error('Error fetching timesheet:', error);
      res.status(500).json({
        message: 'Failed to retrieve timesheet',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/timesheets - Create new timesheet
router.post('/',
  permissionAuth('payroll_manage_timesheets'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      const timesheetData = {
        ...req.body,
        created_by: req.user._id
      };

      const timesheet = await TimeSheet.create(db, timesheetData);

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'create_timesheet',
        entity_type: 'timesheet',
        entity_id: timesheet._id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          employee_id: timesheetData.employee_id,
          work_date: timesheetData.work_date,
          total_hours: timesheet.total_hours,
          total_pay: timesheet.total_pay
        },
        severity: 'medium',
        category: 'data_modification'
      });

      res.status(201).json({
        message: 'Timesheet created successfully',
        timesheet: timesheet
      });
    } catch (error) {
      console.error('Error creating timesheet:', error);
      res.status(400).json({
        message: 'Failed to create timesheet',
        error: error.message
      });
    }
  }
);

// PUT /api/payroll/timesheets/:id - Update timesheet
router.put('/:id',
  permissionAuth('payroll_manage_timesheets'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      const updateData = {
        ...req.body,
        updated_by: req.user._id
      };

      const success = await TimeSheet.update(db, req.params.id, updateData);

      if (!success) {
        return res.status(404).json({
          message: 'Timesheet not found or cannot be updated'
        });
      }

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'update_timesheet',
        entity_type: 'timesheet',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          updated_fields: Object.keys(req.body)
        },
        severity: 'medium',
        category: 'data_modification'
      });

      const updatedTimesheet = await TimeSheet.findById(db, req.params.id);

      res.json({
        message: 'Timesheet updated successfully',
        timesheet: updatedTimesheet
      });
    } catch (error) {
      console.error('Error updating timesheet:', error);
      res.status(400).json({
        message: 'Failed to update timesheet',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/timesheets/:id/submit - Submit timesheet for approval
router.post('/:id/submit',
  permissionAuth('payroll_manage_timesheets'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      const success = await TimeSheet.submit(db, req.params.id, req.user._id);

      if (!success) {
        return res.status(404).json({
          message: 'Timesheet not found or cannot be submitted'
        });
      }

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'submit_timesheet',
        entity_type: 'timesheet',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          action: 'submitted_for_approval'
        },
        severity: 'medium',
        category: 'workflow'
      });

      const timesheet = await TimeSheet.findById(db, req.params.id);

      res.json({
        message: 'Timesheet submitted for approval successfully',
        timesheet: timesheet
      });
    } catch (error) {
      console.error('Error submitting timesheet:', error);
      res.status(500).json({
        message: 'Failed to submit timesheet',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/timesheets/:id/approve - Approve timesheet
router.post('/:id/approve',
  permissionAuth('payroll_approve_timesheets'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      const success = await TimeSheet.approve(db, req.params.id, req.user._id);

      if (!success) {
        return res.status(404).json({
          message: 'Timesheet not found or cannot be approved'
        });
      }

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'approve_timesheet',
        entity_type: 'timesheet',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          approval_notes: req.body.notes
        },
        severity: 'high',
        category: 'authorization'
      });

      const timesheet = await TimeSheet.findById(db, req.params.id);

      res.json({
        message: 'Timesheet approved successfully',
        timesheet: timesheet
      });
    } catch (error) {
      console.error('Error approving timesheet:', error);
      res.status(500).json({
        message: 'Failed to approve timesheet',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/timesheets/:id/reject - Reject timesheet
router.post('/:id/reject',
  permissionAuth('payroll_approve_timesheets'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { reason } = req.body;

      if (!reason) {
        return res.status(400).json({
          message: 'Rejection reason is required'
        });
      }
      
      const success = await TimeSheet.reject(db, req.params.id, req.user._id, reason);

      if (!success) {
        return res.status(404).json({
          message: 'Timesheet not found or cannot be rejected'
        });
      }

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'reject_timesheet',
        entity_type: 'timesheet',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          rejection_reason: reason
        },
        severity: 'high',
        category: 'authorization'
      });

      const timesheet = await TimeSheet.findById(db, req.params.id);

      res.json({
        message: 'Timesheet rejected successfully',
        timesheet: timesheet
      });
    } catch (error) {
      console.error('Error rejecting timesheet:', error);
      res.status(500).json({
        message: 'Failed to reject timesheet',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/timesheets/pending-approvals - Get pending approvals
router.get('/pending-approvals',
  permissionAuth('payroll_approve_timesheets'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { page = 1, limit = 50 } = req.query;

      const options = {
        limit: parseInt(limit),
        skip: (parseInt(page) - 1) * parseInt(limit)
      };

      const pendingTimesheets = await TimeSheet.getPendingApprovals(db, options);

      res.json({
        message: 'Pending timesheet approvals retrieved successfully',
        pending_timesheets: pendingTimesheets,
        pagination: {
          current_page: parseInt(page),
          limit: parseInt(limit)
        }
      });
    } catch (error) {
      console.error('Error fetching pending approvals:', error);
      res.status(500).json({
        message: 'Failed to retrieve pending approvals',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/timesheets/employees/:employeeId/attendance-summary - Get attendance summary
router.get('/employees/:employeeId/attendance-summary',
  permissionAuth(['payroll_view_timesheets', 'payroll_manage_timesheets']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { start_date, end_date } = req.query;

      if (!start_date || !end_date) {
        return res.status(400).json({
          message: 'Start date and end date are required'
        });
      }

      const summary = await TimeSheet.getAttendanceSummary(
        db, 
        req.params.employeeId, 
        start_date, 
        end_date
      );

      res.json({
        message: 'Attendance summary retrieved successfully',
        summary: summary,
        period: {
          start_date: start_date,
          end_date: end_date
        }
      });
    } catch (error) {
      console.error('Error fetching attendance summary:', error);
      res.status(500).json({
        message: 'Failed to retrieve attendance summary',
        error: error.message
      });
    }
  }
);

// DELETE /api/payroll/timesheets/:id - Delete timesheet (draft only)
router.delete('/:id',
  permissionAuth('payroll_manage_timesheets'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      const success = await TimeSheet.delete(db, req.params.id);

      if (!success) {
        return res.status(404).json({
          message: 'Timesheet not found or cannot be deleted (only draft timesheets can be deleted)'
        });
      }

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'delete_timesheet',
        entity_type: 'timesheet',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          action: 'timesheet_deleted'
        },
        severity: 'high',
        category: 'data_modification'
      });

      res.json({
        message: 'Timesheet deleted successfully'
      });
    } catch (error) {
      console.error('Error deleting timesheet:', error);
      res.status(500).json({
        message: 'Failed to delete timesheet',
        error: error.message
      });
    }
  }
);

module.exports = router;