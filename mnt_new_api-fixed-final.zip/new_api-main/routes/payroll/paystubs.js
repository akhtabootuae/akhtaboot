const express = require('express');
const router = express.Router();
const PayStub = require('../../models/PayStub');
const PayrollAuditLog = require('../../models/PayrollAuditLog');
const permissionAuth = require('../../middleware/permissionAuth');
const { ObjectId } = require('mongodb');

// GET /api/payroll/paystubs - Get all paystubs (with filtering)
router.get('/',
  permissionAuth(['payroll_view_paystubs', 'payroll_generate_paystubs']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { 
        employee_id, 
        pay_period_id, 
        year, 
        status, 
        page = 1, 
        limit = 50 
      } = req.query;

      let paystubs;
      let total = 0;

      if (employee_id) {
        const options = {
          limit: parseInt(limit),
          skip: (parseInt(page) - 1) * parseInt(limit)
        };
        if (year) options.year = parseInt(year);
        if (status) options.status = status;

        paystubs = await PayStub.findByEmployee(db, employee_id, options);
        
        // Get count for pagination
        const countOptions = { ...options };
        delete countOptions.limit;
        delete countOptions.skip;
        const allPaystubs = await PayStub.findByEmployee(db, employee_id, countOptions);
        total = allPaystubs.length;

      } else if (pay_period_id) {
        const options = {
          limit: parseInt(limit),
          skip: (parseInt(page) - 1) * parseInt(limit)
        };
        if (status) options.status = status;

        paystubs = await PayStub.findByPayPeriod(db, pay_period_id, options);
        
        // Get count for pagination
        const countOptions = { ...options };
        delete countOptions.limit;
        delete countOptions.skip;
        const allPaystubs = await PayStub.findByPayPeriod(db, pay_period_id, countOptions);
        total = allPaystubs.length;

      } else {
        // Get all paystubs with filters
        const matchStage = {};
        
        if (year) {
          const startOfYear = new Date(parseInt(year), 0, 1);
          const endOfYear = new Date(parseInt(year), 11, 31, 23, 59, 59);
          matchStage.issue_date = { $gte: startOfYear, $lte: endOfYear };
        }
        
        if (status) {
          matchStage.status = status;
        }

        const pipeline = [
          { $match: matchStage },
          { $sort: { issue_date: -1 } },
          { $skip: (parseInt(page) - 1) * parseInt(limit) },
          { $limit: parseInt(limit) }
        ];

        paystubs = await db.collection('pay_stubs').aggregate(pipeline).toArray();
        
        // Get total count
        const countPipeline = [{ $match: matchStage }, { $count: 'total' }];
        const countResult = await db.collection('pay_stubs').aggregate(countPipeline).toArray();
        total = countResult[0]?.total || 0;
      }

      res.json({
        message: 'Pay stubs retrieved successfully',
        paystubs: paystubs,
        pagination: {
          current_page: parseInt(page),
          total_pages: Math.ceil(total / parseInt(limit)),
          total_records: total,
          limit: parseInt(limit)
        }
      });
    } catch (error) {
      console.error('Error fetching pay stubs:', error);
      res.status(500).json({
        message: 'Failed to retrieve pay stubs',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/paystubs/:id - Get specific paystub
router.get('/:id',
  permissionAuth(['payroll_view_paystubs', 'payroll_generate_paystubs']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const paystub = await PayStub.findById(db, req.params.id);

      if (!paystub) {
        return res.status(404).json({
          message: 'Pay stub not found'
        });
      }

      // Check if user has access to this paystub
      const canView = req.user.role_name === 'Admin' || 
                     req.user.role_name === 'Supervisor' ||
                     paystub.employee_id.equals(req.user._id);

      if (!canView) {
        return res.status(403).json({
          message: 'Access denied to this pay stub'
        });
      }

      // Mark as viewed if employee is viewing their own paystub
      if (paystub.employee_id.equals(req.user._id) && paystub.status !== 'viewed') {
        await PayStub.markAsViewed(db, req.params.id);
        paystub.status = 'viewed';
        paystub.viewed_at = new Date();
      }

      res.json({
        message: 'Pay stub retrieved successfully',
        paystub: paystub
      });
    } catch (error) {
      console.error('Error fetching pay stub:', error);
      res.status(500).json({
        message: 'Failed to retrieve pay stub',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/paystubs - Create paystub from payroll calculation
router.post('/',
  permissionAuth('payroll_generate_paystubs'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { payroll_calculation_id, company_info, issue_date } = req.body;

      if (!payroll_calculation_id) {
        return res.status(400).json({
          message: 'Payroll calculation ID is required'
        });
      }

      const options = {};
      if (company_info) options.company_info = company_info;
      if (issue_date) options.issue_date = issue_date;

      const paystub = await PayStub.create(db, payroll_calculation_id, req.user._id, options);

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'create_paystub',
        entity_type: 'paystub',
        entity_id: paystub._id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          payroll_calculation_id: payroll_calculation_id,
          employee_id: paystub.employee_id,
          stub_number: paystub.stub_number
        },
        severity: 'medium',
        category: 'data_modification'
      });

      res.status(201).json({
        message: 'Pay stub created successfully',
        paystub: paystub
      });
    } catch (error) {
      console.error('Error creating pay stub:', error);
      res.status(400).json({
        message: 'Failed to create pay stub',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/paystubs/batch - Create paystubs for entire pay period
router.post('/batch',
  permissionAuth('payroll_generate_paystubs'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { pay_period_id, company_info, issue_date } = req.body;

      if (!pay_period_id) {
        return res.status(400).json({
          message: 'Pay period ID is required'
        });
      }

      const options = {};
      if (company_info) options.company_info = company_info;
      if (issue_date) options.issue_date = issue_date;

      const results = await PayStub.batchCreate(db, pay_period_id, req.user._id, options);

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'batch_create_paystubs',
        entity_type: 'paystub',
        entity_id: pay_period_id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          pay_period_id: pay_period_id,
          successful: results.successful.length,
          failed: results.failed.length,
          skipped: results.skipped.length
        },
        severity: 'high',
        category: 'batch_operation'
      });

      res.json({
        message: 'Batch pay stub creation completed',
        results: results,
        summary: {
          successful: results.successful.length,
          failed: results.failed.length,
          skipped: results.skipped.length
        }
      });
    } catch (error) {
      console.error('Error creating batch pay stubs:', error);
      res.status(500).json({
        message: 'Failed to create batch pay stubs',
        error: error.message
      });
    }
  }
);

// PUT /api/payroll/paystubs/:id/status - Update paystub status
router.put('/:id/status',
  permissionAuth('payroll_generate_paystubs'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { status } = req.body;

      if (!status) {
        return res.status(400).json({
          message: 'Status is required'
        });
      }

      const success = await PayStub.updateStatus(db, req.params.id, status, req.user._id);

      if (!success) {
        return res.status(404).json({
          message: 'Pay stub not found or status unchanged'
        });
      }

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'update_paystub_status',
        entity_type: 'paystub',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          new_status: status
        },
        severity: 'medium',
        category: 'data_modification'
      });

      const updatedPaystub = await PayStub.findById(db, req.params.id);

      res.json({
        message: 'Pay stub status updated successfully',
        paystub: updatedPaystub
      });
    } catch (error) {
      console.error('Error updating pay stub status:', error);
      res.status(500).json({
        message: 'Failed to update pay stub status',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/paystubs/:id/mark-viewed - Mark paystub as viewed by employee
router.post('/:id/mark-viewed',
  permissionAuth(['payroll_view_paystubs']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      const paystub = await PayStub.findById(db, req.params.id);
      
      if (!paystub) {
        return res.status(404).json({
          message: 'Pay stub not found'
        });
      }

      // Only allow employee to mark their own paystub as viewed
      if (!paystub.employee_id.equals(req.user._id)) {
        return res.status(403).json({
          message: 'You can only mark your own pay stubs as viewed'
        });
      }

      const success = await PayStub.markAsViewed(db, req.params.id);

      if (!success) {
        return res.status(400).json({
          message: 'Pay stub could not be marked as viewed'
        });
      }

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'view_paystub',
        entity_type: 'paystub',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          stub_number: paystub.stub_number
        },
        severity: 'low',
        category: 'data_access'
      });

      res.json({
        message: 'Pay stub marked as viewed successfully'
      });
    } catch (error) {
      console.error('Error marking pay stub as viewed:', error);
      res.status(500).json({
        message: 'Failed to mark pay stub as viewed',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/paystubs/employees/:employeeId/current - Get current paystub for employee
router.get('/employees/:employeeId/current',
  permissionAuth(['payroll_view_paystubs', 'payroll_generate_paystubs']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      // Check if user can view this employee's paystubs
      const canView = req.user.role_name === 'Admin' || 
                     req.user.role_name === 'Supervisor' ||
                     req.params.employeeId === req.user._id.toString();

      if (!canView) {
        return res.status(403).json({
          message: 'Access denied to view this employee\'s pay stubs'
        });
      }

      // Get most recent paystub for employee
      const paystubs = await PayStub.findByEmployee(db, req.params.employeeId, { 
        limit: 1,
        status: 'issued'
      });

      if (paystubs.length === 0) {
        return res.status(404).json({
          message: 'No current pay stub found for employee'
        });
      }

      res.json({
        message: 'Current pay stub retrieved successfully',
        paystub: paystubs[0]
      });
    } catch (error) {
      console.error('Error fetching current pay stub:', error);
      res.status(500).json({
        message: 'Failed to retrieve current pay stub',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/paystubs/statistics - Get paystub statistics
router.get('/statistics',
  permissionAuth(['payroll_view_paystubs', 'payroll_generate_paystubs']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { year, pay_period_id } = req.query;

      const options = {};
      if (year) options.year = parseInt(year);
      if (pay_period_id) options.pay_period_id = pay_period_id;

      const statistics = await PayStub.getStatistics(db, options);

      res.json({
        message: 'Pay stub statistics retrieved successfully',
        statistics: statistics
      });
    } catch (error) {
      console.error('Error fetching pay stub statistics:', error);
      res.status(500).json({
        message: 'Failed to retrieve pay stub statistics',
        error: error.message
      });
    }
  }
);

// PUT /api/payroll/paystubs/:id/pdf-path - Update PDF path
router.put('/:id/pdf-path',
  permissionAuth('payroll_generate_paystubs'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { pdf_path } = req.body;

      if (!pdf_path) {
        return res.status(400).json({
          message: 'PDF path is required'
        });
      }

      const success = await PayStub.updatePdfPath(db, req.params.id, pdf_path, req.user._id);

      if (!success) {
        return res.status(404).json({
          message: 'Pay stub not found'
        });
      }

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'update_paystub_pdf',
        entity_type: 'paystub',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          pdf_path: pdf_path
        },
        severity: 'low',
        category: 'data_modification'
      });

      res.json({
        message: 'Pay stub PDF path updated successfully'
      });
    } catch (error) {
      console.error('Error updating pay stub PDF path:', error);
      res.status(500).json({
        message: 'Failed to update pay stub PDF path',
        error: error.message
      });
    }
  }
);

// DELETE /api/payroll/paystubs/:id - Delete paystub (draft only)
router.delete('/:id',
  permissionAuth('payroll_generate_paystubs'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      const success = await PayStub.delete(db, req.params.id);

      if (!success) {
        return res.status(404).json({
          message: 'Pay stub not found or cannot be deleted (only draft pay stubs can be deleted)'
        });
      }

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'delete_paystub',
        entity_type: 'paystub',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          action: 'paystub_deleted'
        },
        severity: 'high',
        category: 'data_modification'
      });

      res.json({
        message: 'Pay stub deleted successfully'
      });
    } catch (error) {
      console.error('Error deleting pay stub:', error);
      res.status(500).json({
        message: 'Failed to delete pay stub',
        error: error.message
      });
    }
  }
);

module.exports = router;