const express = require('express');
const router = express.Router();
const PayrollDeductionType = require('../../models/PayrollDeductionType');
const PayrollAuditLog = require('../../models/PayrollAuditLog');
const permissionAuth = require('../../middleware/permissionAuth');

// GET /api/payroll/deduction-types - Get all deduction types
router.get('/', 
  permissionAuth(['payroll_manage_deduction_types', 'payroll_view_deductions']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { active } = req.query;
      
      const filters = {};
      if (active !== undefined) filters.active = active === 'true';
      
      const deductionTypes = await PayrollDeductionType.findAll(db, filters);
      
      res.json({
        message: 'Deduction types retrieved successfully',
        deduction_types: deductionTypes
      });
    } catch (error) {
      console.error('Error fetching deduction types:', error);
      res.status(500).json({
        message: 'Failed to retrieve deduction types',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/deduction-types/:id - Get specific deduction type
router.get('/:id',
  permissionAuth(['payroll_manage_deduction_types', 'payroll_view_deductions']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const deductionType = await PayrollDeductionType.findById(db, req.params.id);
      
      if (!deductionType) {
        return res.status(404).json({
          message: 'Deduction type not found'
        });
      }
      
      res.json({
        message: 'Deduction type retrieved successfully',
        deduction_type: deductionType
      });
    } catch (error) {
      console.error('Error fetching deduction type:', error);
      res.status(500).json({
        message: 'Failed to retrieve deduction type',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/deduction-types - Create new deduction type
router.post('/',
  permissionAuth('payroll_manage_deduction_types'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      // Validate input
      const errors = PayrollDeductionType.validateDeductionType(req.body);
      if (errors.length > 0) {
        return res.status(400).json({
          message: 'Validation failed',
          errors: errors
        });
      }
      
      const deductionTypeData = {
        ...req.body,
        is_system_type: false, // User-created types are not system types
        active: req.body.active !== undefined ? req.body.active : true
      };
      
      const deductionType = await PayrollDeductionType.create(db, deductionTypeData);
      
      // Log the audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'create_deduction_type',
        entity_type: 'deduction_type',
        entity_id: deductionType._id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          name: deductionTypeData.name,
          type: deductionTypeData.type,
          frequency: deductionTypeData.frequency
        },
        severity: 'medium',
        category: 'data_modification'
      });
      
      res.status(201).json({
        message: 'Deduction type created successfully',
        deduction_type: deductionType
      });
    } catch (error) {
      console.error('Error creating deduction type:', error);
      res.status(500).json({
        message: 'Failed to create deduction type',
        error: error.message
      });
    }
  }
);

// PUT /api/payroll/deduction-types/:id - Update deduction type
router.put('/:id',
  permissionAuth('payroll_manage_deduction_types'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      // Check if deduction type exists
      const existingType = await PayrollDeductionType.findById(db, req.params.id);
      if (!existingType) {
        return res.status(404).json({
          message: 'Deduction type not found'
        });
      }
      
      // Validate input
      const errors = PayrollDeductionType.validateDeductionType(req.body);
      if (errors.length > 0) {
        return res.status(400).json({
          message: 'Validation failed',
          errors: errors
        });
      }
      
      const success = await PayrollDeductionType.update(db, req.params.id, req.body);
      
      if (!success) {
        return res.status(404).json({
          message: 'Deduction type not found or no changes made'
        });
      }
      
      // Log the audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'update_deduction_type',
        entity_type: 'deduction_type',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          old_values: existingType,
          new_values: req.body
        },
        severity: 'medium',
        category: 'data_modification'
      });
      
      const updatedType = await PayrollDeductionType.findById(db, req.params.id);
      
      res.json({
        message: 'Deduction type updated successfully',
        deduction_type: updatedType
      });
    } catch (error) {
      console.error('Error updating deduction type:', error);
      res.status(500).json({
        message: 'Failed to update deduction type',
        error: error.message
      });
    }
  }
);

// DELETE /api/payroll/deduction-types/:id - Delete deduction type
router.delete('/:id',
  permissionAuth('payroll_manage_deduction_types'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      // Get existing type for audit
      const existingType = await PayrollDeductionType.findById(db, req.params.id);
      if (!existingType) {
        return res.status(404).json({
          message: 'Deduction type not found'
        });
      }
      
      const success = await PayrollDeductionType.delete(db, req.params.id);
      
      if (!success) {
        return res.status(404).json({
          message: 'Deduction type not found'
        });
      }
      
      // Log the audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'delete_deduction_type',
        entity_type: 'deduction_type',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          deleted_type: existingType
        },
        severity: 'high',
        category: 'data_modification'
      });
      
      res.json({
        message: 'Deduction type deleted successfully'
      });
    } catch (error) {
      console.error('Error deleting deduction type:', error);
      if (error.message.includes('Cannot delete')) {
        return res.status(400).json({
          message: error.message
        });
      }
      res.status(500).json({
        message: 'Failed to delete deduction type',
        error: error.message
      });
    }
  }
);

module.exports = router;