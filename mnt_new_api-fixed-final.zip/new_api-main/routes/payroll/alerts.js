const express = require('express');
const router = express.Router();
const Alert = require('../../models/Alert');
const PayrollAuditLog = require('../../models/PayrollAuditLog');
const permissionAuth = require('../../middleware/permissionAuth');

// GET /api/payroll/alerts - Get alerts for user
router.get('/',
  permissionAuth(['payroll_view_alerts', 'payroll_manage_alerts']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { 
        status, 
        severity, 
        alert_type, 
        include_expired = 'false',
        page = 1, 
        limit = 50 
      } = req.query;

      const options = {
        limit: parseInt(limit),
        skip: (parseInt(page) - 1) * parseInt(limit),
        userRoles: [req.user.role_name]
      };

      if (status) options.status = status;
      if (severity) options.severity = severity;
      if (alert_type) options.alert_type = alert_type;
      if (include_expired === 'true') options.include_expired = true;

      const alerts = await Alert.findForUser(db, req.user._id, options);
      
      // Get total count for pagination
      const allAlerts = await Alert.findForUser(db, req.user._id, {
        userRoles: [req.user.role_name],
        status: options.status,
        severity: options.severity,
        alert_type: options.alert_type,
        include_expired: options.include_expired
      });
      const total = allAlerts.length;

      res.json({
        message: 'Alerts retrieved successfully',
        alerts: alerts,
        pagination: {
          current_page: parseInt(page),
          total_pages: Math.ceil(total / parseInt(limit)),
          total_records: total,
          limit: parseInt(limit)
        }
      });
    } catch (error) {
      console.error('Error fetching alerts:', error);
      res.status(500).json({
        message: 'Failed to retrieve alerts',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/alerts/:id - Get specific alert
router.get('/:id',
  permissionAuth(['payroll_view_alerts', 'payroll_manage_alerts']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const alert = await Alert.findById(db, req.params.id);

      if (!alert) {
        return res.status(404).json({
          message: 'Alert not found'
        });
      }

      // Check if user has access to this alert
      const hasAccess = alert.created_by.equals(req.user._id) ||
        alert.target_users?.some(userId => userId.equals(req.user._id)) ||
        alert.target_roles?.includes(req.user.role_name);

      if (!hasAccess) {
        return res.status(403).json({
          message: 'Access denied to this alert'
        });
      }

      res.json({
        message: 'Alert retrieved successfully',
        alert: alert
      });
    } catch (error) {
      console.error('Error fetching alert:', error);
      res.status(500).json({
        message: 'Failed to retrieve alert',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/alerts - Create new alert
router.post('/',
  permissionAuth('payroll_manage_alerts'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      const alertData = {
        ...req.body,
        created_by: req.user._id
      };

      const alert = await Alert.create(db, alertData);

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'create_alert',
        entity_type: 'alert',
        entity_id: alert._id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          alert_type: alert.alert_type,
          severity: alert.severity,
          title: alert.title
        },
        severity: 'medium',
        category: 'data_modification'
      });

      res.status(201).json({
        message: 'Alert created successfully',
        alert: alert
      });
    } catch (error) {
      console.error('Error creating alert:', error);
      res.status(400).json({
        message: 'Failed to create alert',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/alerts/:id/acknowledge - Acknowledge alert
router.post('/:id/acknowledge',
  permissionAuth(['payroll_view_alerts', 'payroll_manage_alerts']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      const success = await Alert.acknowledge(db, req.params.id, req.user._id);

      if (!success) {
        return res.status(404).json({
          message: 'Alert not found or cannot be acknowledged'
        });
      }

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'acknowledge_alert',
        entity_type: 'alert',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          action: 'alert_acknowledged'
        },
        severity: 'low',
        category: 'workflow'
      });

      const alert = await Alert.findById(db, req.params.id);

      res.json({
        message: 'Alert acknowledged successfully',
        alert: alert
      });
    } catch (error) {
      console.error('Error acknowledging alert:', error);
      res.status(500).json({
        message: 'Failed to acknowledge alert',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/alerts/:id/resolve - Resolve alert
router.post('/:id/resolve',
  permissionAuth('payroll_manage_alerts'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { resolution_notes } = req.body;
      
      const success = await Alert.resolve(db, req.params.id, req.user._id, resolution_notes);

      if (!success) {
        return res.status(404).json({
          message: 'Alert not found or cannot be resolved'
        });
      }

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'resolve_alert',
        entity_type: 'alert',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          resolution_notes: resolution_notes
        },
        severity: 'medium',
        category: 'workflow'
      });

      const alert = await Alert.findById(db, req.params.id);

      res.json({
        message: 'Alert resolved successfully',
        alert: alert
      });
    } catch (error) {
      console.error('Error resolving alert:', error);
      res.status(500).json({
        message: 'Failed to resolve alert',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/alerts/:id/dismiss - Dismiss alert
router.post('/:id/dismiss',
  permissionAuth(['payroll_view_alerts', 'payroll_manage_alerts']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      const success = await Alert.dismiss(db, req.params.id, req.user._id);

      if (!success) {
        return res.status(404).json({
          message: 'Alert not found or cannot be dismissed'
        });
      }

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'dismiss_alert',
        entity_type: 'alert',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          action: 'alert_dismissed'
        },
        severity: 'low',
        category: 'workflow'
      });

      res.json({
        message: 'Alert dismissed successfully'
      });
    } catch (error) {
      console.error('Error dismissing alert:', error);
      res.status(500).json({
        message: 'Failed to dismiss alert',
        error: error.message
      });
    }
  }
);

// PUT /api/payroll/alerts/:id/action-items/:actionIndex - Update action item
router.put('/:id/action-items/:actionIndex',
  permissionAuth('payroll_manage_alerts'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { completed } = req.body;
      const actionIndex = parseInt(req.params.actionIndex);

      if (typeof completed !== 'boolean') {
        return res.status(400).json({
          message: 'Completed status (boolean) is required'
        });
      }

      const success = await Alert.updateActionItem(
        db, 
        req.params.id, 
        actionIndex, 
        completed, 
        req.user._id
      );

      if (!success) {
        return res.status(404).json({
          message: 'Alert or action item not found'
        });
      }

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'update_alert_action_item',
        entity_type: 'alert',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          action_index: actionIndex,
          completed: completed
        },
        severity: 'low',
        category: 'workflow'
      });

      const alert = await Alert.findById(db, req.params.id);

      res.json({
        message: 'Action item updated successfully',
        alert: alert
      });
    } catch (error) {
      console.error('Error updating action item:', error);
      res.status(500).json({
        message: 'Failed to update action item',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/alerts/action-required - Get alerts requiring action
router.get('/action-required',
  permissionAuth(['payroll_view_alerts', 'payroll_manage_alerts']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      const alerts = await Alert.getActionRequired(db, req.user._id, [req.user.role_name]);

      res.json({
        message: 'Action required alerts retrieved successfully',
        alerts: alerts,
        count: alerts.length
      });
    } catch (error) {
      console.error('Error fetching action required alerts:', error);
      res.status(500).json({
        message: 'Failed to retrieve action required alerts',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/alerts/statistics - Get alert statistics
router.get('/statistics',
  permissionAuth(['payroll_view_alerts', 'payroll_manage_alerts']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { start_date, end_date } = req.query;

      const options = {};
      if (start_date) options.start_date = start_date;
      if (end_date) options.end_date = end_date;

      // Admin can see all statistics, others see only their own
      if (req.user.role_name !== 'Admin') {
        options.user_id = req.user._id;
      }

      const statistics = await Alert.getStatistics(db, options);

      res.json({
        message: 'Alert statistics retrieved successfully',
        statistics: statistics
      });
    } catch (error) {
      console.error('Error fetching alert statistics:', error);
      res.status(500).json({
        message: 'Failed to retrieve alert statistics',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/alerts/cleanup-expired - Clean up expired alerts
router.post('/cleanup-expired',
  permissionAuth('payroll_manage_alerts'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      // Only allow admin to run cleanup
      if (req.user.role_name !== 'Admin') {
        return res.status(403).json({
          message: 'Only administrators can run alert cleanup'
        });
      }

      const deletedCount = await Alert.cleanupExpired(db);

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'cleanup_expired_alerts',
        entity_type: 'alert',
        entity_id: null,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          deleted_count: deletedCount
        },
        severity: 'medium',
        category: 'system_maintenance'
      });

      res.json({
        message: 'Expired alerts cleaned up successfully',
        deleted_count: deletedCount
      });
    } catch (error) {
      console.error('Error cleaning up expired alerts:', error);
      res.status(500).json({
        message: 'Failed to clean up expired alerts',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/alerts/check-recurring - Check and trigger recurring alerts
router.post('/check-recurring',
  permissionAuth('payroll_manage_alerts'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      // Only allow admin to trigger recurring check
      if (req.user.role_name !== 'Admin') {
        return res.status(403).json({
          message: 'Only administrators can trigger recurring alert checks'
        });
      }

      const triggeredAlerts = await Alert.checkRecurringAlerts(db);

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'check_recurring_alerts',
        entity_type: 'alert',
        entity_id: null,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          triggered_count: triggeredAlerts.length
        },
        severity: 'medium',
        category: 'system_maintenance'
      });

      res.json({
        message: 'Recurring alerts checked successfully',
        triggered_alerts: triggeredAlerts,
        triggered_count: triggeredAlerts.length
      });
    } catch (error) {
      console.error('Error checking recurring alerts:', error);
      res.status(500).json({
        message: 'Failed to check recurring alerts',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/alerts/payroll-overdue - Create payroll overdue alert
router.post('/payroll-overdue',
  permissionAuth('payroll_manage_alerts'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { pay_period_id } = req.body;

      if (!pay_period_id) {
        return res.status(400).json({
          message: 'Pay period ID is required'
        });
      }

      // Get pay period details
      const payPeriod = await db.collection('pay_periods').findOne({
        _id: new ObjectId(pay_period_id)
      });

      if (!payPeriod) {
        return res.status(404).json({
          message: 'Pay period not found'
        });
      }

      const alert = await Alert.createPayrollOverdueAlert(db, payPeriod, req.user._id);

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'create_payroll_overdue_alert',
        entity_type: 'alert',
        entity_id: alert._id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          pay_period_id: pay_period_id,
          pay_period_name: payPeriod.period_name
        },
        severity: 'high',
        category: 'alert_generation'
      });

      res.status(201).json({
        message: 'Payroll overdue alert created successfully',
        alert: alert
      });
    } catch (error) {
      console.error('Error creating payroll overdue alert:', error);
      res.status(500).json({
        message: 'Failed to create payroll overdue alert',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/alerts/missing-timesheet - Create missing timesheet alert
router.post('/missing-timesheet',
  permissionAuth('payroll_manage_alerts'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { employee_id, pay_period_id } = req.body;

      if (!employee_id || !pay_period_id) {
        return res.status(400).json({
          message: 'Employee ID and pay period ID are required'
        });
      }

      // Get employee and pay period details
      const [employee, payPeriod] = await Promise.all([
        db.collection('users').findOne({ _id: new ObjectId(employee_id) }),
        db.collection('pay_periods').findOne({ _id: new ObjectId(pay_period_id) })
      ]);

      if (!employee) {
        return res.status(404).json({
          message: 'Employee not found'
        });
      }

      if (!payPeriod) {
        return res.status(404).json({
          message: 'Pay period not found'
        });
      }

      const alert = await Alert.createMissingTimesheetAlert(db, employee, payPeriod, req.user._id);

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'create_missing_timesheet_alert',
        entity_type: 'alert',
        entity_id: alert._id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          employee_id: employee_id,
          pay_period_id: pay_period_id,
          employee_name: `${employee.first_name} ${employee.last_name}`
        },
        severity: 'medium',
        category: 'alert_generation'
      });

      res.status(201).json({
        message: 'Missing timesheet alert created successfully',
        alert: alert
      });
    } catch (error) {
      console.error('Error creating missing timesheet alert:', error);
      res.status(500).json({
        message: 'Failed to create missing timesheet alert',
        error: error.message
      });
    }
  }
);

module.exports = router;