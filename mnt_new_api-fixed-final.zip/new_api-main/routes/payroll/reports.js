const express = require('express');
const router = express.Router();
const Report = require('../../models/Report');
const PayrollAuditLog = require('../../models/PayrollAuditLog');
const permissionAuth = require('../../middleware/permissionAuth');
const ReportGenerator = require('../../utils/reportGenerator');
const path = require('path');
const fs = require('fs-extra');

// GET /api/payroll/reports - Get all reports for user
router.get('/',
  permissionAuth(['payroll_view_reports', 'payroll_generate_reports']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { 
        report_type, 
        status, 
        page = 1, 
        limit = 50 
      } = req.query;

      const options = {
        limit: parseInt(limit),
        skip: (parseInt(page) - 1) * parseInt(limit)
      };

      if (report_type) options.report_type = report_type;
      if (status) options.status = status;

      const reports = await Report.findByUser(db, req.user._id, options);
      
      // Get total count for pagination
      const allReports = await Report.findByUser(db, req.user._id, { 
        report_type: options.report_type, 
        status: options.status 
      });
      const total = allReports.length;

      res.json({
        message: 'Reports retrieved successfully',
        reports: reports,
        pagination: {
          current_page: parseInt(page),
          total_pages: Math.ceil(total / parseInt(limit)),
          total_records: total,
          limit: parseInt(limit)
        }
      });
    } catch (error) {
      console.error('Error fetching reports:', error);
      res.status(500).json({
        message: 'Failed to retrieve reports',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/reports/:id - Get specific report
router.get('/:id',
  permissionAuth(['payroll_view_reports', 'payroll_generate_reports']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const report = await Report.findById(db, req.params.id);

      if (!report) {
        return res.status(404).json({
          message: 'Report not found'
        });
      }

      // Check if user has access to this report
      const hasAccess = report.generated_by.equals(req.user._id) ||
        report.shared_with?.some(share => share.user_id.equals(req.user._id));

      if (!hasAccess) {
        return res.status(403).json({
          message: 'Access denied to this report'
        });
      }

      res.json({
        message: 'Report retrieved successfully',
        report: report
      });
    } catch (error) {
      console.error('Error fetching report:', error);
      res.status(500).json({
        message: 'Failed to retrieve report',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/reports/payroll-summary - Generate payroll summary report
router.post('/payroll-summary',
  permissionAuth('payroll_generate_reports'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { start_date, end_date, branch_id, department, format = 'json' } = req.body;

      if (!start_date || !end_date) {
        return res.status(400).json({
          message: 'Start date and end date are required'
        });
      }

      // Create report record
      const reportData = {
        report_name: `Payroll Summary - ${start_date} to ${end_date}`,
        report_type: 'payroll_summary',
        description: 'Summary of payroll data for specified period',
        parameters: { start_date, end_date, branch_id, department },
        format: format,
        generated_by: req.user._id
      };

      const report = await Report.create(db, reportData);
      const startTime = Date.now();

      try {
        // Generate report data
        const reportResult = await Report.generatePayrollSummary(db, reportData.parameters);
        const generationTime = Date.now() - startTime;

        // Update report with results
        await Report.markCompleted(db, report._id, reportResult, null, generationTime);

        // Log audit trail
        await PayrollAuditLog.createAuditEntry(db, {
          user_id: req.user._id,
          user_email: req.user.email,
          action: 'generate_payroll_summary_report',
          entity_type: 'report',
          entity_id: report._id,
          ip_address: req.ip,
          user_agent: req.get('User-Agent'),
          details: {
            report_type: 'payroll_summary',
            parameters: reportData.parameters,
            generation_time_ms: generationTime
          },
          severity: 'medium',
          category: 'report_generation'
        });

        const completedReport = await Report.findById(db, report._id);

        res.status(201).json({
          message: 'Payroll summary report generated successfully',
          report: completedReport
        });

      } catch (generationError) {
        await Report.markFailed(db, report._id, generationError.message);
        throw generationError;
      }

    } catch (error) {
      console.error('Error generating payroll summary report:', error);
      res.status(500).json({
        message: 'Failed to generate payroll summary report',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/reports/employee-earnings - Generate employee earnings report
router.post('/employee-earnings',
  permissionAuth('payroll_generate_reports'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { start_date, end_date, employee_ids, format = 'json' } = req.body;

      if (!start_date || !end_date) {
        return res.status(400).json({
          message: 'Start date and end date are required'
        });
      }

      // Create report record
      const reportData = {
        report_name: `Employee Earnings - ${start_date} to ${end_date}`,
        report_type: 'employee_earnings',
        description: 'Employee earnings breakdown for specified period',
        parameters: { start_date, end_date, employee_ids },
        format: format,
        generated_by: req.user._id
      };

      const report = await Report.create(db, reportData);
      const startTime = Date.now();

      try {
        // Generate report data
        const reportResult = await Report.generateEmployeeEarnings(db, reportData.parameters);
        const generationTime = Date.now() - startTime;

        // Update report with results
        await Report.markCompleted(db, report._id, reportResult, null, generationTime);

        // Log audit trail
        await PayrollAuditLog.createAuditEntry(db, {
          user_id: req.user._id,
          user_email: req.user.email,
          action: 'generate_employee_earnings_report',
          entity_type: 'report',
          entity_id: report._id,
          ip_address: req.ip,
          user_agent: req.get('User-Agent'),
          details: {
            report_type: 'employee_earnings',
            parameters: reportData.parameters,
            generation_time_ms: generationTime
          },
          severity: 'medium',
          category: 'report_generation'
        });

        const completedReport = await Report.findById(db, report._id);

        res.status(201).json({
          message: 'Employee earnings report generated successfully',
          report: completedReport
        });

      } catch (generationError) {
        await Report.markFailed(db, report._id, generationError.message);
        throw generationError;
      }

    } catch (error) {
      console.error('Error generating employee earnings report:', error);
      res.status(500).json({
        message: 'Failed to generate employee earnings report',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/reports/deduction-summary - Generate deduction summary report
router.post('/deduction-summary',
  permissionAuth('payroll_generate_reports'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { start_date, end_date, format = 'json' } = req.body;

      if (!start_date || !end_date) {
        return res.status(400).json({
          message: 'Start date and end date are required'
        });
      }

      // Create report record
      const reportData = {
        report_name: `Deduction Summary - ${start_date} to ${end_date}`,
        report_type: 'deduction_summary',
        description: 'Summary of all deductions for specified period',
        parameters: { start_date, end_date },
        format: format,
        generated_by: req.user._id
      };

      const report = await Report.create(db, reportData);
      const startTime = Date.now();

      try {
        // Generate report data
        const reportResult = await Report.generateDeductionSummary(db, reportData.parameters);
        const generationTime = Date.now() - startTime;

        // Update report with results
        await Report.markCompleted(db, report._id, reportResult, null, generationTime);

        // Log audit trail
        await PayrollAuditLog.createAuditEntry(db, {
          user_id: req.user._id,
          user_email: req.user.email,
          action: 'generate_deduction_summary_report',
          entity_type: 'report',
          entity_id: report._id,
          ip_address: req.ip,
          user_agent: req.get('User-Agent'),
          details: {
            report_type: 'deduction_summary',
            parameters: reportData.parameters,
            generation_time_ms: generationTime
          },
          severity: 'medium',
          category: 'report_generation'
        });

        const completedReport = await Report.findById(db, report._id);

        res.status(201).json({
          message: 'Deduction summary report generated successfully',
          report: completedReport
        });

      } catch (generationError) {
        await Report.markFailed(db, report._id, generationError.message);
        throw generationError;
      }

    } catch (error) {
      console.error('Error generating deduction summary report:', error);
      res.status(500).json({
        message: 'Failed to generate deduction summary report',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/reports/attendance-summary - Generate attendance summary report
router.post('/attendance-summary',
  permissionAuth('payroll_generate_reports'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { start_date, end_date, employee_ids, format = 'json' } = req.body;

      if (!start_date || !end_date) {
        return res.status(400).json({
          message: 'Start date and end date are required'
        });
      }

      // Create report record
      const reportData = {
        report_name: `Attendance Summary - ${start_date} to ${end_date}`,
        report_type: 'attendance_summary',
        description: 'Employee attendance summary for specified period',
        parameters: { start_date, end_date, employee_ids },
        format: format,
        generated_by: req.user._id
      };

      const report = await Report.create(db, reportData);
      const startTime = Date.now();

      try {
        // Generate report data
        const reportResult = await Report.generateAttendanceSummary(db, reportData.parameters);
        const generationTime = Date.now() - startTime;

        // Update report with results
        await Report.markCompleted(db, report._id, reportResult, null, generationTime);

        // Log audit trail
        await PayrollAuditLog.createAuditEntry(db, {
          user_id: req.user._id,
          user_email: req.user.email,
          action: 'generate_attendance_summary_report',
          entity_type: 'report',
          entity_id: report._id,
          ip_address: req.ip,
          user_agent: req.get('User-Agent'),
          details: {
            report_type: 'attendance_summary',
            parameters: reportData.parameters,
            generation_time_ms: generationTime
          },
          severity: 'medium',
          category: 'report_generation'
        });

        const completedReport = await Report.findById(db, report._id);

        res.status(201).json({
          message: 'Attendance summary report generated successfully',
          report: completedReport
        });

      } catch (generationError) {
        await Report.markFailed(db, report._id, generationError.message);
        throw generationError;
      }

    } catch (error) {
      console.error('Error generating attendance summary report:', error);
      res.status(500).json({
        message: 'Failed to generate attendance summary report',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/reports/:id/download - Download report
router.get('/:id/download',
  permissionAuth(['payroll_view_reports', 'payroll_generate_reports']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const report = await Report.findById(db, req.params.id);

      if (!report) {
        return res.status(404).json({
          message: 'Report not found'
        });
      }

      // Check if user has access to this report
      const hasAccess = report.generated_by.equals(req.user._id) ||
        report.shared_with?.some(share => 
          share.user_id.equals(req.user._id) && 
          share.permissions.includes('download')
        );

      if (!hasAccess) {
        return res.status(403).json({
          message: 'Access denied to download this report'
        });
      }

      if (report.status !== 'completed') {
        return res.status(400).json({
          message: 'Report is not ready for download'
        });
      }

      // Increment download count
      await Report.incrementDownloadCount(db, req.params.id);

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'download_report',
        entity_type: 'report',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          report_type: report.report_type,
          report_name: report.report_name
        },
        severity: 'low',
        category: 'data_access'
      });

      // Return report data (in a real implementation, you might serve a file)
      res.json({
        message: 'Report data retrieved successfully',
        report: {
          name: report.report_name,
          type: report.report_type,
          format: report.format,
          data: report.data,
          generated_at: report.generation_date
        }
      });

    } catch (error) {
      console.error('Error downloading report:', error);
      res.status(500).json({
        message: 'Failed to download report',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/reports/:id/share - Share report with other users
router.post('/:id/share',
  permissionAuth('payroll_generate_reports'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { user_ids, permissions = ['view'] } = req.body;

      if (!user_ids || !Array.isArray(user_ids)) {
        return res.status(400).json({
          message: 'User IDs array is required'
        });
      }

      const report = await Report.findById(db, req.params.id);

      if (!report) {
        return res.status(404).json({
          message: 'Report not found'
        });
      }

      // Check if user owns this report
      if (!report.generated_by.equals(req.user._id)) {
        return res.status(403).json({
          message: 'Only report owner can share reports'
        });
      }

      // Prepare sharing data
      const sharedWith = user_ids.map(userId => ({
        user_id: new ObjectId(userId),
        shared_at: new Date(),
        permissions: permissions
      }));

      // Update report with sharing information
      const success = await Report.updateReport(db, req.params.id, {
        shared_with: [...(report.shared_with || []), ...sharedWith]
      });

      if (!success) {
        return res.status(500).json({
          message: 'Failed to share report'
        });
      }

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'share_report',
        entity_type: 'report',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          shared_with_users: user_ids,
          permissions: permissions
        },
        severity: 'medium',
        category: 'authorization'
      });

      res.json({
        message: 'Report shared successfully',
        shared_with_count: user_ids.length
      });

    } catch (error) {
      console.error('Error sharing report:', error);
      res.status(500).json({
        message: 'Failed to share report',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/reports/statistics - Get report statistics
router.get('/statistics',
  permissionAuth(['payroll_view_reports', 'payroll_generate_reports']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      // Get statistics for current user or all users (if admin)
      const userId = req.user.role_name === 'Admin' ? null : req.user._id;
      const statistics = await Report.getStatistics(db, userId);

      res.json({
        message: 'Report statistics retrieved successfully',
        statistics: statistics
      });
    } catch (error) {
      console.error('Error fetching report statistics:', error);
      res.status(500).json({
        message: 'Failed to retrieve report statistics',
        error: error.message
      });
    }
  }
);

// DELETE /api/payroll/reports/:id - Delete report
router.delete('/:id',
  permissionAuth('payroll_generate_reports'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const report = await Report.findById(db, req.params.id);

      if (!report) {
        return res.status(404).json({
          message: 'Report not found'
        });
      }

      // Check if user owns this report
      if (!report.generated_by.equals(req.user._id)) {
        return res.status(403).json({
          message: 'Only report owner can delete reports'
        });
      }

      const result = await db.collection('reports').deleteOne({
        _id: new ObjectId(req.params.id)
      });

      if (result.deletedCount === 0) {
        return res.status(404).json({
          message: 'Report not found or already deleted'
        });
      }

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'delete_report',
        entity_type: 'report',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          report_name: report.report_name,
          report_type: report.report_type
        },
        severity: 'high',
        category: 'data_modification'
      });

      res.json({
        message: 'Report deleted successfully'
      });

    } catch (error) {
      console.error('Error deleting report:', error);
      res.status(500).json({
        message: 'Failed to delete report',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/reports/generate - Generate report in different formats
router.post('/generate',
  permissionAuth('payroll_generate_reports'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { 
        report_type, 
        start_date, 
        end_date, 
        employee_ids, 
        branch_id, 
        department, 
        format = 'json' 
      } = req.body;

      if (!report_type || !start_date || !end_date) {
        return res.status(400).json({
          message: 'Report type, start date, and end date are required'
        });
      }

      let reportData;

      // Generate report data based on type
      switch (report_type) {
        case 'payroll_summary':
          reportData = await Report.generatePayrollSummary(db, { start_date, end_date, branch_id, department });
          break;
        case 'employee_earnings':
          reportData = await Report.generateEmployeeEarnings(db, { start_date, end_date, employee_ids });
          break;
        case 'deduction_summary':
          reportData = await Report.generateDeductionSummary(db, { start_date, end_date });
          break;
        case 'attendance_summary':
          reportData = await Report.generateAttendanceSummary(db, { start_date, end_date, employee_ids });
          break;
        default:
          return res.status(400).json({
            message: 'Invalid report type'
          });
      }

      // Create report record
      const reportRecord = {
        report_name: `${report_type.replace('_', ' ').toUpperCase()} - ${start_date} to ${end_date}`,
        report_type: report_type,
        description: `Generated report for ${report_type.replace('_', ' ')} from ${start_date} to ${end_date}`,
        parameters: { start_date, end_date, employee_ids, branch_id, department },
        format: format,
        generated_by: req.user._id
      };

      const report = await Report.create(db, reportRecord);

      // Save report data to file if required
      if (format !== 'json') {
        const filePath = path.join(__dirname, `../../reports/${report._id}.${format}`);
        await fs.outputJson(filePath, reportData);

        // Update report record with file path
        await Report.updateReport(db, report._id, { file_path: filePath });
      }

      res.status(201).json({
        message: 'Report generated successfully',
        report: report
      });

    } catch (error) {
      console.error('Error generating report:', error);
      res.status(500).json({
        message: 'Failed to generate report',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/reports/:id/generate-file - Generate report file in specified format
router.post('/:id/generate-file',
  permissionAuth(['payroll_view_reports', 'payroll_generate_reports']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { format = 'pdf' } = req.body;
      
      // Validate format
      const supportedFormats = ['pdf', 'csv', 'xlsx', 'excel'];
      if (!supportedFormats.includes(format.toLowerCase())) {
        return res.status(400).json({
          message: 'Unsupported format. Supported formats: pdf, csv, xlsx'
        });
      }

      const report = await Report.findById(db, req.params.id);

      if (!report) {
        return res.status(404).json({
          message: 'Report not found'
        });
      }

      // Check if user has access to this report
      const hasAccess = report.generated_by.equals(req.user._id) ||
        report.shared_with?.some(share => 
          share.user_id.equals(req.user._id) && 
          (share.permissions.includes('download') || share.permissions.includes('view'))
        );

      if (!hasAccess) {
        return res.status(403).json({
          message: 'Access denied to this report'
        });
      }

      if (report.status !== 'completed') {
        return res.status(400).json({
          message: 'Report is not ready for file generation'
        });
      }

      // Prepare report data for file generation
      const reportData = {
        report_name: report.report_name,
        report_type: report.report_type,
        data: report.data
      };

      // Generate file
      const outputDir = path.join(__dirname, '../../uploads/reports');
      await fs.ensureDir(outputDir);

      const fileResult = await ReportGenerator.generate(reportData, format, outputDir);

      // Update report with file information
      const fileInfo = {
        file_path: fileResult.file_path,
        file_size: fileResult.file_size,
        file_format: fileResult.format,
        file_generated_at: new Date()
      };

      await Report.updateReport(db, req.params.id, {
        $push: {
          generated_files: fileInfo
        }
      });

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'generate_report_file',
        entity_type: 'report',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          report_type: report.report_type,
          file_format: format,
          file_size: fileResult.file_size
        },
        severity: 'medium',
        category: 'file_generation'
      });

      res.json({
        message: `${format.toUpperCase()} file generated successfully`,
        file: {
          filename: fileResult.filename,
          format: fileResult.format,
          size: fileResult.file_size,
          download_url: `/api/payroll/reports/${req.params.id}/download-file/${fileResult.filename}`
        }
      });

    } catch (error) {
      console.error('Error generating report file:', error);
      res.status(500).json({
        message: 'Failed to generate report file',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/reports/:id/download-file/:filename - Download generated report file
router.get('/:id/download-file/:filename',
  permissionAuth(['payroll_view_reports', 'payroll_generate_reports']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const report = await Report.findById(db, req.params.id);

      if (!report) {
        return res.status(404).json({
          message: 'Report not found'
        });
      }

      // Check if user has access to this report
      const hasAccess = report.generated_by.equals(req.user._id) ||
        report.shared_with?.some(share => 
          share.user_id.equals(req.user._id) && 
          (share.permissions.includes('download') || share.permissions.includes('view'))
        );

      if (!hasAccess) {
        return res.status(403).json({
          message: 'Access denied to download this report'
        });
      }

      // Find the file in generated_files
      const fileInfo = report.generated_files?.find(file => 
        file.file_path.endsWith(req.params.filename)
      );

      if (!fileInfo) {
        return res.status(404).json({
          message: 'Report file not found'
        });
      }

      // Check if file exists
      if (!await fs.pathExists(fileInfo.file_path)) {
        return res.status(404).json({
          message: 'Report file no longer exists on server'
        });
      }

      // Increment download count
      await Report.incrementDownloadCount(db, req.params.id);

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'download_report_file',
        entity_type: 'report',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          filename: req.params.filename,
          file_format: fileInfo.file_format,
          file_size: fileInfo.file_size
        },
        severity: 'low',
        category: 'file_access'
      });

      // Set appropriate headers
      const fileExtension = path.extname(req.params.filename).toLowerCase();
      let contentType = 'application/octet-stream';
      
      switch (fileExtension) {
        case '.pdf':
          contentType = 'application/pdf';
          break;
        case '.csv':
          contentType = 'text/csv';
          break;
        case '.xlsx':
          contentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
          break;
      }

      res.setHeader('Content-Type', contentType);
      res.setHeader('Content-Disposition', `attachment; filename="${req.params.filename}"`);
      res.setHeader('Content-Length', fileInfo.file_size);

      // Stream the file
      const fileStream = fs.createReadStream(fileInfo.file_path);
      fileStream.pipe(res);

    } catch (error) {
      console.error('Error downloading report file:', error);
      res.status(500).json({
        message: 'Failed to download report file',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/reports/generate-direct - Generate report directly in specified format
router.post('/generate-direct',
  permissionAuth('payroll_generate_reports'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { 
        report_type, 
        parameters, 
        format = 'pdf',
        report_name 
      } = req.body;

      // Validate required fields
      if (!report_type || !parameters) {
        return res.status(400).json({
          message: 'Report type and parameters are required'
        });
      }

      // Validate format
      const supportedFormats = ['pdf', 'csv', 'xlsx', 'excel'];
      if (!supportedFormats.includes(format.toLowerCase())) {
        return res.status(400).json({
          message: 'Unsupported format. Supported formats: pdf, csv, xlsx'
        });
      }

      // Validate report type
      const supportedTypes = ['payroll_summary', 'employee_earnings', 'deduction_summary', 'attendance_summary'];
      if (!supportedTypes.includes(report_type)) {
        return res.status(400).json({
          message: `Unsupported report type. Supported types: ${supportedTypes.join(', ')}`
        });
      }

      const startTime = Date.now();

      try {
        // Generate report data based on type
        let reportResult;
        switch (report_type) {
          case 'payroll_summary':
            reportResult = await Report.generatePayrollSummary(db, parameters);
            break;
          case 'employee_earnings':
            reportResult = await Report.generateEmployeeEarnings(db, parameters);
            break;
          case 'deduction_summary':
            reportResult = await Report.generateDeductionSummary(db, parameters);
            break;
          case 'attendance_summary':
            reportResult = await Report.generateAttendanceSummary(db, parameters);
            break;
        }

        // Prepare report data for file generation
        const reportData = {
          report_name: report_name || `${report_type.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())} Report`,
          report_type: report_type,
          data: reportResult
        };

        // Generate file
        const outputDir = path.join(__dirname, '../../uploads/reports');
        await fs.ensureDir(outputDir);

        const fileResult = await ReportGenerator.generate(reportData, format, outputDir);
        const generationTime = Date.now() - startTime;

        // Log audit trail
        await PayrollAuditLog.createAuditEntry(db, {
          user_id: req.user._id,
          user_email: req.user.email,
          action: 'generate_direct_report',
          entity_type: 'report',
          ip_address: req.ip,
          user_agent: req.get('User-Agent'),
          details: {
            report_type: report_type,
            file_format: format,
            file_size: fileResult.file_size,
            generation_time_ms: generationTime,
            parameters: parameters
          },
          severity: 'medium',
          category: 'report_generation'
        });

        // Set appropriate headers for immediate download
        const fileExtension = path.extname(fileResult.filename).toLowerCase();
        let contentType = 'application/octet-stream';
        
        switch (fileExtension) {
          case '.pdf':
            contentType = 'application/pdf';
            break;
          case '.csv':
            contentType = 'text/csv';
            break;
          case '.xlsx':
            contentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
            break;
        }

        res.setHeader('Content-Type', contentType);
        res.setHeader('Content-Disposition', `attachment; filename="${fileResult.filename}"`);
        res.setHeader('Content-Length', fileResult.file_size);

        // Stream the file and clean up after
        const fileStream = fs.createReadStream(fileResult.file_path);
        fileStream.pipe(res);

        // Clean up the temporary file after sending
        fileStream.on('end', async () => {
          try {
            await fs.remove(fileResult.file_path);
          } catch (cleanupError) {
            console.error('Error cleaning up temporary file:', cleanupError);
          }
        });

      } catch (generationError) {
        throw generationError;
      }

    } catch (error) {
      console.error('Error generating direct report:', error);
      res.status(500).json({
        message: 'Failed to generate report',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/reports/cleanup - Clean up old report files
router.post('/cleanup',
  permissionAuth('payroll_generate_reports'),
  async (req, res) => {
    try {
      const { max_age_days = 30 } = req.body;
      
      // Only allow admins to perform cleanup
      if (req.user.role_name !== 'Admin') {
        return res.status(403).json({
          message: 'Only administrators can perform report cleanup'
        });
      }

      const outputDir = path.join(__dirname, '../../uploads/reports');
      const deletedCount = await ReportGenerator.cleanupOldFiles(outputDir, max_age_days);

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(req.app.locals.db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'cleanup_report_files',
        entity_type: 'system',
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          deleted_files_count: deletedCount,
          max_age_days: max_age_days
        },
        severity: 'medium',
        category: 'system_maintenance'
      });

      res.json({
        message: `Report cleanup completed. ${deletedCount} files deleted.`,
        deleted_files: deletedCount
      });

    } catch (error) {
      console.error('Error during report cleanup:', error);
      res.status(500).json({
        message: 'Failed to cleanup report files',
        error: error.message
      });
    }
  }
);

module.exports = router;