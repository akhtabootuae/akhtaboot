const express = require('express');
const router = express.Router();
const PayrollCalculation = require('../../models/PayrollCalculation');
const PayrollAuditLog = require('../../models/PayrollAuditLog');
const permissionAuth = require('../../middleware/permissionAuth');

// GET /api/payroll/calculations - Get all calculations (with filtering)
router.get('/',
  permissionAuth(['payroll_view_calculations', 'payroll_process']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { 
        pay_period_id, 
        employee_id, 
        status, 
        page = 1, 
        limit = 50 
      } = req.query;

      const options = {
        limit: parseInt(limit),
        skip: (parseInt(page) - 1) * parseInt(limit)
      };

      let calculations;
      let total = 0;

      if (pay_period_id) {
        calculations = await PayrollCalculation.findByPayPeriod(db, pay_period_id, options);
        // Get total count
        const allCalculations = await PayrollCalculation.findByPayPeriod(db, pay_period_id);
        total = allCalculations.length;
      } else if (employee_id) {
        calculations = await PayrollCalculation.findByEmployee(db, employee_id, options);
        // Get total count
        const allCalculations = await PayrollCalculation.findByEmployee(db, employee_id, {});
        total = allCalculations.length;
      } else {
        // Get all calculations with employee and pay period info
        const pipeline = [
          {
            $lookup: {
              from: 'users',
              localField: 'employee_id',
              foreignField: '_id',
              as: 'employee'
            }
          },
          {
            $lookup: {
              from: 'pay_periods',
              localField: 'pay_period_id',
              foreignField: '_id',
              as: 'pay_period'
            }
          },
          { $unwind: '$employee' },
          { $unwind: '$pay_period' },
          {
            $project: {
              employee_id: 1,
              pay_period_id: 1,
              gross_pay: 1,
              total_deductions: 1,
              net_pay: 1,
              total_hours: 1,
              status: 1,
              calculation_date: 1,
              approved_at: 1,
              paid_at: 1,
              'employee.email': 1,
              'employee.first_name': 1,
              'employee.last_name': 1,
              'pay_period.period_name': 1,
              'pay_period.start_date': 1,
              'pay_period.end_date': 1
            }
          },
          { $sort: { calculation_date: -1 } }
        ];

        // Add status filter if provided
        if (status) {
          pipeline.unshift({ $match: { status: status } });
        }

        // Add pagination
        pipeline.push({ $skip: options.skip });
        pipeline.push({ $limit: options.limit });

        calculations = await db.collection('payroll_calculations').aggregate(pipeline).toArray();
        
        // Get total count
        const countPipeline = pipeline.slice(0, -2); // Remove skip and limit
        countPipeline.push({ $count: 'total' });
        const countResult = await db.collection('payroll_calculations').aggregate(countPipeline).toArray();
        total = countResult[0]?.total || 0;
      }

      res.json({
        message: 'Payroll calculations retrieved successfully',
        calculations: calculations,
        pagination: {
          current_page: parseInt(page),
          total_pages: Math.ceil(total / parseInt(limit)),
          total_records: total,
          limit: parseInt(limit)
        }
      });
    } catch (error) {
      console.error('Error fetching payroll calculations:', error);
      res.status(500).json({
        message: 'Failed to retrieve payroll calculations',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/calculations/:id - Get specific calculation
router.get('/:id',
  permissionAuth(['payroll_view_calculations', 'payroll_process']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const calculation = await PayrollCalculation.findById(db, req.params.id);

      if (!calculation) {
        return res.status(404).json({
          message: 'Payroll calculation not found'
        });
      }

      res.json({
        message: 'Payroll calculation retrieved successfully',
        calculation: calculation
      });
    } catch (error) {
      console.error('Error fetching payroll calculation:', error);
      res.status(500).json({
        message: 'Failed to retrieve payroll calculation',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/calculations - Create new calculation
router.post('/',
  permissionAuth('payroll_process'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      const calculationData = {
        ...req.body,
        created_by: req.user._id
      };

      const calculation = await PayrollCalculation.create(db, calculationData);

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'create_payroll_calculation',
        entity_type: 'payroll_calculation',
        entity_id: calculation._id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          employee_id: calculationData.employee_id,
          pay_period_id: calculationData.pay_period_id,
          gross_pay: calculation.gross_pay,
          net_pay: calculation.net_pay
        },
        severity: 'medium',
        category: 'calculation'
      });

      res.status(201).json({
        message: 'Payroll calculation created successfully',
        calculation: calculation
      });
    } catch (error) {
      console.error('Error creating payroll calculation:', error);
      res.status(400).json({
        message: 'Failed to create payroll calculation',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/calculations/batch - Create calculations for entire pay period
router.post('/batch',
  permissionAuth('payroll_process'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { pay_period_id, employee_ids } = req.body;

      if (!pay_period_id) {
        return res.status(400).json({
          message: 'Pay period ID is required'
        });
      }

      // Get pay period
      const payPeriod = await db.collection('pay_periods').findOne({
        _id: new ObjectId(pay_period_id)
      });

      if (!payPeriod) {
        return res.status(404).json({
          message: 'Pay period not found'
        });
      }

      // Get eligible employees
      let eligibleEmployees;
      if (employee_ids && employee_ids.length > 0) {
        eligibleEmployees = await db.collection('users').find({
          _id: { $in: employee_ids.map(id => new ObjectId(id)) },
          'payroll_info.payroll_eligible': true,
          status: 'active'
        }).toArray();
      } else {
        eligibleEmployees = await db.collection('users').find({
          'payroll_info.payroll_eligible': true,
          status: 'active'
        }).toArray();
      }

      const results = {
        successful: [],
        failed: [],
        skipped: []
      };

      // Process each employee
      for (const employee of eligibleEmployees) {
        try {
          // Check if calculation already exists
          const existing = await db.collection('payroll_calculations').findOne({
            employee_id: employee._id,
            pay_period_id: new ObjectId(pay_period_id)
          });

          if (existing) {
            results.skipped.push({
              employee_id: employee._id.toString(),
              email: employee.email,
              reason: 'Calculation already exists'
            });
            continue;
          }

          const calculationData = {
            employee_id: employee._id.toString(),
            pay_period_id: pay_period_id,
            created_by: req.user._id
          };

          const calculation = await PayrollCalculation.create(db, calculationData);
          
          results.successful.push({
            employee_id: employee._id.toString(),
            email: employee.email,
            calculation_id: calculation._id,
            gross_pay: calculation.gross_pay,
            net_pay: calculation.net_pay
          });

        } catch (error) {
          results.failed.push({
            employee_id: employee._id.toString(),
            email: employee.email,
            error: error.message
          });
        }
      }

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'batch_create_payroll_calculations',
        entity_type: 'payroll_calculation',
        entity_id: pay_period_id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          pay_period_id: pay_period_id,
          total_processed: eligibleEmployees.length,
          successful: results.successful.length,
          failed: results.failed.length,
          skipped: results.skipped.length
        },
        severity: 'high',
        category: 'batch_operation'
      });

      res.json({
        message: 'Batch payroll calculation completed',
        results: results,
        summary: {
          total_employees: eligibleEmployees.length,
          successful: results.successful.length,
          failed: results.failed.length,
          skipped: results.skipped.length
        }
      });
    } catch (error) {
      console.error('Error creating batch payroll calculations:', error);
      res.status(500).json({
        message: 'Failed to create batch payroll calculations',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/calculations/:id/approve - Approve calculation
router.post('/:id/approve',
  permissionAuth('payroll_approve'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      const success = await PayrollCalculation.approve(db, req.params.id, req.user._id);

      if (!success) {
        return res.status(404).json({
          message: 'Calculation not found or cannot be approved'
        });
      }

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'approve_payroll_calculation',
        entity_type: 'payroll_calculation',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          approval_notes: req.body.notes
        },
        severity: 'high',
        category: 'authorization'
      });

      const calculation = await PayrollCalculation.findById(db, req.params.id);

      res.json({
        message: 'Payroll calculation approved successfully',
        calculation: calculation
      });
    } catch (error) {
      console.error('Error approving payroll calculation:', error);
      res.status(500).json({
        message: 'Failed to approve payroll calculation',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/calculations/batch-approve - Batch approve calculations
router.post('/batch-approve',
  permissionAuth('payroll_approve'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { calculation_ids } = req.body;

      if (!calculation_ids || !Array.isArray(calculation_ids)) {
        return res.status(400).json({
          message: 'Calculation IDs array is required'
        });
      }

      const approvedCount = await PayrollCalculation.batchApprove(db, calculation_ids, req.user._id);

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'batch_approve_payroll_calculations',
        entity_type: 'payroll_calculation',
        entity_id: calculation_ids[0], // Use first ID as reference
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          calculation_ids: calculation_ids,
          approved_count: approvedCount
        },
        severity: 'high',
        category: 'batch_operation'
      });

      res.json({
        message: 'Batch approval completed',
        approved_count: approvedCount,
        requested_count: calculation_ids.length
      });
    } catch (error) {
      console.error('Error batch approving calculations:', error);
      res.status(500).json({
        message: 'Failed to batch approve calculations',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/calculations/:id/mark-paid - Mark calculation as paid
router.post('/:id/mark-paid',
  permissionAuth('payroll_process'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { pay_method } = req.body;
      
      const success = await PayrollCalculation.markPaid(db, req.params.id, req.user._id, pay_method);

      if (!success) {
        return res.status(404).json({
          message: 'Calculation not found or cannot be marked as paid'
        });
      }

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'mark_payroll_paid',
        entity_type: 'payroll_calculation',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          pay_method: pay_method || 'bank_transfer'
        },
        severity: 'high',
        category: 'payment'
      });

      const calculation = await PayrollCalculation.findById(db, req.params.id);

      res.json({
        message: 'Payroll calculation marked as paid successfully',
        calculation: calculation
      });
    } catch (error) {
      console.error('Error marking calculation as paid:', error);
      res.status(500).json({
        message: 'Failed to mark calculation as paid',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/calculations/:id/recalculate - Recalculate existing calculation
router.post('/:id/recalculate',
  permissionAuth('payroll_process'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      const success = await PayrollCalculation.recalculate(db, req.params.id, req.user._id);

      if (!success) {
        return res.status(404).json({
          message: 'Calculation not found or cannot be recalculated'
        });
      }

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'recalculate_payroll',
        entity_type: 'payroll_calculation',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          reason: req.body.reason || 'Manual recalculation'
        },
        severity: 'medium',
        category: 'calculation'
      });

      const calculation = await PayrollCalculation.findById(db, req.params.id);

      res.json({
        message: 'Payroll calculation recalculated successfully',
        calculation: calculation
      });
    } catch (error) {
      console.error('Error recalculating payroll:', error);
      res.status(500).json({
        message: 'Failed to recalculate payroll',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/calculations/pay-periods/:payPeriodId/summary - Get pay period summary
router.get('/pay-periods/:payPeriodId/summary',
  permissionAuth(['payroll_view_calculations', 'payroll_process']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      const summary = await PayrollCalculation.getPayPeriodSummary(db, req.params.payPeriodId);

      res.json({
        message: 'Pay period summary retrieved successfully',
        summary: summary
      });
    } catch (error) {
      console.error('Error fetching pay period summary:', error);
      res.status(500).json({
        message: 'Failed to retrieve pay period summary',
        error: error.message
      });
    }
  }
);

// DELETE /api/payroll/calculations/:id - Delete calculation (draft/calculated only)
router.delete('/:id',
  permissionAuth('payroll_process'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      const success = await PayrollCalculation.delete(db, req.params.id);

      if (!success) {
        return res.status(404).json({
          message: 'Calculation not found or cannot be deleted (only draft/calculated calculations can be deleted)'
        });
      }

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'delete_payroll_calculation',
        entity_type: 'payroll_calculation',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          action: 'calculation_deleted'
        },
        severity: 'high',
        category: 'data_modification'
      });

      res.json({
        message: 'Payroll calculation deleted successfully'
      });
    } catch (error) {
      console.error('Error deleting payroll calculation:', error);
      res.status(500).json({
        message: 'Failed to delete payroll calculation',
        error: error.message
      });
    }
  }
);

module.exports = router;