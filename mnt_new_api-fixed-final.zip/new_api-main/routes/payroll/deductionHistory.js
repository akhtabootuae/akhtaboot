const express = require('express');
const router = express.Router();
const PayrollDeductionHistory = require('../../models/PayrollDeductionHistory');
const permissionAuth = require('../../middleware/permissionAuth');

// GET /api/payroll/deduction-history - Get all deduction history records
router.get('/deduction-history',
  permissionAuth(['payroll_view_deduction_history', 'payroll_manage_deductions']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { 
        page = 1, 
        limit = 50, 
        start_date, 
        end_date, 
        employee_id, 
        deduction_type_id 
      } = req.query;
      
      const options = {
        limit: parseInt(limit),
        skip: (parseInt(page) - 1) * parseInt(limit),
        startDate: start_date,
        endDate: end_date,
        employeeId: employee_id,
        deductionTypeId: deduction_type_id
      };
      
      const history = await PayrollDeductionHistory.findAll(db, options);
      
      // Count total records with same filters
      const countFilters = {};
      if (employee_id) countFilters.employeeId = employee_id;
      if (start_date) countFilters.startDate = start_date;
      if (end_date) countFilters.endDate = end_date;
      
      const total = await PayrollDeductionHistory.count(db, countFilters);
      
      res.json({
        message: 'All deduction history retrieved successfully',
        history: history,
        pagination: {
          current_page: parseInt(page),
          total_pages: Math.ceil(total / parseInt(limit)),
          total_records: total,
          limit: parseInt(limit)
        },
        filters: {
          start_date,
          end_date,
          employee_id,
          deduction_type_id
        }
      });
    } catch (error) {
      console.error('Error fetching all deduction history:', error);
      res.status(500).json({
        message: 'Failed to retrieve deduction history',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/employees/:employeeId/deduction-history - Get employee's deduction history
router.get('/:employeeId/deduction-history',
  permissionAuth(['payroll_view_deduction_history', 'payroll_manage_deductions']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { page = 1, limit = 50, start_date, end_date } = req.query;
      
      const options = {
        limit: parseInt(limit),
        skip: (parseInt(page) - 1) * parseInt(limit),
        startDate: start_date,
        endDate: end_date
      };
      
      const history = await PayrollDeductionHistory.findByEmployee(db, req.params.employeeId, options);
      const total = await PayrollDeductionHistory.count(db, { 
        employeeId: req.params.employeeId,
        startDate: start_date,
        endDate: end_date
      });
      
      res.json({
        message: 'Employee deduction history retrieved successfully',
        history: history,
        pagination: {
          current_page: parseInt(page),
          total_pages: Math.ceil(total / parseInt(limit)),
          total_records: total,
          limit: parseInt(limit)
        }
      });
    } catch (error) {
      console.error('Error fetching deduction history:', error);
      res.status(500).json({
        message: 'Failed to retrieve deduction history',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/deductions/:deductionId/history - Get history for specific deduction
router.get('/deductions/:deductionId/history',
  permissionAuth(['payroll_view_deduction_history', 'payroll_manage_deductions']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const history = await PayrollDeductionHistory.findByDeduction(db, req.params.deductionId);
      
      res.json({
        message: 'Deduction history retrieved successfully',
        history: history
      });
    } catch (error) {
      console.error('Error fetching deduction history:', error);
      res.status(500).json({
        message: 'Failed to retrieve deduction history',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/employees/:employeeId/deduction-summary - Get deduction summary
router.get('/:employeeId/deduction-summary',
  permissionAuth(['payroll_view_deduction_history', 'payroll_manage_deductions']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { start_date, end_date } = req.query;
      
      const options = {
        startDate: start_date,
        endDate: end_date
      };
      
      const summary = await PayrollDeductionHistory.getDeductionSummary(db, req.params.employeeId, options);
      
      res.json({
        message: 'Deduction summary retrieved successfully',
        summary: summary,
        period: {
          start_date: start_date,
          end_date: end_date
        }
      });
    } catch (error) {
      console.error('Error fetching deduction summary:', error);
      res.status(500).json({
        message: 'Failed to retrieve deduction summary',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/payroll-summary - Get payroll summary for a period
router.get('/payroll-summary',
  permissionAuth(['payroll_view_deduction_history', 'payroll_process']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { pay_period_start, pay_period_end, branch_id } = req.query;
      
      if (!pay_period_start || !pay_period_end) {
        return res.status(400).json({
          message: 'Pay period start and end dates are required'
        });
      }
      
      const options = {};
      if (branch_id) {
        options.branchId = branch_id;
      }
      
      const summary = await PayrollDeductionHistory.getPayrollSummary(
        db, 
        pay_period_start, 
        pay_period_end, 
        options
      );
      
      res.json({
        message: 'Payroll summary retrieved successfully',
        summary: summary,
        period: {
          start_date: pay_period_start,
          end_date: pay_period_end
        }
      });
    } catch (error) {
      console.error('Error fetching payroll summary:', error);
      res.status(500).json({
        message: 'Failed to retrieve payroll summary',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/deduction-trends - Get deduction trends over time
router.get('/deduction-trends',
  permissionAuth(['payroll_view_deduction_history', 'payroll_process']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { employee_id, deduction_type_id, months = 12 } = req.query;
      
      const options = {
        employeeId: employee_id,
        deductionTypeId: deduction_type_id,
        months: parseInt(months)
      };
      
      const trends = await PayrollDeductionHistory.getDeductionTrends(db, options);
      
      res.json({
        message: 'Deduction trends retrieved successfully',
        trends: trends,
        period_months: parseInt(months)
      });
    } catch (error) {
      console.error('Error fetching deduction trends:', error);
      res.status(500).json({
        message: 'Failed to retrieve deduction trends',
        error: error.message
      });
    }
  }
);

module.exports = router;