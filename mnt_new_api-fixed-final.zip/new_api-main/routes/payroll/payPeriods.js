const express = require('express');
const router = express.Router();
const { ObjectId } = require('mongodb');
const PayPeriod = require('../../models/PayPeriod');
const PayrollAuditLog = require('../../models/PayrollAuditLog');
const permissionAuth = require('../../middleware/permissionAuth');

// GET /api/payroll/pay-periods - Get all pay periods
router.get('/',
  permissionAuth(['payroll_view_pay_periods', 'payroll_manage_pay_periods']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { 
        year, 
        frequency, 
        status, 
        start_date, 
        end_date, 
        page = 1, 
        limit = 50 
      } = req.query;

      const criteria = {};
      if (year) criteria.year = parseInt(year);
      if (frequency) criteria.frequency = frequency;
      if (status) criteria.status = status;
      if (start_date) criteria.startDate = start_date;
      if (end_date) criteria.endDate = end_date;

      const options = {
        limit: parseInt(limit),
        skip: (parseInt(page) - 1) * parseInt(limit)
      };

      const payPeriods = await PayPeriod.find(db, criteria, options);
      
      // Get total count for pagination
      const totalPayPeriods = await PayPeriod.find(db, criteria);
      const total = totalPayPeriods.length;

      res.json({
        message: 'Pay periods retrieved successfully',
        pay_periods: payPeriods,
        pagination: {
          current_page: parseInt(page),
          total_pages: Math.ceil(total / parseInt(limit)),
          total_records: total,
          limit: parseInt(limit)
        }
      });
    } catch (error) {
      console.error('Error fetching pay periods:', error);
      res.status(500).json({
        message: 'Failed to retrieve pay periods',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/pay-periods/current - Get current active pay period
router.get('/current',
  permissionAuth(['payroll_view_pay_periods', 'payroll_manage_pay_periods']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const currentPeriod = await PayPeriod.findCurrent(db);

      if (!currentPeriod) {
        return res.status(404).json({
          message: 'No current active pay period found'
        });
      }

      res.json({
        message: 'Current pay period retrieved successfully',
        pay_period: currentPeriod
      });
    } catch (error) {
      console.error('Error fetching current pay period:', error);
      res.status(500).json({
        message: 'Failed to retrieve current pay period',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/pay-periods/:id - Get specific pay period
router.get('/:id',
  permissionAuth(['payroll_view_pay_periods', 'payroll_manage_pay_periods']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const payPeriod = await PayPeriod.findById(db, req.params.id);

      if (!payPeriod) {
        return res.status(404).json({
          message: 'Pay period not found'
        });
      }

      res.json({
        message: 'Pay period retrieved successfully',
        pay_period: payPeriod
      });
    } catch (error) {
      console.error('Error fetching pay period:', error);
      res.status(500).json({
        message: 'Failed to retrieve pay period',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/pay-periods - Create new pay period
router.post('/',
  permissionAuth('payroll_manage_pay_periods'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      const periodData = {
        ...req.body,
        created_by: req.user._id
      };

      const payPeriod = await PayPeriod.create(db, periodData);

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'create_pay_period',
        entity_type: 'pay_period',
        entity_id: payPeriod._id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          period_name: payPeriod.period_name,
          start_date: payPeriod.start_date,
          end_date: payPeriod.end_date,
          frequency: payPeriod.frequency
        },
        severity: 'medium',
        category: 'data_modification'
      });

      res.status(201).json({
        message: 'Pay period created successfully',
        pay_period: payPeriod
      });
    } catch (error) {
      console.error('Error creating pay period:', error);
      res.status(400).json({
        message: 'Failed to create pay period',
        error: error.message
      });
    }
  }
);

// PUT /api/payroll/pay-periods/:id - Update pay period
router.put('/:id',
  permissionAuth('payroll_manage_pay_periods'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      const updateData = {
        ...req.body,
        updated_by: req.user._id
      };

      const success = await PayPeriod.update(db, req.params.id, updateData);

      if (!success) {
        return res.status(404).json({
          message: 'Pay period not found or cannot be updated'
        });
      }

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'update_pay_period',
        entity_type: 'pay_period',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          updated_fields: Object.keys(req.body)
        },
        severity: 'medium',
        category: 'data_modification'
      });

      const updatedPayPeriod = await PayPeriod.findById(db, req.params.id);

      res.json({
        message: 'Pay period updated successfully',
        pay_period: updatedPayPeriod
      });
    } catch (error) {
      console.error('Error updating pay period:', error);
      res.status(400).json({
        message: 'Failed to update pay period',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/pay-periods/:id/open - Open pay period
router.post('/:id/open',
  permissionAuth('payroll_manage_pay_periods'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      const success = await PayPeriod.open(db, req.params.id, req.user._id);

      if (!success) {
        return res.status(404).json({
          message: 'Pay period not found or cannot be opened'
        });
      }

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'open_pay_period',
        entity_type: 'pay_period',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          action: 'pay_period_opened'
        },
        severity: 'high',
        category: 'workflow'
      });

      const payPeriod = await PayPeriod.findById(db, req.params.id);

      res.json({
        message: 'Pay period opened successfully',
        pay_period: payPeriod
      });
    } catch (error) {
      console.error('Error opening pay period:', error);
      res.status(500).json({
        message: 'Failed to open pay period',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/pay-periods/:id/start-processing - Start processing pay period
router.post('/:id/start-processing',
  permissionAuth('payroll_process'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      const success = await PayPeriod.startProcessing(db, req.params.id, req.user._id);

      if (!success) {
        return res.status(404).json({
          message: 'Pay period not found or cannot be processed'
        });
      }

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'start_processing_pay_period',
        entity_type: 'pay_period',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          action: 'processing_started'
        },
        severity: 'high',
        category: 'workflow'
      });

      const payPeriod = await PayPeriod.findById(db, req.params.id);

      res.json({
        message: 'Pay period processing started successfully',
        pay_period: payPeriod
      });
    } catch (error) {
      console.error('Error starting pay period processing:', error);
      res.status(500).json({
        message: 'Failed to start pay period processing',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/pay-periods/:id/close - Close pay period
router.post('/:id/close',
  permissionAuth('payroll_process'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      const success = await PayPeriod.close(db, req.params.id, req.user._id);

      if (!success) {
        return res.status(404).json({
          message: 'Pay period not found or cannot be closed'
        });
      }

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'close_pay_period',
        entity_type: 'pay_period',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          action: 'pay_period_closed'
        },
        severity: 'high',
        category: 'workflow'
      });

      const payPeriod = await PayPeriod.findById(db, req.params.id);

      res.json({
        message: 'Pay period closed successfully',
        pay_period: payPeriod
      });
    } catch (error) {
      console.error('Error closing pay period:', error);
      res.status(500).json({
        message: 'Failed to close pay period',
        error: error.message
      });
    }
  }
);

// PUT /api/payroll/pay-periods/:id/totals - Update pay period totals
router.put('/:id/totals',
  permissionAuth('payroll_process'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      const success = await PayPeriod.updateTotals(db, req.params.id, req.body);

      if (!success) {
        return res.status(404).json({
          message: 'Pay period not found'
        });
      }

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'update_pay_period_totals',
        entity_type: 'pay_period',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          totals: req.body
        },
        severity: 'medium',
        category: 'data_modification'
      });

      const payPeriod = await PayPeriod.findById(db, req.params.id);

      res.json({
        message: 'Pay period totals updated successfully',
        pay_period: payPeriod
      });
    } catch (error) {
      console.error('Error updating pay period totals:', error);
      res.status(500).json({
        message: 'Failed to update pay period totals',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/pay-periods/:id/calculate-totals - Calculate pay period totals
router.post('/:id/calculate-totals',
  permissionAuth('payroll_process'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      const totals = await PayPeriod.calculateTotals(db, req.params.id);

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'calculate_pay_period_totals',
        entity_type: 'pay_period',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          calculated_totals: totals
        },
        severity: 'medium',
        category: 'calculation'
      });

      res.json({
        message: 'Pay period totals calculated successfully',
        totals: totals
      });
    } catch (error) {
      console.error('Error calculating pay period totals:', error);
      res.status(500).json({
        message: 'Failed to calculate pay period totals',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/pay-periods/statistics/:year - Get pay period statistics
router.get('/statistics/:year',
  permissionAuth(['payroll_view_pay_periods', 'payroll_manage_pay_periods']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const year = parseInt(req.params.year);
      
      const statistics = await PayPeriod.getStatistics(db, year);

      res.json({
        message: 'Pay period statistics retrieved successfully',
        year: year,
        statistics: statistics
      });
    } catch (error) {
      console.error('Error fetching pay period statistics:', error);
      res.status(500).json({
        message: 'Failed to retrieve pay period statistics',
        error: error.message
      });
    }
  }
);

// DELETE /api/payroll/pay-periods/:id - Delete pay period (draft only)
router.delete('/:id',
  permissionAuth('payroll_manage_pay_periods'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      const success = await PayPeriod.delete(db, req.params.id);

      if (!success) {
        return res.status(404).json({
          message: 'Pay period not found or cannot be deleted (only draft periods with no associated data can be deleted)'
        });
      }

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'delete_pay_period',
        entity_type: 'pay_period',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          action: 'pay_period_deleted'
        },
        severity: 'high',
        category: 'data_modification'
      });

      res.json({
        message: 'Pay period deleted successfully'
      });
    } catch (error) {
      console.error('Error deleting pay period:', error);
      res.status(500).json({
        message: 'Failed to delete pay period',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/pay-periods/:id/calculate - Calculate payroll for all employees in pay period
router.post('/:id/calculate',
  permissionAuth('payroll_process'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      // First verify the pay period exists and is in correct status
      const payPeriod = await PayPeriod.findById(db, req.params.id);
      
      if (!payPeriod) {
        return res.status(404).json({
          message: 'Pay period not found'
        });
      }

      // Check if pay period is in correct status for calculation
      if (!['open', 'processing'].includes(payPeriod.status)) {
        return res.status(400).json({
          message: `Cannot calculate payroll for pay period with status '${payPeriod.status}'. Pay period must be 'open' or 'processing'.`
        });
      }

      // Update status to processing if it's open
      if (payPeriod.status === 'open') {
        await PayPeriod.startProcessing(db, req.params.id, req.user._id);
      }

      // Import PayrollCalculation model to create batch calculations
      const PayrollCalculation = require('../../models/PayrollCalculation');
      
      // Create batch calculations for all employees in the pay period
      const calculationResult = await PayrollCalculation.createBatchCalculations(db, {
        pay_period_id: req.params.id,
        start_date: payPeriod.start_date,
        end_date: payPeriod.end_date,
        created_by: req.user._id
      });

      // Calculate and update pay period totals
      const totals = await PayPeriod.calculateTotals(db, req.params.id);
      
      // Update pay period status to 'calculated' and set calculation metadata
      await PayPeriod.update(db, req.params.id, {
        status: 'calculated',
        total_employees: totals.total_employees || 0,
        total_gross_pay: totals.total_gross_pay || 0,
        total_deductions: totals.total_deductions || 0,
        total_net_pay: totals.total_net_pay || 0,
        calculated_by: req.user._id,
        calculated_at: new Date(),
        updated_by: req.user._id
      });

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'calculate_payroll',
        entity_type: 'pay_period',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          employees_calculated: calculationResult.successful_calculations || 0,
          total_gross_pay: totals.total_gross_pay || 0,
          total_deductions: totals.total_deductions || 0,
          total_net_pay: totals.total_net_pay || 0,
          calculation_errors: calculationResult.errors || []
        },
        severity: 'high',
        category: 'calculation'
      });

      // Get updated pay period
      const updatedPayPeriod = await PayPeriod.findById(db, req.params.id);

      res.json({
        message: 'Payroll calculation completed successfully',
        pay_period: {
          _id: updatedPayPeriod._id,
          status: updatedPayPeriod.status,
          total_employees: updatedPayPeriod.total_employees,
          total_gross_pay: updatedPayPeriod.total_gross_pay,
          total_deductions: updatedPayPeriod.total_deductions,
          total_net_pay: updatedPayPeriod.total_net_pay,
          calculated_by: updatedPayPeriod.calculated_by,
          calculated_at: updatedPayPeriod.calculated_at
        },
        calculation_summary: {
          employees_processed: calculationResult.successful_calculations || 0,
          calculation_errors: calculationResult.errors || []
        }
      });
    } catch (error) {
      console.error('Error calculating payroll:', error);
      res.status(500).json({
        message: 'Failed to calculate payroll',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/pay-periods/:id/approve - Approve calculated pay period
router.post('/:id/approve',
  permissionAuth('payroll_process'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      // First verify the pay period exists and is in correct status
      const payPeriod = await PayPeriod.findById(db, req.params.id);
      
      if (!payPeriod) {
        return res.status(404).json({
          message: 'Pay period not found'
        });
      }

      // Check if pay period is in correct status for approval
      if (payPeriod.status !== 'calculated') {
        return res.status(400).json({
          message: `Cannot approve pay period with status '${payPeriod.status}'. Pay period must be 'calculated' first.`
        });
      }

      // Update pay period status to 'approved' and set approval metadata
      const success = await PayPeriod.update(db, req.params.id, {
        status: 'approved',
        approved_by: req.user._id,
        approved_at: new Date(),
        updated_by: req.user._id
      });

      if (!success) {
        return res.status(500).json({
          message: 'Failed to update pay period status'
        });
      }

      // Log audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'approve_payroll',
        entity_type: 'pay_period',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          period_name: payPeriod.period_name,
          total_employees: payPeriod.total_employees,
          total_gross_pay: payPeriod.total_gross_pay,
          total_net_pay: payPeriod.total_net_pay,
          approval_action: 'pay_period_approved'
        },
        severity: 'high',
        category: 'workflow'
      });

      // Get updated pay period
      const updatedPayPeriod = await PayPeriod.findById(db, req.params.id);

      res.json({
        message: 'Pay period approved successfully',
        pay_period: {
          _id: updatedPayPeriod._id,
          status: updatedPayPeriod.status,
          approved_by: updatedPayPeriod.approved_by,
          approved_at: updatedPayPeriod.approved_at,
          period_name: updatedPayPeriod.period_name,
          total_employees: updatedPayPeriod.total_employees,
          total_gross_pay: updatedPayPeriod.total_gross_pay,
          total_deductions: updatedPayPeriod.total_deductions,
          total_net_pay: updatedPayPeriod.total_net_pay
        }
      });
    } catch (error) {
      console.error('Error approving pay period:', error);
      res.status(500).json({
        message: 'Failed to approve pay period',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/pay-periods/:id/analytics - Get comprehensive analytics for pay period
router.get('/:id/analytics',
  permissionAuth(['payroll_view_pay_periods', 'payroll_manage_pay_periods']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const payPeriodId = req.params.id;
      
      // Verify pay period exists
      const payPeriod = await PayPeriod.findById(db, payPeriodId);
      if (!payPeriod) {
        return res.status(404).json({
          message: 'Pay period not found'
        });
      }

      // Get all calculations for this pay period
      const calculations = await db.collection('payroll_calculations').aggregate([
        { $match: { pay_period_id: new ObjectId(payPeriodId) } },
        {
          $lookup: {
            from: 'users',
            localField: 'employee_id',
            foreignField: '_id',
            as: 'employee'
          }
        },
        { $unwind: '$employee' }
      ]).toArray();

      // Get timesheets for the period
      const timesheets = await db.collection('timesheets').aggregate([
        {
          $match: {
            work_date: {
              $gte: new Date(payPeriod.start_date),
              $lte: new Date(payPeriod.end_date)
            }
          }
        },
        {
          $lookup: {
            from: 'users',
            localField: 'employee_id',
            foreignField: '_id',
            as: 'employee'
          }
        },
        { $unwind: '$employee' }
      ]).toArray();

      // Department/Branch breakdown
      const departmentBreakdown = {};
      const branchBreakdown = {};
      
      calculations.forEach(calc => {
        const dept = calc.employee.department || 'Unknown';
        const branch = calc.employee.branch?.branch_name || 'Unknown';
        
        if (!departmentBreakdown[dept]) {
          departmentBreakdown[dept] = { employees: 0, total_gross: 0, total_net: 0 };
        }
        if (!branchBreakdown[branch]) {
          branchBreakdown[branch] = { employees: 0, total_gross: 0, total_net: 0 };
        }
        
        departmentBreakdown[dept].employees++;
        departmentBreakdown[dept].total_gross += calc.gross_pay || 0;
        departmentBreakdown[dept].total_net += calc.net_pay || 0;
        
        branchBreakdown[branch].employees++;
        branchBreakdown[branch].total_gross += calc.gross_pay || 0;
        branchBreakdown[branch].total_net += calc.net_pay || 0;
      });

      // Overtime statistics
      const overtimeStats = {
        total_overtime_hours: calculations.reduce((sum, calc) => sum + (calc.overtime_hours || 0), 0),
        employees_with_overtime: calculations.filter(calc => (calc.overtime_hours || 0) > 0).length,
        average_overtime_per_employee: 0,
        total_overtime_pay: calculations.reduce((sum, calc) => sum + (calc.overtime_pay || 0), 0)
      };
      
      if (overtimeStats.employees_with_overtime > 0) {
        overtimeStats.average_overtime_per_employee = overtimeStats.total_overtime_hours / overtimeStats.employees_with_overtime;
      }

      // Deduction analysis
      const deductionAnalysis = {};
      calculations.forEach(calc => {
        if (calc.deductions && Array.isArray(calc.deductions)) {
          calc.deductions.forEach(ded => {
            const name = ded.deduction_name || 'Unknown';
            if (!deductionAnalysis[name]) {
              deductionAnalysis[name] = { total_amount: 0, employee_count: 0 };
            }
            deductionAnalysis[name].total_amount += ded.amount || 0;
            deductionAnalysis[name].employee_count++;
          });
        }
      });

      // Get previous pay period for comparison
      const previousPeriods = await PayPeriod.find(db, {
        year: payPeriod.year,
        end_date: { $lt: payPeriod.start_date }
      }, { limit: 1, sort: { end_date: -1 } });
      
      let comparison = null;
      if (previousPeriods.length > 0) {
        const prevPeriod = previousPeriods[0];
        comparison = {
          previous_period_id: prevPeriod._id,
          previous_period_name: prevPeriod.period_name,
          gross_pay_change: ((payPeriod.total_gross_pay || 0) - (prevPeriod.total_gross_pay || 0)),
          employee_count_change: ((payPeriod.total_employees || 0) - (prevPeriod.total_employees || 0)),
          net_pay_change: ((payPeriod.total_net_pay || 0) - (prevPeriod.total_net_pay || 0))
        };
      }

      res.json({
        message: 'Pay period analytics retrieved successfully',
        analytics: {
          pay_period: {
            _id: payPeriod._id,
            period_name: payPeriod.period_name,
            status: payPeriod.status,
            start_date: payPeriod.start_date,
            end_date: payPeriod.end_date
          },
          department_breakdown: departmentBreakdown,
          branch_breakdown: branchBreakdown,
          overtime_statistics: overtimeStats,
          deduction_analysis: deductionAnalysis,
          comparison_with_previous: comparison,
          summary: {
            total_employees: calculations.length,
            total_timesheets: timesheets.length,
            average_gross_pay: calculations.length > 0 ? calculations.reduce((sum, calc) => sum + (calc.gross_pay || 0), 0) / calculations.length : 0,
            average_net_pay: calculations.length > 0 ? calculations.reduce((sum, calc) => sum + (calc.net_pay || 0), 0) / calculations.length : 0
          }
        }
      });
    } catch (error) {
      console.error('Error fetching pay period analytics:', error);
      res.status(500).json({
        message: 'Failed to retrieve pay period analytics',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/pay-periods/:id/missing-timesheets - Get employees missing timesheets
router.get('/:id/missing-timesheets',
  permissionAuth(['payroll_view_pay_periods', 'payroll_manage_pay_periods']),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const payPeriodId = req.params.id;
      
      // Verify pay period exists
      const payPeriod = await PayPeriod.findById(db, payPeriodId);
      if (!payPeriod) {
        return res.status(404).json({
          message: 'Pay period not found'
        });
      }

      // Get all active employees
      const allEmployees = await db.collection('users').find({
        'payroll_info.payroll_eligible': true,
        status: 'active'
      }).toArray();

      // Get employees who have submitted timesheets for this period
      const employeesWithTimesheets = await db.collection('timesheets').distinct('employee_id', {
        work_date: {
          $gte: new Date(payPeriod.start_date),
          $lte: new Date(payPeriod.end_date)
        }
      });

      // Find employees missing timesheets
      const missingTimesheets = allEmployees.filter(emp => 
        !employeesWithTimesheets.some(tsEmpId => tsEmpId.toString() === emp._id.toString())
      );

      // Get additional info for missing employees
      const missingEmployeesDetails = missingTimesheets.map(emp => ({
        employee_id: emp._id,
        name: `${emp.first_name} ${emp.last_name}`,
        email: emp.email,
        department: emp.department || 'Unknown',
        branch: emp.branch?.branch_name || 'Unknown',
        phone: emp.phone || null,
        last_timesheet_date: null // Could be enhanced to show last submitted timesheet
      }));

      // Calculate timesheet completion statistics
      const stats = {
        total_eligible_employees: allEmployees.length,
        employees_with_timesheets: employeesWithTimesheets.length,
        employees_missing_timesheets: missingTimesheets.length,
        completion_percentage: allEmployees.length > 0 ? 
          Math.round((employeesWithTimesheets.length / allEmployees.length) * 100) : 0
      };

      res.json({
        message: 'Missing timesheets report generated successfully',
        pay_period: {
          _id: payPeriod._id,
          period_name: payPeriod.period_name,
          start_date: payPeriod.start_date,
          end_date: payPeriod.end_date,
          status: payPeriod.status
        },
        statistics: stats,
        missing_employees: missingEmployeesDetails
      });
    } catch (error) {
      console.error('Error generating missing timesheets report:', error);
      res.status(500).json({
        message: 'Failed to generate missing timesheets report',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/pay-periods/:id/bulk-approve-calculations - Bulk approve all calculations
router.post('/:id/bulk-approve-calculations',
  permissionAuth('payroll_process'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const payPeriodId = req.params.id;
      const { calculation_ids } = req.body; // Optional: specific calculation IDs to approve
      
      // Verify pay period exists
      const payPeriod = await PayPeriod.findById(db, payPeriodId);
      if (!payPeriod) {
        return res.status(404).json({
          message: 'Pay period not found'
        });
      }

      // Build filter criteria
      const filter = { 
        pay_period_id: new ObjectId(payPeriodId),
        status: 'calculated'
      };
      
      // If specific calculation IDs provided, filter by those
      if (calculation_ids && Array.isArray(calculation_ids)) {
        filter._id = { $in: calculation_ids.map(id => new ObjectId(id)) };
      }

      // Get calculations to approve
      const calculationsToApprove = await db.collection('payroll_calculations').find(filter).toArray();
      
      if (calculationsToApprove.length === 0) {
        return res.status(400).json({
          message: 'No calculations found in calculated status for approval'
        });
      }

      // Bulk approve calculations
      const approvalDate = new Date();
      const result = await db.collection('payroll_calculations').updateMany(
        filter,
        {
          $set: {
            status: 'approved',
            approved_by: req.user._id,
            approved_at: approvalDate,
            updated_at: approvalDate
          }
        }
      );

      // Log audit trail for bulk approval
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'bulk_approve_calculations',
        entity_type: 'pay_period',
        entity_id: payPeriodId,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          calculations_approved: result.modifiedCount,
          calculation_ids: calculationsToApprove.map(calc => calc._id),
          period_name: payPeriod.period_name
        },
        severity: 'high',
        category: 'workflow'
      });

      res.json({
        message: `Successfully approved ${result.modifiedCount} calculations`,
        bulk_approval: {
          calculations_approved: result.modifiedCount,
          calculations_requested: calculationsToApprove.length,
          approved_at: approvalDate,
          approved_by: req.user._id
        }
      });
    } catch (error) {
      console.error('Error in bulk approve calculations:', error);
      res.status(500).json({
        message: 'Failed to bulk approve calculations',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/pay-periods/:id/bulk-recalculate - Bulk recalculate all calculations
router.post('/:id/bulk-recalculate',
  permissionAuth('payroll_process'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const payPeriodId = req.params.id;
      const { calculation_ids, reason } = req.body; // Optional: specific calculation IDs and reason
      
      // Verify pay period exists
      const payPeriod = await PayPeriod.findById(db, payPeriodId);
      if (!payPeriod) {
        return res.status(404).json({
          message: 'Pay period not found'
        });
      }

      // Build filter criteria for calculations to recalculate
      const filter = { 
        pay_period_id: new ObjectId(payPeriodId),
        status: { $in: ['calculated', 'approved'] } // Can recalculate both calculated and approved
      };
      
      // If specific calculation IDs provided, filter by those
      if (calculation_ids && Array.isArray(calculation_ids)) {
        filter._id = { $in: calculation_ids.map(id => new ObjectId(id)) };
      }

      // Get calculations to recalculate
      const calculationsToRecalculate = await db.collection('payroll_calculations').find(filter).toArray();
      
      if (calculationsToRecalculate.length === 0) {
        return res.status(400).json({
          message: 'No calculations found for recalculation'
        });
      }

      const results = {
        successful_recalculations: 0,
        failed_recalculations: 0,
        errors: []
      };

      // Recalculate each calculation
      const PayrollCalculation = require('../../models/PayrollCalculation');
      
      for (const calculation of calculationsToRecalculate) {
        try {
          const success = await PayrollCalculation.recalculate(
            db, 
            calculation._id.toString(), 
            req.user._id
          );
          
          if (success) {
            results.successful_recalculations++;
          } else {
            results.failed_recalculations++;
            results.errors.push({
              calculation_id: calculation._id,
              employee_id: calculation.employee_id,
              error: 'Recalculation failed'
            });
          }
        } catch (error) {
          results.failed_recalculations++;
          results.errors.push({
            calculation_id: calculation._id,
            employee_id: calculation.employee_id,
            error: error.message
          });
        }
      }

      // Recalculate pay period totals after individual recalculations
      await PayPeriod.calculateTotals(db, payPeriodId);

      // Log audit trail for bulk recalculation
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'bulk_recalculate_calculations',
        entity_type: 'pay_period',
        entity_id: payPeriodId,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          calculations_processed: calculationsToRecalculate.length,
          successful_recalculations: results.successful_recalculations,
          failed_recalculations: results.failed_recalculations,
          reason: reason || 'Bulk recalculation requested',
          period_name: payPeriod.period_name
        },
        severity: 'high',
        category: 'calculation'
      });

      res.json({
        message: `Bulk recalculation completed. ${results.successful_recalculations} successful, ${results.failed_recalculations} failed`,
        bulk_recalculation: {
          ...results,
          total_calculations: calculationsToRecalculate.length,
          recalculated_at: new Date(),
          recalculated_by: req.user._id,
          reason: reason || 'Bulk recalculation requested'
        }
      });
    } catch (error) {
      console.error('Error in bulk recalculate:', error);
      res.status(500).json({
        message: 'Failed to bulk recalculate calculations',
        error: error.message
      });
    }
  }
);

module.exports = router;