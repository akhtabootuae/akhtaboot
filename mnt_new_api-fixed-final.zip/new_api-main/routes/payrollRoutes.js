const express = require('express');
const { ObjectId } = require('mongodb');
const User = require('../models/User');
const PayrollAuditLog = require('../models/PayrollAuditLog');
const permissionAuth = require('../middleware/permissionAuth');
const payrollAudit = require('../middleware/payrollAudit');

// Import deduction routes
const deductionRoutes = require('./payroll');

const router = express.Router();

// GET /api/payroll/employees - Get all payroll-eligible employees with monthly salaries
router.get('/employees', 
  permissionAuth('payroll_view'),
  payrollAudit('view_payroll', 'payroll_system'),
  async (req, res) => {
    try {
      const { page = 1, limit = 20, branch_id, active_only = 'true' } = req.query;
      
      // Build filter criteria
      const filter = {
        'payroll_info.payroll_eligible': true
      };
      
      if (branch_id) {
        filter['branch.branch_id'] = new ObjectId(branch_id);
      }
      
      if (active_only === 'true') {
        filter.is_active = true;
      }
      
      // Get payroll eligible employees
      const employees = await req.app.locals.db.collection('users')
        .find(filter, {
          projection: {
            _id: 1,
            email: 1,
            first_name: 1,
            last_name: 1,
            branch: 1,
            payroll_info: 1
          }
        })
        .sort({ last_name: 1, first_name: 1 })
        .skip((parseInt(page) - 1) * parseInt(limit))
        .limit(parseInt(limit))
        .toArray();
      
      // Count total eligible employees
      const total = await req.app.locals.db.collection('users').countDocuments(filter);
      
      res.json({
        employees: employees,
        pagination: {
          current_page: parseInt(page),
          total_pages: Math.ceil(total / limit),
          total_employees: total,
          per_page: parseInt(limit)
        }
      });
    } catch (error) {
      console.error('Error fetching payroll employees:', error);
      res.status(500).json({ message: 'Internal server error', error: error.message });
    }
  }
);


// PUT /api/payroll/employees/:id/salary - Update employee monthly salary
router.put('/employees/:id/salary',
  permissionAuth('payroll_manage_rates'),
  payrollAudit('update_salary', 'payroll_salary'),
  async (req, res) => {
    try {
      const { id } = req.params;
      const { monthly_salary, reason } = req.body;
      
      // Validate input
      if (!monthly_salary || monthly_salary <= 0) {
        return res.status(400).json({ message: 'Valid monthly salary is required' });
      }
      
      // Check if user is properly authenticated
      if (!req.user || !req.user._id) {
        return res.status(401).json({ 
          message: 'Authentication required' 
        });
      }
      
      // Verify employee exists and is payroll eligible
      const employee = await req.app.locals.db.collection('users').findOne({ 
        _id: new ObjectId(id),
        'payroll_info.payroll_eligible': true 
      });
      
      if (!employee) {
        return res.status(404).json({ 
          message: 'Payroll-eligible employee not found' 
        });
      }
      
      const oldSalary = employee.payroll_info?.monthly_salary || 0;
      
      // Update employee's monthly salary
      await req.app.locals.db.collection('users').updateOne(
        { _id: new ObjectId(id) },
        {
          $set: {
            'payroll_info.monthly_salary': parseFloat(monthly_salary),
            'payroll_info.last_rate_update': new Date(),
            'payroll_info.updated_by': req.user.email,
            updated_at: new Date()
          }
        }
      );
      
      // Create audit log
      await PayrollAuditLog.createAuditEntry(req.app.locals.db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'update_salary',
        entity_type: 'payroll_salary',
        entity_id: id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          old_values: { monthly_salary: oldSalary },
          new_values: { monthly_salary: parseFloat(monthly_salary) },
          request_method: req.method,
          endpoint: req.originalUrl,
          success: true,
          reason: reason
        },
        severity: 'medium',
        category: 'data_modification'
      });
      
      res.json({ 
        message: 'Employee salary updated successfully',
        employee_id: id,
        old_salary: oldSalary,
        new_salary: parseFloat(monthly_salary),
        updated_by: req.user.email
      });
      
    } catch (error) {
      console.error('Error updating employee salary:', error);
      res.status(500).json({ message: 'Internal server error', error: error.message });
    }
  }
);

// PUT /api/payroll/employees/:id/rate - Update employee daily rate
router.put('/employees/:id/rate',
  permissionAuth('payroll_manage_rates'),
  payrollAudit('update_rate', 'payroll_rate'),
  async (req, res) => {
    try {
      const { id } = req.params;
      const { daily_rate, reason } = req.body;
      
      // Validate input
      if (!daily_rate || daily_rate <= 0) {
        return res.status(400).json({ message: 'Valid daily rate is required' });
      }
      
      // Check if user is properly authenticated
      if (!req.user || !req.user._id) {
        return res.status(401).json({ 
          message: 'Authentication required' 
        });
      }
      
      // Verify employee exists and is payroll eligible
      const employee = await req.app.locals.db.collection('users').findOne({ 
        _id: new ObjectId(id),
        'payroll_info.payroll_eligible': true 
      });
      
      if (!employee) {
        return res.status(404).json({ 
          message: 'Payroll-eligible employee not found' 
        });
      }
      
      const oldRate = employee.payroll_info?.daily_rate || 0;
      
      // Update employee's daily rate
      await req.app.locals.db.collection('users').updateOne(
        { _id: new ObjectId(id) },
        {
          $set: {
            'payroll_info.daily_rate': parseFloat(daily_rate),
            'payroll_info.last_rate_update': new Date(),
            'payroll_info.updated_by': req.user.email,
            updated_at: new Date()
          }
        }
      );
      
      // Create audit log
      await PayrollAuditLog.createAuditEntry(req.app.locals.db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'update_rate',
        entity_type: 'payroll_rate',
        entity_id: id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          old_values: { daily_rate: oldRate },
          new_values: { daily_rate: parseFloat(daily_rate) },
          request_method: req.method,
          endpoint: req.originalUrl,
          success: true,
          reason: reason
        },
        severity: 'medium',
        category: 'data_modification'
      });
      
      res.json({ 
        message: 'Employee daily rate updated successfully',
        employee_id: id,
        old_rate: oldRate,
        new_rate: parseFloat(daily_rate),
        updated_by: req.user.email
      });
      
    } catch (error) {
      console.error('Error updating employee daily rate:', error);
      res.status(500).json({ message: 'Internal server error', error: error.message });
    }
  }
);

// GET /api/payroll/employees/:id/salary - Get employee salary information
router.get('/employees/:id/salary',
  permissionAuth('payroll_view'),
  payrollAudit('view_payroll', 'payroll_salary'),
  async (req, res) => {
    try {
      const { id } = req.params;
      
      // Verify employee exists and is payroll eligible
      const employee = await req.app.locals.db.collection('users').findOne({ 
        _id: new ObjectId(id),
        'payroll_info.payroll_eligible': true 
      }, { projection: { _id: 1, email: 1, first_name: 1, last_name: 1, payroll_info: 1 } });
      
      if (!employee) {
        return res.status(404).json({ message: 'Payroll-eligible employee not found' });
      }
      
      res.json({
        employee: {
          _id: employee._id,
          email: employee.email,
          first_name: employee.first_name,
          last_name: employee.last_name
        },
        payroll_info: employee.payroll_info
      });
      
    } catch (error) {
      console.error('Error fetching employee salary:', error);
      res.status(500).json({ message: 'Internal server error', error: error.message });
    }
  }
);

// GET /api/payroll/employees/:id/rate - Get employee daily rate information
router.get('/employees/:id/rate',
  permissionAuth('payroll_view'),
  payrollAudit('view_payroll', 'payroll_rate'),
  async (req, res) => {
    try {
      const { id } = req.params;
      
      // Verify employee exists and is payroll eligible
      const employee = await req.app.locals.db.collection('users').findOne({ 
        _id: new ObjectId(id),
        'payroll_info.payroll_eligible': true 
      }, { projection: { _id: 1, email: 1, first_name: 1, last_name: 1, payroll_info: 1 } });
      
      if (!employee) {
        return res.status(404).json({ message: 'Payroll-eligible employee not found' });
      }
      
      res.json({
        employee: {
          _id: employee._id,
          email: employee.email,
          first_name: employee.first_name,
          last_name: employee.last_name
        },
        payroll_info: employee.payroll_info
      });
      
    } catch (error) {
      console.error('Error fetching employee daily rate:', error);
      res.status(500).json({ message: 'Internal server error', error: error.message });
    }
  }
);

// GET /api/payroll/audit-log - Get audit log entries (admin only)
router.get('/audit-log',
  permissionAuth('payroll_view'),
  async (req, res) => {
    try {
      // Additional admin check for audit logs
      if (req.user.role_name !== 'Admin') {
        return res.status(403).json({ message: 'Access denied: Admin role required for audit logs' });
      }
      
      const { page = 1, limit = 50, user_id, action, start_date, end_date } = req.query;
      
      // Build filter criteria
      const filters = {};
      
      if (user_id) {
        filters.user_id = user_id;
      }
      
      if (action) {
        filters.action = action;
      }
      
      if (start_date) {
        filters.start_date = start_date;
      }
      
      if (end_date) {
        filters.end_date = end_date;
      }
      
      // Use PayrollAuditLog model to get audit entries
      const auditEntries = await PayrollAuditLog.findAuditLogs(
        req.app.locals.db,
        filters,
        { 
          limit: parseInt(limit), 
          skip: (parseInt(page) - 1) * parseInt(limit) 
        }
      );
      
      const total = await PayrollAuditLog.countAuditLogs(req.app.locals.db, filters);
      
      res.json({
        audit_entries: auditEntries,
        pagination: {
          current_page: parseInt(page),
          total_pages: Math.ceil(total / limit),
          total_entries: total,
          per_page: parseInt(limit)
        }
      });
      
    } catch (error) {
      console.error('Error fetching audit log:', error);
      res.status(500).json({ message: 'Internal server error', error: error.message });
    }
  }
);

// Mount deduction routes
router.use('/', deductionRoutes);

module.exports = router;