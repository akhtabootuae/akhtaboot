const express = require('express');
const router = express.Router();
const { ObjectId, Int32 } = require('mongodb');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { getDefaultPermissionsForRole } = require('../config/permissions');

// JWT Secret - must be set via environment variable
const JWT_SECRET = process.env.JWT_SECRET;
const JWT_EXPIRE = process.env.JWT_EXPIRE || '24h';

if (!JWT_SECRET) {
  console.error('FATAL: JWT_SECRET environment variable is not set. Authentication will fail.');
}

// Middleware
const auth = require('../middleware/auth');
const adminAuth = require('../middleware/adminAuth');
const permissionAuth = require('../middleware/permissionAuth');

/**
 * Helper function to format user name
 */
const formatUserName = (user) => {
  if (user.first_name && user.last_name) {
    return `${user.first_name} ${user.last_name}`;
  }
  return user.name || 'Unknown User';
};

/**
 * Helper function to sanitize user data (remove sensitive fields)
 */
const sanitizeUser = (user) => {
  const { password_hash, ...safeUser } = user;
  return safeUser;
};

/**
 * @route   GET /api/users
 * @desc    Get all users with optional role filtering
 * @access  Private
 */
router.get('/', auth, async (req, res) => {
  try {
    const { role, role_id } = req.query;
    const db = req.app.locals.db;
    
    let query = {};
    
    // Filter by role name
    if (role) {
      const roleDoc = await db.collection('roles').findOne({ role_name: role });
      if (roleDoc) {
        query.role_id = roleDoc._id;
      } else {
        return res.json([]); // Return empty array if role not found
      }
    }
    
    // Filter by role_id directly
    if (role_id) {
      query.role_id = new ObjectId(role_id);
    }
    
    const users = await db.collection('users').find(query).toArray();
    
    // Enhance users with role information
    const enhancedUsers = await Promise.all(users.map(async (user) => {
      let roleName = null;
      if (user.role_id) {
        const roleDoc = await db.collection('roles').findOne({ _id: user.role_id });
        roleName = roleDoc ? roleDoc.role_name : null;
      }
      
      return {
        _id: user._id,
        name: formatUserName(user),
        email: user.email,
        phone: user.phone || '',
        role: roleName || user.role_name,
        role_id: user.role_id,
        is_active: user.is_active !== undefined ? user.is_active : true,
        staff_code: user.staff_code || '',
        speciality: user.speciality || '',
        branch: user.branch || null,
        created_at: user.created_at,
        updated_at: user.updated_at
      };
    }));
    
    res.json(enhancedUsers);
  } catch (error) {
    console.error('Error fetching users:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

/**
 * @route   GET /api/users/technicians
 * @desc    Get all technicians specifically
 * @access  Private
 */
router.get('/technicians', auth, async (req, res) => {
  try {
    const db = req.app.locals.db;
    
    // Find the Technician role
    const techRole = await db.collection('roles').findOne({ role_name: 'Technician' });
    
    if (!techRole) {
      return res.json([]); // Return empty array if Technician role doesn't exist
    }
    
    const technicians = await db.collection('users').find({
      role_id: techRole._id,
      is_active: { $ne: false } // Only active technicians
    }).toArray();
    
    // Format for frontend use (compatible with registration system)
    const formattedTechnicians = technicians.map(tech => ({
      _id: tech._id,
      name: formatUserName(tech),
      email: tech.email,
      phone: tech.phone || '',
      role: 'Technician',
      user_id: tech._id, // For backward compatibility
      technician_name: formatUserName(tech), // For backward compatibility
      staff_code: tech.staff_code || '',
      speciality: tech.speciality || '',
      branch: tech.branch || null
    }));
    
    res.json(formattedTechnicians);
  } catch (error) {
    console.error('Error fetching technicians:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

/**
 * @route   GET /api/users/technicians/by-specialty
 * @desc    Get technicians by specialty with optional exclusion
 * @access  Private
 */
router.get('/technicians/by-specialty', auth, async (req, res) => {
  try {
    const { specialty, excludeId } = req.query;
    
    // Validate required specialty parameter
    if (!specialty) {
      return res.status(400).json({ message: 'Specialty parameter is required' });
    }
    
    const db = req.app.locals.db;
    
    // Find the Technician role
    const techRole = await db.collection('roles').findOne({ role_name: 'Technician' });
    
    if (!techRole) {
      return res.json([]); // Return empty array if Technician role doesn't exist
    }
    
    // Build query
    const query = {
      role_id: techRole._id,
      speciality: specialty,
      is_active: { $ne: false } // Only active technicians
    };
    
    // Exclude specific technician if excludeId is provided
    if (excludeId) {
      query._id = { $ne: new ObjectId(excludeId) };
    }
    
    const technicians = await db.collection('users').find(query).toArray();
    
    // Format response with only necessary fields
    const formattedTechnicians = technicians.map(tech => ({
      _id: tech._id,
      name: formatUserName(tech),
      email: tech.email,
      speciality: tech.speciality
    }));
    
    res.json(formattedTechnicians);
  } catch (error) {
    console.error('Error fetching technicians by specialty:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

/**
 * @route   GET /api/users/export
 * @desc    Export users data as CSV
 * @access  Users with export_users permission
 */
router.get('/export', permissionAuth('export_users'), async (req, res) => {
  try {
    const users = await req.app.locals.db.collection('users')
      .find({}, { projection: { password_hash: 0 } })
      .toArray();

    // Prepare CSV headers
    const fields = [
      'first_name', 'last_name', 'email', 'phone', 'is_active',
      'staff_code', 'speciality', 'role_name', 'branch_name'
    ];

    // Build CSV string
    const csvRows = [];
    csvRows.push(fields.join(','));

    users.forEach(user => {
      const row = [
        user.first_name || '',
        user.last_name || '',
        user.email || '',
        user.phone || '',
        user.is_active !== undefined ? user.is_active : true,
        user.staff_code || '',
        user.speciality || '',
        user.role_name || '',
        user.branch?.branch_name || ''
      ].map(val => `"${String(val).replace(/"/g, '""')}"`);
      csvRows.push(row.join(','));
    });

    const csvContent = csvRows.join('\n');

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="users_export_${Date.now()}.csv"`);
    res.send(csvContent);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   GET /api/users/:id
 * @desc    Get user by ID
 * @access  Private
 */
router.get('/:id', permissionAuth("view_users"), async (req, res) => {
  try {
    const db = req.app.locals.db;
    
    // Validate ObjectId format
    if (!ObjectId.isValid(req.params.id)) {
      return res.status(400).json({ message: 'Invalid user ID format' });
    }
    
    const user = await db.collection('users').findOne({
      _id: new ObjectId(req.params.id)
    });
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    // Get role information
    let roleName = null;
    if (user.role_id) {
      const roleDoc = await db.collection('roles').findOne({ _id: user.role_id });
      roleName = roleDoc ? roleDoc.role_name : null;
    }
    
    const userResponse = {
      _id: user._id,
      first_name: user.first_name || '',
      last_name: user.last_name || '',
      name: formatUserName(user),
      email: user.email,
      phone: user.phone || '',
      role: roleName || user.role_name,
      role_id: user.role_id,
      is_active: user.is_active !== undefined ? user.is_active : true,
      staff_code: user.staff_code || '',
      speciality: user.speciality || '',
      branch: user.branch || null,
      created_at: user.created_at,
      updated_at: user.updated_at
    };
    
    res.json(userResponse);
  } catch (error) {
    console.error('Error fetching user:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

/**
 * @route   GET /api/users/:id/workorders
 * @desc    Get all work orders for a specific user with pagination
 * @access  Admin or Self or users with view_workorders permission
 */
router.get('/:id/workorders', permissionAuth("view_work_order"), async (req, res) => {
  try {
    const userId = new ObjectId(req.params.id);
    const isSelf = req.user._id.toString() === req.params.id;
    const isAdmin = req.user.role_name === 'Admin';
    const hasViewWorkOrdersPermission = req.user.permissions?.some(p => p.permission_name === 'view_work_order');
    
    // Check access rights (permissionAuth middleware already handles permission check)
    if (!isAdmin && !isSelf && !hasViewWorkOrdersPermission) {
      return res.status(403).json({ message: 'Access denied' });
    }

    // Check if user exists
    const user = await req.app.locals.db.collection('users').findOne({ _id: userId });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Pagination parameters
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    // Build filters based on the work order schema
    const filters = { 
      $or: [
        // Work orders where user is assigned to any part
        { "parts.assignedTo": userId },
        // Work orders where user is assigned to any stage
        { "parts.stages.assignedTo": userId }
      ]
    };

    // Add status filter if provided
    if (req.query.status) {
      filters.status = req.query.status;
    }

    // Add date range filter if provided
    if (req.query.start_date || req.query.end_date) {
      filters.createdAt = {};
      if (req.query.start_date) {
        filters.createdAt.$gte = new Date(req.query.start_date);
      }
      if (req.query.end_date) {
        filters.createdAt.$lte = new Date(req.query.end_date);
      }
    }

    // Get total count for pagination
    const totalCount = await req.app.locals.db.collection('work_orders').countDocuments(filters);
    
    // Get work orders with pagination
    const workorders = await req.app.locals.db.collection('work_orders')
      .find(filters)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .toArray();

    // Calculate pagination info
    const totalPages = Math.ceil(totalCount / limit);
    const hasNextPage = page < totalPages;
    const hasPrevPage = page > 1;

    res.json({
      workorders,
      pagination: {
        current_page: page,
        total_pages: totalPages,
        total_count: totalCount,
        per_page: limit,
        has_next_page: hasNextPage,
        has_prev_page: hasPrevPage,
        next_page: hasNextPage ? page + 1 : null,
        prev_page: hasPrevPage ? page - 1 : null
      },
      user: {
        id: user._id,
        name: `${user.first_name} ${user.last_name}`,
        email: user.email
      }
    });
  } catch (err) {
    console.error('Error fetching user workorders:', err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   PUT /api/users/:id/activate
 * @desc    Activate or deactivate a user
 * @access  Admin or user with manage_user_status permission
 */
router.put('/:id/activate', permissionAuth('manage_user_status'), async (req, res) => {
  try {
    const userId = new ObjectId(req.params.id);
    const { is_active } = req.body;
    
    if (typeof is_active !== 'boolean') {
      return res.status(400).json({ message: 'is_active field must be a boolean' });
    }

    // Get the user being modified
    const userToModify = await req.app.locals.db.collection('users').findOne({ _id: userId });
    if (!userToModify) {
      return res.status(404).json({ message: 'User not found' });
    }

    // If trying to deactivate an admin, check if they're the last active admin
    if (is_active === false && userToModify.role_name === 'Admin') {
      const activeAdminCount = await req.app.locals.db.collection('users').countDocuments({
        role_name: 'Admin',
        is_active: true
      });

      if (activeAdminCount <= 1) {
        return res.status(400).json({ 
          message: 'Cannot deactivate the last active admin. There must be at least one active admin in the system.' 
        });
      }
    }
    
    const result = await req.app.locals.db.collection('users').updateOne(
      { _id: userId },
      { 
        $set: { 
          is_active: is_active,
          updated_at: new Date()
        }
      }
    );

    if (result.matchedCount === 0) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({ 
      message: `User ${is_active ? 'activated' : 'deactivated'} successfully` 
    });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   POST /api/users
 * @desc    Create a new user
 * @access  Admin or users with create_user permission
 */
router.post('/', permissionAuth('create_user'), async (req, res) => {
  try {
    const { 
      first_name, last_name, email, phone, password, 
      is_active, staff_code, speciality, role, branch
    } = req.body;

    // Validate required fields
    if (!first_name || !last_name || !email || !password || !role) {
      return res.status(400).json({ message: 'Missing required fields: first_name, last_name, email, password, role' });
    }

    // Check if email already exists
    const existingUser = await req.app.locals.db.collection('users').findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'Email already registered' });
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const password_hash = await bcrypt.hash(password, salt);

    // Get role from roles collection
    let roleFromDb;
    if (typeof role === 'object') {
      if (role.role_id) {
        roleFromDb = await req.app.locals.db.collection('roles').findOne({ 
          _id: new ObjectId(role.role_id) 
        });
      } else if (role.role_name) {
        roleFromDb = await req.app.locals.db.collection('roles').findOne({ 
          role_name: role.role_name 
        });
      }
    } else if (typeof role === 'string') {
      // Treat as role name
      roleFromDb = await req.app.locals.db.collection('roles').findOne({ 
        role_name: role 
      });
    }
    
    if (!roleFromDb) {
      return res.status(400).json({ message: 'Invalid role. Role not found in the database.' });
    }
    
    // Get branch from branches collection
    let branchFromDb = null;
    if (branch) {
      if (typeof branch === 'object') {
        if (branch.branch_id) {
          branchFromDb = await req.app.locals.db.collection('branches').findOne({
            _id: new ObjectId(branch.branch_id)
          });
        } else if (branch.branch_code) {
          branchFromDb = await req.app.locals.db.collection('branches').findOne({
            branch_code: branch.branch_code
          });
        } else if (branch.branch_name) {
          branchFromDb = await req.app.locals.db.collection('branches').findOne({
            branch_name: branch.branch_name
          });
        }
      } else if (typeof branch === 'string') {
        // Try to find by code first, then by name
        branchFromDb = await req.app.locals.db.collection('branches').findOne({
          branch_code: branch
        });
        if (!branchFromDb) {
          branchFromDb = await req.app.locals.db.collection('branches').findOne({
            branch_name: branch
          });
        }
      }
    }
    
    // Default to Main Branch (HQ) if no valid branch provided or found
    if (!branchFromDb) {
      branchFromDb = await req.app.locals.db.collection('branches').findOne({
        branch_code: "HQ"
      });
      
      if (!branchFromDb) {
        // Try to find any branch as fallback
        branchFromDb = await req.app.locals.db.collection('branches').findOne({});
      }
    }

    // Get default permissions for the role
    const defaultPermissions = getDefaultPermissionsForRole(roleFromDb.role_name);

    const newUser = {
      first_name,
      last_name,
      name: `${first_name} ${last_name}`,
      email,
      phone: phone || "",
      password_hash,
      is_active: is_active !== undefined ? is_active : true,
      staff_code: staff_code || "",
      speciality: speciality || "",
      branch: branchFromDb ? {
        branch_id: branchFromDb._id,
        branch_name: branchFromDb.branch_name,
        branch_code: branchFromDb.branch_code,
        location: branchFromDb.location || ""
      } : null,
      role_id: roleFromDb._id,
      role_name: roleFromDb.role_name,
      role_description: roleFromDb.description || '',
      permissions: defaultPermissions,
      permission_logs: [],
      created_at: new Date(),
      updated_at: new Date()
    };

    const result = await req.app.locals.db.collection('users').insertOne(newUser);
    
    res.status(201).json({
      message: 'User created successfully',
      userId: result.insertedId,
      user: {
        _id: result.insertedId,
        name: newUser.name,
        email: newUser.email,
        role: newUser.role_name,
        branch: newUser.branch
      }
    });
  } catch (err) {
    console.error('Error creating user:', err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   PUT /api/users/:id
 * @desc    Update a user
 * @access  Admin or Self or users with update_user permission
 */
router.put('/:id', permissionAuth("update_user"), async (req, res) => {
  try {
    const userId = new ObjectId(req.params.id);
    const isSelf = req.user.id?.toString() === req.params.id || req.user._id?.toString() === req.params.id;
    const isAdmin = req.user.role === 'Admin' || req.user.role_name === 'Admin';
    
    // Check if user has update_user permission (simplified check)
    const hasUpdatePermission = isAdmin; // Simplify for now
    
    // Check access rights
    if (!isAdmin && !isSelf && !hasUpdatePermission) {
      return res.status(403).json({ message: 'Access denied' });
    }

    const updateData = { updated_at: new Date() };
    
    // Fields that any user can update for themselves
    const selfFields = ['first_name', 'last_name', 'phone'];
    
    // Fields that require special permission
    const restrictedFields = ['is_active', 'staff_code', 'speciality', 'role', 'branch'];
    
    if (isSelf) {
      // User can only update their own basic info
      selfFields.forEach(field => {
        if (req.body[field] !== undefined) {
          updateData[field] = req.body[field];
        }
      });
    } else if (isAdmin || hasUpdatePermission) {
      // Admin or users with update permission can update all fields
      [...selfFields, ...restrictedFields].forEach(field => {
        if (req.body[field] !== undefined && field !== 'role' && field !== 'branch') {
          updateData[field] = req.body[field];
        }
      });
    }
    
    // Handle password update separately with hashing
    if (req.body.password && (isSelf || isAdmin)) {
      const salt = await bcrypt.genSalt(10);
      updateData.password_hash = await bcrypt.hash(req.body.password, salt);
    }

    // Process role update if admin
    if (isAdmin && req.body.role) {
      let roleFromDb;
      const role = req.body.role;
      
      if (typeof role === 'object') {
        if (role.role_id) {
          roleFromDb = await req.app.locals.db.collection('roles').findOne({ 
            _id: new ObjectId(role.role_id) 
          });
        } else if (role.role_name) {
          roleFromDb = await req.app.locals.db.collection('roles').findOne({ 
            role_name: role.role_name 
          });
        }
      } else if (typeof role === 'string') {
        roleFromDb = await req.app.locals.db.collection('roles').findOne({ 
          role_name: role 
        });
      }
      
      if (roleFromDb) {
        updateData.role_id = roleFromDb._id;
        updateData.role_name = roleFromDb.role_name;
        updateData.role_description = roleFromDb.description || '';
      }
    }

    // Process branch update if admin
    if (isAdmin && req.body.branch) {
      let branchFromDb = null;
      const branch = req.body.branch;
      
      if (typeof branch === 'object') {
        if (branch.branch_id) {
          branchFromDb = await req.app.locals.db.collection('branches').findOne({
            _id: new ObjectId(branch.branch_id)
          });
        } else if (branch.branch_code) {
          branchFromDb = await req.app.locals.db.collection('branches').findOne({
            branch_code: branch.branch_code
          });
        } else if (branch.branch_name) {
          branchFromDb = await req.app.locals.db.collection('branches').findOne({
            branch_name: branch.branch_name
          });
        }
      } else if (typeof branch === 'string') {
        branchFromDb = await req.app.locals.db.collection('branches').findOne({
          branch_code: branch
        });
        if (!branchFromDb) {
          branchFromDb = await req.app.locals.db.collection('branches').findOne({
            branch_name: branch
          });
        }
      }
      
      if (branchFromDb) {
        updateData.branch = {
          branch_id: branchFromDb._id,
          branch_name: branchFromDb.branch_name,
          branch_code: branchFromDb.branch_code,
          location: branchFromDb.location || ""
        };
      }
    }

    // Update name field if first_name or last_name is being updated
    if (updateData.first_name || updateData.last_name) {
      const currentUser = await req.app.locals.db.collection('users').findOne({ _id: userId });
      const firstName = updateData.first_name || currentUser.first_name;
      const lastName = updateData.last_name || currentUser.last_name;
      updateData.name = `${firstName} ${lastName}`;
    }

    const result = await req.app.locals.db.collection('users').updateOne(
      { _id: userId },
      { $set: updateData }
    );

    if (result.matchedCount === 0) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({ message: 'User updated successfully' });
  } catch (err) {
    console.error('Error updating user:', err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   DELETE /api/users/:id
 * @desc    Delete a user
 * @access  Admin or users with delete_user permission
 */
router.delete('/:id', permissionAuth('delete_user'), async (req, res) => {
  try {
    const result = await req.app.locals.db.collection('users').deleteOne({ 
      _id: new ObjectId(req.params.id) 
    });

    if (result.deletedCount === 0) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({ message: 'User deleted successfully' });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   PUT /api/users/:id/permissions
 * @desc    Update user permissions (toggle granted status)
 * @access  Admin or users with manage_permissions permission
 * Hacve to add perm log when updated */
router.put('/:id/permissions', permissionAuth('manage_permissions'), async (req, res) => {
  try {
    const userId = new ObjectId(req.params.id);
    const { permissions } = req.body;

    if (!Array.isArray(permissions)) {
      return res.status(400).json({ message: 'Permissions must be an array' });
    }

    // Get current user from database
    const user = await req.app.locals.db.collection('users').findOne({ _id: userId });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Ensure user has existing permissions array
    if (!user.permissions || !Array.isArray(user.permissions)) {
      return res.status(400).json({ message: 'User does not have a valid permissions array' });
    }

    // Ensure req.user exists for logging
    if (!req.user || !req.user.first_name || !req.user.last_name) {
      return res.status(401).json({ message: 'Invalid user session' });
    }

    // Helper function to generate unique log ID
    const generateUniqueLogId = (existingLogs) => {
      let logId;
      let attempts = 0;
      const maxAttempts = 10;
      
      do {
        logId = `${Date.now()}-${Math.floor(Math.random() * 1000000)}`;
        attempts++;
        
        if (attempts >= maxAttempts) {
          // Fallback with timestamp + counter if random fails
          logId = `${Date.now()}-${attempts}-${Math.floor(Math.random() * 100000)}`;
          break;
        }
      } while (existingLogs.some(log => log.log_id === logId));
      
      return logId;
    };

    // Create logs for permission changes
    const permissionLogs = [];
    const currentTime = new Date();
    const updateOperations = [];
    
    // Get existing permission logs to ensure uniqueness
    const existingLogs = user.permission_logs || [];
    
    // Process each permission update
    for (const permissionUpdate of permissions) {
      // Validate the permission update structure
      if (!permissionUpdate.permission_name || typeof permissionUpdate.granted !== 'boolean') {
        throw new Error('Each permission must have permission_name and a boolean granted field');
      }

      // Find the existing permission in user's permissions array
      const existingPerm = user.permissions.find(p => 
        p.permission_name === permissionUpdate.permission_name
      );
      
      if (!existingPerm) {
        throw new Error(`Permission '${permissionUpdate.permission_name}' not found in user's permissions`);
      }

      // If permission state changed, add to logs and prepare update
      if (existingPerm.granted !== permissionUpdate.granted) {
        // Generate unique log ID
        const allLogs = [...existingLogs, ...permissionLogs]; // Include both existing and new logs
        const uniqueLogId = generateUniqueLogId(allLogs);
        
        // Add to permission logs
        permissionLogs.push({
          log_id: uniqueLogId,
          target_type: "user",
          target_id: user._id,
          permission_id: existingPerm.permission_id || permissionUpdate.permission_name, // Use permission_id from existing permission
          action: permissionUpdate.granted ? "grant" : "revoke",
          created_at: currentTime,
          details: `Permission '${permissionUpdate.permission_name}' ${permissionUpdate.granted ? 'granted' : 'revoked'} by ${req.user.first_name} ${req.user.last_name}`
        });

        // Add update operation for this permission
        updateOperations.push({
          permission_name: permissionUpdate.permission_name,
          granted: permissionUpdate.granted,
          permission_id: existingPerm.permission_id
        });
      }
    }

    // If no changes, return early
    if (updateOperations.length === 0) {
      return res.json({ 
        message: 'No permission changes required',
        permissions_changed: 0
      });
    }

    // Update permissions one by one to avoid schema validation issues
    let totalUpdated = 0;
    
    for (const operation of updateOperations) {
      // Find the index of the permission in the user's permissions array
      const permIndex = user.permissions.findIndex(p => 
        p.permission_name === operation.permission_name
      );
      
      if (permIndex !== -1) {
        // Update just the granted field for this specific permission
        const updateResult = await req.app.locals.db.collection('users').updateOne(
          { _id: userId },
          {
            $set: {
              [`permissions.${permIndex}.granted`]: operation.granted,
              updated_at: currentTime
            }
          }
        );
        
        if (updateResult.modifiedCount > 0) {
          totalUpdated++;
        }
      }
    }
    
    // Check if any updates were made
    const updateResult = { 
      matchedCount: 1, 
      modifiedCount: totalUpdated > 0 ? 1 : 0 
    };

    if (updateResult.matchedCount === 0) {
      return res.status(404).json({ message: 'User not found during update' });
    }

    if (updateResult.modifiedCount === 0) {
      return res.status(400).json({ message: 'No permissions were updated' });
    }

    // Add permission logs if there are changes
    if (permissionLogs.length > 0) {
      await req.app.locals.db.collection('users').updateOne(
        { _id: userId },
        {
          $push: {
            permission_logs: { $each: permissionLogs }
          }
        }
      );
    }

    res.json({ 
      message: 'User permissions updated successfully',
      logs_added: permissionLogs.length,
      permissions_changed: updateOperations.length,
      updated_count: updateResult.modifiedCount
    });
  } catch (err) {
    console.error("Permission update failed:", err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   GET /api/users/permissions/all
 * @desc    Get all available permissions in the system
 * @access  Admin or users with manage_permissions permission
 */
router.get('/permissions/all', permissionAuth('manage_permissions'), async (req, res) => {
  try {
    const { getAllPermissions, PERMISSIONS } = require('../config/permissions');
    
    // Get all permissions as a flat array
    const allPermissions = getAllPermissions();
    
    // Use PERMISSIONS directly instead of hardcoding categories
    const permissionsByCategory = PERMISSIONS;

    res.json({
      message: 'All permissions retrieved successfully',
      total_permissions: allPermissions.length,
      permissions_by_category: permissionsByCategory
    });
  } catch (err) {
    console.error('Error fetching all permissions:', err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   PUT /api/users/:id/role
 * @desc    Update user role
 * @access  Admin or users with manage_roles permission
 */
router.put('/:id/role', permissionAuth('manage_roles'), async (req, res) => {
  try {
    const userId = new ObjectId(req.params.id);
    const { role } = req.body;

    if (!role || (!role.role_id && !role.role_name)) {
      return res.status(400).json({ message: 'Invalid role data. Provide either role_id or role_name' });
    }

    // Get role from roles collection
    let roleFromDb;
    if (role.role_id) {
      roleFromDb = await req.app.locals.db.collection('roles').findOne({ 
        _id: new ObjectId(role.role_id) 
      });
    } else if (role.role_name) {
      roleFromDb = await req.app.locals.db.collection('roles').findOne({ 
        role_name: role.role_name 
      });
    }
    
    if (!roleFromDb) {
      return res.status(400).json({ message: 'Invalid role. Role not found in the database.' });
    }

    const result = await req.app.locals.db.collection('users').updateOne(
      { _id: userId },
      {
        $set: {
          role_id: roleFromDb._id,
          role_name: roleFromDb.role_name,
          role_description: roleFromDb.description,
          updated_at: new Date()
        }
      }
    );

    if (result.matchedCount === 0) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({ message: 'User role updated successfully' });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   GET /api/users/:id/permission-logs
 * @desc    Get user permission logs
 * @access  Admin or users with view_permission_logs permission
 */
router.get('/:id/permission-logs', permissionAuth('view_permission_logs'), async (req, res) => {
  try {
    const user = await req.app.locals.db.collection('users').findOne(
      { _id: new ObjectId(req.params.id) },
      { projection: { permission_logs: 1, first_name: 1, last_name: 1 } }
    );

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({
      user: `${user.first_name} ${user.last_name}`,
      permission_logs: user.permission_logs || []
    });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   GET /api/users/:id/granted-permissions
 * @desc    Get only the granted permissions for a user
 * @access  Admin or Self or users with view_users permission
 */
router.get('/:id/granted-permissions',permissionAuth("view_users"), async (req, res) => {
  try {
    const userId = new ObjectId(req.params.id);

    // Get user from database
    const user = await req.app.locals.db.collection('users').findOne({ _id: userId });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Filter to get only granted permissions
    const grantedPermissions = user.permissions?.filter(perm => perm.granted === true) || [];
    
    // Group granted permissions by category for better organization
    const grantedByCategory = {};
    grantedPermissions.forEach(perm => {
      const category = perm.category || 'Uncategorized';
      if (!grantedByCategory[category]) {
        grantedByCategory[category] = [];
      }
      grantedByCategory[category].push({
        permission_id: perm.permission_id,
        permission_name: perm.permission_name,
        description: perm.permission_description
      });
    });

    res.json({
      user: {
        id: user._id,
        name: `${user.first_name} ${user.last_name}`,
        role: user.role_name,
        email: user.email
      },
      granted_permissions: grantedPermissions.map(perm => ({
        permission_id: perm.permission_id,
        permission_name: perm.permission_name,
        description: perm.permission_description,
      })),
      total_granted: grantedPermissions.length
    });
  } catch (err) {
    console.error('Error fetching granted permissions:', err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   POST /api/users/register
 * @desc    Register a new user (public registration)
 * @access  Public
 */
router.post('/register', async (req, res) => {
  try {
    const { first_name, last_name, email, phone, password, branch } = req.body;

    // Validate required fields
    if (!first_name || !last_name || !email || !password) {
      return res.status(400).json({ message: 'Missing required fields: first_name, last_name, email, password' });
    }

    // Check if email already exists
    const existingUser = await req.app.locals.db.collection('users').findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'Email already registered' });
    }

    // Get Technician role from the roles collection
    const technicianRole = await req.app.locals.db.collection('roles').findOne({ 
      role_name: "Technician" 
    });
    
    if (!technicianRole) {
      return res.status(500).json({ 
        message: 'Could not find Technician role. Please ensure roles are seeded correctly.' 
      });
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const password_hash = await bcrypt.hash(password, salt);

    // Handle branch lookup
    let branchFromDb = null;
    if (branch) {
      if (typeof branch === 'object' && branch.branch_id) {
        branchFromDb = await req.app.locals.db.collection('branches').findOne({
          _id: new ObjectId(branch.branch_id)
        });
      } else if (typeof branch === 'string') {
        branchFromDb = await req.app.locals.db.collection('branches').findOne({
          branch_code: branch
        });
      }
    }
    
    // Default to first available branch if none specified
    if (!branchFromDb) {
      branchFromDb = await req.app.locals.db.collection('branches').findOne({});
    }
    
    // Get default permissions for Technician role
    const technicianPermissions = getDefaultPermissionsForRole("Technician");
    
    const newUser = {
      first_name,
      last_name,
      name: `${first_name} ${last_name}`,
      email,
      phone: phone || "",
      password_hash,
      is_active: true,
      staff_code: "",
      speciality: "",
      branch: branchFromDb ? {
        branch_id: branchFromDb._id,
        branch_name: branchFromDb.branch_name,
        branch_code: branchFromDb.branch_code,
        location: branchFromDb.location || ""
      } : null,
      role_id: technicianRole._id,
      role_name: technicianRole.role_name,
      role_description: technicianRole.description || '',
      permissions: technicianPermissions,
      permission_logs: [],
      created_at: new Date(),
      updated_at: new Date()
    };

    const result = await req.app.locals.db.collection('users').insertOne(newUser);
    
    // Create and return JWT token
    const payload = {
      user: {
        id: result.insertedId,
        role: technicianRole.role_name
      }
    };

    jwt.sign(
      payload,
      JWT_SECRET,
      { expiresIn: JWT_EXPIRE },
      (err, token) => {
        if (err) {
          console.error('JWT signing error:', err);
          return res.status(500).json({ message: 'Error creating token' });
        }
        
        res.status(201).json({
          message: 'User registered successfully',
          token,
          user: {
            id: result.insertedId,
            name: newUser.name,
            email: newUser.email,
            role_name: newUser.role_name,
            role_id: newUser.role_id,
            role_description: newUser.role_description,
            branch: newUser.branch
          }
        });
      }
    );
  } catch (err) {
    console.error('Registration error:', err);
    res.status(500).json({ 
      message: 'Server error during registration', 
      error: err.message 
    });
  }
});

/**
 * @route   POST /api/users/login
 * @desc    Authenticate user & get token
 * @access  Public
 */
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ message: 'Please provide email and password' });
    }

    // Find user by email
    const user = await req.app.locals.db.collection('users').findOne({ email });

    if (!user) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    // Check if user account is active
    if (user.is_active === false) {
      return res.status(401).json({ message: 'Account is inactive' });
    }

    // Compare passwords
    const isMatch = await bcrypt.compare(password, user.password_hash);

    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    // Create JWT payload
    const payload = {
      user: {
        id: user._id,
        role: user.role_name
      }
    };

    // Sign and return JWT token
    jwt.sign(
      payload,
      JWT_SECRET,
      { expiresIn: JWT_EXPIRE },
      (err, token) => {
        if (err) {
          console.error('JWT signing error:', err);
          return res.status(500).json({ message: 'Error creating token' });
        }
        
        const safeUser = sanitizeUser(user);
        res.json({
          token,
          user: {
            id: safeUser._id,
            name: formatUserName(safeUser),
            email: safeUser.email,
            role_name: safeUser.role_name,
            role_id: safeUser.role_id,
            role_description: safeUser.role_description,
            branch: safeUser.branch
          }
        });
      }
    );
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   PUT /api/users/:id/role
 * @desc    Update user role
 * @access  Admin or users with manage_roles permission
 */
router.put('/:id/role', permissionAuth('manage_roles'), async (req, res) => {
  try {
    const userId = new ObjectId(req.params.id);
    const { role } = req.body;

    if (!role || (typeof role === 'object' && !role.role_id && !role.role_name) || 
        (typeof role === 'string' && !role)) {
      return res.status(400).json({ message: 'Invalid role data. Provide role_id, role_name, or role string' });
    }

    // Get role from roles collection
    let roleFromDb;
    if (typeof role === 'object') {
      if (role.role_id) {
        roleFromDb = await req.app.locals.db.collection('roles').findOne({ 
          _id: new ObjectId(role.role_id) 
        });
      } else if (role.role_name) {
        roleFromDb = await req.app.locals.db.collection('roles').findOne({ 
          role_name: role.role_name 
        });
      }
    } else if (typeof role === 'string') {
      roleFromDb = await req.app.locals.db.collection('roles').findOne({ 
        role_name: role 
      });
    }
    
    if (!roleFromDb) {
      return res.status(400).json({ message: 'Invalid role. Role not found in the database.' });
    }

    // Get default permissions for the new role
    const newPermissions = getDefaultPermissionsForRole(roleFromDb.role_name);

    const result = await req.app.locals.db.collection('users').updateOne(
      { _id: userId },
      {
        $set: {
          role_id: roleFromDb._id,
          role_name: roleFromDb.role_name,
          role_description: roleFromDb.description || '',
          permissions: newPermissions,
          updated_at: new Date()
        }
      }
    );

    if (result.matchedCount === 0) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({ message: 'User role updated successfully' });
  } catch (err) {
    console.error('Error updating user role:', err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   GET /api/users/:id/manner-evaluations
 * @desc    Get all manner evaluations for a user
 * @access  Admin or users with view_manner_evaluations permission
 */
router.get('/:id/manner-evaluations', permissionAuth('view_manner_evaluations'), async (req, res) => {
  try {
    const userId = req.params.id;
    
    const user = await req.app.locals.db.collection('users').findOne(
      { _id: new ObjectId(userId) },
      { projection: { manner_evaluations: 1, first_name: 1, last_name: 1, email: 1 } }
    );

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({
      user: {
        id: user._id,
        name: `${user.first_name} ${user.last_name}`,
        email: user.email
      },
      manner_evaluations: user.manner_evaluations || [],
      total_evaluations: (user.manner_evaluations || []).length
    });
  } catch (err) {
    console.error('Error fetching manner evaluations:', err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   POST /api/users/:id/manner-evaluations
 * @desc    Add a new manner evaluation for a user
 * @access  Admin or users with manage_manner_evaluations permission
 */
router.post('/:id/manner-evaluations', permissionAuth('manage_manner_evaluations'), async (req, res) => {
  try {
    const userId = req.params.id;
    const { category, rating, notes, work_order_id } = req.body;

    // Validate required fields
    if (!category || rating === undefined || !notes) {
      return res.status(400).json({ 
        message: 'Category, rating, and notes are required' 
      });
    }

    // Validate rating range
    const ratingNum = parseInt(rating);
    if (isNaN(ratingNum) || ratingNum < 1 || ratingNum > 5) {
      return res.status(400).json({ 
        message: 'Rating must be an integer between 1 and 5' 
      });
    }

    // Check if user exists
    const user = await req.app.locals.db.collection('users').findOne({ _id: new ObjectId(userId) });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Get evaluator ID from the authenticated user
    const evaluatorId = req.user._id || req.user.id;

    // Import User model and add the evaluation
    const User = require('../models/User');
    const result = await User.addMannerEvaluation(req.app.locals.db, userId, {
      category,
      rating: ratingNum,
      notes,
      work_order_id
    }, evaluatorId);

    if (result.success) {
      res.status(201).json({
        message: 'Manner evaluation added successfully',
        evaluation_id: result.evaluationId
      });
    } else {
      res.status(500).json({ message: 'Failed to add manner evaluation' });
    }
  } catch (err) {
    console.error('Error adding manner evaluation:', err);
    
    // Enhanced error logging for MongoDB validation errors
    if (err.code === 121) {
      console.log('\n🎯 MONGODB VALIDATION ERROR (Code 121):');
      console.log('Error Info:', JSON.stringify(err.errInfo, null, 2));
      
      if (err.errInfo && err.errInfo.details) {
        console.log('\n📋 Schema validation details:');
        console.log(JSON.stringify(err.errInfo.details, null, 2));
        
        if (err.errInfo.details.schemaRulesNotSatisfied) {
          console.log('\n❌ Schema Rules Not Satisfied:');
          err.errInfo.details.schemaRulesNotSatisfied.forEach((rule, index) => {
            console.log(`\n${index + 1}. ${rule.operatorName}:`);
            if (rule.propertiesNotSatisfied) {
              rule.propertiesNotSatisfied.forEach(prop => {
                console.log(`   Property: ${prop.propertyName}`);
                console.log(`   Details: ${JSON.stringify(prop.details, null, 4)}`);
              });
            }
          });
        }
      }
      
      return res.status(400).json({ 
        message: 'Document failed validation',
        error: 'Data format does not match required schema',
        validation_details: err.errInfo?.details // Include in development only
      });
    }
    
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   PUT /api/users/:id/manner-evaluations/:evaluationId
 * @desc    Update an existing manner evaluation
 * @access  Admin or users with manage_manner_evaluations permission
 */
router.put('/:id/manner-evaluations/:evaluationId', permissionAuth('manage_manner_evaluations'), async (req, res) => {
  try {
    const { id: userId, evaluationId } = req.params;
    const { category, rating, notes, work_order_id } = req.body;

    // Validate required fields
    if (!category || rating === undefined || !notes) {
      return res.status(400).json({ 
        message: 'Category, rating, and notes are required' 
      });
    }

    // Validate rating range
    const ratingNum = parseInt(rating);
    if (isNaN(ratingNum) || ratingNum < 1 || ratingNum > 5) {
      return res.status(400).json({ 
        message: 'Rating must be an integer between 1 and 5' 
      });
    }

    // Check if user exists
    const user = await req.app.locals.db.collection('users').findOne({ _id: new ObjectId(userId) });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Get evaluator ID from the authenticated user
    const evaluatorId = req.user._id || req.user.id;

    // Import User model and update the evaluation
    const User = require('../models/User');
    const result = await User.updateMannerEvaluation(req.app.locals.db, userId, evaluationId, {
      category,
      rating: ratingNum,
      notes,
      work_order_id
    }, evaluatorId);

    if (result.success) {
      res.json({ message: 'Manner evaluation updated successfully' });
    } else {
      res.status(404).json({ message: 'Evaluation not found or failed to update' });
    }
  } catch (err) {
    console.error('Error updating manner evaluation:', err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   DELETE /api/users/:id/manner-evaluations/:evaluationId
 * @desc    Delete a manner evaluation
 * @access  Admin or users with manage_manner_evaluations permission
 */
router.delete('/:id/manner-evaluations/:evaluationId', permissionAuth('manage_manner_evaluations'), async (req, res) => {
  try {
    const { id: userId, evaluationId } = req.params;

    // Check if user exists
    const user = await req.app.locals.db.collection('users').findOne({ _id: new ObjectId(userId) });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Get evaluator ID from the authenticated user
    const evaluatorId = req.user._id || req.user.id;

    // Import User model and delete the evaluation
    const User = require('../models/User');
    const result = await User.deleteMannerEvaluation(req.app.locals.db, userId, evaluationId, evaluatorId);

    if (result.success) {
      res.json({ message: 'Manner evaluation deleted successfully' });
    } else {
      res.status(404).json({ message: result.error || 'Evaluation not found or failed to delete' });
    }
  } catch (err) {
    console.error('Error deleting manner evaluation:', err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   GET /api/users/:id/manner-evaluation-logs
 * @desc    Get manner evaluation logs for a user
 * @access  Admin or users with view_manner_evaluations permission
 */
router.get('/:id/manner-evaluation-logs', permissionAuth('view_manner_evaluations'), async (req, res) => {
  try {
    const userId = req.params.id;
    
    const user = await req.app.locals.db.collection('users').findOne(
      { _id: new ObjectId(userId) },
      { projection: { manner_evaluation_logs: 1, first_name: 1, last_name: 1, email: 1 } }
    );

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Sort logs by created_at descending (newest first)
    const sortedLogs = (user.manner_evaluation_logs || []).sort((a, b) => 
      new Date(b.created_at) - new Date(a.created_at)
    );

    res.json({
      user: {
        id: user._id,
        name: `${user.first_name} ${user.last_name}`,
        email: user.email
      },
      manner_evaluation_logs: sortedLogs,
      total_logs: sortedLogs.length
    });
  } catch (err) {
    console.error('Error fetching manner evaluation logs:', err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});


/**
 * @route   POST /api/users/validate
 * @desc    Validate JWT token
 * @access  Public
 */
router.post('/validate', (req, res) => {
  const token = req.body.token || req.headers['authorization']?.replace('Bearer ', '');
  if (!token) {
    return res.status(400).json({ valid: false, message: 'No token provided' });
  }
  jwt.verify(token, JWT_SECRET, (err, decoded) => {
    if (err) {
      return res.status(401).json({ valid: false, message: 'Invalid token' });
    }
    res.json({ valid: true, decoded });
  });
});

/**
 * @route   POST /api/users/change-password
 * @desc    Change password for the authenticated user
 * @access  Private (self-service)
 */
router.post('/change-password', auth, async (req, res) => {
  try {
    const userId = req.user._id || req.user.id;
    const { currentPassword, newPassword } = req.body;
    if (!currentPassword || !newPassword) {
      return res.status(400).json({ message: 'Current and new password are required.' });
    }

    // Find user by ID
    const user = await req.app.locals.db.collection('users').findOne({ _id: new ObjectId(userId) });
    if (!user) {
      return res.status(404).json({ message: 'User not found.' });
    }

    // Check current password
    const isMatch = await bcrypt.compare(currentPassword, user.password_hash);
    if (!isMatch) {
      return res.status(400).json({ message: 'Current password is incorrect.' });
    }

    // Hash new password
    const salt = await bcrypt.genSalt(10);
    const newPasswordHash = await bcrypt.hash(newPassword, salt);

    // Update password in DB
    await req.app.locals.db.collection('users').updateOne(
      { _id: new ObjectId(userId) },
      { $set: { password_hash: newPasswordHash, updated_at: new Date() } }
    );

    res.json({ message: 'Password changed successfully.' });
  } catch (err) {
    console.error('Change password error:', err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

module.exports = router;