const express = require('express');
const router = express.Router();
const { ObjectId } = require('mongodb');
const { WorkOrder, Stage, Variation, ErrorReport } = require('../models');
const { ValidationError } = require('../models/WorkOrder');
const permissionAuth = require('../middleware/permissionAuth');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { createS3Upload, uploadConfigs, deleteFromS3, getSignedUrl } = require('../middleware/s3Upload');

// Configure S3 upload for cancellation approval images
const uploadCancellationImage = createS3Upload({
  folderName: 'work-orders/cancellation-approvals',
  ...uploadConfigs.images,
  fieldName: 'approvalImage'
});

// Configure S3 upload for error report images
const uploadErrorReportImage = createS3Upload({
  folderName: 'work-orders/error-reports',
  ...uploadConfigs.images,
  fieldName: 'image'
});

// Temporary simple multer for testing
const upload = multer({ dest: 'uploads/' });

// Middleware to check if ObjectId is valid
const validateObjectId = (req, res, next) => {
  // Get the ID from any of the possible parameters
  const id = req.params.id || req.params.customerId || req.params.supervisorId;
  
  if (!ObjectId.isValid(id)) {
    return res.status(400).json({ 
      success: false,
      message: 'Invalid ID format' 
    });
  }
  
  next();
};

// Enhanced error handler
const handleError = (res, error, context = '') => {
  console.error(`Error in ${context}:`, error);
  
  if (error.name === 'ValidationError') {
    return res.status(400).json({
      success: false,
      message: error.message
    });
  }
  
  return res.status(500).json({
    success: false,
    message: error.message
  });
};

/**
 * Enhance work order stages with stage details from stages collection
 * @param {Object} db MongoDB database connection
 * @param {Object} workOrder Work order to enhance
 * @returns {Object} Enhanced work order with stage details
 */
async function enhanceWorkOrderStages(db, workOrder) {
  if (!workOrder || !workOrder.parts || !Array.isArray(workOrder.parts)) {
    return workOrder;
  }

  try {
    // Collect all unique stage IDs from all parts
    const stageIds = new Set();
    workOrder.parts.forEach(part => {
      if (part.stages && Array.isArray(part.stages)) {
        part.stages.forEach(stage => {
          if (stage.stage_id || stage.stageId) {
            stageIds.add((stage.stage_id || stage.stageId).toString());
          }
        });
      }
    });

    if (stageIds.size === 0) {
      return workOrder;
    }

    // Fetch stage details from stages collection
    const stageDetails = await db.collection('stages').find({
      _id: { $in: Array.from(stageIds).map(id => new ObjectId(id)) }
    }).toArray();

    // Create a map for quick lookup
    const stageMap = new Map();
    stageDetails.forEach(stage => {
      stageMap.set(stage._id.toString(), stage);
    });

    // Enhance each stage in each part
    workOrder.parts.forEach(part => {
      if (part.stages && Array.isArray(part.stages)) {
        part.stages.forEach(stage => {
          const stageId = (stage.stage_id || stage.stageId)?.toString();
          if (stageId && stageMap.has(stageId)) {
            const stageInfo = stageMap.get(stageId);
            stage.stage_name = stageInfo.name;
            stage.stage_description = stageInfo.description;
            stage.stage_order = stageInfo.order;
          }
        });
      }
    });

    return workOrder;
  } catch (error) {
    console.error('Error enhancing work order stages:', error);
    return workOrder; // Return original if enhancement fails
  }
}

/**
 * @route   GET /api/work-orders/status-summary
 * @desc    Get work order status summary for the frontend
 * @access  Private (requires view_all_work_orders permission)
 */
router.get('/status-summary', async (req, res) => {
  try {
    const db = req.app.locals.db;
    
    // Get work order status summary
    const statusSummary = await db.collection('work_orders').aggregate([
      {
        $match: {
          deleted: { $ne: true }
        }
      },
      {
        $group: {
          _id: '$status',
          count: { $sum: 1 }
        }
      },
      {
        $project: {
          _id: 0,
          status: '$_id',
          count: 1
        }
      },
      {
        $sort: {
          status: 1
        }
      }
    ]).toArray();
    
    // Ensure all possible statuses are represented (with 0 if none exist)
    const allStatuses = ['pending', 'in_progress', 'qa_review', 'completed', 'cancelled'];
    const completeStatusSummary = allStatuses.map(status => {
      const existing = statusSummary.find(s => s.status === status);
      return {
        status,
        count: existing ? existing.count : 0
      };
    });
    
    res.json({
      success: true,
      data: completeStatusSummary
    });
  } catch (error) {
    handleError(res, error, 'GET /work-orders/status-summary');
  }
});

/**
 * @route   POST /api/work-orders
 * @desc    Create a new work order
 * @access  Private (requires create_work_order permission)
 */
router.post('/', permissionAuth('create_work_order'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    
    // Check if both customer_id and vehicle_id are provided
    if (!req.body.customer_id) {
      return res.status(400).json({ 
        success: false,
        message: 'Customer ID is required' 
      });
    }
    
    if (req.body.vehicle_id === undefined) {
      return res.status(400).json({ 
        success: false,
        message: 'Vehicle ID is required' 
      });
    }
    
    const workOrder = await WorkOrder.create(db, req.body);
    
    // Get the enhanced work order with customer and vehicle details for WebSocket
    const enhancedWorkOrder = await WorkOrder.getById(db, workOrder._id);
    await WorkOrder.enhanceWorkOrdersWithVehicleDetails(db, [enhancedWorkOrder]);
    await WorkOrder.enhanceWorkOrdersWithCustomerDetails(db, [enhancedWorkOrder]);
    
    // Emit WebSocket event for work order creation with full data
    if (req.app.locals.websocket) {
      req.app.locals.websocket.notifyWorkOrderCreated(enhancedWorkOrder);
    }
    
    res.status(201).json({
      success: true,
      data: enhancedWorkOrder
    });
  } catch (error) {
    handleError(res, error, 'POST /work-orders');
  }
});

/**
 * @route   POST /api/work-orders/registration
 * @desc    Create a work order specifically for registration process
 * @access  Private (requires create_work_order permission)
 */
router.post('/registration', permissionAuth('create_work_order'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    
    const {
      invoice_id,
      assigned_technician,
      variation_id,
      notes,
      technician_expected_delivery_date,
      technician_ratio
    } = req.body;
    
    // Validate required fields
    if (!invoice_id) {
      return res.status(400).json({
        success: false,
        message: 'Invoice ID is required'
      });
    }
    
    // Get invoice details to extract customer and vehicle info
    const invoice = await db.collection('invoices').findOne({
      _id: new ObjectId(invoice_id)
    });
    
    if (!invoice) {
      return res.status(404).json({
        success: false,
        message: 'Invoice not found'
      });
    }
    
    // Get variation details if provided
    let variationDetails = null;
    if (variation_id) {
      variationDetails = await db.collection('variations').findOne({
        _id: new ObjectId(variation_id)
      });
    }
    
    // Generate work order number
    const workOrderCount = await db.collection('work_orders').countDocuments();
    const workOrderNumber = `WO-${String(workOrderCount + 1).padStart(6, '0')}`;
    
    // Create work order document
    const workOrderData = {
      workOrderNumber,
      customer_id: invoice.customer_id,
      vehicle_id: invoice.vehicle_id,
      invoice_id: new ObjectId(invoice_id),
      status: 'pending',
      assigned_technician: assigned_technician ? new ObjectId(assigned_technician) : null,
      supervisor: req.user?.name || 'ADMIN', // Get from authenticated user
      service_variations: variationDetails ? [{
        variation_id: new ObjectId(variation_id),
        code: variationDetails.code,
        description: variationDetails.description,
        expected_hours: variationDetails.defaultLaborHours || 0,
        actual_hours: 0,
        status: 'pending',
        stages: variationDetails.defaultStages ? variationDetails.defaultStages.map(stageId => ({
          stage_id: new ObjectId(stageId),
          status: 'pending',
          started_at: null,
          completed_at: null,
          notes: '',
          logs: []
        })) : []
      }] : [],
      parts: [],
      expected_completion_date: technician_expected_delivery_date ? new Date(technician_expected_delivery_date) : null,
      actual_completion_date: null,
      quality_ratio: technician_ratio ? parseFloat(technician_ratio) : 100,
      notes: notes || '',
      created_at: new Date(),
      updated_at: new Date(),
      deleted: false
    };
    
    // Insert work order
    const result = await db.collection('work_orders').insertOne(workOrderData);
    
    // Get the created work order with enhanced details
    const createdWorkOrder = await db.collection('work_orders').findOne({
      _id: result.insertedId
    });
    
    // Enhance with customer and vehicle details for both response and WebSocket
    await WorkOrder.enhanceWorkOrdersWithVehicleDetails(db, [createdWorkOrder]);
    await WorkOrder.enhanceWorkOrdersWithCustomerDetails(db, [createdWorkOrder]);
    
    // Emit WebSocket event for work order creation with full data
    if (req.app.locals.websocket) {
      req.app.locals.websocket.notifyWorkOrderCreated(createdWorkOrder);
    }
    
    res.status(201).json({
      success: true,
      data: createdWorkOrder,
      work_order_id: result.insertedId
    });
    
  } catch (error) {
    handleError(res, error, 'POST /work-orders/registration');
  }
});

/**
 * @route   GET /api/work-orders
 * @desc    Get all work orders with optional filters, pagination, and search
 * @access  Private (requires view_all_work_orders permission)
 */
router.get('/', async (req, res) => {
  try {
    const db = req.app.locals.db;
    const { 
      customer_id, 
      status, 
      created_from, 
      created_to, 
      vin,
      search,
      page = 1,
      limit = 10,
      sortBy = 'createdAt',
      sortOrder = 'desc'
    } = req.query;
    
    // Build query object
    const query = { deleted: { $ne: true } };
    
    if (customer_id) {
      if (!ObjectId.isValid(customer_id)) {
        return res.status(400).json({
          success: false,
          message: 'Invalid customer_id format'
        });
      }
      query.customer_id = new ObjectId(customer_id);
    }
    
    if (status) {
      const validStatuses = ['pending', 'in_progress', 'qa_review', 'completed', 'cancelled'];
      if (!validStatuses.includes(status)) {
        return res.status(400).json({
          success: false,
          message: 'Invalid status value',
          validStatuses
        });
      }
      query.status = status;
    }
    
    if (created_from || created_to) {
      query.createdAt = {};
      
      if (created_from) {
        const fromDate = new Date(created_from);
        if (isNaN(fromDate.getTime())) {
          return res.status(400).json({
            success: false,
            message: 'Invalid created_from date format'
          });
        }
        query.createdAt.$gte = fromDate;
      }
      
      if (created_to) {
        const toDate = new Date(created_to);
        if (isNaN(toDate.getTime())) {
          return res.status(400).json({
            success: false,
            message: 'Invalid created_to date format'
          });
        }
        query.createdAt.$lte = toDate;
      }
    }
    
    // Pagination
    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    const skip = (pageNum - 1) * limitNum;
    
    // Sorting
    const sortOptions = {};
    sortOptions[sortBy] = sortOrder === 'desc' ? -1 : 1;
    
    // Get total count for pagination
    const totalCount = await db.collection('work_orders').countDocuments(query);
    
    // Get work orders with pagination and sorting
    let workOrders = await db.collection('work_orders')
      .find(query)
      .sort(sortOptions)
      .skip(skip)
      .limit(limitNum)
      .toArray();
    
    // Enhance work orders with vehicle and customer details
    await WorkOrder.enhanceWorkOrdersWithVehicleDetails(db, workOrders);
    await WorkOrder.enhanceWorkOrdersWithCustomerDetails(db, workOrders);
    
    // Apply search filter after enhancement
    if (search) {
      const searchLower = search.toLowerCase();
      workOrders = workOrders.filter(workOrder => {
        // Search in work order number
        if (workOrder.workOrderNumber && workOrder.workOrderNumber.toLowerCase().includes(searchLower)) {
          return true;
        }
        
        // Search in customer details
        if (workOrder.customerDetails) {
          if (workOrder.customerDetails.name && workOrder.customerDetails.name.toLowerCase().includes(searchLower)) {
            return true;
          }
          if (workOrder.customerDetails.phone && workOrder.customerDetails.phone.toLowerCase().includes(searchLower)) {
            return true;
          }
          if (workOrder.customerDetails.email && workOrder.customerDetails.email.toLowerCase().includes(searchLower)) {
            return true;
          }
        }
        
        // Search in vehicle details
        if (workOrder.vehicleDetails) {
          if (workOrder.vehicleDetails.make && workOrder.vehicleDetails.make.toLowerCase().includes(searchLower)) {
            return true;
          }
          if (workOrder.vehicleDetails.model && workOrder.vehicleDetails.model.toLowerCase().includes(searchLower)) {
            return true;
          }
          if (workOrder.vehicleDetails.licensePlate && workOrder.vehicleDetails.licensePlate.toLowerCase().includes(searchLower)) {
            return true;
          }
          if (workOrder.vehicleDetails.color && workOrder.vehicleDetails.color.toLowerCase().includes(searchLower)) {
            return true;
          }
          if (workOrder.vehicleDetails.vin && workOrder.vehicleDetails.vin.toLowerCase().includes(searchLower)) {
            return true;
          }
        }
        
        // Search in supervisor
        if (workOrder.supervisor && workOrder.supervisor.toLowerCase().includes(searchLower)) {
          return true;
        }
        
        return false;
      });
    }
    
    // Filter by VIN if requested
    if (vin) {
      workOrders = workOrders.filter(workOrder => 
        workOrder.vehicleDetails && 
        workOrder.vehicleDetails.vin && 
        workOrder.vehicleDetails.vin.toLowerCase().includes(vin.toLowerCase())
      );
    }
    
    res.json({
      success: true,
      data: workOrders,
      pagination: {
        currentPage: pageNum,
        totalPages: Math.ceil(totalCount / limitNum),
        totalItems: totalCount,
        itemsPerPage: limitNum,
        hasNext: pageNum < Math.ceil(totalCount / limitNum),
        hasPrev: pageNum > 1
      }
    });
  } catch (error) {
    handleError(res, error, 'GET /work-orders');
  }
});


/**
 * @route   GET /api/work-orders/number/:workOrderNumber
 * @desc    Get a work order by work order number
 * @access  Private (requires view_work_order permission)
 */
router.get('/number/:workOrderNumber', permissionAuth('view_work_order'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const workOrder = await WorkOrder.getByWorkOrderNumber(db, req.params.workOrderNumber);
    
    if (!workOrder) {
      return res.status(404).json({ 
        success: false,
        message: 'Work order not found' 
      });
    }
    
    // Enhance with customer and vehicle details
    await WorkOrder.enhanceWorkOrdersWithVehicleDetails(db, [workOrder]);
    await WorkOrder.enhanceWorkOrdersWithCustomerDetails(db, [workOrder]);
    
    res.json({
      success: true,
      data: workOrder
    });
  } catch (error) {
    handleError(res, error, 'GET /work-orders/number/:workOrderNumber');
  }
});

/**
 * @route   GET /api/work-orders/customer/:customerId
 * @desc    Get all work orders for a specific customer
 * @access  Private (requires view_work_order permission)
 */
router.get('/customer/:customerId',permissionAuth('view_work_order'), validateObjectId, async (req, res) => {
  try {
    const db = req.app.locals.db;
    const workOrders = await WorkOrder.getByCustomerId(db, req.params.customerId);
    
    // Enhance with customer and vehicle details
    await WorkOrder.enhanceWorkOrdersWithVehicleDetails(db, workOrders);
    await WorkOrder.enhanceWorkOrdersWithCustomerDetails(db, workOrders);
    
    res.json({
      success: true,
      data: workOrders
    });
  } catch (error) {
    handleError(res, error, 'GET /work-orders/customer/:customerId');
  }
});

/**
 * @route   GET /api/work-orders/supervisor/:supervisorId
 * @desc    Get all work orders for a specific supervisor
 * @access  Private (requires view_work_order permission)
 */
router.get('/supervisor/:supervisorId', permissionAuth('view_work_order'), validateObjectId, async (req, res) => {
  try {
    const db = req.app.locals.db;
    const supervisorId = req.params.supervisorId;
    
    // Validate if supervisor exists
    const supervisor = await db.collection('users').findOne({ 
      _id: new ObjectId(supervisorId) 
    });
    
    if (!supervisor) {
      return res.status(404).json({
        success: false,
        message: 'Supervisor not found'
      });
    }

    // Build query to find work orders by supervisor
    // Based on the schema, supervisor ID is stored in parts.assignedTo field
    const query = {
      deleted: { $ne: true },
      'parts.assignedTo': new ObjectId(supervisorId)
    };

    // Add pagination support
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    // Add status filter if provided
    if (req.query.status) {
      const validStatuses = ['open', 'in_progress', 'qa_review', 'completed', 'cancelled'];
      if (!validStatuses.includes(req.query.status)) {
        return res.status(400).json({
          success: false,
          message: 'Invalid status value',
          validStatuses
        });
      }
      query.status = req.query.status;
    }

    // Add date range filter if provided
    if (req.query.created_from || req.query.created_to) {
      query.createdAt = {};
      
      if (req.query.created_from) {
        const fromDate = new Date(req.query.created_from);
        if (isNaN(fromDate.getTime())) {
          return res.status(400).json({
            success: false,
            message: 'Invalid created_from date format'
          });
        }
        query.createdAt.$gte = fromDate;
      }
      
      if (req.query.created_to) {
        const toDate = new Date(req.query.created_to);
        if (isNaN(toDate.getTime())) {
          return res.status(400).json({
            success: false,
            message: 'Invalid created_to date format'
          });
        }
        query.createdAt.$lte = toDate;
      }
    }

    // Get total count for pagination
    const totalCount = await db.collection('work_orders').countDocuments(query);

    // Get work orders with pagination and sorting
    const workOrders = await db.collection('work_orders')
      .find(query)
      .sort({ createdAt: -1 }) // Most recent first
      .skip(skip)
      .limit(limit)
      .toArray();

    // Enhance with customer and vehicle details
    await WorkOrder.enhanceWorkOrdersWithVehicleDetails(db, workOrders);
    await WorkOrder.enhanceWorkOrdersWithCustomerDetails(db, workOrders);

    res.json({
      success: true,
      data: workOrders,
      supervisor: {
        _id: supervisor._id,
        name: `${supervisor.first_name} ${supervisor.last_name}`,
        email: supervisor.email,
        role: supervisor.role_name
      },
      pagination: {
        currentPage: page,
        totalPages: Math.ceil(totalCount / limit),
        totalItems: totalCount,
        itemsPerPage: limit,
        hasNext: page < Math.ceil(totalCount / limit),
        hasPrev: page > 1
      }
    });
  } catch (error) {
    handleError(res, error, 'GET /work-orders/supervisor/:supervisorId');
  }
});

/**
 * @route   GET /api/work-orders/:id
 * @desc    Get a work order by ID
 * @access  Private (requires view_work_order permission)
 */
router.get('/:id', validateObjectId, permissionAuth('view_work_order'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const workOrder = await WorkOrder.getById(db, req.params.id);
    
    if (!workOrder) {
      return res.status(404).json({ 
        success: false,
        message: 'Work order not found' 
      });
    }
    
    // Enhance with customer and vehicle details
    await WorkOrder.enhanceWorkOrdersWithVehicleDetails(db, [workOrder]);
    await WorkOrder.enhanceWorkOrdersWithCustomerDetails(db, [workOrder]);
    
    res.json({
      success: true,
      data: workOrder
    });
  } catch (error) {
    handleError(res, error, 'GET /work-orders/:id');
  }
});


/**
 * @route   PUT /api/work-orders/:id
 * @desc    Update a work order
 * @access  Private (requires update_work_order permission)
 */
router.put('/:id', validateObjectId, permissionAuth('update_work_order'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    
    // Get the work order to make sure it exists
    const workOrder = await WorkOrder.getById(db, req.params.id);
    
    if (!workOrder) {
      return res.status(404).json({ 
        success: false,
        message: 'Work order not found' 
      });
    }
    
    // Update work order
    await WorkOrder.updateById(db, req.params.id, req.body);
    
    // Get updated work order with enhanced details
    const updatedWorkOrder = await WorkOrder.getById(db, req.params.id);
    await WorkOrder.enhanceWorkOrdersWithVehicleDetails(db, [updatedWorkOrder]);
    await WorkOrder.enhanceWorkOrdersWithCustomerDetails(db, [updatedWorkOrder]);
    
    // Emit WebSocket event for work order update
    if (req.app.locals.websocket) {
      const changes = Object.keys(req.body); // Track what fields were changed
      req.app.locals.websocket.notifyWorkOrderUpdated(updatedWorkOrder, changes);
    }
    
    res.json({
      success: true,
      data: updatedWorkOrder
    });
  } catch (error) {
    handleError(res, error, 'PUT /work-orders/:id');
  }
});

/**
 * @route   DELETE /api/work-orders/:id
 * @desc    Delete a work order
 * @access  Private (requires delete_work_order permission)
 */
router.delete('/:id', validateObjectId, permissionAuth('delete_work_order'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    
    // Check if work order exists
    const workOrder = await WorkOrder.getById(db, req.params.id);
    
    if (!workOrder) {
      return res.status(404).json({ 
        success: false,
        message: 'Work order not found' 
      });
    }
    
    // Store work order details before deletion for WebSocket event
    const workOrderNumber = workOrder.work_order_number || workOrder.workOrderNumber;
    const workOrderId = workOrder._id;
    
    await WorkOrder.deleteById(db, req.params.id);
    
    // Emit WebSocket event for work order deletion
    if (req.app.locals.websocket) {
      req.app.locals.websocket.notifyWorkOrderDeleted(workOrderId, workOrderNumber);
    }
    
    res.json({ 
      success: true,
      message: 'Work order deleted successfully' 
    });
  } catch (error) {
    handleError(res, error, 'DELETE /work-orders/:id');
  }
});

/**
 * @route   POST /api/work-orders/:id/parts
 * @desc    Add a part to a work order
 * @access  Private (requires manage_work_order_parts permission)
 */
router.post('/:id/parts', validateObjectId, permissionAuth('manage_work_order_parts'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    
    // Check if work order exists
    const workOrder = await WorkOrder.getById(db, req.params.id);
    
    if (!workOrder) {
      return res.status(404).json({ 
        success: false,
        message: 'Work order not found' 
      });
    }
    
    // Verify the variation exists
    if (req.body.variationId) {
      const variation = await db.collection('variations').findOne({ 
        _id: typeof req.body.variationId === 'string' ? 
          new ObjectId(req.body.variationId) : req.body.variationId 
      });
      
      if (!variation) {
        return res.status(404).json({ 
          success: false,
          message: 'Variation not found' 
        });
      }
    }
    
    await WorkOrder.addPart(db, req.params.id, req.body);
    
    // Get updated work order
    const updatedWorkOrder = await WorkOrder.getById(db, req.params.id);
    
    res.json({
      success: true,
      data: updatedWorkOrder
    });
  } catch (error) {
    handleError(res, error, 'POST /work-orders/:id/parts');
  }
});

/**
 * @route   PUT /api/work-orders/:id/parts/:partIndex
 * @desc    Update a part in a work order
 * @access  Private (requires manage_work_order_parts permission)
 */
router.put('/:id/parts/:partIndex', validateObjectId, permissionAuth('manage_work_order_parts'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const partIndex = parseInt(req.params.partIndex);
    
    if (isNaN(partIndex)) {
      return res.status(400).json({ 
        success: false,
        message: 'Invalid part index' 
      });
    }
    
    // Check if work order exists
    const workOrder = await WorkOrder.getById(db, req.params.id);
    
    if (!workOrder) {
      return res.status(404).json({ 
        success: false,
        message: 'Work order not found' 
      });
    }
    
    if (!workOrder.parts || partIndex >= workOrder.parts.length) {
      return res.status(404).json({ 
        success: false,
        message: 'Part not found' 
      });
    }
    
    await WorkOrder.updatePart(db, req.params.id, partIndex, req.body);
    
    // Get updated work order
    const updatedWorkOrder = await WorkOrder.getById(db, req.params.id);
    
    res.json({
      success: true,
      data: updatedWorkOrder
    });
  } catch (error) {
    handleError(res, error, 'PUT /work-orders/:id/parts/:partIndex');
  }
});

/**
 * @route   PUT /api/work-orders/:id/parts/:partIndex/status
 * @desc    Update the status of a part in a work order
 * @access  Private (requires update_work_order_part_status permission)
 */
router.put('/:id/parts/:partIndex/status', validateObjectId, permissionAuth('update_work_order_part_status'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const partIndex = parseInt(req.params.partIndex);
    const { status } = req.body;
    
    if (isNaN(partIndex)) {
      return res.status(400).json({ 
        success: false,
        message: 'Invalid part index' 
      });
    }
    
    if (!status) {
      return res.status(400).json({ 
        success: false,
        message: 'Status is required' 
      });
    }
    
    // Check if work order exists
    const workOrder = await WorkOrder.getById(db, req.params.id);
    
    if (!workOrder) {
      return res.status(404).json({ 
        success: false,
        message: 'Work order not found' 
      });
    }
    
    if (!workOrder.parts || partIndex >= workOrder.parts.length) {
      return res.status(404).json({ 
        success: false,
        message: 'Part not found' 
      });
    }
    
    await WorkOrder.updatePartStatus(db, req.params.id, partIndex, status);
    
    // Get updated work order
    const updatedWorkOrder = await WorkOrder.getById(db, req.params.id);
    
    res.json({
      success: true,
      data: updatedWorkOrder
    });
  } catch (error) {
    handleError(res, error, 'PUT /work-orders/:id/parts/:partIndex/status');
  }
});

/**
 * @route   PUT /api/work-orders/:id/status
 * @desc    Update a work order status
 * @access  Private (requires update_work_order_status permission)
 */
router.put('/:id/status', validateObjectId, permissionAuth('update_work_order_status'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const { status } = req.body;
    
    if (!status) {
      return res.status(400).json({ 
        success: false,
        message: 'Status is required' 
      });
    }
    
    // Check if work order exists
    const workOrder = await WorkOrder.getById(db, req.params.id);
    
    if (!workOrder) {
      return res.status(404).json({ 
        success: false,
        message: 'Work order not found' 
      });
    }
    
    await WorkOrder.updateStatus(db, req.params.id, status);
    
    // Get updated work order
    const updatedWorkOrder = await WorkOrder.getById(db, req.params.id);
    
    res.json({
      success: true,
      data: updatedWorkOrder
    });
  } catch (error) {
    handleError(res, error, 'PUT /work-orders/:id/status');
  }
});


/**
 * @route   POST /api/work-orders/:id/parts/:partIndex/stages
 * @desc    Add a stage to a part in a work order
 * @access  Private (requires manage_work_order_stages permission)
 */
router.post('/:id/parts/:partIndex/stages', validateObjectId, permissionAuth('manage_work_order_stages'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const partIndex = parseInt(req.params.partIndex);
    
    if (isNaN(partIndex)) {
      return res.status(400).json({ 
        success: false,
        message: 'Invalid part index' 
      });
    }
    
    // Check if work order exists
    const workOrder = await WorkOrder.getById(db, req.params.id);
    
    if (!workOrder) {
      return res.status(404).json({ 
        success: false,
        message: 'Work order not found' 
      });
    }
    
    if (!workOrder.parts || partIndex >= workOrder.parts.length) {
      return res.status(404).json({ 
        success: false,
        message: 'Part not found' 
      });
    }
    
    // Verify the stage exists
    if (req.body.stageId) {
      const stage = await db.collection('stages').findOne({ 
        _id: typeof req.body.stageId === 'string' ? 
          new ObjectId(req.body.stageId) : req.body.stageId 
      });
      
      if (!stage) {
        return res.status(404).json({ 
          success: false,
          message: 'Stage not found' 
        });
      }
    }
    
    await WorkOrder.addStage(db, req.params.id, partIndex, req.body);
    
    // Get updated work order
    const updatedWorkOrder = await WorkOrder.getById(db, req.params.id);
    
    res.json({
      success: true,
      data: updatedWorkOrder
    });
  } catch (error) {
    handleError(res, error, 'POST /work-orders/:id/parts/:partIndex/stages');
  }
});

/**
 * @route   PUT /api/work-orders/:id/parts/:partIndex/stages/:stageIndex
 * @desc    Update a stage in a part of a work order
 * @access  Private (requires manage_work_order_stages permission)
 */
router.put('/:id/parts/:partIndex/stages/:stageIndex', validateObjectId, permissionAuth('manage_work_order_stages'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const partIndex = parseInt(req.params.partIndex);
    const stageIndex = parseInt(req.params.stageIndex);
    
    if (isNaN(partIndex) || isNaN(stageIndex)) {
      return res.status(400).json({ 
        success: false,
        message: 'Invalid index parameters' 
      });
    }
    
    // Check if work order exists
    const workOrder = await WorkOrder.getById(db, req.params.id);
    
    if (!workOrder) {
      return res.status(404).json({ 
        success: false,
        message: 'Work order not found' 
      });
    }
    
    if (!workOrder.parts || partIndex >= workOrder.parts.length) {
      return res.status(404).json({ 
        success: false,
        message: 'Part not found' 
      });
    }
    
    const part = workOrder.parts[partIndex];
    
    if (!part.stages || stageIndex >= part.stages.length) {
      return res.status(404).json({ 
        success: false,
        message: 'Stage not found' 
      });
    }
    
    await WorkOrder.updateStage(db, req.params.id, partIndex, stageIndex, req.body);
    
    // Get updated work order
    const updatedWorkOrder = await WorkOrder.getById(db, req.params.id);
    
    // Enhance with stage details for WebSocket event
    await enhanceWorkOrderStages(db, updatedWorkOrder);
    
    // Emit WebSocket event for stage update
    if (req.app.locals.websocket) {
      const updatedStage = updatedWorkOrder.parts[partIndex].stages[stageIndex];
      req.app.locals.websocket.notifyStageUpdated(
        req.params.id, 
        partIndex, 
        stageIndex, 
        updatedStage,
        updatedWorkOrder.work_order_number || updatedWorkOrder.workOrderNumber,
        updatedWorkOrder  // Pass complete work order for enhanced data
      );
    }
    
    res.json({
      success: true,
      data: updatedWorkOrder
    });
  } catch (error) {
    handleError(res, error, 'PUT /work-orders/:id/parts/:partIndex/stages/:stageIndex');
  }
});

/**
 * @route   PUT /api/work-orders/:id/parts/:partIndex/stages/:stageIndex/status
 * @desc    Update the status of a stage in a part of a work order
 * @access  Private (requires update_work_order_stage_status permission)
 */
router.put('/:id/parts/:partIndex/stages/:stageIndex/status', validateObjectId, permissionAuth('update_work_order_stage_status'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const partIndex = parseInt(req.params.partIndex);
    const stageIndex = parseInt(req.params.stageIndex);
    const { status } = req.body;
    
    if (isNaN(partIndex) || isNaN(stageIndex)) {
      return res.status(400).json({ 
        success: false,
        message: 'Invalid index parameters' 
      });
    }
    
    if (!status) {
      return res.status(400).json({ 
        success: false,
        message: 'Status is required' 
      });
    }
    
    // Check if work order exists
    const workOrder = await WorkOrder.getById(db, req.params.id);
    
    if (!workOrder) {
      return res.status(404).json({ 
        success: false,
        message: 'Work order not found' 
      });
    }
    
    if (!workOrder.parts || partIndex >= workOrder.parts.length) {
      return res.status(404).json({ 
        success: false,
        message: 'Part not found' 
      });
    }
    
    const part = workOrder.parts[partIndex];
    
    if (!part.stages || stageIndex >= part.stages.length) {
      return res.status(404).json({ 
        success: false,
        message: 'Stage not found' 
      });
    }
    
    await WorkOrder.updateStageStatus(db, req.params.id, partIndex, stageIndex, status);
    
    // Get updated work order
    const updatedWorkOrder = await WorkOrder.getById(db, req.params.id);
    
    // Enhance with stage details for WebSocket event
    await enhanceWorkOrderStages(db, updatedWorkOrder);
    
    // Emit WebSocket event for stage status update
    if (req.app.locals.websocket) {
      const updatedStage = updatedWorkOrder.parts[partIndex].stages[stageIndex];
      req.app.locals.websocket.notifyStageUpdated(
        req.params.id, 
        partIndex, 
        stageIndex, 
        updatedStage,
        updatedWorkOrder.work_order_number || updatedWorkOrder.workOrderNumber,
        updatedWorkOrder  // Pass complete work order for enhanced data
      );
    }
    
    res.json({
      success: true,
      data: updatedWorkOrder
    });
  } catch (error) {
    handleError(res, error, 'PUT /work-orders/:id/parts/:partIndex/stages/:stageIndex/status');
  }
});

/**
 * @route   POST /api/work-orders/:id/parts/:partIndex/stages/:stageIndex/logs
 * @desc    Add a log entry to a stage in a work order
 * @access  Private (requires manage_work_order_logs permission)
 */
router.post('/:id/parts/:partIndex/stages/:stageIndex/logs', validateObjectId, permissionAuth('manage_work_order_logs'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const partIndex = parseInt(req.params.partIndex);
    const stageIndex = parseInt(req.params.stageIndex);
    
    if (isNaN(partIndex) || isNaN(stageIndex)) {
      return res.status(400).json({ 
        success: false,
        message: 'Invalid index parameters' 
      });
    }
    
    if (!req.body.action) {
      return res.status(400).json({ 
        success: false,
        message: 'Action is required for log entry' 
      });
    }
    
    // Check if work order exists
    const workOrder = await WorkOrder.getById(db, req.params.id);
    
    if (!workOrder) {
      return res.status(404).json({ 
        success: false,
        message: 'Work order not found' 
      });
    }
    
    if (!workOrder.parts || partIndex >= workOrder.parts.length) {
      return res.status(404).json({ 
        success: false,
        message: 'Part not found' 
      });
    }
    
    const part = workOrder.parts[partIndex];
    
    if (!part.stages || stageIndex >= part.stages.length) {
      return res.status(404).json({ 
        success: false,
        message: 'Stage not found' 
      });
    }
    
    await WorkOrder.addLogEntry(db, req.params.id, partIndex, stageIndex, req.body);
    
    // Get updated work order
    const updatedWorkOrder = await WorkOrder.getById(db, req.params.id);
    
    res.json({
      success: true,
      data: updatedWorkOrder
    });
  } catch (error) {
    handleError(res, error, 'POST /work-orders/:id/parts/:partIndex/stages/:stageIndex/logs');
  }
});

/**
 * @route   POST /api/work-orders/:id/parts/cancel
 * @desc    Cancel a part in a work order with approval image
 * @access  Private (requires update_work_order permission)
 */
router.post('/:id/parts/cancel', validateObjectId, permissionAuth('update_work_order'), uploadCancellationImage, async (req, res) => {
  try {
    const db = req.app.locals.db;
    const { reason, partName } = req.body;
    
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'Approval image is required'
      });
    }
    
    if (!partName) {
      return res.status(400).json({
        success: false,
        message: 'Part name is required'
      });
    }
    
    // Check if work order exists
    const workOrder = await WorkOrder.getById(db, req.params.id);
    
    if (!workOrder) {
      return res.status(404).json({
        success: false,
        message: 'Work order not found'
      });
    }
    
    // Create cancellation record with S3 file information
    const cancellationData = {
      workOrderId: new ObjectId(req.params.id),
      partName: partName,
      reason: reason || 'No reason provided',
      approvalImageS3Key: req.file.key,
      approvalImageUrl: req.file.location,
      approvalImageName: req.file.originalname,
      approvalImageSize: req.file.size,
      cancelledBy: req.user.name || req.user.email || 'Unknown',
      cancelledAt: new Date(),
      status: 'cancelled'
    };
    
    // Store cancellation in work order
    await db.collection('work_orders').updateOne(
      { _id: new ObjectId(req.params.id) },
      {
        $push: {
          cancelledParts: cancellationData
        },
        $set: {
          updated_at: new Date()
        }
      }
    );
    
    // Update work order status if all parts are cancelled
    const updatedWorkOrder = await WorkOrder.getById(db, req.params.id);
    
    res.json({
      success: true,
      message: 'Part cancelled successfully',
      data: {
        cancellation: cancellationData,
        workOrder: updatedWorkOrder
      }
    });
    
  } catch (error) {
    // Clean up uploaded file from S3 if there was an error
    if (req.file && req.file.key) {
      try {
        await deleteFromS3(req.file.key);
      } catch (deleteError) {
        console.error('Error deleting S3 file:', deleteError);
      }
    }
    handleError(res, error, 'POST /work-orders/:id/parts/cancel');
  }
});

/**
 * @route   POST /api/work-orders/:id/parts/:partIndex/stages/:stageIndex/error-report
 * @desc    Report an error for a specific stage
 * @access  Private (requires report_stage_error permission)
 */
router.post('/:id/parts/:partIndex/stages/:stageIndex/error-report', validateObjectId, permissionAuth('report_stage_error'), uploadErrorReportImage, async (req, res) => {
  try {
    const db = req.app.locals.db;
    const partIndex = parseInt(req.params.partIndex);
    const stageIndex = parseInt(req.params.stageIndex);
    
    // Debug: Log req.body to see what we're receiving
    console.log('=== DEBUG: req.body ===', req.body);
    console.log('=== DEBUG: req.file ===', req.file);
    
    const {
      problematicStageIndex,
      problematicTechnicianId,
      reportType,
      issueDescription,
      stagesToRedo
    } = req.body || {};

    if (isNaN(partIndex) || isNaN(stageIndex)) {
      return res.status(400).json({ 
        success: false,
        message: 'Invalid index parameters' 
      });
    }

    // Validate required fields
    if (!problematicTechnicianId || !reportType || !issueDescription) {
      return res.status(400).json({ 
        success: false,
        message: 'Missing required fields: problematicTechnicianId, reportType, issueDescription'
      });
    }

    // Validate image upload
    if (!req.file) {
      return res.status(400).json({ 
        success: false,
        message: 'Evidence image is required' 
      });
    }

    // Check if work order exists
    const workOrder = await WorkOrder.getById(db, req.params.id);
    
    if (!workOrder) {
      return res.status(404).json({ 
        success: false,
        message: 'Work order not found' 
      });
    }

    if (!workOrder.parts || partIndex >= workOrder.parts.length) {
      return res.status(404).json({ 
        success: false,
        message: 'Part not found' 
      });
    }

    const part = workOrder.parts[partIndex];
    
    if (!part.stages || stageIndex >= part.stages.length) {
      return res.status(404).json({ 
        success: false,
        message: 'Stage not found' 
      });
    }

    // Get the stage ID for the reported stage
    const reportedStageId = part.stages[stageIndex].stageId;

    // Create error report data with S3 file information
    const errorReportData = {
      workOrderId: new ObjectId(req.params.id),
      partIndex,
      stageIndex,
      reportedStageId: new ObjectId(reportedStageId), // Convert to ObjectId
      problematicStageIndex: parseInt(problematicStageIndex || stageIndex),
      reportingTechnicianId: new ObjectId(req.user.id),
      problematicTechnicianId: new ObjectId(problematicTechnicianId),
      reportType,
      issueDescription,
      imageS3Key: req.file.key,
      imageUrl: req.file.location,
      imageName: req.file.originalname,
      imageSize: req.file.size,
      timestamp: new Date(), // Add required timestamp field
      status: 'pending',
      stagesToRedo: stagesToRedo ? JSON.parse(stagesToRedo).map(s => parseInt(s)) : []
    };

    // DEBUG: Log the exact data being sent to MongoDB
    console.log('=== ERROR REPORT VALIDATION DEBUG ===');
    console.log('Raw form data received:', req.body);
    console.log('File received:', req.file ? req.file.filename : 'NO FILE');
    console.log('Error report data being sent to MongoDB:');
    console.log(JSON.stringify(errorReportData, null, 2));
    console.log('Data types:');
    Object.keys(errorReportData).forEach(key => {
      const value = errorReportData[key];
      console.log(`${key}: ${typeof value} (${value?.constructor?.name || 'null'})`);
      if (key === 'issueDescription') {
        console.log(`issueDescription length: ${value?.length || 0}`);
      }
    });
    console.log('=== END DEBUG ===');

    // Create the error report
    const errorReport = await ErrorReport.create(db, errorReportData);

    // If stages need to be redone, mark them
    if (errorReportData.stagesToRedo.length > 0) {
      await ErrorReport.markStagesForRedo(
        db, 
        req.params.id, 
        partIndex, 
        errorReportData.stagesToRedo
      );
    }

    res.status(201).json({
      success: true,
      message: 'Error report created successfully',
      data: errorReport
    });

  } catch (error) {
    // Enhanced error logging for validation failures
    console.error('=== ERROR REPORT CREATION FAILED ===');
    console.error('Error message:', error.message);
    if (error.errInfo && error.errInfo.details) {
      console.error('MongoDB validation details:', JSON.stringify(error.errInfo.details, null, 2));
    }
    console.error('Full error object:', error);
    console.error('=== END ERROR DEBUG ===');
    
    // Clean up uploaded file from S3 if there was an error
    if (req.file && req.file.key) {
      try {
        await deleteFromS3(req.file.key);
      } catch (deleteError) {
        console.error('Error deleting S3 file:', deleteError);
      }
    }
    handleError(res, error, 'POST /work-orders/:id/parts/:partIndex/stages/:stageIndex/error-report');
  }
});

/**
 * @route   PUT /api/work-orders/:id/parts/:partIndex/stages/:stageIndex/redo
 * @desc    Mark a stage for redo
 * @access  Private (requires mark_stage_redo permission)
 */
router.put('/:id/parts/:partIndex/stages/:stageIndex/redo', validateObjectId, permissionAuth('mark_stage_redo'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const partIndex = parseInt(req.params.partIndex);
    const stageIndex = parseInt(req.params.stageIndex);

    if (isNaN(partIndex) || isNaN(stageIndex)) {
      return res.status(400).json({ 
        success: false,
        message: 'Invalid index parameters' 
      });
    }

    // Check if work order exists
    const workOrder = await WorkOrder.getById(db, req.params.id);
    
    if (!workOrder) {
      return res.status(404).json({ 
        success: false,
        message: 'Work order not found' 
      });
    }

    if (!workOrder.parts || partIndex >= workOrder.parts.length) {
      return res.status(404).json({ 
        success: false,
        message: 'Part not found' 
      });
    }

    const part = workOrder.parts[partIndex];
    
    if (!part.stages || stageIndex >= part.stages.length) {
      return res.status(404).json({ 
        success: false,
        message: 'Stage not found' 
      });
    }

    // Mark the stage for redo
    await ErrorReport.markStagesForRedo(db, req.params.id, partIndex, [stageIndex]);

    // Get updated work order
    const updatedWorkOrder = await WorkOrder.getById(db, req.params.id);

    res.json({
      success: true,
      message: 'Stage marked for redo successfully',
      data: updatedWorkOrder
    });

  } catch (error) {
    handleError(res, error, 'PUT /work-orders/:id/parts/:partIndex/stages/:stageIndex/redo');
  }
});

/**
 * @route   GET /api/work-orders/:id/parts/:partIndex/stages/:stageIndex/error-report
 * @desc    Get error report for a specific stage
 * @access  Private (requires view_error_reports permission)
 */
router.get('/:id/parts/:partIndex/stages/:stageIndex/error-report', validateObjectId, permissionAuth('view_error_reports'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const partIndex = parseInt(req.params.partIndex);
    const stageIndex = parseInt(req.params.stageIndex);

    if (isNaN(partIndex) || isNaN(stageIndex)) {
      return res.status(400).json({ 
        success: false,
        message: 'Invalid index parameters' 
      });
    }

    // Check if work order exists
    const workOrder = await WorkOrder.getById(db, req.params.id);
    
    if (!workOrder) {
      return res.status(404).json({ 
        success: false,
        message: 'Work order not found' 
      });
    }

    if (!workOrder.parts || partIndex >= workOrder.parts.length) {
      return res.status(404).json({ 
        success: false,
        message: 'Part not found' 
      });
    }

    const part = workOrder.parts[partIndex];
    
    if (!part.stages || stageIndex >= part.stages.length) {
      return res.status(404).json({ 
        success: false,
        message: 'Stage not found' 
      });
    }

    // Query for error report matching this specific stage
    const errorReport = await db.collection('error_reports').findOne({
      workOrderId: new ObjectId(req.params.id),
      partIndex: partIndex,
      stageIndex: stageIndex
    });

    if (!errorReport) {
      return res.status(404).json({
        success: false,
        message: 'No error report found for this stage'
      });
    }

    // Generate signed URL for the error report image if it has an S3 key
    if (errorReport.imageS3Key) {
      try {
        const signedUrl = await getSignedUrl(errorReport.imageS3Key, 3600); // 1 hour expiry
        errorReport.imageSignedUrl = signedUrl;
      } catch (urlError) {
        console.error('Error generating signed URL:', urlError);
        // Continue without the signed URL if there's an error
      }
    }

    // Get additional details if needed (technician names, etc.)
    if (errorReport.reportingTechnicianId) {
      const reportingTech = await db.collection('users').findOne(
        { _id: errorReport.reportingTechnicianId },
        { projection: { name: 1, email: 1 } }
      );
      if (reportingTech) {
        errorReport.reportingTechnician = reportingTech;
      }
    }

    if (errorReport.problematicTechnicianId) {
      const problematicTech = await db.collection('users').findOne(
        { _id: errorReport.problematicTechnicianId },
        { projection: { name: 1, email: 1 } }
      );
      if (problematicTech) {
        errorReport.problematicTechnician = problematicTech;
      }
    }

    res.json({
      success: true,
      data: errorReport
    });

  } catch (error) {
    handleError(res, error, 'GET /work-orders/:id/parts/:partIndex/stages/:stageIndex/error-report');
  }
});

/**
 * @route   GET /api/work-orders/:id/error-summary
 * @desc    Get error summary for a work order
 * @access  Private (requires view_error_reports permission)
 */
router.get('/:id/error-summary', validateObjectId, permissionAuth('view_error_reports'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    
    // Check if work order exists
    const workOrder = await WorkOrder.getById(db, req.params.id);
    
    if (!workOrder) {
      return res.status(404).json({ 
        success: false,
        message: 'Work order not found' 
      });
    }

    const summary = await ErrorReport.getErrorSummary(db, req.params.id);

    res.json({
      success: true,
      data: summary
    });

  } catch (error) {
    handleError(res, error, 'GET /work-orders/:id/error-summary');
  }
});

/**
 * @route   GET /api/work-orders/:id/cancellation-approval/view
 * @desc    Get signed URL for cancellation approval image
 * @access  Private (requires view_work_order permission)
 */
router.get('/:id/cancellation-approval/view', validateObjectId, permissionAuth('view_work_order'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const workOrderId = new ObjectId(req.params.id);
    const redirect = req.query.redirect !== 'false';

    // Find the work order
    const workOrder = await db.collection('work_orders').findOne({ _id: workOrderId });
    
    if (!workOrder) {
      return res.status(404).json({
        success: false,
        message: 'Work order not found'
      });
    }

    // Find cancellation approval image
    const cancelledPart = workOrder.cancelledParts?.find(part => part.approvalImageS3Key);
    
    if (!cancelledPart || !cancelledPart.approvalImageS3Key) {
      return res.status(404).json({
        success: false,
        message: 'No cancellation approval image found'
      });
    }

    // Generate signed URL
    const signedUrl = await getSignedUrl(cancelledPart.approvalImageS3Key, 3600); // 1 hour

    if (redirect) {
      return res.redirect(302, signedUrl);
    } else {
      return res.json({
        success: true,
        data: {
          signedUrl,
          fileName: cancelledPart.approvalImageName,
          fileSize: cancelledPart.approvalImageSize
        }
      });
    }

  } catch (error) {
    handleError(res, error, 'GET /work-orders/:id/cancellation-approval/view');
  }
});


module.exports = router;