const express = require('express');
const router = express.Router();
const { ObjectId } = require('mongodb');
const { Invoice } = require('../models');
const permissionAuth = require('../middleware/permissionAuth');
const { generateInvoicePDF, generateInvoicePDFFromDB } = require('../utils/pdfGenerator');
const { generateCarJobPDFFromDB } = require('../utils/carJobPdfGenerator');
const { createS3Upload, createS3MultiUpload, getSignedUrl, deleteMultipleFromS3 } = require('../middleware/s3Upload');

// Middleware to check if ObjectId is valid
const validateObjectId = (req, res, next) => {
  const id = req.params.id;
  
  if (!ObjectId.isValid(id)) {
    return res.status(400).json({ message: 'Invalid ID format' });
  }
  
  next();
};

/**
 * @route   POST /api/invoices
 * @desc    Create a new invoice with optional image upload
 * @access  Private (requires create_invoice permission)
 */
router.post('/', 
  permissionAuth('create_invoice'), 
  createS3MultiUpload({
    folderName: 'invoices',
    allowedTypes: /jpeg|jpg|png|gif|webp/,
    allowedMimeTypes: /image\/.*/,
    maxSize: 10 * 1024 * 1024, // 10MB limit for images
    fieldName: 'images',
    maxCount: 5
  }),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      // Remove reference fields from payment records if provided - they will be auto-generated
      const invoiceData = { ...req.body };
      if (invoiceData.payment_records && Array.isArray(invoiceData.payment_records)) {
        invoiceData.payment_records = invoiceData.payment_records.map(payment => {
          const { reference, ...paymentWithoutRef } = payment;
          return paymentWithoutRef;
        });
      }
      
      // Add image data to images array if files were uploaded
      if (req.files && req.files.length > 0) {
        // Initialize images array if it doesn't exist
        if (!invoiceData.images) {
          invoiceData.images = [];
        }
        
        // Add all uploaded images
        req.files.forEach(file => {
          const imageData = {
            url: file.location,
            key: file.key,
            filename: file.originalname,
            size: file.size,
            upload_date: new Date()
          };
          invoiceData.images.push(imageData);
        });
      }
      
      const invoice = await Invoice.create(db, invoiceData);
      
      res.status(201).json(invoice);
    } catch (error) {
      // Clean up uploaded files from S3 if there was an error
      if (req.files && req.files.length > 0) {
        try {
          const fileKeys = req.files.map(file => file.key);
          await deleteMultipleFromS3(fileKeys);
        } catch (deleteError) {
          console.error('Error deleting S3 files:', deleteError);
        }
      }
      
      console.error('Invoice creation route error:', error);
      
      if (error.name === 'MongoServerError' && error.code === 121) {
        // This is a document validation error
        return res.status(400).json({
          message: 'Document failed validation',
          details: error.errInfo ? error.errInfo.details : 'Validation error'
        });
      }
      
      res.status(500).json({ message: error.message });
    }
  }
);

/**
 * @route   GET /api/invoices
 * @desc    Get all invoices with optional filters
 * @access  Private (requires view_all_invoices permission)
 */
router.get('/', permissionAuth('view_all_invoices'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const { customer_id, branch_id, invoice_number, date_from, date_to, work_order_id } = req.query;
    
    // Build query object
    const query = {};
    
    if (customer_id) {
      query.customer_id = new ObjectId(customer_id);
    }
    
    if (branch_id) {
      query.branch_id = new ObjectId(branch_id);
    }
    
    if (invoice_number) {
      query.invoice_number = invoice_number;
    }
    
    if (date_from || date_to) {
      query.invoice_date = {};
      
      if (date_from) {
        query.invoice_date.$gte = new Date(date_from);
      }
      
      if (date_to) {
        query.invoice_date.$lte = new Date(date_to);
      }
    }
    
    if (work_order_id) {
      query.work_order_id = new ObjectId(work_order_id);
    }
    
    const invoices = await db.collection('invoices').find(query).toArray();
    
    res.json(invoices);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/invoices/list
 * @desc    Get formatted invoice list with customer and vehicle details
 * @access  Private (requires view_all_invoices permission)
 */
router.get('/list', permissionAuth('view_all_invoices'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const { customer_id, branch_id, invoice_number, date_from, date_to, work_order_id, customer_phone, limit, offset } = req.query;
    
    // Build query object (same as existing filter logic)
    const query = {};
    
    // Handle customer phone number search
    if (customer_phone) {
      // Find customers with matching phone number
      const customersWithPhone = await db.collection('customers').find({
        phone: { $regex: customer_phone, $options: 'i' }
      }).toArray();
      
      if (customersWithPhone.length > 0) {
        const customerIds = customersWithPhone.map(customer => customer._id);
        query.customer_id = { $in: customerIds };
      } else {
        // If no customers found with this phone number, return empty result
        return res.json({
          invoices: [],
          pagination: {
            total: 0,
            limit: parseInt(limit) || 50,
            offset: parseInt(offset) || 0,
            hasMore: false
          }
        });
      }
    } else if (customer_id) {
      // Only apply customer_id filter if customer_phone is not provided
      query.customer_id = new ObjectId(customer_id);
    }
    
    if (branch_id) {
      query.branch_id = new ObjectId(branch_id);
    }
    
    if (invoice_number) {
      query.invoice_number = invoice_number;
    }
    
    if (date_from || date_to) {
      query.invoice_date = {};
      
      if (date_from) {
        query.invoice_date.$gte = new Date(date_from);
      }
      
      if (date_to) {
        query.invoice_date.$lte = new Date(date_to);
      }
    }
    
    if (work_order_id) {
      query.work_order_id = new ObjectId(work_order_id);
    }

    // Apply pagination if provided
    const limitNum = parseInt(limit) || 50; // Default to 50 results
    const offsetNum = parseInt(offset) || 0;
    
    // Get invoices with pagination
    const invoices = await db.collection('invoices')
      .find(query)
      .sort({ created_at: -1 }) // Most recent first
      .skip(offsetNum)
      .limit(limitNum)
      .toArray();

    // Get total count for pagination
    const totalCount = await db.collection('invoices').countDocuments(query);
    
    // Process each invoice to add customer and vehicle details
    const processedInvoices = await Promise.all(
      invoices.map(async (invoice) => {
        try {
          // Get customer details
          const customer = await db.collection('customers').findOne({ 
            _id: invoice.customer_id 
          });
          
          // Get vehicle details from customer's vehicles array
          let vehicle = null;
          if (customer && customer.vehicles && invoice.vehicle_id) {
            vehicle = customer.vehicles.find(v => v.vehicle_id === invoice.vehicle_id);
          }

          // Calculate payment status
          const totalPaid = invoice.payment_records?.reduce((sum, payment) => sum + payment.amount, 0) || 0;
          const totalPrice = invoice.total_price || invoice.price; // Use stored total_price, fallback to price
          const remainingBalance = totalPrice - totalPaid;
          
          let paymentStatus = 'UNPAID';
          if (totalPaid > 0) {
            if (remainingBalance <= 0) {
              paymentStatus = 'PAID';
            } else {
              paymentStatus = 'PARTIAL';
            }
          }

          // Format customer name
          let customerName = 'Unknown Customer';
          if (customer) {
            if (customer.first_name && customer.last_name) {
              customerName = `${customer.first_name} ${customer.last_name}`;
            } else if (customer.name) {
              customerName = customer.name;
            } else if (customer.first_name) {
              customerName = customer.first_name;
            } else if (customer.last_name) {
              customerName = customer.last_name;
            }
          }

          // Format car info
          let carInfo = 'Vehicle Not Found';
          if (vehicle) {
            carInfo = `${vehicle.make} ${vehicle.model} (${vehicle.year})`;
          }

          // Format license plate
          const licensePlate = vehicle?.license_plate || 'N/A';

          return {
            invoice_id: invoice._id,
            invoice_number: invoice.invoice_number,
            license_plate: licensePlate,
            customer: customerName,
            customer_id: invoice.customer_id,
            car_info: carInfo,
            total: parseFloat((invoice.total_price || invoice.price).toFixed(2)),
            price_before_vat: parseFloat((invoice.price_before_vat || invoice.price).toFixed(2)),
            vat_amount: parseFloat((invoice.vat_amount || 0).toFixed(2)),
            vat_percentage: invoice.vat || 0,
            is_taxed: invoice.isTaxed !== undefined ? invoice.isTaxed : true,
            total_paid: parseFloat(totalPaid.toFixed(2)),
            real_value: parseFloat((invoice.real_value || 0).toFixed(2)),
            remaining_balance: parseFloat(remainingBalance.toFixed(2)),
            payment_status: paymentStatus,
            payment_count: invoice.payment_records?.length || 0,
            created_at: invoice.created_at,
            invoice_date: invoice.invoice_date,
            vehicle_id: invoice.vehicle_id,
            work_order_id: invoice.work_order_id || null
          };
        } catch (error) {
          // Return basic invoice info if processing fails
          return {
            invoice_id: invoice._id,
            invoice_number: invoice.invoice_number,
            license_plate: 'Error',
            customer: 'Error Loading Customer',
            customer_id: invoice.customer_id,
            car_info: 'Error Loading Vehicle',
            total: parseFloat((invoice.total_price || invoice.price).toFixed(2)),
            price_before_vat: parseFloat((invoice.price_before_vat || invoice.price).toFixed(2)),
            vat_amount: parseFloat((invoice.vat_amount || 0).toFixed(2)),
            vat_percentage: invoice.vat || 0,
            is_taxed: invoice.isTaxed !== undefined ? invoice.isTaxed : true,
            total_paid: 0,
            real_value: parseFloat((invoice.real_value || 0).toFixed(2)),
            remaining_balance: parseFloat((invoice.total_price || invoice.price).toFixed(2)),
            payment_status: 'UNKNOWN',
            payment_count: 0,
            created_at: invoice.created_at,
            invoice_date: invoice.invoice_date,
            vehicle_id: invoice.vehicle_id,
            work_order_id: invoice.work_order_id || null
          };
        }
      })
    );

    res.json({
      invoices: processedInvoices,
      pagination: {
        total: totalCount,
        limit: limitNum,
        offset: offsetNum,
        hasMore: offsetNum + limitNum < totalCount
      }
    });
    
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/invoices/:id
 * @desc    Get an invoice by ID with signed URLs for images
 * @access  Private (requires view_invoice permission)
 */
router.get('/:id', validateObjectId, permissionAuth('view_invoice'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const invoice = await Invoice.getByIdWithSignedUrls(db, req.params.id);
    
    if (!invoice) {
      return res.status(404).json({ message: 'Invoice not found' });
    }
    
    res.json(invoice);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/invoices/number/:invoice_number
 * @desc    Get an invoice by invoice number with signed URLs for images
 * @access  Private (requires view_invoice permission)
 */
router.get('/number/:invoice_number', permissionAuth('view_invoice'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const invoice = await Invoice.getByInvoiceNumber(db, req.params.invoice_number);
    
    if (!invoice) {
      return res.status(404).json({ message: 'Invoice not found' });
    }

    // Generate signed URLs for the invoice
    const invoiceWithSignedUrls = await Invoice.generateSignedUrlsForInvoice(invoice);
    
    res.json(invoiceWithSignedUrls);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   PUT /api/invoices/:id
 * @desc    Update an invoice
 * @access  Private (requires update_invoice permission)
 */
router.put('/:id', validateObjectId, permissionAuth('update_invoice'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    
    // Get the invoice to make sure it exists
    const invoice = await Invoice.getById(db, req.params.id);
    
    if (!invoice) {
      return res.status(404).json({ message: 'Invoice not found' });
    }
    
    // Update invoice
    const result = await Invoice.updateById(db, req.params.id, req.body);
    
    // Get updated invoice
    const updatedInvoice = await Invoice.getById(db, req.params.id);
    
    res.json(updatedInvoice);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   DELETE /api/invoices/:id
 * @desc    Delete an invoice
 * @access  Private (requires delete_invoice permission)
 */
router.delete('/:id', validateObjectId, permissionAuth('delete_invoice'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    
    // Check if invoice exists
    const invoice = await Invoice.getById(db, req.params.id);
    
    if (!invoice) {
      return res.status(404).json({ message: 'Invoice not found' });
    }
    
    await Invoice.deleteById(db, req.params.id);
    
    res.json({ message: 'Invoice deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   POST /api/invoices/:id/payments
 * @desc    Add a payment record to an invoice
 * @access  Private (requires manage_payments permission)
 */
router.post('/:id/payments', validateObjectId, permissionAuth('manage_payments'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    
    // Check if invoice exists
    const invoice = await Invoice.getById(db, req.params.id);
    
    if (!invoice) {
      return res.status(404).json({ message: 'Invoice not found' });
    }
    
    // Remove reference from request body if provided - it will be auto-generated
    const { reference, ...paymentData } = req.body;
    
    await Invoice.addPaymentRecord(db, req.params.id, paymentData);
    
    // Get updated invoice
    const updatedInvoice = await Invoice.getById(db, req.params.id);
    
    res.json(updatedInvoice);
  } catch (error) {
    console.error('Error adding payment record:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   PUT /api/invoices/:id/payments/:index
 * @desc    Update a payment record in an invoice
 * @access  Private (requires manage_payments permission)
 */
router.put('/:id/payments/:index', validateObjectId, permissionAuth('manage_payments'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const index = parseInt(req.params.index);
    
    if (isNaN(index)) {
      return res.status(400).json({ message: 'Invalid payment index' });
    }
    
    // Check if invoice exists
    const invoice = await Invoice.getById(db, req.params.id);
    
    if (!invoice) {
      return res.status(404).json({ message: 'Invoice not found' });
    }
    
    if (!invoice.payment_records || index >= invoice.payment_records.length) {
      return res.status(404).json({ message: 'Payment record not found' });
    }
    
    // Remove reference from request body if provided - it will be auto-generated if needed
    const { reference, ...updateData } = req.body;
    
    await Invoice.updatePaymentRecord(db, req.params.id, index, updateData);
    
    // Get updated invoice
    const updatedInvoice = await Invoice.getById(db, req.params.id);
    
    res.json(updatedInvoice);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   DELETE /api/invoices/:id/payments/:index
 * @desc    Delete a payment record from an invoice
 * @access  Private (requires manage_payments permission)
 */
router.delete('/:id/payments/:index', validateObjectId, permissionAuth('manage_payments'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const index = parseInt(req.params.index);
    
    if (isNaN(index)) {
      return res.status(400).json({ message: 'Invalid payment index' });
    }
    
    // Check if invoice exists
    const invoice = await Invoice.getById(db, req.params.id);
    
    if (!invoice) {
      return res.status(404).json({ message: 'Invoice not found' });
    }
    
    if (!invoice.payment_records || index >= invoice.payment_records.length) {
      return res.status(404).json({ message: 'Payment record not found' });
    }
    
    await Invoice.removePaymentRecord(db, req.params.id, index);
    
    // Get updated invoice
    const updatedInvoice = await Invoice.getById(db, req.params.id);
    
    res.json(updatedInvoice);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   POST /api/invoices/:id/images
 * @desc    Add an image to an invoice
 * @access  Private (requires manage_invoice_images permission)
 */
router.post('/:id/images', validateObjectId, permissionAuth('manage_invoice_images'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    
    // Check if invoice exists
    const invoice = await Invoice.getById(db, req.params.id);
    
    if (!invoice) {
      return res.status(404).json({ message: 'Invoice not found' });
    }
    
    await Invoice.addImage(db, req.params.id, req.body);
    
    // Get updated invoice
    const updatedInvoice = await Invoice.getById(db, req.params.id);
    
    res.json(updatedInvoice);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   DELETE /api/invoices/:id/images
 * @desc    Remove an image from an invoice
 * @access  Private (requires manage_invoice_images permission)
 */
router.delete('/:id/images', validateObjectId, permissionAuth('manage_invoice_images'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const { imageUrl } = req.body;
    
    if (!imageUrl) {
      return res.status(400).json({ message: 'Image URL is required' });
    }
    
    // Check if invoice exists
    const invoice = await Invoice.getById(db, req.params.id);
    
    if (!invoice) {
      return res.status(404).json({ message: 'Invoice not found' });
    }
    
    await Invoice.removeImage(db, req.params.id, imageUrl);
    
    // Get updated invoice
    const updatedInvoice = await Invoice.getById(db, req.params.id);
    
    res.json(updatedInvoice);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/invoices/customer/:customerId
 * @desc    Get all invoices for a specific customer
 * @access  Private (requires view_invoice permission)
 */
router.get('/customer/:customerId', validateObjectId, permissionAuth('view_invoice'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const invoices = await Invoice.getByCustomerId(db, req.params.customerId);
    
    res.json(invoices);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/invoices/branch/:branchId
 * @desc    Get all invoices for a specific branch
 * @access  Private (requires view_invoice permission)
 */
router.get('/branch/:branchId', validateObjectId, permissionAuth('view_invoice'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const invoices = await Invoice.getByBranchId(db, req.params.branchId);
    
    res.json(invoices);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/invoices/:id/customer
 * @desc    Get the customer information linked to an invoice
 * @access  Private (requires view_invoice permission)
 */
router.get('/:id/customer', validateObjectId, permissionAuth('view_invoice'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const invoice = await Invoice.getById(db, req.params.id);

    if (!invoice) {
      return res.status(404).json({ message: 'Invoice not found' });
    }

    if (!invoice.customer_id) {
      return res.status(404).json({ message: 'Customer not linked to this invoice' });
    }

    const customer = await db.collection('customers').findOne({ _id: new ObjectId(invoice.customer_id) });

    if (!customer) {
      return res.status(404).json({ message: 'Customer not found' });
    }

    res.json(customer);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/invoices/:id/work-order
 * @desc    Get the work order information linked to an invoice
 * @access  Private (requires view_invoice permission)
 */
router.get('/:id/work-order', validateObjectId, permissionAuth('view_invoice'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const invoice = await Invoice.getById(db, req.params.id);

    if (!invoice) {
      return res.status(404).json({ message: 'Invoice not found' });
    }

    if (!invoice.work_order_id) {
      return res.status(404).json({ message: 'No work order linked to this invoice' });
    }

    const workOrder = await db.collection('work_orders').findOne({ _id: new ObjectId(invoice.work_order_id) });

    if (!workOrder) {
      return res.status(404).json({ message: 'Work order not found' });
    }

    res.json(workOrder);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/invoices/:id/pdf
 * @desc    Generate a PDF version of an invoice
 * @access  Private (requires view_invoice permission)
 */
router.get('/:id/pdf', validateObjectId, permissionAuth('view_invoice'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    
    // Get the invoice
    const invoice = await Invoice.getById(db, req.params.id);
    
    if (!invoice) {
      return res.status(404).json({ message: 'Invoice not found' });
    }
    
    // Generate the PDF using the utility function that fetches all required data
    // Pass the isTaxed flag to determine if it's a tax invoice or job order
    await generateInvoicePDFFromDB(db, req.params.id, res, invoice.isTaxed);
  } catch (error) {
      res.status(500).json({ message: error.message });
    }
});

/**
 * @route   GET /api/invoices/:id/service-routes
 * @desc    Get service routes for an invoice - shows which services are applied to which parts
 * @access  Private (requires view_invoice permission)
 */
router.get('/:id/service-routes', validateObjectId, permissionAuth('view_invoice'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const invoice = await Invoice.getById(db, req.params.id);

    if (!invoice) {
      return res.status(404).json({ message: 'Invoice not found' });
    }

    if (!invoice.work_order_id) {
      return res.status(404).json({ message: 'No work order linked to this invoice' });
    }

    // Get the work order
    const workOrder = await db.collection('work_orders').findOne({ _id: new ObjectId(invoice.work_order_id) });

    if (!workOrder) {
      return res.status(404).json({ message: 'Work order not found' });
    }

    // Build service routes data
    const serviceRoutes = [];
    const cancelledServices = [];

    if (workOrder.parts && workOrder.parts.length > 0) {
      for (const part of workOrder.parts) {
        // Handle different possible variation ID field names
        let variationId = part.variationId || part.variation_id || part.serviceId || part.service_id;
        
        if (variationId) {
          // Ensure variationId is an ObjectId
          if (typeof variationId === 'string') {
            try {
              variationId = new ObjectId(variationId);
            } catch (error) {
              variationId = null;
            }
          }
          
          if (variationId) {
            // Get variation (service) details
            const variation = await db.collection('variations').findOne({ _id: variationId });
            
            if (variation) {
              // Get stage details for this part
              const stageDetails = [];
              
              if (part.stages && part.stages.length > 0) {
                for (const stage of part.stages) {
                  let stageId = stage.stageId || stage.stage_id;
                  
                  if (stageId) {
                    if (typeof stageId === 'string') {
                      try {
                        stageId = new ObjectId(stageId);
                      } catch (error) {
                        continue;
                      }
                    }
                    
                    const stageInfo = await db.collection('stages').findOne({ _id: stageId });
                    if (stageInfo) {
                      stageDetails.push({
                        stageId: stage.stageId || stage.stage_id,
                        stageName: stageInfo.name,
                        stageDescription: stageInfo.description,
                        stageOrder: stageInfo.order,
                        status: stage.status,
                        assignedTo: stage.assignedTo || stage.assigned_to,
                        startedAt: stage.startedAt || stage.started_at,
                        completedAt: stage.completedAt || stage.completed_at
                      });
                    }
                  }
                }
                
                // Sort stages by order
                stageDetails.sort((a, b) => a.stageOrder - b.stageOrder);
              }

              serviceRoutes.push({
                partName: part.partName || part.part_name || 'Unknown Part',
                partStatus: part.status || 'unknown',
                assignedTo: part.assignedTo || part.assigned_to,
                service: {
                  code: variation.code,
                  description: variation.description,
                  defaultLaborHours: variation.defaultLaborHours || variation.default_labor_hours
                },
                stages: stageDetails,
                createdAt: part.createdAt || part.created_at,
                updatedAt: part.updatedAt || part.updated_at
              });
            } else {
              // Add entry even if variation not found, for debugging
              serviceRoutes.push({
                partName: part.partName || part.part_name || 'Unknown Part',
                partStatus: part.status || 'unknown',
                assignedTo: part.assignedTo || part.assigned_to,
                service: {
                  code: 'UNKNOWN',
                  description: 'Service not found',
                  defaultLaborHours: 0
                },
                stages: [],
                createdAt: part.createdAt || part.created_at,
                updatedAt: part.updatedAt || part.updated_at,
                debug: {
                  variationId: variationId,
                  originalPart: part
                }
              });
            }
          }
        } else {
          // Add entry for parts without variation ID
          serviceRoutes.push({
            partName: part.partName || part.part_name || 'Unknown Part',
            partStatus: part.status || 'unknown',
            assignedTo: part.assignedTo || part.assigned_to,
            service: {
              code: 'NO_SERVICE',
              description: 'No service linked',
              defaultLaborHours: 0
            },
            stages: [],
            createdAt: part.createdAt || part.created_at,
            updatedAt: part.updatedAt || part.updated_at,
            debug: {
              message: 'No variation ID found',
              originalPart: part
            }
          });
        }
      }
    }

    // Process cancelled parts if they exist
    if (workOrder.cancelledParts && workOrder.cancelledParts.length > 0) {
      for (const cancelledPart of workOrder.cancelledParts) {
        cancelledServices.push({
          partName: cancelledPart.partName,
          partStatus: 'cancelled',
          reason: cancelledPart.reason,
          cancelledBy: cancelledPart.cancelledBy,
          cancelledAt: cancelledPart.cancelledAt,
          approvalImageUrl: cancelledPart.approvalImageUrl
        });
      }
    }

    // Response data
    const response = {
      invoice: {
        id: invoice._id,
        invoiceNumber: invoice.invoice_number,
        workOrderId: invoice.work_order_id
      },
      workOrder: {
        id: workOrder._id,
        workOrderNumber: workOrder.workOrderNumber,
        status: workOrder.status,
        description: workOrder.description
      },
      serviceRoutes: serviceRoutes,
      cancelledServices: cancelledServices,
      summary: {
        totalParts: serviceRoutes.length,
        totalServices: [...new Set(serviceRoutes.map(sr => sr.service.code))].length,
        totalCancelledParts: cancelledServices.length,
        partsByStatus: serviceRoutes.reduce((acc, sr) => {
          acc[sr.partStatus] = (acc[sr.partStatus] || 0) + 1;
          return acc;
        }, {})
      }
    };

    res.json(response);    } catch (error) {
      res.status(500).json({ message: error.message });
    }
});

/**
 * @route   POST /api/invoices/:id/external-services
 * @desc    Add an external service to an invoice with invoice image upload
 * @access  Private (requires manage_external_services permission)
 */
router.post('/:id/external-services', 
  validateObjectId, 
  permissionAuth('manage_external_services'), 
  createS3Upload({
    folderName: 'invoice-external-services',
    allowedTypes: /jpeg|jpg|png|pdf/,
    allowedMimeTypes: /image\/.*|application\/pdf/,
    maxSize: 5 * 1024 * 1024, // 5MB limit for invoice images
    fieldName: 'invoiceImage'
  }),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const { cost, profit, notes } = req.body;
      
      // Validate required fields
      if (!cost || !profit) {
        return res.status(400).json({ 
          message: 'Cost and profit are required fields' 
        });
      }
      
      // Validate that cost and profit are valid numbers
      if (isNaN(parseFloat(cost)) || isNaN(parseFloat(profit))) {
        return res.status(400).json({ 
          message: 'Cost and profit must be valid numbers' 
        });
      }
      
      if (parseFloat(cost) < 0 || parseFloat(profit) < 0) {
        return res.status(400).json({ 
          message: 'Cost and profit must be non-negative values' 
        });
      }
      
      // Check if invoice exists
      const invoice = await Invoice.getById(db, req.params.id);
      
      if (!invoice) {
        return res.status(404).json({ message: 'Invoice not found' });
      }
      
      // Prepare service data
      const serviceData = {
        cost,
        profit,
        notes: notes || ''
      };
      
      // Add invoice image data if file was uploaded
      if (req.file) {
        serviceData.invoice_image = {
          url: req.file.location,
          key: req.file.key,
          filename: req.file.originalname,
          size: req.file.size
        };
      }
      
      // Add external service to invoice
      const result = await Invoice.addExternalService(db, req.params.id, serviceData, req.user._id);
      
      // Get updated invoice
      const updatedInvoice = await Invoice.getById(db, req.params.id);
      
      res.status(201).json({
        message: 'External service added successfully',
        invoice: updatedInvoice,
        expense_id: result.expense_id
      });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  }
);

/**
 * @route   DELETE /api/invoices/:id/external-services/:index
 * @desc    Remove an external service from an invoice
 * @access  Private (requires manage_external_services permission)
 */
router.delete('/:id/external-services/:index', 
  validateObjectId, 
  permissionAuth('manage_external_services'), 
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const serviceIndex = parseInt(req.params.index);
      
      // Validate service index
      if (isNaN(serviceIndex) || serviceIndex < 0) {
        return res.status(400).json({ 
          message: 'Invalid service index' 
        });
      }
      
      // Remove external service from invoice (including S3 image deletion)
      await Invoice.removeExternalService(db, req.params.id, serviceIndex);
      
      // Get updated invoice
      const updatedInvoice = await Invoice.getById(db, req.params.id);
      
      res.json({
        message: 'External service removed successfully',
        invoice: updatedInvoice
      });
    } catch (error) {
      if (error.message === 'Invoice not found') {
        return res.status(404).json({ message: 'Invoice not found' });
      }
      
      if (error.message.includes('Invalid service index')) {
        return res.status(400).json({ message: error.message });
      }
      
      res.status(500).json({ message: error.message });
    }
  }
);

/**
 * @route   PUT /api/invoices/:id/recalculate-total
 * @desc    Recalculate invoice total including all external services
 * @access  Private (requires manage_external_services permission)
 */
router.put('/:id/recalculate-total', 
  validateObjectId, 
  permissionAuth('manage_external_services'), 
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      // Recalculate invoice total
      await Invoice.recalculateTotal(db, req.params.id);
      
      // Get updated invoice
      const updatedInvoice = await Invoice.getById(db, req.params.id);
      
      res.json({
        message: 'Invoice total recalculated successfully',
        invoice: updatedInvoice
      });
    } catch (error) {
      if (error.message === 'Invoice not found') {
        return res.status(404).json({ message: 'Invoice not found' });
      }
      
      res.status(500).json({ message: error.message });
    }
  }
);

/**
 * @route   GET /api/invoices/:id/external-services/:index/image
 * @desc    Get a signed URL to view an external service image
 * @access  Private (requires view_external_services permission)
 */
router.get('/:id/external-services/:index/image', 
  validateObjectId, 
  permissionAuth('view_external_services'), 
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const serviceIndex = parseInt(req.params.index);
      
      // Validate service index
      if (isNaN(serviceIndex) || serviceIndex < 0) {
        return res.status(400).json({ 
          message: 'Invalid service index' 
        });
      }
      
      // Get the invoice
      const invoice = await Invoice.getById(db, req.params.id);
      
      if (!invoice) {
        return res.status(404).json({ message: 'Invoice not found' });
      }
      
      // Check if external services exist
      if (!invoice.external_services || serviceIndex >= invoice.external_services.length) {
        return res.status(404).json({ 
          message: 'External service not found' 
        });
      }
      
      const externalService = invoice.external_services[serviceIndex];
      
      // Check if the service has an image
      if (!externalService.invoice_image || !externalService.invoice_image.key) {
        return res.status(404).json({ 
          message: 'No image found for this external service' 
        });
      }
      
      // Generate signed URL for the image
      try {
        const signedUrl = await getSignedUrl(externalService.invoice_image.key, 3600); // 1 hour expiry
        
        res.json({
          success: true,
          message: 'Signed URL generated successfully',
          data: {
            signedUrl: signedUrl,
            filename: externalService.invoice_image.filename,
            uploadDate: externalService.invoice_image.upload_date,
            expiresIn: 3600 // seconds
          }
        });
      } catch (urlError) {
        res.status(500).json({ 
          message: 'Failed to generate image URL' 
        });
      }
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  }
);

/**
 * @route   POST /api/invoices/:id/signed-invoice
 * @desc    Upload a signed invoice document to an invoice
 * @access  Private (requires manage_signed_invoices permission)
 */
router.post('/:id/signed-invoice', 
  validateObjectId, 
  permissionAuth('manage_signed_invoices'), 
  createS3Upload({
    folderName: 'signed-invoices',
    allowedTypes: /jpeg|jpg|png|pdf/,
    allowedMimeTypes: /image\/.*|application\/pdf/,
    maxSize: 10 * 1024 * 1024, // 10MB limit for signed invoices
    fieldName: 'signedInvoice'
  }),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      // Check if a file was uploaded
      if (!req.file) {
        return res.status(400).json({ 
          message: 'Signed invoice file is required' 
        });
      }
      
      // Check if invoice exists
      const invoice = await Invoice.getById(db, req.params.id);
      
      if (!invoice) {
        return res.status(404).json({ message: 'Invoice not found' });
      }
      
      // Prepare signed invoice data
      const signedInvoiceData = {
        url: req.file.location,
        key: req.file.key,
        filename: req.file.originalname,
        size: req.file.size
      };
      
      // Add signed invoice to invoice
      await Invoice.addSignedInvoice(db, req.params.id, signedInvoiceData);
      
      // Get updated invoice
      const updatedInvoice = await Invoice.getById(db, req.params.id);
      
      res.status(201).json({
        message: 'Signed invoice uploaded successfully',
        invoice: updatedInvoice
      });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  }
);

/**
 * @route   DELETE /api/invoices/:id/signed-invoice
 * @desc    Remove a signed invoice document from an invoice
 * @access  Private (requires manage_signed_invoices permission)
 */
router.delete('/:id/signed-invoice', 
  validateObjectId, 
  permissionAuth('manage_signed_invoices'), 
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      // Check if invoice exists
      const invoice = await Invoice.getById(db, req.params.id);
      
      if (!invoice) {
        return res.status(404).json({ message: 'Invoice not found' });
      }
      
      if (!invoice.signed_invoice) {
        return res.status(404).json({ message: 'No signed invoice found' });
      }
      
      // Remove signed invoice from invoice
      await Invoice.removeSignedInvoice(db, req.params.id);
      
      // Get updated invoice
      const updatedInvoice = await Invoice.getById(db, req.params.id);
      
      res.json({
        message: 'Signed invoice removed successfully',
        invoice: updatedInvoice
      });
    } catch (error) {
      if (error.message === 'Invoice not found') {
        return res.status(404).json({ message: 'Invoice not found' });
      }
      
      if (error.message === 'No signed invoice found') {
        return res.status(404).json({ message: 'No signed invoice found' });
      }
      
      res.status(500).json({ message: error.message });
    }
  }
);

/**
 * @route   GET /api/invoices/:id/signed-invoice/view
 * @desc    Get a signed URL to view the signed invoice document
 * @access  Private (requires view_signed_invoices permission)
 */
router.get('/:id/signed-invoice/view', 
  validateObjectId, 
  permissionAuth('view_signed_invoices'), 
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      // Get the invoice
      const invoice = await Invoice.getById(db, req.params.id);
      
      if (!invoice) {
        return res.status(404).json({ message: 'Invoice not found' });
      }
      
      // Check if the invoice has a signed invoice
      if (!invoice.signed_invoice || !invoice.signed_invoice.key) {
        return res.status(404).json({ 
          message: 'No signed invoice found' 
        });
      }
      
      // Generate signed URL for the signed invoice
      try {
        const signedUrl = await getSignedUrl(invoice.signed_invoice.key, 3600); // 1 hour expiry
        
        res.json({
          success: true,
          message: 'Signed URL generated successfully',
          data: {
            signedUrl: signedUrl,
            filename: invoice.signed_invoice.filename,
            uploadDate: invoice.signed_invoice.upload_date,
            size: invoice.signed_invoice.size,
            expiresIn: 3600 // seconds
          }
        });
      } catch (urlError) {
        res.status(500).json({ 
          message: 'Failed to generate signed invoice URL' 
        });
      }
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  }
);

/**
 * @route   GET /api/invoices/:id/signed-invoice/download
 * @desc    Get a signed URL to download the signed invoice document
 * @access  Private (requires view_signed_invoices permission)
 */
router.get('/:id/signed-invoice/download', 
  validateObjectId, 
  permissionAuth('view_signed_invoices'), 
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      // Get the invoice
      const invoice = await Invoice.getById(db, req.params.id);
      
      if (!invoice) {
        return res.status(404).json({ message: 'Invoice not found' });
      }
      
      // Check if the invoice has a signed invoice
      if (!invoice.signed_invoice || !invoice.signed_invoice.key) {
        return res.status(404).json({ 
          message: 'No signed invoice found' 
        });
      }
      
      // Generate signed URL for download with content-disposition header
      try {
        const signedUrl = await getSignedUrl(
          invoice.signed_invoice.key, 
          3600, // 1 hour expiry
          {
            ResponseContentDisposition: `attachment; filename="${invoice.signed_invoice.filename}"`
          }
        );
        
        res.json({
          success: true,
          message: 'Download URL generated successfully',
          data: {
            downloadUrl: signedUrl,
            filename: invoice.signed_invoice.filename,
            uploadDate: invoice.signed_invoice.upload_date,
            size: invoice.signed_invoice.size,
            expiresIn: 3600 // seconds
          }
        });
      } catch (urlError) {
        res.status(500).json({ 
          message: 'Failed to generate download URL' 
        });
      }
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  }
);

/**
 * @route   POST /api/invoices/:id/signed-job-order
 * @desc    Upload a signed job order document to an invoice
 * @access  Private (requires manage_signed_invoices permission)
 */
router.post('/:id/signed-job-order', 
  validateObjectId, 
  permissionAuth('manage_signed_invoices'), 
  createS3Upload({
    folderName: 'signed-job-orders',
    allowedTypes: /jpeg|jpg|png|pdf/,
    allowedMimeTypes: /image\/.*|application\/pdf/,
    maxSize: 10 * 1024 * 1024, // 10MB limit for signed job orders
    fieldName: 'signedJobOrder'
  }),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      // Check if a file was uploaded
      if (!req.file) {
        return res.status(400).json({ 
          message: 'Signed job order file is required' 
        });
      }
      
      // Check if invoice exists
      const invoice = await Invoice.getById(db, req.params.id);
      
      if (!invoice) {
        return res.status(404).json({ message: 'Invoice not found' });
      }
      
      // Prepare signed job order data
      const signedJobOrderData = {
        url: req.file.location,
        key: req.file.key,
        filename: req.file.originalname,
        size: req.file.size
      };
      
      // Add signed job order to invoice
      await Invoice.addSignedJobOrder(db, req.params.id, signedJobOrderData);
      
      // Get updated invoice
      const updatedInvoice = await Invoice.getById(db, req.params.id);
      
      res.status(201).json({
        message: 'Signed job order uploaded successfully',
        invoice: updatedInvoice
      });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  }
);

/**
 * @route   DELETE /api/invoices/:id/signed-job-order
 * @desc    Remove a signed job order document from an invoice
 * @access  Private (requires manage_signed_invoices permission)
 */
router.delete('/:id/signed-job-order', 
  validateObjectId, 
  permissionAuth('manage_signed_invoices'), 
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      // Check if invoice exists
      const invoice = await Invoice.getById(db, req.params.id);
      
      if (!invoice) {
        return res.status(404).json({ message: 'Invoice not found' });
      }
      
      if (!invoice.signed_job_order) {
        return res.status(404).json({ message: 'No signed job order found' });
      }
      
      // Remove signed job order from invoice
      await Invoice.removeSignedJobOrder(db, req.params.id);
      
      // Get updated invoice
      const updatedInvoice = await Invoice.getById(db, req.params.id);
      
      res.json({
        message: 'Signed job order removed successfully',
        invoice: updatedInvoice
      });
    } catch (error) {
      if (error.message === 'Invoice not found') {
        return res.status(404).json({ message: 'Invoice not found' });
      }
      
      if (error.message === 'No signed job order found') {
        return res.status(404).json({ message: 'No signed job order found' });
      }
      
      res.status(500).json({ message: error.message });
    }
  }
);

/**
 * @route   GET /api/invoices/:id/signed-job-order/view
 * @desc    Get a signed URL to view the signed job order document
 * @access  Private (requires view_signed_invoices permission)
 */
router.get('/:id/signed-job-order/view', 
  validateObjectId, 
  permissionAuth('view_signed_invoices'), 
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      // Get the invoice
      const invoice = await Invoice.getById(db, req.params.id);
      
      if (!invoice) {
        return res.status(404).json({ message: 'Invoice not found' });
      }
      
      // Check if the invoice has a signed job order
      if (!invoice.signed_job_order || !invoice.signed_job_order.key) {
        return res.status(404).json({ 
          message: 'No signed job order found' 
        });
      }
      
      // Generate signed URL for the signed job order
      try {
        const signedUrl = await getSignedUrl(invoice.signed_job_order.key, 3600); // 1 hour expiry
        
        res.json({
          success: true,
          message: 'Signed URL generated successfully',
          data: {
            signedUrl: signedUrl,
            filename: invoice.signed_job_order.filename,
            uploadDate: invoice.signed_job_order.upload_date,
            size: invoice.signed_job_order.size,
            expiresIn: 3600 // seconds
          }
        });
      } catch (urlError) {
        res.status(500).json({ 
          message: 'Failed to generate signed job order URL' 
        });
      }
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  }
);

/**
 * @route   GET /api/invoices/:id/signed-job-order/download
 * @desc    Get a signed URL to download the signed job order document
 * @access  Private (requires view_signed_invoices permission)
 */
router.get('/:id/signed-job-order/download', 
  validateObjectId, 
  permissionAuth('view_signed_invoices'), 
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      // Get the invoice
      const invoice = await Invoice.getById(db, req.params.id);
      
      if (!invoice) {
        return res.status(404).json({ message: 'Invoice not found' });
      }
      
      // Check if the invoice has a signed job order
      if (!invoice.signed_job_order || !invoice.signed_job_order.key) {
        return res.status(404).json({ 
          message: 'No signed job order found' 
        });
      }
      
      // Generate signed URL for download with content-disposition header
      try {
        const signedUrl = await getSignedUrl(
          invoice.signed_job_order.key, 
          3600, // 1 hour expiry
          {
            ResponseContentDisposition: `attachment; filename="${invoice.signed_job_order.filename}"`
          }
        );
        
        res.json({
          success: true,
          message: 'Download URL generated successfully',
          data: {
            downloadUrl: signedUrl,
            filename: invoice.signed_job_order.filename,
            uploadDate: invoice.signed_job_order.upload_date,
            size: invoice.signed_job_order.size,
            expiresIn: 3600 // seconds
          }
        });
      } catch (urlError) {
        res.status(500).json({ 
          message: 'Failed to generate signed job order download URL' 
        });
      }
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  }
);

/**
 * @route   GET /api/invoices/:id/images/:index/view
 * @desc    Get a signed URL to view an invoice image
 * @access  Private (requires view_invoice permission)
 */
router.get('/:id/images/:index/view', 
  validateObjectId, 
  permissionAuth('view_invoice'), 
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const imageIndex = parseInt(req.params.index);
      
      // Validate image index
      if (isNaN(imageIndex) || imageIndex < 0) {
        return res.status(400).json({ 
          message: 'Invalid image index' 
        });
      }
      
      // Get the invoice
      const invoice = await Invoice.getById(db, req.params.id);
      
      if (!invoice) {
        return res.status(404).json({ message: 'Invoice not found' });
      }
      
      // Check if images exist
      if (!invoice.images || imageIndex >= invoice.images.length) {
        return res.status(404).json({ 
          message: 'Image not found' 
        });
      }
      
      const image = invoice.images[imageIndex];
      
      // Check if the image has a key (for S3 images)
      if (!image.key) {
        return res.status(404).json({ 
          message: 'Image key not found - this might be a legacy image' 
        });
      }
      
      // Generate signed URL for the image
      try {
        const signedUrl = await getSignedUrl(image.key, 3600); // 1 hour expiry
        
        res.json({
          success: true,
          message: 'Signed URL generated successfully',
          data: {
            signedUrl: signedUrl,
            filename: image.filename,
            uploadDate: image.upload_date,
            size: image.size,
            expiresIn: 3600 // seconds
          }
        });
      } catch (urlError) {
        res.status(500).json({ 
          message: 'Failed to generate image URL' 
        });
      }
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  }
);

/**
 * @route   GET /api/invoices/:id/carjob-pdf
 * @desc    Generate a car job PDF version of an invoice (without invoice/job numbers)
 * @access  Private (requires view_invoice permission)
 */
router.get('/:id/carjob-pdf', validateObjectId, permissionAuth('view_invoice'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    
    // Get the invoice
    const invoice = await Invoice.getById(db, req.params.id);
    
    if (!invoice) {
      return res.status(404).json({ message: 'Invoice not found' });
    }
    
    // Generate the car job PDF using the dedicated car job PDF generator
    await generateCarJobPDFFromDB(db, req.params.id, res);
  } catch (error) {
    console.error('Car job PDF generation error:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   PUT /api/invoices/:id/add-tax
 * @desc    Add tax (VAT) to an invoice
 * @access  Private (requires update_invoice permission)
 */
router.put('/:id/add-tax', validateObjectId, permissionAuth('update_invoice'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const invoiceId = req.params.id;
    const { vatPercentage } = req.body || {};
    
    // Validate VAT percentage if provided
    if (vatPercentage !== undefined && vatPercentage !== null) {
      if (typeof vatPercentage !== 'number' || vatPercentage < 0 || vatPercentage > 100) {
        return res.status(400).json({ 
          message: 'VAT percentage must be a number between 0 and 100' 
        });
      }
    }
    
    // Check if invoice exists
    const existingInvoice = await Invoice.getById(db, invoiceId);
    if (!existingInvoice) {
      return res.status(404).json({ message: 'Invoice not found' });
    }
    
    // Check if invoice is already taxed
    // Consider invoice as already taxed if isTaxed is explicitly true
    if (existingInvoice.isTaxed === true) {
      return res.status(400).json({ 
        message: 'Invoice is already taxed. Use recalculate-tax endpoint to update VAT percentage.' 
      });
    }
    
    // Add tax to the invoice - default to 5% if not provided
    const result = await Invoice.addTax(db, invoiceId, vatPercentage || 5);
    
    if (result.modifiedCount === 0) {
      return res.status(400).json({ message: 'Failed to add tax to invoice' });
    }
    
    // Get the updated invoice
    const updatedInvoice = await Invoice.getById(db, invoiceId);
    
    res.status(200).json({
      success: true,
      message: 'Tax added to invoice successfully',
      data: {
        invoice_id: invoiceId,
        vat_percentage: updatedInvoice.vat,
        vat_amount: updatedInvoice.vat_amount,
        total_price: updatedInvoice.total_price,
        is_taxed: updatedInvoice.isTaxed
      }
    });
  } catch (error) {
    console.error('Add tax error:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   PUT /api/invoices/:id/remove-tax
 * @desc    Remove tax (VAT) from an invoice
 * @access  Private (requires update_invoice permission)
 */
router.put('/:id/remove-tax', validateObjectId, permissionAuth('update_invoice'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const invoiceId = req.params.id;
    
    // Check if invoice exists
    const existingInvoice = await Invoice.getById(db, invoiceId);
    if (!existingInvoice) {
      return res.status(404).json({ message: 'Invoice not found' });
    }
    
    // Check if invoice has tax to remove
    // Consider invoice as taxed if isTaxed is true OR if it has VAT amount > 0
    const hasTax = existingInvoice.isTaxed === true || 
                   (existingInvoice.vat_amount && existingInvoice.vat_amount > 0);
    
    if (!hasTax) {
      return res.status(400).json({ 
        message: 'Invoice is already non-taxed or has no tax to remove' 
      });
    }
    
    // Remove tax from the invoice
    const result = await Invoice.removeTax(db, invoiceId);
    
    if (result.modifiedCount === 0) {
      return res.status(400).json({ message: 'Failed to remove tax from invoice' });
    }
    
    // Get the updated invoice
    const updatedInvoice = await Invoice.getById(db, invoiceId);
    
    res.status(200).json({
      success: true,
      message: 'Tax removed from invoice successfully',
      data: {
        invoice_id: invoiceId,
        vat_amount: updatedInvoice.vat_amount,
        total_price: updatedInvoice.total_price,
        is_taxed: updatedInvoice.isTaxed
      }
    });
  } catch (error) {
    console.error('Remove tax error:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   PUT /api/invoices/:id/update-information
 * @desc    Update invoice information with automatic subtotal and total recalculation when price changes
 * @access  Private (requires update_invoice permission)
 */
router.put('/:id/update-information', validateObjectId, permissionAuth('update_invoice'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const invoiceId = req.params.id;
    
    // Check if invoice exists
    const existingInvoice = await Invoice.getById(db, invoiceId);
    if (!existingInvoice) {
      return res.status(404).json({ message: 'Invoice not found' });
    }
    
    // Extract allowed fields for update
    const {
      price,
      vat,
      isTaxed,
      invoice_date,
      expected_delivery_date,
      notes,
      special_requests,
      real_value,
      ratio
    } = req.body;
    
    // Prepare update data
    const updateData = {};
    
    // Only include fields that are provided
    if (price !== undefined) {
      if (isNaN(parseFloat(price)) || parseFloat(price) < 0) {
        return res.status(400).json({ 
          message: 'Price must be a valid non-negative number' 
        });
      }
      updateData.price = parseFloat(price);
    }
    
    if (vat !== undefined) {
      if (isNaN(parseFloat(vat)) || parseFloat(vat) < 0 || parseFloat(vat) > 100) {
        return res.status(400).json({ 
          message: 'VAT must be a number between 0 and 100' 
        });
      }
      updateData.vat = parseFloat(vat);
    }
    
    if (isTaxed !== undefined) {
      if (typeof isTaxed !== 'boolean' && !['true', 'false'].includes(String(isTaxed).toLowerCase())) {
        return res.status(400).json({ 
          message: 'isTaxed must be a boolean value' 
        });
      }
      updateData.isTaxed = typeof isTaxed === 'boolean' ? isTaxed : String(isTaxed).toLowerCase() === 'true';
    }
    
    if (invoice_date !== undefined) {
      const parsedDate = new Date(invoice_date);
      if (isNaN(parsedDate.getTime())) {
        return res.status(400).json({ 
          message: 'Invoice date must be a valid date' 
        });
      }
      updateData.invoice_date = parsedDate;
    }
    
    if (expected_delivery_date !== undefined) {
      const parsedDate = new Date(expected_delivery_date);
      if (isNaN(parsedDate.getTime())) {
        return res.status(400).json({ 
          message: 'Expected delivery date must be a valid date' 
        });
      }
      updateData.expected_delivery_date = parsedDate;
    }
    
    if (notes !== undefined) {
      updateData.notes = String(notes);
    }
    
    if (special_requests !== undefined) {
      updateData.special_requests = String(special_requests);
    }
    
    if (real_value !== undefined) {
      if (isNaN(parseFloat(real_value)) || parseFloat(real_value) < 0) {
        return res.status(400).json({ 
          message: 'Real value must be a valid non-negative number' 
        });
      }
      updateData.real_value = parseFloat(real_value);
    }
    
    if (ratio !== undefined) {
      if (isNaN(parseFloat(ratio))) {
        return res.status(400).json({ 
          message: 'Ratio must be a valid number' 
        });
      }
      updateData.ratio = parseFloat(ratio);
    }
    
    // If no valid fields provided, return error
    if (Object.keys(updateData).length === 0) {
      return res.status(400).json({ 
        message: 'No valid fields provided for update' 
      });
    }
    
    // Calculate subtotal and total if price, VAT, or isTaxed is being updated
    if (updateData.price !== undefined || updateData.vat !== undefined || updateData.isTaxed !== undefined) {
      const newPrice = updateData.price !== undefined ? updateData.price : parseFloat(existingInvoice.price || 0);
      const vatPercentage = updateData.vat !== undefined ? updateData.vat : (existingInvoice.vat || 0);
      const isTaxedValue = updateData.isTaxed !== undefined ? updateData.isTaxed : existingInvoice.isTaxed;
      
      // Set subtotal (price before VAT) - this is the base price
      updateData.price_before_vat = newPrice;
      updateData.price = newPrice; // Ensure price field is also updated
      
      // Calculate VAT amount and total price
      if (isTaxedValue && vatPercentage > 0) {
        const vatAmount = (newPrice * vatPercentage) / 100;
        updateData.vat_amount = parseFloat(vatAmount.toFixed(2));
        updateData.total_price = parseFloat((newPrice + vatAmount).toFixed(2));
        updateData.total = parseFloat((newPrice + vatAmount).toFixed(2)); // Also update 'total' field
      } else {
        updateData.vat_amount = 0;
        updateData.total_price = parseFloat(newPrice.toFixed(2));
        updateData.total = parseFloat(newPrice.toFixed(2)); // Also update 'total' field
      }
      
      // Also update the subtotal field if it exists (for compatibility)
      updateData.subtotal = newPrice;
    }
    
    // Update all fields with calculated values
    const result = await db.collection('invoices').updateOne(
      { _id: new ObjectId(invoiceId) },
      { 
        $set: {
          ...updateData,
          updated_at: new Date()
        }
      },
      { bypassDocumentValidation: true } // Bypass validation for information updates
    );
    
    if (result.modifiedCount === 0) {
      return res.status(400).json({ 
        message: 'Failed to update invoice information' 
      });
    }
    
    // Get the updated invoice with all calculated fields
    const updatedInvoice = await Invoice.getById(db, invoiceId);
    
    // Calculate payment status for response based on subtotal (price before VAT)
    const subtotal = parseFloat(updatedInvoice.price_before_vat || updatedInvoice.price || 0);
    const totalPaid = updatedInvoice.payment_records?.reduce((sum, payment) => sum + payment.amount, 0) || 0;
    const subtotalRemainingBalance = subtotal - totalPaid;
    
    // Also calculate based on total price for comprehensive info
    const totalPrice = parseFloat(updatedInvoice.total_price || 0);
    const totalRemainingBalance = totalPrice - totalPaid;
    
    let paymentStatus = 'UNPAID';
    if (totalPaid > 0) {
      if (subtotalRemainingBalance <= 0) {
        paymentStatus = 'PAID';
      } else {
        paymentStatus = 'PARTIAL';
      }
    }
    
    res.status(200).json({
      success: true,
      message: 'Invoice information updated successfully',
      data: {
        invoice_id: invoiceId,
        invoice_number: updatedInvoice.invoice_number,
        subtotal: parseFloat(subtotal.toFixed(2)),
        price_before_vat: parseFloat(subtotal.toFixed(2)),
        vat_percentage: updatedInvoice.vat || 0,
        vat_amount: parseFloat(updatedInvoice.vat_amount?.toFixed(2) || 0),
        total_price: parseFloat(updatedInvoice.total_price?.toFixed(2) || 0),
        is_taxed: updatedInvoice.isTaxed,
        real_value: updatedInvoice.real_value ? parseFloat(updatedInvoice.real_value.toFixed(2)) : null,
        ratio: updatedInvoice.ratio || null,
        payment_status: paymentStatus,
        total_paid: parseFloat(totalPaid.toFixed(2)),
        subtotal_remaining_balance: parseFloat(subtotalRemainingBalance.toFixed(2)),
        total_remaining_balance: parseFloat(totalRemainingBalance.toFixed(2)),
        payment_records: updatedInvoice.payment_records || [],
        payment_count: updatedInvoice.payment_records?.length || 0,
        external_services_count: updatedInvoice.external_services?.length || 0,
        external_services_total: updatedInvoice.external_services?.reduce((total, service) => {
          return total + (parseFloat(service.cost) || 0) + (parseFloat(service.profit) || 0);
        }, 0) || 0,
        updated_at: updatedInvoice.updated_at,
        payment_calculation_info: {
          note: "Payment calculations are based on subtotal (price before VAT)",
          subtotal_used_for_payments: parseFloat(subtotal.toFixed(2)),
          payment_coverage_percentage: subtotal > 0 ? parseFloat(((totalPaid / subtotal) * 100).toFixed(2)) : 0
        }
      }
    });
  } catch (error) {
    console.error('Update invoice information error:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   POST /api/invoices/quotation-pdf
 * @desc    Generate a quotation PDF without saving to database
 * @access  Private (requires create_invoice permission)
 */
router.post('/quotation-pdf', permissionAuth('create_invoice'), async (req, res) => {
  try {
    const quotationData = req.body;

    // Validate required fields
    if (!quotationData.customer_info || !quotationData.vehicle_info || !quotationData.price) {
      return res.status(400).json({
        message: 'Missing required fields: customer_info, vehicle_info, price'
      });
    }

    // Create temporary quotation object
    const quotationInvoice = {
      ...quotationData,
      invoice_number: `QUOT-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      invoice_date: new Date(),
      isQuotation: true,
      external_services: quotationData.external_services || [] // Pass through external services
    };

    // Extract customer and branch info
    const customer = quotationData.customer_info;
    const branch = quotationData.branch_info || null;

    // Determine if taxed
    const isTaxed = quotationData.with_tax || false;

    // Format parts_with_services into serviceRoutesData structure
    let serviceRoutesData = null;
    if (quotationData.parts_with_services && quotationData.parts_with_services.length > 0) {
      serviceRoutesData = {
        serviceRoutes: quotationData.parts_with_services.map(part => ({
          partName: part.part_name,
          serviceName: part.service_type || '',
          notes: part.notes || ''
        })),
        summary: {
          totalParts: quotationData.parts_with_services.length,
          totalServices: quotationData.parts_with_services.filter(p => p.service_type).length,
          totalCancelledParts: 0
        },
        cancelledServices: []
      };
    }

    // Use regular PDF generator but with quotation data and service routes
    await generateInvoicePDF(quotationInvoice, customer, branch, res, serviceRoutesData, isTaxed, true);
  } catch (error) {
    console.error('Quotation PDF generation error:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   POST /api/invoices/quotation-carjob-pdf
 * @desc    Generate a car job quotation PDF without saving to database
 * @access  Private (requires create_invoice permission)
 */
router.post('/quotation-carjob-pdf', permissionAuth('create_invoice'), async (req, res) => {
  try {
    const quotationData = req.body;

    // Validate required fields
    if (!quotationData.customer_info || !quotationData.vehicle_info || !quotationData.price) {
      return res.status(400).json({
        message: 'Missing required fields: customer_info, vehicle_info, price'
      });
    }

    // Create temporary quotation object
    const quotationInvoice = {
      ...quotationData,
      invoice_number: `QUOT-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      invoice_date: new Date(),
      isQuotation: true,
      external_services: quotationData.external_services || [] // Pass through external services
    };

    // Extract customer and branch info
    const customer = quotationData.customer_info;
    const branch = quotationData.branch_info || null;

    // Format parts_with_services into serviceRoutesData structure
    let serviceRoutesData = null;
    if (quotationData.parts_with_services && quotationData.parts_with_services.length > 0) {
      serviceRoutesData = {
        serviceRoutes: quotationData.parts_with_services.map(part => ({
          partName: part.part_name,
          serviceName: part.service_type || '',
          notes: part.notes || ''
        })),
        summary: {
          totalParts: quotationData.parts_with_services.length,
          totalServices: quotationData.parts_with_services.filter(p => p.service_type).length,
          totalCancelledParts: 0
        },
        cancelledServices: []
      };
    }

    // Use car job PDF generator but with quotation data and service routes
    const { generateCarJobPDF } = require('../utils/carJobPdfGenerator');
    await generateCarJobPDF(quotationInvoice, customer, branch, res, serviceRoutesData, true);
  } catch (error) {
    console.error('Car job quotation PDF generation error:', error);
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;