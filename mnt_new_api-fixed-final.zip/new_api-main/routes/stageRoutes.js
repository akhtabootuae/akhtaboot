const express = require('express');
const router = express.Router();
const { ObjectId } = require('mongodb');

// Middleware
const auth = require('../middleware/auth');
const adminAuth = require('../middleware/adminAuth');
const permissionAuth = require('../middleware/permissionAuth');

// Import Stage model
const { Stage } = require('../models');

/**
 * @route   GET /api/stages
 * @desc    Get all stages
 * @access  Private
 */
router.get('/', auth, async (req, res) => {
  try {
    const stages = await Stage.getAll(req.app.locals.db);
    res.json({ success: true, data: stages });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   GET /api/stages/:id
 * @desc    Get stage by ID
 * @access  Private
 */
router.get('/:id', auth, async (req, res) => {
  try {
    const stage = await Stage.getById(req.app.locals.db, req.params.id);
    
    if (!stage) {
      return res.status(404).json({ message: 'Stage not found' });
    }
    
    res.json(stage);
  } catch (err) {
    if (err.name === 'BSONTypeError') {
      return res.status(400).json({ message: 'Invalid stage ID format' });
    }
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   POST /api/stages
 * @desc    Create a new stage
 * @access  Admin or users with manage_stages permission
 */
router.post('/', permissionAuth('manage_stages'), async (req, res) => {
  try {
    const { name, description, order } = req.body;

    // Basic validation
    if (!name || !description || order === undefined) {
      return res.status(400).json({ message: 'Name, description, and order are required' });
    }

    // Validate that order is an integer
    if (!Number.isInteger(order)) {
      return res.status(400).json({ message: 'Order must be an integer' });
    }

    // Create stage
    const newStage = await Stage.create(req.app.locals.db, {
      name,
      description,
      order
    });

    res.status(201).json(newStage);
  } catch (err) {
    if (err.code === 121) { // MongoDB validation error code
      return res.status(400).json({ 
        message: 'Validation error', 
        details: err.errInfo?.details?.schemaRulesNotSatisfied 
      });
    }
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   PUT /api/stages/:id
 * @desc    Update a stage
 * @access  Admin or users with manage_stages permission
 */
router.put('/:id', permissionAuth('manage_stages'), async (req, res) => {
  try {
    const { name, description, order } = req.body;

    // Basic validation
    if (!name && !description && order === undefined) {
      return res.status(400).json({ message: 'At least one field is required to update' });
    }

    // Validate that order is an integer if provided
    if (order !== undefined && !Number.isInteger(order)) {
      return res.status(400).json({ message: 'Order must be an integer' });
    }

    // Check if stage exists
    const stage = await Stage.getById(req.app.locals.db, req.params.id);
    if (!stage) {
      return res.status(404).json({ message: 'Stage not found' });
    }

    // Prepare update data
    const updateData = {};
    if (name) updateData.name = name;
    if (description) updateData.description = description;
    if (order !== undefined) updateData.order = order;

    // Update stage
    const updatedStage = await Stage.update(req.app.locals.db, req.params.id, updateData);

    res.json(updatedStage);
  } catch (err) {
    if (err.name === 'BSONTypeError') {
      return res.status(400).json({ message: 'Invalid stage ID format' });
    }
    if (err.code === 121) { // MongoDB validation error code
      return res.status(400).json({ 
        message: 'Validation error', 
        details: err.errInfo?.details?.schemaRulesNotSatisfied 
      });
    }
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   DELETE /api/stages/:id
 * @desc    Delete a stage
 * @access  Admin or users with manage_stages permission
 */
router.delete('/:id', permissionAuth('manage_stages'), async (req, res) => {
  try {
    // Check if stage is used in any variations
    const variations = await req.app.locals.db.collection('variations').find({
      defaultStages: new ObjectId(req.params.id)
    }).toArray();

    if (variations.length > 0) {
      return res.status(400).json({
        message: 'Cannot delete stage that is used in variations',
        variations: variations.map(v => ({ _id: v._id, code: v.code }))
      });
    }

    // Delete stage
    const deleted = await Stage.delete(req.app.locals.db, req.params.id);

    if (!deleted) {
      return res.status(404).json({ message: 'Stage not found' });
    }

    res.json({ message: 'Stage deleted successfully' });
  } catch (err) {
    if (err.name === 'BSONTypeError') {
      return res.status(400).json({ message: 'Invalid stage ID format' });
    }
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

module.exports = router;
