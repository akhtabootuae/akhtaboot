const express = require('express');
const router = express.Router();
const CarPart = require('../models/CarPart');

// Get all car parts
router.get('/', async (req, res) => {
  try {
    const carParts = await CarPart.find().sort({ category: 1, name: 1 });
    res.json(carParts);
  } catch (error) {
    console.error('Error fetching car parts:', error);
    res.status(500).json({ error: 'Failed to fetch car parts' });
  }
});

// Get car part by ID
router.get('/:id', async (req, res) => {
  try {
    const carPart = await CarPart.findById(req.params.id);
    if (!carPart) {
      return res.status(404).json({ error: 'Car part not found' });
    }
    res.json(carPart);
  } catch (error) {
    console.error('Error fetching car part:', error);
    res.status(500).json({ error: 'Failed to fetch car part' });
  }
});

// Create new car part
router.post('/', async (req, res) => {
  try {
    const { name, category } = req.body;
    
    // Validate input
    if (!name || !category) {
      return res.status(400).json({ error: 'Name and category are required' });
    }
    
    // Check if a part with the same name and category already exists
    const existingPart = await CarPart.findOne({ name, category });
    if (existingPart) {
      return res.status(400).json({ error: 'A car part with this name already exists in this category' });
    }
    
    const newCarPart = new CarPart({
      name,
      category
    });
    
    const savedCarPart = await newCarPart.save();
    res.status(201).json(savedCarPart);
  } catch (error) {
    console.error('Error creating car part:', error);
    if (error.code === 11000) {
      res.status(400).json({ error: 'A car part with this name already exists in this category' });
    } else {
      res.status(500).json({ error: 'Failed to create car part' });
    }
  }
});

// Update car part
router.put('/:id', async (req, res) => {
  try {
    const { name, category } = req.body;
    
    // Validate input
    if (!name && !category) {
      return res.status(400).json({ error: 'At least one field (name or category) must be provided' });
    }
    
    // Check if part exists
    const carPart = await CarPart.findById(req.params.id);
    if (!carPart) {
      return res.status(404).json({ error: 'Car part not found' });
    }
    
    // Check for duplicates if name or category is being changed
    if (name || category) {
      const checkName = name || carPart.name;
      const checkCategory = category || carPart.category;
      
      const duplicate = await CarPart.findOne({
        name: checkName,
        category: checkCategory,
        _id: { $ne: req.params.id }
      });
      
      if (duplicate) {
        return res.status(400).json({ error: 'A car part with this name already exists in this category' });
      }
    }
    
    // Update fields
    if (name) carPart.name = name;
    if (category) carPart.category = category;
    
    const updatedCarPart = await carPart.save();
    res.json(updatedCarPart);
  } catch (error) {
    console.error('Error updating car part:', error);
    if (error.code === 11000) {
      res.status(400).json({ error: 'A car part with this name already exists in this category' });
    } else {
      res.status(500).json({ error: 'Failed to update car part' });
    }
  }
});

// Delete car part
router.delete('/:id', async (req, res) => {
  try {
    const carPart = await CarPart.findById(req.params.id);
    if (!carPart) {
      return res.status(404).json({ error: 'Car part not found' });
    }
    
    await CarPart.findByIdAndDelete(req.params.id);
    res.json({ message: 'Car part deleted successfully' });
  } catch (error) {
    console.error('Error deleting car part:', error);
    res.status(500).json({ error: 'Failed to delete car part' });
  }
});

// Bulk create car parts (for initial seeding)
router.post('/bulk', async (req, res) => {
  try {
    const { parts } = req.body;
    
    if (!Array.isArray(parts) || parts.length === 0) {
      return res.status(400).json({ error: 'Parts array is required' });
    }
    
    // Filter out duplicates
    const uniqueParts = [];
    for (const part of parts) {
      const exists = await CarPart.findOne({ name: part.name, category: part.category });
      if (!exists) {
        uniqueParts.push(part);
      }
    }
    
    if (uniqueParts.length === 0) {
      return res.json({ message: 'All parts already exist', created: [] });
    }
    
    const createdParts = await CarPart.insertMany(uniqueParts, { ordered: false });
    res.status(201).json({
      message: `Created ${createdParts.length} car parts`,
      created: createdParts
    });
  } catch (error) {
    console.error('Error bulk creating car parts:', error);
    res.status(500).json({ error: 'Failed to create car parts' });
  }
});

module.exports = router;