const express = require('express');
const router = express.Router();
const { ObjectId } = require('mongodb');

// Middleware
const auth = require('../middleware/auth');
const permissionAuth = require('../middleware/permissionAuth');

// Import CustomerReview model
const { CustomerReview } = require('../models');

/**
 * @route   GET /api/customer-reviews
 * @desc    Get all customer reviews with pagination and filtering
 * @access  Admin or users with view_customer_reviews permission
 */
router.get('/', permissionAuth('view_customer_reviews'), async (req, res) => {
  try {
    const { 
      page = 1, 
      limit = 20, 
      rating,
      phone_number,
      sort_by = 'created_at',
      sort_order = 'desc'
    } = req.query;

    // Calculate pagination
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const limitNum = parseInt(limit);

    // Build query filter
    let query = {};
    if (rating) {
      query.rating = parseInt(rating);
    }
    if (phone_number) {
      query.phone_number = { $regex: phone_number, $options: 'i' };
    }

    // Build sort options
    const sortOptions = {};
    sortOptions[sort_by] = sort_order === 'desc' ? -1 : 1;

    // Get reviews with pagination
    const reviews = await req.app.locals.db.collection('customer_reviews')
      .find(query)
      .sort(sortOptions)
      .skip(skip)
      .limit(limitNum)
      .toArray();

    // Get total count for pagination
    const totalReviews = await req.app.locals.db.collection('customer_reviews')
      .countDocuments(query);

    // Calculate pagination info
    const totalPages = Math.ceil(totalReviews / limitNum);
    const hasNextPage = page < totalPages;
    const hasPrevPage = page > 1;

    res.json({
      success: true,
      data: {
        reviews,
        pagination: {
          currentPage: parseInt(page),
          totalPages,
          totalReviews,
          hasNextPage,
          hasPrevPage,
          limit: limitNum
        }
      }
    });

  } catch (error) {
    console.error('Error fetching customer reviews:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching reviews',
      error: error.message
    });
  }
});

/**
 * @route   GET /api/customer-reviews/statistics
 * @desc    Get customer review statistics
 * @access  Admin or users with view_customer_reviews permission
 */
router.get('/statistics', permissionAuth('view_customer_reviews'), async (req, res) => {
  try {
    const statistics = await CustomerReview.getStatistics(req.app.locals.db);
    
    res.json({
      success: true,
      data: statistics
    });

  } catch (error) {
    console.error('Error fetching review statistics:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching statistics',
      error: error.message
    });
  }
});

/**
 * @route   GET /api/customer-reviews/:id
 * @desc    Get customer review by ID
 * @access  Admin or users with view_customer_reviews permission
 */
router.get('/:id', permissionAuth('view_customer_reviews'), async (req, res) => {
  try {
    const { id } = req.params;

    // Validate ObjectId
    if (!ObjectId.isValid(id)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid review ID format'
      });
    }

    const review = await CustomerReview.getById(req.app.locals.db, id);

    if (!review) {
      return res.status(404).json({
        success: false,
        message: 'Review not found'
      });
    }

    res.json({
      success: true,
      data: review
    });

  } catch (error) {
    console.error('Error fetching review:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching review',
      error: error.message
    });
  }
});

/**
 * @route   GET /api/customer-reviews/phone/:phoneNumber
 * @desc    Get reviews by phone number
 * @access  Admin or users with view_customer_reviews permission
 */
router.get('/phone/:phoneNumber', permissionAuth('view_customer_reviews'), async (req, res) => {
  try {
    const { phoneNumber } = req.params;

    const reviews = await CustomerReview.getByPhoneNumber(req.app.locals.db, phoneNumber);

    res.json({
      success: true,
      data: {
        phone_number: phoneNumber,
        reviews,
        total_reviews: reviews.length
      }
    });

  } catch (error) {
    console.error('Error fetching reviews by phone:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching reviews',
      error: error.message
    });
  }
});

/**
 * @route   GET /api/customer-reviews/rating/:rating
 * @desc    Get reviews by rating
 * @access  Admin or users with view_customer_reviews permission
 */
router.get('/rating/:rating', permissionAuth('view_customer_reviews'), async (req, res) => {
  try {
    const { rating } = req.params;
    const ratingNum = parseInt(rating);

    // Validate rating
    if (isNaN(ratingNum) || ratingNum < 1 || ratingNum > 5) {
      return res.status(400).json({
        success: false,
        message: 'Rating must be a number between 1 and 5'
      });
    }

    const reviews = await CustomerReview.getByRating(req.app.locals.db, ratingNum);

    res.json({
      success: true,
      data: {
        rating: ratingNum,
        reviews,
        total_reviews: reviews.length
      }
    });

  } catch (error) {
    console.error('Error fetching reviews by rating:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching reviews',
      error: error.message
    });
  }
});

/**
 * @route   POST /api/customer-reviews
 * @desc    Create a new customer review
 * @access  Public (customers can submit reviews) or users with create_customer_reviews permission
 */
router.post('/', async (req, res) => {
  try {
    const { rating, phone_number, comment, referral } = req.body;

    // Validate required fields - only rating is truly required
    if (!rating) {
      return res.status(400).json({
        success: false,
        message: 'Rating is required'
      });
    }

    // Validate rating range
    const ratingNum = parseInt(rating);
    if (isNaN(ratingNum) || ratingNum < 1 || ratingNum > 5) {
      return res.status(400).json({
        success: false,
        message: 'Rating must be a number between 1 and 5'
      });
    }

    // Set defaults for optional fields
    const finalPhoneNumber = phone_number && phone_number.trim() ? phone_number.trim() : 'anonymous';
    const finalComment = comment && comment.trim() ? comment.trim() : 'No comment provided';

    // Validate phone number format if it's not anonymous
    if (finalPhoneNumber !== 'anonymous') {
      const phoneRegex = /^\+?[1-9]\d{1,14}$/;
      if (!phoneRegex.test(finalPhoneNumber)) {
        return res.status(400).json({
          success: false,
          message: 'Invalid phone number format. Please use international format (e.g., +971501234567) or leave empty for anonymous review'
        });
      }
    }

    // Validate comment length if provided
    if (finalComment && finalComment.length > 1000) {
      return res.status(400).json({
        success: false,
        message: 'Comment cannot exceed 1000 characters'
      });
    }

    // Validate referral field if provided
    let finalReferral = null;
    if (referral && referral.trim()) {
      const trimmedReferral = referral.trim();
      const validOptions = ['Tiktok', 'Instagram', 'Youtube', 'Recommended by a friend'];
      
      // Check if it's one of the predefined options
      if (validOptions.includes(trimmedReferral)) {
        finalReferral = trimmedReferral;
      } 
      // Check if it's a custom option starting with "other:"
      else if (trimmedReferral.startsWith('other:')) {
        const customValue = trimmedReferral.substring(6).trim(); // Remove "other:" prefix
        if (customValue.length === 0) {
          return res.status(400).json({
            success: false,
            message: 'Custom referral value cannot be empty after "other:"'
          });
        }
        if (customValue.length > 100) {
          return res.status(400).json({
            success: false,
            message: 'Custom referral value cannot exceed 100 characters'
          });
        }
        finalReferral = trimmedReferral;
      } 
      else {
        return res.status(400).json({
          success: false,
          message: 'Invalid referral source. Must be one of: Tiktok, Instagram, Youtube, Recommended by a friend, or start with "other:" followed by custom text'
        });
      }
    }

    // Create the review data object
    const reviewData = {
      rating: ratingNum,
      phone_number: finalPhoneNumber,
      comment: finalComment
    };

    // Only add referral if it's provided
    if (finalReferral) {
      reviewData.referral = finalReferral;
    }

    // Create the review
    const newReview = await CustomerReview.create(req.app.locals.db, reviewData);

    res.status(201).json({
      success: true,
      message: 'Review created successfully',
      data: newReview
    });

  } catch (error) {
    console.error('Error creating review:', error);
    
    // Handle MongoDB validation errors
    if (error.name === 'MongoServerError' && error.code === 121) {
      return res.status(400).json({
        success: false,
        message: 'Validation error',
        error: 'Review data failed validation',
        details: error.errInfo ? error.errInfo.details : 'Schema validation failed'
      });
    }
    
    res.status(500).json({
      success: false,
      message: 'Server error while creating review',
      error: error.message
    });
  }
});

/**
 * @route   PUT /api/customer-reviews/:id
 * @desc    Update customer review by ID
 * @access  Admin or users with update_customer_reviews permission
 */
router.put('/:id', permissionAuth('update_customer_reviews'), async (req, res) => {
  try {
    const { id } = req.params;
    const { rating, phone_number, comment, referral } = req.body;

    // Validate ObjectId
    if (!ObjectId.isValid(id)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid review ID format'
      });
    }

    // Check if review exists
    const existingReview = await CustomerReview.getById(req.app.locals.db, id);
    if (!existingReview) {
      return res.status(404).json({
        success: false,
        message: 'Review not found'
      });
    }

    // Validate rating if provided
    if (rating !== undefined) {
      const ratingNum = parseInt(rating);
      if (isNaN(ratingNum) || ratingNum < 1 || ratingNum > 5) {
        return res.status(400).json({
          success: false,
          message: 'Rating must be a number between 1 and 5'
        });
      }
    }

    // Validate phone number if provided
    if (phone_number !== undefined) {
      const phoneRegex = /^\+?[1-9]\d{1,14}$/;
      if (!phoneRegex.test(phone_number)) {
        return res.status(400).json({
          success: false,
          message: 'Invalid phone number format'
        });
      }
    }

    // Validate comment length if provided
    if (comment !== undefined && comment && comment.length > 1000) {
      return res.status(400).json({
        success: false,
        message: 'Comment cannot exceed 1000 characters'
      });
    }

    // Validate referral field if provided
    if (referral !== undefined && referral !== null) {
      if (referral.trim()) {
        const trimmedReferral = referral.trim();
        const validOptions = ['Tiktok', 'Instagram', 'Youtube', 'Recommended by a friend'];
        
        // Check if it's one of the predefined options
        if (!validOptions.includes(trimmedReferral)) {
          // Check if it's a custom option starting with "other:"
          if (trimmedReferral.startsWith('other:')) {
            const customValue = trimmedReferral.substring(6).trim();
            if (customValue.length === 0) {
              return res.status(400).json({
                success: false,
                message: 'Custom referral value cannot be empty after "other:"'
              });
            }
            if (customValue.length > 100) {
              return res.status(400).json({
                success: false,
                message: 'Custom referral value cannot exceed 100 characters'
              });
            }
          } else {
            return res.status(400).json({
              success: false,
              message: 'Invalid referral source. Must be one of: Tiktok, Instagram, Youtube, Recommended by a friend, or start with "other:" followed by custom text'
            });
          }
        }
      }
    }

    // Update the review
    const updateData = {};
    if (rating !== undefined) updateData.rating = parseInt(rating);
    if (phone_number !== undefined) updateData.phone_number = phone_number;
    if (comment !== undefined) updateData.comment = comment;
    if (referral !== undefined) updateData.referral = referral;

    const result = await CustomerReview.updateById(req.app.locals.db, id, updateData);

    if (result.matchedCount === 0) {
      return res.status(404).json({
        success: false,
        message: 'Review not found'
      });
    }

    // Get updated review
    const updatedReview = await CustomerReview.getById(req.app.locals.db, id);

    res.json({
      success: true,
      message: 'Review updated successfully',
      data: updatedReview
    });

  } catch (error) {
    console.error('Error updating review:', error);
    
    // Handle MongoDB validation errors
    if (error.name === 'MongoServerError' && error.code === 121) {
      return res.status(400).json({
        success: false,
        message: 'Validation error',
        error: 'Review data failed validation',
        details: error.errInfo ? error.errInfo.details : 'Schema validation failed'
      });
    }
    
    res.status(500).json({
      success: false,
      message: 'Server error while updating review',
      error: error.message
    });
  }
});

/**
 * @route   DELETE /api/customer-reviews/:id
 * @desc    Delete customer review by ID
 * @access  Admin or users with delete_customer_reviews permission
 */
router.delete('/:id', permissionAuth('delete_customer_reviews'), async (req, res) => {
  try {
    const { id } = req.params;

    // Validate ObjectId
    if (!ObjectId.isValid(id)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid review ID format'
      });
    }

    // Check if review exists
    const existingReview = await CustomerReview.getById(req.app.locals.db, id);
    if (!existingReview) {
      return res.status(404).json({
        success: false,
        message: 'Review not found'
      });
    }

    // Delete the review
    const result = await CustomerReview.deleteById(req.app.locals.db, id);

    if (result.deletedCount === 0) {
      return res.status(404).json({
        success: false,
        message: 'Review not found'
      });
    }

    res.json({
      success: true,
      message: 'Review deleted successfully',
      data: {
        deleted_review_id: id,
        deleted_at: new Date()
      }
    });

  } catch (error) {
    console.error('Error deleting review:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while deleting review',
      error: error.message
    });
  }
});

/**
 * @route   POST /api/customer-reviews/bulk-delete
 * @desc    Delete multiple customer reviews
 * @access  Admin or users with delete_customer_reviews permission
 */
router.post('/bulk-delete', permissionAuth('delete_customer_reviews'), async (req, res) => {
  try {
    const { review_ids } = req.body;

    if (!review_ids || !Array.isArray(review_ids) || review_ids.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Please provide an array of review IDs'
      });
    }

    // Validate all ObjectIds
    const invalidIds = review_ids.filter(id => !ObjectId.isValid(id));
    if (invalidIds.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Invalid review ID format(s)',
        invalid_ids: invalidIds
      });
    }

    // Convert to ObjectIds
    const objectIds = review_ids.map(id => new ObjectId(id));

    // Delete reviews
    const result = await req.app.locals.db.collection('customer_reviews')
      .deleteMany({ _id: { $in: objectIds } });

    res.json({
      success: true,
      message: `Successfully deleted ${result.deletedCount} review(s)`,
      data: {
        requested_deletions: review_ids.length,
        actual_deletions: result.deletedCount,
        deleted_at: new Date()
      }
    });

  } catch (error) {
    console.error('Error bulk deleting reviews:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while deleting reviews',
      error: error.message
    });
  }
});

/**
 * @route   POST /api/customer-reviews/export
 * @desc    Export customer reviews to CSV or JSON
 * @access  Admin or users with view_customer_reviews permission
 */
router.post('/export', permissionAuth('export_customer_reviews'), async (req, res) => {
  try {
    const { 
      format = 'json', 
      filters = {},
      include_statistics = false 
    } = req.body;

    // Validate format
    if (!['json', 'csv'].includes(format.toLowerCase())) {
      return res.status(400).json({
        success: false,
        message: 'Format must be either "json" or "csv"'
      });
    }

    // Build query from filters
    let query = {};
    if (filters.rating) {
      query.rating = parseInt(filters.rating);
    }
    if (filters.phone_number) {
      query.phone_number = { $regex: filters.phone_number, $options: 'i' };
    }
    if (filters.date_from || filters.date_to) {
      query.created_at = {};
      if (filters.date_from) {
        query.created_at.$gte = new Date(filters.date_from);
      }
      if (filters.date_to) {
        query.created_at.$lte = new Date(filters.date_to);
      }
    }

    // Get reviews
    const reviews = await req.app.locals.db.collection('customer_reviews')
      .find(query)
      .sort({ created_at: -1 })
      .toArray();

    let responseData = {
      export_date: new Date(),
      total_reviews: reviews.length,
      filters_applied: filters,
      reviews
    };

    // Include statistics if requested
    if (include_statistics) {
      const statistics = await CustomerReview.getStatistics(req.app.locals.db);
      responseData.statistics = statistics;
    }

    if (format.toLowerCase() === 'csv') {
      // Convert to CSV format
      if (reviews.length === 0) {
        return res.status(200).json({
          success: true,
          message: 'No reviews found matching the criteria',
          data: responseData
        });
      }

      const csvHeaders = ['ID', 'Rating', 'Phone Number', 'Comment', 'Referral', 'Created At', 'Updated At'];
      const csvRows = reviews.map(review => [
        review._id.toString(),
        review.rating,
        review.phone_number,
        review.comment || '',
        review.referral || '',
        review.created_at.toISOString(),
        review.updated_at.toISOString()
      ]);

      const csvContent = [csvHeaders, ...csvRows]
        .map(row => row.map(field => `"${field}"`).join(','))
        .join('\n');

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="customer_reviews_${new Date().toISOString().split('T')[0]}.csv"`);
      return res.send(csvContent);
    }

    // Return JSON format
    res.json({
      success: true,
      data: responseData
    });

  } catch (error) {
    console.error('Error exporting reviews:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while exporting reviews',
      error: error.message
    });
  }
});

/**
 * @route   GET /api/customer-reviews/referral-statistics
 * @desc    Get referral source statistics
 * @access  Admin or users with view_customer_reviews permission
 */
router.get('/referral-statistics', permissionAuth('view_customer_reviews'), async (req, res) => {
  try {
    const pipeline = [
      {
        $match: {
          referral: { $exists: true, $ne: null }
        }
      },
      {
        $group: {
          _id: {
            $cond: {
              if: { $regexMatch: { input: "$referral", regex: "^other:" } },
              then: "Other (Custom)",
              else: "$referral"
            }
          },
          count: { $sum: 1 }
        }
      },
      {
        $sort: { count: -1 }
      }
    ];

    const referralStats = await req.app.locals.db.collection('customer_reviews')
      .aggregate(pipeline)
      .toArray();

    // Get total reviews with referral data
    const totalWithReferral = await req.app.locals.db.collection('customer_reviews')
      .countDocuments({ referral: { $exists: true, $ne: null } });

    // Get total reviews
    const totalReviews = await req.app.locals.db.collection('customer_reviews')
      .countDocuments();

    // Calculate percentages
    const referralData = referralStats.map(stat => ({
      source: stat._id,
      count: stat.count,
      percentage: totalWithReferral > 0 ? Math.round((stat.count / totalWithReferral) * 100) : 0
    }));

    res.json({
      success: true,
      data: {
        total_reviews: totalReviews,
        total_with_referral: totalWithReferral,
        referral_completion_rate: totalReviews > 0 ? Math.round((totalWithReferral / totalReviews) * 100) : 0,
        referral_sources: referralData
      }
    });

  } catch (error) {
    console.error('Error fetching referral statistics:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching referral statistics',
      error: error.message
    });
  }
});

module.exports = router;