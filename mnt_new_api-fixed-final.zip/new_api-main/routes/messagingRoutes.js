const express = require('express');
const router = express.Router();
const { ObjectId } = require('mongodb');
const permissionAuth = require('../middleware/permissionAuth');
const messageEncryption = require('../services/messageEncryption');
const Message = require('../models/Message');
const Conversation = require('../models/Conversation');
const { createS3MultiUpload, getSignedUrl, uploadConfigs, waitForS3Object } = require('../middleware/s3Upload');

/**
 * Helper function to sanitize user data for conversation participants
 */
const sanitizeUserForConversation = (user) => ({
  user_id: user._id,
  name: `${user.first_name} ${user.last_name}`,
  email: user.email,
  branch_name: user.branch?.branch_name || null,
  role_name: user.role_name
});

/**
 * @route   GET /api/messaging/conversations
 * @desc    Get all conversations for the authenticated user
 * @access  Private (requires view_conversation_history permission)
 */
router.get('/conversations', permissionAuth('view_conversation_history'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const userId = req.user._id;
    
    const conversations = await db.collection('conversations')
      .find({
        'participants.user_id': new ObjectId(userId)
      })
      .sort({ updated_at: -1 })
      .toArray();

    res.json({
      success: true,
      data: conversations
    });
  } catch (error) {
    console.error('Error fetching conversations:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch conversations'
    });
  }
});

/**
 * @route   POST /api/messaging/conversations/private
 * @desc    Create or get existing private conversation between two users
 * @access  Private (requires send_messages permission)
 */
router.post('/conversations/private', permissionAuth('send_messages'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const { recipient_id } = req.body;
    const currentUser = req.user;

    if (!recipient_id) {
      return res.status(400).json({
        success: false,
        message: 'recipient_id is required'
      });
    }

    if (recipient_id === currentUser._id.toString()) {
      return res.status(400).json({
        success: false,
        message: 'Cannot create conversation with yourself'
      });
    }

    // Get recipient user data
    const recipient = await db.collection('users').findOne({ 
      _id: new ObjectId(recipient_id),
      is_active: true 
    });

    if (!recipient) {
      return res.status(404).json({
        success: false,
        message: 'Recipient user not found'
      });
    }

    // Check if private conversation already exists between these users
    const existingConversation = await db.collection('conversations').findOne({
      conversation_type: 'private',
      'participants.user_id': { 
        $all: [new ObjectId(currentUser._id), new ObjectId(recipient_id)] 
      }
    });

    if (existingConversation) {
      return res.json({
        success: true,
        data: existingConversation,
        message: 'Existing conversation found'
      });
    }

    // Create new private conversation
    const conversationData = Conversation.createPrivate(currentUser, recipient);
    const validation = Conversation.validate(conversationData);

    if (!validation.isValid) {
      return res.status(400).json({
        success: false,
        message: 'Invalid conversation data',
        errors: validation.errors
      });
    }

    const result = await db.collection('conversations').insertOne(conversationData);
    const newConversation = await db.collection('conversations').findOne({ _id: result.insertedId });

    // Notify users via WebSocket
    if (req.app.locals.websocket) {
      const userIds = [currentUser._id.toString(), recipient_id];
      
      // Notify users of new conversation
      userIds.forEach(userId => {
        req.app.locals.websocket.notifyNewConversation(userId, newConversation);
      });

      // Auto-join users to conversation room
      req.app.locals.websocket.joinUsersToConversation(newConversation._id.toString(), userIds);
    }


    res.status(201).json({
      success: true,
      data: newConversation,
      message: 'Private conversation created successfully'
    });

  } catch (error) {
    console.error('Error creating private conversation:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create private conversation'
    });
  }
});

/**
 * @route   POST /api/messaging/conversations/group
 * @desc    Create a new group conversation
 * @access  Private (requires create_group_conversations permission)
 */
router.post('/conversations/group', permissionAuth('create_group_conversations'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const { title, description, participant_ids = [] } = req.body;
    const currentUser = req.user;

    if (!title) {
      return res.status(400).json({
        success: false,
        message: 'Group title is required'
      });
    }

    if (participant_ids.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'At least one participant is required'
      });
    }

    // Get participant user data
    const participantObjectIds = participant_ids.map(id => new ObjectId(id));
    const participants = await db.collection('users')
      .find({ 
        _id: { $in: participantObjectIds },
        is_active: true 
      })
      .toArray();

    if (participants.length !== participant_ids.length) {
      return res.status(400).json({
        success: false,
        message: 'One or more participants not found'
      });
    }

    // Add current user as group admin if not already in participants
    const currentUserInParticipants = participants.find(p => p._id.toString() === currentUser._id.toString());
    if (!currentUserInParticipants) {
      participants.push(currentUser);
    }

    // Create conversation data
    const participantData = participants.map(user => ({
      ...sanitizeUserForConversation(user),
      joined_at: new Date(),
      is_admin: user._id.toString() === currentUser._id.toString()
    }));

    const conversationData = Conversation.create({
      conversation_type: 'group',
      title,
      description,
      participants: participantData,
      created_by: currentUser._id,
      settings: {
        is_active: true,
        allow_join: true,
        max_participants: 50
      }
    });

    const validation = Conversation.validate(conversationData);
    if (!validation.isValid) {
      return res.status(400).json({
        success: false,
        message: 'Invalid conversation data',
        errors: validation.errors
      });
    }

    const result = await db.collection('conversations').insertOne(conversationData);
    const newConversation = await db.collection('conversations').findOne({ _id: result.insertedId });

    // Notify all participants via WebSocket
    if (req.app.locals.websocket) {
      const userIds = participants.map(p => p._id.toString());
      
      // Notify participants of new conversation
      participants.forEach(participant => {
        req.app.locals.websocket.notifyNewConversation(participant._id.toString(), newConversation);
      });

      // Auto-join participants to conversation room
      req.app.locals.websocket.joinUsersToConversation(newConversation._id.toString(), userIds);
    }


    res.status(201).json({
      success: true,
      data: newConversation,
      message: 'Group conversation created successfully'
    });

  } catch (error) {
    console.error('Error creating group conversation:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create group conversation'
    });
  }
});

/**
 * @route   POST /api/messaging/conversations/announcement
 * @desc    Create an announcement conversation for specific users
 * @access  Private (requires send_announcements permission)
 */
router.post('/conversations/announcement', permissionAuth('send_announcements', { requireSameBranch: false }), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const { title, description, recipient_ids = [], duration_minutes } = req.body;
    const currentUser = req.user;

    if (!title) {
      return res.status(400).json({
        success: false,
        message: 'Announcement title is required'
      });
    }

    if (!recipient_ids || recipient_ids.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'At least one recipient is required for the announcement'
      });
    }

    // Get specific users for announcement based on recipient_ids
    const recipientObjectIds = recipient_ids.map(id => new ObjectId(id));
    const recipients = await db.collection('users')
      .find({ 
        _id: { $in: recipientObjectIds },
        is_active: true 
      })
      .toArray();

    if (recipients.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'No valid active recipients found for announcement'
      });
    }

    if (recipients.length !== recipient_ids.length) {
      return res.status(400).json({
        success: false,
        message: 'Some recipients were not found or are inactive'
      });
    }

    // Include the announcement creator in participants
    const allParticipants = [...recipients];
    const creatorAlreadyIncluded = recipients.find(user => user._id.toString() === currentUser._id.toString());
    if (!creatorAlreadyIncluded) {
      allParticipants.push(currentUser);
    }

    const conversationData = Conversation.createAnnouncement(currentUser, allParticipants, title);
    if (description) {
      conversationData.description = description;
    }

    // Set expiresAt if duration_minutes is provided, otherwise default to 24 hours
    let duration = 24 * 60; // default 24 hours
    if (duration_minutes && !isNaN(duration_minutes) && Number(duration_minutes) > 0) {
      duration = Number(duration_minutes);
    }
    conversationData.expiresAt = new Date(Date.now() + duration * 60 * 1000);

    const validation = Conversation.validate(conversationData);
    if (!validation.isValid) {
      return res.status(400).json({
        success: false,
        message: 'Invalid conversation data',
        errors: validation.errors
      });
    }

    const result = await db.collection('conversations').insertOne(conversationData);
    const newConversation = await db.collection('conversations').findOne({ _id: result.insertedId });

    // Notify all participants via WebSocket
    if (req.app.locals.websocket) {
      const userIds = allParticipants.map(user => user._id.toString());
      // Notify all participants of new announcement
      allParticipants.forEach(user => {
        req.app.locals.websocket.notifyNewConversation(user._id.toString(), newConversation);
      });
      // Auto-join all participants to announcement conversation room
      req.app.locals.websocket.joinUsersToConversation(newConversation._id.toString(), userIds);
    }

    res.status(201).json({
      success: true,
      data: newConversation,
      message: `Announcement created successfully for ${recipients.length} recipient(s)`
    });

  } catch (error) {
    console.error('Error creating announcement conversation:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create announcement conversation'
    });
  }
});

/**
 * @route   GET /api/messaging/conversations/:id/messages
 * @desc    Get messages for a specific conversation
 * @access  Private (requires view_conversation_history permission)
 */
router.get('/conversations/:id/messages', permissionAuth('view_conversation_history'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const conversationId = req.params.id;
    const userId = req.user._id;
    const { page = 1, limit = 50 } = req.query;

    // Validate conversation access
    const conversation = await db.collection('conversations').findOne({
      _id: new ObjectId(conversationId),
      'participants.user_id': new ObjectId(userId)
    });

    if (!conversation) {
      return res.status(404).json({
        success: false,
        message: 'Conversation not found or access denied'
      });
    }

    // Find the current user's participant data to check message visibility settings
    const userParticipant = conversation.participants.find(p => 
      p.user_id.toString() === userId.toString()
    );

    // Build message query
    let messageQuery = {
      conversation_id: new ObjectId(conversationId),
      deleted_at: { $exists: false }
    };

    // If user joined a group and show_previous_messages is false, only show messages after they joined
    if (conversation.conversation_type === 'group' && 
        userParticipant && 
        userParticipant.joined_at && 
        userParticipant.show_previous_messages === false) {
      messageQuery.created_at = { $gte: userParticipant.joined_at };
    }

    // Get messages with pagination
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const messages = await db.collection('messages')
      .find(messageQuery)
      .sort({ created_at: -1 })
      .skip(skip)
      .limit(parseInt(limit))
      .toArray();

    // Decrypt message content and generate signed URLs for media files
    const decryptedMessages = await Promise.all(messages.map(async (message) => {
      try {
        const decryptedMessage = {
          ...message,
          content: messageEncryption.decrypt(message.content_encrypted)
        };

        // Generate signed URL for image and voice note messages
        if ((message.message_type === 'image' || message.message_type === 'voice_note') && message.file_id) {
          try {
            decryptedMessage.signed_url = await getSignedUrl(message.file_id, 86400); // 24 hours
          } catch (error) {
            console.error('Failed to generate signed URL for message:', message._id, error);
            // Don't fail the whole request if one file URL generation fails
            decryptedMessage.signed_url = null;
          }
        }

        return decryptedMessage;
      } catch (error) {
        console.error('Failed to decrypt message:', message._id, error);
        return {
          ...message,
          content: '[Message content unavailable]'
        };
      }
    }));

    // Reverse to show oldest first
    decryptedMessages.reverse();

    res.json({
      success: true,
      data: decryptedMessages,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        hasMore: messages.length === parseInt(limit)
      }
    });

  } catch (error) {
    console.error('Error fetching messages:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch messages'
    });
  }
});

/**
 * @route   POST /api/messaging/conversations/:id/messages
 * @desc    Send a message to a conversation
 * @access  Private (requires send_messages permission)
 */
router.post('/conversations/:id/messages', permissionAuth('send_messages'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const conversationId = req.params.id;
    const { content, message_type = 'text' } = req.body;
    const currentUser = req.user;

    if (!content || content.trim().length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Message content is required'
      });
    }

    if (!messageEncryption.validateContent(content)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid message content or content too long (max 10KB)'
      });
    }

    // Validate conversation access
    const conversation = await db.collection('conversations').findOne({
      _id: new ObjectId(conversationId),
      'participants.user_id': new ObjectId(currentUser._id)
    });

    if (!conversation) {
      return res.status(404).json({
        success: false,
        message: 'Conversation not found or access denied'
      });
    }

    // For announcement conversations, only admins or the creator can send messages
    if (conversation.conversation_type === 'announcement') {
      const isCreator = conversation.created_by.toString() === currentUser._id.toString();
      const isAdmin = currentUser.role_name === 'Admin';
      
      if (!isCreator && !isAdmin) {
        return res.status(403).json({
          success: false,
          message: 'Only administrators can send announcement messages'
        });
      }
    }

    // Encrypt message content
    const encryptedContent = messageEncryption.encrypt(content);

    // Create message
    const messageData = Message.create({
      conversation_id: conversationId,
      sender_id: currentUser._id,
      content_encrypted: encryptedContent,
      message_type,
      sender: {
        name: `${currentUser.first_name} ${currentUser.last_name}`,
        email: currentUser.email,
        branch_name: currentUser.branch?.branch_name
      }
    });

    const validation = Message.validate(messageData);
    if (!validation.isValid) {
      return res.status(400).json({
        success: false,
        message: 'Invalid message data',
        errors: validation.errors
      });
    }

    // Insert message
    const result = await db.collection('messages').insertOne(messageData);
    const newMessage = await db.collection('messages').findOne({ _id: result.insertedId });

    // Update conversation's last_message and updated_at
    const contentPreview = messageEncryption.createPreview(encryptedContent);
    await db.collection('conversations').updateOne(
      { _id: new ObjectId(conversationId) },
      {
        $set: {
          last_message: {
            message_id: result.insertedId,
            content_preview: contentPreview,
            sender_name: `${currentUser.first_name} ${currentUser.last_name}`,
            sent_at: new Date()
          },
          updated_at: new Date()
        }
      }
    );

    // Notify conversation participants via WebSocket
    if (req.app.locals.websocket) {
      req.app.locals.websocket.notifyNewMessage(conversationId, {
        ...newMessage,
        content: content
      }, conversation.participants);
    }

    // Return message with decrypted content
    res.status(201).json({
      success: true,
      data: {
        ...newMessage,
        content: content
      },
      message: 'Message sent successfully'
    });

  } catch (error) {
    console.error('Error sending message:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to send message'
    });
  }
});

/**
 * @route   GET /api/messaging/users/search
 * @desc    Search users for creating conversations
 * @access  Private (requires send_messages permission)
 */
router.get('/users/search', permissionAuth('send_messages'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const { q = '', limit = 20 } = req.query;
    const currentUserId = req.user._id;

    let query = {
      is_active: true,
      _id: { $ne: new ObjectId(currentUserId) } // Exclude current user
    };

    // Add search criteria if provided
    if (q.trim()) {
      const searchRegex = new RegExp(q.trim(), 'i');
      query.$or = [
        { first_name: searchRegex },
        { last_name: searchRegex },
        { email: searchRegex }
      ];
    }

    const users = await db.collection('users')
      .find(query, {
        projection: {
          first_name: 1,
          last_name: 1,
          email: 1,
          branch: 1,
          role_name: 1
        }
      })
      .limit(parseInt(limit))
      .toArray();

    const formattedUsers = users.map(user => ({
      _id: user._id,
      name: `${user.first_name} ${user.last_name}`,
      email: user.email,
      branch_name: user.branch?.branch_name || null,
      role_name: user.role_name
    }));

    res.json({
      success: true,
      data: formattedUsers
    });

  } catch (error) {
    console.error('Error searching users:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to search users'
    });
  }
});

/**
 * @route   POST /api/messaging/conversations/:id/add-user
 * @desc    Add a user to a group conversation
 * @access  Private (requires manage_group_conversations permission or be group admin)
 */
router.post('/conversations/:id/add-user', permissionAuth('manage_group_conversations'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const conversationId = req.params.id;
    const { user_id, show_previous_messages = false } = req.body;
    const currentUser = req.user;

    if (!user_id) {
      return res.status(400).json({
        success: false,
        message: 'user_id is required'
      });
    }

    // Get the conversation
    const conversation = await db.collection('conversations').findOne({
      _id: new ObjectId(conversationId),
      conversation_type: 'group'
    });

    if (!conversation) {
      return res.status(404).json({
        success: false,
        message: 'Group conversation not found'
      });
    }

    // Check if user has permission to add users to this group
    const currentUserParticipant = conversation.participants.find(p => 
      p.user_id.toString() === currentUser._id.toString()
    );
    
    if (!currentUserParticipant) {
      return res.status(403).json({
        success: false,
        message: 'You are not a member of this group'
      });
    }

    // Check if current user is admin of the group OR has manage_group_conversations permission
    const hasManagePermission = currentUser.permissions?.some(p => 
      p.permission_name === 'manage_group_conversations' && p.granted === true
    );
    if (!hasManagePermission && !currentUserParticipant.is_admin) {
      return res.status(403).json({
        success: false,
        message: 'Only group administrators can add users to this group'
      });
    }

    // Check if user to be added exists and is active
    const userToAdd = await db.collection('users').findOne({
      _id: new ObjectId(user_id),
      is_active: true
    });

    if (!userToAdd) {
      return res.status(404).json({
        success: false,
        message: 'User not found or inactive'
      });
    }

    // Check if user is already in the group
    const isAlreadyMember = conversation.participants.some(p => 
      p.user_id.toString() === user_id
    );

    if (isAlreadyMember) {
      return res.status(400).json({
        success: false,
        message: 'User is already a member of this group'
      });
    }

    // Check group participant limit
    const maxParticipants = conversation.settings?.max_participants || 50;
    if (conversation.participants.length >= maxParticipants) {
      return res.status(400).json({
        success: false,
        message: `Group has reached maximum participant limit of ${maxParticipants}`
      });
    }

    // Add user to conversation
    const newParticipant = {
      ...sanitizeUserForConversation(userToAdd),
      joined_at: new Date(),
      is_admin: false,
      added_by: currentUser._id,
      show_previous_messages: Boolean(show_previous_messages)
    };

    await db.collection('conversations').updateOne(
      { _id: new ObjectId(conversationId) },
      {
        $push: { participants: newParticipant },
        $set: { updated_at: new Date() }
      }
    );

    // Get updated conversation
    const updatedConversation = await db.collection('conversations').findOne({
      _id: new ObjectId(conversationId)
    });

    // Create system message about user being added
    const systemMessageData = Message.create({
      conversation_id: conversationId,
      sender_id: currentUser._id,
      content_encrypted: messageEncryption.encrypt(`${newParticipant.name} was added to the group`),
      message_type: 'system',
      sender: {
        name: `${currentUser.first_name} ${currentUser.last_name}`,
        email: currentUser.email,
        branch_name: currentUser.branch?.branch_name
      }
    });

    await db.collection('messages').insertOne(systemMessageData);

    // Update conversation's last_message
    await db.collection('conversations').updateOne(
      { _id: new ObjectId(conversationId) },
      {
        $set: {
          last_message: {
            message_id: systemMessageData._id,
            content_preview: `${newParticipant.name} was added to the group`,
            sender_name: `${currentUser.first_name} ${currentUser.last_name}`,
            sent_at: new Date()
          },
          updated_at: new Date()
        }
      }
    );

    // Notify via WebSocket
    if (req.app.locals.websocket) {
      // Notify the new user about the conversation
      req.app.locals.websocket.notifyNewConversation(user_id, updatedConversation);
      
      // Join the new user to the conversation room
      req.app.locals.websocket.joinUsersToConversation(conversationId, [user_id]);
      
      // Notify existing participants about the new member
      const existingUserIds = conversation.participants.map(p => p.user_id.toString());
      req.app.locals.websocket.notifyNewMessage(conversationId, {
        ...systemMessageData,
        content: `${newParticipant.name} was added to the group`
      }, updatedConversation.participants);
    }

    res.json({
      success: true,
      data: {
        conversation: updatedConversation,
        added_participant: newParticipant
      },
      message: `User ${newParticipant.name} added to group successfully`
    });

  } catch (error) {
    console.error('Error adding user to group:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to add user to group'
    });
  }
});

/**
 * @route   POST /api/messaging/conversations/:id/remove-user
 * @desc    Remove a user from a group conversation
 * @access  Private (requires manage_group_conversations permission or be group admin)
 */
router.post('/conversations/:id/remove-user', permissionAuth('manage_group_conversations'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const conversationId = req.params.id;
    const { user_id } = req.body;
    const currentUser = req.user;

    if (!user_id) {
      return res.status(400).json({
        success: false,
        message: 'user_id is required'
      });
    }

    // Get the conversation
    const conversation = await db.collection('conversations').findOne({
      _id: new ObjectId(conversationId),
      conversation_type: 'group'
    });

    if (!conversation) {
      return res.status(404).json({
        success: false,
        message: 'Group conversation not found'
      });
    }

    // Check if current user has permission to remove users from this group
    const currentUserParticipant = conversation.participants.find(p => 
      p.user_id.toString() === currentUser._id.toString()
    );
    
    if (!currentUserParticipant) {
      return res.status(403).json({
        success: false,
        message: 'You are not a member of this group'
      });
    }

    // Check if current user is admin of the group OR has manage_group_conversations permission
    const hasManagePermission = currentUser.permissions?.some(p => 
      p.permission_name === 'manage_group_conversations' && p.granted === true
    );

    if (!hasManagePermission && !currentUserParticipant.is_admin) {
      return res.status(403).json({
        success: false,
        message: 'Only group administrators can remove users from this group'
      });
    }

    // Find the user to remove
    const userToRemove = conversation.participants.find(p => 
      p.user_id.toString() === user_id
    );

    if (!userToRemove) {
      return res.status(404).json({
        success: false,
        message: 'User is not a member of this group'
      });
    }

    // Prevent removing the group creator unless current user has manage_group_conversations permission
    if (conversation.created_by.toString() === user_id && !hasManagePermission) {
      return res.status(403).json({
        success: false,
        message: 'Cannot remove the group creator'
      });
    }

    // Remove user from conversation
    await db.collection('conversations').updateOne(
      { _id: new ObjectId(conversationId) },
      {
        $pull: { participants: { user_id: new ObjectId(user_id) } },
        $set: { updated_at: new Date() }
      }
    );

    // Get updated conversation
    const updatedConversation = await db.collection('conversations').findOne({
      _id: new ObjectId(conversationId)
    });

    // Create system message about user being removed
    const systemMessageData = Message.create({
      conversation_id: conversationId,
      sender_id: currentUser._id,
      content_encrypted: messageEncryption.encrypt(`${userToRemove.name} was removed from the group`),
      message_type: 'system',
      sender: {
        name: `${currentUser.first_name} ${currentUser.last_name}`,
        email: currentUser.email,
        branch_name: currentUser.branch?.branch_name
      }
    });

    await db.collection('messages').insertOne(systemMessageData);

    // Update conversation's last_message
    await db.collection('conversations').updateOne(
      { _id: new ObjectId(conversationId) },
      {
        $set: {
          last_message: {
            message_id: systemMessageData._id,
            content_preview: `${userToRemove.name} was removed from the group`,
            sender_name: `${currentUser.first_name} ${currentUser.last_name}`,
            sent_at: new Date()
          },
          updated_at: new Date()
        }
      }
    );

    // Notify via WebSocket
    if (req.app.locals.websocket) {
      // Remove user from conversation room
      req.app.locals.websocket.removeUserFromConversation(conversationId, user_id);
      
      // Notify remaining participants about the removal
      req.app.locals.websocket.notifyNewMessage(conversationId, {
        ...systemMessageData,
        content: `${userToRemove.name} was removed from the group`
      }, updatedConversation.participants);
      
      // Notify the removed user that they were removed
      req.app.locals.websocket.notifyUserRemovedFromGroup(user_id, conversationId, updatedConversation.title);
    }

    res.json({
      success: true,
      data: {
        conversation: updatedConversation,
        removed_participant: userToRemove
      },
      message: `User ${userToRemove.name} removed from group successfully`
    });

  } catch (error) {
    console.error('Error removing user from group:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to remove user from group'
    });
  }
});

/**
 * @route   POST /api/messaging/conversations/:id/leave
 * @desc    Leave a group conversation
 * @access  Private (requires view_conversation_history permission)
 */
router.post('/conversations/:id/leave', permissionAuth('view_conversation_history'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const conversationId = req.params.id;
    const currentUser = req.user;

    // Get the conversation
    const conversation = await db.collection('conversations').findOne({
      _id: new ObjectId(conversationId),
      conversation_type: 'group'
    });

    if (!conversation) {
      return res.status(404).json({
        success: false,
        message: 'Group conversation not found'
      });
    }

    // Check if user is a member of the group
    const userParticipant = conversation.participants.find(p => 
      p.user_id.toString() === currentUser._id.toString()
    );

    if (!userParticipant) {
      return res.status(404).json({
        success: false,
        message: 'You are not a member of this group'
      });
    }

    // Check if user is the group creator
    const isCreator = conversation.created_by.toString() === currentUser._id.toString();
    if (isCreator && conversation.participants.length > 1) {
      // Find another admin to transfer ownership
      const otherAdmin = conversation.participants.find(p => 
        p.is_admin && p.user_id.toString() !== currentUser._id.toString()
      );

      if (!otherAdmin) {
        return res.status(400).json({
          success: false,
          message: 'Cannot leave group as creator. Please assign another administrator first or remove all other participants.'
        });
      }

      // Transfer ownership to the other admin
      await db.collection('conversations').updateOne(
        { _id: new ObjectId(conversationId) },
        { $set: { created_by: otherAdmin.user_id } }
      );
    }

    // Remove user from conversation
    await db.collection('conversations').updateOne(
      { _id: new ObjectId(conversationId) },
      {
        $pull: { participants: { user_id: new ObjectId(currentUser._id) } },
        $set: { updated_at: new Date() }
      }
    );

    // Get updated conversation
    const updatedConversation = await db.collection('conversations').findOne({
      _id: new ObjectId(conversationId)
    });

    // Create system message about user leaving
    const systemMessageData = Message.create({
      conversation_id: conversationId,
      sender_id: currentUser._id,
      content_encrypted: messageEncryption.encrypt(`${userParticipant.name} left the group`),
      message_type: 'system',
      sender: {
        name: `${currentUser.first_name} ${currentUser.last_name}`,
        email: currentUser.email,
        branch_name: currentUser.branch?.branch_name
      }
    });

    await db.collection('messages').insertOne(systemMessageData);

    // Update conversation's last_message
    await db.collection('conversations').updateOne(
      { _id: new ObjectId(conversationId) },
      {
        $set: {
          last_message: {
            message_id: systemMessageData._id,
            content_preview: `${userParticipant.name} left the group`,
            sender_name: `${currentUser.first_name} ${currentUser.last_name}`,
            sent_at: new Date()
          },
          updated_at: new Date()
        }
      }
    );

    // Notify via WebSocket
    if (req.app.locals.websocket) {
      // Remove user from conversation room
      req.app.locals.websocket.removeUserFromConversation(conversationId, currentUser._id.toString());
      
      // Notify remaining participants about the user leaving
      if (updatedConversation.participants.length > 0) {
        req.app.locals.websocket.notifyNewMessage(conversationId, {
          ...systemMessageData,
          content: `${userParticipant.name} left the group`
        }, updatedConversation.participants);
      }
    }

    res.json({
      success: true,
      message: 'Successfully left the group'
    });

  } catch (error) {
    console.error('Error leaving group:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to leave group'
    });
  }
});

/**
 * @route   DELETE /api/messaging/conversations/announcement/:id
 * @desc    Delete an announcement conversation by marking all messages as deleted
 * @access  Private (requires send_announcements permission)
 */
router.delete('/conversations/announcement/:id', permissionAuth('send_announcements', { requireSameBranch: false }), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const conversationId = req.params.id;
    const currentUser = req.user;

    // Get the announcement conversation
    const conversation = await db.collection('conversations').findOne({
      _id: new ObjectId(conversationId),
      conversation_type: 'announcement'
    });

    if (!conversation) {
      return res.status(404).json({
        success: false,
        message: 'Announcement conversation not found'
      });
    }

    // Check if current user is the creator or has admin rights
    const isCreator = conversation.created_by.toString() === currentUser._id.toString();
    const isAdmin = currentUser.role_name === 'Admin';
    
    if (!isCreator && !isAdmin) {
      return res.status(403).json({
        success: false,
        message: 'Only the announcement creator or administrators can delete announcements'
      });
    }

    // Delete the announcement conversation completely
    const deletedAt = new Date();
    
    // First mark all messages in this conversation as deleted
    await db.collection('messages').updateMany(
      { conversation_id: new ObjectId(conversationId) },
      {
        $set: {
          deleted_at: deletedAt,
          deleted_by: currentUser._id
        }
      }
    );

    // Then delete the conversation itself
    await db.collection('conversations').deleteOne({
      _id: new ObjectId(conversationId)
    });

    // Notify all users via WebSocket about announcement deletion
    if (req.app.locals.websocket) {
      const allUserIds = conversation.participants.map(p => p.user_id.toString());
      
      // Notify users that announcement was deleted
      allUserIds.forEach(userId => {
        req.app.locals.websocket.notifyAnnouncementDeleted(userId, conversationId, conversation.title);
      });

      // Remove all users from conversation room
      req.app.locals.websocket.removeAllUsersFromConversation(conversationId);
    }

    res.json({
      success: true,
      message: 'Announcement deleted successfully',
      data: {
        conversation_id: conversationId,
        title: conversation.title,
        deleted_at: deletedAt
      }
    });

  } catch (error) {
    console.error('Error deleting announcement:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete announcement'
    });
  }
});

/**
 * @route   POST /api/messaging/conversations/:id/send-image
 * @desc    Upload image and send as message in one operation
 * @access  Private
 */
router.post('/conversations/:id/send-image',
  permissionAuth('send_messages'),
  createS3MultiUpload({
    folderName: 'messaging/images',
    ...uploadConfigs.messagingImages,
    fieldName: 'image'
  }),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const conversationId = req.params.id;
      const currentUser = req.user;
      const { caption = '' } = req.body; // Optional caption for the image

      if (!req.files || req.files.length === 0) {
        return res.status(400).json({
          success: false,
          message: 'No image uploaded'
        });
      }

      const imageFile = req.files[0];
      await waitForS3Object(imageFile.key);

      // Validate conversation access
      const conversation = await db.collection('conversations').findOne({
        _id: new ObjectId(conversationId),
        'participants.user_id': new ObjectId(currentUser._id)
      });

      if (!conversation) {
        return res.status(404).json({
          success: false,
          message: 'Conversation not found or access denied'
        });
      }

      // Only allow in private and group conversations (not announcements)
      if (conversation.conversation_type === 'announcement') {
        return res.status(403).json({
          success: false,
          message: 'Images cannot be sent to announcement conversations'
        });
      }

      // Create message content (caption or default text)
      const messageContent = caption.trim() || 'Image shared';
      const encryptedContent = messageEncryption.encrypt(messageContent);

      // Create message with image metadata
      const messageData = Message.create({
        conversation_id: conversationId,
        sender_id: currentUser._id,
        content_encrypted: encryptedContent,
        message_type: 'image',
        file_id: imageFile.key,
        original_name: imageFile.originalname,
        mime_type: imageFile.mimetype,
        file_size: imageFile.size,
        s3_key: imageFile.key,
        sender: {
          name: `${currentUser.first_name} ${currentUser.last_name}`,
          email: currentUser.email,
          branch_name: currentUser.branch?.branch_name
        }
      });

      const validation = Message.validate(messageData);
      if (!validation.isValid) {
        return res.status(400).json({
          success: false,
          message: 'Invalid message data',
          errors: validation.errors
        });
      }

      // Insert message
      const result = await db.collection('messages').insertOne(messageData);
      const newMessage = await db.collection('messages').findOne({ _id: result.insertedId });

      // Update conversation's last_message and updated_at
      const contentPreview = messageEncryption.createPreview(encryptedContent);
      await db.collection('conversations').updateOne(
        { _id: new ObjectId(conversationId) },
        {
          $set: {
            last_message: {
              message_id: result.insertedId,
              content_preview: contentPreview,
              sender_name: `${currentUser.first_name} ${currentUser.last_name}`,
              sent_at: new Date()
            },
            updated_at: new Date()
          }
        }
      );

      // Generate signed URL for immediate access
      const signedUrl = await getSignedUrl(imageFile.key, 86400);

      // Notify conversation participants via WebSocket
      if (req.app.locals.websocket) {
        req.app.locals.websocket.notifyNewMessage(conversationId, {
          ...newMessage,
          content: messageContent,
          signed_url: signedUrl
        }, conversation.participants);
      }

      // Return message with decrypted content and signed URL
      res.status(201).json({
        success: true,
        data: {
          ...newMessage,
          content: messageContent,
          signed_url: signedUrl
        },
        message: 'Image sent successfully'
      });

    } catch (error) {
      console.error('Error sending image message:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to send image'
      });
    }
  }
);

/**
 * @route   POST /api/messaging/conversations/:id/send-voice
 * @desc    Upload voice note and send as message in one operation
 * @access  Private
 */
router.post('/conversations/:id/send-voice',
  permissionAuth('send_messages'),
  createS3MultiUpload({
    folderName: 'messaging/voice-notes',
    ...uploadConfigs.voiceNotes,
    fieldName: 'voiceNote'
  }),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const conversationId = req.params.id;
      const currentUser = req.user;
      const { duration } = req.body; // Voice note duration from frontend

      if (!req.files || req.files.length === 0) {
        return res.status(400).json({
          success: false,
          message: 'No voice note uploaded'
        });
      }

      const voiceFile = req.files[0];
      await waitForS3Object(voiceFile.key);

      // Validate conversation access
      const conversation = await db.collection('conversations').findOne({
        _id: new ObjectId(conversationId),
        'participants.user_id': new ObjectId(currentUser._id)
      });

      if (!conversation) {
        return res.status(404).json({
          success: false,
          message: 'Conversation not found or access denied'
        });
      }

      // Only allow in private and group conversations (not announcements)
      if (conversation.conversation_type === 'announcement') {
        return res.status(403).json({
          success: false,
          message: 'Voice notes cannot be sent to announcement conversations'
        });
      }

      // Create message content
      const messageContent = 'Voice message';
      const encryptedContent = messageEncryption.encrypt(messageContent);

      // Create message with voice note metadata
      const messageData = Message.create({
        conversation_id: conversationId,
        sender_id: currentUser._id,
        content_encrypted: encryptedContent,
        message_type: 'voice_note',
        file_id: voiceFile.key,
        original_name: voiceFile.originalname,
        mime_type: voiceFile.mimetype,
        file_size: voiceFile.size,
        s3_key: voiceFile.key,
        duration: duration ? parseFloat(duration) : null,
        sender: {
          name: `${currentUser.first_name} ${currentUser.last_name}`,
          email: currentUser.email,
          branch_name: currentUser.branch?.branch_name
        }
      });

      const validation = Message.validate(messageData);
      if (!validation.isValid) {
        return res.status(400).json({
          success: false,
          message: 'Invalid message data',
          errors: validation.errors
        });
      }

      // Insert message
      const result = await db.collection('messages').insertOne(messageData);
      const newMessage = await db.collection('messages').findOne({ _id: result.insertedId });

      // Update conversation's last_message and updated_at
      const contentPreview = messageEncryption.createPreview(encryptedContent);
      await db.collection('conversations').updateOne(
        { _id: new ObjectId(conversationId) },
        {
          $set: {
            last_message: {
              message_id: result.insertedId,
              content_preview: contentPreview,
              sender_name: `${currentUser.first_name} ${currentUser.last_name}`,
              sent_at: new Date()
            },
            updated_at: new Date()
          }
        }
      );

      // Generate signed URL for immediate access
      const signedUrl = await getSignedUrl(voiceFile.key, 86400);

      // Notify conversation participants via WebSocket
      if (req.app.locals.websocket) {
        req.app.locals.websocket.notifyNewMessage(conversationId, {
          ...newMessage,
          content: messageContent,
          signed_url: signedUrl
        }, conversation.participants);
      }

      // Return message with decrypted content and signed URL
      res.status(201).json({
        success: true,
        data: {
          ...newMessage,
          content: messageContent,
          signed_url: signedUrl
        },
        message: 'Voice note sent successfully'
      });

    } catch (error) {
      console.error('Error sending voice message:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to send voice note'
      });
    }
  }
);

/**
 * @route   GET /api/messaging/file/:fileKey
 * @desc    Get refreshed signed URL for file access
 * @access  Private
 */
router.get('/file/:fileKey', permissionAuth('view_conversation_history'), async (req, res) => {
  try {
    const fileKey = req.params.fileKey;
    
    // Generate new signed URL (24 hours expiry)
    const signedUrl = await getSignedUrl(fileKey, 86400);
    
    res.json({
      success: true,
      data: {
        signed_url: signedUrl,
        expires_in: 86400
      }
    });

  } catch (error) {
    console.error('Error generating signed URL:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to generate file access URL'
    });
  }
});

module.exports = router;
