const express = require('express');
const router = express.Router();
const { ObjectId } = require('mongodb');
const Finance = require('../models/Finance');
const auth = require('../middleware/auth');
const permissionAuth = require('../middleware/permissionAuth');
const createCsvWriter = require('csv-writer').createObjectCsvWriter;

/**
 * @route   GET /api/finance/revenue
 * @desc    Get revenue analytics for a period
 * @access  Private (requires view_financial_reports permission)
 */
router.get('/revenue', auth, permissionAuth('view_financial_reports'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const finance = new Finance(db);
    
    const filters = {
      start_date: req.query.start_date,
      end_date: req.query.end_date,
      branch_id: req.query.branch_id
    };

    const revenue = await finance.calculateRevenue(filters);
    
    res.json({
      success: true,
      data: revenue,
      filters: filters
    });
  } catch (error) {
    console.error('Revenue calculation error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error calculating revenue', 
      error: error.message 
    });
  }
});

/**
 * @route   GET /api/finance/expenses
 * @desc    Get expense analytics for a period
 * @access  Private (requires view_financial_reports permission)
 */
router.get('/expenses', auth, permissionAuth('view_financial_reports'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const finance = new Finance(db);
    
    const filters = {
      start_date: req.query.start_date,
      end_date: req.query.end_date,
      branch_id: req.query.branch_id,
      expense_type: req.query.expense_type
    };

    const expenses = await finance.calculateExpenses(filters);
    
    res.json({
      success: true,
      data: expenses,
      filters: filters
    });
  } catch (error) {
    console.error('Expense calculation error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error calculating expenses', 
      error: error.message 
    });
  }
});

/**
 * @route   GET /api/finance/payroll
 * @desc    Get payroll cost analytics for a period
 * @access  Private (requires view_financial_reports permission)
 */
router.get('/payroll', auth, permissionAuth('view_financial_reports'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const finance = new Finance(db);
    
    const filters = {
      start_date: req.query.start_date,
      end_date: req.query.end_date,
      branch_id: req.query.branch_id
    };

    const payroll = await finance.calculatePayrollCosts(filters);
    
    res.json({
      success: true,
      data: payroll,
      filters: filters
    });
  } catch (error) {
    console.error('Payroll calculation error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error calculating payroll costs', 
      error: error.message 
    });
  }
});

/**
 * @route   GET /api/finance/profit-loss
 * @desc    Get profit and loss analysis for a period
 * @access  Private (requires view_financial_reports permission)
 */
router.get('/profit-loss', auth, permissionAuth('view_financial_reports'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const finance = new Finance(db);
    
    const filters = {
      start_date: req.query.start_date,
      end_date: req.query.end_date,
      branch_id: req.query.branch_id
    };

    const profitLoss = await finance.calculateProfitLoss(filters);
    
    res.json({
      success: true,
      data: profitLoss,
      filters: filters
    });
  } catch (error) {
    console.error('Profit/Loss calculation error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error calculating profit/loss', 
      error: error.message 
    });
  }
});

/**
 * @route   GET /api/finance/dashboard
 * @desc    Get comprehensive financial dashboard data
 * @access  Private (requires view_financial_reports permission)
 */
router.get('/dashboard', auth, permissionAuth('view_financial_reports'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const finance = new Finance(db);
    
    const filters = {
      start_date: req.query.start_date,
      end_date: req.query.end_date,
      branch_id: req.query.branch_id
    };

    const dashboard = await finance.getDashboardMetrics(filters);
    
    res.json({
      success: true,
      data: dashboard,
      filters: filters
    });
  } catch (error) {
    console.error('Dashboard calculation error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error generating dashboard', 
      error: error.message 
    });
  }
});

/**
 * @route   GET /api/finance/cash-flow
 * @desc    Get cash flow analysis for a period
 * @access  Private (requires view_financial_reports permission)
 */
router.get('/cash-flow', auth, permissionAuth('view_financial_reports'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const finance = new Finance(db);
    
    const filters = {
      start_date: req.query.start_date,
      end_date: req.query.end_date,
      branch_id: req.query.branch_id
    };

    const cashFlow = await finance.getCashFlow(filters);
    
    res.json({
      success: true,
      data: cashFlow,
      filters: filters
    });
  } catch (error) {
    console.error('Cash flow calculation error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error calculating cash flow', 
      error: error.message 
    });
  }
});

/**
 * @route   GET /api/finance/summary
 * @desc    Get a quick financial summary with all key metrics
 * @access  Private (requires view_financial_reports permission)
 */
router.get('/summary', auth, permissionAuth('view_financial_reports'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const finance = new Finance(db);
    
    const filters = {
      start_date: req.query.start_date,
      end_date: req.query.end_date,
      branch_id: req.query.branch_id
    };

    // Get all financial data in parallel
    const [revenue, expenses, payroll, profitLoss, cashFlow] = await Promise.all([
      finance.calculateRevenue(filters),
      finance.calculateExpenses(filters),
      finance.calculatePayrollCosts(filters),
      finance.calculateProfitLoss(filters),
      finance.getCashFlow(filters)
    ]);

    const summary = {
      period: {
        start_date: filters.start_date || 'All time',
        end_date: filters.end_date || 'Present',
        branch_id: filters.branch_id || 'All branches'
      },
      key_metrics: {
        total_revenue: revenue.total_revenue,
        total_expenses: expenses.summary.total_amount,
        total_payroll: payroll.total_gross_pay,
        gross_profit: profitLoss.period_summary.gross_profit,
        net_profit: profitLoss.period_summary.net_profit,
        profit_margin: profitLoss.period_summary.profit_margin,
        cash_flow: cashFlow.net_cash_flow
      },
      revenue_breakdown: revenue,
      expense_breakdown: expenses.by_category.slice(0, 10), // Top 10 expense categories
      payroll_summary: {
        employee_count: payroll.employee_count,
        total_gross_pay: payroll.total_gross_pay,
        total_net_pay: payroll.total_net_pay,
        average_salary: payroll.average_gross_pay
      },
      cash_flow_summary: cashFlow
    };

    res.json({
      success: true,
      data: summary,
      filters: filters
    });
  } catch (error) {
    console.error('Financial summary error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error generating financial summary', 
      error: error.message 
    });
  }
});

/**
 * @route   GET /api/finance/branches/comparison
 * @desc    Compare financial performance across branches
 * @access  Private (requires view_financial_reports permission)
 */
router.get('/branches/comparison', auth, permissionAuth('view_financial_reports'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const finance = new Finance(db);
    
    const baseFilters = {
      start_date: req.query.start_date,
      end_date: req.query.end_date
    };

    // Get all branches
    const branches = await db.collection('branches').find({}).toArray();
    
    // Calculate metrics for each branch
    const branchComparisons = await Promise.all(
      branches.map(async (branch) => {
        const branchFilters = { ...baseFilters, branch_id: branch._id.toString() };
        const [revenue, expenses, profitLoss] = await Promise.all([
          finance.calculateRevenue(branchFilters),
          finance.calculateExpenses(branchFilters),
          finance.calculateProfitLoss(branchFilters)
        ]);

        return {
          branch: {
            id: branch._id,
            name: branch.branch_name,
            code: branch.branch_code
          },
          metrics: {
            revenue: revenue.total_revenue,
            expenses: expenses.summary.total_amount,
            profit: profitLoss.period_summary.gross_profit,
            profit_margin: profitLoss.period_summary.profit_margin,
            invoice_count: revenue.total_invoices,
            expense_count: expenses.summary.total_expenses
          }
        };
      })
    );

    // Sort by revenue descending
    branchComparisons.sort((a, b) => b.metrics.revenue - a.metrics.revenue);

    res.json({
      success: true,
      data: {
        comparison_period: baseFilters,
        branches: branchComparisons,
        totals: {
          total_revenue: branchComparisons.reduce((sum, branch) => sum + branch.metrics.revenue, 0),
          total_expenses: branchComparisons.reduce((sum, branch) => sum + branch.metrics.expenses, 0),
          total_profit: branchComparisons.reduce((sum, branch) => sum + branch.metrics.profit, 0),
          branch_count: branchComparisons.length
        }
      }
    });
  } catch (error) {
    console.error('Branch comparison error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error comparing branch performance', 
      error: error.message 
    });
  }
});

/**
 * @route   GET /api/finance/export/csv
 * @desc    Export financial data to CSV format
 * @access  Private (requires view_financial_reports permission)
 */
router.get('/export/csv', auth, permissionAuth('view_financial_reports'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const finance = new Finance(db);
    
    const filters = {
      start_date: req.query.start_date,
      end_date: req.query.end_date,
      branch_id: req.query.branch_id
    };

    const exportType = req.query.type || 'summary'; // summary, revenue, expenses, payroll, branches

    let csvData = [];
    let filename = 'financial_data';
    let headers = [];

    switch (exportType) {
      case 'revenue':
        const revenueData = await finance.calculateRevenue(filters);
        csvData = [{
          metric: 'Total Invoices',
          value: revenueData.total_invoices,
          currency: ''
        }, {
          metric: 'Total Revenue',
          value: revenueData.total_revenue,
          currency: 'Currency'
        }, {
          metric: 'Total Revenue Before VAT',
          value: revenueData.total_revenue_before_vat,
          currency: 'Currency'
        }, {
          metric: 'Total VAT Amount',
          value: revenueData.total_vat_amount,
          currency: 'Currency'
        }, {
          metric: 'Average Invoice Value',
          value: revenueData.average_invoice_value,
          currency: 'Currency'
        }, {
          metric: 'Total Paid',
          value: revenueData.total_paid,
          currency: 'Currency'
        }, {
          metric: 'Total Real Value (After Card Fees)',
          value: revenueData.total_real_value || 0,
          currency: 'Currency'
        }, {
          metric: 'Outstanding Amount',
          value: revenueData.outstanding_amount,
          currency: 'Currency'
        }];
        headers = [
          { id: 'metric', title: 'Metric' },
          { id: 'value', title: 'Value' },
          { id: 'currency', title: 'Unit' }
        ];
        filename = 'revenue_report';
        break;

      case 'expenses':
        const expenseData = await finance.calculateExpenses(filters);
        
        // Create summary rows
        csvData = [{
          category: 'SUMMARY',
          total_amount: expenseData.summary.total_amount,
          count: expenseData.summary.total_expenses,
          average_amount: expenseData.summary.average_expense
        }];

        // Add category breakdown
        expenseData.by_category.forEach(category => {
          csvData.push({
            category: category._id || 'Unknown',
            total_amount: category.total_amount,
            count: category.count,
            average_amount: category.average_amount
          });
        });

        headers = [
          { id: 'category', title: 'Expense Category' },
          { id: 'total_amount', title: 'Total Amount' },
          { id: 'count', title: 'Number of Expenses' },
          { id: 'average_amount', title: 'Average Amount' }
        ];
        filename = 'expenses_report';
        break;

      case 'payroll':
        const payrollData = await finance.calculatePayrollCosts(filters);
        csvData = [{
          metric: 'Employee Count',
          value: payrollData.employee_count,
          unit: 'Employees'
        }, {
          metric: 'Total Gross Pay',
          value: payrollData.total_gross_pay,
          unit: 'Currency'
        }, {
          metric: 'Total Deductions',
          value: payrollData.total_deductions,
          unit: 'Currency'
        }, {
          metric: 'Total Net Pay',
          value: payrollData.total_net_pay,
          unit: 'Currency'
        }, {
          metric: 'Total Regular Pay',
          value: payrollData.total_regular_pay,
          unit: 'Currency'
        }, {
          metric: 'Total Overtime Pay',
          value: payrollData.total_overtime_pay,
          unit: 'Currency'
        }, {
          metric: 'Total Hours',
          value: payrollData.total_hours,
          unit: 'Hours'
        }, {
          metric: 'Total Overtime Hours',
          value: payrollData.total_overtime_hours,
          unit: 'Hours'
        }, {
          metric: 'Average Gross Pay',
          value: payrollData.average_gross_pay,
          unit: 'Currency'
        }, {
          metric: 'Average Net Pay',
          value: payrollData.average_net_pay,
          unit: 'Currency'
        }];
        headers = [
          { id: 'metric', title: 'Payroll Metric' },
          { id: 'value', title: 'Value' },
          { id: 'unit', title: 'Unit' }
        ];
        filename = 'payroll_report';
        break;

      case 'branches':
        const branchData = await finance.getDashboardMetrics({ ...filters, branch_id: undefined });
        
        // Get branch comparison data
        const branchComparison = await finance.calculateRevenue({ ...filters, branch_id: undefined });
        const branches = await db.collection('branches').find({}).toArray();
        
        csvData = [];
        for (const branch of branches) {
          const branchFilters = { ...filters, branch_id: branch._id.toString() };
          const [branchRevenue, branchExpenses, branchPayroll] = await Promise.all([
            finance.calculateRevenue(branchFilters),
            finance.calculateExpenses(branchFilters),
            finance.calculatePayrollCosts(branchFilters)
          ]);

          const profit = branchRevenue.total_revenue - branchExpenses.summary.total_amount - branchPayroll.total_gross_pay;
          const profitMargin = branchRevenue.total_revenue > 0 ? (profit / branchRevenue.total_revenue) * 100 : 0;

          csvData.push({
            branch_name: branch.branch_name,
            branch_code: branch.branch_code,
            total_revenue: branchRevenue.total_revenue,
            total_expenses: branchExpenses.summary.total_amount,
            total_payroll: branchPayroll.total_gross_pay,
            gross_profit: profit,
            profit_margin: profitMargin,
            invoice_count: branchRevenue.total_invoices,
            expense_count: branchExpenses.summary.total_expenses,
            employee_count: branchPayroll.employee_count
          });
        }

        headers = [
          { id: 'branch_name', title: 'Branch Name' },
          { id: 'branch_code', title: 'Branch Code' },
          { id: 'total_revenue', title: 'Total Revenue' },
          { id: 'total_expenses', title: 'Total Expenses' },
          { id: 'total_payroll', title: 'Total Payroll' },
          { id: 'gross_profit', title: 'Gross Profit' },
          { id: 'profit_margin', title: 'Profit Margin (%)' },
          { id: 'invoice_count', title: 'Invoice Count' },
          { id: 'expense_count', title: 'Expense Count' },
          { id: 'employee_count', title: 'Employee Count' }
        ];
        filename = 'branch_comparison';
        break;

      case 'summary':
      default:
        const summaryData = await finance.calculateProfitLoss(filters);
        csvData = [{
          metric: 'Total Revenue',
          value: summaryData.period_summary.total_revenue,
          unit: 'Currency'
        }, {
          metric: 'Total Paid',
          value: summaryData.period_summary.total_paid,
          unit: 'Currency'
        }, {
          metric: 'Outstanding Amount',
          value: summaryData.period_summary.outstanding_amount,
          unit: 'Currency'
        }, {
          metric: 'Total Expenses',
          value: summaryData.period_summary.total_expenses,
          unit: 'Currency'
        }, {
          metric: 'Total Payroll Costs',
          value: summaryData.period_summary.total_payroll_costs,
          unit: 'Currency'
        }, {
          metric: 'Total Costs',
          value: summaryData.period_summary.total_costs,
          unit: 'Currency'
        }, {
          metric: 'Gross Profit',
          value: summaryData.period_summary.gross_profit,
          unit: 'Currency'
        }, {
          metric: 'Net Profit',
          value: summaryData.period_summary.net_profit,
          unit: 'Currency'
        }, {
          metric: 'Profit Margin',
          value: summaryData.period_summary.profit_margin,
          unit: 'Percentage'
        }, {
          metric: 'Net Profit Margin',
          value: summaryData.period_summary.net_profit_margin,
          unit: 'Percentage'
        }];
        headers = [
          { id: 'metric', title: 'Financial Metric' },
          { id: 'value', title: 'Value' },
          { id: 'unit', title: 'Unit' }
        ];
        filename = 'financial_summary';
        break;
    }

    // Add filter information to filename
    if (filters.start_date && filters.end_date) {
      filename += `_${filters.start_date}_to_${filters.end_date}`;
    } else if (filters.start_date) {
      filename += `_from_${filters.start_date}`;
    } else if (filters.end_date) {
      filename += `_until_${filters.end_date}`;
    }

    if (filters.branch_id) {
      const branch = await db.collection('branches').findOne({ _id: new ObjectId(filters.branch_id) });
      if (branch) {
        filename += `_${branch.branch_code}`;
      }
    }

    filename += `_${new Date().toISOString().split('T')[0]}.csv`;

    // Create CSV content
    let csvContent = '';
    
    // Add header
    csvContent += headers.map(h => h.title).join(',') + '\n';
    
    // Add data rows
    csvData.forEach(row => {
      const rowData = headers.map(header => {
        const value = row[header.id];
        // Handle commas and quotes in values
        if (typeof value === 'string' && (value.includes(',') || value.includes('"'))) {
          return `"${value.replace(/"/g, '""')}"`;
        }
        return value || '';
      });
      csvContent += rowData.join(',') + '\n';
    });

    // Set response headers
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Pragma', 'no-cache');

    res.send(csvContent);

  } catch (error) {
    console.error('CSV export error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error generating CSV export', 
      error: error.message 
    });
  }
});

/**
 * @route   GET /api/finance/export/csv/detailed
 * @desc    Export detailed financial transactions to CSV
 * @access  Private (requires view_financial_reports permission)
 */
router.get('/export/csv/detailed', auth, permissionAuth('view_financial_reports'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    
    const filters = {
      start_date: req.query.start_date,
      end_date: req.query.end_date,
      branch_id: req.query.branch_id
    };

    const exportType = req.query.type || 'all'; // all, invoices, expenses, payroll

    let csvData = [];
    let filename = 'detailed_financial_data';
    let headers = [];

    const matchStage = {};
    
    // Date filtering
    if (filters.start_date || filters.end_date) {
      const dateField = exportType === 'invoices' ? 'invoice_date' : 
                       exportType === 'expenses' ? 'date' : 'created_at';
      matchStage[dateField] = {};
      if (filters.start_date) matchStage[dateField].$gte = new Date(filters.start_date);
      if (filters.end_date) matchStage[dateField].$lte = new Date(filters.end_date);
    }
    
    // Branch filtering
    if (filters.branch_id) {
      matchStage.branch_id = new ObjectId(filters.branch_id);
    }

    switch (exportType) {
      case 'invoices':
        const invoices = await db.collection('invoices').aggregate([
          { $match: matchStage },
          {
            $lookup: {
              from: 'customers',
              localField: 'customer_id',
              foreignField: '_id',
              as: 'customer'
            }
          },
          {
            $lookup: {
              from: 'branches',
              localField: 'branch_id',
              foreignField: '_id',
              as: 'branch'
            }
          },
          { $unwind: { path: '$customer', preserveNullAndEmptyArrays: true } },
          { $unwind: { path: '$branch', preserveNullAndEmptyArrays: true } }
        ]).toArray();

        csvData = invoices.map(invoice => ({
          invoice_number: invoice.invoice_number,
          invoice_date: invoice.invoice_date ? invoice.invoice_date.toISOString().split('T')[0] : '',
          customer_name: invoice.customer?.name || 'Unknown',
          branch_name: invoice.branch?.branch_name || 'Unknown',
          price_before_vat: invoice.price_before_vat || 0,
          vat_amount: invoice.vat_amount || 0,
          total_price: invoice.total_price || 0,
          total_paid: invoice.payment_records ? invoice.payment_records.reduce((sum, p) => sum + (p.amount || 0), 0) : 0,
          real_value: invoice.real_value || 0,
          outstanding: (invoice.total_price || 0) - (invoice.payment_records ? invoice.payment_records.reduce((sum, p) => sum + (p.amount || 0), 0) : 0),
          status: invoice.payment_records && invoice.payment_records.length > 0 ? 'Partial/Paid' : 'Unpaid'
        }));

        headers = [
          { id: 'invoice_number', title: 'Invoice Number' },
          { id: 'invoice_date', title: 'Invoice Date' },
          { id: 'customer_name', title: 'Customer Name' },
          { id: 'branch_name', title: 'Branch Name' },
          { id: 'price_before_vat', title: 'Price Before VAT' },
          { id: 'vat_amount', title: 'VAT Amount' },
          { id: 'total_price', title: 'Total Price' },
          { id: 'total_paid', title: 'Total Paid' },
          { id: 'real_value', title: 'Real Value (After Card Fees)' },
          { id: 'outstanding', title: 'Outstanding Amount' },
          { id: 'status', title: 'Payment Status' }
        ];
        filename = 'detailed_invoices';
        break;

      case 'expenses':
        const expenses = await db.collection('expenses').aggregate([
          { $match: matchStage },
          {
            $lookup: {
              from: 'branches',
              localField: 'branch_id',
              foreignField: '_id',
              as: 'branch'
            }
          },
          {
            $lookup: {
              from: 'users',
              localField: 'created_by',
              foreignField: '_id',
              as: 'creator'
            }
          },
          { $unwind: { path: '$branch', preserveNullAndEmptyArrays: true } },
          { $unwind: { path: '$creator', preserveNullAndEmptyArrays: true } }
        ]).toArray();

        csvData = expenses.map(expense => ({
          expense_number: expense.expense_number,
          date: expense.date ? expense.date.toISOString().split('T')[0] : '',
          title: expense.title,
          description: expense.description || '',
          amount: expense.amount || 0,
          expense_type: expense.expense_type || 'Unknown',
          branch_name: expense.branch?.branch_name || 'Unknown',
          created_by: expense.creator?.name || 'Unknown',
          status: expense.status || 'Pending'
        }));

        headers = [
          { id: 'expense_number', title: 'Expense Number' },
          { id: 'date', title: 'Date' },
          { id: 'title', title: 'Title' },
          { id: 'description', title: 'Description' },
          { id: 'amount', title: 'Amount' },
          { id: 'expense_type', title: 'Category' },
          { id: 'branch_name', title: 'Branch Name' },
          { id: 'created_by', title: 'Created By' },
          { id: 'status', title: 'Status' }
        ];
        filename = 'detailed_expenses';
        break;

      case 'payroll':
        const payrollRecords = await db.collection('payroll_calculations').aggregate([
          { $match: matchStage },
          {
            $lookup: {
              from: 'users',
              localField: 'employee_id',
              foreignField: '_id',
              as: 'employee'
            }
          },
          {
            $lookup: {
              from: 'pay_periods',
              localField: 'pay_period_id',
              foreignField: '_id',
              as: 'pay_period'
            }
          },
          { $unwind: { path: '$employee', preserveNullAndEmptyArrays: true } },
          { $unwind: { path: '$pay_period', preserveNullAndEmptyArrays: true } }
        ]).toArray();

        csvData = payrollRecords.map(record => ({
          employee_name: record.employee?.name || 'Unknown',
          employee_email: record.employee?.email || 'Unknown',
          pay_period: record.pay_period?.period_name || 'Unknown',
          regular_hours: record.regular_hours || 0,
          overtime_hours: record.overtime_hours || 0,
          total_hours: record.total_hours || 0,
          regular_pay: record.regular_pay || 0,
          overtime_pay: record.overtime_pay || 0,
          gross_pay: record.gross_pay || 0,
          total_deductions: record.total_deductions || 0,
          net_pay: record.net_pay || 0,
          calculation_date: record.created_at ? record.created_at.toISOString().split('T')[0] : ''
        }));

        headers = [
          { id: 'employee_name', title: 'Employee Name' },
          { id: 'employee_email', title: 'Employee Email' },
          { id: 'pay_period', title: 'Pay Period' },
          { id: 'regular_hours', title: 'Regular Hours' },
          { id: 'overtime_hours', title: 'Overtime Hours' },
          { id: 'total_hours', title: 'Total Hours' },
          { id: 'regular_pay', title: 'Regular Pay' },
          { id: 'overtime_pay', title: 'Overtime Pay' },
          { id: 'gross_pay', title: 'Gross Pay' },
          { id: 'total_deductions', title: 'Total Deductions' },
          { id: 'net_pay', title: 'Net Pay' },
          { id: 'calculation_date', title: 'Calculation Date' }
        ];
        filename = 'detailed_payroll';
        break;

      case 'all':
      default:
        // Export all data types in separate sections
        return res.status(400).json({
          success: false,
          message: 'For detailed export, please specify type: invoices, expenses, or payroll'
        });
    }

    // Add filter information to filename
    if (filters.start_date && filters.end_date) {
      filename += `_${filters.start_date}_to_${filters.end_date}`;
    }
    if (filters.branch_id) {
      const branch = await db.collection('branches').findOne({ _id: new ObjectId(filters.branch_id) });
      if (branch) {
        filename += `_${branch.branch_code}`;
      }
    }
    filename += `_${new Date().toISOString().split('T')[0]}.csv`;

    // Create CSV content
    let csvContent = '';
    
    // Add header
    csvContent += headers.map(h => h.title).join(',') + '\n';
    
    // Add data rows
    csvData.forEach(row => {
      const rowData = headers.map(header => {
        const value = row[header.id];
        // Handle commas and quotes in values
        if (typeof value === 'string' && (value.includes(',') || value.includes('"'))) {
          return `"${value.replace(/"/g, '""')}"`;
        }
        return value || '';
      });
      csvContent += rowData.join(',') + '\n';
    });

    // Set response headers
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Pragma', 'no-cache');

    res.send(csvContent);

  } catch (error) {
    console.error('Detailed CSV export error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error generating detailed CSV export', 
      error: error.message 
    });
  }
});

module.exports = router;
