const express = require('express');
const router = express.Router();
const { ObjectId } = require('mongodb');
const auth = require('../middleware/auth');
const adminAuth = require('../middleware/adminAuth');

// Get all roles
router.get('/', auth, async (req, res) => {
  try {
    const roles = await req.app.locals.db.collection('roles').find({}).toArray();
    res.json(roles);
  } catch (error) {
    console.error('Error fetching roles:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get role by ID
router.get('/:id', auth, async (req, res) => {
  try {
    const role = await req.app.locals.db.collection('roles').findOne({
      _id: new ObjectId(req.params.id) 
    });
    
    if (!role) {
      return res.status(404).json({ message: 'Role not found' });
    }
    
    res.json(role);
  } catch (error) {
    console.error('Error fetching role:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Create a new role (admin only)
router.post('/', auth, adminAuth, async (req, res) => {
  try {
    const { role_name, description } = req.body;
    
    // Validate required fields
    if (!role_name || !description) {
      return res.status(400).json({ 
        message: 'Please provide role_name and description' 
      });
    }
    
    // Check if role already exists
    const existingRole = await req.app.locals.db.collection('roles').findOne({ role_name });
    if (existingRole) {
      return res.status(400).json({ message: 'Role already exists' });
    }
    
    const now = new Date();
    
    const newRole = {
      role_name,
      description,
      created_at: now,
      updated_at: now
    };
    
    const result = await req.app.locals.db.collection('roles').insertOne(newRole);
    
    res.status(201).json({
      _id: result.insertedId,
      ...newRole
    });
  } catch (error) {
    console.error('Error creating role:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Update a role (admin only)
router.put('/:id', auth, adminAuth, async (req, res) => {
  try {
    const { role_name, description } = req.body;
    
    // Validate required fields
    if (!role_name && !description) {
      return res.status(400).json({ 
        message: 'Please provide at least one field to update' 
      });
    }
    
    // Check if role exists
    const role = await req.app.locals.db.collection('roles').findOne({ 
      _id: new ObjectId(req.params.id) 
    });
    
    if (!role) {
      return res.status(404).json({ message: 'Role not found' });
    }
    
    // Build update object
    const updateObj = {
      updated_at: new Date()
    };
    
    if (role_name) updateObj.role_name = role_name;
    if (description) updateObj.description = description;
    
    // Update the role
    await req.app.locals.db.collection('roles').updateOne(
      { _id: new ObjectId(req.params.id) },
      { $set: updateObj }
    );
    
    res.json({ 
      message: 'Role updated successfully',
      _id: req.params.id,
      ...updateObj
    });
  } catch (error) {
    console.error('Error updating role:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Delete a role (admin only)
router.delete('/:id', auth, adminAuth, async (req, res) => {
  try {
    // Check if role exists
    const role = await req.app.locals.db.collection('roles').findOne({ 
      _id: new ObjectId(req.params.id) 
    });
    
    if (!role) {
      return res.status(404).json({ message: 'Role not found' });
    }
    
    // Delete the role
    await req.app.locals.db.collection('roles').deleteOne({ _id: new ObjectId(req.params.id) });
    
    res.json({ message: 'Role deleted successfully' });
  } catch (error) {
    console.error('Error deleting role:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
