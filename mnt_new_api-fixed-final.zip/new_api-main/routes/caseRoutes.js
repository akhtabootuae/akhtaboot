const express = require('express');
const router = express.Router();
const { ObjectId } = require('mongodb');
const auth = require('../middleware/auth');
const permissionAuth = require('../middleware/permissionAuth');
const { body, param, query, validationResult } = require('express-validator');
const multer = require('multer');
const path = require('path');
const fs = require('fs').promises;
const { createS3Upload, uploadConfigs, deleteFromS3, deleteMultipleFromS3, getSignedUrl } = require('../middleware/s3Upload');
const CaseLog = require('../models/CaseLog');

// Configure S3 upload for case attachments
const uploadCaseAttachment = createS3Upload({
  folderName: 'cases/attachments',
  ...uploadConfigs.documents,
  fieldName: 'attachment'
});

// Alternative upload middleware with 'file' field name (common default)
const uploadCaseAttachmentFile = createS3Upload({
  folderName: 'cases/attachments',
  ...uploadConfigs.documents,
  fieldName: 'file'
});

// Helper function to generate signed URLs for case attachments
const generateSignedUrlsForCase = async (caseDoc) => {
  if (caseDoc.attachments && caseDoc.attachments.length > 0) {
    const attachmentsWithSignedUrls = await Promise.all(
      caseDoc.attachments.map(async (attachment, index) => {
        if (attachment.s3Key) {
          try {
            const signedUrl = await getSignedUrl(attachment.s3Key, 3600); // 1 hour expiry
            return {
              ...attachment,
              index: index,
              signedUrl: signedUrl,
              viewUrl: `/api/cases/${caseDoc._id}/attachments/${index}/view`,
              downloadUrl: `/api/cases/${caseDoc._id}/attachments/${index}/download`
            };
          } catch (urlError) {
            console.error('Error generating signed URL for attachment:', attachment.s3Key, urlError);
            return {
              ...attachment,
              index: index,
              viewUrl: `/api/cases/${caseDoc._id}/attachments/${index}/view`,
              downloadUrl: `/api/cases/${caseDoc._id}/attachments/${index}/download`
            }; // Return attachment without signed URL if error
          }
        }
        return {
          ...attachment,
          index: index,
          viewUrl: `/api/cases/${caseDoc._id}/attachments/${index}/view`,
          downloadUrl: `/api/cases/${caseDoc._id}/attachments/${index}/download`
        };
      })
    );
    caseDoc.attachments = attachmentsWithSignedUrls;
  }
  return caseDoc;
};

// Helper function to generate signed URLs for multiple cases
const generateSignedUrlsForCases = async (cases) => {
  return Promise.all(cases.map(generateSignedUrlsForCase));
};

// Validation middleware
const validateCase = [
  body('title')
    .trim()
    .isLength({ min: 3, max: 200 })
    .withMessage('Title must be between 3 and 200 characters'),
  body('description')
    .trim()
    .isLength({ min: 10, max: 2000 })
    .withMessage('Description must be between 10 and 2000 characters'),
  body('status')
    .optional()
    .isIn(['open', 'in-progress', 'pending', 'resolved', 'closed'])
    .withMessage('Status must be one of: open, in-progress, pending, resolved, closed'),
  body('priority')
    .optional()
    .isIn(['low', 'medium', 'high', 'urgent'])
    .withMessage('Priority must be one of: low, medium, high, urgent'),
  body('linkedTo.type')
    .optional()
    .isString()
    .withMessage('LinkedTo type must be a string'),
  body('linkedTo.id')
    .optional()
    .isMongoId()
    .withMessage('LinkedTo ID must be a valid MongoDB ObjectId'),
  body('assignedTo')
    .optional()
    .isMongoId()
    .withMessage('AssignedTo must be a valid MongoDB ObjectId'),
  body('tags')
    .optional()
    .isArray()
    .withMessage('Tags must be an array'),
  body('tags.*')
    .optional()
    .isString()
    .trim()
    .withMessage('Each tag must be a string'),
  body('dueDate')
    .optional()
    .isISO8601()
    .withMessage('Due date must be a valid ISO 8601 date')
];

const validateCaseUpdate = [
  body('title')
    .optional()
    .trim()
    .isLength({ min: 3, max: 200 })
    .withMessage('Title must be between 3 and 200 characters'),
  body('description')
    .optional()
    .trim()
    .isLength({ min: 10, max: 2000 })
    .withMessage('Description must be between 10 and 2000 characters'),
  body('status')
    .optional()
    .isIn(['open', 'in-progress', 'pending', 'resolved', 'closed'])
    .withMessage('Status must be one of: open, in-progress, pending, resolved, closed'),
  body('priority')
    .optional()
    .isIn(['low', 'medium', 'high', 'urgent'])
    .withMessage('Priority must be one of: low, medium, high, urgent'),
  body('assignedTo')
    .optional()
    .isMongoId()
    .withMessage('AssignedTo must be a valid MongoDB ObjectId'),
  body('tags')
    .optional()
    .isArray()
    .withMessage('Tags must be an array'),
  body('tags.*')
    .optional()
    .isString()
    .trim()
    .withMessage('Each tag must be a string'),
  body('dueDate')
    .optional()
    .isISO8601()
    .withMessage('Due date must be a valid ISO 8601 date')
];

const validateCaseId = [
  param('id')
    .isMongoId()
    .withMessage('Case ID must be a valid MongoDB ObjectId')
];

const validateNote = [
  body('content')
    .trim()
    .isLength({ min: 1, max: 1000 })
    .withMessage('Note content must be between 1 and 1000 characters')
];

const validatePagination = [
  query('page')
    .optional()
    .isInt({ min: 1 })
    .withMessage('Page must be a positive integer'),
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('Limit must be between 1 and 100'),
  query('sortBy')
    .optional()
    .isIn(['createdAt', 'updatedAt', 'title', 'status', 'priority', 'dueDate'])
    .withMessage('SortBy must be one of: createdAt, updatedAt, title, status, priority, dueDate'),
  query('sortOrder')
    .optional()
    .isIn(['asc', 'desc', '1', '-1'])
    .withMessage('SortOrder must be asc, desc, 1, or -1')
];

// Middleware to check validation results
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      message: 'Validation failed',
      errors: errors.array()
    });
  }
  next();
};

// Routes

/**
 * POST /api/cases
 * Create a new case
 */
router.post('/', 
  auth, 
  permissionAuth(['create_case']),
  validateCase, 
  handleValidationErrors,
  async (req, res) => {
    try {
      const Case = req.app.locals.models.Case;
      const newCase = await Case.createCase(req.body, req.user);

      // Log case creation
      try {
        await CaseLog.createLogEntry(req.app.locals.db, {
          user_id: req.user._id,
          user_email: req.user.email || 'unknown',
          action: 'create_case',
          entity_type: 'case',
          entity_id: newCase._id,
          ip_address: req.ip || req.connection?.remoteAddress || 'unknown',
          user_agent: req.get('User-Agent') || 'unknown',
          details: {
            request_method: req.method,
            endpoint: req.originalUrl,
            success: true,
            case_title: newCase.title,
            case_status: newCase.status,
            case_priority: newCase.priority,
            assigned_to: newCase.assignedTo || null,
            linked_entity: newCase.linkedTo || null
          },
          severity: 'medium',
          category: 'data_modification'
        });
      } catch (logError) {
        console.error('Error creating case log:', logError);
        // Don't fail the request if logging fails
      }

      res.status(201).json({
        success: true,
        message: 'Case created successfully',
        data: newCase
      });
    } catch (error) {
      console.error('Create case error:', error);
      
      // Log failed case creation attempt
      try {
        await CaseLog.createLogEntry(req.app.locals.db, {
          user_id: req.user._id,
          user_email: req.user.email || 'unknown',
          action: 'create_case',
          entity_type: 'case',
          entity_id: null,
          ip_address: req.ip || req.connection?.remoteAddress || 'unknown',
          user_agent: req.get('User-Agent') || 'unknown',
          details: {
            request_method: req.method,
            endpoint: req.originalUrl,
            success: false,
            error_message: error.message,
            attempted_data: {
              title: req.body.title,
              priority: req.body.priority,
              status: req.body.status
            }
          },
          severity: 'high',
          category: 'data_modification'
        });
      } catch (logError) {
        console.error('Error creating case failure log:', logError);
      }

      res.status(500).json({
        success: false,
        message: error.message || 'Failed to create case'
      });
    }
  }
);

/**
 * GET /api/cases
 * Get cases with filtering and pagination
 */
router.get('/', 
  auth, 
  permissionAuth(['view_all_cases', 'view_case']),
  validatePagination,
  handleValidationErrors,
  async (req, res) => {
    try {
      const Case = req.app.locals.models.Case;
      
      // Build filters from query parameters
      const filters = {};
      if (req.query.status) filters.status = req.query.status;
      if (req.query.priority) filters.priority = req.query.priority;
      if (req.query.createdBy) filters.createdBy = req.query.createdBy;
      if (req.query.assignedTo) filters.assignedTo = req.query.assignedTo;
      if (req.query.search) filters.search = req.query.search;
      if (req.query.tags) {
        filters.tags = Array.isArray(req.query.tags) ? req.query.tags : [req.query.tags];
      }
      if (req.query.dateFrom) filters.dateFrom = req.query.dateFrom;
      if (req.query.dateTo) filters.dateTo = req.query.dateTo;
      
      // Linked entity filters
      if (req.query.linkedType || req.query.linkedId) {
        filters.linkedTo = {};
        if (req.query.linkedType) filters.linkedTo.type = req.query.linkedType;
        if (req.query.linkedId) filters.linkedTo.id = req.query.linkedId;
      }

      // Build options
      const options = {
        page: parseInt(req.query.page) || 1,
        limit: parseInt(req.query.limit) || 10,
        sortBy: req.query.sortBy || 'createdAt',
        sortOrder: req.query.sortOrder === 'asc' || req.query.sortOrder === '1' ? 1 : -1
      };

      const result = await Case.getCases(filters, options);

      // Log case viewing (only log once per request, not for each case)
      try {
        await CaseLog.createLogEntry(req.app.locals.db, {
          user_id: req.user._id,
          user_email: req.user.email || 'unknown',
          action: 'view_all_cases',
          entity_type: 'case_system',
          entity_id: null,
          ip_address: req.ip || req.connection?.remoteAddress || 'unknown',
          user_agent: req.get('User-Agent') || 'unknown',
          details: {
            request_method: req.method,
            endpoint: req.originalUrl,
            success: true,
            filters_applied: filters,
            results_count: result.cases.length,
            total_count: result.pagination.totalCases,
            page: options.page,
            limit: options.limit
          },
          severity: 'low',
          category: 'data_access'
        });
      } catch (logError) {
        console.error('Error creating case view log:', logError);
        // Don't fail the request if logging fails
      }

      // Generate signed URLs for attachments in all cases
      const casesWithSignedUrls = await generateSignedUrlsForCases(result.cases);

      res.json({
        success: true,
        message: 'Cases retrieved successfully',
        data: casesWithSignedUrls,
        pagination: result.pagination
      });
    } catch (error) {
      console.error('Get cases error:', error);
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to retrieve cases'
      });
    }
  }
);

/**
 * GET /api/cases/stats
 * Get case statistics
 */
router.get('/stats', 
  auth, 
  permissionAuth(['view_case_stats']),
  async (req, res) => {
    try {
      const Case = req.app.locals.models.Case;
      
      const filters = {};
      if (req.query.dateFrom) filters.dateFrom = req.query.dateFrom;
      if (req.query.dateTo) filters.dateTo = req.query.dateTo;
      if (req.query.assignedTo) filters.assignedTo = req.query.assignedTo;

      const stats = await Case.getCaseStats(filters);

      // Log case statistics access
      try {
        await CaseLog.createLogEntry(req.app.locals.db, {
          user_id: req.user._id,
          user_email: req.user.email || 'unknown',
          action: 'view_case_stats',
          entity_type: 'case_analytics',
          entity_id: null,
          ip_address: req.ip || req.connection?.remoteAddress || 'unknown',
          user_agent: req.get('User-Agent') || 'unknown',
          details: {
            request_method: req.method,
            endpoint: req.originalUrl,
            success: true,
            filters_applied: filters,
            stats_generated: {
              total_cases: stats.totalCases,
              open_cases: stats.openCases,
              resolved_cases: stats.resolvedCases
            }
          },
          severity: 'low',
          category: 'data_access'
        });
      } catch (logError) {
        console.error('Error creating case stats log:', logError);
        // Don't fail the request if logging fails
      }

      res.json({
        success: true,
        message: 'Case statistics retrieved successfully',
        data: stats
      });
    } catch (error) {
      console.error('Get case stats error:', error);
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to retrieve case statistics'
      });
    }
  }
);

/**
 * GET /api/cases/debug-permissions
 * Debug route to check user permissions (temporary)
 */
router.get('/debug-permissions', 
  auth,
  async (req, res) => {
    try {
      const user = req.user;
      
      const debugInfo = {
        userId: user._id,
        email: user.email,
        role: user.role,
        roleName: user.role_name,
        hasPermissions: Array.isArray(user.permissions),
        permissionsCount: user.permissions?.length || 0,
        grantedPermissions: user.permissions?.filter(p => p.granted === true).map(p => p.permission_name) || [],
        casePermissions: user.permissions?.filter(p => 
          p.permission_name?.includes('case') && p.granted === true
        ).map(p => p.permission_name) || [],
        isAdmin: user.role === 'Admin' || user.role_name === 'Admin',
        isSupervisor: user.role === 'Supervisor' || user.role_name === 'Supervisor'
      };
      
      res.json({
        success: true,
        message: 'User permission debug information',
        data: debugInfo
      });
    } catch (error) {
      console.error('Debug permissions error:', error);
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to get debug information'
      });
    }
  }
);

/**
 * GET /api/cases/logs
 * Get case logs with optional filters
 * @access Private (requires view_case_analytics permission)
 */
router.get('/logs', 
  auth, 
  permissionAuth('view_case_analytics'), 
  async (req, res) => {
    try {
      const { 
        user_id, 
        action, 
        entity_type,
        entity_id, 
        start_date, 
        end_date,
        severity,
        category,
        branch_id,
        page = 1, 
        limit = 20 
      } = req.query;
      
      const filters = {};
      if (user_id) filters.user_id = user_id;
      if (action) filters.action = action;
      if (entity_type) filters.entity_type = entity_type;
      if (entity_id) filters.entity_id = entity_id;
      if (start_date) filters.start_date = start_date;
      if (end_date) filters.end_date = end_date;
      if (severity) filters.severity = severity;
      if (category) filters.category = category;
      if (branch_id) filters.branch_id = branch_id;
      
      const options = {
        limit: parseInt(limit),
        skip: (parseInt(page) - 1) * parseInt(limit),
        sort: { timestamp: -1 }
      };
      
      const logs = await CaseLog.findCaseLogs(req.app.locals.db, filters, options);
      const total = await CaseLog.countCaseLogs(req.app.locals.db, filters);
      
      // Log access to case logs
      try {
        await CaseLog.createLogEntry(req.app.locals.db, {
          user_id: req.user._id,
          user_email: req.user.email || 'unknown',
          action: 'view_case_logs',
          entity_type: 'case_analytics',
          entity_id: null,
          ip_address: req.ip || req.connection?.remoteAddress || 'unknown',
          user_agent: req.get('User-Agent') || 'unknown',
          details: {
            request_method: req.method,
            endpoint: req.originalUrl,
            success: true,
            filters_applied: filters,
            results_count: logs.length,
            total_count: total,
            page: parseInt(page),
            limit: parseInt(limit)
          },
          severity: 'low',
          category: 'data_access'
        });
      } catch (logError) {
        console.error('Error creating case logs access log:', logError);
      }
      
      res.json({
        success: true,
        message: 'Case logs retrieved successfully',
        data: logs,
        pagination: {
          current_page: parseInt(page),
          total_pages: Math.ceil(total / limit),
          total_logs: total,
          per_page: parseInt(limit)
        }
      });
    } catch (error) {
      console.error('Error fetching case logs:', error);
      res.status(500).json({ 
        success: false,
        message: error.message || 'Failed to retrieve case logs'
      });
    }
  }
);

/**
 * GET /api/cases/logs/statistics
 * Get case log statistics
 * @access Private (requires view_case_analytics permission)
 */
router.get('/logs/statistics', 
  auth, 
  permissionAuth('view_case_analytics'), 
  async (req, res) => {
    try {
      const { start_date, end_date } = req.query;
      
      const startDate = start_date ? new Date(start_date) : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000); // 30 days ago
      const endDate = end_date ? new Date(end_date) : new Date();
      
      const statistics = await CaseLog.getCaseLogStatistics(req.app.locals.db, startDate, endDate);
      
      // Log access to case log statistics
      try {
        await CaseLog.createLogEntry(req.app.locals.db, {
          user_id: req.user._id,
          user_email: req.user.email || 'unknown',
          action: 'view_case_log_stats',
          entity_type: 'case_analytics',
          entity_id: null,
          ip_address: req.ip || req.connection?.remoteAddress || 'unknown',
          user_agent: req.get('User-Agent') || 'unknown',
          details: {
            request_method: req.method,
            endpoint: req.originalUrl,
            success: true,
            date_range: { start_date: startDate, end_date: endDate },
            statistics: statistics
          },
          severity: 'low',
          category: 'data_access'
        });
      } catch (logError) {
        console.error('Error creating case log statistics access log:', logError);
      }
      
      res.json({
        success: true,
        message: 'Case log statistics retrieved successfully',
        data: {
          date_range: { start_date: startDate, end_date: endDate },
          statistics: statistics
        }
      });
    } catch (error) {
      console.error('Error fetching case log statistics:', error);
      res.status(500).json({ 
        success: false,
        message: error.message || 'Failed to retrieve case log statistics'
      });
    }
  }
);

/**
 * GET /api/cases/logs/recent
 * Get recent case activity
 * @access Private (requires view_case_analytics permission)
 */
router.get('/logs/recent', 
  auth, 
  permissionAuth('view_case_analytics'), 
  async (req, res) => {
    try {
      const { hours = 24, limit = 50 } = req.query;
      
      const recentActivity = await CaseLog.findRecentActivity(
        req.app.locals.db, 
        parseInt(hours), 
        parseInt(limit)
      );
      
      // Log access to recent case activity
      try {
        await CaseLog.createLogEntry(req.app.locals.db, {
          user_id: req.user._id,
          user_email: req.user.email || 'unknown',
          action: 'view_recent_case_activity',
          entity_type: 'case_analytics',
          entity_id: null,
          ip_address: req.ip || req.connection?.remoteAddress || 'unknown',
          user_agent: req.get('User-Agent') || 'unknown',
          details: {
            request_method: req.method,
            endpoint: req.originalUrl,
            success: true,
            hours_back: parseInt(hours),
            limit: parseInt(limit),
            results_count: recentActivity.length
          },
          severity: 'low',
          category: 'data_access'
        });
      } catch (logError) {
        console.error('Error creating recent activity access log:', logError);
      }
      
      res.json({
        success: true,
        message: 'Recent case activity retrieved successfully',
        data: {
          hours_back: parseInt(hours),
          activity_count: recentActivity.length,
          activities: recentActivity
        }
      });
    } catch (error) {
      console.error('Error fetching recent case activity:', error);
      res.status(500).json({ 
        success: false,
        message: error.message || 'Failed to retrieve recent case activity'
      });
    }
  }
);

/**
 * GET /api/cases/logs/display
 * Get formatted case logs with user-friendly display
 * @access Private (requires view_case_analytics permission)
 */
router.get('/logs/display', 
  auth, 
  permissionAuth('view_case_analytics'), 
  async (req, res) => {
    try {
      const { 
        user_id, 
        action, 
        entity_type,
        entity_id, 
        start_date, 
        end_date,
        severity,
        category,
        branch_id,
        page = 1, 
        limit = 20,
        format = 'detailed' // detailed, summary, timeline
      } = req.query;
      
      const filters = {};
      if (user_id) filters.user_id = user_id;
      if (action) filters.action = action;
      if (entity_type) filters.entity_type = entity_type;
      if (entity_id) filters.entity_id = entity_id;
      if (start_date) filters.start_date = start_date;
      if (end_date) filters.end_date = end_date;
      if (severity) filters.severity = severity;
      if (category) filters.category = category;
      if (branch_id) filters.branch_id = branch_id;
      
      const options = {
        limit: parseInt(limit),
        skip: (parseInt(page) - 1) * parseInt(limit),
        sort: { timestamp: -1 }
      };
      
      const logs = await CaseLog.findCaseLogs(req.app.locals.db, filters, options);
      const total = await CaseLog.countCaseLogs(req.app.locals.db, filters);
      
      // Enhance logs with user information
      const enhancedLogs = await Promise.all(logs.map(async (log) => {
        let user = null;
        if (log.user_id) {
          try {
            user = await req.app.locals.db.collection('users').findOne(
              { _id: log.user_id },
              { projection: { first_name: 1, last_name: 1, email: 1, role_name: 1 } }
            );
          } catch (error) {
            console.warn('Could not fetch user for log:', log._id);
          }
        }
        
        // Format the log based on requested format
        const baseLog = {
          id: log._id,
          timestamp: log.timestamp,
          action: log.action,
          entity_type: log.entity_type,
          entity_id: log.entity_id,
          severity: log.severity,
          category: log.category,
          ip_address: log.ip_address,
          user_agent: log.user_agent,
          user: user ? {
            name: `${user.first_name} ${user.last_name}`,
            email: user.email,
            role: user.role_name
          } : {
            email: log.user_email || 'Unknown',
            name: 'Unknown User',
            role: 'Unknown'
          }
        };
        
        // Add format-specific fields
        if (format === 'detailed') {
          return {
            ...baseLog,
            details: log.details || {},
            session_id: log.session_id,
            branch_id: log.branch_id,
            formatted_action: formatActionName(log.action),
            formatted_timestamp: log.timestamp.toLocaleString(),
            success_indicator: log.details?.success ? '✅' : '❌'
          };
        } else if (format === 'summary') {
          return {
            ...baseLog,
            summary: generateLogSummary(log),
            formatted_timestamp: log.timestamp.toLocaleString()
          };
        } else if (format === 'timeline') {
          return {
            id: log._id,
            timestamp: log.timestamp,
            formatted_timestamp: log.timestamp.toLocaleString(),
            timeline_entry: generateTimelineEntry(log, user),
            severity: log.severity,
            entity_type: log.entity_type
          };
        }
        
        return baseLog;
      }));
      
      // Log access to formatted case logs
      try {
        await CaseLog.createLogEntry(req.app.locals.db, {
          user_id: req.user._id,
          user_email: req.user.email || 'unknown',
          action: 'view_case_logs_display',
          entity_type: 'case_analytics',
          entity_id: null,
          ip_address: req.ip || req.connection?.remoteAddress || 'unknown',
          user_agent: req.get('User-Agent') || 'unknown',
          details: {
            request_method: req.method,
            endpoint: req.originalUrl,
            success: true,
            filters_applied: filters,
            results_count: enhancedLogs.length,
            total_count: total,
            page: parseInt(page),
            limit: parseInt(limit),
            format: format
          },
          severity: 'low',
          category: 'data_access'
        });
      } catch (logError) {
        console.error('Error creating case logs display access log:', logError);
      }
      
      res.json({
        success: true,
        message: 'Formatted case logs retrieved successfully',
        data: {
          logs: enhancedLogs,
          format: format,
          filters_applied: filters,
          available_actions: getAvailableActions(),
          available_entity_types: getAvailableEntityTypes(),
          severity_levels: ['low', 'medium', 'high', 'critical'],
          categories: ['authentication', 'authorization', 'data_access', 'data_modification', 'system']
        },
        pagination: {
          current_page: parseInt(page),
          total_pages: Math.ceil(total / limit),
          total_logs: total,
          per_page: parseInt(limit)
        }
      });
    } catch (error) {
      console.error('Error fetching formatted case logs:', error);
      res.status(500).json({ 
        success: false,
        message: error.message || 'Failed to retrieve formatted case logs'
      });
    }
  }
);

/**
 * GET /api/cases/logs/list
 * Get comprehensive list of case logs with advanced filtering
 * @access Private (requires view_case_analytics permission)
 */
router.get('/logs/list', 
  auth, 
  permissionAuth('view_case_analytics'), 
  async (req, res) => {
    try {
      const { 
        search,
        user_email,
        action_group,
        date_range = '7d', // 1d, 7d, 30d, 90d, custom
        custom_start,
        custom_end,
        severity_levels,
        include_user_details = 'true',
        include_case_details = 'true',
        sort_by = 'timestamp',
        sort_order = 'desc',
        page = 1, 
        limit = 50
      } = req.query;
      
      // Build dynamic filters
      const filters = {};
      
      // Handle date range filtering
      if (date_range === 'custom' && custom_start && custom_end) {
        filters.start_date = custom_start;
        filters.end_date = custom_end;
      } else if (date_range !== 'all') {
        const now = new Date();
        const ranges = {
          '1d': 1,
          '7d': 7,
          '30d': 30,
          '90d': 90
        };
        const days = ranges[date_range] || 7;
        filters.start_date = new Date(now.getTime() - (days * 24 * 60 * 60 * 1000)).toISOString();
        filters.end_date = now.toISOString();
      }
      
      // Handle search in user email or action
      if (search) {
        // We'll filter this after getting the data since MongoDB text search is complex
      }
      
      if (user_email) {
        filters.user_email = user_email;
      }
      
      // Handle action groups
      if (action_group) {
        const actionGroups = {
          'case_management': ['create_case', 'update_case', 'delete_case', 'view_case'],
          'case_notes': ['add_case_note', 'remove_case_note'],
          'case_attachments': ['upload_case_attachment', 'remove_case_attachment'],
          'case_assignment': ['assign_case', 'unassign_case'],
          'case_status': ['resolve_case', 'close_case', 'reopen_case', 'change_case_status'],
          'case_priority': ['change_case_priority'],
          'case_analytics': ['view_case_stats', 'view_case_logs', 'export_case_data']
        };
        
        if (actionGroups[action_group]) {
          // MongoDB $in query for multiple actions
          filters.action_in = actionGroups[action_group];
        }
      }
      
      // Handle severity levels (comma-separated)
      if (severity_levels) {
        filters.severity_in = severity_levels.split(',');
      }
      
      // Build sort options
      const sortField = sort_by === 'timestamp' ? 'timestamp' : sort_by;
      const sortDirection = sort_order === 'asc' ? 1 : -1;
      
      const options = {
        limit: parseInt(limit),
        skip: (parseInt(page) - 1) * parseInt(limit),
        sort: { [sortField]: sortDirection }
      };
      
      const logs = await CaseLog.findCaseLogs(req.app.locals.db, filters, options);
      const total = await CaseLog.countCaseLogs(req.app.locals.db, filters);
      
      // Apply text search if provided
      let filteredLogs = logs;
      if (search) {
        const searchLower = search.toLowerCase();
        filteredLogs = logs.filter(log => 
          (log.user_email && log.user_email.toLowerCase().includes(searchLower)) ||
          (log.action && log.action.toLowerCase().includes(searchLower)) ||
          (log.details && JSON.stringify(log.details).toLowerCase().includes(searchLower))
        );
      }
      
      // Enhance logs with additional details
      const enhancedLogs = await Promise.all(filteredLogs.map(async (log) => {
        const enhancedLog = {
          id: log._id,
          timestamp: log.timestamp,
          formatted_timestamp: log.timestamp.toLocaleString(),
          action: log.action,
          formatted_action: formatActionName(log.action),
          entity_type: log.entity_type,
          entity_id: log.entity_id,
          severity: log.severity,
          severity_icon: getSeverityIcon(log.severity),
          category: log.category,
          ip_address: log.ip_address,
          user_agent: log.user_agent,
          user_email: log.user_email,
          success: log.details?.success || false,
          success_icon: log.details?.success ? '✅' : '❌'
        };
        
        // Include user details if requested
        if (include_user_details === 'true' && log.user_id) {
          try {
            const user = await req.app.locals.db.collection('users').findOne(
              { _id: log.user_id },
              { 
                projection: { 
                  first_name: 1, 
                  last_name: 1, 
                  email: 1, 
                  role_name: 1,
                  staff_code: 1,
                  branch: 1
                } 
              }
            );
            
            if (user) {
              enhancedLog.user_details = {
                name: `${user.first_name} ${user.last_name}`,
                email: user.email,
                role: user.role_name,
                staff_code: user.staff_code,
                branch: user.branch?.branch_name || 'Unknown'
              };
            }
          } catch (error) {
            console.warn('Could not fetch user details for log:', log._id);
          }
        }
        
        // Include case details if requested and entity is a case
        if (include_case_details === 'true' && log.entity_type === 'case' && log.entity_id) {
          try {
            const caseDoc = await req.app.locals.db.collection('cases').findOne(
              { _id: typeof log.entity_id === 'string' ? new ObjectId(log.entity_id) : log.entity_id },
              { projection: { title: 1, status: 1, priority: 1, createdBy: 1 } }
            );
            
            if (caseDoc) {
              enhancedLog.case_details = {
                title: caseDoc.title,
                status: caseDoc.status,
                priority: caseDoc.priority
              };
            }
          } catch (error) {
            console.warn('Could not fetch case details for log:', log._id);
          }
        }
        
        return enhancedLog;
      }));
      
      // Generate summary statistics for this result set
      const summaryStats = {
        total_logs: enhancedLogs.length,
        actions_summary: {},
        severity_summary: {},
        success_rate: 0,
        unique_users: new Set(enhancedLogs.map(log => log.user_email)).size,
        date_range_covered: {
          start: enhancedLogs.length > 0 ? enhancedLogs[enhancedLogs.length - 1].timestamp : null,
          end: enhancedLogs.length > 0 ? enhancedLogs[0].timestamp : null
        }
      };
      
      // Calculate action summary
      enhancedLogs.forEach(log => {
        summaryStats.actions_summary[log.action] = (summaryStats.actions_summary[log.action] || 0) + 1;
        summaryStats.severity_summary[log.severity] = (summaryStats.severity_summary[log.severity] || 0) + 1;
      });
      
      // Calculate success rate
      const successfulLogs = enhancedLogs.filter(log => log.success).length;
      summaryStats.success_rate = enhancedLogs.length > 0 ? 
        Math.round((successfulLogs / enhancedLogs.length) * 100) : 0;
      
      // Log access to comprehensive case logs list
      try {
        await CaseLog.createLogEntry(req.app.locals.db, {
          user_id: req.user._id,
          user_email: req.user.email || 'unknown',
          action: 'view_case_logs_list',
          entity_type: 'case_analytics',
          entity_id: null,
          ip_address: req.ip || req.connection?.remoteAddress || 'unknown',
          user_agent: req.get('User-Agent') || 'unknown',
          details: {
            request_method: req.method,
            endpoint: req.originalUrl,
            success: true,
            filters_applied: {
              search,
              user_email,
              action_group,
              date_range,
              severity_levels,
              sort_by,
              sort_order
            },
            results_count: enhancedLogs.length,
            total_count: total,
            page: parseInt(page),
            limit: parseInt(limit)
          },
          severity: 'low',
          category: 'data_access'
        });
      } catch (logError) {
        console.error('Error creating case logs list access log:', logError);
      }
      
      res.json({
        success: true,
        message: 'Comprehensive case logs list retrieved successfully',
        data: {
          logs: enhancedLogs,
          summary: summaryStats,
          filters_applied: {
            search,
            user_email,
            action_group,
            date_range,
            severity_levels,
            sort_by,
            sort_order
          },
          metadata: {
            available_action_groups: {
              'case_management': 'Case CRUD Operations',
              'case_notes': 'Note Management',
              'case_attachments': 'Attachment Management',
              'case_assignment': 'Assignment Changes',
              'case_status': 'Status & Resolution',
              'case_priority': 'Priority Changes',
              'case_analytics': 'Analytics & Reporting'
            },
            available_date_ranges: ['1d', '7d', '30d', '90d', 'custom'],
            available_severity_levels: ['low', 'medium', 'high', 'critical'],
            available_sort_fields: ['timestamp', 'action', 'severity', 'user_email'],
            total_unique_actions: Object.keys(summaryStats.actions_summary).length
          }
        },
        pagination: {
          current_page: parseInt(page),
          total_pages: Math.ceil(total / limit),
          total_logs: total,
          per_page: parseInt(limit),
          showing: enhancedLogs.length
        }
      });
    } catch (error) {
      console.error('Error fetching comprehensive case logs list:', error);
      res.status(500).json({ 
        success: false,
        message: error.message || 'Failed to retrieve comprehensive case logs list'
      });
    }
  }
);

/**
 * GET /api/cases/logs/export
 * Export case logs in various formats (JSON, CSV)
 * @access Private (requires view_case_analytics permission)
 */
router.get('/logs/export', 
  auth, 
  permissionAuth('view_case_analytics'), 
  async (req, res) => {
    try {
      const { 
        format = 'json', // json, csv
        start_date, 
        end_date,
        action,
        severity,
        user_id,
        limit = 1000
      } = req.query;
      
      const filters = {};
      if (start_date) filters.start_date = start_date;
      if (end_date) filters.end_date = end_date;
      if (action) filters.action = action;
      if (severity) filters.severity = severity;
      if (user_id) filters.user_id = user_id;
      
      const options = {
        limit: parseInt(limit),
        skip: 0,
        sort: { timestamp: -1 }
      };
      
      const logs = await CaseLog.findCaseLogs(req.app.locals.db, filters, options);
      
      // Log export action
      try {
        await CaseLog.createLogEntry(req.app.locals.db, {
          user_id: req.user._id,
          user_email: req.user.email || 'unknown',
          action: 'export_case_data',
          entity_type: 'case_analytics',
          entity_id: null,
          ip_address: req.ip || req.connection?.remoteAddress || 'unknown',
          user_agent: req.get('User-Agent') || 'unknown',
          details: {
            request_method: req.method,
            endpoint: req.originalUrl,
            success: true,
            export_format: format,
            filters_applied: filters,
            records_exported: logs.length,
            export_timestamp: new Date()
          },
          severity: 'medium',
          category: 'data_access'
        });
      } catch (logError) {
        console.error('Error creating export log:', logError);
      }
      
      if (format === 'csv') {
        // Convert to CSV format
        const csvHeaders = [
          'ID', 'Timestamp', 'User Email', 'Action', 'Entity Type', 'Entity ID',
          'Severity', 'Category', 'IP Address', 'Success', 'Details'
        ];
        
        const csvRows = logs.map(log => [
          log._id.toString(),
          log.timestamp.toISOString(),
          log.user_email || '',
          log.action,
          log.entity_type,
          log.entity_id || '',
          log.severity,
          log.category,
          log.ip_address || '',
          log.details?.success ? 'Yes' : 'No',
          JSON.stringify(log.details || {}).replace(/"/g, '""')
        ]);
        
        const csvContent = [
          csvHeaders.join(','),
          ...csvRows.map(row => row.map(field => `"${field}"`).join(','))
        ].join('\n');
        
        const filename = `case_logs_export_${new Date().toISOString().split('T')[0]}.csv`;
        
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
        res.send(csvContent);
      } else {
        // JSON format
        const filename = `case_logs_export_${new Date().toISOString().split('T')[0]}.json`;
        
        res.setHeader('Content-Type', 'application/json');
        res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
        res.json({
          export_info: {
            generated_at: new Date(),
            generated_by: req.user.email,
            total_records: logs.length,
            filters_applied: filters,
            format: 'json'
          },
          data: logs
        });
      }
    } catch (error) {
      console.error('Error exporting case logs:', error);
      res.status(500).json({ 
        success: false,
        message: error.message || 'Failed to export case logs'
      });
    }
  }
);

/**
 * GET /api/cases/logs/dashboard
 * Get dashboard data for case logs overview
 * @access Private (requires view_case_analytics permission)
 */
router.get('/logs/dashboard', 
  auth, 
  permissionAuth('view_case_analytics'), 
  async (req, res) => {
    try {
      const { days = 30 } = req.query;
      
      const endDate = new Date();
      const startDate = new Date(Date.now() - (parseInt(days) * 24 * 60 * 60 * 1000));
      
      // Get basic statistics
      const stats = await CaseLog.getCaseLogStatistics(req.app.locals.db, startDate, endDate);
      
      // Get recent activity
      const recentActivity = await CaseLog.findRecentActivity(req.app.locals.db, 24, 10);
      
      // Get activity by day (for charts)
      const dailyActivity = await req.app.locals.db.collection('case_logs').aggregate([
        {
          $match: {
            timestamp: {
              $gte: startDate,
              $lte: endDate
            }
          }
        },
        {
          $group: {
            _id: {
              $dateToString: { format: "%Y-%m-%d", date: "$timestamp" }
            },
            count: { $sum: 1 },
            actions: { $push: "$action" },
            severities: { $push: "$severity" }
          }
        },
        {
          $sort: { "_id": 1 }
        }
      ]).toArray();
      
      // Get top users by activity
      const topUsers = await req.app.locals.db.collection('case_logs').aggregate([
        {
          $match: {
            timestamp: {
              $gte: startDate,
              $lte: endDate
            }
          }
        },
        {
          $group: {
            _id: "$user_email",
            activity_count: { $sum: 1 },
            actions: { $addToSet: "$action" },
            last_activity: { $max: "$timestamp" }
          }
        },
        {
          $sort: { activity_count: -1 }
        },
        {
          $limit: 10
        }
      ]).toArray();
      
      // Get action distribution
      const actionDistribution = await req.app.locals.db.collection('case_logs').aggregate([
        {
          $match: {
            timestamp: {
              $gte: startDate,
              $lte: endDate
            }
          }
        },
        {
          $group: {
            _id: "$action",
            count: { $sum: 1 },
            users: { $addToSet: "$user_email" }
          }
        },
        {
          $sort: { count: -1 }
        }
      ]).toArray();
      
      // Get error rate (failed actions)
      const errorRate = await req.app.locals.db.collection('case_logs').aggregate([
        {
          $match: {
            timestamp: {
              $gte: startDate,
              $lte: endDate
            }
          }
        },
        {
          $group: {
            _id: null,
            total: { $sum: 1 },
            failed: {
              $sum: {
                $cond: [{ $eq: ["$details.success", false] }, 1, 0]
              }
            }
          }
        }
      ]).toArray();
      
      const errorRatePercent = errorRate.length > 0 && errorRate[0].total > 0 
        ? Math.round((errorRate[0].failed / errorRate[0].total) * 100) 
        : 0;
      
      // Log dashboard access
      try {
        await CaseLog.createLogEntry(req.app.locals.db, {
          user_id: req.user._id,
          user_email: req.user.email || 'unknown',
          action: 'view_case_logs_dashboard',
          entity_type: 'case_analytics',
          entity_id: null,
          ip_address: req.ip || req.connection?.remoteAddress || 'unknown',
          user_agent: req.get('User-Agent') || 'unknown',
          details: {
            request_method: req.method,
            endpoint: req.originalUrl,
            success: true,
            days_requested: parseInt(days),
            dashboard_components: [
              'statistics', 'recent_activity', 'daily_activity', 
              'top_users', 'action_distribution', 'error_rate'
            ]
          },
          severity: 'low',
          category: 'data_access'
        });
      } catch (logError) {
        console.error('Error creating dashboard access log:', logError);
      }
      
      res.json({
        success: true,
        message: 'Case logs dashboard data retrieved successfully',
        data: {
          period: {
            start_date: startDate,
            end_date: endDate,
            days: parseInt(days)
          },
          overview: {
            total_actions: stats.total_actions || 0,
            unique_users: stats.unique_user_count || 0,
            error_rate_percent: errorRatePercent,
            total_errors: errorRate.length > 0 ? errorRate[0].failed : 0
          },
          recent_activity: recentActivity.slice(0, 5).map(log => ({
            timestamp: log.timestamp,
            formatted_timestamp: log.timestamp.toLocaleString(),
            action: formatActionName(log.action),
            user: log.user_email,
            severity: log.severity,
            severity_icon: getSeverityIcon(log.severity),
            success: log.details?.success || false
          })),
          daily_activity: dailyActivity.map(day => ({
            date: day._id,
            count: day.count,
            actions: [...new Set(day.actions)].length,
            severity_breakdown: {
              low: day.severities.filter(s => s === 'low').length,
              medium: day.severities.filter(s => s === 'medium').length,
              high: day.severities.filter(s => s === 'high').length,
              critical: day.severities.filter(s => s === 'critical').length
            }
          })),
          top_users: topUsers.map(user => ({
            email: user._id,
            activity_count: user.activity_count,
            unique_actions: user.actions.length,
            last_activity: user.last_activity,
            formatted_last_activity: user.last_activity.toLocaleString()
          })),
          action_distribution: actionDistribution.map(action => ({
            action: action._id,
            formatted_action: formatActionName(action._id),
            count: action.count,
            unique_users: action.users.length,
            percentage: stats.total_actions > 0 ? 
              Math.round((action.count / stats.total_actions) * 100) : 0
          })),
          severity_distribution: {
            low: stats.severity_counts?.filter(s => s === 'low').length || 0,
            medium: stats.severity_counts?.filter(s => s === 'medium').length || 0,
            high: stats.severity_counts?.filter(s => s === 'high').length || 0,
            critical: stats.severity_counts?.filter(s => s === 'critical').length || 0
          }
        }
      });
    } catch (error) {
      console.error('Error fetching case logs dashboard data:', error);
      res.status(500).json({ 
        success: false,
        message: error.message || 'Failed to retrieve dashboard data'
      });
    }
  }
);

/**
 * GET /api/cases/logs/:logId
 * Get detailed information about a specific log entry
 * @access Private (requires view_case_analytics permission)
 */
router.get('/logs/:logId', 
  auth, 
  permissionAuth('view_case_analytics'), 
  async (req, res) => {
    try {
      const { logId } = req.params;
      
      // Validate ObjectId
      if (!ObjectId.isValid(logId)) {
        return res.status(400).json({
          success: false,
          message: 'Invalid log ID format'
        });
      }
      
      const log = await req.app.locals.db.collection('case_logs').findOne({
        _id: new ObjectId(logId)
      });
      
      if (!log) {
        return res.status(404).json({
          success: false,
          message: 'Log entry not found'
        });
      }
      
      // Enhance log with additional details
      let userDetails = null;
      if (log.user_id) {
        try {
          userDetails = await req.app.locals.db.collection('users').findOne(
            { _id: log.user_id },
            { 
              projection: { 
                first_name: 1, 
                last_name: 1, 
                email: 1, 
                role_name: 1,
                staff_code: 1,
                branch: 1
              } 
            }
          );
        } catch (error) {
          console.warn('Could not fetch user details for log:', logId);
        }
      }
      
      let caseDetails = null;
      if (log.entity_type === 'case' && log.entity_id) {
        try {
          caseDetails = await req.app.locals.db.collection('cases').findOne(
            { _id: typeof log.entity_id === 'string' ? new ObjectId(log.entity_id) : log.entity_id },
            { 
              projection: { 
                title: 1, 
                status: 1, 
                priority: 1, 
                createdBy: 1,
                assignedTo: 1,
                createdAt: 1,
                updatedAt: 1
              } 
            }
          );
        } catch (error) {
          console.warn('Could not fetch case details for log:', logId);
        }
      }
      
      // Get related logs (same entity, similar timeframe)
      const relatedLogs = await req.app.locals.db.collection('case_logs').find({
        _id: { $ne: log._id },
        $or: [
          { entity_id: log.entity_id },
          { user_id: log.user_id }
        ],
        timestamp: {
          $gte: new Date(log.timestamp.getTime() - (60 * 60 * 1000)), // 1 hour before
          $lte: new Date(log.timestamp.getTime() + (60 * 60 * 1000))  // 1 hour after
        }
      }).sort({ timestamp: -1 }).limit(5).toArray();
      
      // Log access to specific log entry
      try {
        await CaseLog.createLogEntry(req.app.locals.db, {
          user_id: req.user._id,
          user_email: req.user.email || 'unknown',
          action: 'view_case_log_details',
          entity_type: 'case_analytics',
          entity_id: logId,
          ip_address: req.ip || req.connection?.remoteAddress || 'unknown',
          user_agent: req.get('User-Agent') || 'unknown',
          details: {
            request_method: req.method,
            endpoint: req.originalUrl,
            success: true,
            viewed_log_id: logId,
            viewed_log_action: log.action,
            viewed_log_timestamp: log.timestamp
          },
          severity: 'low',
          category: 'data_access'
        });
      } catch (logError) {
        console.error('Error creating log details access log:', logError);
      }
      
      res.json({
        success: true,
        message: 'Log entry details retrieved successfully',
        data: {
          log: {
            ...log,
            formatted_timestamp: log.timestamp.toLocaleString(),
            formatted_action: formatActionName(log.action),
            severity_icon: getSeverityIcon(log.severity),
            success_icon: log.details?.success ? '✅' : '❌'
          },
          user_details: userDetails ? {
            name: `${userDetails.first_name} ${userDetails.last_name}`,
            email: userDetails.email,
            role: userDetails.role_name,
            staff_code: userDetails.staff_code,
            branch: userDetails.branch?.branch_name || 'Unknown'
          } : null,
          case_details: caseDetails,
          related_logs: relatedLogs.map(relLog => ({
            id: relLog._id,
            timestamp: relLog.timestamp,
            formatted_timestamp: relLog.timestamp.toLocaleString(),
            action: relLog.action,
            formatted_action: formatActionName(relLog.action),
            severity: relLog.severity,
            user_email: relLog.user_email
          })),
          metadata: {
            is_case_related: log.entity_type === 'case',
            has_user_details: !!userDetails,
            has_case_details: !!caseDetails,
            related_logs_count: relatedLogs.length
          }
        }
      });
    } catch (error) {
      console.error('Error fetching log entry details:', error);
      res.status(500).json({ 
        success: false,
        message: error.message || 'Failed to retrieve log entry details'
      });
    }
  }
);

/**
 * GET /api/cases/:id
 * Get case by ID
 */
router.get('/:id',
  (req, res, next) => {
    if (!ObjectId.isValid(req.params.id)) return next('route');
    next();
  },
  auth,
  permissionAuth(['view_case']),
  validateCaseId,
  handleValidationErrors,
  async (req, res) => {
    try {
      const Case = req.app.locals.models.Case;
      const caseDoc = await Case.getCaseById(req.params.id);

      if (!caseDoc) {
        // Log case not found attempt
        try {
          await CaseLog.createLogEntry(req.app.locals.db, {
            user_id: req.user._id,
            user_email: req.user.email || 'unknown',
            action: 'view_case',
            entity_type: 'case',
            entity_id: req.params.id,
            ip_address: req.ip || req.connection?.remoteAddress || 'unknown',
            user_agent: req.get('User-Agent') || 'unknown',
            details: {
              request_method: req.method,
              endpoint: req.originalUrl,
              success: false,
              error_message: 'Case not found'
            },
            severity: 'medium',
            category: 'data_access'
          });
        } catch (logError) {
          console.error('Error creating case not found log:', logError);
        }

        return res.status(404).json({
          success: false,
          message: 'Case not found'
        });
      }

      // Log successful case viewing
      try {
        await CaseLog.createLogEntry(req.app.locals.db, {
          user_id: req.user._id,
          user_email: req.user.email || 'unknown',
          action: 'view_case',
          entity_type: 'case',
          entity_id: caseDoc._id,
          ip_address: req.ip || req.connection?.remoteAddress || 'unknown',
          user_agent: req.get('User-Agent') || 'unknown',
          details: {
            request_method: req.method,
            endpoint: req.originalUrl,
            success: true,
            case_title: caseDoc.title,
            case_status: caseDoc.status,
            case_priority: caseDoc.priority,
            assigned_to: caseDoc.assignedTo || null
          },
          severity: 'low',
          category: 'data_access'
        });
      } catch (logError) {
        console.error('Error creating case view log:', logError);
        // Don't fail the request if logging fails
      }

      // Generate signed URLs for attachments
      const caseWithSignedUrls = await generateSignedUrlsForCase(caseDoc);

      res.json({
        success: true,
        message: 'Case retrieved successfully',
        data: caseWithSignedUrls
      });
    } catch (error) {
      console.error('Get case by ID error:', error);
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to retrieve case'
      });
    }
  }
);

/**
 * PUT /api/cases/:id
 * Update case
 */
router.put('/:id', 
  auth, 
  permissionAuth(['update_case']),
  validateCaseId, 
  validateCaseUpdate, 
  handleValidationErrors,
  async (req, res) => {
    try {
      // Check if trying to update status to resolved/closed
      if (req.body.status && ['resolved', 'closed'].includes(req.body.status)) {
        // Check if user has resolve_case permission for status changes
        const hasResolvePermission = req.user.role_name === 'Admin' || 
                                   req.user.role_name === 'Supervisor' ||
                                   req.user.permissions?.some(p => 
                                     p.permission_name === 'resolve_case' && p.granted === true
                                   );
        
        if (!hasResolvePermission) {
          return res.status(403).json({
            success: false,
            message: 'Only administrators and supervisors can resolve or close cases'
          });
        }
      }

      const Case = req.app.locals.models.Case;
      
      // Get original case for logging comparison
      const originalCase = await Case.getCaseById(req.params.id);
      if (!originalCase) {
        return res.status(404).json({
          success: false,
          message: 'Case not found'
        });
      }

      const updatedCase = await Case.updateCase(req.params.id, req.body, req.user);

      // Log case update
      try {
        // Determine the specific action based on what was updated
        let action = 'update_case';
        if (req.body.status && req.body.status !== originalCase.status) {
          if (req.body.status === 'resolved') action = 'resolve_case';
          else if (req.body.status === 'closed') action = 'close_case';
          else action = 'change_case_status';
        } else if (req.body.priority && req.body.priority !== originalCase.priority) {
          action = 'change_case_priority';
        } else if (req.body.assignedTo !== originalCase.assignedTo) {
          action = 'assign_case';
        }

        await CaseLog.createLogEntry(req.app.locals.db, {
          user_id: req.user._id,
          user_email: req.user.email || 'unknown',
          action: action,
          entity_type: 'case',
          entity_id: updatedCase._id,
          ip_address: req.ip || req.connection?.remoteAddress || 'unknown',
          user_agent: req.get('User-Agent') || 'unknown',
          details: {
            request_method: req.method,
            endpoint: req.originalUrl,
            success: true,
            case_title: updatedCase.title,
            old_values: {
              status: originalCase.status,
              priority: originalCase.priority,
              assigned_to: originalCase.assignedTo,
              title: originalCase.title
            },
            new_values: {
              status: updatedCase.status,
              priority: updatedCase.priority,
              assigned_to: updatedCase.assignedTo,
              title: updatedCase.title
            },
            changes_made: Object.keys(req.body)
          },
          severity: action.includes('resolve') || action.includes('close') ? 'medium' : 'low',
          category: 'data_modification'
        });
      } catch (logError) {
        console.error('Error creating case update log:', logError);
        // Don't fail the request if logging fails
      }

      res.json({
        success: true,
        message: 'Case updated successfully',
        data: updatedCase
      });
    } catch (error) {
      console.error('Update case error:', error);
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to update case'
      });
    }
  }
);

/**
 * POST /api/cases/:id/notes
 * Add note to case
 */
router.post('/:id/notes', 
  auth, 
  permissionAuth(['add_case_notes', 'update_case']),
  validateCaseId, 
  validateNote, 
  handleValidationErrors,
  async (req, res) => {
    try {
      const Case = req.app.locals.models.Case;
      const updatedCase = await Case.addNote(req.params.id, req.body.content, req.user);

      // Log note addition
      try {
        await CaseLog.createLogEntry(req.app.locals.db, {
          user_id: req.user._id,
          user_email: req.user.email || 'unknown',
          action: 'add_case_note',
          entity_type: 'case_note',
          entity_id: updatedCase._id,
          ip_address: req.ip || req.connection?.remoteAddress || 'unknown',
          user_agent: req.get('User-Agent') || 'unknown',
          details: {
            request_method: req.method,
            endpoint: req.originalUrl,
            success: true,
            case_title: updatedCase.title,
            note_content: req.body.content.substring(0, 100) + (req.body.content.length > 100 ? '...' : ''),
            note_length: req.body.content.length,
            total_notes: updatedCase.notes?.length || 0
          },
          severity: 'low',
          category: 'data_modification'
        });
      } catch (logError) {
        console.error('Error creating note addition log:', logError);
        // Don't fail the request if logging fails
      }

      res.json({
        success: true,
        message: 'Note added successfully',
        data: updatedCase
      });
    } catch (error) {
      console.error('Add note error:', error);
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to add note'
      });
    }
  }
);

/**
 * GET /api/cases/:id/attachments/upload-info
 * Get information about how to upload attachments
 */
router.get('/:id/attachments/upload-info', 
  auth, 
  permissionAuth(['manage_case_attachments', 'update_case']),
  validateCaseId,
  handleValidationErrors,
  (req, res) => {      res.json({
        success: true,
        message: 'Case attachment API information',
        data: {
          upload: {
            endpoint: `/api/cases/${req.params.id}/attachments`,
            method: 'POST',
            contentType: 'multipart/form-data',
            fieldNames: {
              preferred: 'attachment',
              alternative: 'file',
              description: 'Use either "attachment" or "file" as the form field name for the file upload'
            },
            limits: {
              maxFileSize: '25MB',
              maxFileSizeBytes: 25 * 1024 * 1024
            },
            allowedTypes: {
              extensions: ['jpeg', 'jpg', 'png', 'gif', 'pdf', 'doc', 'docx', 'txt', 'csv', 'xlsx', 'xls'],
              mimeTypes: ['image/*', 'application/pdf', 'application/msword', 'application/vnd.*', 'text/plain', 'text/csv']
            }
          },
          list: {
            endpoint: `/api/cases/${req.params.id}/attachments`,
            method: 'GET',
            description: 'Get all attachments for the case with metadata and signed URLs'
          },
          view: {
            endpoint: `/api/cases/${req.params.id}/attachments/{index}/view`,
            method: 'GET',
            description: 'Get a signed URL to view a specific attachment by index'
          },
          download: {
            endpoint: `/api/cases/${req.params.id}/attachments/{index}/download`,
            method: 'GET',
            description: 'Get a signed URL to download a specific attachment by index'
          },
          delete: {
            endpoint: `/api/cases/${req.params.id}/attachments/{index}`,
            method: 'DELETE',
            description: 'Remove a specific attachment by index'
          },
          legacy: {
            endpoint: `/api/cases/${req.params.id}/attachments/{filename}`,
            method: 'GET',
            description: 'Legacy endpoint for accessing attachments by filename (deprecated)'
          },
          example: {
            curl: `curl -X POST \\
  ${process.env.API_URL || 'http://localhost:3000'}/api/cases/${req.params.id}/attachments \\
  -H "Authorization: Bearer YOUR_TOKEN" \\
  -F "attachment=@/path/to/file.pdf"`,
            javascript: `const formData = new FormData();
formData.append('attachment', file); // or formData.append('file', file);

fetch('/api/cases/${req.params.id}/attachments', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer YOUR_TOKEN'
  },
  body: formData
})`
          }
        }
      });
  }
);

/**
 * POST /api/cases/:id/attachments
 * Upload attachment to case
 */
router.post('/:id/attachments', 
  auth, 
  permissionAuth(['manage_case_attachments', 'update_case']),
  validateCaseId, 
  handleValidationErrors,
  (req, res, next) => {
    // Debug logging middleware (can be removed after testing)
    if (process.env.DEBUG_UPLOADS === 'true') {
      console.log('=== Case Attachment Upload Debug ===');
      console.log('Content-Type:', req.headers['content-type']);
      console.log('Request body fields:', Object.keys(req.body));
    }
    next();
  },
  (req, res, next) => {
    // Try 'attachment' field name first
    uploadCaseAttachment(req, res, (err) => {
      if (err || !req.file) {
        console.log('First attempt with "attachment" field failed:', err?.message || 'No file');
        
        // Check if this is a field name issue
        const contentType = req.headers['content-type'] || '';
        if (!contentType.includes('multipart/form-data')) {
          return res.status(400).json({
            success: false,
            message: 'Content-Type must be multipart/form-data for file uploads'
          });
        }
        
        // Reset req.file for second attempt
        req.file = undefined;
        
        // Try 'file' field name
        uploadCaseAttachmentFile(req, res, (err2) => {
          if (err2) {
            console.log('Second attempt with "file" field failed:', err2.message);
            
            // Provide detailed error message
            let errorMessage = 'File upload failed. ';
            if (err2.message && err2.message.includes('Invalid file type')) {
              errorMessage = err2.message;
            } else if (err2.code === 'LIMIT_FILE_SIZE') {
              errorMessage = 'File size exceeds the maximum allowed size of 25MB.';
            } else {
              errorMessage += 'Please ensure you are sending a file with field name "attachment" or "file" in a multipart/form-data request.';
            }
            
            return res.status(400).json({
              success: false,
              message: errorMessage,
              details: {
                expectedFieldNames: ['attachment', 'file'],
                maxFileSize: '25MB',
                allowedTypes: 'jpeg, jpg, png, gif, pdf, doc, docx, txt, csv, xlsx, xls'
              }
            });
          }
          next();
        });
      } else {
        console.log('File uploaded successfully with "attachment" field');
        next();
      }
    });
  },
  async (req, res) => {
    try {
      if (process.env.DEBUG_UPLOADS === 'true') {
        console.log('=== After Multer Processing ===');
        console.log('req.file:', req.file);
        console.log('req.body:', req.body);
      }
      
      if (!req.file) {
        return res.status(400).json({
          success: false,
          message: 'No file uploaded. Please ensure you are sending a file with field name "attachment" or "file".'
        });
      }

      const Case = req.app.locals.models.Case;
      const caseDoc = await Case.getCaseById(req.params.id);

      if (!caseDoc) {
        return res.status(404).json({
          success: false,
          message: 'Case not found'
        });
      }

      const attachment = {
        s3Key: req.file.key,
        filename: req.file.key.split('/').pop(), // Extract filename from S3 key
        originalName: req.file.originalname,
        mimetype: req.file.mimetype,
        size: req.file.size,
        s3Url: req.file.location,
        uploadedBy: req.user._id,
        uploadedAt: new Date()
      };

      const result = await Case.collection.updateOne(
        { _id: caseDoc._id },
        {
          $push: { attachments: attachment },
          $set: { updatedAt: new Date() }
        }
      );

      if (result.matchedCount === 0) {
        return res.status(404).json({
          success: false,
          message: 'Case not found'
        });
      }

      const updatedCase = await Case.getCaseById(req.params.id);

      // Log attachment upload
      try {
        await CaseLog.createLogEntry(req.app.locals.db, {
          user_id: req.user._id,
          user_email: req.user.email || 'unknown',
          action: 'upload_case_attachment',
          entity_type: 'case_attachment',
          entity_id: updatedCase._id,
          ip_address: req.ip || req.connection?.remoteAddress || 'unknown',
          user_agent: req.get('User-Agent') || 'unknown',
          details: {
            request_method: req.method,
            endpoint: req.originalUrl,
            success: true,
            case_title: updatedCase.title,
            attachment_info: {
              filename: attachment.filename,
              original_name: attachment.originalName,
              mimetype: attachment.mimetype,
              size: attachment.size
            },
            total_attachments: updatedCase.attachments?.length || 0
          },
          severity: 'low',
          category: 'data_modification'
        });
      } catch (logError) {
        console.error('Error creating attachment upload log:', logError);
        // Don't fail the request if logging fails
      }

      res.status(201).json({
        success: true,
        message: 'Attachment uploaded successfully',
        data: {
          case: updatedCase,
          attachment: {
            index: updatedCase.attachments.length - 1,
            filename: attachment.originalName,
            mimetype: attachment.mimetype,
            size: attachment.size,
            s3Key: attachment.s3Key,
            uploadedBy: attachment.uploadedBy,
            uploadedAt: attachment.uploadedAt,
            viewUrl: `/api/cases/${req.params.id}/attachments/${updatedCase.attachments.length - 1}/view`,
            downloadUrl: `/api/cases/${req.params.id}/attachments/${updatedCase.attachments.length - 1}/download`
          }
        }
      });
    } catch (error) {
      console.error('Upload attachment error:', error);
      
      // Clean up uploaded file from S3 if there was an error
      if (req.file && req.file.key) {
        try {
          await deleteFromS3(req.file.key);
        } catch (deleteError) {
          console.error('Error deleting S3 file:', deleteError);
        }
      }
      
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to upload attachment'
      });
    }
  }
);

/**
 * GET /api/cases/:id/attachments/:index/view
 * Get a signed URL to view a case attachment (following invoice external services pattern)
 * @access Private (requires view_case_attachments or view_case permission)
 */
router.get('/:id/attachments/:index/view', 
  auth, 
  permissionAuth(['view_case_attachments', 'view_case']),
  validateCaseId,
  param('index').isInt({ min: 0 }).withMessage('Index must be a non-negative integer'),
  handleValidationErrors,
  async (req, res) => {
    try {
      const Case = req.app.locals.models.Case;
      const attachmentIndex = parseInt(req.params.index);
      
      if (isNaN(attachmentIndex)) {
        return res.status(400).json({ 
          success: false,
          message: 'Invalid attachment index' 
        });
      }
      
      // Get the case
      const caseDoc = await Case.getCaseById(req.params.id);

      if (!caseDoc) {
        return res.status(404).json({
          success: false,
          message: 'Case not found'
        });
      }

      // Check if attachments exist
      if (!caseDoc.attachments || attachmentIndex >= caseDoc.attachments.length) {
        return res.status(404).json({
          success: false,
          message: 'Attachment not found'
        });
      }

      const attachment = caseDoc.attachments[attachmentIndex];

      // Check if the attachment has an S3 key
      if (!attachment.s3Key) {
        return res.status(404).json({
          success: false,
          message: 'No file found for this attachment'
        });
      }

      try {
        // Generate signed URL for secure access (expires in 1 hour)
        const signedUrl = await getSignedUrl(attachment.s3Key, 3600);
        
        res.json({
          success: true,
          message: 'Signed URL generated successfully',
          data: {
            signedUrl: signedUrl,
            filename: attachment.originalName,
            mimetype: attachment.mimetype,
            size: attachment.size,
            uploadedBy: attachment.uploadedBy,
            uploadedAt: attachment.uploadedAt,
            expiresIn: 3600 // seconds
          }
        });
      } catch (urlError) {
        console.error('Error generating signed URL:', urlError);
        res.status(500).json({
          success: false,
          message: 'Failed to generate attachment URL'
        });
      }
    } catch (error) {
      console.error('Attachment view error:', error);
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to view attachment'
      });
    }
  }
);

/**
 * GET /api/cases/:id/attachments/:index/download
 * Get a signed URL to download a case attachment with content-disposition header
 * @access Private (requires view_case_attachments or view_case permission)
 */
router.get('/:id/attachments/:index/download', 
  auth, 
  permissionAuth(['view_case_attachments', 'view_case']),
  validateCaseId,
  param('index').isInt({ min: 0 }).withMessage('Index must be a non-negative integer'),
  handleValidationErrors,
  async (req, res) => {
    try {
      const Case = req.app.locals.models.Case;
      const attachmentIndex = parseInt(req.params.index);
      
      if (isNaN(attachmentIndex)) {
        return res.status(400).json({ 
          success: false,
          message: 'Invalid attachment index' 
        });
      }
      
      // Get the case
      const caseDoc = await Case.getCaseById(req.params.id);

      if (!caseDoc) {
        return res.status(404).json({
          success: false,
          message: 'Case not found'
        });
      }

      // Check if attachments exist
      if (!caseDoc.attachments || attachmentIndex >= caseDoc.attachments.length) {
        return res.status(404).json({
          success: false,
          message: 'Attachment not found'
        });
      }

      const attachment = caseDoc.attachments[attachmentIndex];

      // Check if the attachment has an S3 key
      if (!attachment.s3Key) {
        return res.status(404).json({
          success: false,
          message: 'No file found for this attachment'
        });
      }

      try {
        // Generate signed URL for download with content-disposition header
        const signedUrl = await getSignedUrl(
          attachment.s3Key, 
          3600, // 1 hour expiry
          {
            ResponseContentDisposition: `attachment; filename="${attachment.originalName}"`
          }
        );
        
        res.json({
          success: true,
          message: 'Download URL generated successfully',
          data: {
            downloadUrl: signedUrl,
            filename: attachment.originalName,
            mimetype: attachment.mimetype,
            size: attachment.size,
            uploadedBy: attachment.uploadedBy,
            uploadedAt: attachment.uploadedAt,
            expiresIn: 3600 // seconds
          }
        });
      } catch (urlError) {
        console.error('Error generating download URL:', urlError);
        res.status(500).json({
          success: false,
          message: 'Failed to generate download URL'
        });
      }
    } catch (error) {
      console.error('Attachment download error:', error);
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to generate download URL'
      });
    }
  }
);

/**
 * DELETE /api/cases/:id/attachments/:index
 * Remove an attachment from a case
 * @access Private (requires manage_case_attachments permission)
 */
router.delete('/:id/attachments/:index', 
  auth, 
  permissionAuth(['manage_case_attachments']),
  validateCaseId,
  param('index').isInt({ min: 0 }).withMessage('Index must be a non-negative integer'),
  handleValidationErrors,
  async (req, res) => {
    try {
      const Case = req.app.locals.models.Case;
      const attachmentIndex = parseInt(req.params.index);
      
      if (isNaN(attachmentIndex)) {
        return res.status(400).json({ 
          success: false,
          message: 'Invalid attachment index' 
        });
      }
      
      // Get the case first to check if attachment exists
      const caseDoc = await Case.getCaseById(req.params.id);

      if (!caseDoc) {
        return res.status(404).json({
          success: false,
          message: 'Case not found'
        });
      }

      // Check if attachments exist
      if (!caseDoc.attachments || attachmentIndex >= caseDoc.attachments.length) {
        return res.status(404).json({
          success: false,
          message: 'Attachment not found'
        });
      }

      const attachmentToDelete = caseDoc.attachments[attachmentIndex];

      // Remove attachment from case
      const result = await Case.collection.updateOne(
        { _id: caseDoc._id },
        {
          $pull: { attachments: { s3Key: attachmentToDelete.s3Key } },
          $set: { updatedAt: new Date() }
        }
      );

      if (result.matchedCount === 0) {
        return res.status(404).json({
          success: false,
          message: 'Case not found'
        });
      }

      // Delete file from S3 if it exists
      if (attachmentToDelete.s3Key) {
        try {
          await deleteFromS3(attachmentToDelete.s3Key);
        } catch (s3Error) {
          console.error('Error deleting S3 file:', s3Error);
          // Don't fail the request if S3 deletion fails
        }
      }

      // Log attachment removal
      try {
        await CaseLog.createLogEntry(req.app.locals.db, {
          user_id: req.user._id,
          user_email: req.user.email || 'unknown',
          action: 'remove_case_attachment',
          entity_type: 'case_attachment',
          entity_id: req.params.id,
          ip_address: req.ip || req.connection?.remoteAddress || 'unknown',
          user_agent: req.get('User-Agent') || 'unknown',
          details: {
            request_method: req.method,
            endpoint: req.originalUrl,
            success: true,
            case_title: caseDoc.title,
            attachment_info: {
              filename: attachmentToDelete.filename,
              original_name: attachmentToDelete.originalName,
              mimetype: attachmentToDelete.mimetype,
              size: attachmentToDelete.size,
              s3_key: attachmentToDelete.s3Key
            },
            remaining_attachments: (caseDoc.attachments?.length || 1) - 1
          },
          severity: 'low',
          category: 'data_modification'
        });
      } catch (logError) {
        console.error('Error creating attachment removal log:', logError);
        // Don't fail the request if logging fails
      }

      // Get updated case
      const updatedCase = await Case.getCaseById(req.params.id);

      res.json({
        success: true,
        message: 'Attachment removed successfully',
        data: updatedCase
      });
    } catch (error) {
      console.error('Attachment removal error:', error);
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to remove attachment'
      });
    }
  }
);

/**
 * GET /api/cases/:id/attachments/:filename
 * Retrieve/serve attachment file with proper security using S3 signed URLs (legacy endpoint)
 * @deprecated Use /api/cases/:id/attachments/:index/view or /api/cases/:id/attachments/:index/download instead
 */
router.get('/:id/attachments/:filename', 
  auth, 
  permissionAuth(['view_case_attachments', 'view_case']),
  validateCaseId,
  param('filename').notEmpty().withMessage('Filename is required'),
  handleValidationErrors,
  async (req, res) => {
    try {
      const Case = req.app.locals.models.Case;
      const caseDoc = await Case.getCaseById(req.params.id);

      if (!caseDoc) {
        return res.status(404).json({
          success: false,
          message: 'Case not found'
        });
      }

      // Find the attachment in the case
      const requestedFilename = req.params.filename;
      const attachment = caseDoc.attachments?.find(att => 
        att.filename === requestedFilename || att.s3Key?.endsWith(requestedFilename)
      );

      if (!attachment) {
        return res.status(404).json({
          success: false,
          message: 'Attachment not found'
        });
      }

      try {
        // Generate signed URL for secure access (expires in 1 hour)
        const signedUrl = await getSignedUrl(attachment.s3Key, 3600);
        
        // Always return JSON response to match the new pattern
        res.json({
          success: true,
          message: 'Signed URL generated successfully (legacy endpoint - consider using index-based endpoints)',
          data: {
            signedUrl: signedUrl,
            filename: attachment.originalName,
            mimetype: attachment.mimetype,
            size: attachment.size,
            uploadedBy: attachment.uploadedBy,
            uploadedAt: attachment.uploadedAt,
            expiresIn: 3600
          }
        });

      } catch (s3Error) {
        console.error('S3 error:', s3Error);
        return res.status(500).json({
          success: false,
          message: 'Error accessing file from storage'
        });
      }

    } catch (error) {
      console.error('Serve attachment error:', error);
      if (!res.headersSent) {
        res.status(500).json({
          success: false,
          message: error.message || 'Failed to serve attachment'
        });
      }
    }
  }
);

/**
 * DELETE /api/cases/:id
 * Delete case
 */
router.delete('/:id', 
  auth, 
  validateCaseId, 
  handleValidationErrors,
  permissionAuth(['delete_case']),
  async (req, res) => {
    try {
      const Case = req.app.locals.models.Case;
      
      // Get case details before deletion for logging
      const caseToDelete = await Case.getCaseById(req.params.id);
      if (!caseToDelete) {
        return res.status(404).json({
          success: false,
          message: 'Case not found'
        });
      }
      
      // Collect S3 keys for cleanup
      const s3KeysToDelete = [];
      if (caseToDelete.attachments) {
        caseToDelete.attachments.forEach(attachment => {
          if (attachment.s3Key) {
            s3KeysToDelete.push(attachment.s3Key);
          }
        });
      }
      

      await Case.deleteCase(req.params.id, req.user);
      
      // Delete S3 files after successful database deletion
      if (s3KeysToDelete.length > 0) {
        try {
          await deleteMultipleFromS3(s3KeysToDelete);
        } catch (s3Error) {
          console.error('Error deleting S3 files for case:', s3Error);
          // Don't fail the request if S3 cleanup fails
        }
      }

      // Log case deletion
      try {
        await CaseLog.createLogEntry(req.app.locals.db, {
          user_id: req.user._id,
          user_email: req.user.email || 'unknown',
          action: 'delete_case',
          entity_type: 'case',
          entity_id: req.params.id,
          ip_address: req.ip || req.connection?.remoteAddress || 'unknown',
          user_agent: req.get('User-Agent') || 'unknown',
          details: {
            request_method: req.method,
            endpoint: req.originalUrl,
            success: true,
            deleted_case: {
              title: caseToDelete.title,
              status: caseToDelete.status,
              priority: caseToDelete.priority,
              created_by: caseToDelete.createdBy,
              assigned_to: caseToDelete.assignedTo,
              notes_count: caseToDelete.notes?.length || 0,
              attachments_count: caseToDelete.attachments?.length || 0,
              created_at: caseToDelete.createdAt
            }
          },
          severity: 'high',
          category: 'data_modification'
        });
      } catch (logError) {
        console.error('Error creating case deletion log:', logError);
        // Don't fail the request if logging fails
      }

      res.json({
        success: true,
        message: 'Case deleted successfully',
        s3_files_deleted: s3KeysToDelete.length
      });
    } catch (error) {
      console.error('Delete case error:', error);
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to delete case'
      });
    }
  }
);


/**
 * GET /api/cases/:id/logs
 * Get logs for a specific case
 * @access Private (requires view_case permission)
 */
router.get('/:id/logs', 
  auth, 
  permissionAuth('view_case'), 
  validateCaseId, 
  handleValidationErrors,
  async (req, res) => {
    try {
      const { page = 1, limit = 20 } = req.query;
      
      const options = {
        limit: parseInt(limit),
        skip: (parseInt(page) - 1) * parseInt(limit),
        sort: { timestamp: -1 }
      };
      
      const logs = await CaseLog.findCaseLogsByCase(req.app.locals.db, req.params.id, options);
      
      // Log access to specific case logs
      try {
        await CaseLog.createLogEntry(req.app.locals.db, {
          user_id: req.user._id,
          user_email: req.user.email || 'unknown',
          action: 'view_case_logs',
          entity_type: 'case',
          entity_id: req.params.id,
          ip_address: req.ip || req.connection?.remoteAddress || 'unknown',
          user_agent: req.get('User-Agent') || 'unknown',
          details: {
            request_method: req.method,
            endpoint: req.originalUrl,
            success: true,
            case_id: req.params.id,
            results_count: logs.length,
            page: parseInt(page),
            limit: parseInt(limit)
          },
          severity: 'low',
          category: 'data_access'
        });
      } catch (logError) {
        console.error('Error creating case-specific logs access log:', logError);
      }
      
      res.json({
        success: true,
        message: 'Case logs retrieved successfully',
        case_id: req.params.id,
        data: logs,
        pagination: {
          current_page: parseInt(page),
          per_page: parseInt(limit),
          total_logs: logs.length
        }
      });
    } catch (error) {
      console.error('Error fetching case logs:', error);
      res.status(500).json({ 
        success: false,
        message: error.message || 'Failed to retrieve case logs'
      });
    }
  }
);

// Helper functions for log formatting
function formatActionName(action) {
  const actionMap = {
    'create_case': 'Case Created',
    'update_case': 'Case Updated',
    'delete_case': 'Case Deleted',
    'view_case': 'Case Viewed',
    'view_all_cases': 'All Cases Viewed',
    'add_case_note': 'Note Added',
    'remove_case_note': 'Note Removed',
    'upload_case_attachment': 'Attachment Uploaded',
    'remove_case_attachment': 'Attachment Removed',
    'assign_case': 'Case Assigned',
    'unassign_case': 'Case Unassigned',
    'resolve_case': 'Case Resolved',
    'close_case': 'Case Closed',
    'reopen_case': 'Case Reopened',
    'change_case_priority': 'Priority Changed',
    'change_case_status': 'Status Changed',
    'add_case_tag': 'Tag Added',
    'remove_case_tag': 'Tag Removed',
    'link_case_entity': 'Entity Linked',
    'unlink_case_entity': 'Entity Unlinked',
    'view_case_stats': 'Statistics Viewed',
    'export_case_data': 'Data Exported'
  };
  
  return actionMap[action] || action.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
}

function getSeverityIcon(severity) {
  const severityIcons = {
    'low': '🟢',
    'medium': '🟡',
    'high': '🟠',
    'critical': '🔴'
  };
  
  return severityIcons[severity] || '⚪';
}

function generateLogSummary(log) {
  const action = formatActionName(log.action);
  const user = log.user_email || 'Unknown User';
  const timestamp = log.timestamp.toLocaleString();
  const success = log.details?.success ? 'successfully' : 'unsuccessfully';
  
  return `${user} ${success} performed "${action}" on ${timestamp}`;
}

function generateTimelineEntry(log, user) {
  const action = formatActionName(log.action);
  const userName = user ? `${user.first_name} ${user.last_name}` : (log.user_email || 'Unknown User');
  const severity = getSeverityIcon(log.severity);
  
  return `${severity} ${userName} - ${action}`;
}

function getAvailableActions() {
  return [
    'create_case', 'update_case', 'delete_case', 'view_case', 'view_all_cases',
    'add_case_note', 'remove_case_note', 'upload_case_attachment', 'remove_case_attachment',
    'assign_case', 'unassign_case', 'resolve_case', 'close_case', 'reopen_case',
    'change_case_priority', 'change_case_status', 'add_case_tag', 'remove_case_tag',
    'link_case_entity', 'unlink_case_entity', 'view_case_stats', 'export_case_data'
  ];
}

function getAvailableEntityTypes() {
  return ['case', 'case_note', 'case_attachment', 'case_system', 'case_analytics'];
}

module.exports = router;
