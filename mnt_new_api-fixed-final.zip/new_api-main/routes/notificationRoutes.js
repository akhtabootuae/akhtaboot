const express = require('express');
const router = express.Router();
const { ObjectId } = require('mongodb');
const authenticateUser = require('../middleware/auth');

// Get all notifications for the authenticated user
router.get('/', authenticateUser, async (req, res) => {
  try {
    const db = req.app.locals.db;
    const userId = req.user._id;
    const userRole = req.user.role_name;
    
    // Build query based on filters
    const query = {
      $or: [
        { recipientId: new ObjectId(userId) },
        { recipientType: userRole.toLowerCase() },
        { recipientType: 'all' }
      ]
    };
    
    // Apply filters if provided
    if (req.query.type && req.query.type !== 'all') {
      query.type = req.query.type;
    }
    if (req.query.priority && req.query.priority !== 'all') {
      query.priority = req.query.priority;
    }
    if (req.query.status && req.query.status !== 'all') {
      query.status = req.query.status;
    }
    
    // Get notifications sorted by creation date (newest first)
    const notifications = await db.collection('notifications')
      .find(query)
      .sort({ createdAt: -1 })
      .toArray();
    
    res.json(notifications);
  } catch (error) {
    console.error('Error fetching notifications:', error);
    res.status(500).json({ message: 'Error fetching notifications', error: error.message });
  }
});

// Get notification statistics - MUST BE BEFORE /:id route
router.get('/stats', authenticateUser, async (req, res) => {
  try {
    const db = req.app.locals.db;
    const userId = req.user._id;
    const userRole = req.user.role_name;
    
    const query = {
      $or: [
        { recipientId: new ObjectId(userId) },
        { recipientType: userRole.toLowerCase() },
        { recipientType: 'all' }
      ]
    };
    
    const [total, unread, highPriority] = await Promise.all([
      db.collection('notifications').countDocuments(query),
      db.collection('notifications').countDocuments({ ...query, status: 'unread' }),
      db.collection('notifications').countDocuments({ ...query, priority: { $in: ['high', 'urgent'] } })
    ]);
    
    res.json({ total, unread, highPriority });
  } catch (error) {
    console.error('Error fetching notification stats:', error);
    res.status(500).json({ message: 'Error fetching statistics', error: error.message });
  }
});

// Get notification by ID
router.get('/:id', authenticateUser, async (req, res) => {
  try {
    const db = req.app.locals.db;
    const notificationId = req.params.id;
    
    if (!ObjectId.isValid(notificationId)) {
      return res.status(400).json({ message: 'Invalid notification ID' });
    }
    
    const notification = await db.collection('notifications')
      .findOne({ _id: new ObjectId(notificationId) });
    
    if (!notification) {
      return res.status(404).json({ message: 'Notification not found' });
    }
    
    // Check if user has permission to view this notification
    const userId = req.user._id;
    const userRole = req.user.role_name;
    
    const hasAccess = 
      notification.recipientId?.toString() === userId ||
      notification.recipientType === userRole.toLowerCase() ||
      notification.recipientType === 'all';
    
    if (!hasAccess) {
      return res.status(403).json({ message: 'Access denied to this notification' });
    }
    
    res.json(notification);
  } catch (error) {
    console.error('Error fetching notification:', error);
    res.status(500).json({ message: 'Error fetching notification', error: error.message });
  }
});

// Mark notification as read
router.put('/:id/read', authenticateUser, async (req, res) => {
  try {
    const db = req.app.locals.db;
    const notificationId = req.params.id;
    
    if (!ObjectId.isValid(notificationId)) {
      return res.status(400).json({ message: 'Invalid notification ID' });
    }
    
    const result = await db.collection('notifications')
      .updateOne(
        { _id: new ObjectId(notificationId) },
        { 
          $set: { 
            status: 'read',
            readAt: new Date()
          } 
        }
      );
    
    if (result.matchedCount === 0) {
      return res.status(404).json({ message: 'Notification not found' });
    }
    
    res.json({ message: 'Notification marked as read' });
  } catch (error) {
    console.error('Error marking notification as read:', error);
    res.status(500).json({ message: 'Error updating notification', error: error.message });
  }
});

// Mark multiple notifications as read
router.put('/read', authenticateUser, async (req, res) => {
  try {
    const db = req.app.locals.db;
    const { notificationIds } = req.body;
    
    if (!Array.isArray(notificationIds)) {
      return res.status(400).json({ message: 'notificationIds must be an array' });
    }
    
    const objectIds = notificationIds
      .filter(id => ObjectId.isValid(id))
      .map(id => new ObjectId(id));
    
    if (objectIds.length === 0) {
      return res.status(400).json({ message: 'No valid notification IDs provided' });
    }
    
    const result = await db.collection('notifications')
      .updateMany(
        { _id: { $in: objectIds } },
        { 
          $set: { 
            status: 'read',
            readAt: new Date()
          } 
        }
      );
    
    res.json({ 
      message: 'Notifications marked as read',
      modifiedCount: result.modifiedCount 
    });
  } catch (error) {
    console.error('Error marking notifications as read:', error);
    res.status(500).json({ message: 'Error updating notifications', error: error.message });
  }
});

// Archive notification
router.put('/:id/archive', authenticateUser, async (req, res) => {
  try {
    const db = req.app.locals.db;
    const notificationId = req.params.id;
    
    if (!ObjectId.isValid(notificationId)) {
      return res.status(400).json({ message: 'Invalid notification ID' });
    }
    
    const result = await db.collection('notifications')
      .updateOne(
        { _id: new ObjectId(notificationId) },
        { $set: { status: 'archived' } }
      );
    
    if (result.matchedCount === 0) {
      return res.status(404).json({ message: 'Notification not found' });
    }
    
    res.json({ message: 'Notification archived' });
  } catch (error) {
    console.error('Error archiving notification:', error);
    res.status(500).json({ message: 'Error archiving notification', error: error.message });
  }
});

// Delete expired notifications (admin only)
router.delete('/expired', authenticateUser, async (req, res) => {
  try {
    // Check if user is admin
    if (req.user.role_name !== 'Admin') {
      return res.status(403).json({ message: 'Admin access required' });
    }
    
    const db = req.app.locals.db;
    const now = new Date();
    
    const result = await db.collection('notifications')
      .deleteMany({ 
        expiresAt: { $exists: true, $lt: now } 
      });
    
    res.json({ 
      message: 'Expired notifications deleted',
      deletedCount: result.deletedCount 
    });
  } catch (error) {
    console.error('Error deleting expired notifications:', error);
    res.status(500).json({ message: 'Error deleting notifications', error: error.message });
  }
});

// Create a notification (typically called internally by other services)
router.post('/', authenticateUser, async (req, res) => {
  try {
    // Only allow admins or system to create notifications
    if (req.user.role_name !== 'Admin') {
      return res.status(403).json({ message: 'Admin access required' });
    }
    
    const db = req.app.locals.db;
    const {
      type,
      title,
      message,
      workOrderId,
      stageId,
      recipientType,
      recipientId,
      priority = 'medium',
      percentComplete,
      metadata,
      employeeId,
      timesheetId,
      deductionId
    } = req.body;
    
    // Validate required fields
    if (!type || !title || !message) {
      return res.status(400).json({ message: 'Type, title, and message are required' });
    }
    
    const notification = {
      type,
      title,
      message,
      workOrderId: workOrderId || null,
      stageId: stageId || null,
      recipientType: recipientType || null,
      recipientId: recipientId ? new ObjectId(recipientId) : null,
      priority,
      status: 'unread',
      percentComplete: percentComplete || null,
      metadata: metadata || {},
      employeeId: employeeId || null,
      timesheetId: timesheetId || null,
      deductionId: deductionId || null,
      createdAt: new Date(),
      readAt: null,
      expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // 30 days default
    };
    
    const result = await db.collection('notifications').insertOne(notification);
    
    res.status(201).json({ 
      message: 'Notification created',
      notificationId: result.insertedId 
    });
  } catch (error) {
    console.error('Error creating notification:', error);
    res.status(500).json({ message: 'Error creating notification', error: error.message });
  }
});

module.exports = router;