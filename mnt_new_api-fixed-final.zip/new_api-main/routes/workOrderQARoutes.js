const express = require('express');
const router = express.Router();
const { createS3MultiUpload, deleteMultipleFromS3, getSignedUrl, uploadConfigs } = require('../middleware/s3Upload');
const WorkOrderQA = require('../models/WorkOrderQA');

// Create upload middleware for QA images
const uploadQAImages = createS3MultiUpload({
  folderName: 'qa-images',
  ...uploadConfigs.qaImages,
  fieldName: 'images',
  maxCount: 5
});

// Initialize WorkOrderQA model
let workOrderQAModel;

// Middleware to initialize database connection
const initializeDB = (req, res, next) => {
  if (!workOrderQAModel && req.app.locals.db) {
    workOrderQAModel = new WorkOrderQA(req.app.locals.db);
  }
  if (!workOrderQAModel) {
    return res.status(500).json({ error: 'Database connection not available' });
  }
  next();
};

// Middleware to validate image count (3-5 images required)
const validateImageCount = (req, res, next) => {
  if (!req.files || req.files.length < 3) {
    return res.status(400).json({ 
      error: 'At least 3 images are required for QA submission' 
    });
  }
  if (req.files.length > 5) {
    return res.status(400).json({ 
      error: 'Maximum 5 images allowed for QA submission' 
    });
  }
  next();
};

/**
 * @route   POST /api/workorder-qa
 * @desc    Create a new work order QA record with images
 * @access  Private
 */
router.post('/', initializeDB, uploadQAImages, validateImageCount, async (req, res) => {
  try {
    const { WO_ID, person_name, passed, description } = req.body;

    // Validate required fields
    if (!WO_ID || !person_name || passed === undefined || !description) {
      return res.status(400).json({ 
        error: 'WO_ID, person_name, passed status, and description are required' 
      });
    }

    // Convert passed to boolean
    const passedBool = passed === 'true' || passed === true;

    // Process uploaded images
    const images = req.files.map(file => ({
      s3_key: file.key,
      original_name: file.originalname,
      size: file.size,
      mime_type: file.mimetype,
      upload_date: new Date()
    }));

    // Create QA record
    const qaData = {
      WO_ID,
      person_name,
      passed: passedBool,
      images,
      description
    };

    const createdQA = await workOrderQAModel.create(qaData);

    res.status(201).json({
      success: true,
      message: 'Work order QA record created successfully',
      data: createdQA
    });

  } catch (error) {
    console.error('Error creating work order QA:', error);
    
    // Clean up uploaded files if QA creation failed
    if (req.files && req.files.length > 0) {
      const fileKeys = req.files.map(file => file.key);
      try {
        await deleteMultipleFromS3(fileKeys);
      } catch (deleteError) {
        console.error('Error cleaning up uploaded files:', deleteError);
      }
    }

    res.status(500).json({
      success: false,
      error: 'Failed to create work order QA record',
      details: error.message
    });
  }
});

/**
 * @route   GET /api/workorder-qa
 * @desc    Get all QA records with pagination
 * @access  Private
 */
router.get('/', initializeDB, async (req, res) => {
  try {
    const { page = 1, limit = 10, wo_id, passed } = req.query;
    
    // Build filter
    const filter = {};
    if (wo_id) filter.WO_ID = wo_id;
    if (passed !== undefined) filter.passed = passed === 'true';

    const options = {
      page: parseInt(page),
      limit: parseInt(limit),
      filter
    };

    const result = await workOrderQAModel.findAll(options);

    // Generate signed URLs for images
    for (const qa of result.data) {
      for (const image of qa.images) {
        image.signed_url = await getSignedUrl(image.s3_key, 3600); // 1 hour expiry
      }
    }

    res.json({
      success: true,
      ...result
    });

  } catch (error) {
    console.error('Error fetching QA records:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch QA records',
      details: error.message
    });
  }
});

/**
 * @route   GET /api/workorder-qa/work-order/:woId
 * @desc    Get QA records for a specific work order
 * @access  Private
 */
router.get('/work-order/:woId', initializeDB, async (req, res) => {
  try {
    const { woId } = req.params;
    const qaRecords = await workOrderQAModel.findByWorkOrderId(woId);

    // Generate signed URLs for images
    for (const qa of qaRecords) {
      for (const image of qa.images) {
        image.signed_url = await getSignedUrl(image.s3_key, 3600);
      }
    }

    res.json({
      success: true,
      data: qaRecords,
      count: qaRecords.length
    });

  } catch (error) {
    console.error('Error fetching QA records for work order:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch QA records for work order',
      details: error.message
    });
  }
});

/**
 * @route   GET /api/workorder-qa/:id
 * @desc    Get a specific QA record by ID
 * @access  Private
 */
router.get('/:id', initializeDB, async (req, res) => {
  try {
    const { id } = req.params;
    const qaRecord = await workOrderQAModel.findById(id);

    if (!qaRecord) {
      return res.status(404).json({
        success: false,
        error: 'QA record not found'
      });
    }

    // Generate signed URLs for images
    for (const image of qaRecord.images) {
      image.signed_url = await getSignedUrl(image.s3_key, 3600);
    }

    res.json({
      success: true,
      data: qaRecord
    });

  } catch (error) {
    console.error('Error fetching QA record:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch QA record',
      details: error.message
    });
  }
});

/**
 * @route   PUT /api/workorder-qa/:id
 * @desc    Update a QA record (without changing images)
 * @access  Private
 */
router.put('/:id', initializeDB, async (req, res) => {
  try {
    const { id } = req.params;
    const { person_name, passed, description } = req.body;

    // Build update object
    const updateData = {};
    if (person_name !== undefined) updateData.person_name = person_name;
    if (passed !== undefined) updateData.passed = passed === 'true' || passed === true;
    if (description !== undefined) updateData.description = description;

    if (Object.keys(updateData).length === 0) {
      return res.status(400).json({
        success: false,
        error: 'No valid fields provided for update'
      });
    }

    const updatedQA = await workOrderQAModel.update(id, updateData);

    if (!updatedQA) {
      return res.status(404).json({
        success: false,
        error: 'QA record not found'
      });
    }

    // Generate signed URLs for images
    for (const image of updatedQA.images) {
      image.signed_url = await getSignedUrl(image.s3_key, 3600);
    }

    res.json({
      success: true,
      message: 'QA record updated successfully',
      data: updatedQA
    });

  } catch (error) {
    console.error('Error updating QA record:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to update QA record',
      details: error.message
    });
  }
});

/**
 * @route   DELETE /api/workorder-qa/:id
 * @desc    Delete a QA record and associated images
 * @access  Private
 */
router.delete('/:id', initializeDB, async (req, res) => {
  try {
    const { id } = req.params;
    
    // First get the QA record to get image keys
    const qaRecord = await workOrderQAModel.findById(id);
    
    if (!qaRecord) {
      return res.status(404).json({
        success: false,
        error: 'QA record not found'
      });
    }

    // Delete the QA record from database
    await workOrderQAModel.delete(id);

    // Delete associated images from S3
    if (qaRecord.images && qaRecord.images.length > 0) {
      const imageKeys = qaRecord.images.map(img => img.s3_key);
      try {
        await deleteMultipleFromS3(imageKeys);
      } catch (s3Error) {
        console.error('Error deleting images from S3:', s3Error);
        // Don't fail the entire operation if S3 deletion fails
      }
    }

    res.json({
      success: true,
      message: 'QA record and associated images deleted successfully'
    });

  } catch (error) {
    console.error('Error deleting QA record:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to delete QA record',
      details: error.message
    });
  }
});

/**
 * @route   GET /api/workorder-qa/stats
 * @desc    Get QA statistics
 * @access  Private
 */
router.get('/stats/overview', initializeDB, async (req, res) => {
  try {
    const stats = await workOrderQAModel.getStats();

    res.json({
      success: true,
      data: stats
    });

  } catch (error) {
    console.error('Error fetching QA stats:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch QA statistics',
      details: error.message
    });
  }
});

/**
 * @route   GET /api/workorder-qa/:id/images/:imageIndex/download
 * @desc    Get a signed URL for downloading a specific image
 * @access  Private
 */
router.get('/:id/images/:imageIndex/download', initializeDB, async (req, res) => {
  try {
    const { id, imageIndex } = req.params;
    const qaRecord = await workOrderQAModel.findById(id);

    if (!qaRecord) {
      return res.status(404).json({
        success: false,
        error: 'QA record not found'
      });
    }

    const index = parseInt(imageIndex);
    if (index < 0 || index >= qaRecord.images.length) {
      return res.status(404).json({
        success: false,
        error: 'Image not found'
      });
    }

    const image = qaRecord.images[index];
    const signedUrl = await getSignedUrl(image.s3_key, 3600, {
      ResponseContentDisposition: `attachment; filename="${image.original_name}"`
    });

    res.json({
      success: true,
      data: {
        download_url: signedUrl,
        filename: image.original_name,
        size: image.size,
        mime_type: image.mime_type
      }
    });

  } catch (error) {
    console.error('Error generating download URL:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to generate download URL',
      details: error.message
    });
  }
});

module.exports = router;