const express = require('express');
const router = express.Router();
const { ObjectId } = require('mongodb');
const { Expense } = require('../models');
const ExpenseLog = require('../models/ExpenseLog');
const permissionAuth = require('../middleware/permissionAuth');
const auth = require('../middleware/auth');
const { createS3Upload, uploadConfigs, deleteFromS3, deleteMultipleFromS3, getSignedUrl } = require('../middleware/s3Upload');
const { generateExpenseSignaturePDF } = require('../utils/pdfGenerator');

// Configure S3 upload for expense receipts
const uploadReceiptImage = createS3Upload({
  folderName: 'expenses/receipts',
  ...uploadConfigs.receipts,
  fieldName: 'receipt'
});

// Configure S3 upload for expense invoice images
const uploadInvoiceImage = createS3Upload({
  folderName: 'expenses/invoices',
  ...uploadConfigs.invoiceImages,
  fieldName: 'invoice_image'
});

// Helper function to generate signed URLs for expense receipt images
const generateSignedUrlsForExpense = async (expense) => {
  // Handle receipt images
  if (expense.receipt_images && expense.receipt_images.length > 0) {
    const receiptImagesWithSignedUrls = await Promise.all(
      expense.receipt_images.map(async (receipt) => {
        if (receipt.s3Key) {
          try {
            const signedUrl = await getSignedUrl(receipt.s3Key, 3600); // 1 hour expiry
            return {
              ...receipt,
              signedUrl
            };
          } catch (urlError) {
            console.error('Error generating signed URL for receipt:', receipt.s3Key, urlError);
            return receipt; // Return receipt without signed URL if error
          }
        }
        return receipt;
      })
    );
    expense.receipt_images = receiptImagesWithSignedUrls;
  }

  // Handle invoice image
  if (expense.invoice_image && expense.invoice_image.s3Key) {
    try {
      const signedUrl = await getSignedUrl(expense.invoice_image.s3Key, 3600); // 1 hour expiry
      expense.invoice_image = {
        ...expense.invoice_image,
        signedUrl
      };
    } catch (urlError) {
      console.error('Error generating signed URL for invoice image:', expense.invoice_image.s3Key, urlError);
      // Keep invoice_image without signed URL if error
    }
  }

  return expense;
};

// Helper function to generate signed URLs for multiple expenses
const generateSignedUrlsForExpenses = async (expenses) => {
  return Promise.all(expenses.map(generateSignedUrlsForExpense));
};

// Middleware to check if ObjectId is valid
const validateObjectId = (req, res, next) => {
  const id = req.params.id;
  
  if (!ObjectId.isValid(id)) {
    return res.status(400).json({ message: 'Invalid ID format' });
  }
  
  next();
};

/**
 * @route   POST /api/expenses
 * @desc    Create a new expense with required invoice image
 * @access  Private (requires create_expense permission)
 */
router.post('/', auth, permissionAuth('create_expense'), uploadInvoiceImage, async (req, res) => {
  try {
    const db = req.app.locals.db;
    
    // Check if invoice image was uploaded (required)
    if (!req.file) {
      return res.status(400).json({ 
        message: 'Invoice image is required for expense creation' 
      });
    }
    
    // Get the current count to generate expense number
    const expenseCount = await db.collection('expenses').countDocuments();
    const expense_number = `EXP-${String(expenseCount + 1).padStart(7, '0')}`;
    
    // Map frontend fields to schema requirements
    const expenseData = {
      expense_number,
      title: req.body.description || req.body.title, // Map description to title
      description: req.body.description, // Keep original description if needed
      amount: parseFloat(req.body.amount),
      expense_type: req.body.category || req.body.expense_type, // Map category to expense_type
      date: req.body.date ? new Date(req.body.date) : new Date(),
      status: req.body.status || 'approved', // Default to approved status
      created_by: new ObjectId(req.user._id),
      branch_id: new ObjectId(req.user.branch.branch_id), // Get branch from user
      created_at: new Date(),
      updated_at: new Date(),
      // Add invoice image data
      invoice_image: {
        s3Key: req.file.key,
        url: req.file.location,
        filename: req.file.originalname,
        mimetype: req.file.mimetype,
        size: req.file.size,
        uploadedAt: new Date()
      },
      // Include any other fields from request body
      ...Object.fromEntries(
        Object.entries(req.body).filter(([key]) => 
          !['description', 'category', 'amount', 'date', 'status'].includes(key)
        )
      )
    };

    // Normalize payment_method to match schema enum values
    if (expenseData.payment_method) {
      const paymentMethod = expenseData.payment_method.toLowerCase().trim();
      
      // Map common variations to schema values
      const paymentMethodMap = {
        'credit card': 'card',
        'credit_card': 'card',
        'debit card': 'card',
        'debit_card': 'card',
        'bank transfer': 'bank_transfer',
        'bank_transfer': 'bank_transfer',
        'wire transfer': 'bank_transfer',
        'cheque': 'check',
        'cash': 'cash',
        'card': 'card',
        'check': 'check',
        'petty cash': 'petty_cash',
        'petty_cash': 'petty_cash',
        'digital wallet': 'digital_wallet',
        'digital_wallet': 'digital_wallet',
        'e-wallet': 'digital_wallet',
        'paypal': 'digital_wallet',
        'apple pay': 'digital_wallet',
        'google pay': 'digital_wallet',
        'other': 'other',
        'misc': 'other',
        'miscellaneous': 'other'
      };
      
      expenseData.payment_method = paymentMethodMap[paymentMethod] || paymentMethod;
    }
    
    console.log('Transformed expense data:', JSON.stringify(expenseData, null, 2));
    
    const expense = await Expense.create(db, expenseData);
    
    // Create expense log entry
    try {
      await ExpenseLog.createLogEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email || 'unknown',
        action: 'create_expense',
        entity_type: 'expense',
        entity_id: expense._id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          expense_number: expense.expense_number,
          amount: expense.amount,
          expense_type: expense.expense_type,
          request_method: req.method,
          endpoint: req.originalUrl,
          success: true,
          auto_approved: expense.approval_status === 'approved', // Flag for auto-approval
          new_values: {
            title: expense.title,
            amount: expense.amount,
            expense_type: expense.expense_type,
            status: expense.status,
            approval_status: expense.approval_status
          }
        },
        severity: 'medium',
        category: 'data_modification',
        branch_id: expense.branch_id
      });
    } catch (logError) {
      console.error('Error creating expense log:', logError);
      // Don't fail the request if logging fails
    }
    
    res.status(201).json(expense);
  } catch (error) {
    // Clean up uploaded file from S3 if there was an error
    if (req.file && req.file.key) {
      try {
        await deleteFromS3(req.file.key);
      } catch (deleteError) {
        console.error('Error deleting S3 file:', deleteError);
      }
    }
    
    console.error('Expense creation route error:', error);
    
    if (error.name === 'MongoServerError' && error.code === 121) {
      return res.status(400).json({
        message: 'Document failed validation',
        details: error.errInfo ? error.errInfo.details : 'Validation error'
      });
    }
    
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   POST /api/expenses/generate-signature-pdf
 * @desc    Generate a PDF document for expense signature (before expense creation)
 * @access  Private (requires create_expense permission)
 */
router.post('/generate-signature-pdf', auth, permissionAuth('create_expense'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    
    // Validate required fields
    const { description, amount, expense_type, date } = req.body;
    
    if (!description || !amount || !expense_type) {
      return res.status(400).json({ 
        message: 'Description, amount, and expense_type are required fields' 
      });
    }
    
    // Validate amount is a positive number
    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      return res.status(400).json({ 
        message: 'Amount must be a valid positive number' 
      });
    }

    // Get user's branch information
    let branchData = {};
    if (req.user.branch?.branch_id) {
      try {
        branchData = await db.collection('branches').findOne({ 
          _id: new ObjectId(req.user.branch.branch_id) 
        });
      } catch (branchError) {
        console.warn('Could not fetch branch data:', branchError);
      }
    }

    // Prepare expense data for PDF
    const expenseData = {
      description: description || req.body.title,
      title: req.body.title || description,
      amount: parsedAmount,
      expense_type: expense_type || req.body.category,
      date: date ? new Date(date) : new Date(),
      vendor: req.body.vendor || '',
      payment_method: req.body.payment_method || '',
      invoice_number: req.body.invoice_number || '',
      notes: req.body.notes || req.body.description || '',
      // Include any additional fields
      ...Object.fromEntries(
        Object.entries(req.body).filter(([key]) => 
          !['description', 'title', 'amount', 'expense_type', 'category', 'date'].includes(key)
        )
      )
    };

    // Prepare user data for PDF
    const userData = {
      first_name: req.user.first_name || '',
      last_name: req.user.last_name || '',
      email: req.user.email || '',
      employee_id: req.user.employee_id || req.user.user_id || ''
    };

    // Generate and stream the PDF
    await generateExpenseSignaturePDF(expenseData, branchData, userData, res);

    // Create expense log entry for PDF generation
    try {
      await ExpenseLog.createLogEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email || 'unknown',
        action: 'generate_expense_pdf',
        entity_type: 'expense_system',
        entity_id: null,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          expense_description: expenseData.description,
          expense_amount: expenseData.amount,
          expense_type: expenseData.expense_type,
          request_method: req.method,
          endpoint: req.originalUrl,
          success: true,
          pdf_type: 'signature_document',
          generated_for_user: userData.email
        },
        severity: 'low',
        category: 'document_generation',
        branch_id: req.user.branch?.branch_id || null
      });
    } catch (logError) {
      console.error('Error creating expense PDF generation log:', logError);
      // Don't fail the request if logging fails
    }

  } catch (error) {
    console.error('Error generating expense signature PDF:', error);
    
    if (!res.headersSent) {
      res.status(500).json({ 
        message: 'Error generating PDF document',
        error: error.message 
      });
    }
  }
});

/**
 * @route   GET /api/expenses
 * @desc    Get all expenses with optional filters
 * @access  Private (requires view_all_expenses permission)
 */
router.get('/', auth, permissionAuth('view_all_expenses'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const { 
      created_by, 
      branch_id, 
      expense_type, 
      status, 
      approval_status,
      date_from, 
      date_to,
      work_order_id,
      project_id,
      vendor,
      tags,
      search
    } = req.query;
    
    // Build filter object
    const filters = {};
    
    if (created_by) filters.created_by = created_by;
    if (branch_id) filters.branch_id = branch_id;
    if (expense_type) filters.expense_type = expense_type;
    if (status) filters.status = status;
    if (approval_status) filters.approval_status = approval_status;
    if (date_from) filters.date_from = date_from;
    if (date_to) filters.date_to = date_to;
    if (work_order_id) filters.work_order_id = work_order_id;
    if (project_id) filters.project_id = project_id;
    if (vendor) filters.vendor = vendor;
    if (search) filters.search = search;
    
    // Parse tags if provided
    if (tags) {
      try {
        filters.tags = Array.isArray(tags) ? tags : JSON.parse(tags);
      } catch (e) {
        filters.tags = [tags]; // Single tag as string
      }
    }
    
    const expenses = await Expense.getAll(db, filters);
    
    // Create expense log entry for viewing expenses
    try {
      await ExpenseLog.createLogEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email || 'unknown',
        action: 'view_expenses',
        entity_type: 'expense_system',
        entity_id: null,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          filters: filters,
          result_count: expenses.length,
          request_method: req.method,
          endpoint: req.originalUrl,
          success: true
        },
        severity: 'low',
        category: 'data_access',
        branch_id: req.user.branch?.branch_id || null
      });
    } catch (logError) {
      console.error('Error creating expense log:', logError);
      // Don't fail the request if logging fails
    }
    
    // Generate signed URLs for receipt images in all expenses
    const expensesWithSignedUrls = await generateSignedUrlsForExpenses(expenses);
    
    res.json(expensesWithSignedUrls);
  } catch (error) {
    console.error('Error fetching expenses:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/expenses/my
 * @desc    Get expenses created by the authenticated user
 * @access  Private
 */
router.get('/my', auth, async (req, res) => {
  try {
    const db = req.app.locals.db;
    const expenses = await Expense.getByCreator(db, req.user._id);
    
    // Generate signed URLs for receipt images in all expenses
    const expensesWithSignedUrls = await generateSignedUrlsForExpenses(expenses);
    
    res.json(expensesWithSignedUrls);
  } catch (error) {
    console.error('Error fetching user expenses:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/expenses/statistics
 * @desc    Get expense statistics
 * @access  Private (requires view_expense_stats permission)
 */
router.get('/statistics', auth, permissionAuth('view_expense_stats'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const { branch_id, created_by, date_from, date_to } = req.query;
    
    const filters = {};
    if (branch_id) filters.branch_id = branch_id;
    if (created_by) filters.created_by = created_by;
    if (date_from) filters.date_from = date_from;
    if (date_to) filters.date_to = date_to;
    
    const statistics = await Expense.getStatistics(db, filters);
    
    // Create expense log entry for viewing analytics
    try {
      await ExpenseLog.createLogEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email || 'unknown',
        action: 'view_expense_analytics',
        entity_type: 'expense_analytics',
        entity_id: null,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          filters: filters,
          request_method: req.method,
          endpoint: req.originalUrl,
          success: true
        },
        severity: 'low',
        category: 'data_access',
        branch_id: req.user.branch?.branch_id || null
      });
    } catch (logError) {
      console.error('Error creating expense log:', logError);
      // Don't fail the request if logging fails
    }
    
    res.json(statistics);
  } catch (error) {
    console.error('Error fetching expense statistics:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/expenses/by-type
 * @desc    Get expenses aggregated by type
 * @access  Private (requires view_expense_analytics permission)
 */
router.get('/by-type', auth, permissionAuth('view_expense_stats'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const { branch_id, date_from, date_to } = req.query;
    
    const filters = {};
    if (branch_id) filters.branch_id = branch_id;
    if (date_from) filters.date_from = date_from;
    if (date_to) filters.date_to = date_to;
    
    const expensesByType = await Expense.getExpensesByType(db, filters);
    
    // Create expense log entry for viewing analytics
    try {
      await ExpenseLog.createLogEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email || 'unknown',
        action: 'view_expense_analytics',
        entity_type: 'expense_analytics',
        entity_id: null,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          filters: filters,
          request_method: req.method,
          endpoint: req.originalUrl,
          success: true
        },
        severity: 'low',
        category: 'data_access',
        branch_id: req.user.branch?.branch_id || null
      });
    } catch (logError) {
      console.error('Error creating expense log:', logError);
      // Don't fail the request if logging fails
    }
    
    res.json(expensesByType);
  } catch (error) {
    console.error('Error fetching expenses by type:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/expenses/types
 * @desc    Get all available expense types
 * @access  Private
 */
router.get('/types', auth, async (req, res) => {
  try {
    const expenseTypes = [
      { value: 'office_supplies', label: 'Office Supplies' },
      { value: 'equipment', label: 'Equipment' },
      { value: 'utilities', label: 'Utilities' },
      { value: 'rent', label: 'Rent' },
      { value: 'maintenance', label: 'Maintenance' },
      { value: 'fuel', label: 'Fuel' },
      { value: 'travel', label: 'Travel' },
      { value: 'meals', label: 'Meals' },
      { value: 'marketing', label: 'Marketing' },
      { value: 'insurance', label: 'Insurance' },
      { value: 'professional_services', label: 'Professional Services' },
      { value: 'software_licenses', label: 'Software Licenses' },
      { value: 'telecommunications', label: 'Telecommunications' },
      { value: 'training', label: 'Training' },
      { value: 'repairs', label: 'Repairs' },
      { value: 'inventory', label: 'Inventory' },
      { value: 'miscellaneous', label: 'Miscellaneous' }
    ];
    
    res.json(expenseTypes);
  } catch (error) {
    console.error('Error fetching expense types:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/expenses/:id
 * @desc    Get expense by ID
 * @access  Private (requires view_expenses permission)
 */
router.get('/:id', auth, permissionAuth('view_expense'), validateObjectId, async (req, res) => {
  try {
    const db = req.app.locals.db;
    const expense = await Expense.getById(db, req.params.id);
    
    if (!expense) {
      return res.status(404).json({ message: 'Expense not found' });
    }
    
    // Create expense log entry for viewing
    try {
      await ExpenseLog.createLogEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email || 'unknown',
        action: 'view_expense',
        entity_type: 'expense',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          expense_number: expense.expense_number,
          amount: expense.amount,
          expense_type: expense.expense_type,
          request_method: req.method,
          endpoint: req.originalUrl,
          success: true
        },
        severity: 'low',
        category: 'data_access',
        branch_id: expense.branch_id
      });
    } catch (logError) {
      console.error('Error creating expense log:', logError);
      // Don't fail the request if logging fails
    }
    
    // Generate signed URLs for receipt images
    const expenseWithSignedUrls = await generateSignedUrlsForExpense(expense);
    
    res.json(expenseWithSignedUrls);
  } catch (error) {
    console.error('Error fetching expense:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   PUT /api/expenses/:id
 * @desc    Update expense by ID
 * @access  Private (requires edit_expense permission)
 */
router.put('/:id', auth, permissionAuth('edit_expense'), validateObjectId, async (req, res) => {
  try {
    const db = req.app.locals.db;
    
    // Get the expense first
    const expense = await Expense.getById(db, req.params.id);
    
    if (!expense) {
      return res.status(404).json({ message: 'Expense not found' });
    }
    
    // Don't allow non-approvers to change approval status
    if (req.body.approval_status && !req.user.permissions?.some(p => p.permission_name === 'approve_expenses' && p.granted)) {
      delete req.body.approval_status;
      delete req.body.approved_by;
      delete req.body.approval_date;
      delete req.body.approval_notes;
    }
    
    // Normalize payment_method to match schema enum values
    if (req.body.payment_method) {
      const paymentMethod = req.body.payment_method.toLowerCase().trim();
      
      // Map common variations to schema values
      const paymentMethodMap = {
        'credit card': 'card',
        'credit_card': 'card',
        'debit card': 'card',
        'debit_card': 'card',
        'bank transfer': 'bank_transfer',
        'bank_transfer': 'bank_transfer',
        'wire transfer': 'bank_transfer',
        'cheque': 'check',
        'cash': 'cash',
        'card': 'card',
        'check': 'check',
        'petty cash': 'petty_cash',
        'petty_cash': 'petty_cash',
        'digital wallet': 'digital_wallet',
        'digital_wallet': 'digital_wallet',
        'e-wallet': 'digital_wallet',
        'paypal': 'digital_wallet',
        'apple pay': 'digital_wallet',
        'google pay': 'digital_wallet',
        'other': 'other',
        'misc': 'other',
        'miscellaneous': 'other'
      };
      
      req.body.payment_method = paymentMethodMap[paymentMethod] || paymentMethod;
    }
    
    const result = await Expense.updateById(db, req.params.id, req.body);
    
    if (result.matchedCount === 0) {
      return res.status(404).json({ message: 'Expense not found' });
    }
    
    // Return updated expense
    const updatedExpense = await Expense.getById(db, req.params.id);
    
    // Create expense log entry
    try {
      await ExpenseLog.createLogEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email || 'unknown',
        action: 'update_expense',
        entity_type: 'expense',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          expense_number: expense.expense_number,
          amount: updatedExpense.amount,
          expense_type: updatedExpense.expense_type,
          request_method: req.method,
          endpoint: req.originalUrl,
          success: true,
          old_values: {
            title: expense.title,
            amount: expense.amount,
            expense_type: expense.expense_type,
            status: expense.status,
            approval_status: expense.approval_status
          },
          new_values: {
            title: updatedExpense.title,
            amount: updatedExpense.amount,
            expense_type: updatedExpense.expense_type,
            status: updatedExpense.status,
            approval_status: updatedExpense.approval_status
          }
        },
        severity: 'medium',
        category: 'data_modification',
        branch_id: updatedExpense.branch_id
      });
    } catch (logError) {
      console.error('Error creating expense log:', logError);
      // Don't fail the request if logging fails
    }
    
    res.json(updatedExpense);
  } catch (error) {
    console.error('Error updating expense:', error);
    
    if (error.name === 'MongoServerError' && error.code === 121) {
      return res.status(400).json({
        message: 'Document failed validation',
        details: error.errInfo ? error.errInfo.details : 'Validation error'
      });
    }
    
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   DELETE /api/expenses/:id
 * @desc    Delete expense by ID
 * @access  Private (requires delete_expense permission)
 */
router.delete('/:id', auth, permissionAuth('delete_expense'), validateObjectId, async (req, res) => {
  try {
    const db = req.app.locals.db;
    
    // Get the expense first
    const expense = await Expense.getById(db, req.params.id);
    
    if (!expense) {
      return res.status(404).json({ message: 'Expense not found' });
    }
    
    // Don't allow deletion of approved expenses unless user has special permission
    if (expense.approval_status === 'approved' && !req.user.permissions?.some(p => p.permission_name === 'delete_approved_expenses' && p.granted)) {
      return res.status(403).json({ message: 'Cannot delete approved expenses' });
    }
    
    // Collect S3 keys for cleanup
    const s3KeysToDelete = [];
    
    // Add receipt images to deletion list
    if (expense.receipt_images) {
      expense.receipt_images.forEach(receipt => {
        if (receipt.s3Key) {
          s3KeysToDelete.push(receipt.s3Key);
        }
      });
    }
    
    // Add invoice image to deletion list
    if (expense.invoice_image && expense.invoice_image.s3Key) {
      s3KeysToDelete.push(expense.invoice_image.s3Key);
    }
    
    const result = await Expense.deleteById(db, req.params.id);
    
    if (result.deletedCount === 0) {
      return res.status(404).json({ message: 'Expense not found' });
    }
    
    // Delete S3 files after successful database deletion
    if (s3KeysToDelete.length > 0) {
      try {
        await deleteMultipleFromS3(s3KeysToDelete);
      } catch (s3Error) {
        console.error('Error deleting S3 files for expense:', s3Error);
        // Don't fail the request if S3 cleanup fails
      }
    }
    
    // Create expense log entry
    try {
      await ExpenseLog.createLogEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email || 'unknown',
        action: 'delete_expense',
        entity_type: 'expense',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          expense_number: expense.expense_number,
          amount: expense.amount,
          expense_type: expense.expense_type,
          request_method: req.method,
          endpoint: req.originalUrl,
          success: true,
          s3_files_deleted: s3KeysToDelete.length,
          old_values: {
            title: expense.title,
            amount: expense.amount,
            expense_type: expense.expense_type,
            status: expense.status,
            approval_status: expense.approval_status
          }
        },
        severity: 'high',
        category: 'data_modification',
        branch_id: expense.branch_id
      });
    } catch (logError) {
      console.error('Error creating expense log:', logError);
      // Don't fail the request if logging fails
    }
    
    res.json({ message: 'Expense deleted successfully' });
  } catch (error) {
    console.error('Error deleting expense:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   POST /api/expenses/:id/receipt-images
 * @desc    Add a receipt image to an expense (supports both file upload and URL)
 * @access  Private (requires edit_expense permission)
 */
router.post('/:id/receipt-images', auth, permissionAuth('edit_expense'), validateObjectId, uploadReceiptImage, async (req, res) => {
  try {
    const db = req.app.locals.db;
    
    // Get the expense first
    const expense = await Expense.getById(db, req.params.id);
    
    if (!expense) {
      return res.status(404).json({ message: 'Expense not found' });
    }
    
    let receiptData;
    
    if (req.file) {
      // File upload case
      receiptData = {
        s3Key: req.file.key,
        url: req.file.location,
        title: req.body.title || req.file.originalname,
        description: req.body.description || '',
        filename: req.file.originalname,
        mimetype: req.file.mimetype,
        size: req.file.size,
        uploadedAt: new Date()
      };
    } else {
      // URL case (backward compatibility)
      const { url, title, description } = req.body;
      
      if (!url) {
        return res.status(400).json({ message: 'Either file upload or image URL is required' });
      }
      
      receiptData = {
        url,
        title: title || 'Receipt Image',
        description: description || '',
        uploadedAt: new Date()
      };
    }
    
    const result = await Expense.addReceiptImage(db, req.params.id, receiptData);
    
    if (result.matchedCount === 0) {
      return res.status(404).json({ message: 'Expense not found' });
    }
    
    // Return updated expense
    const updatedExpense = await Expense.getById(db, req.params.id);
    
    // Create expense log entry
    try {
      await ExpenseLog.createLogEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email || 'unknown',
        action: 'add_receipt',
        entity_type: 'expense',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          expense_number: expense.expense_number,
          amount: expense.amount,
          expense_type: expense.expense_type,
          request_method: req.method,
          endpoint: req.originalUrl,
          success: true,
          upload_type: req.file ? 'file_upload' : 'url',
          new_values: {
            receipt_url: receiptData.url,
            receipt_title: receiptData.title,
            receipt_description: receiptData.description,
            receipt_s3_key: receiptData.s3Key || null
          }
        },
        severity: 'low',
        category: 'data_modification',
        branch_id: expense.branch_id
      });
    } catch (logError) {
      console.error('Error creating expense log:', logError);
      // Don't fail the request if logging fails
    }
    
    res.json(updatedExpense);
  } catch (error) {
    console.error('Error adding receipt image:', error);
    
    // Clean up uploaded file from S3 if there was an error
    if (req.file && req.file.key) {
      try {
        await deleteFromS3(req.file.key);
      } catch (deleteError) {
        console.error('Error deleting S3 file:', deleteError);
      }
    }
    
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/expenses/:id/receipt-images/:receiptIndex/view
 * @desc    Get a signed URL to view a receipt image
 * @access  Private (requires view_expenses permission)
 */
router.get('/:id/receipt-images/:receiptIndex/view', auth, permissionAuth('view_expense'), validateObjectId, async (req, res) => {
  try {
    const db = req.app.locals.db;
    const receiptIndex = parseInt(req.params.receiptIndex);
    
    if (isNaN(receiptIndex)) {
      return res.status(400).json({ message: 'Invalid receipt index' });
    }
    
    // Get the expense first
    const expense = await Expense.getById(db, req.params.id);
    
    if (!expense) {
      return res.status(404).json({ message: 'Expense not found' });
    }
    
    if (!expense.receipt_images || receiptIndex >= expense.receipt_images.length) {
      return res.status(404).json({ message: 'Receipt image not found' });
    }
    
    const receiptImage = expense.receipt_images[receiptIndex];
    
    // If it's a URL-based receipt (no S3 key), return the URL directly
    if (!receiptImage.s3Key) {
      return res.json({
        success: true,
        message: 'Receipt image URL retrieved',
        data: {
          url: receiptImage.url,
          title: receiptImage.title,
          description: receiptImage.description,
          type: 'external_url'
        }
      });
    }
    
    try {
      // Generate signed URL for S3-stored receipts
      const signedUrl = await getSignedUrl(receiptImage.s3Key, 3600);
      
      if (req.query.redirect === 'false') {
        return res.json({
          success: true,
          message: 'Signed URL generated successfully',
          data: {
            url: signedUrl,
            title: receiptImage.title,
            description: receiptImage.description,
            filename: receiptImage.filename,
            mimetype: receiptImage.mimetype,
            size: receiptImage.size,
            type: 's3_file',
            expiresIn: 3600
          }
        });
      } else {
        // Redirect to the signed URL for direct file access
        res.redirect(signedUrl);
      }
    } catch (s3Error) {
      console.error('S3 error:', s3Error);
      return res.status(500).json({
        success: false,
        message: 'Error accessing receipt from storage'
      });
    }
  } catch (error) {
    console.error('Error viewing receipt image:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   DELETE /api/expenses/:id/receipt-images
 * @desc    Remove a receipt image from an expense
 * @access  Private (requires edit_expense permission)
 */
router.delete('/:id/receipt-images', auth, permissionAuth('edit_expense'), validateObjectId, async (req, res) => {
  try {
    const db = req.app.locals.db;
    
    // Get the expense first
    const expense = await Expense.getById(db, req.params.id);
    
    if (!expense) {
      return res.status(404).json({ message: 'Expense not found' });
    }
    
    const { url, receiptIndex } = req.body;
    
    if (!url && receiptIndex === undefined) {
      return res.status(400).json({ message: 'Either image URL or receipt index is required' });
    }
    
    let receiptToDelete = null;
    
    // Find the receipt to delete
    if (receiptIndex !== undefined) {
      const index = parseInt(receiptIndex);
      if (index >= 0 && expense.receipt_images && index < expense.receipt_images.length) {
        receiptToDelete = expense.receipt_images[index];
      }
    } else if (url) {
      receiptToDelete = expense.receipt_images?.find(receipt => receipt.url === url);
    }
    
    if (!receiptToDelete) {
      return res.status(404).json({ message: 'Receipt image not found' });
    }
    
    // Delete from S3 if it has an S3 key
    if (receiptToDelete.s3Key) {
      try {
        await deleteFromS3(receiptToDelete.s3Key);
      } catch (s3Error) {
        console.error('Error deleting receipt from S3:', s3Error);
        // Continue with database deletion even if S3 deletion fails
      }
    }
    
    const result = await Expense.removeReceiptImage(db, req.params.id, receiptToDelete.url);
    
    if (result.matchedCount === 0) {
      return res.status(404).json({ message: 'Expense not found' });
    }
    
    // Return updated expense
    const updatedExpense = await Expense.getById(db, req.params.id);
    
    // Create expense log entry
    try {
      await ExpenseLog.createLogEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email || 'unknown',
        action: 'remove_receipt',
        entity_type: 'expense',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          expense_number: expense.expense_number,
          amount: expense.amount,
          expense_type: expense.expense_type,
          request_method: req.method,
          endpoint: req.originalUrl,
          success: true,
          old_values: {
            receipt_url: receiptToDelete.url,
            receipt_s3_key: receiptToDelete.s3Key || null
          }
        },
        severity: 'low',
        category: 'data_modification',
        branch_id: expense.branch_id
      });
    } catch (logError) {
      console.error('Error creating expense log:', logError);
      // Don't fail the request if logging fails
    }
    
    res.json(updatedExpense);
  } catch (error) {
    console.error('Error removing receipt image:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/expenses/:id/invoice-image/view
 * @desc    Get a signed URL to view the invoice image
 * @access  Private (requires view_expenses permission)
 */
router.get('/:id/invoice-image/view', auth, permissionAuth('view_expense'), validateObjectId, async (req, res) => {
  try {
    const db = req.app.locals.db;
    
    // Get the expense first
    const expense = await Expense.getById(db, req.params.id);
    
    if (!expense) {
      return res.status(404).json({ message: 'Expense not found' });
    }
    
    if (!expense.invoice_image) {
      return res.status(404).json({ message: 'Invoice image not found' });
    }
    
    try {
      // Generate signed URL for the invoice image
      const signedUrl = await getSignedUrl(expense.invoice_image.s3Key, 3600);
      
      if (req.query.redirect === 'false') {
        return res.json({
          success: true,
          message: 'Signed URL generated successfully',
          data: {
            url: signedUrl,
            filename: expense.invoice_image.filename,
            mimetype: expense.invoice_image.mimetype,
            size: expense.invoice_image.size,
            uploadedAt: expense.invoice_image.uploadedAt,
            type: 's3_file',
            expiresIn: 3600
          }
        });
      } else {
        // Redirect to the signed URL for direct file access
        res.redirect(signedUrl);
      }
    } catch (s3Error) {
      console.error('S3 error:', s3Error);
      return res.status(500).json({
        success: false,
        message: 'Error accessing invoice image from storage'
      });
    }
  } catch (error) {
    console.error('Error viewing invoice image:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   PUT /api/expenses/:id/invoice-image
 * @desc    Update/replace the invoice image for an expense
 * @access  Private (requires edit_expense permission)
 */
router.put('/:id/invoice-image', auth, permissionAuth('edit_expense'), validateObjectId, uploadInvoiceImage, async (req, res) => {
  try {
    const db = req.app.locals.db;
    
    // Check if new invoice image was uploaded
    if (!req.file) {
      return res.status(400).json({ 
        message: 'Invoice image is required' 
      });
    }
    
    // Get the expense first
    const expense = await Expense.getById(db, req.params.id);
    
    if (!expense) {
      return res.status(404).json({ message: 'Expense not found' });
    }
    
    // Store old S3 key for cleanup
    const oldS3Key = expense.invoice_image?.s3Key;
    
    // Prepare new invoice image data
    const newInvoiceImageData = {
      s3Key: req.file.key,
      url: req.file.location,
      filename: req.file.originalname,
      mimetype: req.file.mimetype,
      size: req.file.size,
      uploadedAt: new Date()
    };
    
    // Update the expense with new invoice image
    const result = await Expense.updateById(db, req.params.id, {
      invoice_image: newInvoiceImageData,
      updated_at: new Date()
    });
    
    if (result.matchedCount === 0) {
      // Clean up the newly uploaded file if update failed
      try {
        await deleteFromS3(req.file.key);
      } catch (deleteError) {
        console.error('Error deleting new S3 file:', deleteError);
      }
      return res.status(404).json({ message: 'Expense not found' });
    }
    
    // Delete old S3 file after successful update
    if (oldS3Key) {
      try {
        await deleteFromS3(oldS3Key);
      } catch (s3Error) {
        console.error('Error deleting old invoice image from S3:', s3Error);
        // Don't fail the request if S3 cleanup fails
      }
    }
    
    // Return updated expense
    const updatedExpense = await Expense.getById(db, req.params.id);
    
    // Create expense log entry
    try {
      await ExpenseLog.createLogEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email || 'unknown',
        action: 'update_invoice_image',
        entity_type: 'expense',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          expense_number: expense.expense_number,
          amount: expense.amount,
          expense_type: expense.expense_type,
          request_method: req.method,
          endpoint: req.originalUrl,
          success: true,
          old_values: {
            invoice_image_s3_key: oldS3Key || null
          },
          new_values: {
            invoice_image_s3_key: newInvoiceImageData.s3Key,
            invoice_image_filename: newInvoiceImageData.filename,
            invoice_image_size: newInvoiceImageData.size
          }
        },
        severity: 'medium',
        category: 'data_modification',
        branch_id: expense.branch_id
      });
    } catch (logError) {
      console.error('Error creating expense log:', logError);
      // Don't fail the request if logging fails
    }
    
    res.json(updatedExpense);
  } catch (error) {
    console.error('Error updating invoice image:', error);
    
    // Clean up uploaded file from S3 if there was an error
    if (req.file && req.file.key) {
      try {
        await deleteFromS3(req.file.key);
      } catch (deleteError) {
        console.error('Error deleting S3 file:', deleteError);
      }
    }
    
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   PUT /api/expenses/:id/approval
 * @desc    Approve or reject an expense
 * @access  Private (requires approve_expenses permission)
 */
router.put('/:id/approval', auth, permissionAuth('approve_expenses'), validateObjectId, async (req, res) => {
  try {
    const db = req.app.locals.db;
    
    // Get the expense first for logging
    const expense = await Expense.getById(db, req.params.id);
    
    if (!expense) {
      return res.status(404).json({ message: 'Expense not found' });
    }
    
    const { approval_status, approval_notes } = req.body;
    
    if (!approval_status || !['approved', 'rejected'].includes(approval_status)) {
      return res.status(400).json({ 
        message: 'Valid approval_status is required (approved or rejected)' 
      });
    }
    
    const result = await Expense.updateApprovalStatus(db, req.params.id, {
      approval_status,
      approved_by: req.user._id,
      approval_notes
    });
    
    if (result.matchedCount === 0) {
      return res.status(404).json({ message: 'Expense not found' });
    }
    
    // Return updated expense
    const updatedExpense = await Expense.getById(db, req.params.id);
    
    // Create expense log entry
    try {
      await ExpenseLog.createLogEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email || 'unknown',
        action: approval_status === 'approved' ? 'approve_expense' : 'reject_expense',
        entity_type: 'expense',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          expense_number: expense.expense_number,
          amount: expense.amount,
          expense_type: expense.expense_type,
          request_method: req.method,
          endpoint: req.originalUrl,
          success: true,
          old_values: {
            approval_status: expense.approval_status,
            approved_by: expense.approved_by,
            approval_notes: expense.approval_notes
          },
          new_values: {
            approval_status: updatedExpense.approval_status,
            approved_by: updatedExpense.approved_by,
            approval_notes: updatedExpense.approval_notes
          }
        },
        severity: 'high',
        category: 'data_modification',
        branch_id: expense.branch_id
      });
    } catch (logError) {
      console.error('Error creating expense log:', logError);
      // Don't fail the request if logging fails
    }
    
    res.json(updatedExpense);
  } catch (error) {
    console.error('Error updating expense approval:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/expenses/branch/:branchId
 * @desc    Get expenses by branch ID
 * @access  Private (requires view_expenses permission)
 */
router.get('/branch/:branchId', auth, permissionAuth('view_expense'), validateObjectId, async (req, res) => {
  try {
    const db = req.app.locals.db;
    const expenses = await Expense.getByBranch(db, req.params.branchId);
    
    res.json(expenses);
  } catch (error) {
    console.error('Error fetching expenses by branch:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/expenses/pending-approval
 * @desc    Get expenses pending approval
 * @access  Private (requires approve_expenses permission)
 */
router.get('/pending-approval', auth, permissionAuth('approve_expenses'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const { branch_id } = req.query;
    
    const filters = {
      approval_status: 'pending'
    };
    
    if (branch_id) {
      filters.branch_id = branch_id;
    }
    
    const expenses = await Expense.getAll(db, filters);
    
    res.json(expenses);
  } catch (error) {
    console.error('Error fetching pending expenses:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/expenses/logs
 * @desc    Get expense logs with optional filters
 * @access  Private (requires view_expense_analytics permission)
 */
router.get('/logs', auth, permissionAuth('view_expense_stats'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const { 
      user_id, 
      action, 
      entity_id, 
      start_date, 
      end_date,
      severity,
      category,
      branch_id,
      page = 1,
      limit = 50
    } = req.query;
    
    // Build filter object
    const filters = {};
    if (user_id) filters.user_id = user_id;
    if (action) filters.action = action;
    if (entity_id) filters.entity_id = entity_id;
    if (start_date) filters.start_date = start_date;
    if (end_date) filters.end_date = end_date;
    if (severity) filters.severity = severity;
    if (category) filters.category = category;
    if (branch_id) filters.branch_id = branch_id;
    
    const options = {
      limit: parseInt(limit),
      skip: (parseInt(page) - 1) * parseInt(limit),
      sort: { timestamp: -1 }
    };
    
    const logs = await ExpenseLog.findExpenseLogs(db, filters, options);
    const total = await ExpenseLog.countExpenseLogs(db, filters);
    
    res.json({
      logs,
      pagination: {
        current_page: parseInt(page),
        total_pages: Math.ceil(total / limit),
        total_logs: total,
        per_page: parseInt(limit)
      }
    });
  } catch (error) {
    console.error('Error fetching expense logs:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/expenses/:id/logs
 * @desc    Get logs for a specific expense
 * @access  Private (requires view_expenses permission)
 */
router.get('/:id/logs', auth, permissionAuth('view_expense'), validateObjectId, async (req, res) => {
  try {
    const db = req.app.locals.db;
    const { page = 1, limit = 20 } = req.query;
    
    const options = {
      limit: parseInt(limit),
      skip: (parseInt(page) - 1) * parseInt(limit),
      sort: { timestamp: -1 }
    };
    
    const logs = await ExpenseLog.findExpenseLogsByExpenseId(db, req.params.id, options);
    
    res.json({
      expense_id: req.params.id,
      logs,
      pagination: {
        current_page: parseInt(page),
        per_page: parseInt(limit),
        total_logs: logs.length
      }
    });
  } catch (error) {
    console.error('Error fetching expense logs:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/expenses/logs/statistics
 * @desc    Get expense log statistics
 * @access  Private (requires view_expense_analytics permission)
 */
router.get('/logs/statistics', auth, permissionAuth('view_expense_stats'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const { start_date, end_date } = req.query;
    
    const startDate = start_date ? new Date(start_date) : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000); // 30 days ago
    const endDate = end_date ? new Date(end_date) : new Date();
    
    const statistics = await ExpenseLog.getExpenseLogStatistics(db, startDate, endDate);
    
    res.json({
      period: {
        start_date: startDate,
        end_date: endDate
      },
      statistics
    });
  } catch (error) {
    console.error('Error fetching expense log statistics:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/expenses/logs/recent
 * @desc    Get recent expense activity
 * @access  Private (requires view_expense_analytics permission)
 */
router.get('/logs/recent', auth, permissionAuth('view_expense_stats'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const { hours = 24, limit = 100 } = req.query;
    
    const recentLogs = await ExpenseLog.findRecentActivity(db, parseInt(hours), parseInt(limit));
    
    res.json({
      period_hours: parseInt(hours),
      activity_count: recentLogs.length,
      recent_activity: recentLogs
    });
  } catch (error) {
    console.error('Error fetching recent expense activity:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/expenses/logs/user/:userId
 * @desc    Get expense logs for a specific user
 * @access  Private (requires view_expense_analytics permission or own user)
 */
router.get('/logs/user/:userId', auth, validateObjectId, async (req, res) => {
  try {
    const db = req.app.locals.db;
    
    // Check if user can view logs for this user
    if (req.params.userId !== req.user._id.toString() && 
        !req.user.permissions.includes('view_expense_analytics')) {
      return res.status(403).json({ 
        message: 'You can only view your own expense logs unless you have analytics permission' 
      });
    }
    
    const { 
      action, 
      start_date, 
      end_date,
      severity,
      category,
      page = 1,
      limit = 50
    } = req.query;
    
    const filters = {
      user_id: req.params.userId
    };
    
    if (action) filters.action = action;
    if (start_date) filters.start_date = start_date;
    if (end_date) filters.end_date = end_date;
    if (severity) filters.severity = severity;
    if (category) filters.category = category;
    
    const options = {
      limit: parseInt(limit),
      skip: (parseInt(page) - 1) * parseInt(limit),
      sort: { timestamp: -1 }
    };
    
    const logs = await ExpenseLog.findExpenseLogs(db, filters, options);
    const total = await ExpenseLog.countExpenseLogs(db, filters);
    
    res.json({
      user_id: req.params.userId,
      logs,
      pagination: {
        current_page: parseInt(page),
        total_pages: Math.ceil(total / limit),
        total_logs: total,
        per_page: parseInt(limit)
      }
    });
  } catch (error) {
    console.error('Error fetching user expense logs:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/expenses/logs/dashboard
 * @desc    Get expense log dashboard data
 * @access  Private (requires view_expense_analytics permission)
 */
router.get('/logs/dashboard', auth, permissionAuth('view_expense_stats'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const { period_days = 7 } = req.query;
    
    const startDate = new Date(Date.now() - (parseInt(period_days) * 24 * 60 * 60 * 1000));
    const endDate = new Date();
    
    // Get recent activity
    const recentActivity = await ExpenseLog.findRecentActivity(db, 24, 10);
    
    // Get statistics for the period
    const statistics = await ExpenseLog.getExpenseLogStatistics(db, startDate, endDate);
    
    // Get activity breakdown by action
    const actionBreakdown = await db.collection('expense_logs').aggregate([
      {
        $match: {
          timestamp: {
            $gte: startDate,
            $lte: endDate
          }
        }
      },
      {
        $group: {
          _id: "$action",
          count: { $sum: 1 }
        }
      },
      {
        $sort: { count: -1 }
      }
    ]).toArray();
    
    // Get activity by severity
    const severityBreakdown = await db.collection('expense_logs').aggregate([
      {
        $match: {
          timestamp: {
            $gte: startDate,
            $lte: endDate
          }
        }
      },
      {
        $group: {
          _id: "$severity",
          count: { $sum: 1 }
        }
      }
    ]).toArray();
    
    // Get daily activity trend
    const dailyActivity = await db.collection('expense_logs').aggregate([
      {
        $match: {
          timestamp: {
            $gte: startDate,
            $lte: endDate
          }
        }
      },
      {
        $group: {
          _id: {
            $dateToString: { format: "%Y-%m-%d", date: "$timestamp" }
          },
          count: { $sum: 1 }
        }
      },
      {
        $sort: { "_id": 1 }
      }
    ]).toArray();
    
    res.json({
      period: {
        start_date: startDate,
        end_date: endDate,
        days: parseInt(period_days)
      },
      recent_activity: recentActivity,
      statistics,
      breakdowns: {
        by_action: actionBreakdown,
        by_severity: severityBreakdown,
        daily_trend: dailyActivity
      }
    });
  } catch (error) {
    console.error('Error fetching expense log dashboard:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/expenses/logs/export
 * @desc    Export expense logs as CSV
 * @access  Private (requires view_expense_analytics permission)
 */
router.get('/logs/export', auth, permissionAuth('view_expense_stats'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const { 
      user_id, 
      action, 
      entity_id, 
      start_date, 
      end_date,
      severity,
      category,
      branch_id,
      format = 'csv'
    } = req.query;
    
    // Build filter object
    const filters = {};
    if (user_id) filters.user_id = user_id;
    if (action) filters.action = action;
    if (entity_id) filters.entity_id = entity_id;
    if (start_date) filters.start_date = start_date;
    if (end_date) filters.end_date = end_date;
    if (severity) filters.severity = severity;
    if (category) filters.category = category;
    if (branch_id) filters.branch_id = branch_id;
    
    // Get logs (no pagination for export)
    const logs = await ExpenseLog.findExpenseLogs(db, filters, { limit: 10000 });
    
    if (format === 'csv') {
      // Create CSV headers
      const headers = [
        'Timestamp',
        'User Email',
        'Action',
        'Entity Type',
        'Entity ID',
        'IP Address',
        'Severity',
        'Category',
        'Details'
      ];
      
      // Create CSV rows
      const rows = logs.map(log => [
        log.timestamp.toISOString(),
        log.user_email || 'unknown',
        log.action,
        log.entity_type,
        log.entity_id || '',
        log.ip_address || 'unknown',
        log.severity || 'low',
        log.category || 'data_access',
        JSON.stringify(log.details || {})
      ]);
      
      // Combine headers and rows
      const csvContent = [headers, ...rows]
        .map(row => row.map(field => `"${String(field).replace(/"/g, '""')}"`).join(','))
        .join('\n');
      
      // Set headers for file download
      const filename = `expense_logs_${new Date().toISOString().split('T')[0]}.csv`;
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      
      res.send(csvContent);
    } else {
      // JSON format
      res.json({
        export_info: {
          total_records: logs.length,
          export_date: new Date(),
          filters: filters
        },
        logs
      });
    }
    
    // Log the export action
    try {
      await ExpenseLog.createLogEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email || 'unknown',
        action: 'export_expenses',
        entity_type: 'expense_system',
        entity_id: null,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          export_format: format,
          filters: filters,
          record_count: logs.length,
          request_method: req.method,
          endpoint: req.originalUrl,
          success: true
        },
        severity: 'medium',
        category: 'data_access',
        branch_id: req.user.branch?.branch_id || null
      });
    } catch (logError) {
      console.error('Error creating export log:', logError);
      // Don't fail the request if logging fails
    }
    
  } catch (error) {
    console.error('Error exporting expense logs:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   POST /api/expenses/logs/cleanup
 * @desc    Clean up old expense logs (Admin only)
 * @access  Private (Admin only)
 */
router.post('/logs/cleanup', auth, async (req, res) => {
  try {
    // Check if user is admin
    if (req.user.role_name !== 'Admin') {
      return res.status(403).json({ 
        message: 'Only administrators can perform log cleanup' 
      });
    }
    
    const db = req.app.locals.db;
    const { days_to_keep = 365 } = req.body;
    
    const cutoffDate = new Date(Date.now() - (parseInt(days_to_keep) * 24 * 60 * 60 * 1000));
    
    const result = await ExpenseLog.deleteOldLogs(db, cutoffDate);
    
    // Log the cleanup action
    try {
      await ExpenseLog.createLogEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email || 'unknown',
        action: 'view_expense_analytics',
        entity_type: 'expense_system',
        entity_id: null,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          cleanup_action: 'delete_old_logs',
          days_to_keep: parseInt(days_to_keep),
          cutoff_date: cutoffDate,
          deleted_count: result.deletedCount,
          request_method: req.method,
          endpoint: req.originalUrl,
          success: true
        },
        severity: 'high',
        category: 'system',
        branch_id: req.user.branch?.branch_id || null
      });
    } catch (logError) {
      console.error('Error creating cleanup log:', logError);
      // Don't fail the request if logging fails
    }
    
    res.json({
      message: `Successfully cleaned up old expense logs`,
      deleted_count: result.deletedCount,
      cutoff_date: cutoffDate,
      days_kept: parseInt(days_to_keep)
    });
    
  } catch (error) {
    console.error('Error cleaning up expense logs:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/expenses/logs/search
 * @desc    Search expense logs
 * @access  Private (requires view_expense_analytics permission)
 */
router.get('/logs/search', auth, permissionAuth('view_expense_stats'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const { 
      q: searchTerm,
      user_id,
      action,
      start_date,
      end_date,
      page = 1,
      limit = 50
    } = req.query;
    
    if (!searchTerm) {
      return res.status(400).json({ message: 'Search term (q) is required' });
    }
    
    const filters = {};
    if (user_id) filters.user_id = user_id;
    if (action) filters.action = action;
    if (start_date) filters.start_date = start_date;
    if (end_date) filters.end_date = end_date;
    
    const options = {
      limit: parseInt(limit),
      skip: (parseInt(page) - 1) * parseInt(limit),
      sort: { timestamp: -1 }
    };
    
    const logs = await ExpenseLog.searchExpenseLogs(db, searchTerm, filters, options);
    
    res.json({
      search_term: searchTerm,
      filters,
      results: logs,
      pagination: {
        current_page: parseInt(page),
        per_page: parseInt(limit),
        result_count: logs.length
      }
    });
  } catch (error) {
    console.error('Error searching expense logs:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/expenses/logs/users/active
 * @desc    Get most active users in expense system
 * @access  Private (requires view_expense_analytics permission)
 */
router.get('/logs/users/active', auth, permissionAuth('view_expense_stats'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const { days = 30, limit = 10 } = req.query;
    
    const activeUsers = await ExpenseLog.getMostActiveUsers(db, parseInt(days), parseInt(limit));
    
    res.json({
      period_days: parseInt(days),
      active_users: activeUsers
    });
  } catch (error) {
    console.error('Error fetching active users:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/expenses/:id/timeline
 * @desc    Get activity timeline for a specific expense
 * @access  Private (requires view_expenses permission)
 */
router.get('/:id/timeline', auth, permissionAuth('view_expense'), validateObjectId, async (req, res) => {
  try {
    const db = req.app.locals.db;
    
    // First check if expense exists
    const expense = await Expense.getById(db, req.params.id);
    if (!expense) {
      return res.status(404).json({ message: 'Expense not found' });
    }
    
    const timeline = await ExpenseLog.getExpenseActivityTimeline(db, req.params.id);
    
    res.json({
      expense_id: req.params.id,
      expense_number: expense.expense_number,
      timeline
    });
  } catch (error) {
    console.error('Error fetching expense timeline:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/expenses/logs/trends
 * @desc    Get expense activity trends
 * @access  Private (requires view_expense_analytics permission)
 */
router.get('/logs/trends', auth, permissionAuth('view_expense_stats'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const { days = 30 } = req.query;
    
    const trends = await ExpenseLog.getActivityTrends(db, parseInt(days));
    
    res.json(trends);
  } catch (error) {
    console.error('Error fetching expense trends:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/expenses/logs/user/:userId/summary
 * @desc    Get activity summary for a specific user
 * @access  Private (requires view_expense_analytics permission or own user)
 */
router.get('/logs/user/:userId/summary', auth, validateObjectId, async (req, res) => {
  try {
    const db = req.app.locals.db;
    
    // Check if user can view summary for this user
    if (req.params.userId !== req.user._id.toString() && 
        !req.user.permissions.includes('view_expense_analytics')) {
      return res.status(403).json({ 
        message: 'You can only view your own activity summary unless you have analytics permission' 
      });
    }
    
    const { days = 30 } = req.query;
    
    const summary = await ExpenseLog.getUserActivitySummary(db, req.params.userId, parseInt(days));
    
    res.json(summary);
  } catch (error) {
    console.error('Error fetching user activity summary:', error);
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
