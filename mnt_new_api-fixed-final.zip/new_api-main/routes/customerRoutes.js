const express = require('express');
const router = express.Router();
const { ObjectId } = require('mongodb');

// Middleware
const auth = require('../middleware/auth');
const adminAuth = require('../middleware/adminAuth');
const permissionAuth = require('../middleware/permissionAuth');

// Import Customer model
const { Customer } = require('../models');

/**
 * @route   GET /api/customers
 * @desc    Get all customers
 * @access  Admin or users with view_all_customers permission
 */
router.get('/', permissionAuth('view_all_customers'), async (req, res) => {
  try {
    // Check for branch filter
    const { branch_id } = req.query;
    
    let query = {};
    if (branch_id) {
      // If branch_id is provided, filter by branch
      query = { 'branch.branch_id': new ObjectId(branch_id) };
    }
    
    const customers = await req.app.locals.db.collection('customers').find(query).toArray();
    res.json(customers);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   POST /api/customers
 * @desc    Create a new customer
 * @access  Admin or users with create_customer permission
 */
router.post('/',permissionAuth('create_customer'), async (req, res) => {
  try {
    const { first_name, last_name, email, phone, city, country, branch, vehicles } = req.body;

    // Basic validation
    if (!first_name || !last_name) {
      return res.status(400).json({ message: 'First name and last name are required' });
    }

    // Check for existing customer with email if email is provided
    if (email) {
      const existingCustomer = await req.app.locals.db.collection('customers').findOne({ email });
      if (existingCustomer) {
        return res.status(400).json({ message: 'Customer with this email already exists' });
      }
    }

    // Process vehicles to ensure year is an integer
    let processedVehicles = [];
    if (vehicles && Array.isArray(vehicles)) {
      processedVehicles = vehicles.map(vehicle => {
        const processedVehicle = { ...vehicle };
        
        // Only include year field if it exists and is not empty
        if (vehicle.year && vehicle.year.toString().trim() !== '') {
          processedVehicle.year = parseInt(vehicle.year, 10);
        } else {
          // Remove year field completely if it doesn't exist or is empty
          delete processedVehicle.year;
        }
        
        return processedVehicle;
      });
    }
    
    // Convert branch_id to ObjectId if branch data is provided
    let processedBranch = null;
    if (branch) {
      processedBranch = {
        ...branch,
        branch_id: branch.branch_id ? new ObjectId(branch.branch_id) : null
      };
    }

    // Create customer
    const customerData = {
      first_name,
      last_name,
      phone,
      city,
      country,
      branch: processedBranch,
      vehicles: processedVehicles
    };
    
    // Only include email if it's provided and not empty
    if (email && email.trim() !== '') {
      customerData.email = email.trim();
    }
    
    const customer = await Customer.create(req.app.locals.db, customerData);

    res.status(201).json(customer);
  } catch (err) {
    console.error(err);
    
    // Check for MongoDB validation errors
    if (err.name === 'MongoServerError' && err.code === 121) {
      return res.status(400).json({ 
        message: 'Validation error', 
        error: 'Document failed validation',
        details: err.errInfo ? err.errInfo.details : 'Schema validation failed'
      });
    }
    
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   GET /api/customers/check-exists
 * @desc    Check if a customer exists by phone or email
 * @access  Private
 */
router.get('/check-exists', permissionAuth('view_all_customers'), async (req, res) => {
  try {
    const { phone, email } = req.query;

    if (!phone && !email) {
      return res.status(400).json({
        success: false,
        message: 'Phone or email is required'
      });
    }

    const db = req.app.locals.db;

    // Build query
    const query = { $or: [] };
    if (phone) query.$or.push({ phone });
    if (email) query.$or.push({ email });

    const customer = await db.collection('customers').findOne(query);

    if (customer) {
      res.json({
        success: true,
        exists: true,
        customer: {
          customer_id: customer._id,
          first_name: customer.first_name,
          last_name: customer.last_name,
          phone: customer.phone,
          email: customer.email,
          city: customer.city,
          country: customer.country
        }
      });
    } else {
      res.json({
        success: true,
        exists: false,
        customer: null
      });
    }
  } catch (error) {
    console.error('Error checking customer existence:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

/**
 * @route   GET /api/customers/search
 * @desc    Search customers by name, phone, or email
 * @access  Private
 */
router.get('/search', permissionAuth('view_all_customers'), async (req, res) => {
  try {
    const { search } = req.query;

    if (!search || search.length < 2) {
      return res.json({
        success: true,
        customers: []
      });
    }

    const db = req.app.locals.db;

    // Create search query
    const searchRegex = new RegExp(search, 'i');
    const query = {
      $or: [
        { first_name: { $regex: searchRegex } },
        { last_name: { $regex: searchRegex } },
        { email: { $regex: searchRegex } },
        { phone: { $regex: searchRegex } }
      ]
    };

    const customers = await db.collection('customers')
      .find(query)
      .limit(10) // Limit results for performance
      .toArray();

    res.json({
      success: true,
      customers: customers.map(customer => ({
        _id: customer._id,
        first_name: customer.first_name,
        last_name: customer.last_name,
        phone: customer.phone,
        email: customer.email,
        city: customer.city,
        country: customer.country,
        vehicles: customer.vehicles || []
      }))
    });
  } catch (error) {
    console.error('Error searching customers:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

/**
 * @route   GET /api/customers/:id
 * @desc    Get customer by ID
 * @access  Admin or users with view_customer permission
 */
router.get('/:id', permissionAuth('view_customer') ,async (req, res) => {
  try {
    const customer = await Customer.getById(req.app.locals.db, req.params.id);

    if (!customer) {
      return res.status(404).json({ message: 'Customer not found' });
    }

    res.json(customer);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   PUT /api/customers/:id
 * @desc    Update customer by ID
 * @access  Admin or users with update_customer permission
 */
router.put('/:id', permissionAuth('update_customer'),async (req, res) => {
  try {
    const { first_name, last_name, email, phone, city, country, branch } = req.body;

    // Check if customer exists
    const customer = await Customer.getById(req.app.locals.db, req.params.id);
    if (!customer) {
      return res.status(404).json({ message: 'Customer not found' });
    }

    // Check email uniqueness if email is being updated
    if (email && email !== customer.email) {
      const existingCustomer = await req.app.locals.db.collection('customers')
        .findOne({ email, _id: { $ne: new ObjectId(req.params.id) } });
        
      if (existingCustomer) {
        return res.status(400).json({ message: 'Email already in use' });
      }
    }

    // Update customer
    const updatedData = {};
    if (first_name) updatedData.first_name = first_name;
    if (last_name) updatedData.last_name = last_name;
    if (email) updatedData.email = email;
    if (phone !== undefined) updatedData.phone = phone;
    if (city !== undefined) updatedData.city = city;
    if (country !== undefined) updatedData.country = country;
    
    // Convert branch_id to ObjectId if branch data is provided
    if (branch !== undefined) {
      if (branch === null) {
        updatedData.branch = null;
      } else {
        updatedData.branch = {
          ...branch,
          branch_id: branch.branch_id ? new ObjectId(branch.branch_id) : null
        };
      }
    }

    const result = await Customer.updateById(req.app.locals.db, req.params.id, updatedData);

    if (result.matchedCount === 0) {
      return res.status(404).json({ message: 'Customer not found' });
    }

    // Get updated customer
    const updatedCustomer = await Customer.getById(req.app.locals.db, req.params.id);
    res.json(updatedCustomer);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   DELETE /api/customers/:id
 * @desc    Delete customer by ID
 * @access  Admin or users with delete_customer permission
 */
router.delete('/:id', permissionAuth('delete_customer'), async (req, res) => {
  try {
    const result = await Customer.deleteById(req.app.locals.db, req.params.id);

    if (result.deletedCount === 0) {
      return res.status(404).json({ message: 'Customer not found' });
    }

    res.json({ message: 'Customer deleted' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   POST /api/customers/:id/vehicles
 * @desc    Add a vehicle to a customer
 * @access  Admin or users with manage_vehicles permission
 */
router.post('/:id/vehicles', permissionAuth('manage_vehicles'), async (req, res) => {
  try {
    const { vin, make, model, year, license_plate, color, vehicle_type } = req.body;

    // Basic validation
    if (!make || !model || !year) {
      return res.status(400).json({ message: 'Make, model, and year are required' });
    }

    // Check if customer exists
    const customer = await Customer.getById(req.app.locals.db, req.params.id);
    if (!customer) {
      return res.status(404).json({ message: 'Customer not found' });
    }

    // Check if VIN is already registered for this customer (only if VIN is provided)
    if (vin && vin.trim() && customer.vehicles.some(v => v.vin && v.vin.toLowerCase() === vin.toLowerCase())) {
      return res.status(400).json({ message: 'Vehicle with this VIN already exists for this customer' });
    }

    // Add vehicle
    const result = await Customer.addVehicle(req.app.locals.db, req.params.id, {
      vin,
      make,
      model,
      year: parseInt(year),
      license_plate,
      color,
      vehicle_type
    });

    // Get updated customer
    const updatedCustomer = await Customer.getById(req.app.locals.db, req.params.id);
    res.status(201).json(updatedCustomer);
  } catch (err) {
    console.error(err);
    
    // Check for MongoDB validation errors
    if (err.name === 'MongoServerError' && err.code === 121) {
      return res.status(400).json({ 
        message: 'Validation error', 
        error: 'Document failed validation',
        details: err.errInfo ? err.errInfo.details : 'Schema validation failed'
      });
    }
    
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   PUT /api/customers/:customerId/vehicles/:vehicleId
 * @desc    Update a vehicle
 * @access  Admin or users with manage_vehicles permission
 */
router.put('/:customerId/vehicles/:vehicleId', async (req, res) => {
  try {
    const { vin, make, model, year, license_plate, color, vehicle_type } = req.body;
    const { customerId, vehicleId } = req.params;

    // Check if customer exists
    const customer = await Customer.getById(req.app.locals.db, customerId);
    if (!customer) {
      return res.status(404).json({ message: 'Customer not found' });
    }

    // Check if vehicle exists
    const vehicle = customer.vehicles.find(v => v.vehicle_id === parseInt(vehicleId));
    if (!vehicle) {
      return res.status(404).json({ message: 'Vehicle not found' });
    }

    // Check if VIN is updated and already exists for another vehicle
    if (vin && vin !== vehicle.vin && 
        customer.vehicles.some(v => v.vin.toLowerCase() === vin.toLowerCase() && v.vehicle_id !== parseInt(vehicleId))) {
      return res.status(400).json({ message: 'Another vehicle with this VIN already exists for this customer' });
    }

    // Update vehicle data
    const updateData = {};
    if (vin) updateData.vin = vin;
    if (make) updateData.make = make;
    if (model) updateData.model = model;
    if (year) updateData.year = parseInt(year);
    if (license_plate !== undefined) updateData.license_plate = license_plate;
    if (color !== undefined) updateData.color = color;
    if (vehicle_type !== undefined) updateData.vehicle_type = vehicle_type;

    await Customer.updateVehicle(req.app.locals.db, customerId, parseInt(vehicleId), updateData);

    // Get updated customer
    const updatedCustomer = await Customer.getById(req.app.locals.db, customerId);
    res.json(updatedCustomer);
  } catch (err) {
    console.error(err);
    
    // Check for MongoDB validation errors
    if (err.name === 'MongoServerError' && err.code === 121) {
      return res.status(400).json({ 
        message: 'Validation error', 
        error: 'Document failed validation',
        details: err.errInfo ? err.errInfo.details : 'Schema validation failed'
      });
    }
    
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   DELETE /api/customers/:customerId/vehicles/:vehicleId
 * @desc    Remove a vehicle
 * @access  Admin or users with manage_vehicles permission
 */
router.delete('/:customerId/vehicles/:vehicleId', permissionAuth('manage_vehicles'), async (req, res) => {
  try {
    const { customerId, vehicleId } = req.params;

    // Check if customer exists
    const customer = await Customer.getById(req.app.locals.db, customerId);
    if (!customer) {
      return res.status(404).json({ message: 'Customer not found' });
    }

    // Check if vehicle exists
    const vehicle = customer.vehicles.find(v => v.vehicle_id === parseInt(vehicleId));
    if (!vehicle) {
      return res.status(404).json({ message: 'Vehicle not found' });
    }

    // Remove vehicle
    await Customer.removeVehicle(req.app.locals.db, customerId, parseInt(vehicleId));

    // Get updated customer
    const updatedCustomer = await Customer.getById(req.app.locals.db, customerId);
    res.json(updatedCustomer);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   GET /api/customers/:customerId/vehicles/:vehicleId
 * @desc    Get a specific vehicle
 * @access  Admin or users with view_customer permission
 */
router.get('/:customerId/vehicles/:vehicleId', permissionAuth('view_customer'), async (req, res) => {
  try {
    const { customerId, vehicleId } = req.params;

    // Check if customer exists
    const customer = await Customer.getById(req.app.locals.db, customerId);
    if (!customer) {
      return res.status(404).json({ message: 'Customer not found' });
    }

    // Find vehicle
    const vehicle = customer.vehicles.find(v => v.vehicle_id === parseInt(vehicleId));
    if (!vehicle) {
      return res.status(404).json({ message: 'Vehicle not found' });
    }

    res.json(vehicle);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   GET /api/customers/:customerId/vehicles
 * @desc    Get all vehicles for a customer
 * @access  Admin or users with view_customer permission
 */
router.get('/:customerId/vehicles', permissionAuth('view_customer'), async (req, res) => {
  try {
    const customer = await Customer.getById(req.app.locals.db, req.params.customerId);
    
    if (!customer) {
      return res.status(404).json({ message: 'Customer not found' });
    }

    res.json(customer.vehicles);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   PATCH /api/customers/:id/branch
 * @desc    Update customer branch
 * @access  Admin or users with update_customer permission
 */
router.patch('/:id/branch', permissionAuth('update_customer'), async (req, res) => {
  try {
    const { branch } = req.body;

    // Basic validation
    if (!branch || !branch.branch_id || !branch.branch_name) {
      return res.status(400).json({ message: 'Branch ID and branch name are required' });
    }

    // Check if customer exists
    const customer = await Customer.getById(req.app.locals.db, req.params.id);
    if (!customer) {
      return res.status(404).json({ message: 'Customer not found' });
    }

    // Convert branch_id to ObjectId and update branch
    const processedBranch = {
      ...branch,
      branch_id: branch.branch_id ? new ObjectId(branch.branch_id) : null
    };
    
    await Customer.updateBranch(req.app.locals.db, req.params.id, processedBranch);

    // Get updated customer
    const updatedCustomer = await Customer.getById(req.app.locals.db, req.params.id);
    res.json(updatedCustomer);
  } catch (err) {
    console.error(err);
    
    // Check for MongoDB validation errors
    if (err.name === 'MongoServerError' && err.code === 121) {
      return res.status(400).json({ 
        message: 'Validation error', 
        error: 'Document failed validation',
        details: err.errInfo ? err.errInfo.details : 'Schema validation failed'
      });
    }
    
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   GET /api/customers/:id/vehicles-enhanced
 * @desc    Get all vehicles for a customer with enhanced details
 * @access  Private
 */
router.get('/:id/vehicles-enhanced', permissionAuth('view_customer'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const customer = await db.collection('customers').findOne({
      _id: new ObjectId(req.params.id)
    });
    
    if (!customer) {
      return res.status(404).json({
        success: false,
        message: 'Customer not found'
      });
    }
    
    // Enhance vehicles with customer information for easier selection
    const enhancedVehicles = (customer.vehicles || []).map(vehicle => ({
      vehicle_id: vehicle.vehicle_id,
      customer_id: customer._id,
      make: vehicle.make,
      model: vehicle.model,
      year: vehicle.year,
      license_plate: vehicle.license_plate,
      vin: vehicle.vin,
      color: vehicle.color,
      vehicle_type: vehicle.vehicle_type,
      customer_first_name: customer.first_name,
      customer_last_name: customer.last_name,
      customer_email: customer.email,
      customer_phone: customer.phone,
      customer_city: customer.city,
      customer_country: customer.country
    }));
    
    res.json({
      success: true,
      vehicles: enhancedVehicles
    });
  } catch (error) {
    console.error('Error fetching enhanced vehicles:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

module.exports = router;
