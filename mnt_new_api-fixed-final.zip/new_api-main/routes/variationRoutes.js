const express = require('express');
const router = express.Router();
const { ObjectId } = require('mongodb');

// Middleware
const auth = require('../middleware/auth');
const adminAuth = require('../middleware/adminAuth');
const permissionAuth = require('../middleware/permissionAuth');

// Import Variation model
const { Variation, Stage } = require('../models');

/**
 * @route   GET /api/variations
 * @desc    Get all variations
 * @access  Private
 */
router.get('/', auth, async (req, res) => {
  try {
    const variations = await Variation.getAll(req.app.locals.db);
    res.json(variations);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   GET /api/variations/:id
 * @desc    Get variation by ID
 * @access  Private
 */
router.get('/:id', auth, async (req, res) => {
  try {
    // Check for "include" query parameter to determine whether to populate stages
    const { include } = req.query;
    
    let variation;
    if (include === 'stages') {
      variation = await Variation.getWithStages(req.app.locals.db, req.params.id);
    } else {
      variation = await Variation.getById(req.app.locals.db, req.params.id);
    }
    
    if (!variation) {
      return res.status(404).json({ message: 'Variation not found' });
    }
    
    res.json(variation);
  } catch (err) {
    if (err.name === 'BSONTypeError') {
      return res.status(400).json({ message: 'Invalid variation ID format' });
    }
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   GET /api/variations/code/:code
 * @desc    Get variation by code
 * @access  Private
 */
router.get('/code/:code', auth, async (req, res) => {
  try {
    const variation = await Variation.getByCode(req.app.locals.db, req.params.code);
    
    if (!variation) {
      return res.status(404).json({ message: 'Variation not found' });
    }
    
    res.json(variation);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   POST /api/variations
 * @desc    Create a new variation
 * @access  Admin or users with manage_variations permission
 */
router.post('/', permissionAuth('manage_variations'), async (req, res) => {
  try {
    const { code, description, defaultLaborHours, defaultStages } = req.body;

    // Basic validation
    if (!code || !description || defaultLaborHours === undefined || !defaultStages || !defaultStages.length) {
      return res.status(400).json({ 
        message: 'Code, description, defaultLaborHours, and at least one defaultStage are required' 
      });
    }

    // Check if variation code already exists
    const existingVariation = await Variation.getByCode(req.app.locals.db, code);
    if (existingVariation) {
      return res.status(400).json({ message: 'Variation code already exists' });
    }

    // Validate stages exist
    const stageIds = defaultStages.map(id => new ObjectId(id));
    const stagesCount = await req.app.locals.db.collection('stages').countDocuments({
      _id: { $in: stageIds }
    });

    if (stagesCount !== stageIds.length) {
      return res.status(400).json({ message: 'One or more stages do not exist' });
    }

    // Create variation
    const newVariation = await Variation.create(req.app.locals.db, {
      code,
      description,
      defaultLaborHours,
      defaultStages: stageIds
    });

    res.status(201).json(newVariation);
  } catch (err) {
    if (err.name === 'BSONTypeError') {
      return res.status(400).json({ message: 'Invalid stage ID format' });
    }
    if (err.code === 121) { // MongoDB validation error code
      return res.status(400).json({ 
        message: 'Validation error', 
        details: err.errInfo?.details?.schemaRulesNotSatisfied 
      });
    }
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   PUT /api/variations/:id
 * @desc    Update a variation
 * @access  Admin or users with manage_variations permission
 */
router.put('/:id', permissionAuth('manage_variations'), async (req, res) => {
  try {
    const { code, description, defaultLaborHours, defaultStages } = req.body;

    // Basic validation
    if (!code && !description && defaultLaborHours === undefined && !defaultStages) {
      return res.status(400).json({ message: 'At least one field is required to update' });
    }

    // Check if variation exists
    const variation = await Variation.getById(req.app.locals.db, req.params.id);
    if (!variation) {
      return res.status(404).json({ message: 'Variation not found' });
    }

    // Check if code is being changed and if new code is unique
    if (code && code !== variation.code) {
      const existingVariation = await Variation.getByCode(req.app.locals.db, code);
      if (existingVariation) {
        return res.status(400).json({ message: 'Variation code already exists' });
      }
    }

    // Validate stages exist if provided
    if (defaultStages && defaultStages.length > 0) {
      const stageIds = defaultStages.map(id => new ObjectId(id));
      const stagesCount = await req.app.locals.db.collection('stages').countDocuments({
        _id: { $in: stageIds }
      });

      if (stagesCount !== stageIds.length) {
        return res.status(400).json({ message: 'One or more stages do not exist' });
      }
    }

    // Prepare update data
    const updateData = {};
    if (code) updateData.code = code;
    if (description) updateData.description = description;
    if (defaultLaborHours !== undefined) updateData.defaultLaborHours = defaultLaborHours;
    if (defaultStages) updateData.defaultStages = defaultStages.map(id => new ObjectId(id));

    // Update variation
    const updatedVariation = await Variation.update(req.app.locals.db, req.params.id, updateData);

    res.json(updatedVariation);
  } catch (err) {
    if (err.name === 'BSONTypeError') {
      return res.status(400).json({ message: 'Invalid ID format' });
    }
    if (err.code === 121) { // MongoDB validation error code
      return res.status(400).json({ 
        message: 'Validation error', 
        details: err.errInfo?.details?.schemaRulesNotSatisfied 
      });
    }
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/**
 * @route   DELETE /api/variations/:id
 * @desc    Delete a variation
 * @access  Admin or users with manage_variations permission
 */
router.delete('/:id', permissionAuth('manage_variations'), async (req, res) => {
  try {
    // Check if variation is used in any work orders
    const workOrders = await req.app.locals.db.collection('work_orders').find({
      'service_variations.variation_id': new ObjectId(req.params.id)
    }).toArray();

    if (workOrders.length > 0) {
      return res.status(400).json({
        message: 'Cannot delete variation that is used in work orders',
        workOrders: workOrders.map(wo => ({ _id: wo._id, number: wo.work_order_number }))
      });
    }

    // Delete variation
    const deleted = await Variation.delete(req.app.locals.db, req.params.id);

    if (!deleted) {
      return res.status(404).json({ message: 'Variation not found' });
    }

    res.json({ message: 'Variation deleted successfully' });
  } catch (err) {
    if (err.name === 'BSONTypeError') {
      return res.status(400).json({ message: 'Invalid variation ID format' });
    }
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

module.exports = router;
