# 🧪 Comprehensive S3 Integration Testing Plan

## Prerequisites
1. Ensure these environment variables are set:
   - `S3_BUCKET_NAME`
   - `AWS_ACCESS_KEY_ID`
   - `AWS_SECRET_ACCESS_KEY`
   - `AWS_REGION`
2. Have test files ready: JPG, PNG, PDF, DOC
3. Set up Postman with your API base URL and authentication token

---

## Phase 1: Work Order Tests

### Test 1: Work Order Cancellation Image Upload
```
POST {{base_url}}/api/work-orders/{work_order_id}/parts/cancel
Headers:
- Authorization: Bearer {your_jwt_token}
- Content-Type: multipart/form-data

Body (form-data):
- approvalImage: (file) test-image.jpg
- partName: "Test Part"
- reason: "Testing S3 upload"

Expected Response:
✅ Status 200
✅ Response contains: approvalImageS3Key, approvalImageUrl
✅ File should be in S3 bucket under work-orders/cancellation-approvals/
```

### Test 2: Work Order Error Report Image Upload
```
POST {{base_url}}/api/work-orders/{work_order_id}/parts/{partIndex}/stages/{stageIndex}/error-report
Headers:
- Authorization: Bearer {your_jwt_token}
- Content-Type: multipart/form-data

Body (form-data):
- image: (file) error-screenshot.png
- problematicTechnicianId: {technician_id}
- reportType: "quality_issue"
- issueDescription: "Testing S3 error report upload"

Expected Response:
✅ Status 201
✅ Response contains: imageS3Key, imageUrl
✅ File should be in S3 bucket under work-orders/error-reports/
```

---

## Phase 2: Error Report Direct Tests

### Test 3: Standalone Error Report Upload
```
POST {{base_url}}/api/error-reports/
Headers:
- Authorization: Bearer {your_jwt_token}
- Content-Type: multipart/form-data

Body (form-data):
- image: (file) error-evidence.jpg
- workOrderId: {work_order_id}
- partIndex: 0
- stageIndex: 0
- reportedStageId: {stage_id}
- problematicStageIndex: 0
- problematicTechnicianId: {technician_id}
- reportType: "revert"
- issueDescription: "Testing standalone error report"

Expected Response:
✅ Status 201
✅ Response contains: imageS3Key, imageUrl
✅ File should be in S3 bucket under error-reports/
```

---

## Phase 3: Case Attachment Tests

### Test 4: Case Attachment Upload
```
POST {{base_url}}/api/cases/{case_id}/attachments
Headers:
- Authorization: Bearer {your_jwt_token}
- Content-Type: multipart/form-data

Body (form-data):
- attachment: (file) case-document.pdf

Expected Response:
✅ Status 200
✅ Response contains attachment with: s3Key, s3Url
✅ File should be in S3 bucket under cases/attachments/
```

### Test 5: Case Attachment Retrieval (Redirect)
```
GET {{base_url}}/api/cases/{case_id}/attachments/{filename}
Headers:
- Authorization: Bearer {your_jwt_token}

Expected Response:
✅ Status 302 (Redirect)
✅ Redirects to signed S3 URL
✅ Following redirect should serve the file
```

### Test 6: Case Attachment Retrieval (JSON)
```
GET {{base_url}}/api/cases/{case_id}/attachments/{filename}?redirect=false
Headers:
- Authorization: Bearer {your_jwt_token}

Expected Response:
✅ Status 200
✅ JSON response with signed URL
✅ URL should be accessible and serve the file
```

---

## Phase 4: Expense Receipt Tests

### Test 7: Expense Receipt File Upload
```
POST {{base_url}}/api/expenses/{expense_id}/receipt-images
Headers:
- Authorization: Bearer {your_jwt_token}
- Content-Type: multipart/form-data

Body (form-data):
- receipt: (file) receipt.jpg
- title: "Test Receipt Upload"
- description: "Testing S3 receipt upload"

Expected Response:
✅ Status 200
✅ Updated expense with receipt containing: s3Key, url
✅ File should be in S3 bucket under expenses/receipts/
```

### Test 8: Expense Receipt URL Upload (Backward Compatibility)
```
POST {{base_url}}/api/expenses/{expense_id}/receipt-images
Headers:
- Authorization: Bearer {your_jwt_token}
- Content-Type: application/json

Body (JSON):
{
  "url": "https://example.com/receipt.jpg",
  "title": "External Receipt",
  "description": "Testing URL upload"
}

Expected Response:
✅ Status 200
✅ Receipt added with URL but no s3Key
```

### Test 9: Expense Receipt Viewing (S3 File)
```
GET {{base_url}}/api/expenses/{expense_id}/receipt-images/0/view
Headers:
- Authorization: Bearer {your_jwt_token}

Expected Response:
✅ Status 302 (Redirect) for S3 files
✅ Status 200 (JSON) for URL-based receipts
✅ Signed URL should serve the file
```

### Test 10: Expense Receipt Viewing (JSON Response)
```
GET {{base_url}}/api/expenses/{expense_id}/receipt-images/0/view?redirect=false
Headers:
- Authorization: Bearer {your_jwt_token}

Expected Response:
✅ Status 200
✅ JSON with signed URL for S3 files
✅ JSON with direct URL for URL-based receipts
```

---

## Phase 5: File Validation Tests

### Test 11: Invalid File Type
```
POST {{base_url}}/api/cases/{case_id}/attachments
Headers:
- Authorization: Bearer {your_jwt_token}
- Content-Type: multipart/form-data

Body (form-data):
- attachment: (file) malicious.exe

Expected Response:
✅ Status 400
✅ Error message about invalid file type
✅ No file uploaded to S3
```

### Test 12: Oversized File
```
POST {{base_url}}/api/expenses/{expense_id}/receipt-images
Headers:
- Authorization: Bearer {your_jwt_token}
- Content-Type: multipart/form-data

Body (form-data):
- receipt: (file) large-file.jpg (>10MB for receipts, >25MB for documents)

Expected Response:
✅ Status 400
✅ Error message about file size
✅ No file uploaded to S3
```

---

## Phase 6: Cleanup Tests

### Test 13: Expense Deletion with S3 Cleanup
```
1. First upload receipts to an expense (Test 7)
2. DELETE {{base_url}}/api/expenses/{expense_id}
   Headers:
   - Authorization: Bearer {your_jwt_token}

Expected Response:
✅ Status 200
✅ Expense deleted from database
✅ S3 files deleted (check S3 bucket)
✅ Response includes s3_files_deleted count
```

### Test 14: Case Deletion with S3 Cleanup
```
1. First upload attachments to a case (Test 4)
2. DELETE {{base_url}}/api/cases/{case_id}
   Headers:
   - Authorization: Bearer {your_jwt_token}

Expected Response:
✅ Status 200
✅ Case deleted from database
✅ S3 files deleted (check S3 bucket)
✅ Response includes s3_files_deleted count
```

### Test 15: Individual Receipt Deletion
```
DELETE {{base_url}}/api/expenses/{expense_id}/receipt-images
Headers:
- Authorization: Bearer {your_jwt_token}
- Content-Type: application/json

Body (JSON):
{
  "receiptIndex": 0
}

Expected Response:
✅ Status 200
✅ Receipt removed from expense
✅ S3 file deleted
```

---

## Phase 7: Error Handling Tests

### Test 16: Invalid S3 Configuration
```
Temporarily change S3 bucket name to invalid value and test uploads

Expected Response:
✅ Graceful error handling
✅ No partial uploads
✅ Proper error messages
```

---

## Manual Verification Checklist

After running all tests:

### 1. Check S3 Bucket Structure:
```
your-bucket/
├── work-orders/
│   ├── cancellation-approvals/
│   └── error-reports/
├── error-reports/
├── cases/
│   └── attachments/
└── expenses/
    └── receipts/
```

### 2. Verify Database Records:
- Work orders have S3 keys in cancellation data
- Error reports have imageS3Key fields
- Cases have s3Key in attachments
- Expenses have s3Key in receipt_images

### 3. Test Signed URL Expiration:
- URLs should expire after 1 hour
- Expired URLs should return access denied

---

## Quick Test Commands Summary

For quick reference, here are the main endpoints to test:

| Endpoint | Method | Purpose | File Field |
|----------|--------|---------|------------|
| `/api/work-orders/{id}/parts/cancel` | POST | Cancellation approval | `approvalImage` |
| `/api/work-orders/{id}/parts/{partIndex}/stages/{stageIndex}/error-report` | POST | Error report | `image` |
| `/api/error-reports/` | POST | Standalone error report | `image` |
| `/api/cases/{id}/attachments` | POST | Case attachment | `attachment` |
| `/api/cases/{id}/attachments/{filename}` | GET | Retrieve attachment | N/A |
| `/api/expenses/{id}/receipt-images` | POST | Receipt upload | `receipt` |
| `/api/expenses/{id}/receipt-images/{index}/view` | GET | View receipt | N/A |

---

## Test Results Template

Use this template to track your testing:

```
[ ] Test 1: Work Order Cancellation Image Upload
[ ] Test 2: Work Order Error Report Image Upload
[ ] Test 3: Standalone Error Report Upload
[ ] Test 4: Case Attachment Upload
[ ] Test 5: Case Attachment Retrieval (Redirect)
[ ] Test 6: Case Attachment Retrieval (JSON)
[ ] Test 7: Expense Receipt File Upload
[ ] Test 8: Expense Receipt URL Upload
[ ] Test 9: Expense Receipt Viewing (S3 File)
[ ] Test 10: Expense Receipt Viewing (JSON Response)
[ ] Test 11: Invalid File Type
[ ] Test 12: Oversized File
[ ] Test 13: Expense Deletion with S3 Cleanup
[ ] Test 14: Case Deletion with S3 Cleanup
[ ] Test 15: Individual Receipt Deletion
[ ] Test 16: Invalid S3 Configuration
```

---

## Troubleshooting Common Issues

1. **403 Forbidden on S3**: Check AWS credentials and bucket permissions
2. **File not found in S3**: Verify bucket name and region in environment variables
3. **Signed URL not working**: Check if files are private and ACL is set correctly
4. **Upload timeout**: Check file size limits and network connection
5. **Database missing S3 keys**: Verify the upload was successful before database save

This comprehensive testing plan will ensure your S3 integration is 100% functional!