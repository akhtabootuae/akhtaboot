# Branch API Documentation

This document provides details about the Branch API endpoints for managing branches in the system.

## Base URL

```
/api/branches
```

## Authentication

All endpoints require authentication using JWT token.

Include the token in the Authorization header:

```
Authorization: Bearer <token>
```

## Branch Object

```json
{
  "_id": "60d21b5b8a8d6f001f3c2c7e",
  "branch_name": "Main Branch",
  "branch_code": "HQ",
  "location": "123 Main Street, Headquarters",
  "created_at": "2023-07-01T00:00:00.000Z",
  "updated_at": "2023-07-01T00:00:00.000Z"
}
```

## Endpoints

### Get All Branches

Retrieves all branches in the system.

- **URL:** `/api/branches`
- **Method:** `GET`
- **Auth required:** Yes
- **Permissions required:** None (Available to all authenticated users)

#### Success Response

- **Code:** 200
- **Content Example:**
  ```json
  [
    {
      "_id": "60d21b5b8a8d6f001f3c2c7e",
      "branch_name": "Main Branch",
      "branch_code": "HQ",
      "location": "123 Main Street, Headquarters",
      "created_at": "2023-07-01T00:00:00.000Z",
      "updated_at": "2023-07-01T00:00:00.000Z"
    },
    {
      "_id": "60d21b5b8a8d6f001f3c2c7f",
      "branch_name": "North Branch",
      "branch_code": "NB",
      "location": "456 North Avenue, North District",
      "created_at": "2023-07-01T00:00:00.000Z",
      "updated_at": "2023-07-01T00:00:00.000Z"
    }
  ]
  ```

### Get Branch by ID

Retrieves a specific branch by its ID.

- **URL:** `/api/branches/:id`
- **Method:** `GET`
- **URL Parameters:** `id=[MongoDB ObjectId]`
- **Auth required:** Yes
- **Permissions required:** None (Available to all authenticated users)

#### Success Response

- **Code:** 200
- **Content Example:**
  ```json
  {
    "_id": "60d21b5b8a8d6f001f3c2c7e",
    "branch_name": "Main Branch",
    "branch_code": "HQ",
    "location": "123 Main Street, Headquarters",
    "created_at": "2023-07-01T00:00:00.000Z",
    "updated_at": "2023-07-01T00:00:00.000Z"
  }
  ```

#### Error Response

- **Code:** 404
- **Content:** `{ "message": "Branch not found" }`

### Create a New Branch

Creates a new branch in the system.

- **URL:** `/api/branches`
- **Method:** `POST`
- **Auth required:** Yes
- **Permissions required:** Admin only
- **Request Body:**
  ```json
  {
    "branch_name": "West Branch",
    "branch_code": "WB",
    "location": "789 West Boulevard, West District" 
  }
  ```
- **Required fields:** `branch_name`, `branch_code`

#### Success Response

- **Code:** 201
- **Content Example:**
  ```json
  {
    "_id": "60d21b5b8a8d6f001f3c2c80",
    "branch_name": "West Branch",
    "branch_code": "WB",
    "location": "789 West Boulevard, West District",
    "created_at": "2023-07-02T00:00:00.000Z",
    "updated_at": "2023-07-02T00:00:00.000Z"
  }
  ```

#### Error Response

- **Code:** 400
- **Content:** `{ "message": "Branch name and code are required" }`
  
  OR

- **Code:** 400
- **Content:** `{ "message": "A branch with this code already exists" }`


### Update a Branch

Updates an existing branch.

- **URL:** `/api/branches/:id`
- **Method:** `PUT`
- **URL Parameters:** `id=[MongoDB ObjectId]`
- **Auth required:** Yes
- **Permissions required:** Admin only
- **Request Body:**
  ```json
  {
    "branch_name": "Updated Branch Name",
    "branch_code": "UB",
    "location": "Updated Address"
  }
  ```
- **Required fields:** At least one field to update

#### Success Response

- **Code:** 200
- **Content Example:**
  ```json
  {
    "_id": "60d21b5b8a8d6f001f3c2c7e",
    "branch_name": "Updated Branch Name",
    "branch_code": "UB",
    "location": "Updated Address",
    "created_at": "2023-07-01T00:00:00.000Z",
    "updated_at": "2023-07-03T00:00:00.000Z"
  }
  ```

#### Error Response

- **Code:** 400
- **Content:** `{ "message": "Please provide at least one field to update" }`
  
  OR

- **Code:** 404
- **Content:** `{ "message": "Branch not found" }`

  OR

- **Code:** 400
- **Content:** `{ "message": "A branch with this code already exists" }`


### Delete a Branch

Deletes a branch from the system.

- **URL:** `/api/branches/:id`
- **Method:** `DELETE`
- **URL Parameters:** `id=[MongoDB ObjectId]`
- **Auth required:** Yes
- **Permissions required:** Admin only

#### Success Response

- **Code:** 200
- **Content Example:**
  ```json
  { "message": "Branch deleted successfully" }
  ```

#### Error Response

- **Code:** 404
- **Content:** `{ "message": "Branch not found" }`
  
  OR

- **Code:** 400
- **Content:** `{ "message": "Cannot delete branch that has users assigned to it", "usersCount": 5 }`


### Get Users by Branch

Retrieves all users assigned to a specific branch.

- **URL:** `/api/branches/:id/users`
- **Method:** `GET`
- **URL Parameters:** `id=[MongoDB ObjectId]`
- **Auth required:** Yes
- **Permissions required:** Admin or `view_all_users` permission

#### Success Response

- **Code:** 200
- **Content Example:**
  ```json
  [
    {
      "_id": "60d21b5b8a8d6f001f3c2c81",
      "first_name": "John",
      "last_name": "Doe",
      "email": "john.doe@example.com",
      "branch": {
        "branch_id": "60d21b5b8a8d6f001f3c2c7e",
        "branch_name": "Main Branch",
        "branch_code": "HQ",
        "location": "123 Main Street, Headquarters"
      },
      "role_name": "Technician",
      "is_active": true
    },
    {
      "_id": "60d21b5b8a8d6f001f3c2c82",
      "first_name": "Jane",
      "last_name": "Smith",
      "email": "jane.smith@example.com",
      "branch": {
        "branch_id": "60d21b5b8a8d6f001f3c2c7e",
        "branch_name": "Main Branch",
        "branch_code": "HQ",
        "location": "123 Main Street, Headquarters"
      },
      "role_name": "Supervisor",
      "is_active": true
    }
  ]
  ```

#### Error Response

- **Code:** 404
- **Content:** `{ "message": "Branch not found" }`

## Error Handling

All endpoints may return these errors:

- **Code:** 401
- **Content:** `{ "message": "Authorization header missing or invalid" }`
  
  OR

- **Code:** 403
- **Content:** `{ "message": "Admin access required" }`
  
  OR

- **Code:** 500
- **Content:** `{ "message": "Server error" }`
