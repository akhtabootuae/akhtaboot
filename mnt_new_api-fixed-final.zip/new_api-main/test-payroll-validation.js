const { MongoClient, ObjectId } = require('mongodb');

// MongoDB connection URL
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/your_database_name';

async function testPayrollValidation() {
  let client;
  
  try {
    // Connect to MongoDB
    client = await MongoClient.connect(MONGO_URI);
    const db = client.db();
    
    console.log('Testing payroll audit log validation...\n');
    
    // Test 1: Valid audit entry
    console.log('Test 1: Creating valid audit entry');
    try {
      const validEntry = {
        user_id: new ObjectId(),
        user_email: 'test@example.com',
        action: 'update_rate',
        entity_type: 'payroll_rate',
        entity_id: new ObjectId().toString(),
        timestamp: new Date(),
        ip_address: '127.0.0.1',
        user_agent: 'Test Agent',
        details: {
          request_method: 'PUT',
          endpoint: '/api/payroll/employees/123/rate',
          success: true
        },
        severity: 'low',
        category: 'data_modification'
      };
      
      const result = await db.collection('payroll_audit_log').insertOne(validEntry);
      console.log('✓ Valid entry created successfully:', result.insertedId);
    } catch (error) {
      console.error('✗ Failed to create valid entry:', error.message);
    }
    
    // Test 2: Invalid entry (missing required fields)
    console.log('\nTest 2: Attempting to create invalid entry (missing user_id)');
    try {
      const invalidEntry = {
        // user_id is missing - this should fail
        action: 'update_rate',
        entity_type: 'payroll_rate',
        timestamp: new Date()
      };
      
      await db.collection('payroll_audit_log').insertOne(invalidEntry);
      console.log('✗ Invalid entry was created (this should not happen)');
    } catch (error) {
      console.log('✓ Invalid entry rejected correctly:', error.message);
    }
    
    // Test 3: Invalid action value
    console.log('\nTest 3: Attempting to create entry with invalid action');
    try {
      const invalidActionEntry = {
        user_id: new ObjectId(),
        action: 'invalid_action', // This should fail
        entity_type: 'payroll_rate',
        timestamp: new Date()
      };
      
      await db.collection('payroll_audit_log').insertOne(invalidActionEntry);
      console.log('✗ Entry with invalid action was created (this should not happen)');
    } catch (error) {
      console.log('✓ Entry with invalid action rejected correctly:', error.message);
    }
    
    // Test 4: Check collection validation
    console.log('\nTest 4: Checking collection validation rules');
    const collections = await db.listCollections({ name: 'payroll_audit_log' }).toArray();
    if (collections.length > 0) {
      const collectionInfo = await db.command({ 
        listCollections: 1, 
        filter: { name: 'payroll_audit_log' } 
      });
      
      const validation = collectionInfo.cursor.firstBatch[0].options?.validator;
      if (validation) {
        console.log('✓ Collection has validation rules');
        console.log('Required fields:', validation.$jsonSchema?.required);
      } else {
        console.log('✗ Collection does not have validation rules');
      }
    }
    
  } catch (error) {
    console.error('Test error:', error);
  } finally {
    if (client) {
      await client.close();
    }
  }
}

// Run the test
testPayrollValidation().catch(console.error);