# Logo Instructions

Place your logo image file here as `logo.png`.

The logo should be:
- High-quality and clear
- Ideally with transparent background
- Sized properly (recommended dimension: at least 300x300px)

This logo will be used in the PDF invoice generation process.
