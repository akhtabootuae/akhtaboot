/**
 * Debug script to check user permissions and identify 403 issues
 */

const jwt = require('jsonwebtoken');

/**
 * Debug function to analyze a JWT token and check permissions
 * @param {string} token - JWT token from Authorization header
 */
function debugUserPermissions(token) {
  try {
    // Remove 'Bearer ' prefix if present
    const cleanToken = token.startsWith('Bearer ') ? token.substring(7) : token;
    
    // Decode the token (you'll need to replace with your actual JWT secret)
    const decoded = jwt.decode(cleanToken);
    
    console.log('🔍 Token Debug Information:');
    console.log('===========================');
    console.log('User ID:', decoded?.userId || decoded?.id);
    console.log('Email:', decoded?.email);
    console.log('Role:', decoded?.role);
    console.log('Role Name:', decoded?.role_name);
    console.log('Has Permissions Array:', Array.isArray(decoded?.permissions));
    console.log('Permissions Count:', decoded?.permissions?.length || 0);
    
    if (decoded?.permissions) {
      console.log('\n📋 User Permissions:');
      console.log('====================');
      
      // Filter for case-related permissions
      const casePermissions = decoded.permissions.filter(p => 
        p.permission_name?.includes('case') && p.granted === true
      );
      
      console.log('\n✅ Granted Case Permissions:');
      casePermissions.forEach(p => {
        console.log(`  • ${p.permission_name} - ${p.permission_description}`);
      });
      
      // Check specific permissions needed for case routes
      const requiredPermissions = [
        'create_case',
        'view_all_cases', 
        'view_case',
        'update_case',
        'delete_case',
        'resolve_case',
        'view_case_stats',
        'add_case_notes',
        'manage_case_attachments'
      ];
      
      console.log('\n🔍 Required Permission Check:');
      requiredPermissions.forEach(reqPerm => {
        const hasPermission = decoded.permissions.some(p => 
          p.permission_name === reqPerm && p.granted === true
        );
        const status = hasPermission ? '✅' : '❌';
        console.log(`  ${status} ${reqPerm}`);
      });
      
      // Check role-based access
      console.log('\n👤 Role-Based Access:');
      console.log(`  Admin Access: ${decoded?.role === 'Admin' || decoded?.role_name === 'Admin' ? '✅' : '❌'}`);
      console.log(`  Supervisor Access: ${decoded?.role === 'Supervisor' || decoded?.role_name === 'Supervisor' ? '✅' : '❌'}`);
    }
    
    return decoded;
  } catch (error) {
    console.error('❌ Error decoding token:', error.message);
    return null;
  }
}

/**
 * Express middleware to debug permission issues
 */
function debugPermissionMiddleware(req, res, next) {
  console.log('\n🚨 DEBUG: Permission Check');
  console.log('Route:', req.method, req.originalUrl);
  console.log('User Role:', req.user?.role);
  console.log('User Role Name:', req.user?.role_name);
  console.log('User ID:', req.user?._id);
  console.log('Has Permissions:', Array.isArray(req.user?.permissions));
  console.log('Permissions Count:', req.user?.permissions?.length || 0);
  
  if (req.user?.permissions) {
    const grantedPermissions = req.user.permissions
      .filter(p => p.granted === true)
      .map(p => p.permission_name);
    console.log('Granted Permissions:', grantedPermissions.slice(0, 5) + (grantedPermissions.length > 5 ? '...' : ''));
  }
  
  next();
}

/**
 * Check if user has specific permission
 */
function checkUserPermission(user, permissionName) {
  if (!user) return false;
  
  // Admin always has access
  if (user.role === 'Admin' || user.role_name === 'Admin') {
    return true;
  }
  
  // Check permissions array
  if (user.permissions && Array.isArray(user.permissions)) {
    return user.permissions.some(p => 
      p.permission_name === permissionName && p.granted === true
    );
  }
  
  return false;
}

// If running this file directly, allow manual testing
if (require.main === module) {
  const token = process.argv[2];
  if (token) {
    debugUserPermissions(token);
  } else {
    console.log('Usage: node debug-permissions.js <your-jwt-token>');
    console.log('Example: node debug-permissions.js eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...');
  }
}

module.exports = {
  debugUserPermissions,
  debugPermissionMiddleware,
  checkUserPermission
};
