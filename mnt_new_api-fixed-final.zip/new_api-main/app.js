require('dotenv').config();

const express = require('express');
const crypto = require('crypto');
const http = require('http');
const mongoose = require('mongoose');
const { initializeDatabase } = require('./models');
const { seedDatabase } = require('./config/dbSeeder');
const cors = require('cors');
const websocketService = require('./services/websocket');

// ===== SECURITY: Validate JWT_SECRET at startup =====
if (!process.env.JWT_SECRET || process.env.JWT_SECRET === 'replace_this_with_a_secure_string') {
  if (process.env.NODE_ENV === 'production') {
    console.error('FATAL: JWT_SECRET must be set in production environment!');
    process.exit(1);
  }
  // Generate a random secret for development only
  process.env.JWT_SECRET = crypto.randomBytes(64).toString('hex');
  console.warn('WARNING: JWT_SECRET not set. Generated random secret for development. Set JWT_SECRET in .env for production.');
}

// Routes
const userRoutes = require('./routes/userRoutes');
const customerRoutes = require('./routes/customerRoutes');
const customerReviewRoutes = require('./routes/customerReviewRoutes');
const roleRoutes = require('./routes/roleRoutes');
const userRoleRoutes = require('./routes/userRoleRoutes');
const branchRoutes = require('./routes/branchRoutes');
const invoiceRoutes = require('./routes/invoiceRoutes');
const workOrderRoutes = require('./routes/workOrderRoutes');
const stageRoutes = require('./routes/stageRoutes');
const variationRoutes = require('./routes/variationRoutes');
const errorReportRoutes = require('./routes/errorReportRoutes');
const notificationRoutes = require('./routes/notificationRoutes');
const caseRoutes = require('./routes/caseRoutes');
const payrollRoutes = require('./routes/payrollRoutes');
const expenseRoutes = require('./routes/expenseRoutes');
const financeRoutes = require('./routes/financeRoutes');
const workOrderQARoutes = require('./routes/workOrderQARoutes');
const messagingRoutes = require('./routes/messagingRoutes');
const qcApprovalRoutes = require('./routes/qcApprovalRoutes');
const carPartRoutes = require('./routes/carPartRoutes');


// Initialize express
const app = express();
const server = http.createServer(app);

// ===== SECURITY: Request body size limit =====
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: false, limit: '10mb' }));

// ===== SECURITY: Security headers =====
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.removeHeader('X-Powered-By');
  next();
});

// CORS config
const allowedOrigins = process.env.ALLOW_ORIGINS
  ? process.env.ALLOW_ORIGINS.split(',').map(origin => origin.trim())
  : ['http://localhost:3001'];

app.use(cors({
  origin: allowedOrigins,
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// ===== SECURITY: Simple rate limiting =====
const requestCounts = new Map();
const RATE_LIMIT_WINDOW = 60000; // 1 minute
const RATE_LIMIT_MAX = 200; // max requests per window

app.use((req, res, next) => {
  const ip = req.ip || req.connection?.remoteAddress || 'unknown';
  const now = Date.now();

  if (!requestCounts.has(ip)) {
    requestCounts.set(ip, { count: 1, startTime: now });
    return next();
  }

  const record = requestCounts.get(ip);
  if (now - record.startTime > RATE_LIMIT_WINDOW) {
    record.count = 1;
    record.startTime = now;
    return next();
  }

  record.count++;
  if (record.count > RATE_LIMIT_MAX) {
    return res.status(429).json({ message: 'Too many requests. Please try again later.' });
  }

  next();
});

// Clean up rate limit map periodically
setInterval(() => {
  const now = Date.now();
  for (const [ip, record] of requestCounts) {
    if (now - record.startTime > RATE_LIMIT_WINDOW * 2) {
      requestCounts.delete(ip);
    }
  }
}, RATE_LIMIT_WINDOW * 5);

// MongoDB Connection
const connectDB = async () => {
  try {
    if (!process.env.MONGO_URI) {
      console.error('FATAL: MONGO_URI environment variable is not set');
      process.exit(1);
    }

    await mongoose.connect(process.env.MONGO_URI, {
      serverSelectionTimeoutMS: 5000,
      socketTimeoutMS: 45000
    });

    console.log('MongoDB connected');

    const db = mongoose.connection.db;
    app.locals.db = db;

    // Initialize database collections and validation
    await initializeDatabase(db);

    // Seed database with initial data including admin user
    await seedDatabase(db);

    return db;
  } catch (error) {
    console.error('MongoDB connection error:', error.message);
    process.exit(1);
  }
};

// Connect to database before starting server
connectDB().then((db) => {
  // Initialize models with database connection
  const models = require('./models');
  const modelInstances = {};

  // Initialize each model with database connection
  Object.keys(models).forEach(modelName => {
    if (modelName !== 'initializeDatabase' && typeof models[modelName] === 'function') {
      try {
        modelInstances[modelName] = new models[modelName](db);
      } catch (err) {
        console.error(`Failed to initialize model ${modelName}:`, err.message);
      }
    }
  });

  // Make models available to routes
  app.locals.models = modelInstances;

  // Initialize WebSocket service
  websocketService.initialize(server);
  app.locals.websocket = websocketService;

  // Routes - FIX: userRoleRoutes now has its own path to avoid conflict
  app.use('/api/users', userRoutes);
  app.use('/api/user-roles', userRoleRoutes);
  app.use('/api/customers', customerRoutes);
  app.use('/api/customer-reviews', customerReviewRoutes);
  app.use('/api/roles', roleRoutes);
  app.use('/api/branches', branchRoutes);
  app.use('/api/invoices', invoiceRoutes);
  app.use('/api/work-orders', workOrderRoutes);
  app.use('/api/stages', stageRoutes);
  app.use('/api/variations', variationRoutes);
  app.use('/api/error-reports', errorReportRoutes);
  app.use('/api/notifications', notificationRoutes);
  app.use('/api/cases', caseRoutes);
  app.use('/api/payroll', payrollRoutes);
  app.use('/api/expenses', expenseRoutes);
  app.use('/api/finance', financeRoutes);
  app.use('/api/workorder-qa', workOrderQARoutes);
  app.use('/api/messaging', messagingRoutes);
  app.use('/api', qcApprovalRoutes);
  app.use('/api/car-parts', carPartRoutes);

  // ===== JSON parse error handler =====
  app.use((err, req, res, next) => {
    if (err.type === 'entity.parse.failed') {
      return res.status(400).json({ message: 'Invalid JSON in request body' });
    }
    next(err);
  });

  // Error handling middleware
  app.use((err, req, res, next) => {
    console.error('Server Error:', err.message);

    // Don't leak error details in production
    const errorResponse = {
      message: 'Server Error',
      ...(process.env.NODE_ENV !== 'production' && { error: err.message })
    };

    res.status(err.status || 500).json(errorResponse);
  });

  // Create TTL index for conversations
  if (app.locals && app.locals.db) {
    app.locals.db.collection('conversations').createIndex(
      { expiresAt: 1 },
      { expireAfterSeconds: 0 }
    ).then(() => {
      console.log('TTL index on expiresAt ensured.');
    }).catch(err => {
      console.error('Error ensuring TTL index on expiresAt:', err.message);
    });
  }

  // Start server
  const PORT = process.env.PORT || 3000;
  server.listen(PORT, () => console.log(`Server running on port ${PORT} in ${process.env.NODE_ENV || 'development'} mode`));
}).catch(err => {
  console.error('Failed to start server:', err.message);
  process.exit(1);
});

// ===== Graceful shutdown =====
const gracefulShutdown = async (signal) => {
  console.log(`\n${signal} received. Starting graceful shutdown...`);

  server.close(() => {
    console.log('HTTP server closed.');
  });

  try {
    await mongoose.connection.close();
    console.log('MongoDB connection closed.');
  } catch (err) {
    console.error('Error closing MongoDB connection:', err.message);
  }

  process.exit(0);
};

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Handle unhandled promise rejections
process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Promise Rejection:', reason);
});

module.exports = app;
