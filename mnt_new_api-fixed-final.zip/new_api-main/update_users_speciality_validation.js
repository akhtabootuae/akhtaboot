const { MongoClient } = require('mongodb');
require('dotenv').config();

async function updateUsersSpecialityValidation() {
  const client = new MongoClient(process.env.MONGODB_URI);
  
  try {
    console.log('Connecting to MongoDB...');
    await client.connect();
    const db = client.db(process.env.MONGODB_DB);
    
    console.log('Updating users collection validation...');
    
    // Update the collection validator
    await db.command({
      collMod: 'users',
      validator: {
        $jsonSchema: {
          bsonType: 'object',
          required: [
            'first_name',
            'last_name',
            'email',
            'password_hash',
            'role_id',
            'role_name',
            'created_at',
            'updated_at'
          ],
          properties: {
            first_name: { bsonType: 'string' },
            last_name: { bsonType: 'string' },
            email: { 
              bsonType: 'string',
              description: 'must be a string and is required'
            },
            phone: { bsonType: 'string' },
            password_hash: { bsonType: 'string' },
            is_active: {
              bsonType: 'bool',
              description: 'active flag'
            },
            staff_code: { bsonType: 'string' },
            speciality: {
              bsonType: 'string',
              enum: ['PDR', 'Fix/Remove', 'Paint', 'Body Work', 'Mechanical', 'Electrical', 'General', 'Denter', 'Polish', 'PDR & Paint Supervision', 'System Administration', 'Supervision', 'Management', 'Other'],
              description: 'Technician specialty - only applicable for technician roles'
            },
            branch: {
              bsonType: 'object',
              required: ['branch_id', 'branch_name'],
              properties: {
                branch_id: { bsonType: 'objectId' },
                branch_name: { bsonType: 'string' },
                branch_code: { bsonType: 'string' },
                location: { bsonType: 'string' }
              }
            },
            role_id: { bsonType: 'objectId' },
            role_name: { bsonType: 'string' },
            role_description: { bsonType: 'string' },
            permissions: {
              bsonType: 'array',
              items: {
                bsonType: 'object',
                required: ['permission_id', 'permission_name', 'granted'],
                properties: {
                  permission_id: { bsonType: 'string' },
                  permission_name: { bsonType: 'string' },
                  permission_description: { bsonType: 'string' },
                  category: { bsonType: 'string' },
                  granted: { bsonType: 'bool' }
                }
              }
            },
            permission_logs: {
              bsonType: 'array',
              items: {
                bsonType: 'object',
                required: [
                  'log_id',
                  'target_type',
                  'target_id',
                  'permission_id',
                  'action',
                  'created_at'
                ],
                properties: {
                  log_id: { bsonType: 'string' },
                  target_type: { enum: ['user', 'role'] },
                  target_id: { bsonType: 'objectId' },
                  permission_id: { bsonType: 'string' },
                  action: { enum: ['grant', 'revoke'] },
                  created_at: { bsonType: 'date' },
                  details: { bsonType: 'string' }
                }
              }
            },
            created_at: { bsonType: 'date' },
            updated_at: { bsonType: 'date' }
          }
        }
      },
      validationLevel: 'moderate',
      validationAction: 'warn'
    });
    
    console.log('✓ Users collection validation updated successfully');
    
    // Get all users with Technician role and ensure they have a valid specialty
    const technicianRole = await db.collection('roles').findOne({ role_name: 'Technician' });
    
    if (technicianRole) {
      const technicians = await db.collection('users').find({ 
        role_id: technicianRole._id,
        $or: [
          { speciality: { $exists: false } },
          { speciality: '' },
          { speciality: null }
        ]
      }).toArray();
      
      if (technicians.length > 0) {
        console.log(`Found ${technicians.length} technicians without specialty. Setting to 'General'...`);
        
        const result = await db.collection('users').updateMany(
          { 
            role_id: technicianRole._id,
            $or: [
              { speciality: { $exists: false } },
              { speciality: '' },
              { speciality: null }
            ]
          },
          { 
            $set: { 
              speciality: 'General',
              updated_at: new Date()
            }
          }
        );
        
        console.log(`✓ Updated ${result.modifiedCount} technicians with default specialty`);
      } else {
        console.log('✓ All technicians have valid specialties');
      }
    }
    
    // Verify the validation is working
    const collections = await db.listCollections({ name: 'users' }).toArray();
    const usersCollection = collections[0];
    console.log('\nValidation info:', JSON.stringify(usersCollection.options.validator, null, 2));
    
  } catch (error) {
    console.error('Error updating validation:', error);
    throw error;
  } finally {
    await client.close();
  }
}

// Run the update
updateUsersSpecialityValidation()
  .then(() => {
    console.log('\n✅ Users collection validation updated successfully!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('\n❌ Failed to update validation:', error);
    process.exit(1);
  });