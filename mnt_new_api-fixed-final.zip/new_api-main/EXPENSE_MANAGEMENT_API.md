# Expense Management API Documentation

## Overview

The Expense Management system provides comprehensive functionality for creating, managing, and tracking business expenses. This API supports expense creation, approval workflows, receipt management, and analytics.

## Table of Contents

1. [Authentication](#authentication)
2. [Field Mapping](#field-mapping)
3. [API Endpoints](#api-endpoints)
4. [Data Models](#data-models)
5. [Frontend Integration Guide](#frontend-integration-guide)
6. [Error Handling](#error-handling)
7. [Examples](#examples)

## Authentication

All expense endpoints require authentication using a Bearer token. Include the token in the Authorization header:

```
Authorization: Bearer <your-token-here>
```

### Login Endpoint
```http
POST /api/users/login
Content-Type: application/json

{
  "email": "admin@example.com",
  "password": "admin123!"
}
```

## Field Mapping

**IMPORTANT**: The frontend should use user-friendly field names, but the API automatically maps them to the database schema:

| Frontend Field | API Field | Database Field | Description |
|----------------|-----------|----------------|-------------|
| `description` | `description` | `title` | Expense description/title |
| `category` | `category` | `expense_type` | Type of expense |
| `amount` | `amount` | `amount` | Expense amount |
| `date` | `date` | `date` | Expense date |
| `vendor` | `vendor` | `vendor` | Vendor name |
| `invoice_number` | `invoice_number` | `invoice_number` | Invoice reference |
| `payment_method` | `payment_method` | `payment_method` | Payment method |
| `notes` | `notes` | `notes` | Additional notes |
| `tags` | `tags` | `tags` | Array of tags |

### Auto-Generated Fields

The API automatically generates these fields:
- `expense_number`: Format `EXP-XXXXXXX` (7-digit random number)
- `branch_id`: Extracted from authenticated user's branch
- `user_id`: Extracted from authenticated user
- `status`: Defaults to `"draft"`
- `approval_status`: Defaults to `"pending"`
- `created_at`: Current timestamp
- `updated_at`: Current timestamp

## API Endpoints

### 1. Create Expense

```http
POST /api/expenses
Authorization: Bearer <token>
Content-Type: application/json
```

**Request Body (Frontend Format):**
```json
{
  "description": "Office Supplies Purchase",
  "amount": 150.75,
  "category": "office_supplies",
  "date": "2025-06-09T13:00:00.000Z",
  "vendor": "Office Depot",
  "invoice_number": "INV-2025-001",
  "payment_method": "card",
  "tags": ["office", "supplies", "stationery"],
  "notes": "Monthly office supplies replenishment"
}
```

**Response (201 Created):**
```json
{
  "_id": "674f8a1b2c3d4e5f6a7b8c9d",
  "expense_number": "EXP-1234567",
  "title": "Office Supplies Purchase",
  "description": "Office Supplies Purchase",
  "amount": 150.75,
  "expense_type": "office_supplies",
  "date": "2025-06-09T13:00:00.000Z",
  "vendor": "Office Depot",
  "invoice_number": "INV-2025-001",
  "payment_method": "card",
  "status": "draft",
  "approval_status": "pending",
  "branch_id": "68460d027a461fb930412fdc",
  "user_id": "68460d027a461fb930412fdd",
  "tags": ["office", "supplies", "stationery"],
  "notes": "Monthly office supplies replenishment",
  "receipt_images": [],
  "created_at": "2025-06-09T13:00:00.000Z",
  "updated_at": "2025-06-09T13:00:00.000Z"
}
```

### 2. Get All Expenses

```http
GET /api/expenses
Authorization: Bearer <token>
```

**Query Parameters:**
- `branch_id`: Filter by branch ID
- `expense_type`: Filter by expense type
- `status`: Filter by status
- `approval_status`: Filter by approval status
- `date_from`: Filter from date (YYYY-MM-DD)
- `date_to`: Filter to date (YYYY-MM-DD)
- `vendor`: Filter by vendor name
- `search`: Search in titles and descriptions
- `page`: Page number (default: 1)
- `limit`: Items per page (default: 10)

**Example:**
```http
GET /api/expenses?expense_type=office_supplies&status=draft&date_from=2025-01-01&date_to=2025-12-31
```

### 3. Get My Expenses

```http
GET /api/expenses/my
Authorization: Bearer <token>
```

Returns expenses created by the authenticated user.

### 4. Get Expense by ID

```http
GET /api/expenses/:id
Authorization: Bearer <token>
```

### 5. Update Expense

```http
PUT /api/expenses/:id
Authorization: Bearer <token>
Content-Type: application/json
```

**Request Body:**
```json
{
  "title": "Updated Office Supplies Purchase",
  "description": "Updated purchase of stationery and office materials",
  "amount": 175.50,
  "expense_type": "office_supplies",
  "vendor": "Staples",
  "notes": "Updated monthly office supplies replenishment with additional items"
}
```

### 6. Delete Expense

```http
DELETE /api/expenses/:id
Authorization: Bearer <token>
```

### 7. Expense Statistics

```http
GET /api/expenses/statistics
Authorization: Bearer <token>
```

**Query Parameters:**
- `branch_id`: Filter by branch
- `date_from`: Start date
- `date_to`: End date

**Response:**
```json
{
  "total_expenses": 15,
  "total_amount": 12500.75,
  "by_status": {
    "draft": 5,
    "submitted": 4,
    "approved": 4,
    "paid": 2
  },
  "by_approval_status": {
    "pending": 8,
    "approved": 5,
    "rejected": 2
  },
  "average_amount": 833.38
}
```

### 8. Expenses by Type

```http
GET /api/expenses/by-type
Authorization: Bearer <token>
```

Returns expense breakdown by category/type.

### 9. Approval Management

#### Get Pending Approvals
```http
GET /api/expenses/pending-approval
Authorization: Bearer <token>
```

#### Approve/Reject Expense
```http
PUT /api/expenses/:id/approval
Authorization: Bearer <token>
Content-Type: application/json
```

**Approve:**
```json
{
  "approval_status": "approved",
  "approval_notes": "Expense approved - valid business expense"
}
```

**Reject:**
```json
{
  "approval_status": "rejected",
  "approval_notes": "Expense rejected - insufficient documentation"
}
```

### 10. Receipt Management

#### Add Receipt Image
```http
POST /api/expenses/:id/receipt-images
Authorization: Bearer <token>
Content-Type: application/json
```

```json
{
  "url": "https://example.com/receipts/receipt-001.jpg",
  "title": "Office Supplies Receipt",
  "description": "Receipt for office supplies purchase"
}
```

#### Remove Receipt Image
```http
DELETE /api/expenses/:id/receipt-images
Authorization: Bearer <token>
Content-Type: application/json
```

```json
{
  "url": "https://example.com/receipts/receipt-001.jpg"
}
```

## Data Models

### Expense Schema

```typescript
interface Expense {
  _id: string;
  expense_number: string;          // Auto-generated: EXP-XXXXXXX
  title: string;                   // Mapped from frontend 'description'
  description?: string;
  amount: number;
  expense_type: ExpenseType;       // Mapped from frontend 'category'
  date: Date;
  vendor?: string;
  invoice_number?: string;
  payment_method?: PaymentMethod;
  status: ExpenseStatus;
  approval_status: ApprovalStatus;
  branch_id: string;               // Auto-extracted from user
  user_id: string;                 // Auto-extracted from auth
  tags?: string[];
  notes?: string;
  receipt_images?: ReceiptImage[];
  approval_notes?: string;
  approved_by?: string;
  approved_at?: Date;
  created_at: Date;
  updated_at: Date;
}
```

### Enums

#### Expense Types
```typescript
type ExpenseType = 
  | "office_supplies"
  | "equipment"
  | "utilities"
  | "rent"
  | "maintenance"
  | "fuel"
  | "travel"
  | "meals"
  | "marketing"
  | "insurance"
  | "professional_services"
  | "software_licenses"
  | "telecommunications"
  | "training"
  | "repairs"
  | "inventory"
  | "miscellaneous";
```

#### Status Values
```typescript
type ExpenseStatus = "draft" | "submitted" | "approved" | "rejected" | "paid";
type ApprovalStatus = "pending" | "approved" | "rejected";
type PaymentMethod = "cash" | "card" | "bank_transfer" | "check" | "other";
```

## Frontend Integration Guide

### 1. Expense Creation Form

Create a form with these fields:

```typescript
interface ExpenseFormData {
  description: string;          // Maps to title in DB
  amount: number;
  category: ExpenseType;        // Maps to expense_type in DB
  date: Date;
  vendor?: string;
  invoice_number?: string;
  payment_method?: PaymentMethod;
  tags?: string[];
  notes?: string;
}
```

### 2. API Service Example

```typescript
class ExpenseService {
  private baseUrl = 'http://localhost:3000/api/expenses';
  private token = localStorage.getItem('authToken');

  async createExpense(data: ExpenseFormData) {
    const response = await fetch(this.baseUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.token}`
      },
      body: JSON.stringify(data)
    });
    
    if (!response.ok) {
      throw new Error('Failed to create expense');
    }
    
    return response.json();
  }

  async getExpenses(filters?: ExpenseFilters) {
    const params = new URLSearchParams(filters as any);
    const response = await fetch(`${this.baseUrl}?${params}`, {
      headers: {
        'Authorization': `Bearer ${this.token}`
      }
    });
    
    return response.json();
  }

  async updateExpense(id: string, data: Partial<ExpenseFormData>) {
    const response = await fetch(`${this.baseUrl}/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.token}`
      },
      body: JSON.stringify(data)
    });
    
    return response.json();
  }

  async deleteExpense(id: string) {
    const response = await fetch(`${this.baseUrl}/${id}`, {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${this.token}`
      }
    });
    
    return response.ok;
  }
}
```

### 3. React Component Example

```typescript
import React, { useState } from 'react';

const ExpenseForm: React.FC = () => {
  const [formData, setFormData] = useState<ExpenseFormData>({
    description: '',
    amount: 0,
    category: 'office_supplies',
    date: new Date(),
    vendor: '',
    invoice_number: '',
    payment_method: 'card',
    tags: [],
    notes: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const expenseService = new ExpenseService();
      const result = await expenseService.createExpense(formData);
      console.log('Expense created:', result);
      // Handle success
    } catch (error) {
      console.error('Error creating expense:', error);
      // Handle error
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        placeholder="Description"
        value={formData.description}
        onChange={(e) => setFormData({...formData, description: e.target.value})}
        required
      />
      
      <input
        type="number"
        placeholder="Amount"
        value={formData.amount}
        onChange={(e) => setFormData({...formData, amount: parseFloat(e.target.value)})}
        required
      />
      
      <select
        value={formData.category}
        onChange={(e) => setFormData({...formData, category: e.target.value as ExpenseType})}
      >
        <option value="office_supplies">Office Supplies</option>
        <option value="equipment">Equipment</option>
        <option value="travel">Travel</option>
        {/* Add other categories */}
      </select>
      
      <button type="submit">Create Expense</button>
    </form>
  );
};
```

## Error Handling

### Common Error Responses

```json
{
  "error": "Validation failed",
  "details": {
    "amount": "Amount is required",
    "expense_type": "Invalid expense type"
  }
}
```

### HTTP Status Codes

- `200`: Success
- `201`: Created successfully
- `400`: Bad Request (validation errors)
- `401`: Unauthorized (invalid token)
- `403`: Forbidden (insufficient permissions)
- `404`: Not Found
- `500`: Internal Server Error

## Examples

### Complete Expense Creation Flow

1. **Login to get token:**
```javascript
const loginResponse = await fetch('/api/users/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    email: 'admin@example.com',
    password: 'admin123!'
  })
});
const { token } = await loginResponse.json();
```

2. **Create expense:**
```javascript
const expenseData = {
  description: "Office Supplies Purchase",
  amount: 150.75,
  category: "office_supplies",
  date: "2025-06-09T13:00:00.000Z",
  vendor: "Office Depot",
  payment_method: "card",
  notes: "Monthly supplies"
};

const response = await fetch('/api/expenses', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`
  },
  body: JSON.stringify(expenseData)
});

const expense = await response.json();
```

3. **Get expenses with filters:**
```javascript
const filters = new URLSearchParams({
  expense_type: 'office_supplies',
  status: 'draft',
  date_from: '2025-01-01',
  date_to: '2025-12-31'
});

const response = await fetch(`/api/expenses?${filters}`, {
  headers: { 'Authorization': `Bearer ${token}` }
});

const expenses = await response.json();
```

## Testing

Use the provided Postman collection (`postman_expenses_collection_corrected.json`) for testing all endpoints. The collection includes:

- Authentication flow
- All CRUD operations
- Filter examples
- Approval workflows
- Receipt management
- Analytics endpoints

## Notes

1. **Field Mapping**: Always use frontend-friendly field names (`description`, `category`). The API handles the mapping automatically.

2. **Auto-Generation**: Don't send `expense_number`, `branch_id`, `user_id`, or timestamps - these are auto-generated.

3. **Validation**: The API validates all required fields and enum values before saving.

4. **Permissions**: Users can only see expenses from their branch unless they have admin permissions.

5. **Status Workflow**: Expenses follow the flow: `draft` → `submitted` → `approved` → `paid`

6. **Receipt Images**: Store receipt URLs and metadata, not the actual files through this API.

This documentation provides everything needed to integrate the expense management system into your frontend application.
