# Stage API Documentation

Stages represent workflow steps that are used in service variations.

## Schema

```javascript
{
  "_id": ObjectId,
  "name": String,        // Human-readable stage name (e.g. 'Disassembly')
  "description": String, // What happens in this stage
  "order": Integer,      // 1-based ordering for the workflow
  "created_at": Date,
  "updated_at": Date
}
```

## Endpoints

### Get All Stages

```
GET /api/stages
```

Returns a list of all available stages sorted by order.

**Auth Required**: Yes (Any authenticated user)

**Response Example**:

```javascript
[
  {
    "_id": "6078f2a56821e33d1c21f255",
    "name": "Disassembly",
    "description": "Remove damaged panels and components",
    "order": 1,
    "created_at": "2025-05-22T10:30:45.000Z",
    "updated_at": "2025-05-22T10:30:45.000Z"
  },
  {
    "_id": "6078f2c96821e33d1c21f256",
    "name": "Repair",
    "description": "Perform necessary repairs on components",
    "order": 2,
    "created_at": "2025-05-22T10:31:22.000Z",
    "updated_at": "2025-05-22T10:31:22.000Z"
  }
]
```

### Get Stage by ID

```
GET /api/stages/:id
```

Returns a single stage by its ID.

**Auth Required**: Yes (Any authenticated user)

**URL Parameters**:
- `id` - The MongoDB ObjectId of the stage

**Response Example**:

```javascript
{
  "_id": "6078f2a56821e33d1c21f255",
  "name": "Disassembly",
  "description": "Remove damaged panels and components",
  "order": 1,
  "created_at": "2025-05-22T10:30:45.000Z",
  "updated_at": "2025-05-22T10:30:45.000Z"
}
```

### Create New Stage

```
POST /api/stages
```

Creates a new workflow stage.

**Auth Required**: Yes (Admin or user with `manage_stages` permission)

**Request Body**:

```javascript
{
  "name": "Reassembly",
  "description": "Put all components back together",
  "order": 3
}
```

**Response Example**:

```javascript
{
  "_id": "6078f2e56821e33d1c21f257",
  "name": "Reassembly",
  "description": "Put all components back together",
  "order": 3,
  "created_at": "2025-05-22T10:32:15.000Z",
  "updated_at": "2025-05-22T10:32:15.000Z"
}
```

### Update Stage

```
PUT /api/stages/:id
```

Updates an existing workflow stage.

**Auth Required**: Yes (Admin or user with `manage_stages` permission)

**URL Parameters**:
- `id` - The MongoDB ObjectId of the stage

**Request Body** (all fields optional):

```javascript
{
  "name": "Reassembly and Testing",
  "description": "Put all components back together and test functionality",
  "order": 4
}
```

**Response Example**:

```javascript
{
  "_id": "6078f2e56821e33d1c21f257",
  "name": "Reassembly and Testing",
  "description": "Put all components back together and test functionality",
  "order": 4,
  "created_at": "2025-05-22T10:32:15.000Z",
  "updated_at": "2025-05-22T10:35:30.000Z"
}
```

### Delete Stage

```
DELETE /api/stages/:id
```

Deletes a workflow stage.

**Auth Required**: Yes (Admin or user with `manage_stages` permission)

**URL Parameters**:
- `id` - The MongoDB ObjectId of the stage

**Response Example**:

```javascript
{
  "message": "Stage deleted successfully"
}
```

**Error Responses**:

If the stage is used in any variations:
```javascript
{
  "message": "Cannot delete stage that is used in variations",
  "variations": [
    {
      "_id": "6078f3a56821e33d1c21f260",
      "code": "PDR"
    }
  ]
}
```
