const { ObjectId } = require('mongodb');

/**
 * Custom error class for validation errors
 */
class ValidationError extends Error {
  constructor(message) {
    super(message);
    this.name = 'ValidationError';
  }
}

/**
 * WorkOrder Model
 * Provides structure and methods for WorkOrder data
 */
class WorkOrder {
  /**
   * Get MongoDB schema validation for work_orders collection
   * @returns {Object} MongoDB schema validation object
   */
  static getSchema() {
    return {        validator: {
        $jsonSchema: {
          bsonType: "object",
          required: ["workOrderNumber", "customer_id", "vehicle_id", "status", "createdAt", "parts"],
          properties: {
            workOrderNumber: {
              bsonType: "string",
              description: "Unique identifier for this work order"
            },
            customer_id: {
              bsonType: "objectId",
              description: "Reference to a customer document"
            },
            vehicle_id: {
              bsonType: "int",
              description: "ID of the vehicle in customer's vehicles array"
            },
            status: {
              enum: ["open", "in_progress", "on_hold", "completed", "closed"],
              description: "Overall status of the work order"
            },
            description: {
              bsonType: "string",
              description: "detailed description of the work to be performed"
            },
            createdAt: {
              bsonType: "date",
              description: "Work order creation timestamp"
            },
            updatedAt: {
              bsonType: "date",
              description: "Last update timestamp"
            },
            parts: {
              bsonType: "array",
              minItems: 1,
              description: "Sub-workorders split by vehicle part",
              items: {
                bsonType: "object",
                required: ["partName", "variationId", "status", "stages", "createdAt"],
                properties: {
                  partName: {
                    bsonType: "string",
                    description: "e.g. 'left door', 'engine'"
                  },
                  variationId: {
                    bsonType: "objectId",
                    description: "Refers to a document in `variations`"
                  },
                  status: {
                    enum: ["pending", "in_progress", "completed"],
                    description: "Status of this part's overall work"
                  },
                  assignedTo: {
                    bsonType: "objectId",
                    description: "Technician _id"
                  },
                  createdAt: {
                    bsonType: "date",
                    description: "Timestamp when this part was added"
                  },
                  updatedAt: {
                    bsonType: "date",
                    description: "Timestamp of last change to this part"
                  },
                  stages: {
                    bsonType: "array",
                    minItems: 1,
                    description: "Workflow stages for this part",
                    items: {
                      bsonType: "object",
                      required: ["stageId", "status", "logs", "createdAt"],
                      properties: {
                        stageId: {
                          bsonType: "objectId",
                          description: "Refers to a document in `stages`"
                        },
                        status: {
                          enum: ["pending", "in_progress", "completed", "paused"],
                          description: "Status of this stage"
                        },
                        assignedTo: {
                          bsonType: "objectId",
                          description: "Technician _id for this stage"
                        },
                        createdAt: {
                          bsonType: "date",
                          description: "Stage start timestamp"
                        },
                        updatedAt: {
                          bsonType: "date",
                          description: "Stage last update timestamp"
                        },
                        estimatedHours: {
                          bsonType: "double",
                          minimum: 0,
                          description: "Estimated hours for this stage"
                        },
                        logs: {
                          bsonType: "array",
                          description: "Time-log entries for this stage",
                          items: {
                            bsonType: "object",
                            required: ["timestamp", "action"],
                            properties: {
                              timestamp: {
                                bsonType: "date",
                                description: "When the action occurred"
                              },
                              action: {
                                enum: ["start", "pause", "resume", "complete"],
                                description: "Type of time-log event"
                              },
                              note: {
                                bsonType: "string",
                                description: "Optional comment"
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    };
  }

  /**
   * Generate a unique work order number
   * @param {Object} db MongoDB database connection
   * @returns {string} Unique work order number
   */
  static async generateWorkOrderNumber(db) {
    const lastWorkOrder = await db.collection('work_orders')
      .find({}, { projection: { workOrderNumber: 1 } })
      .sort({ workOrderNumber: -1 })
      .limit(1)
      .toArray();
    
    let nextNumber = 1;
    
    if (lastWorkOrder.length > 0 && lastWorkOrder[0].workOrderNumber) {
      // Extract the number part if it has a specific format, or just increment
      const match = lastWorkOrder[0].workOrderNumber.match(/(\d+)$/);
      if (match) {
        nextNumber = parseInt(match[1], 10) + 1;
      }
    }
    
    // Format the work order number with leading zeros
    return `WO-${nextNumber.toString().padStart(6, '0')}`;
  }

  /**
   * Create a new work order
   * @param {Object} db MongoDB database connection
   * @param {Object} workOrderData Work order data to create
   * @returns {Object} Created work order
   */
  static async create(db, workOrderData) {
    // Add timestamps
    const timestamp = new Date();
    
    // Generate work order number if not provided
    if (!workOrderData.workOrderNumber) {
      workOrderData.workOrderNumber = await WorkOrder.generateWorkOrderNumber(db);
    }
    
    // Ensure parts array exists
    if (!workOrderData.parts || !Array.isArray(workOrderData.parts) || workOrderData.parts.length === 0) {
      throw new Error('Work order must have at least one part');
    }
    
    // Convert string customer_id to ObjectId if needed
    if (workOrderData.customer_id && typeof workOrderData.customer_id === 'string') {
      workOrderData.customer_id = new ObjectId(workOrderData.customer_id);
    }
    
    // Validate that the vehicle belongs to the customer
    if (workOrderData.customer_id && workOrderData.vehicle_id !== undefined) {
      const customer = await db.collection('customers').findOne({ _id: workOrderData.customer_id });
      
      if (!customer) {
        throw new ValidationError('Customer not found');
      }
      
      // Ensure vehicle_id is an integer
      const vehicleId = parseInt(workOrderData.vehicle_id);
      if (isNaN(vehicleId)) {
        throw new ValidationError('Vehicle ID must be a valid integer');
      }
      
      // Check if the vehicle_id exists in the customer's vehicles array
      const vehicleExists = customer.vehicles.some(vehicle => 
        vehicle.vehicle_id === vehicleId
      );
      
      if (!vehicleExists) {
        throw new ValidationError('The specified vehicle does not belong to this customer');
      }
      
      // Set vehicle_id as integer to ensure consistent typing
      workOrderData.vehicle_id = vehicleId;
    } else if (workOrderData.customer_id) {
      throw new ValidationError('Vehicle ID is required when customer is specified');
    }
    
    // Process parts array and populate stages from variations
    const processedParts = [];
    for (const part of workOrderData.parts) {
      // Convert variationId to ObjectId
      if (part.variationId && typeof part.variationId === 'string') {
        part.variationId = new ObjectId(part.variationId);
      }
      
      // Convert assignedTo to ObjectId if present
      if (part.assignedTo && typeof part.assignedTo === 'string') {
        part.assignedTo = new ObjectId(part.assignedTo);
      }
      
      // Get the variation to get its default stages
      const variation = await db.collection('variations').findOne({ _id: part.variationId });
      if (!variation) {
        throw new ValidationError(`Variation not found for part "${part.partName}"`);
      }

      // Get stages from the variation's default stages
      const stages = await db.collection('stages')
        .find({ _id: { $in: variation.defaultStages } })
        .sort({ order: 1 })
        .toArray();

      if (stages.length === 0) {
        throw new ValidationError(`No stages found for variation of part "${part.partName}"`);
      }

      // Create stage entries
      const processedStages = stages.map(stage => ({
        stageId: stage._id,
        status: 'pending',
        logs: [],
        createdAt: timestamp,
        updatedAt: timestamp
      }));

      processedParts.push({
        ...part,
        status: 'pending',
        stages: processedStages,
        createdAt: timestamp,
        updatedAt: timestamp
      });
    }
    
    const newWorkOrder = {
      ...workOrderData,
      parts: processedParts,
      status: workOrderData.status || 'open', // Default to 'open' if no status provided
      createdAt: timestamp,
      updatedAt: timestamp
    };
    
    const result = await db.collection('work_orders').insertOne(newWorkOrder);
    return { ...newWorkOrder, _id: result.insertedId };
  }

  /**
   * Get work order by ID
   * @param {Object} db MongoDB database connection
   * @param {string} id Work order ID
   * @returns {Object} Work order document
   */
  static async getById(db, id) {
    const workOrder = await db.collection('work_orders').findOne({ _id: new ObjectId(id) });
    
    if (!workOrder) {
      return null;
    }
    
    // Enhance with vehicle and customer details
    await WorkOrder.enhanceWorkOrdersWithVehicleDetails(db, [workOrder]);
    await WorkOrder.enhanceWorkOrdersWithCustomerDetails(db, [workOrder]);
    
    return workOrder;
  }

  /**
   * Get work order by work order number
   * @param {Object} db MongoDB database connection
   * @param {string} workOrderNumber Work order number
   * @returns {Object} Work order document
   */
  static async getByWorkOrderNumber(db, workOrderNumber) {
    const workOrder = await db.collection('work_orders').findOne({ workOrderNumber });
    
    if (!workOrder) {
      return null;
    }
    
    // Enhance with vehicle and customer details
    await WorkOrder.enhanceWorkOrdersWithVehicleDetails(db, [workOrder]);
    await WorkOrder.enhanceWorkOrdersWithCustomerDetails(db, [workOrder]);
    
    return workOrder;
  }

  /**
   * Get work orders for a specific customer
   * @param {Object} db MongoDB database connection
   * @param {string} customerId Customer ID
   * @returns {Array} Array of work order documents
   */
  static async getByCustomerId(db, customerId) {
    const workOrders = await db.collection('work_orders')
      .find({ customer_id: new ObjectId(customerId) })
      .toArray();
    
    // Enhance with vehicle and customer details
    await WorkOrder.enhanceWorkOrdersWithVehicleDetails(db, workOrders);
    await WorkOrder.enhanceWorkOrdersWithCustomerDetails(db, workOrders);
    
    return workOrders;
  }
  
  /**
   * Enhance work orders with vehicle details from the customer
   * @param {Object} db MongoDB database connection
   * @param {Array} workOrders Array of work order documents
   * @returns {Array} Enhanced work orders
   */
  static async enhanceWorkOrdersWithVehicleDetails(db, workOrders) {
    if (!workOrders || workOrders.length === 0) return workOrders;
    
    // Enhance each work order with vehicle details
    const Customer = require('./Customer');
    
    for (let workOrder of workOrders) {
      if (!workOrder.customer_id || workOrder.vehicle_id === undefined) continue;
      
      // Get the customer ID (it might be an object if already populated)
      const customerId = workOrder.customer_id._id || workOrder.customer_id;
      
      const vehicleDetails = await Customer.getVehicleDetails(
        db, 
        customerId,
        workOrder.vehicle_id
      );
      
      if (vehicleDetails) {
        // Replace vehicle_id with the full vehicle object
        workOrder.vehicle_id = vehicleDetails;
      }
    }
    
    return workOrders;
  }

  /**
   * Enhance work orders with customer details
   * @param {Object} db MongoDB database connection
   * @param {Array} workOrders Array of work order documents
   * @returns {Array} Enhanced work orders
   */
  static async enhanceWorkOrdersWithCustomerDetails(db, workOrders) {
    if (!workOrders || workOrders.length === 0) return workOrders;
    
    // Get unique customer IDs
    const customerIds = [...new Set(workOrders
      .map(wo => wo.customer_id)
      .filter(id => id)
      .map(id => id.toString())
    )];
    
    if (customerIds.length === 0) return workOrders;
    
    // Fetch all customers in one query
    const customers = await db.collection('customers').find({
      _id: { $in: customerIds.map(id => new ObjectId(id)) }
    }).toArray();
    
    // Create a map for quick lookup
    const customerMap = new Map();
    customers.forEach(customer => {
      customerMap.set(customer._id.toString(), customer);
    });
    
    // Enhance work orders with customer details
    for (let workOrder of workOrders) {
      if (workOrder.customer_id) {
        const customer = customerMap.get(workOrder.customer_id.toString());
        if (customer) {
          workOrder.customer_id = {
            _id: customer._id,
            name: `${customer.first_name} ${customer.last_name}`,
            first_name: customer.first_name,
            last_name: customer.last_name,
            email: customer.email,
            phone: customer.phone,
            city: customer.city,
            country: customer.country,
            branch: customer.branch
          };
        }
      }
    }
    
    return workOrders;
  }

  /**
   * Enhance work orders with customer details
   * @param {Object} db MongoDB database connection
   * @param {Array} workOrders Array of work order documents
   * @returns {Array} Enhanced work orders
   */
  static async enhanceWorkOrdersWithCustomerDetails(db, workOrders) {
    if (!workOrders || workOrders.length === 0) return workOrders;
    
    // Get all unique customer IDs
    const customerIds = [...new Set(workOrders
      .filter(wo => wo.customer_id)
      .map(wo => wo.customer_id)
    )];
    
    if (customerIds.length === 0) return workOrders;
    
    // Get all customers in one query
    const customers = await db.collection('customers')
      .find({ _id: { $in: customerIds } })
      .toArray();
    
    // Create a map for quick lookups
    const customerMap = new Map(customers.map(c => [c._id.toString(), c]));
    
    // Enhance work orders with customer details
    for (let workOrder of workOrders) {
      if (!workOrder.customer_id) continue;
      
      const customer = customerMap.get(workOrder.customer_id.toString());
      if (customer) {
        workOrder.customerDetails = {
          name: `${customer.first_name} ${customer.last_name}`,
          email: customer.email,
          phone: customer.phone
        };
      }
    }
    
    return workOrders;
  }

  /**
   * Search work orders with enhanced customer and vehicle data
   * @param {Object} db MongoDB database connection
   * @param {Object} searchParams Search parameters
   * @returns {Array} Array of matching work order documents
   */
  static async searchWorkOrders(db, searchParams) {
    const { 
      customer_id, 
      status, 
      created_from, 
      created_to, 
      vin, 
      search 
    } = searchParams;
    
    // Build base query
    const query = {};
    
    if (customer_id) {
      query.customer_id = new ObjectId(customer_id);
    }
    
    if (status) {
      query.status = status;
    }
    
    // Date range filtering
    if (created_from || created_to) {
      query.createdAt = {};
      
      if (created_from) {
        query.createdAt.$gte = new Date(created_from);
      }
      
      if (created_to) {
        query.createdAt.$lte = new Date(created_to);
      }
    }
    
    // Text search on work order fields
    if (search && search.trim()) {
      const searchRegex = new RegExp(search.trim(), 'i');
      query.$or = [
        { workOrderNumber: searchRegex },
        { description: searchRegex },
        { 'parts.partName': searchRegex }
      ];
    }
    
    // If searching by customer name, we need to join with customers collection
    let workOrders;
    if (search && search.trim() && !customer_id) {
      // Search in customers and get matching customer IDs
      const Customer = require('./Customer');
      const searchRegex = new RegExp(search.trim(), 'i');
      
      const matchingCustomers = await db.collection('customers').find({
        $or: [
          { first_name: searchRegex },
          { last_name: searchRegex },
          { email: searchRegex }
        ]
      }, { projection: { _id: 1 } }).toArray();
      
      const customerIds = matchingCustomers.map(c => c._id);
      
      if (customerIds.length > 0) {
        // Combine customer search with existing query
        if (query.$or) {
          query.$or.push({ customer_id: { $in: customerIds } });
        } else {
          query.$or = [{ customer_id: { $in: customerIds } }];
        }
      }
    }
    
    // Execute the search
    workOrders = await db.collection('work_orders').find(query).toArray();
    
    // Enhance with vehicle details
    await WorkOrder.enhanceWorkOrdersWithVehicleDetails(db, workOrders);
    
    // Apply post-enhancement filtering
    if (vin || (search && search.trim())) {
      workOrders = workOrders.filter(workOrder => {
        let matches = true;
        
        // VIN filtering
        if (vin && workOrder.vehicleDetails) {
          matches = matches && workOrder.vehicleDetails.vin && 
                   workOrder.vehicleDetails.vin.toLowerCase().includes(vin.toLowerCase());
        }
        
        // Vehicle details search
        if (search && search.trim() && workOrder.vehicleDetails) {
          const searchLower = search.trim().toLowerCase();
          const vehicleMatch = 
            workOrder.vehicleDetails.make?.toLowerCase().includes(searchLower) ||
            workOrder.vehicleDetails.model?.toLowerCase().includes(searchLower) ||
            workOrder.vehicleDetails.vin?.toLowerCase().includes(searchLower) ||
            workOrder.vehicleDetails.license_plate?.toLowerCase().includes(searchLower);
          
          // Keep if vehicle matches or if there was already a database match
          if (!vehicleMatch && query.$or && !query.$or.some(condition => 
            condition.customer_id || 
            condition.workOrderNumber || 
            condition.description || 
            condition['parts.partName']
          )) {
            matches = false;
          }
        }
        
        return matches;
      });
    }
    
    return workOrders;
  }

  /**
   * Update work order by ID
   * @param {Object} db MongoDB database connection
   * @param {string} id Work order ID
   * @param {Object} updateData Update data
   * @returns {Object} Update result
   */
  static async updateById(db, id, updateData) {
    const timestamp = new Date();
    
    // Don't allow direct updates to parts array through this method
    const { parts, ...updates } = updateData;
    
    // Handle special cases for nested objects and ObjectId conversions
    if (updates.customer_id && typeof updates.customer_id === 'string') {
      updates.customer_id = new ObjectId(updates.customer_id);
    }
    
    // If vehicle_id is being updated, validate ownership
    if (updates.vehicle_id !== undefined) {
      // Get the current work order to check customer_id
      const workOrder = await db.collection('work_orders').findOne({ _id: new ObjectId(id) });
      if (!workOrder) {
        throw new ValidationError('Work order not found');
      }
      
      // Use the customer_id from the update if provided, otherwise use the existing one
      const customerId = updates.customer_id || workOrder.customer_id;
      
      // Get customer information
      const customer = await db.collection('customers').findOne({ _id: customerId });
      if (!customer) {
        throw new ValidationError('Customer not found');
      }
      
      // Ensure vehicle_id is an integer
      const vehicleId = parseInt(updates.vehicle_id);
      if (isNaN(vehicleId)) {
        throw new ValidationError('Vehicle ID must be a valid integer');
      }
      
      // Check if vehicle belongs to customer
      const vehicleExists = customer.vehicles.some(vehicle => 
        vehicle.vehicle_id === vehicleId
      );
      
      if (!vehicleExists) {
        throw new ValidationError('The specified vehicle does not belong to this customer');
      }
      
      // Ensure vehicle_id is stored as integer
      updates.vehicle_id = vehicleId;
    }
    
    const result = await db.collection('work_orders').updateOne(
      { _id: new ObjectId(id) },
      { 
        $set: {
          ...updates,
          updatedAt: timestamp
        } 
      }
    );
    
    return result;
  }

  /**
   * Delete work order by ID
   * @param {Object} db MongoDB database connection
   * @param {string} id Work order ID
   * @returns {Object} Delete result
   */
  static async deleteById(db, id) {
    return db.collection('work_orders').deleteOne({ _id: new ObjectId(id) });
  }
  
  /**
   * Add a part to a work order
   * @param {Object} db MongoDB database connection
   * @param {string} workOrderId Work order ID
   * @param {Object} partData Part data
   * @returns {Object} Update result
   */
  static async addPart(db, workOrderId, partData) {
    const timestamp = new Date();
    
    // Convert IDs to ObjectIds
    if (partData.variationId && typeof partData.variationId === 'string') {
      partData.variationId = new ObjectId(partData.variationId);
    }
    
    if (partData.assignedTo && typeof partData.assignedTo === 'string') {
      partData.assignedTo = new ObjectId(partData.assignedTo);
    }

    // Get the variation to get its default stages
    const variation = await db.collection('variations').findOne({ _id: partData.variationId });
    if (!variation) {
      throw new ValidationError('Variation not found');
    }

    // Create stages from the variation's default stages
    const stages = await db.collection('stages')
      .find({ _id: { $in: variation.defaultStages } })
      .sort({ order: 1 })
      .toArray();

    if (stages.length === 0) {
      throw new ValidationError('No stages found for this variation');
    }

    partData.stages = stages.map(stage => ({
      stageId: stage._id,
      status: 'pending',
      logs: [],
      createdAt: timestamp,
      updatedAt: timestamp
    }));
    
    const partWithTimestamps = {
      ...partData,
      status: 'pending', // Ensure new parts start as pending
      createdAt: timestamp,
      updatedAt: timestamp
    };
    
    return db.collection('work_orders').updateOne(
      { _id: new ObjectId(workOrderId) },
      { 
        $push: { parts: partWithTimestamps },
        $set: { updatedAt: timestamp }
      }
    );
  }
  
  /**
   * Update a part in a work order
   * @param {Object} db MongoDB database connection
   * @param {string} workOrderId Work order ID
   * @param {number} partIndex Index of the part in the array
   * @param {Object} updateData Part update data
   * @returns {Object} Update result
   */
  static async updatePart(db, workOrderId, partIndex, updateData) {
    const timestamp = new Date();
    
    // Handle ID conversions
    if (updateData.variationId && typeof updateData.variationId === 'string') {
      updateData.variationId = new ObjectId(updateData.variationId);
    }
    
    if (updateData.assignedTo && typeof updateData.assignedTo === 'string') {
      updateData.assignedTo = new ObjectId(updateData.assignedTo);
    }
    
    // Create update object with dot notation for the specific array element
    const updates = {};
    Object.entries(updateData).forEach(([key, value]) => {
      updates[`parts.${partIndex}.${key}`] = value;
    });
    
    updates[`parts.${partIndex}.updatedAt`] = timestamp;
    updates.updatedAt = timestamp;
    
    return db.collection('work_orders').updateOne(
      { _id: new ObjectId(workOrderId) },
      { $set: updates }
    );
  }
  
  /**
   * Add a stage to a part in a work order
   * @param {Object} db MongoDB database connection
   * @param {string} workOrderId Work order ID
   * @param {number} partIndex Index of the part in the array
   * @param {Object} stageData Stage data
   * @returns {Object} Update result
   */
  static async addStage(db, workOrderId, partIndex, stageData) {
    const timestamp = new Date();
    
    // Convert IDs to ObjectIds
    if (stageData.stageId && typeof stageData.stageId === 'string') {
      stageData.stageId = new ObjectId(stageData.stageId);
    }
    
    if (stageData.assignedTo && typeof stageData.assignedTo === 'string') {
      stageData.assignedTo = new ObjectId(stageData.assignedTo);
    }
    
    const stageWithTimestamps = {
      ...stageData,
      logs: stageData.logs || [],
      createdAt: timestamp,
      updatedAt: timestamp
    };
    
    return db.collection('work_orders').updateOne(
      { _id: new ObjectId(workOrderId) },
      { 
        $push: { [`parts.${partIndex}.stages`]: stageWithTimestamps },
        $set: { 
          [`parts.${partIndex}.updatedAt`]: timestamp,
          updatedAt: timestamp
        }
      }
    );
  }
  
  /**
   * Update a stage in a work order part
   * @param {Object} db MongoDB database connection
   * @param {string} workOrderId Work order ID
   * @param {number} partIndex Index of the part in the array
   * @param {number} stageIndex Index of the stage in the part's stages array
   * @param {Object} updateData Stage update data
   * @returns {Object} Update result
   */
  static async updateStage(db, workOrderId, partIndex, stageIndex, updateData) {
    const timestamp = new Date();
    
    // Convert IDs to ObjectIds
    if (updateData.stageId && typeof updateData.stageId === 'string') {
      updateData.stageId = new ObjectId(updateData.stageId);
    }
    
    if (updateData.assignedTo && typeof updateData.assignedTo === 'string') {
      updateData.assignedTo = new ObjectId(updateData.assignedTo);
    }
    
    // Create update object with dot notation for the specific array element
    const updates = {};
    Object.entries(updateData).forEach(([key, value]) => {
      updates[`parts.${partIndex}.stages.${stageIndex}.${key}`] = value;
    });
    
    updates[`parts.${partIndex}.stages.${stageIndex}.updatedAt`] = timestamp;
    updates[`parts.${partIndex}.updatedAt`] = timestamp;
    updates.updatedAt = timestamp;
    
    return db.collection('work_orders').updateOne(
      { _id: new ObjectId(workOrderId) },
      { $set: updates }
    );
  }
  
  /**
   * Add a log entry to a stage
   * @param {Object} db MongoDB database connection
   * @param {string} workOrderId Work order ID
   * @param {number} partIndex Index of the part in the array
   * @param {number} stageIndex Index of the stage in the part's stages array
   * @param {Object} logData Log entry data
   * @returns {Object} Update result
   */
  static async addLogEntry(db, workOrderId, partIndex, stageIndex, logData) {
    const timestamp = new Date();
    
    const logEntry = {
      ...logData,
      timestamp: logData.timestamp || timestamp
    };
    
    return db.collection('work_orders').updateOne(
      { _id: new ObjectId(workOrderId) },
      { 
        $push: { [`parts.${partIndex}.stages.${stageIndex}.logs`]: logEntry },
        $set: { 
          [`parts.${partIndex}.stages.${stageIndex}.updatedAt`]: timestamp,
          [`parts.${partIndex}.updatedAt`]: timestamp,
          updatedAt: timestamp
        }
      }
    );
  }
  
  /**
   * Update work order status
   * @param {Object} db MongoDB database connection
   * @param {string} id Work order ID
   * @param {string} status New status
   * @returns {Object} Update result
   */
  static async updateStatus(db, id, status) {
    const timestamp = new Date();
    
    // Validate status
    const validStatuses = ['open', 'in_progress', 'on_hold', 'completed', 'closed'];
    if (!validStatuses.includes(status)) {
      throw new Error('Invalid status. Must be one of: ' + validStatuses.join(', '));
    }
    
    return db.collection('work_orders').updateOne(
      { _id: new ObjectId(id) },
      { 
        $set: { 
          status,
          updatedAt: timestamp
        }
      }
    );
  }
  
  /**
   * Update part status
   * @param {Object} db MongoDB database connection
   * @param {string} workOrderId Work order ID
   * @param {number} partIndex Index of the part in the array
   * @param {string} status New status
   * @returns {Object} Update result
   */
  static async updatePartStatus(db, workOrderId, partIndex, status) {
    const timestamp = new Date();
    
    // Validate status
    const validStatuses = ['pending', 'in_progress', 'completed'];
    if (!validStatuses.includes(status)) {
      throw new Error('Invalid status. Must be one of: ' + validStatuses.join(', '));
    }
    
    return db.collection('work_orders').updateOne(
      { _id: new ObjectId(workOrderId) },
      { 
        $set: { 
          [`parts.${partIndex}.status`]: status,
          [`parts.${partIndex}.updatedAt`]: timestamp,
          updatedAt: timestamp
        }
      }
    );
  }
  
  /**
   * Update stage status
   * @param {Object} db MongoDB database connection
   * @param {string} workOrderId Work order ID
   * @param {number} partIndex Index of the part in the array
   * @param {number} stageIndex Index of the stage in the part's stages array
   * @param {string} status New status
   * @returns {Object} Update result
   */
  static async updateStageStatus(db, workOrderId, partIndex, stageIndex, status) {
    const timestamp = new Date();
    
    // Validate status
    const validStatuses = ['pending', 'in_progress', 'completed', 'paused'];
    if (!validStatuses.includes(status)) {
      throw new Error('Invalid status. Must be one of: ' + validStatuses.join(', '));
    }
    
    return db.collection('work_orders').updateOne(
      { _id: new ObjectId(workOrderId) },
      { 
        $set: { 
          [`parts.${partIndex}.stages.${stageIndex}.status`]: status,
          [`parts.${partIndex}.stages.${stageIndex}.updatedAt`]: timestamp,
          [`parts.${partIndex}.updatedAt`]: timestamp,
          updatedAt: timestamp
        }
      }
    );
  }
}

module.exports = WorkOrder;
module.exports.ValidationError = ValidationError;
