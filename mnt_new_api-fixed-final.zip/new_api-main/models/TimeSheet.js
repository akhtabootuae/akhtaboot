const { ObjectId } = require('mongodb');
const moment = require('moment');

class TimeSheet {
  /**
   * Get collection validation schema for MongoDB
   */
  static getSchema() {
    // No validation schema to avoid any validation errors
    return {};
  }

  /**
   * Create a new timesheet
   */
  static async create(db, timesheetData) {
    // Simple timesheet creation - just time tracking fields
    const timesheet = {
      employee_id: new ObjectId(timesheetData.employee_id),
      work_date: new Date(timesheetData.work_date),
      time_in: timesheetData.time_in ? new Date(timesheetData.time_in) : null,
      time_out: timesheetData.time_out ? new Date(timesheetData.time_out) : null,
      total_hours: parseFloat(timesheetData.total_hours || 8),
      notes: timesheetData.notes || '',
      status: timesheetData.status || 'draft',
      created_at: new Date(),
      updated_at: new Date(),
      created_by: new ObjectId(timesheetData.created_by)
    };

    const result = await db.collection('timesheets').insertOne(timesheet);
    return { ...timesheet, _id: result.insertedId };
  }

  /**
   * Calculate timesheet hours from time in/out
   */
  static calculateHours(timesheetData) {
    let totalHours = 0;

    // If manual hours provided, use them
    if (timesheetData.total_hours !== undefined && timesheetData.total_hours !== null) {
      totalHours = parseFloat(timesheetData.total_hours);
    } else if (timesheetData.time_in && timesheetData.time_out) {
      // Calculate from time in/out
      const timeIn = moment(timesheetData.time_in);
      const timeOut = moment(timesheetData.time_out);
      const breakDuration = timesheetData.break_duration || 0;
      
      totalHours = timeOut.diff(timeIn, 'hours', true) - (breakDuration / 60);
      totalHours = Math.max(0, totalHours); // Ensure non-negative
    } else {
      // Default to 8 hours if no time data provided
      totalHours = 8;
    }

    return {
      total_hours: parseFloat(totalHours.toFixed(2)),
      time_in: timesheetData.time_in ? new Date(timesheetData.time_in) : null,
      time_out: timesheetData.time_out ? new Date(timesheetData.time_out) : null,
      break_duration: timesheetData.break_duration || 0
    };
  }

  /**
   * Find timesheet by ID
   */
  static async findById(db, timesheetId) {
    // Validate ObjectId format
    if (!ObjectId.isValid(timesheetId)) {
      throw new Error('Invalid timesheet ID format');
    }
    
    return await db.collection('timesheets').findOne({
      _id: new ObjectId(timesheetId)
    });
  }

  /**
   * Find timesheets by employee
   */
  static async findByEmployee(db, employeeId, options = {}) {
    const filter = { employee_id: new ObjectId(employeeId) };
    
    if (options.startDate || options.endDate) {
      filter.work_date = {};
      if (options.startDate) filter.work_date.$gte = new Date(options.startDate);
      if (options.endDate) filter.work_date.$lte = new Date(options.endDate);
    }

    if (options.status) {
      filter.status = options.status;
    }

    return await db.collection('timesheets')
      .find(filter)
      .sort({ work_date: -1 })
      .limit(options.limit || 50)
      .skip(options.skip || 0)
      .toArray();
  }

  /**
   * Submit timesheet for approval
   */
  static async submit(db, timesheetId, submittedBy) {
    const result = await db.collection('timesheets').updateOne(
      { 
        _id: new ObjectId(timesheetId),
        status: 'draft'
      },
      {
        $set: {
          status: 'submitted',
          submitted_at: new Date(),
          updated_at: new Date(),
          updated_by: new ObjectId(submittedBy)
        }
      }
    );

    return result.modifiedCount > 0;
  }

  /**
   * Approve timesheet
   */
  static async approve(db, timesheetId, approvedBy) {
    const result = await db.collection('timesheets').updateOne(
      { 
        _id: new ObjectId(timesheetId),
        status: 'submitted'
      },
      {
        $set: {
          status: 'approved',
          approved_by: new ObjectId(approvedBy),
          approved_at: new Date(),
          updated_at: new Date(),
          updated_by: new ObjectId(approvedBy)
        }
      }
    );

    return result.modifiedCount > 0;
  }

  /**
   * Reject timesheet
   */
  static async reject(db, timesheetId, rejectedBy, reason) {
    const result = await db.collection('timesheets').updateOne(
      { 
        _id: new ObjectId(timesheetId),
        status: 'submitted'
      },
      {
        $set: {
          status: 'rejected',
          rejection_reason: reason,
          updated_at: new Date(),
          updated_by: new ObjectId(rejectedBy)
        }
      }
    );

    return result.modifiedCount > 0;
  }

  /**
   * Update timesheet (only if draft)
   */
  static async update(db, timesheetId, updateData) {
    // Only allow updates to draft timesheets
    const timesheet = await this.findById(db, timesheetId);
    if (!timesheet || timesheet.status !== 'draft') {
      throw new Error('Can only update draft timesheets');
    }

    // Recalculate if hours or time data changed
    if (updateData.total_hours !== undefined || updateData.time_in || updateData.time_out) {
      const calculatedData = this.calculateHours({
        ...timesheet,
        ...updateData
      });
      
      Object.assign(updateData, calculatedData);
    }

    // Handle ObjectId fields
    if (updateData.work_order_ids) {
      updateData.work_order_ids = updateData.work_order_ids.map(id => new ObjectId(id));
    }

    const result = await db.collection('timesheets').updateOne(
      { _id: new ObjectId(timesheetId) },
      {
        $set: {
          ...updateData,
          updated_at: new Date(),
          updated_by: new ObjectId(updateData.updated_by)
        }
      }
    );

    return result.modifiedCount > 0;
  }

  /**
   * Get pending approvals
   */
  static async getPendingApprovals(db, options = {}) {
    return await db.collection('timesheets').aggregate([
      { $match: { status: 'submitted' } },
      {
        $lookup: {
          from: 'users',
          localField: 'employee_id',
          foreignField: '_id',
          as: 'employee'
        }
      },
      { $unwind: '$employee' },
      {
        $project: {
          work_date: 1,
          total_hours: 1,
          submitted_at: 1,
          'employee.email': 1,
          'employee.first_name': 1,
          'employee.last_name': 1
        }
      },
      { $sort: { submitted_at: 1 } },
      { $skip: options.skip || 0 },
      { $limit: options.limit || 50 }
    ]).toArray();
  }

  /**
   * Get employee attendance summary
   */
  static async getAttendanceSummary(db, employeeId, startDate, endDate) {
    const pipeline = [
      {
        $match: {
          employee_id: new ObjectId(employeeId),
          work_date: {
            $gte: new Date(startDate),
            $lte: new Date(endDate)
          },
          status: { $in: ['approved'] }
        }
      },
      {
        $group: {
          _id: null,
          total_days: { $sum: 1 },
          total_hours: { $sum: '$total_hours' }
        }
      }
    ];

    const result = await db.collection('timesheets').aggregate(pipeline).toArray();
    return result[0] || {
      total_days: 0,
      total_hours: 0
    };
  }

  /**
   * Delete timesheet (only if draft)
   */
  static async delete(db, timesheetId) {
    const result = await db.collection('timesheets').deleteOne({
      _id: new ObjectId(timesheetId),
      status: 'draft'
    });

    return result.deletedCount > 0;
  }
}

module.exports = TimeSheet;