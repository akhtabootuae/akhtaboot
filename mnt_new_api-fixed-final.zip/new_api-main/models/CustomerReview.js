const { ObjectId } = require('mongodb');

/**
 * Customer Review Model
 * Handles customer reviews with ratings, phone numbers, comments, and timestamps
 */
class CustomerReview {
  /**
   * Get MongoDB schema validation for customer_reviews collection
   * @returns {Object} MongoDB schema validation object
   */
  static getSchema() {
    return {
      validator: {
        $jsonSchema: {
          bsonType: "object",
          required: ["rating", "created_at", "updated_at"],
          properties: {
            rating: {
              bsonType: "int",
              minimum: 1,
              maximum: 5,
              description: "Customer rating from 1 to 5 stars - required"
            },
            phone_number: {
              bsonType: "string",
              anyOf: [
                { pattern: "^\\+?[1-9]\\d{1,14}$" },
                { enum: ["anonymous"] }
              ],
              description: "Customer phone number in international format or 'anonymous' - optional"
            },
            comment: {
              bsonType: ["string", "null"],
              maxLength: 1000,
              description: "Optional customer comment - maximum 1000 characters"
            },
            referral: {
              bsonType: "string",
              anyOf: [
                { enum: ["Tiktok", "Instagram", "Youtube", "Recommended by a friend"] },
                { pattern: "^other:.+" }
              ],
              description: "How customer found us - predefined options or 'other:' followed by custom text"
            },
            created_at: {
              bsonType: "date",
              description: "When the review was created - required"
            },
            updated_at: {
              bsonType: "date",
              description: "When the review was last updated - required"
            }
          }
        }
      },
      validationLevel: 'strict',
      validationAction: 'error'
    };
  }

  /**
   * Create a new customer review
   * @param {Object} db MongoDB database connection
   * @param {Object} reviewData Review data to create
   * @returns {Object} Created review with generated ID
   */
  static async create(db, reviewData) {
    const timestamp = new Date();
    
    const newReview = {
      rating: parseInt(reviewData.rating),
      phone_number: reviewData.phone_number,
      created_at: timestamp,
      updated_at: timestamp
    };
    
    // Only add comment field if it's provided
    if (reviewData.comment) {
      newReview.comment = reviewData.comment;
    }
    
    // Only add referral field if it's provided
    if (reviewData.referral) {
      newReview.referral = reviewData.referral;
    }
    
    const result = await db.collection('customer_reviews').insertOne(newReview);
    return { ...newReview, _id: result.insertedId };
  }

  /**
   * Get all customer reviews
   * @param {Object} db MongoDB database connection
   * @param {Object} options Query options (limit, skip, sort)
   * @returns {Array} Array of reviews
   */
  static async getAll(db, options = {}) {
    const { limit = 50, skip = 0, sort = { created_at: -1 } } = options;
    
    return await db.collection('customer_reviews')
      .find({})
      .sort(sort)
      .skip(skip)
      .limit(limit)
      .toArray();
  }

  /**
   * Get review by ID
   * @param {Object} db MongoDB database connection
   * @param {string} id Review ID
   * @returns {Object} Review document
   */
  static async getById(db, id) {
    return await db.collection('customer_reviews').findOne({ 
      _id: new ObjectId(id) 
    });
  }

  /**
   * Get reviews by phone number
   * @param {Object} db MongoDB database connection
   * @param {string} phoneNumber Customer phone number
   * @returns {Array} Array of reviews for this phone number
   */
  static async getByPhoneNumber(db, phoneNumber) {
    return await db.collection('customer_reviews')
      .find({ phone_number: phoneNumber })
      .sort({ created_at: -1 })
      .toArray();
  }

  /**
   * Get reviews by rating
   * @param {Object} db MongoDB database connection
   * @param {number} rating Rating value (1-5)
   * @returns {Array} Array of reviews with this rating
   */
  static async getByRating(db, rating) {
    return await db.collection('customer_reviews')
      .find({ rating: parseInt(rating) })
      .sort({ created_at: -1 })
      .toArray();
  }

  /**
   * Update review by ID
   * @param {Object} db MongoDB database connection
   * @param {string} id Review ID
   * @param {Object} updateData Update data
   * @returns {Object} Update result
   */
  static async updateById(db, id, updateData) {
    const timestamp = new Date();
    
    const allowedFields = ['rating', 'phone_number', 'comment', 'referral'];
    const filteredData = {};
    
    allowedFields.forEach(field => {
      if (updateData[field] !== undefined) {
        if (field === 'rating') {
          filteredData[field] = parseInt(updateData[field]);
        } else {
          filteredData[field] = updateData[field];
        }
      }
    });
    
    const result = await db.collection('customer_reviews').updateOne(
      { _id: new ObjectId(id) },
      { 
        $set: {
          ...filteredData,
          updated_at: timestamp
        } 
      }
    );
    
    return result;
  }

  /**
   * Delete review by ID
   * @param {Object} db MongoDB database connection
   * @param {string} id Review ID
   * @returns {Object} Delete result
   */
  static async deleteById(db, id) {
    return await db.collection('customer_reviews').deleteOne({ 
      _id: new ObjectId(id) 
    });
  }

  /**
   * Get review statistics
   * @param {Object} db MongoDB database connection
   * @returns {Object} Statistics including average rating, total reviews, rating distribution
   */
  static async getStatistics(db) {
    const pipeline = [
      {
        $group: {
          _id: null,
          totalReviews: { $sum: 1 },
          averageRating: { $avg: "$rating" },
          ratingDistribution: {
            $push: "$rating"
          }
        }
      },
      {
        $project: {
          _id: 0,
          totalReviews: 1,
          averageRating: { $round: ["$averageRating", 2] },
          ratingDistribution: {
            $reduce: {
              input: [1, 2, 3, 4, 5],
              initialValue: {},
              in: {
                $mergeObjects: [
                  "$$value",
                  {
                    $arrayToObject: [
                      [
                        {
                          k: { $toString: "$$this" },
                          v: {
                            $size: {
                              $filter: {
                                input: "$ratingDistribution",
                                cond: { $eq: ["$$item", "$$this"] }
                              }
                            }
                          }
                        }
                      ]
                    ]
                  }
                ]
              }
            }
          }
        }
      }
    ];

    const result = await db.collection('customer_reviews').aggregate(pipeline).toArray();
    return result.length > 0 ? result[0] : {
      totalReviews: 0,
      averageRating: 0,
      ratingDistribution: { "1": 0, "2": 0, "3": 0, "4": 0, "5": 0 }
    };
  }

  /**
   * Create collection with schema validation
   * @param {Object} db MongoDB database connection
   * @returns {boolean} Success status
   */
  static async createCollection(db) {
    try {
      const collections = await db.listCollections({ name: 'customer_reviews' }).toArray();
      
      if (collections.length === 0) {
        await db.createCollection('customer_reviews', this.getSchema());
        console.log('✅ Customer reviews collection created with validation schema');
        return true;
      } else {
        console.log('ℹ️  Customer reviews collection already exists');
        return true;
      }
    } catch (error) {
      console.error('❌ Error creating customer reviews collection:', error);
      throw error;
    }
  }
}

module.exports = CustomerReview;
