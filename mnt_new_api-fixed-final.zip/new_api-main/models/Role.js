const { ObjectId } = require('mongodb');

/**
 * Role Model
 * Provides structure and methods for Role data
 */
class Role {
  /**
   * Get MongoDB schema validation for roles collection
   * @returns {Object} MongoDB schema validation object
   */
  static getSchema() {
    return {
      validator: {
        $jsonSchema: {
          bsonType: "object",
          required: ["role_name", "description", "created_at", "updated_at"],
          properties: {
            role_name: {
              bsonType: "string",
              description: "Name of the role (e.g., Admin, Technician, Supervisor)"
            },
            description: {
              bsonType: "string",
              description: "Description of the role's responsibilities"
            },
            created_at: {
              bsonType: "date",
              description: "When the role was created"
            },
            updated_at: {
              bsonType: "date",
              description: "When the role was last updated"
            }
          }
        }
      }
    };
  }

  /**
   * Create a new role
   * @param {Object} db MongoDB database connection
   * @param {Object} roleData Role data to create
   * @returns {Object} Created role
   */
  static async create(db, roleData) {
    const timestamp = new Date();
    
    const newRole = {
      ...roleData,
      created_at: timestamp,
      updated_at: timestamp
    };
    
    const result = await db.collection('roles').insertOne(newRole);
    return { ...newRole, _id: result.insertedId };
  }

  /**
   * Get all roles
   * @param {Object} db MongoDB database connection
   * @returns {Array} Array of roles
   */
  static async getAll(db) {
    return await db.collection('roles').find().toArray();
  }

  /**
   * Get role by ID
   * @param {Object} db MongoDB database connection
   * @param {string} id Role ID
   * @returns {Object} Role document
   */
  static async getById(db, id) {
    return await db.collection('roles').findOne({ _id: new ObjectId(id) });
  }

  /**
   * Get role by name
   * @param {Object} db MongoDB database connection
   * @param {string} roleName Role name
   * @returns {Object} Role document
   */
  static async getByName(db, roleName) {
    return await db.collection('roles').findOne({ role_name: roleName });
  }

  /**
   * Update role by ID
   * @param {Object} db MongoDB database connection
   * @param {string} id Role ID
   * @param {Object} updateData Update data
   * @returns {Object} Update result
   */
  static async updateById(db, id, updateData) {
    const timestamp = new Date();
    
    const result = await db.collection('roles').updateOne(
      { _id: new ObjectId(id) },
      { 
        $set: {
          ...updateData,
          updated_at: timestamp
        } 
      }
    );
    
    return result;
  }

  /**
   * Delete role by ID
   * @param {Object} db MongoDB database connection
   * @param {string} id Role ID
   * @returns {Object} Delete result
   */
  static async deleteById(db, id) {
    return await db.collection('roles').deleteOne({ _id: new ObjectId(id) });
  }
}

module.exports = Role;
