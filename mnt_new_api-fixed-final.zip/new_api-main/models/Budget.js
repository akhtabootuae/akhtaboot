const { ObjectId } = require('mongodb');
const moment = require('moment');

class Budget {
  /**
   * Get collection validation schema for MongoDB
   */
  static getSchema() {
    return {
      validator: {
        $jsonSchema: {
          bsonType: "object",
          required: ["name", "budget_type", "amount", "period_start", "period_end", "created_by"],
          properties: {
            name: {
              bsonType: "string",
              maxLength: 200,
              description: "Budget name"
            },
            description: {
              bsonType: "string",
              maxLength: 500,
              description: "Budget description"
            },
            budget_type: {
              bsonType: "string",
              enum: [
                "payroll_total", "department", "branch", "employee_group", 
                "overtime", "deductions", "taxes", "benefits", "custom"
              ],
              description: "Type of budget"
            },
            amount: {
              bsonType: "number",
              minimum: 0,
              description: "Budget amount"
            },
            currency: {
              bsonType: "string",
              enum: ["USD", "EUR", "GBP", "CAD", "AUD"],
              description: "Budget currency"
            },
            period_start: {
              bsonType: "date",
              description: "Budget period start date"
            },
            period_end: {
              bsonType: "date",
              description: "Budget period end date"
            },
            frequency: {
              bsonType: "string",
              enum: ["one-time", "monthly", "quarterly", "yearly"],
              description: "Budget frequency"
            },
            scope: {
              bsonType: "object",
              properties: {
                scope_type: {
                  bsonType: "string",
                  enum: ["company", "branch", "department", "employee_group", "specific_employees"]
                },
                branch_ids: {
                  bsonType: "array",
                  items: {
                    bsonType: "objectId"
                  },
                  description: "Branches included in budget scope"
                },
                department_names: {
                  bsonType: "array",
                  items: {
                    bsonType: "string"
                  },
                  description: "Departments included in budget scope"
                },
                employee_ids: {
                  bsonType: "array",
                  items: {
                    bsonType: "objectId"
                  },
                  description: "Specific employees included in budget scope"
                },
                employee_groups: {
                  bsonType: "array",
                  items: {
                    bsonType: "string"
                  },
                  description: "Employee groups included in budget scope"
                }
              },
              description: "Budget scope definition"
            },
            categories: {
              bsonType: "array",
              items: {
                bsonType: "object",
                properties: {
                  category_name: {
                    bsonType: "string",
                    description: "Category name (e.g., regular_pay, overtime, benefits)"
                  },
                  allocated_amount: {
                    bsonType: "number",
                    minimum: 0,
                    description: "Amount allocated to this category"
                  },
                  percentage: {
                    bsonType: "number",
                    minimum: 0,
                    maximum: 100,
                    description: "Percentage of total budget"
                  }
                }
              },
              description: "Budget breakdown by categories"
            },
            thresholds: {
              bsonType: "object",
              properties: {
                warning_threshold: {
                  bsonType: "number",
                  minimum: 0,
                  maximum: 100,
                  description: "Percentage at which to send warning (default: 80%)"
                },
                critical_threshold: {
                  bsonType: "number",
                  minimum: 0,
                  maximum: 100,
                  description: "Percentage at which to send critical alert (default: 95%)"
                },
                alert_recipients: {
                  bsonType: "array",
                  items: {
                    bsonType: "objectId"
                  },
                  description: "Users to notify when thresholds are exceeded"
                }
              },
              description: "Alert thresholds and notification settings"
            },
            status: {
              bsonType: "string",
              enum: ["draft", "active", "exceeded", "completed", "cancelled"],
              description: "Budget status"
            },
            actual_spending: {
              bsonType: "object",
              properties: {
                total_spent: {
                  bsonType: "number",
                  minimum: 0,
                  description: "Total amount spent against this budget"
                },
                last_calculated: {
                  bsonType: "date",
                  description: "When spending was last calculated"
                },
                category_spending: {
                  bsonType: "array",
                  items: {
                    bsonType: "object",
                    properties: {
                      category_name: {
                        bsonType: "string"
                      },
                      spent_amount: {
                        bsonType: "number",
                        minimum: 0
                      },
                      percentage_used: {
                        bsonType: "number",
                        minimum: 0
                      }
                    }
                  },
                  description: "Spending breakdown by category"
                }
              },
              description: "Actual spending against this budget"
            },
            variance_analysis: {
              bsonType: "object",
              properties: {
                variance_amount: {
                  bsonType: "number",
                  description: "Difference between budget and actual (negative = over budget)"
                },
                variance_percentage: {
                  bsonType: "number",
                  description: "Variance as percentage of budget"
                },
                trend: {
                  bsonType: "string",
                  enum: ["under", "on_track", "over", "critical"],
                  description: "Budget trend analysis"
                },
                projected_total: {
                  bsonType: "number",
                  minimum: 0,
                  description: "Projected total spending based on current trend"
                }
              },
              description: "Budget variance and trend analysis"
            },
            approval_workflow: {
              bsonType: "object",
              properties: {
                requires_approval: {
                  bsonType: "bool",
                  description: "Whether budget changes require approval"
                },
                approved_by: {
                  bsonType: "objectId",
                  description: "User who approved the budget"
                },
                approved_at: {
                  bsonType: "date",
                  description: "When budget was approved"
                },
                approval_notes: {
                  bsonType: "string",
                  maxLength: 500,
                  description: "Approval notes"
                }
              },
              description: "Budget approval workflow"
            },
            auto_refresh: {
              bsonType: "bool",
              description: "Whether to automatically refresh budget for next period"
            },
            refresh_config: {
              bsonType: "object",
              properties: {
                adjustment_percentage: {
                  bsonType: "number",
                  description: "Percentage adjustment for next period (can be negative)"
                },
                base_on_actual: {
                  bsonType: "bool",
                  description: "Whether to base next budget on actual spending"
                },
                copy_categories: {
                  bsonType: "bool",
                  description: "Whether to copy category breakdown to next period"
                }
              },
              description: "Auto-refresh configuration"
            },
            tags: {
              bsonType: "array",
              items: {
                bsonType: "string",
                maxLength: 50
              },
              description: "Budget tags for categorization"
            },
            notes: {
              bsonType: "string",
              maxLength: 1000,
              description: "Additional notes about the budget"
            },
            created_at: {
              bsonType: "date",
              description: "Creation timestamp"
            },
            updated_at: {
              bsonType: "date",
              description: "Last update timestamp"
            },
            created_by: {
              bsonType: "objectId",
              description: "User who created the budget"
            },
            updated_by: {
              bsonType: "objectId",
              description: "User who last updated the budget"
            }
          }
        }
      }
    };
  }

  /**
   * Create a new budget
   */
  static async create(db, budgetData) {
    // Validate date range
    const startDate = new Date(budgetData.period_start);
    const endDate = new Date(budgetData.period_end);
    
    if (startDate >= endDate) {
      throw new Error('Start date must be before end date');
    }

    // Check for overlapping budgets of same type and scope
    const overlapping = await this.findOverlapping(db, budgetData);
    if (overlapping.length > 0) {
      throw new Error('Budget overlaps with existing budget of same type and scope');
    }

    const budget = {
      name: budgetData.name,
      description: budgetData.description || '',
      budget_type: budgetData.budget_type,
      amount: parseFloat(budgetData.amount),
      currency: budgetData.currency || 'USD',
      period_start: startDate,
      period_end: endDate,
      frequency: budgetData.frequency || 'one-time',
      scope: budgetData.scope || { scope_type: 'company' },
      categories: budgetData.categories || [],
      thresholds: {
        warning_threshold: budgetData.thresholds?.warning_threshold || 80,
        critical_threshold: budgetData.thresholds?.critical_threshold || 95,
        alert_recipients: budgetData.thresholds?.alert_recipients ? 
          budgetData.thresholds.alert_recipients.map(id => new ObjectId(id)) : []
      },
      status: budgetData.status || 'draft',
      actual_spending: {
        total_spent: 0,
        last_calculated: null,
        category_spending: []
      },
      variance_analysis: {
        variance_amount: 0,
        variance_percentage: 0,
        trend: 'on_track',
        projected_total: 0
      },
      approval_workflow: budgetData.approval_workflow || { requires_approval: false },
      auto_refresh: budgetData.auto_refresh || false,
      refresh_config: budgetData.refresh_config || null,
      tags: budgetData.tags || [],
      notes: budgetData.notes || '',
      created_at: new Date(),
      updated_at: new Date(),
      created_by: new ObjectId(budgetData.created_by)
    };

    // Validate and normalize categories
    if (budget.categories.length > 0) {
      let totalPercentage = 0;
      let totalAmount = 0;

      budget.categories.forEach(category => {
        if (category.percentage) {
          totalPercentage += category.percentage;
          category.allocated_amount = (budget.amount * category.percentage) / 100;
        } else if (category.allocated_amount) {
          totalAmount += category.allocated_amount;
          category.percentage = (category.allocated_amount / budget.amount) * 100;
        }
      });

      if (totalPercentage > 100) {
        throw new Error('Total category percentages cannot exceed 100%');
      }

      if (totalAmount > budget.amount) {
        throw new Error('Total category amounts cannot exceed budget amount');
      }
    }

    const result = await db.collection('budgets').insertOne(budget);
    return { ...budget, _id: result.insertedId };
  }

  /**
   * Find overlapping budgets
   */
  static async findOverlapping(db, budgetData) {
    const startDate = new Date(budgetData.period_start);
    const endDate = new Date(budgetData.period_end);

    return await db.collection('budgets').find({
      budget_type: budgetData.budget_type,
      status: { $ne: 'cancelled' },
      $or: [
        {
          period_start: { $lte: endDate },
          period_end: { $gte: startDate }
        }
      ],
      // Add scope matching logic here if needed
      'scope.scope_type': budgetData.scope?.scope_type || 'company'
    }).toArray();
  }

  /**
   * Find budget by ID
   */
  static async findById(db, budgetId) {
    return await db.collection('budgets').findOne({
      _id: new ObjectId(budgetId)
    });
  }

  /**
   * Find budgets by criteria
   */
  static async find(db, criteria = {}, options = {}) {
    const filter = {};

    if (criteria.budget_type) {
      filter.budget_type = criteria.budget_type;
    }

    if (criteria.status) {
      filter.status = criteria.status;
    }

    if (criteria.active_only) {
      const now = new Date();
      filter.period_start = { $lte: now };
      filter.period_end = { $gte: now };
      filter.status = { $in: ['active', 'exceeded'] };
    }

    if (criteria.year) {
      const startOfYear = new Date(criteria.year, 0, 1);
      const endOfYear = new Date(criteria.year, 11, 31, 23, 59, 59);
      filter.$or = [
        {
          period_start: { $gte: startOfYear, $lte: endOfYear }
        },
        {
          period_end: { $gte: startOfYear, $lte: endOfYear }
        },
        {
          period_start: { $lte: startOfYear },
          period_end: { $gte: endOfYear }
        }
      ];
    }

    if (criteria.scope_type) {
      filter['scope.scope_type'] = criteria.scope_type;
    }

    return await db.collection('budgets')
      .find(filter)
      .sort({ period_start: -1 })
      .limit(options.limit || 50)
      .skip(options.skip || 0)
      .toArray();
  }

  /**
   * Update budget
   */
  static async update(db, budgetId, updateData) {
    const budget = await this.findById(db, budgetId);
    if (!budget) {
      throw new Error('Budget not found');
    }

    // Prevent updates to completed or cancelled budgets
    if (budget.status === 'completed' || budget.status === 'cancelled') {
      throw new Error('Cannot update completed or cancelled budget');
    }

    // Handle date updates
    if (updateData.period_start) {
      updateData.period_start = new Date(updateData.period_start);
    }
    if (updateData.period_end) {
      updateData.period_end = new Date(updateData.period_end);
    }

    // Validate date range if both dates are being updated
    if (updateData.period_start && updateData.period_end) {
      if (updateData.period_start >= updateData.period_end) {
        throw new Error('Start date must be before end date');
      }
    }

    const result = await db.collection('budgets').updateOne(
      { _id: new ObjectId(budgetId) },
      {
        $set: {
          ...updateData,
          updated_at: new Date(),
          updated_by: new ObjectId(updateData.updated_by)
        }
      }
    );

    return result.modifiedCount > 0;
  }

  /**
   * Calculate actual spending against budget
   */
  static async calculateActualSpending(db, budgetId) {
    const budget = await this.findById(db, budgetId);
    if (!budget) {
      throw new Error('Budget not found');
    }

    // Build aggregation pipeline based on budget scope and type
    const matchStage = {
      calculation_date: {
        $gte: budget.period_start,
        $lte: budget.period_end
      },
      status: { $in: ['approved', 'paid'] }
    };

    // Apply scope filters
    if (budget.scope.scope_type !== 'company') {
      if (budget.scope.employee_ids && budget.scope.employee_ids.length > 0) {
        matchStage.employee_id = { $in: budget.scope.employee_ids };
      }
      
      // For branch/department scope, we need to lookup employees
      if (budget.scope.branch_ids || budget.scope.department_names) {
        const employeeFilter = {};
        
        if (budget.scope.branch_ids) {
          employeeFilter['branch.branch_id'] = { $in: budget.scope.branch_ids };
        }
        
        if (budget.scope.department_names) {
          employeeFilter.department = { $in: budget.scope.department_names };
        }

        const scopeEmployees = await db.collection('users').find(
          employeeFilter,
          { projection: { _id: 1 } }
        ).toArray();
        
        matchStage.employee_id = { $in: scopeEmployees.map(emp => emp._id) };
      }
    }

    // Calculate total spending
    const totalPipeline = [
      { $match: matchStage },
      {
        $group: {
          _id: null,
          total_gross_pay: { $sum: '$gross_pay' },
          total_deductions: { $sum: '$total_deductions' },
          total_taxes: { $sum: '$taxes.total_taxes' },
          total_net_pay: { $sum: '$net_pay' },
          total_regular_pay: { $sum: '$regular_pay' },
          total_overtime_pay: { $sum: '$overtime_pay' }
        }
      }
    ];

    const totalResult = await db.collection('payroll_calculations').aggregate(totalPipeline).toArray();
    const totals = totalResult[0] || {
      total_gross_pay: 0,
      total_deductions: 0,
      total_taxes: 0,
      total_net_pay: 0,
      total_regular_pay: 0,
      total_overtime_pay: 0
    };

    // Determine total spent based on budget type
    let totalSpent = 0;
    switch (budget.budget_type) {
      case 'payroll_total':
        totalSpent = totals.total_gross_pay;
        break;
      case 'overtime':
        totalSpent = totals.total_overtime_pay;
        break;
      case 'deductions':
        totalSpent = totals.total_deductions;
        break;
      case 'taxes':
        totalSpent = totals.total_taxes;
        break;
      default:
        totalSpent = totals.total_gross_pay;
    }

    // Calculate category spending if categories are defined
    const categorySpending = [];
    if (budget.categories && budget.categories.length > 0) {
      for (const category of budget.categories) {
        let categorySpent = 0;
        
        // Map category names to actual spending data
        switch (category.category_name) {
          case 'regular_pay':
            categorySpent = totals.total_regular_pay;
            break;
          case 'overtime':
            categorySpent = totals.total_overtime_pay;
            break;
          case 'deductions':
            categorySpent = totals.total_deductions;
            break;
          case 'taxes':
            categorySpent = totals.total_taxes;
            break;
          default:
            categorySpent = 0;
        }

        categorySpending.push({
          category_name: category.category_name,
          spent_amount: parseFloat(categorySpent.toFixed(2)),
          percentage_used: category.allocated_amount > 0 ? 
            parseFloat(((categorySpent / category.allocated_amount) * 100).toFixed(2)) : 0
        });
      }
    }

    // Calculate variance and trend
    const varianceAmount = budget.amount - totalSpent;
    const variancePercentage = budget.amount > 0 ? 
      parseFloat(((varianceAmount / budget.amount) * 100).toFixed(2)) : 0;
    
    const percentageUsed = budget.amount > 0 ? 
      parseFloat(((totalSpent / budget.amount) * 100).toFixed(2)) : 0;

    let trend = 'on_track';
    if (percentageUsed >= budget.thresholds.critical_threshold) {
      trend = 'critical';
    } else if (percentageUsed >= budget.thresholds.warning_threshold) {
      trend = 'over';
    } else if (percentageUsed < 50) {
      trend = 'under';
    }

    // Project total spending (simple linear projection)
    const daysElapsed = moment().diff(moment(budget.period_start), 'days');
    const totalDays = moment(budget.period_end).diff(moment(budget.period_start), 'days');
    const projectedTotal = totalDays > 0 && daysElapsed > 0 ? 
      parseFloat(((totalSpent / daysElapsed) * totalDays).toFixed(2)) : totalSpent;

    // Update budget with calculated values
    const actualSpending = {
      total_spent: parseFloat(totalSpent.toFixed(2)),
      last_calculated: new Date(),
      category_spending: categorySpending
    };

    const varianceAnalysis = {
      variance_amount: parseFloat(varianceAmount.toFixed(2)),
      variance_percentage: variancePercentage,
      trend: trend,
      projected_total: projectedTotal
    };

    // Determine new status
    let newStatus = budget.status;
    if (totalSpent > budget.amount) {
      newStatus = 'exceeded';
    } else if (moment().isAfter(moment(budget.period_end))) {
      newStatus = 'completed';
    } else if (budget.status === 'draft') {
      newStatus = 'active';
    }

    await db.collection('budgets').updateOne(
      { _id: budget._id },
      {
        $set: {
          actual_spending: actualSpending,
          variance_analysis: varianceAnalysis,
          status: newStatus,
          updated_at: new Date()
        }
      }
    );

    return {
      budget_id: budgetId,
      actual_spending: actualSpending,
      variance_analysis: varianceAnalysis,
      status: newStatus
    };
  }

  /**
   * Check budget thresholds and create alerts
   */
  static async checkThresholds(db, budgetId) {
    const budget = await this.findById(db, budgetId);
    if (!budget || !budget.actual_spending) {
      return [];
    }

    const percentageUsed = budget.amount > 0 ? 
      (budget.actual_spending.total_spent / budget.amount) * 100 : 0;

    const alerts = [];

    // Check critical threshold
    if (percentageUsed >= budget.thresholds.critical_threshold) {
      // Check if critical alert already exists for this budget
      const existingAlert = await db.collection('alerts').findOne({
        'related_entity.entity_type': 'budget',
        'related_entity.entity_id': budget._id,
        alert_type: 'budget_exceeded',
        status: { $in: ['active', 'acknowledged'] }
      });

      if (!existingAlert) {
        alerts.push({
          type: 'critical',
          threshold: budget.thresholds.critical_threshold,
          actual: percentageUsed
        });
      }
    }
    // Check warning threshold
    else if (percentageUsed >= budget.thresholds.warning_threshold) {
      const existingAlert = await db.collection('alerts').findOne({
        'related_entity.entity_type': 'budget',
        'related_entity.entity_id': budget._id,
        alert_type: 'budget_exceeded',
        status: { $in: ['active', 'acknowledged'] }
      });

      if (!existingAlert) {
        alerts.push({
          type: 'warning',
          threshold: budget.thresholds.warning_threshold,
          actual: percentageUsed
        });
      }
    }

    return alerts;
  }

  /**
   * Approve budget
   */
  static async approve(db, budgetId, approvedBy, approvalNotes = '') {
    const result = await db.collection('budgets').updateOne(
      { 
        _id: new ObjectId(budgetId),
        'approval_workflow.requires_approval': true,
        status: 'draft'
      },
      {
        $set: {
          'approval_workflow.approved_by': new ObjectId(approvedBy),
          'approval_workflow.approved_at': new Date(),
          'approval_workflow.approval_notes': approvalNotes,
          status: 'active',
          updated_at: new Date(),
          updated_by: new ObjectId(approvedBy)
        }
      }
    );

    return result.modifiedCount > 0;
  }

  /**
   * Get budget summary for period
   */
  static async getSummary(db, startDate, endDate, options = {}) {
    const matchStage = {
      $or: [
        {
          period_start: { $gte: new Date(startDate), $lte: new Date(endDate) }
        },
        {
          period_end: { $gte: new Date(startDate), $lte: new Date(endDate) }
        },
        {
          period_start: { $lte: new Date(startDate) },
          period_end: { $gte: new Date(endDate) }
        }
      ]
    };

    if (options.budget_type) {
      matchStage.budget_type = options.budget_type;
    }

    if (options.status) {
      matchStage.status = options.status;
    }

    const pipeline = [
      { $match: matchStage },
      {
        $group: {
          _id: '$status',
          count: { $sum: 1 },
          total_budgeted: { $sum: '$amount' },
          total_spent: { $sum: '$actual_spending.total_spent' },
          avg_variance: { $avg: '$variance_analysis.variance_percentage' }
        }
      }
    ];

    const results = await db.collection('budgets').aggregate(pipeline).toArray();
    
    return {
      period: { start_date: startDate, end_date: endDate },
      summary: results
    };
  }

  /**
   * Delete budget (only if draft)
   */
  static async delete(db, budgetId) {
    const result = await db.collection('budgets').deleteOne({
      _id: new ObjectId(budgetId),
      status: 'draft'
    });

    return result.deletedCount > 0;
  }

  /**
   * Get budgets requiring attention
   */
  static async getRequiringAttention(db) {
    const now = new Date();
    
    return await db.collection('budgets').find({
      status: { $in: ['active', 'exceeded'] },
      period_end: { $gte: now },
      $or: [
        { 'variance_analysis.trend': { $in: ['over', 'critical'] } },
        { status: 'exceeded' },
        { 'approval_workflow.requires_approval': true, status: 'draft' }
      ]
    }).sort({ 'variance_analysis.variance_percentage': 1 }).toArray();
  }
}

module.exports = Budget;