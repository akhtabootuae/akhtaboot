const { ObjectId } = require('mongodb');

/**
 * Stage Model
 * Provides structure and methods for Stage data
 */
class Stage {
  /**
   * Get MongoDB schema validation for stages collection
   * @returns {Object} MongoDB schema validation object
   */
  static getSchema() {
    return {
      validator: {
        $jsonSchema: {
          bsonType: "object",
          required: ["name", "description", "order", "created_at", "updated_at"],
          properties: {
            name: {
              bsonType: "string",
              description: "Human-readable stage name (e.g. 'Disassembly')"
            },
            description: {
              bsonType: "string",
              description: "What happens in this stage"
            },
            order: {
              bsonType: "int",
              description: "1-based ordering for the workflow"
            },
            created_at: {
              bsonType: "date",
              description: "Date when the stage was created"
            },
            updated_at: {
              bsonType: "date",
              description: "Date when the stage was last updated"
            }
          }
        }
      }
    };
  }

  /**
   * Create a new stage
   * @param {Object} db - MongoDB database instance
   * @param {Object} stageData - Stage data to create
   * @returns {Object} Created stage
   */
  static async create(db, stageData) {
    const now = new Date();
    const newStage = {
      ...stageData,
      created_at: now,
      updated_at: now
    };

    const result = await db.collection('stages').insertOne(newStage);
    return { _id: result.insertedId, ...newStage };
  }

  /**
   * Get all stages
   * @param {Object} db - MongoDB database instance
   * @returns {Array} Array of stages
   */
  static async getAll(db) {
    return await db.collection('stages').find().sort({ order: 1 }).toArray();
  }

  /**
   * Get stage by ID
   * @param {Object} db - MongoDB database instance
   * @param {String} id - Stage ID
   * @returns {Object} Stage document
   */
  static async getById(db, id) {
    return await db.collection('stages').findOne({ _id: new ObjectId(id) });
  }

  /**
   * Update a stage
   * @param {Object} db - MongoDB database instance
   * @param {String} id - Stage ID
   * @param {Object} stageData - Updated stage data
   * @returns {Object} Updated stage
   */
  static async update(db, id, stageData) {
    const updatedStage = {
      ...stageData,
      updated_at: new Date()
    };

    await db.collection('stages').updateOne(
      { _id: new ObjectId(id) },
      { $set: updatedStage }
    );

    return { _id: new ObjectId(id), ...updatedStage };
  }

  /**
   * Delete a stage
   * @param {Object} db - MongoDB database instance
   * @param {String} id - Stage ID
   * @returns {Boolean} True if successful
   */
  static async delete(db, id) {
    const result = await db.collection('stages').deleteOne({ _id: new ObjectId(id) });
    return result.deletedCount > 0;
  }
}

module.exports = Stage;
