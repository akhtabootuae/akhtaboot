const { ObjectId, Double, Int32 } = require('mongodb');
const Customer = require('./Customer');
const Expense = require('./Expense');
const { deleteFromS3, getSignedUrl } = require('../middleware/s3Upload');

/**
 * Invoice Model
 * Provides structure and methods for Invoice data
 */
class Invoice {
  /**
   * Get MongoDB schema validation for invoices collection
   * @returns {Object} MongoDB schema validation object
   */
  static getSchema() {
    return {
      validator: {
        $jsonSchema: {
          bsonType: "object",
          required: [
            "invoice_number",
            "customer_id",
            "vehicle_id",
            "branch_id",
            "invoice_date",
            "price",
            "vat",
            "isTaxed",
            "price_before_vat",
            "vat_amount",
            "total_price",
            "payment_records",
            "created_at",
            "updated_at"
          ],
          properties: {
            invoice_number: {
              bsonType: "string",
              pattern: "^INV-[0-9]{7}$",
              description: "must be a string in format INV-XXXXXXX where X is a digit and is required"
            },
            customer_id: {
              bsonType: "objectId",
              description: "must be an objectId reference to a customer and is required"
            },
            branch_id: {
              bsonType: "objectId",
              description: "must be an objectId reference to a branch and is required"
            },
            vehicle_id: {
              bsonType: "int",
              description: "must be an integer identifying which vehicle of the customer and is required"
            },
            work_order_id: {
              bsonType: "objectId",
              description: "reference to related work order"
            },
            invoice_date: {
              bsonType: "date",
              description: "date when invoice was created and is required"
            },
            expected_delivery_date: {
              bsonType: "date",
              description: "expected date of delivery"
            },
            price: {
              bsonType: "double",
              description: "base price of the invoice before VAT and is required"
            },
            isTaxed: {
              bsonType: "bool",
              description: "indicates whether VAT should be applied to this invoice and is required"
            },
            price_before_vat: {
              bsonType: "double",
              description: "price before VAT (same as price) and is required"
            },
            vat_amount: {
              bsonType: "double",
              description: "calculated VAT amount and is required"
            },
            total_price: {
              bsonType: "double",
              description: "final total price including VAT and is required"
            },
            real_value: {
              bsonType: "double",
              description: "total amount of payments received for this invoice (card payments have 2.65% fee deducted)"
            },
            vat: {
              bsonType: "double",
              minimum: 0,
              maximum: 100,
              description: "VAT percentage (default 5%)"
            },
            ratio: {
              bsonType: "double",
              description: "ratio value associated with the invoice"
            },
            payment_records: {
              bsonType: "array",
              description: "array of payment record sub-documents",
              items: {
                bsonType: "object",
                required: ["payment_date", "amount", "payment_method"],
                properties: {
                  payment_date: {
                    bsonType: "date",
                    description: "date when payment was made"
                  },
                  amount: {
                    bsonType: "double",
                    description: "amount paid in this payment"
                  },
                  payment_method: {
                    bsonType: "string",
                    description: "method of payment (cash, card, bank transfer, etc.)"
                  },
                  is_downpayment: {
                    bsonType: "bool",
                    description: "indicates if this payment is a downpayment"
                  },
                  reference: {
                    bsonType: "string",
                    description: "payment reference number if applicable"
                  },
                  notes: {
                    bsonType: "string",
                    description: "any notes about this payment"
                  }
                }
              }
            },
            images: {
              bsonType: "array",
              description: "array of image sub-documents",
              items: {
                bsonType: "object",
                required: ["url", "upload_date"],
                properties: {
                  url: {
                    bsonType: "string",
                    description: "S3 URL to the image file"
                  },
                  key: {
                    bsonType: "string",
                    description: "S3 key for the image file"
                  },
                  filename: {
                    bsonType: "string",
                    description: "original filename of the image"
                  },
                  size: {
                    bsonType: "int",
                    description: "file size in bytes"
                  },
                  title: {
                    bsonType: "string",
                    description: "title/name of the image"
                  },
                  description: {
                    bsonType: "string",
                    description: "description of the image"
                  },
                  upload_date: {
                    bsonType: "date",
                    description: "date when image was uploaded"
                  }
                }
              }
            },
            notes: {
              bsonType: "string",
              description: "general notes about the invoice"
            },
            special_requests: {
              bsonType: "string",
              description: "any special requests related to this invoice"
            },
            external_services: {
              bsonType: "array",
              description: "array of external service sub-documents",
              items: {
                bsonType: "object",
                required: ["cost", "profit", "created_at"],
                properties: {
                  cost: {
                    bsonType: "double",
                    minimum: 0,
                    description: "cost of the external service"
                  },
                  profit: {
                    bsonType: "double",
                    minimum: 0,
                    description: "profit from the external service"
                  },
                  expense_id: {
                    bsonType: "objectId",
                    description: "reference to the expense record created for this service cost"
                  },
                  invoice_image: {
                    bsonType: "object",
                    description: "uploaded invoice image details",
                    properties: {
                      url: {
                        bsonType: "string",
                        description: "S3 URL to the invoice image file"
                      },
                      key: {
                        bsonType: "string",
                        description: "S3 key for the invoice image file"
                      },
                      filename: {
                        bsonType: "string",
                        description: "original filename of the invoice image"
                      },
                      size: {
                        bsonType: "int",
                        description: "file size in bytes"
                      },
                      upload_date: {
                        bsonType: "date",
                        description: "date when image was uploaded"
                      }
                    }
                  },
                  notes: {
                    bsonType: "string",
                    description: "notes about the external service"
                  },
                  created_at: {
                    bsonType: "date",
                    description: "when the external service record was created"
                  }
                }
              }
            },
            signed_invoice: {
              bsonType: "object",
              description: "uploaded signed invoice document details",
              properties: {
                url: {
                  bsonType: "string",
                  description: "S3 URL to the signed invoice file"
                },
                key: {
                  bsonType: "string",
                  description: "S3 key for the signed invoice file"
                },
                filename: {
                  bsonType: "string",
                  description: "original filename of the signed invoice"
                },
                size: {
                  bsonType: "int",
                  description: "file size in bytes"
                },
                upload_date: {
                  bsonType: "date",
                  description: "date when signed invoice was uploaded"
                }
              }
            },
            signed_job_order: {
              bsonType: "object",
              description: "uploaded signed job order document details",
              properties: {
                url: {
                  bsonType: "string",
                  description: "S3 URL to the signed job order file"
                },
                key: {
                  bsonType: "string",
                  description: "S3 key for the signed job order file"
                },
                filename: {
                  bsonType: "string",
                  description: "original filename of the signed job order"
                },
                size: {
                  bsonType: "int",
                  description: "file size in bytes"
                },
                upload_date: {
                  bsonType: "date",
                  description: "date when signed job order was uploaded"
                }
              }
            },
            created_at: {
              bsonType: "date",
              description: "When the invoice record was created"
            },
            updated_at: {
              bsonType: "date",
              description: "When the invoice record was last updated"
            }
          }
        }
      }
    };
  }

  /**
   * Generate a unique invoice number in the format INV-XXXXXXX
   * @param {Object} db MongoDB database connection
   * @returns {string} Unique invoice number
   */
  static async generateInvoiceNumber(db) {
    // Use atomic findOneAndUpdate with $inc to prevent race conditions
    // when multiple invoices are created concurrently
    const counter = await db.collection('counters').findOneAndUpdate(
      { _id: 'invoice_number' },
      { $inc: { sequence: 1 } },
      { upsert: true, returnDocument: 'after' }
    );

    let nextNumber = counter.sequence || counter.value?.sequence;

    // If this is the first time using the counter, initialize from existing invoices
    if (nextNumber === 1) {
      const lastInvoice = await db.collection('invoices')
        .find({}, { projection: { invoice_number: 1 } })
        .sort({ invoice_number: -1 })
        .limit(1)
        .toArray();

      if (lastInvoice.length > 0) {
        const lastNumberStr = lastInvoice[0].invoice_number.split('-')[1];
        const lastNumber = parseInt(lastNumberStr, 10);
        if (lastNumber >= nextNumber) {
          // Update the counter to match existing data
          const updated = await db.collection('counters').findOneAndUpdate(
            { _id: 'invoice_number' },
            { $set: { sequence: lastNumber + 1 } },
            { returnDocument: 'after' }
          );
          nextNumber = updated.sequence || updated.value?.sequence;
        }
      }
    }

    // Format the invoice number with leading zeros
    return `INV-${nextNumber.toString().padStart(7, '0')}`;
  }

  /**
   * Generate a unique payment reference number in the format PAY-XXXXXX
   * @param {Object} db MongoDB database connection
   * @returns {string} Unique payment reference number
   */
  static async generatePaymentReference(db) {
    // Get all invoices and find the highest payment reference number
    const allInvoices = await db.collection('invoices')
      .find({ payment_records: { $exists: true, $ne: [] } })
      .toArray();
    
    let nextNumber = 1;
    let highestRefNumber = 0;
    
    // Iterate through all payment records to find the highest reference number
    allInvoices.forEach(invoice => {
      if (invoice.payment_records && Array.isArray(invoice.payment_records)) {
        invoice.payment_records.forEach(payment => {
          if (payment.reference && payment.reference.startsWith('PAY-')) {
            const refNumber = parseInt(payment.reference.split('-')[1], 10);
            if (!isNaN(refNumber) && refNumber > highestRefNumber) {
              highestRefNumber = refNumber;
            }
          }
        });
      }
    });
    
    nextNumber = highestRefNumber + 1;
    
    // Format the payment reference with leading zeros
    return `PAY-${nextNumber.toString().padStart(6, '0')}`;
  }

  /**
   * Create a new invoice
   * @param {Object} db MongoDB database connection
   * @param {Object} invoiceData Invoice data to create
   * @returns {Object} Created invoice
   */
  static async create(db, invoiceData) {
    // Add timestamps
    const timestamp = new Date();
    
    // Generate invoice number if not provided
    if (!invoiceData.invoice_number) {
      invoiceData.invoice_number = await Invoice.generateInvoiceNumber(db);
    }
    
    // Set VAT to 5% if not provided
    if (!invoiceData.vat) {
      invoiceData.vat = 5;
    }
    
    // Ensure payment_records array exists
    if (!invoiceData.payment_records) {
      invoiceData.payment_records = [];
    }
    
    // Ensure images array exists
    if (!invoiceData.images) {
      invoiceData.images = [];
    }
    
    // Convert string customer_id to ObjectId if needed
    if (typeof invoiceData.customer_id === 'string') {
      invoiceData.customer_id = new ObjectId(invoiceData.customer_id);
    }
    
    // Set default branch if not provided
    if (!invoiceData.branch_id) {
      // Get the default Sharjah branch
      const defaultBranch = await db.collection('branches').findOne({ branch_code: "SJH" });
      if (defaultBranch) {
        invoiceData.branch_id = defaultBranch._id;
      } else {
        // Fallback to any available branch if Sharjah branch doesn't exist
        const anyBranch = await db.collection('branches').findOne({});
        if (anyBranch) {
          invoiceData.branch_id = anyBranch._id;
        }
      }
    }
    
    // Convert string branch_id to ObjectId if needed
    if (typeof invoiceData.branch_id === 'string') {
      invoiceData.branch_id = new ObjectId(invoiceData.branch_id);
    }
    
    // Convert string work_order_id to ObjectId if provided
    if (invoiceData.work_order_id && typeof invoiceData.work_order_id === 'string') {
      invoiceData.work_order_id = new ObjectId(invoiceData.work_order_id);
    }
    
    // Ensure vehicle_id is an Int32 as required by schema
    if (invoiceData.vehicle_id !== undefined) {
      try {
        invoiceData.vehicle_id = new Int32(parseInt(invoiceData.vehicle_id, 10));
      } catch (error) {
        console.error(`Error converting vehicle_id to Int32: ${error.message}`);
        throw new Error(`Invalid vehicle_id: ${invoiceData.vehicle_id}. Must be a valid integer.`);
      }
    }
    
    // Convert date strings to Date objects
    if (invoiceData.invoice_date && typeof invoiceData.invoice_date === 'string') {
      invoiceData.invoice_date = new Date(invoiceData.invoice_date);
    }
    
    if (invoiceData.expected_delivery_date && typeof invoiceData.expected_delivery_date === 'string') {
      invoiceData.expected_delivery_date = new Date(invoiceData.expected_delivery_date);
    }
     // Force numeric fields to be stored as doubles (floating-point) as required by schema
    // Using MongoDB Double type explicitly to ensure correct BSON type
    if (invoiceData.price !== undefined) {
      invoiceData.price = new Double(invoiceData.price);
    }

    if (invoiceData.vat !== undefined) {
      invoiceData.vat = new Double(invoiceData.vat);
    }

    // Convert string boolean values to actual boolean for isTaxed
    if (invoiceData.isTaxed !== undefined) {
      if (typeof invoiceData.isTaxed === 'string') {
        invoiceData.isTaxed = invoiceData.isTaxed.toLowerCase() === 'true';
      }
    } else {
      invoiceData.isTaxed = true; // Default to taxed
    }

    // Calculate and store VAT-related fields
    const basePrice = invoiceData.price || 0;
    const vatPercentage = invoiceData.vat || 5; // Default 5% VAT
    
    // Always store price_before_vat (same as base price)
    invoiceData.price_before_vat = new Double(basePrice);
    
    // Calculate VAT amount and total based on isTaxed flag
    if (invoiceData.isTaxed) {
      invoiceData.vat_amount = new Double(basePrice * (vatPercentage / 100));
      invoiceData.total_price = new Double(basePrice + (basePrice * (vatPercentage / 100)));
    } else {
      invoiceData.vat_amount = new Double(0);
      invoiceData.total_price = new Double(basePrice);
    }
    
    // Set real_value - defaults to total_price if not provided
    if (invoiceData.real_value !== undefined) {
      invoiceData.real_value = new Double(invoiceData.real_value);
    } else {
      invoiceData.real_value = new Double(invoiceData.total_price);
    }
    
    if (invoiceData.ratio !== undefined) {
      invoiceData.ratio = new Double(invoiceData.ratio);
    }
    
    // Convert payment dates in payment records and ensure amount is a double using MongoDB Double
    if (Array.isArray(invoiceData.payment_records)) {
      // Process payment records to auto-generate references if needed
      for (let i = 0; i < invoiceData.payment_records.length; i++) {
        const payment = invoiceData.payment_records[i];
        
        // Auto-generate reference if not provided
        if (!payment.reference) {
          payment.reference = await Invoice.generatePaymentReference(db);
        }
        
        if (payment.payment_date && typeof payment.payment_date === 'string') {
          payment.payment_date = new Date(payment.payment_date);
        }
        
        if (payment.amount !== undefined) {
          payment.amount = new Double(payment.amount);
        }
      }
    }
    
    const newInvoice = {
      ...invoiceData,
      created_at: timestamp,
      updated_at: timestamp
    };
    
    try {
      // Log the document before insertion for debugging
      console.log('Attempting to insert invoice with data:', JSON.stringify(newInvoice, (key, value) => {
        // Handle special MongoDB types in the log
        if (value instanceof ObjectId) return `ObjectId("${value}")`;
        if (value instanceof Double) return `Double(${value})`;
        if (value instanceof Int32) return `Int32(${value})`;
        if (value instanceof Date) return `Date("${value.toISOString()}")`;
        return value;
      }, 2));
      
      const result = await db.collection('invoices').insertOne(newInvoice);
      return { ...newInvoice, _id: result.insertedId };
    } catch (error) {
      console.error('Invoice creation error:', error);
      
      // More detailed error logging for document validation failures
      if (error.code === 121) {
        console.error('Validation error details:', JSON.stringify(error.errInfo?.details, null, 2));
      }
      
      throw error;
    }
  }

  /**
   * Get invoice by ID
   * @param {Object} db MongoDB database connection
   * @param {string} id Invoice ID
   * @returns {Object} Invoice document
   */
  static async getById(db, id) {
    return db.collection('invoices').findOne({ _id: new ObjectId(id) });
  }

  /**
   * Get invoice by invoice number
   * @param {Object} db MongoDB database connection
   * @param {string} invoiceNumber Invoice number
   * @returns {Object} Invoice document
   */
  static async getByInvoiceNumber(db, invoiceNumber) {
    return db.collection('invoices').findOne({ invoice_number: invoiceNumber });
  }

  /**
   * Get invoices for a specific customer
   * @param {Object} db MongoDB database connection
   * @param {string} customerId Customer ID
   * @returns {Array} Array of invoice documents
   */
  static async getByCustomerId(db, customerId) {
    return db.collection('invoices')
      .find({ customer_id: new ObjectId(customerId) })
      .toArray();
  }

  /**
   * Get invoices for a specific branch
   * @param {Object} db MongoDB database connection
   * @param {string} branchId Branch ID
   * @returns {Array} Array of invoice documents
   */
  static async getByBranchId(db, branchId) {
    return db.collection('invoices')
      .find({ branch_id: new ObjectId(branchId) })
      .toArray();
  }

  /**
   * Update invoice by ID
   * @param {Object} db MongoDB database connection
   * @param {string} id Invoice ID
   * @param {Object} updateData Update data
   * @returns {Object} Update result
   */
  static async updateById(db, id, updateData) {
    const timestamp = new Date();
    
    // Don't allow direct updates to payment_records array or images array
    const { payment_records, images, ...updates } = updateData;
    
    // Convert string branch_id to ObjectId if provided
    if (updates.branch_id && typeof updates.branch_id === 'string') {
      updates.branch_id = new ObjectId(updates.branch_id);
    }
    
    // Convert string work_order_id to ObjectId if provided
    if (updates.work_order_id && typeof updates.work_order_id === 'string') {
      updates.work_order_id = new ObjectId(updates.work_order_id);
    }

    // Force numeric fields to be stored as doubles
    if (updates.price !== undefined) {
      updates.price = new Double(updates.price);
    }

    if (updates.vat !== undefined) {
      updates.vat = new Double(updates.vat);
    }

    if (updates.real_value !== undefined) {
      updates.real_value = new Double(updates.real_value);
    }

    // Convert string boolean values to actual boolean for isTaxed
    if (updates.isTaxed !== undefined && typeof updates.isTaxed === 'string') {
      updates.isTaxed = updates.isTaxed.toLowerCase() === 'true';
    }

    // Check if we need to recalculate VAT-related fields
    const needsVatRecalculation = updates.price !== undefined || 
                                  updates.vat !== undefined || 
                                  updates.isTaxed !== undefined;

    if (needsVatRecalculation) {
      // Get current invoice to get missing values
      const currentInvoice = await db.collection('invoices').findOne({ _id: new ObjectId(id) });
      if (!currentInvoice) {
        throw new Error('Invoice not found');
      }

      // Use updated values or fall back to current values
      const basePrice = updates.price !== undefined ? updates.price : currentInvoice.price;
      const vatPercentage = updates.vat !== undefined ? updates.vat : (currentInvoice.vat || 5);
      const isTaxed = updates.isTaxed !== undefined ? updates.isTaxed : 
                      (currentInvoice.isTaxed !== undefined ? currentInvoice.isTaxed : true);

      // Recalculate VAT-related fields
      updates.price_before_vat = new Double(basePrice);
      
      if (isTaxed) {
        updates.vat_amount = new Double(basePrice * (vatPercentage / 100));
        updates.total_price = new Double(basePrice + (basePrice * (vatPercentage / 100)));
      } else {
        updates.vat_amount = new Double(0);
        updates.total_price = new Double(basePrice);
      }
    }
    
    const result = await db.collection('invoices').updateOne(
      { _id: new ObjectId(id) },
      { 
        $set: {
          ...updates,
          updated_at: timestamp
        } 
      }
    );
    
    return result;
  }

  /**
   * Delete invoice by ID
   * @param {Object} db MongoDB database connection
   * @param {string} id Invoice ID
   * @returns {Object} Delete result
   */
  static async deleteById(db, id) {
    // Get the invoice first to check for external service images and signed documents
    const invoice = await db.collection('invoices').findOne({ _id: new ObjectId(id) });
    
    if (invoice) {
      const deletePromises = [];
      
      // Delete all S3 images for external services
      if (invoice.external_services && invoice.external_services.length > 0) {
        const imageKeys = invoice.external_services
          .filter(service => service.invoice_image && service.invoice_image.key)
          .map(service => service.invoice_image.key);
        
        if (imageKeys.length > 0) {
          deletePromises.push(
            ...imageKeys.map(key => deleteFromS3(key))
          );
        }
      }
      
      // Delete signed invoice from S3 if it exists
      if (invoice.signed_invoice && invoice.signed_invoice.key) {
        deletePromises.push(deleteFromS3(invoice.signed_invoice.key));
      }
      
      // Delete signed job order from S3 if it exists
      if (invoice.signed_job_order && invoice.signed_job_order.key) {
        deletePromises.push(deleteFromS3(invoice.signed_job_order.key));
      }
      
      // Execute all S3 deletions
      if (deletePromises.length > 0) {
        try {
          await Promise.all(deletePromises);
          console.log(`Successfully deleted ${deletePromises.length} files from S3`);
        } catch (error) {
          console.error('Failed to delete some files from S3:', error);
          // Continue with invoice deletion even if S3 cleanup fails
        }
      }
    }
    
    return db.collection('invoices').deleteOne({ _id: new ObjectId(id) });
  }
  
  /**
   * Add a payment record to an invoice
   * @param {Object} db MongoDB database connection
   * @param {string} invoiceId Invoice ID
   * @param {Object} paymentData Payment data
   * @returns {Object} Update result
   */
  static async addPaymentRecord(db, invoiceId, paymentData) {
    const timestamp = new Date();
    
    // Validate required fields
    if (!paymentData.payment_method || typeof paymentData.payment_method !== 'string') {
      throw new Error('Payment method is required and must be a string');
    }
    
    if (paymentData.amount === undefined || paymentData.amount === null) {
      throw new Error('Payment amount is required');
    }
    
    // Clean up the payment data - remove empty optional fields
    const cleanPaymentData = { ...paymentData };
    
    // Remove empty notes field if it's an empty string
    if (cleanPaymentData.notes === '') {
      delete cleanPaymentData.notes;
    }
    
    // Auto-generate payment reference if not provided
    if (!cleanPaymentData.reference) {
      cleanPaymentData.reference = await Invoice.generatePaymentReference(db);
    }
    
    // Ensure payment date is a Date object
    if (!cleanPaymentData.payment_date) {
      cleanPaymentData.payment_date = new Date();
    } else if (typeof cleanPaymentData.payment_date === 'string') {
      cleanPaymentData.payment_date = new Date(cleanPaymentData.payment_date);
    }
    
    // Ensure amount is a valid number and convert to Double type as required by schema
    const numericAmount = Number(cleanPaymentData.amount);
    if (isNaN(numericAmount) || numericAmount < 0) {
      throw new Error('Payment amount must be a valid positive number');
    }
    cleanPaymentData.amount = new Double(numericAmount);
    
    const result = await db.collection('invoices').updateOne(
      { _id: new ObjectId(invoiceId) },
      { 
        $push: { payment_records: cleanPaymentData },
        $set: { updated_at: timestamp }
      }
    );
    
    // Update real_value based on total payments received only if the payment was successfully added
    if (result.modifiedCount > 0) {
      try {
        await Invoice.updateRealValue(db, invoiceId);
      } catch (realValueError) {
        console.error('Warning: Failed to update real_value after adding payment:', realValueError.message);
        // Don't throw here - the payment was successfully added, just the real_value update failed
      }
    }
    
    return result;
  }
  
  /**
   * Update a payment record in an invoice
   * @param {Object} db MongoDB database connection
   * @param {string} invoiceId Invoice ID
   * @param {number} index Index of the payment record in the array
   * @param {Object} updateData Payment record update data
   * @returns {Object} Update result
   */
  static async updatePaymentRecord(db, invoiceId, index, updateData) {
    const timestamp = new Date();
    
    // If reference is being cleared or not provided, auto-generate one
    if (!updateData.reference || updateData.reference === '') {
      updateData.reference = await Invoice.generatePaymentReference(db);
    }
    
    // Create update object with dot notation for the specific array element
    const updates = {};
    Object.entries(updateData).forEach(([key, value]) => {
      // Convert date strings to Date objects
      if (key === 'payment_date' && typeof value === 'string') {
        value = new Date(value);
      }
      // Convert amount to Double type
      if (key === 'amount' && value !== undefined) {
        value = new Double(value);
      }
      updates[`payment_records.${index}.${key}`] = value;
    });
    
    updates.updated_at = timestamp;
    
    const result = await db.collection('invoices').updateOne(
      { _id: new ObjectId(invoiceId) },
      { $set: updates }
    );
    
    // Update real_value based on total payments received
    if (result.modifiedCount > 0) {
      try {
        await Invoice.updateRealValue(db, invoiceId);
      } catch (realValueError) {
        console.error('Warning: Failed to update real_value after updating payment:', realValueError.message);
        // Don't throw here - the payment was successfully updated, just the real_value update failed
      }
    }
    
    return result;
  }
  
  /**
   * Remove a payment record from an invoice
   * @param {Object} db MongoDB database connection
   * @param {string} invoiceId Invoice ID
   * @param {number} index Index of the payment record in the array
   * @returns {Object} Update result
   */
  static async removePaymentRecord(db, invoiceId, index) {
    const timestamp = new Date();
    
    // First get the invoice to access its payment records
    const invoice = await Invoice.getById(db, invoiceId);
    
    if (!invoice || !invoice.payment_records || index >= invoice.payment_records.length) {
      throw new Error('Payment record not found');
    }
    
    // Remove the payment record at the specified index
    invoice.payment_records.splice(index, 1);
    
    // Update the invoice with the modified payment_records array
    const result = await db.collection('invoices').updateOne(
      { _id: new ObjectId(invoiceId) },
      { 
        $set: { 
          payment_records: invoice.payment_records,
          updated_at: timestamp
        }
      }
    );
    
    // Update real_value based on total payments received
    if (result.modifiedCount > 0) {
      try {
        await Invoice.updateRealValue(db, invoiceId);
      } catch (realValueError) {
        console.error('Warning: Failed to update real_value after removing payment:', realValueError.message);
        // Don't throw here - the payment was successfully removed, just the real_value update failed
      }
    }
    
    return result;
  }
  
  /**
   * Add an image to an invoice
   * @param {Object} db MongoDB database connection
   * @param {string} invoiceId Invoice ID
   * @param {Object} imageData Image data
   * @returns {Object} Update result
   */
  static async addImage(db, invoiceId, imageData) {
    const timestamp = new Date();
    
    // Ensure upload date is a Date object
    if (!imageData.upload_date) {
      imageData.upload_date = timestamp;
    } else if (typeof imageData.upload_date === 'string') {
      imageData.upload_date = new Date(imageData.upload_date);
    }
    
    return db.collection('invoices').updateOne(
      { _id: new ObjectId(invoiceId) },
      { 
        $push: { images: imageData },
        $set: { updated_at: timestamp }
      }
    );
  }
  
  /**
   * Remove an image from an invoice
   * @param {Object} db MongoDB database connection
   * @param {string} invoiceId Invoice ID
   * @param {string} imageUrl URL of the image to remove
   * @returns {Object} Update result
   */
  static async removeImage(db, invoiceId, imageUrl) {
    const timestamp = new Date();
    
    return db.collection('invoices').updateOne(
      { _id: new ObjectId(invoiceId) },
      { 
        $pull: { images: { url: imageUrl } },
        $set: { updated_at: timestamp }
      }
    );
  }
  
  /**
   * Get invoice data with customer and vehicle details for PDF generation
   * @param {Object} db MongoDB database connection
   * @param {string} invoiceId Invoice ID
   * @returns {Object} Object containing invoice, customer, and vehicle details
   */
  static async getInvoiceDataForPDF(db, invoiceId) {
    // Get the invoice document
    const invoice = await Invoice.getById(db, invoiceId);
    
    if (!invoice) {
      throw new Error(`Invoice with ID ${invoiceId} not found`);
    }
    
    // Get customer information
    const customer = await db.collection('customers').findOne({ _id: invoice.customer_id });
    
    if (!customer) {
      throw new Error(`Customer with ID ${invoice.customer_id} not found`);
    }
    
    // Get branch information
    let branch = null;
    if (invoice.branch_id) {
      branch = await db.collection('branches').findOne({ _id: invoice.branch_id });
    }
    
    // Find the vehicle in customer's vehicles array
    let vehicle = null;
    if (Array.isArray(customer.vehicles) && customer.vehicles.length > 0) {
      vehicle = customer.vehicles.find(v => v.vehicle_id === invoice.vehicle_id);
    }
    
    // Prepare formatted customer data for PDF
    // Ensure the customer name is properly set from available fields
    let customerName = '';
    if (customer.first_name && customer.last_name) {
      customerName = `${customer.first_name} ${customer.last_name}`;
    } else if (customer.name) {
      customerName = customer.name;
    } else if (customer.first_name) {
      customerName = customer.first_name;
    } else if (customer.last_name) {
      customerName = customer.last_name;
    }
    
    const formattedCustomer = {
      name: customerName,
      phone: customer.phone || '',
      email: customer.email || '',
      city: customer.city || '',
      country: customer.country || ''
    };
    
    // Debug log
    console.log('Formatted customer data:', formattedCustomer);
    
    // Add vehicle details to invoice
    let enhancedInvoice = { ...invoice };
    
    // Add branch TRN to invoice for PDF generation
    if (branch && branch.trn) {
      enhancedInvoice.branch_trn = branch.trn;
    }
    
    if (vehicle) {
      enhancedInvoice.car_type = `${vehicle.make} ${vehicle.model} (${vehicle.year})`;
      enhancedInvoice.license_plate = vehicle.license_plate || '';
      enhancedInvoice.vehicle_color = vehicle.color || '';
    }
    
    // Add work order number if there's a linked work order
    if (invoice.work_order_id) {
      try {
        const workOrder = await db.collection('work_orders').findOne({ _id: invoice.work_order_id });
        if (workOrder && workOrder.workOrderNumber) {
          enhancedInvoice.work_order_number = workOrder.workOrderNumber;
        }
      } catch (error) {
        console.error('Error fetching work order:', error);
      }
    }
    
    // Final debug log before returning the data
    console.log('Final customer data for PDF:', { 
      customerName: formattedCustomer.name,
      hasName: !!formattedCustomer.name,
      nameLength: formattedCustomer.name?.length 
    });
    
    return {
      invoice: enhancedInvoice,
      customer: formattedCustomer,
      vehicle: vehicle,
      branch: branch
    };
  }
  
  /**
   * Add an external service to an invoice
   * @param {Object} db MongoDB database connection
   * @param {string} invoiceId Invoice ID
   * @param {Object} serviceData External service data
   * @param {string} userId User ID of the person adding the service (for expense tracking)
   * @returns {Object} Update result with expense_id
   */
  static async addExternalService(db, invoiceId, serviceData, userId) {
    const timestamp = new Date();
    
    // Get the current invoice to calculate new total
    const currentInvoice = await db.collection('invoices').findOne({ _id: new ObjectId(invoiceId) });
    if (!currentInvoice) {
      throw new Error('Invoice not found');
    }
    
    // Prepare the external service object
    const externalService = {
      cost: new Double(parseFloat(serviceData.cost)),
      profit: new Double(parseFloat(serviceData.profit)),
      notes: serviceData.notes || '',
      created_at: timestamp
    };
    
    // Add invoice image if provided
    if (serviceData.invoice_image) {
      externalService.invoice_image = {
        ...serviceData.invoice_image,
        upload_date: timestamp
      };
    }
    
    // Calculate the external service total (cost + profit)
    const externalServiceTotal = externalService.cost + externalService.profit;
    
    // Create an expense record for the cost of this external service
    let expenseId = null;
    if (externalService.cost > 0 && userId) {
      try {
        const expenseData = {
          title: `External Service Cost - Invoice ${currentInvoice.invoice_number}`,
          description: `Cost for external service on invoice ${currentInvoice.invoice_number}. ${serviceData.notes ? 'Notes: ' + serviceData.notes : ''}`,
          amount: parseFloat(serviceData.cost),
          expense_type: 'external_service',
          date: timestamp,
          created_by: new ObjectId(userId),
          branch_id: currentInvoice.branch_id,
          vendor: serviceData.vendor || 'External Service Provider',
          status: 'submitted',
          related_invoice_id: new ObjectId(invoiceId),
          tags: ['external_service', 'auto_generated']
        };

        // Only add invoice_number if it has a value
        if (serviceData.vendor_invoice_number) {
          expenseData.invoice_number = serviceData.vendor_invoice_number;
        }

        // Handle invoice image for expense - create a proper structure if image exists
        if (serviceData.invoice_image) {
          expenseData.invoice_image = {
            s3Key: serviceData.invoice_image.key,
            url: serviceData.invoice_image.url,
            filename: serviceData.invoice_image.filename || 'external_service_invoice.jpg',
            mimetype: serviceData.invoice_image.mimetype || 'image/jpeg',
            size: serviceData.invoice_image.size || 0,
            uploadedAt: timestamp
          };
        } else {
          // Create a placeholder invoice image since it's required by schema
          expenseData.invoice_image = {
            s3Key: 'placeholder',
            url: 'placeholder',
            filename: 'auto_generated_expense.txt',
            mimetype: 'text/plain',
            size: 0,
            uploadedAt: timestamp
          };
        }

        const createdExpense = await Expense.create(db, expenseData);
        expenseId = createdExpense._id;
        
        // Add expense reference to the external service
        externalService.expense_id = expenseId;
        
        console.log(`Created expense record ${expenseId} for external service cost of ${serviceData.cost}`);
      } catch (error) {
        console.error('Failed to create expense for external service:', error);
        // Continue with external service creation even if expense creation fails
      }
    }
    
    const updateResult = await db.collection('invoices').updateOne(
      { _id: new ObjectId(invoiceId) },
      { 
        $push: { external_services: externalService },
        $set: { 
          updated_at: timestamp 
        }
      }
    );
    
    // Recalculate tax after adding external service
    await Invoice.recalculateTax(db, invoiceId);
    
    return {
      ...updateResult,
      expense_id: expenseId
    };
  }
  
  /**
   * Remove an external service from an invoice and update total price
   * @param {Object} db - Database connection
   * @param {string} invoiceId - Invoice ID
   * @param {number} serviceIndex - Index of the service to remove
   * @returns {Object} Update result
   */
  static async removeExternalService(db, invoiceId, serviceIndex) {
    const timestamp = new Date();
    
    // Get the current invoice
    const currentInvoice = await db.collection('invoices').findOne({ _id: new ObjectId(invoiceId) });
    if (!currentInvoice) {
      throw new Error('Invoice not found');
    }
    
    if (!currentInvoice.external_services || serviceIndex >= currentInvoice.external_services.length || serviceIndex < 0) {
      throw new Error('Invalid service index or no external services found');
    }
    
    // Get the service to remove and calculate its total
    const serviceToRemove = currentInvoice.external_services[serviceIndex];
    const serviceTotal = parseFloat(serviceToRemove.cost) + parseFloat(serviceToRemove.profit);
    
    // Delete the associated expense if it exists
    if (serviceToRemove.expense_id) {
      try {
        await db.collection('expenses').deleteOne({ _id: serviceToRemove.expense_id });
        console.log(`Successfully deleted associated expense: ${serviceToRemove.expense_id}`);
      } catch (error) {
        console.error(`Failed to delete associated expense: ${serviceToRemove.expense_id}`, error);
        // Continue with the removal even if expense deletion fails
      }
    }
    
    // Delete the S3 image if it exists
    if (serviceToRemove.invoice_image && serviceToRemove.invoice_image.key) {
      try {
        await deleteFromS3(serviceToRemove.invoice_image.key);
        console.log(`Successfully deleted S3 image: ${serviceToRemove.invoice_image.key}`);
      } catch (error) {
        console.error(`Failed to delete S3 image: ${serviceToRemove.invoice_image.key}`, error);
        // Continue with the removal even if S3 deletion fails
      }
    }
    
    // Calculate new total price by subtracting the service total
    const currentTotal = parseFloat(currentInvoice.total_price) || 0;
    const newTotalPrice = Math.max(0, currentTotal - serviceTotal); // Ensure total doesn't go negative
    
    // Remove the service from the array
    const updatedServices = [...currentInvoice.external_services];
    updatedServices.splice(serviceIndex, 1);
    
    const updateResult = await db.collection('invoices').updateOne(
      { _id: new ObjectId(invoiceId) },
      { 
        $set: { 
          external_services: updatedServices,
          updated_at: timestamp 
        }
      }
    );
    
    // Recalculate tax after removing external service
    await Invoice.recalculateTax(db, invoiceId);
    
    return updateResult;
  }
  
  /**
   * Set the real value (price after deductions) for an invoice manually
   * @param {Object} db MongoDB database connection
   * @param {string} invoiceId Invoice ID
   * @param {number} realValue The real value after deductions
   * @returns {Object} Update result
   */
  static async setRealValue(db, invoiceId, realValue) {
    const timestamp = new Date();
    
    return db.collection('invoices').updateOne(
      { _id: new ObjectId(invoiceId) },
      { 
        $set: { 
          real_value: new Double(realValue),
          updated_at: timestamp 
        }
      }
    );
  }

  /**
   * Calculate deductions for an invoice
   * @param {Object} db MongoDB database connection
   * @param {string} invoiceId Invoice ID
   * @returns {Object} Object containing total_price, real_value, and deductions
   */
  static async calculateDeductions(db, invoiceId) {
    const invoice = await db.collection('invoices').findOne({ _id: new ObjectId(invoiceId) });
    
    if (!invoice) {
      throw new Error('Invoice not found');
    }
    
    const totalPrice = parseFloat(invoice.total_price) || 0;
    const realValue = parseFloat(invoice.real_value) || totalPrice;
    const deductions = totalPrice - realValue;
    
    return {
      total_price: totalPrice,
      real_value: realValue,
      deductions: deductions
    };
  }

  /**
   * Recalculate total price including all external services
   * @param {Object} db - Database connection
   * @param {string} invoiceId - Invoice ID
   * @returns {Object} Update result
   */
  static async recalculateTotal(db, invoiceId) {
    const timestamp = new Date();
    
    // Get the current invoice
    const currentInvoice = await db.collection('invoices').findOne({ _id: new ObjectId(invoiceId) });
    if (!currentInvoice) {
      throw new Error('Invoice not found');
    }
    
    // Calculate base price (original invoice total without external services)
    let basePrice = parseFloat(currentInvoice.price_before_vat) || parseFloat(currentInvoice.price) || 0;
    
    // Add VAT if applicable
    const vatPercentage = parseFloat(currentInvoice.vat) || 0;
    if (vatPercentage > 0) {
      basePrice = basePrice + (basePrice * (vatPercentage / 100));
    }
    
    // Add all external services totals
    let externalServicesTotal = 0;
    if (currentInvoice.external_services && Array.isArray(currentInvoice.external_services)) {
      externalServicesTotal = currentInvoice.external_services.reduce((total, service) => {
        return total + (parseFloat(service.cost) || 0) + (parseFloat(service.profit) || 0);
      }, 0);
    }
    
    const newTotalPrice = basePrice + externalServicesTotal;
    
    return db.collection('invoices').updateOne(
      { _id: new ObjectId(invoiceId) },
      { 
        $set: { 
          total_price: new Double(newTotalPrice),
          updated_at: timestamp 
        }
      }
    );
  }

  /**
   * Add a signed invoice document to an invoice
   * @param {Object} db MongoDB database connection
   * @param {string} invoiceId Invoice ID
   * @param {Object} signedInvoiceData Signed invoice file data
   * @returns {Object} Update result
   */
  static async addSignedInvoice(db, invoiceId, signedInvoiceData) {
    const timestamp = new Date();
    
    // Check if invoice exists
    const currentInvoice = await db.collection('invoices').findOne({ _id: new ObjectId(invoiceId) });
    if (!currentInvoice) {
      throw new Error('Invoice not found');
    }

    // Delete existing signed invoice from S3 if it exists
    if (currentInvoice.signed_invoice && currentInvoice.signed_invoice.key) {
      try {
        await deleteFromS3(currentInvoice.signed_invoice.key);
        console.log(`Successfully deleted old signed invoice: ${currentInvoice.signed_invoice.key}`);
      } catch (error) {
        console.error(`Failed to delete old signed invoice: ${currentInvoice.signed_invoice.key}`, error);
        // Continue with the update even if S3 deletion fails
      }
    }
    
    // Prepare the signed invoice object
    const signedInvoice = {
      ...signedInvoiceData,
      upload_date: timestamp
    };

    return db.collection('invoices').updateOne(
      { _id: new ObjectId(invoiceId) },
      { 
        $set: { 
          signed_invoice: signedInvoice,
          updated_at: timestamp 
        }
      }
    );
  }

  /**
   * Remove a signed invoice document from an invoice
   * @param {Object} db MongoDB database connection
   * @param {string} invoiceId Invoice ID
   * @returns {Object} Update result
   */
  static async removeSignedInvoice(db, invoiceId) {
    const timestamp = new Date();
    
    // Get the current invoice
    const currentInvoice = await db.collection('invoices').findOne({ _id: new ObjectId(invoiceId) });
    if (!currentInvoice) {
      throw new Error('Invoice not found');
    }

    if (!currentInvoice.signed_invoice) {
      throw new Error('No signed invoice found');
    }

    // Delete the S3 file if it exists
    if (currentInvoice.signed_invoice.key) {
      try {
        await deleteFromS3(currentInvoice.signed_invoice.key);
        console.log(`Successfully deleted signed invoice: ${currentInvoice.signed_invoice.key}`);
      } catch (error) {
        console.error(`Failed to delete signed invoice: ${currentInvoice.signed_invoice.key}`, error);
        // Continue with the removal even if S3 deletion fails
      }
    }

    return db.collection('invoices').updateOne(
      { _id: new ObjectId(invoiceId) },
      { 
        $unset: { signed_invoice: "" },
        $set: { updated_at: timestamp }
      }
    );
  }

  /**
   * Add a signed job order document to an invoice
   * @param {Object} db MongoDB database connection
   * @param {string} invoiceId Invoice ID
   * @param {Object} signedJobOrderData Signed job order file data
   * @returns {Object} Update result
   */
  static async addSignedJobOrder(db, invoiceId, signedJobOrderData) {
    const timestamp = new Date();
    
    // Check if invoice exists
    const currentInvoice = await db.collection('invoices').findOne({ _id: new ObjectId(invoiceId) });
    if (!currentInvoice) {
      throw new Error('Invoice not found');
    }

    // Delete existing signed job order from S3 if it exists
    if (currentInvoice.signed_job_order && currentInvoice.signed_job_order.key) {
      try {
        await deleteFromS3(currentInvoice.signed_job_order.key);
        console.log(`Successfully deleted old signed job order: ${currentInvoice.signed_job_order.key}`);
      } catch (error) {
        console.error(`Failed to delete old signed job order: ${currentInvoice.signed_job_order.key}`, error);
        // Continue with the update even if S3 deletion fails
      }
    }
    
    // Prepare the signed job order object
    const signedJobOrder = {
      ...signedJobOrderData,
      upload_date: timestamp
    };

    return db.collection('invoices').updateOne(
      { _id: new ObjectId(invoiceId) },
      { 
        $set: { 
          signed_job_order: signedJobOrder,
          updated_at: timestamp 
        }
      }
    );
  }

  /**
   * Remove a signed job order document from an invoice
   * @param {Object} db MongoDB database connection
   * @param {string} invoiceId Invoice ID
   * @returns {Object} Update result
   */
  static async removeSignedJobOrder(db, invoiceId) {
    const timestamp = new Date();
    
    // Get the current invoice
    const currentInvoice = await db.collection('invoices').findOne({ _id: new ObjectId(invoiceId) });
    if (!currentInvoice) {
      throw new Error('Invoice not found');
    }

    if (!currentInvoice.signed_job_order) {
      throw new Error('No signed job order found');
    }

    // Delete the S3 file if it exists
    if (currentInvoice.signed_job_order.key) {
      try {
        await deleteFromS3(currentInvoice.signed_job_order.key);
        console.log(`Successfully deleted signed job order: ${currentInvoice.signed_job_order.key}`);
      } catch (error) {
        console.error(`Failed to delete signed job order: ${currentInvoice.signed_job_order.key}`, error);
        // Continue with the removal even if S3 deletion fails
      }
    }

    return db.collection('invoices').updateOne(
      { _id: new ObjectId(invoiceId) },
      { 
        $unset: { signed_job_order: "" },
        $set: { updated_at: timestamp }
      }
    );
  }

  /**
   * Get invoice by ID with signed URLs for images
   * @param {Object} db MongoDB database connection
   * @param {string} id Invoice ID
   * @returns {Object} Invoice document with signed URLs
   */
  static async getByIdWithSignedUrls(db, id) {
    const invoice = await db.collection('invoices').findOne({ _id: new ObjectId(id) });
    
    if (!invoice) {
      return null;
    }

    return await Invoice.generateSignedUrlsForInvoice(invoice);
  }

  /**
   * Generate signed URLs for all images in an invoice
   * @param {Object} invoice Invoice document
   * @returns {Object} Invoice with signed URLs added
   */
  static async generateSignedUrlsForInvoice(invoice) {
    try {
      // Generate signed URLs for main invoice images
      if (invoice.images && invoice.images.length > 0) {
        for (const image of invoice.images) {
          if (image.key) {
            try {
              image.signed_url = await getSignedUrl(image.key, 3600); // 1 hour expiry
            } catch (urlError) {
              console.error(`Error generating signed URL for image ${image.key}:`, urlError);
              // Keep image without signed URL if error occurs
            }
          }
        }
      }

      // Generate signed URLs for external service invoice images
      if (invoice.external_services && invoice.external_services.length > 0) {
        for (const service of invoice.external_services) {
          if (service.invoice_image && service.invoice_image.key) {
            try {
              service.invoice_image.signed_url = await getSignedUrl(service.invoice_image.key, 3600);
            } catch (urlError) {
              console.error(`Error generating signed URL for external service image ${service.invoice_image.key}:`, urlError);
              // Keep image without signed URL if error occurs
            }
          }
        }
      }

      // Generate signed URL for signed invoice document
      if (invoice.signed_invoice && invoice.signed_invoice.key) {
        try {
          invoice.signed_invoice.signed_url = await getSignedUrl(invoice.signed_invoice.key, 3600);
        } catch (urlError) {
          console.error(`Error generating signed URL for signed invoice ${invoice.signed_invoice.key}:`, urlError);
          // Keep document without signed URL if error occurs
        }
      }

      // Generate signed URL for signed job order document
      if (invoice.signed_job_order && invoice.signed_job_order.key) {
        try {
          invoice.signed_job_order.signed_url = await getSignedUrl(invoice.signed_job_order.key, 3600);
        } catch (urlError) {
          console.error(`Error generating signed URL for signed job order ${invoice.signed_job_order.key}:`, urlError);
          // Keep document without signed URL if error occurs
        }
      }

      return invoice;
    } catch (error) {
      console.error('Error generating signed URLs for invoice:', error);
      return invoice; // Return original invoice if error occurs
    }
  }

  /**
   * Recalculate tax (VAT) for an invoice based on current price, VAT percentage, and tax status
   * @param {Object} db MongoDB database connection
   * @param {string} invoiceId Invoice ID
   * @param {Object} options Optional parameters to override current values
   * @param {number} options.price Override the base price
   * @param {number} options.vat Override the VAT percentage
   * @param {boolean} options.isTaxed Override the tax status
   * @returns {Object} Update result
   */
  static async recalculateTax(db, invoiceId, options = {}) {
    const timestamp = new Date();
    
    // Get the current invoice
    const currentInvoice = await db.collection('invoices').findOne({ _id: new ObjectId(invoiceId) });
    if (!currentInvoice) {
      throw new Error('Invoice not found');
    }
    
    // Use provided options or fall back to current invoice values
    const basePrice = options.price !== undefined ? options.price : currentInvoice.price;
    const vatPercentage = options.vat !== undefined ? options.vat : (currentInvoice.vat || 5);
    const isTaxed = options.isTaxed !== undefined ? options.isTaxed : 
                    (currentInvoice.isTaxed !== undefined ? currentInvoice.isTaxed : true);
    
    // Calculate external services total
    let externalServicesTotal = 0;
    if (currentInvoice.external_services && Array.isArray(currentInvoice.external_services)) {
      externalServicesTotal = currentInvoice.external_services.reduce((total, service) => {
        return total + (parseFloat(service.cost) || 0) + (parseFloat(service.profit) || 0);
      }, 0);
    }
    
    // Calculate total amount before VAT (base price + external services)
    const totalBeforeVat = basePrice + externalServicesTotal;
    
    // Calculate VAT-related fields
    const updates = {};
    
    // Update the base price if provided in options
    if (options.price !== undefined) {
      updates.price = new Double(basePrice);
    }
    
    // Always store price_before_vat (same as base price)
    updates.price_before_vat = new Double(basePrice);
    updates.vat = new Double(vatPercentage);
    updates.isTaxed = isTaxed;
    
    // Calculate VAT amount and total based on isTaxed flag
    if (isTaxed) {
      // VAT should be calculated on the total amount (base price + external services)
      updates.vat_amount = new Double(totalBeforeVat * (vatPercentage / 100));
      updates.total_price = new Double(totalBeforeVat + (totalBeforeVat * (vatPercentage / 100)));
    } else {
      updates.vat_amount = new Double(0);
      updates.total_price = new Double(totalBeforeVat);
    }
    
    // Update the invoice - ensure all required fields are preserved
    const result = await db.collection('invoices').updateOne(
      { _id: new ObjectId(invoiceId) },
      { 
        $set: {
          ...updates,
          updated_at: timestamp
        }
      },
      { bypassDocumentValidation: false } // Ensure we validate but with proper field handling
    );
    
    return result;
  }

  /**
   * Add tax (VAT) to an invoice by setting it to taxed status
   * @param {Object} db MongoDB database connection
   * @param {string} invoiceId Invoice ID
   * @param {number} vatPercentage VAT percentage to apply (optional, defaults to current or 5%)
   * @returns {Object} Update result
   */
  static async addTax(db, invoiceId, vatPercentage = null) {
    const timestamp = new Date();
    
    // Get the current invoice
    const currentInvoice = await db.collection('invoices').findOne({ _id: new ObjectId(invoiceId) });
    if (!currentInvoice) {
      throw new Error('Invoice not found');
    }
    
    // Use provided VAT percentage or fall back to current or default 5%
    const vat = vatPercentage !== null ? vatPercentage : (currentInvoice.vat || 5);
    
    // Calculate external services total
    let externalServicesTotal = 0;
    if (currentInvoice.external_services && Array.isArray(currentInvoice.external_services)) {
      externalServicesTotal = currentInvoice.external_services.reduce((total, service) => {
        return total + (parseFloat(service.cost) || 0) + (parseFloat(service.profit) || 0);
      }, 0);
    }
    
    // Calculate total amount before VAT (base price + external services)
    const basePrice = parseFloat(currentInvoice.price) || 0;
    const totalBeforeVat = basePrice + externalServicesTotal;
    
    // Calculate VAT amount and total with VAT
    const vatAmount = totalBeforeVat * (vat / 100);
    const totalWithVat = totalBeforeVat + vatAmount;
    
    // Update VAT-related fields to add tax
    const updates = {
      isTaxed: true,
      vat: new Double(vat),
      vat_amount: new Double(vatAmount),
      total_price: new Double(totalWithVat),
      updated_at: timestamp
    };
    
    // Update the invoice
    const result = await db.collection('invoices').updateOne(
      { _id: new ObjectId(invoiceId) },
      { $set: updates }
    );
    
    return result;
  }

  /**
   * Remove tax (VAT) from an invoice by setting it to non-taxed status
   * @param {Object} db MongoDB database connection
   * @param {string} invoiceId Invoice ID
   * @returns {Object} Update result
   */
  static async removeTax(db, invoiceId) {
    const timestamp = new Date();
    
    // Get the current invoice
    const currentInvoice = await db.collection('invoices').findOne({ _id: new ObjectId(invoiceId) });
    if (!currentInvoice) {
      throw new Error('Invoice not found');
    }
    
    // Calculate external services total
    let externalServicesTotal = 0;
    if (currentInvoice.external_services && Array.isArray(currentInvoice.external_services)) {
      externalServicesTotal = currentInvoice.external_services.reduce((total, service) => {
        return total + (parseFloat(service.cost) || 0) + (parseFloat(service.profit) || 0);
      }, 0);
    }
    
    // Calculate total amount without VAT (base price + external services)
    const basePrice = parseFloat(currentInvoice.price) || 0;
    const totalWithoutVat = basePrice + externalServicesTotal;
    
    // Update VAT-related fields to remove tax
    const updates = {
      isTaxed: false,
      vat_amount: new Double(0),
      total_price: new Double(totalWithoutVat),
      updated_at: timestamp
    };
    
    // Update the invoice
    const result = await db.collection('invoices').updateOne(
      { _id: new ObjectId(invoiceId) },
      { $set: updates }
    );
    
    return result;
  }

  /**
   * Calculate total payments received for an invoice
   * @param {Array} paymentRecords Array of payment records
   * @returns {number} Total amount of payments received (with card payment fees deducted)
   */
  static calculateTotalPayments(paymentRecords) {
    if (!paymentRecords || !Array.isArray(paymentRecords)) {
      return 0;
    }
    
    return paymentRecords.reduce((total, payment) => {
      const amount = payment.amount || 0;
      const actualAmount = typeof amount === 'object' && amount.value !== undefined ? amount.value : Number(amount);
      
      // If payment method is card, deduct 2.65% fee
      if (payment.payment_method && payment.payment_method.toLowerCase() === 'card') {
        const amountAfterFee = actualAmount * (1 - 0.0265); // Subtract 2.65%
        return total + amountAfterFee;
      }
      
      return total + actualAmount;
    }, 0);
  }

  /**
   * Update real_value field based on total payments received
   * @param {Object} db MongoDB database connection
   * @param {string} invoiceId Invoice ID
   * @returns {Object} Update result
   */
  static async updateRealValue(db, invoiceId) {
    // Get current invoice to access payment records
    const invoice = await Invoice.getById(db, invoiceId);
    if (!invoice) {
      throw new Error('Invoice not found');
    }
    
    // Calculate total payments received
    const totalPayments = Invoice.calculateTotalPayments(invoice.payment_records);
    
    // Ensure totalPayments is a valid number
    const validTotalPayments = (isNaN(totalPayments) || totalPayments < 0) ? 0 : totalPayments;
    
    // Update real_value field
    return await db.collection('invoices').updateOne(
      { _id: new ObjectId(invoiceId) },
      { 
        $set: { 
          real_value: new Double(validTotalPayments),
          updated_at: new Date()
        }
      }
    );
  }
}

module.exports = Invoice;
