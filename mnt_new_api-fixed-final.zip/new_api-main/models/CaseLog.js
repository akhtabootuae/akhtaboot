const { ObjectId } = require('mongodb');

/**
 * CaseLog Model
 * Provides structure and methods for Case audit logging
 */
class CaseLog {
  /**
   * Get MongoDB schema validation for case_logs collection
   * @returns {Object} MongoDB schema validation object
   */
  static getSchema() {
    return {
      validator: {
        $jsonSchema: {
          bsonType: "object",
          required: [
            "user_id", "action", "entity_type", "timestamp"
          ],
          additionalProperties: true,
          properties: {
            user_id: { 
              bsonType: "objectId",
              description: "User who performed the action - must be a valid ObjectId and is required"
            },
            user_email: {
              bsonType: ["string", "null"],
              description: "Email of the user who performed the action"
            },
            action: {
              bsonType: "string",
              enum: [
                "create_case", "update_case", "delete_case", "view_case", "view_all_cases",
                "add_case_note", "remove_case_note", "upload_case_attachment", "remove_case_attachment",
                "assign_case", "unassign_case", "resolve_case", "close_case", "reopen_case",
                "change_case_priority", "change_case_status", "add_case_tag", "remove_case_tag",
                "link_case_entity", "unlink_case_entity", "view_case_stats", "export_case_data",
                "view_case_logs"
              ],
              description: "Action performed - must be one of the specified values and is required"
            },
            entity_type: {
              bsonType: "string",
              enum: ["case", "case_note", "case_attachment", "case_system", "case_analytics"],
              description: "Type of entity affected - must be one of the specified values and is required"
            },
            entity_id: {
              bsonType: ["objectId", "string", "null"],
              description: "ID of the entity affected (can be ObjectId, string, or null)"
            },
            timestamp: {
              bsonType: "date",
              description: "When the action occurred - must be a valid date and is required"
            },
            ip_address: {
              bsonType: ["string", "null"],
              description: "IP address from which the action was performed"
            },
            user_agent: {
              bsonType: ["string", "null"],
              description: "User agent string from the request"
            },
            details: {
              bsonType: "object",
              description: "Additional details about the action",
              additionalProperties: true,
              properties: {
                old_values: {
                  bsonType: ["object", "null"],
                  description: "Previous values before the change"
                },
                new_values: {
                  bsonType: ["object", "null"],
                  description: "New values after the change"
                },
                request_method: {
                  bsonType: ["string", "null"],
                  description: "HTTP method used (GET, POST, PUT, DELETE)"
                },
                endpoint: {
                  bsonType: ["string", "null"],
                  description: "API endpoint that was called"
                },
                error_message: {
                  bsonType: ["string", "null"],
                  description: "Error message if action failed"
                },
                success: {
                  bsonType: "bool",
                  description: "Whether the action was successful"
                },
                case_title: {
                  bsonType: ["string", "null"],
                  description: "Title of the case if relevant"
                },
                case_status: {
                  bsonType: ["string", "null"],
                  description: "Status of the case if relevant"
                },
                case_priority: {
                  bsonType: ["string", "null"],
                  description: "Priority of the case if relevant"
                },
                assigned_to: {
                  bsonType: ["objectId", "string", "null"],
                  description: "User assigned to the case if relevant"
                },
                linked_entity: {
                  bsonType: ["object", "null"],
                  description: "Information about linked entity if relevant",
                  properties: {
                    type: {
                      bsonType: "string",
                      description: "Type of linked entity"
                    },
                    id: {
                      bsonType: ["objectId", "string"],
                      description: "ID of linked entity"
                    },
                    reference: {
                      bsonType: ["string", "null"],
                      description: "Reference identifier"
                    }
                  }
                }
              }
            },
            session_id: {
              bsonType: ["string", "null"],
              description: "Session ID for tracking user sessions"
            },
            severity: {
              bsonType: "string",
              enum: ["low", "medium", "high", "critical"],
              description: "Severity level of the audit event"
            },
            category: {
              bsonType: "string",
              enum: ["authentication", "authorization", "data_access", "data_modification", "system"],
              description: "Category of the audit event"
            },
            branch_id: {
              bsonType: ["objectId", "null"],
              description: "Branch ID associated with the case action"
            }
          }
        }
      }
    };
  }

  /**
   * Create a new case log entry
   * @param {Object} db MongoDB database connection
   * @param {Object} logData Case log data
   * @returns {Object} Insert result
   */
  static async createLogEntry(db, logData) {
    // Log case entry creation for monitoring
    console.log('Creating case log entry:', logData.action, 'on', logData.entity_type);

    // Comprehensive validation before any processing
    const preValidationErrors = this.validateLogData(logData);
    if (preValidationErrors.length > 0) {
      console.error('Pre-validation failed:', preValidationErrors);
      throw new Error(`Case log data pre-validation failed: ${preValidationErrors.join(', ')}`);
    }

    // Handle case where user_id might be undefined or invalid
    if (!logData.user_id) {
      const error = new Error('user_id is required for case log entry');
      console.error('Missing user_id:', error.message);
      throw error;
    }
    
    // Ensure user_id is an ObjectId with comprehensive validation
    let userId;
    try {
      if (logData.user_id instanceof ObjectId) {
        userId = logData.user_id;
      } else if (typeof logData.user_id === 'string') {
        if (logData.user_id.length !== 24) {
          throw new Error(`Invalid ObjectId string length: ${logData.user_id.length}, expected 24`);
        }
        if (!/^[0-9a-fA-F]{24}$/.test(logData.user_id)) {
          throw new Error(`Invalid ObjectId string format: ${logData.user_id}`);
        }
        userId = new ObjectId(logData.user_id);
      } else {
        throw new Error(`user_id must be ObjectId or valid ObjectId string, got ${typeof logData.user_id}: ${logData.user_id}`);
      }
    } catch (error) {
      console.error('user_id validation failed:', {
        originalUserId: logData.user_id,
        type: typeof logData.user_id,
        error: error.message
      });
      throw new Error(`Invalid user_id format: ${error.message}`);
    }

    // Handle entity_id with proper validation
    let entityId = null;
    if (logData.entity_id) {
      if (logData.entity_id instanceof ObjectId) {
        entityId = logData.entity_id;
      } else if (typeof logData.entity_id === 'string') {
        if (logData.entity_id.length === 24 && /^[0-9a-fA-F]{24}$/.test(logData.entity_id)) {
          try {
            entityId = new ObjectId(logData.entity_id);
          } catch (entityError) {
            // Keep as string if ObjectId conversion fails
            console.warn('Entity ID kept as string due to conversion error:', entityError.message);
            entityId = logData.entity_id;
          }
        } else {
          // Keep non-ObjectId strings as strings
          entityId = logData.entity_id;
        }
      } else {
        console.warn('Unexpected entity_id type:', typeof logData.entity_id);
        entityId = logData.entity_id;
      }
    }

    // Handle branch_id validation
    let branchId = null;
    if (logData.branch_id) {
      try {
        if (logData.branch_id instanceof ObjectId) {
          branchId = logData.branch_id;
        } else if (typeof logData.branch_id === 'string' && logData.branch_id.length === 24) {
          branchId = new ObjectId(logData.branch_id);
        }
      } catch (branchError) {
        console.warn('Invalid branch_id, setting to null:', branchError.message);
        branchId = null;
      }
    }
    
    const caseLogEntry = {
      user_id: userId,
      user_email: logData.user_email || 'unknown',
      action: logData.action,
      entity_type: logData.entity_type,
      entity_id: entityId,
      timestamp: new Date(),
      ip_address: logData.ip_address || 'unknown',
      user_agent: logData.user_agent || 'unknown',
      details: logData.details || {},
      severity: logData.severity || 'low',
      category: logData.category || 'data_access',
      branch_id: branchId
    };

    // Only add session_id if it's a non-empty string
    if (logData.session_id && typeof logData.session_id === 'string') {
      caseLogEntry.session_id = logData.session_id;
    }

    // Log final validation check
    console.log('Validating case log entry before insertion');

    // Final validation against schema before inserting
    const finalValidationErrors = this.validateLogData(caseLogEntry);
    if (finalValidationErrors.length > 0) {
      console.error('Final validation failed:', finalValidationErrors);
      throw new Error(`Case log data final validation failed: ${finalValidationErrors.join(', ')}`);
    }

    try {
      const result = await db.collection('case_logs').insertOne(caseLogEntry);
      console.log('✅ Case log entry created successfully with ID:', result.insertedId);
      return result;
    } catch (insertError) {
      console.error('❌ MongoDB case log insertion failed:', insertError.message);
      
      // If we have detailed validation errors, log them for debugging
      if (insertError.errInfo?.details?.schemaRulesNotSatisfied) {
        console.error('Schema validation errors:', 
          JSON.stringify(insertError.errInfo.details.schemaRulesNotSatisfied, null, 2)
        );
      }
      
      throw insertError;
    }
  }

  /**
   * Find case logs with filters
   * @param {Object} db MongoDB database connection
   * @param {Object} filters Filter criteria
   * @param {Object} options Query options (limit, skip, sort)
   * @returns {Array} Array of case log entries
   */
  static async findCaseLogs(db, filters = {}, options = {}) {
    const { limit = 50, skip = 0, sort = { timestamp: -1 } } = options;
    
    const query = {};
    
    // Add filters
    if (filters.user_id) {
      query.user_id = new ObjectId(filters.user_id);
    }
    
    if (filters.action) {
      query.action = filters.action;
    }
    
    if (filters.entity_type) {
      query.entity_type = filters.entity_type;
    }
    
    if (filters.entity_id) {
      query.entity_id = typeof filters.entity_id === 'string' ? 
        filters.entity_id : new ObjectId(filters.entity_id);
    }

    if (filters.branch_id) {
      query.branch_id = new ObjectId(filters.branch_id);
    }
    
    if (filters.start_date || filters.end_date) {
      query.timestamp = {};
      if (filters.start_date) {
        query.timestamp.$gte = new Date(filters.start_date);
      }
      if (filters.end_date) {
        query.timestamp.$lte = new Date(filters.end_date);
      }
    }
    
    if (filters.severity) {
      query.severity = filters.severity;
    }
    
    if (filters.category) {
      query.category = filters.category;
    }

    return await db.collection('case_logs')
      .find(query)
      .sort(sort)
      .limit(limit)
      .skip(skip)
      .toArray();
  }

  /**
   * Count case logs with filters
   * @param {Object} db MongoDB database connection
   * @param {Object} filters Filter criteria
   * @returns {Number} Count of matching case log entries
   */
  static async countCaseLogs(db, filters = {}) {
    const query = {};
    
    // Add filters (same logic as findCaseLogs)
    if (filters.user_id) {
      query.user_id = new ObjectId(filters.user_id);
    }
    
    if (filters.action) {
      query.action = filters.action;
    }
    
    if (filters.entity_type) {
      query.entity_type = filters.entity_type;
    }
    
    if (filters.entity_id) {
      query.entity_id = typeof filters.entity_id === 'string' ? 
        filters.entity_id : new ObjectId(filters.entity_id);
    }

    if (filters.branch_id) {
      query.branch_id = new ObjectId(filters.branch_id);
    }
    
    if (filters.start_date || filters.end_date) {
      query.timestamp = {};
      if (filters.start_date) {
        query.timestamp.$gte = new Date(filters.start_date);
      }
      if (filters.end_date) {
        query.timestamp.$lte = new Date(filters.end_date);
      }
    }
    
    if (filters.severity) {
      query.severity = filters.severity;
    }
    
    if (filters.category) {
      query.category = filters.category;
    }

    return await db.collection('case_logs').countDocuments(query);
  }

  /**
   * Find case logs for a specific case
   * @param {Object} db MongoDB database connection
   * @param {ObjectId|string} caseId Case ObjectId or string
   * @param {Object} options Query options (limit, skip, sort)
   * @returns {Array} Array of case log entries for the case
   */
  static async findCaseLogsByCase(db, caseId, options = {}) {
    const { limit = 100, skip = 0, sort = { timestamp: -1 } } = options;
    
    const query = {
      entity_id: typeof caseId === 'string' ? caseId : new ObjectId(caseId),
      entity_type: 'case'
    };

    return await db.collection('case_logs')
      .find(query)
      .sort(sort)
      .limit(limit)
      .skip(skip)
      .toArray();
  }

  /**
   * Find recent case activity
   * @param {Object} db MongoDB database connection
   * @param {Number} hours Number of hours to look back (default 24)
   * @param {Number} limit Maximum number of entries to return
   * @returns {Array} Array of recent case log entries
   */
  static async findRecentActivity(db, hours = 24, limit = 100) {
    const startDate = new Date(Date.now() - (hours * 60 * 60 * 1000));
    
    return await db.collection('case_logs')
      .find({ 
        timestamp: { $gte: startDate }
      })
      .sort({ timestamp: -1 })
      .limit(limit)
      .toArray();
  }

  /**
   * Get case log statistics
   * @param {Object} db MongoDB database connection
   * @param {Date} startDate Start date for statistics
   * @param {Date} endDate End date for statistics
   * @returns {Object} Case log statistics
   */
  static async getCaseLogStatistics(db, startDate, endDate) {
    const pipeline = [
      {
        $match: {
          timestamp: {
            $gte: new Date(startDate),
            $lte: new Date(endDate)
          }
        }
      },
      {
        $group: {
          _id: null,
          total_actions: { $sum: 1 },
          unique_users: { $addToSet: "$user_id" },
          actions_by_type: {
            $push: "$action"
          },
          severity_counts: {
            $push: "$severity"
          }
        }
      },
      {
        $project: {
          total_actions: 1,
          unique_user_count: { $size: "$unique_users" },
          actions_by_type: 1,
          severity_counts: 1
        }
      }
    ];

    const result = await db.collection('case_logs').aggregate(pipeline).toArray();
    return result[0] || {
      total_actions: 0,
      unique_user_count: 0,
      actions_by_type: [],
      severity_counts: []
    };
  }

  /**
   * Delete old case logs (for data retention)
   * @param {Object} db MongoDB database connection
   * @param {Date} beforeDate Delete logs before this date
   * @returns {Object} Delete result
   */
  static async deleteOldLogs(db, beforeDate) {
    return await db.collection('case_logs').deleteMany({
      timestamp: { $lt: new Date(beforeDate) }
    });
  }

  /**
   * Validate case log data
   * @param {Object} logData Case log data to validate
   * @returns {Array} Array of validation errors (empty if valid)
   */
  static validateLogData(logData) {
    const errors = [];

    if (!logData.user_id) {
      errors.push('User ID is required');
    }

    if (!logData.action) {
      errors.push('Action is required');
    }

    if (!logData.entity_type) {
      errors.push('Entity type is required');
    }

    const validActions = [
      'create_case', 'update_case', 'delete_case', 'view_case', 'view_all_cases',
      'add_case_note', 'remove_case_note', 'upload_case_attachment', 'remove_case_attachment',
      'assign_case', 'unassign_case', 'resolve_case', 'close_case', 'reopen_case',
      'change_case_priority', 'change_case_status', 'add_case_tag', 'remove_case_tag',
      'link_case_entity', 'unlink_case_entity', 'view_case_stats', 'export_case_data'
    ];
    if (logData.action && !validActions.includes(logData.action)) {
      errors.push(`Action must be one of: ${validActions.join(', ')}`);
    }

    const validEntityTypes = ['case', 'case_note', 'case_attachment', 'case_system', 'case_analytics'];
    if (logData.entity_type && !validEntityTypes.includes(logData.entity_type)) {
      errors.push(`Entity type must be one of: ${validEntityTypes.join(', ')}`);
    }

    return errors;
  }
}

module.exports = CaseLog;
