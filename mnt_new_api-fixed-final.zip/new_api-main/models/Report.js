const { ObjectId } = require('mongodb');
const moment = require('moment');

class Report {
  /**
   * Get collection validation schema for MongoDB
   */
  static getSchema() {
    return {
      validator: {
        $jsonSchema: {
          bsonType: "object",
          required: ["report_name", "report_type", "generated_by", "generation_date"],
          properties: {
            report_name: {
              bsonType: "string",
              maxLength: 200,
              description: "Name of the report"
            },
            report_type: {
              bsonType: "string",
              enum: [
                "payroll_summary", "employee_earnings", "deduction_summary", 
                "tax_summary", "attendance_summary", "pay_period_summary",
                "ytd_summary", "custom_report", "compliance_report"
              ],
              description: "Type of report"
            },
            description: {
              bsonType: "string",
              maxLength: 500,
              description: "Report description"
            },
            parameters: {
              bsonType: "object",
              properties: {
                start_date: {
                  bsonType: "date",
                  description: "Report start date"
                },
                end_date: {
                  bsonType: "date",
                  description: "Report end date"
                },
                employee_ids: {
                  bsonType: "array",
                  items: {
                    bsonType: "objectId"
                  },
                  description: "Specific employees to include"
                },
                pay_period_ids: {
                  bsonType: "array",
                  items: {
                    bsonType: "objectId"
                  },
                  description: "Specific pay periods to include"
                },
                branch_id: {
                  bsonType: "objectId",
                  description: "Specific branch to filter by"
                },
                department: {
                  bsonType: "string",
                  description: "Department filter"
                },
                include_terminated: {
                  bsonType: "bool",
                  description: "Include terminated employees"
                },
                group_by: {
                  bsonType: "string",
                  enum: ["employee", "department", "branch", "pay_period", "month", "quarter"],
                  description: "How to group the data"
                },
                filters: {
                  bsonType: "object",
                  description: "Additional filters"
                }
              },
              description: "Report generation parameters"
            },
            data: {
              bsonType: "object",
              properties: {
                summary: {
                  bsonType: "object",
                  description: "Report summary data"
                },
                details: {
                  bsonType: "array",
                  description: "Detailed report data"
                },
                totals: {
                  bsonType: "object",
                  description: "Report totals and aggregations"
                },
                charts: {
                  bsonType: "array",
                  items: {
                    bsonType: "object",
                    properties: {
                      chart_type: {
                        bsonType: "string",
                        enum: ["bar", "line", "pie", "table"]
                      },
                      title: {
                        bsonType: "string"
                      },
                      data: {
                        bsonType: "array"
                      }
                    }
                  },
                  description: "Chart data for visualization"
                }
              },
              description: "Report data and results"
            },
            format: {
              bsonType: "string",
              enum: ["json", "csv", "xlsx", "pdf"],
              description: "Report output format"
            },
            file_path: {
              bsonType: "string",
              description: "Path to generated report file"
            },
            file_size: {
              bsonType: "int",
              minimum: 0,
              description: "Size of generated file in bytes"
            },
            status: {
              bsonType: "string",
              enum: ["generating", "completed", "failed", "expired"],
              description: "Report generation status"
            },
            generation_date: {
              bsonType: "date",
              description: "When the report was generated"
            },
            generation_time_ms: {
              bsonType: "int",
              minimum: 0,
              description: "Time taken to generate report in milliseconds"
            },
            expiry_date: {
              bsonType: "date",
              description: "When the report expires"
            },
            download_count: {
              bsonType: "int",
              minimum: 0,
              description: "Number of times report was downloaded"
            },
            last_downloaded: {
              bsonType: "date",
              description: "Last download timestamp"
            },
            error_message: {
              bsonType: "string",
              maxLength: 1000,
              description: "Error message if generation failed"
            },
            generated_by: {
              bsonType: "objectId",
              description: "User who generated the report"
            },
            shared_with: {
              bsonType: "array",
              items: {
                bsonType: "object",
                properties: {
                  user_id: {
                    bsonType: "objectId"
                  },
                  shared_at: {
                    bsonType: "date"
                  },
                  permissions: {
                    bsonType: "array",
                    items: {
                      bsonType: "string",
                      enum: ["view", "download", "share"]
                    }
                  }
                }
              },
              description: "Users the report is shared with"
            },
            tags: {
              bsonType: "array",
              items: {
                bsonType: "string",
                maxLength: 50
              },
              description: "Report tags for categorization"
            },
            is_scheduled: {
              bsonType: "bool",
              description: "Whether this is a scheduled report"
            },
            schedule_config: {
              bsonType: "object",
              properties: {
                frequency: {
                  bsonType: "string",
                  enum: ["daily", "weekly", "monthly", "quarterly", "yearly"]
                },
                next_run: {
                  bsonType: "date"
                },
                last_run: {
                  bsonType: "date"
                },
                recipients: {
                  bsonType: "array",
                  items: {
                    bsonType: "string"
                  }
                }
              },
              description: "Scheduled report configuration"
            },
            generated_files: {
              bsonType: "array",
              items: {
                bsonType: "object",
                properties: {
                  file_path: {
                    bsonType: "string",
                    description: "Path to the generated file"
                  },
                  file_size: {
                    bsonType: "int",
                    minimum: 0,
                    description: "File size in bytes"
                  },
                  file_format: {
                    bsonType: "string",
                    enum: ["pdf", "csv", "xlsx"],
                    description: "File format"
                  },
                  file_generated_at: {
                    bsonType: "date",
                    description: "When the file was generated"
                  }
                }
              },
              description: "Generated report files in different formats"
            },
            created_at: {
              bsonType: "date",
              description: "Creation timestamp"
            },
            updated_at: {
              bsonType: "date",
              description: "Last update timestamp"
            }
          }
        }
      }
    };
  }

  /**
   * Create a new report
   */
  static async create(db, reportData) {
    const report = {
      report_name: reportData.report_name,
      report_type: reportData.report_type,
      description: reportData.description || '',
      parameters: reportData.parameters || {},
      format: reportData.format || 'json',
      status: 'generating',
      generation_date: new Date(),
      generated_by: new ObjectId(reportData.generated_by),
      download_count: 0,
      tags: reportData.tags || [],
      is_scheduled: reportData.is_scheduled || false,
      schedule_config: reportData.schedule_config || null,
      created_at: new Date(),
      updated_at: new Date()
    };

    // Set expiry date (default 30 days)
    const expiryDays = reportData.expiry_days || 30;
    report.expiry_date = new Date(Date.now() + (expiryDays * 24 * 60 * 60 * 1000));

    const result = await db.collection('reports').insertOne(report);
    return { ...report, _id: result.insertedId };
  }

  /**
   * Generate payroll summary report
   */
  static async generatePayrollSummary(db, parameters) {
    const { start_date, end_date, branch_id, department } = parameters;
    
    const matchStage = {
      calculation_date: {
        $gte: new Date(start_date),
        $lte: new Date(end_date)
      },
      status: { $in: ['approved', 'paid'] }
    };

    // Add branch filter if specified
    if (branch_id) {
      const branchEmployees = await db.collection('users').find({
        'branch.branch_id': branch_id
      }).toArray();
      
      matchStage.employee_id = { 
        $in: branchEmployees.map(emp => emp._id) 
      };
    }

    const pipeline = [
      { $match: matchStage },
      {
        $lookup: {
          from: 'users',
          localField: 'employee_id',
          foreignField: '_id',
          as: 'employee'
        }
      },
      {
        $lookup: {
          from: 'pay_periods',
          localField: 'pay_period_id',
          foreignField: '_id',
          as: 'pay_period'
        }
      },
      { $unwind: '$employee' },
      { $unwind: '$pay_period' }
    ];

    // Add department filter
    if (department) {
      pipeline.push({
        $match: { 'employee.department': department }
      });
    }

    // Aggregate data
    pipeline.push({
      $group: {
        _id: null,
        total_employees: { $addToSet: '$employee_id' },
        total_gross_pay: { $sum: '$gross_pay' },
        total_deductions: { $sum: '$total_deductions' },
        total_net_pay: { $sum: '$net_pay' },
        total_hours: { $sum: '$total_hours' },
        total_regular_hours: { $sum: '$regular_hours' },
        total_overtime_hours: { $sum: '$overtime_hours' },
        avg_daily_rate: { $avg: '$daily_rate' },
        calculations: { $push: '$$ROOT' }
      }
    });

    const result = await db.collection('payroll_calculations').aggregate(pipeline).toArray();
    
    if (result.length === 0) {
      return {
        summary: {
          total_employees: 0,
          total_gross_pay: 0,
          total_deductions: 0,
          total_net_pay: 0,
          total_hours: 0,
          avg_daily_rate: 0
        },
        details: [],
        totals: {}
      };
    }

    const data = result[0];
    
    return {
      summary: {
        total_employees: data.total_employees.length,
        total_gross_pay: parseFloat((data.total_gross_pay || 0).toFixed(2)),
        total_deductions: parseFloat((data.total_deductions || 0).toFixed(2)),
        total_net_pay: parseFloat((data.total_net_pay || 0).toFixed(2)),
        total_hours: parseFloat((data.total_hours || 0).toFixed(2)),
        total_regular_hours: parseFloat((data.total_regular_hours || 0).toFixed(2)),
        total_overtime_hours: parseFloat((data.total_overtime_hours || 0).toFixed(2)),
        avg_daily_rate: parseFloat((data.avg_daily_rate || 0).toFixed(2))
      },
      details: data.calculations.map(calc => ({
        employee_name: `${calc.employee.first_name} ${calc.employee.last_name}`,
        employee_email: calc.employee.email,
        pay_period: calc.pay_period.period_name,
        gross_pay: calc.gross_pay,
        deductions: calc.total_deductions,
        net_pay: calc.net_pay,
        hours: calc.total_hours,
        daily_rate: calc.daily_rate
      })),
      totals: {
        period_start: start_date,
        period_end: end_date,
        generated_at: new Date()
      }
    };
  }

  /**
   * Generate employee earnings report
   */
  static async generateEmployeeEarnings(db, parameters) {
    const { employee_ids, start_date, end_date } = parameters;
    
    const matchStage = {
      calculation_date: {
        $gte: new Date(start_date),
        $lte: new Date(end_date)
      },
      status: { $in: ['approved', 'paid'] }
    };

    if (employee_ids && employee_ids.length > 0) {
      matchStage.employee_id = { 
        $in: employee_ids.map(id => new ObjectId(id)) 
      };
    }

    const pipeline = [
      { $match: matchStage },
      {
        $lookup: {
          from: 'users',
          localField: 'employee_id',
          foreignField: '_id',
          as: 'employee'
        }
      },
      {
        $lookup: {
          from: 'pay_periods',
          localField: 'pay_period_id',
          foreignField: '_id',
          as: 'pay_period'
        }
      },
      { $unwind: '$employee' },
      { $unwind: '$pay_period' },
      {
        $group: {
          _id: '$employee_id',
          employee_name: { $first: { $concat: ['$employee.first_name', ' ', '$employee.last_name'] } },
          employee_email: { $first: '$employee.email' },
          employee_id_number: { $first: '$employee.payroll_info.employee_id' },
          total_gross_pay: { $sum: '$gross_pay' },
          total_deductions: { $sum: '$total_deductions' },
          total_net_pay: { $sum: '$net_pay' },
          total_hours: { $sum: '$total_hours' },
          total_regular_hours: { $sum: '$regular_hours' },
          total_overtime_hours: { $sum: '$overtime_hours' },
          pay_periods_count: { $sum: 1 },
          calculations: { $push: '$$ROOT' }
        }
      },
      { $sort: { employee_name: 1 } }
    ];

    const employees = await db.collection('payroll_calculations').aggregate(pipeline).toArray();
    
    return {
      summary: {
        total_employees: employees.length,
        report_period: `${start_date} to ${end_date}`,
        total_gross_pay: employees.reduce((sum, emp) => sum + emp.total_gross_pay, 0),
        total_net_pay: employees.reduce((sum, emp) => sum + emp.total_net_pay, 0)
      },
      details: employees.map(emp => ({
        employee_id: emp._id,
        employee_name: emp.employee_name,
        employee_email: emp.employee_email,
        employee_id_number: emp.employee_id_number,
        total_gross_pay: parseFloat(emp.total_gross_pay.toFixed(2)),
        total_deductions: parseFloat(emp.total_deductions.toFixed(2)),
        total_net_pay: parseFloat(emp.total_net_pay.toFixed(2)),
        total_hours: parseFloat(emp.total_hours.toFixed(2)),
        pay_periods_count: emp.pay_periods_count,
        avg_gross_per_period: parseFloat((emp.total_gross_pay / emp.pay_periods_count).toFixed(2))
      })),
      totals: {
        generated_at: new Date()
      }
    };
  }

  /**
   * Generate deduction summary report
   */
  static async generateDeductionSummary(db, parameters) {
    const { start_date, end_date } = parameters;
    
    const pipeline = [
      {
        $match: {
          calculation_date: {
            $gte: new Date(start_date),
            $lte: new Date(end_date)
          },
          status: { $in: ['approved', 'paid'] }
        }
      },
      { $unwind: '$deductions' },
      {
        $lookup: {
          from: 'payroll_deduction_types',
          localField: 'deductions.deduction_type_id',
          foreignField: '_id',
          as: 'deduction_type'
        }
      },
      { $unwind: '$deduction_type' },
      {
        $group: {
          _id: '$deductions.deduction_type_id',
          deduction_name: { $first: '$deductions.deduction_name' },
          deduction_type: { $first: '$deduction_type.type' },
          total_amount: { $sum: '$deductions.amount' },
          count: { $sum: 1 },
          avg_amount: { $avg: '$deductions.amount' },
          min_amount: { $min: '$deductions.amount' },
          max_amount: { $max: '$deductions.amount' }
        }
      },
      { $sort: { total_amount: -1 } }
    ];

    const deductions = await db.collection('payroll_calculations').aggregate(pipeline).toArray();
    
    return {
      summary: {
        total_deduction_types: deductions.length,
        total_deduction_amount: deductions.reduce((sum, ded) => sum + ded.total_amount, 0),
        report_period: `${start_date} to ${end_date}`
      },
      details: deductions.map(ded => ({
        deduction_name: ded.deduction_name,
        deduction_type: ded.deduction_type,
        total_amount: parseFloat(ded.total_amount.toFixed(2)),
        count: ded.count,
        avg_amount: parseFloat(ded.avg_amount.toFixed(2)),
        min_amount: parseFloat(ded.min_amount.toFixed(2)),
        max_amount: parseFloat(ded.max_amount.toFixed(2))
      })),
      charts: [
        {
          chart_type: 'pie',
          title: 'Deductions by Type',
          data: deductions.map(ded => ({
            label: ded.deduction_name,
            value: ded.total_amount
          }))
        }
      ],
      totals: {
        generated_at: new Date()
      }
    };
  }

  /**
   * Generate attendance summary report
   */
  static async generateAttendanceSummary(db, parameters) {
    const { start_date, end_date, employee_ids } = parameters;
    
    const matchStage = {
      work_date: {
        $gte: new Date(start_date),
        $lte: new Date(end_date)
      },
      status: 'approved'
    };

    if (employee_ids && employee_ids.length > 0) {
      matchStage.employee_id = { 
        $in: employee_ids.map(id => new ObjectId(id)) 
      };
    }

    const pipeline = [
      { $match: matchStage },
      {
        $lookup: {
          from: 'users',
          localField: 'employee_id',
          foreignField: '_id',
          as: 'employee'
        }
      },
      { $unwind: '$employee' },
      {
        $group: {
          _id: '$employee_id',
          employee_name: { $first: { $concat: ['$employee.first_name', ' ', '$employee.last_name'] } },
          employee_email: { $first: '$employee.email' },
          total_days: { $sum: 1 },
          total_hours: { $sum: '$total_hours' },
          total_regular_hours: { $sum: '$regular_hours' },
          total_overtime_hours: { $sum: '$overtime_hours' },
          avg_hours_per_day: { $avg: '$total_hours' },
          timesheets: { $push: '$$ROOT' }
        }
      },
      { $sort: { employee_name: 1 } }
    ];

    const attendance = await db.collection('timesheets').aggregate(pipeline).toArray();
    
    return {
      summary: {
        total_employees: attendance.length,
        report_period: `${start_date} to ${end_date}`,
        total_hours_worked: attendance.reduce((sum, att) => sum + att.total_hours, 0),
        total_days_worked: attendance.reduce((sum, att) => sum + att.total_days, 0)
      },
      details: attendance.map(att => ({
        employee_name: att.employee_name,
        employee_email: att.employee_email,
        days_worked: att.total_days,
        total_hours: parseFloat(att.total_hours.toFixed(2)),
        regular_hours: parseFloat(att.total_regular_hours.toFixed(2)),
        overtime_hours: parseFloat(att.total_overtime_hours.toFixed(2)),
        avg_hours_per_day: parseFloat(att.avg_hours_per_day.toFixed(2))
      })),
      totals: {
        generated_at: new Date()
      }
    };
  }

  /**
   * Find report by ID
   */
  static async findById(db, reportId) {
    return await db.collection('reports').findOne({
      _id: new ObjectId(reportId)
    });
  }

  /**
   * Find reports by user
   */
  static async findByUser(db, userId, options = {}) {
    const filter = {
      $or: [
        { generated_by: new ObjectId(userId) },
        { 'shared_with.user_id': new ObjectId(userId) }
      ]
    };

    if (options.report_type) {
      filter.report_type = options.report_type;
    }

    if (options.status) {
      filter.status = options.status;
    }

    return await db.collection('reports')
      .find(filter)
      .sort({ generation_date: -1 })
      .limit(options.limit || 50)
      .skip(options.skip || 0)
      .toArray();
  }

  /**
   * Update report status and data
   */
  static async updateReport(db, reportId, updateData) {
    const result = await db.collection('reports').updateOne(
      { _id: new ObjectId(reportId) },
      {
        $set: {
          ...updateData,
          updated_at: new Date()
        }
      }
    );

    return result.modifiedCount > 0;
  }

  /**
   * Mark report as completed
   */
  static async markCompleted(db, reportId, data, filePath = null, generationTimeMs = null) {
    const updateData = {
      status: 'completed',
      data: data,
      updated_at: new Date()
    };

    if (filePath) {
      updateData.file_path = filePath;
    }

    if (generationTimeMs) {
      updateData.generation_time_ms = generationTimeMs;
    }

    const result = await db.collection('reports').updateOne(
      { _id: new ObjectId(reportId) },
      { $set: updateData }
    );

    return result.modifiedCount > 0;
  }

  /**
   * Mark report as failed
   */
  static async markFailed(db, reportId, errorMessage) {
    const result = await db.collection('reports').updateOne(
      { _id: new ObjectId(reportId) },
      {
        $set: {
          status: 'failed',
          error_message: errorMessage,
          updated_at: new Date()
        }
      }
    );

    return result.modifiedCount > 0;
  }

  /**
   * Increment download count
   */
  static async incrementDownloadCount(db, reportId) {
    const result = await db.collection('reports').updateOne(
      { _id: new ObjectId(reportId) },
      {
        $inc: { download_count: 1 },
        $set: { last_downloaded: new Date() }
      }
    );

    return result.modifiedCount > 0;
  }

  /**
   * Delete expired reports
   */
  static async deleteExpired(db) {
    const result = await db.collection('reports').deleteMany({
      expiry_date: { $lt: new Date() },
      status: { $in: ['completed', 'failed'] }
    });

    return result.deletedCount;
  }

  /**
   * Get report statistics
   */
  static async getStatistics(db, userId = null) {
    const matchStage = userId ? 
      { generated_by: new ObjectId(userId) } : 
      {};

    const pipeline = [
      { $match: matchStage },
      {
        $group: {
          _id: '$status',
          count: { $sum: 1 },
          total_size: { $sum: '$file_size' },
          avg_generation_time: { $avg: '$generation_time_ms' }
        }
      }
    ];

    return await db.collection('reports').aggregate(pipeline).toArray();
  }
}

module.exports = Report;