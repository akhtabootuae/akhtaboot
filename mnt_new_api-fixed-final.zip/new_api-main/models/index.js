const User = require('./User');
const Customer = require('./Customer');
const CustomerReview = require('./CustomerReview');
const Role = require('./Role');
const Branch = require('./Branch');
const Invoice = require('./Invoice');
const WorkOrder = require('./WorkOrder');
const Stage = require('./Stage');
const Variation = require('./Variation');
const ErrorReport = require('./ErrorReport');
const Case = require('./Case');
const CaseLog = require('./CaseLog');
const PayrollAuditLog = require('./PayrollAuditLog');
const PayrollDeductionType = require('./PayrollDeductionType');
const PayrollEmployeeDeduction = require('./PayrollEmployeeDeduction');
const PayrollDeductionHistory = require('./PayrollDeductionHistory');
const TimeSheet = require('./TimeSheet');
const PayPeriod = require('./PayPeriod');
const PayrollCalculation = require('./PayrollCalculation');
const PayStub = require('./PayStub');
const Report = require('./Report');
const Alert = require('./Alert');
const Budget = require('./Budget');
const Expense = require('./Expense');
const ExpenseLog = require('./ExpenseLog');
const Finance = require('./Finance');
const WorkOrderQA = require('./WorkOrderQA');
const Message = require('./Message');
const Conversation = require('./Conversation');
const CarPart = require('./CarPart');


/**
 * Initialize database with proper collections and validation
 * @param {Object} db MongoDB database connection
 */
async function initializeDatabase(db) {
  try {
    // Get all collection names
    const collections = await db.listCollections().toArray();
    const collectionNames = collections.map(c => c.name);
    
    // Create users collection if it doesn't exist
    if (!collectionNames.includes('users')) {
      await db.createCollection('users', User.getSchema());
      console.log('Created users collection with validation schema');
    } else {
      console.log('Users collection already exists, skipping validation update');
    }
    
    // Create indexes
    await db.collection('users').createIndex({ email: 1 }, { unique: true });
    console.log('Ensured email index on users collection');
    
    // Create customers collection if it doesn't exist
    if (!collectionNames.includes('customers')) {
      await db.createCollection('customers', Customer.getSchema());
      console.log('Created customers collection with validation schema');
    } else {
      console.log('Customers collection already exists, skipping validation update');
    }
    
    // Create indexes for customers collection
    try {
      await db.collection('customers').createIndex({ email: 1 }, { unique: true, partialFilterExpression: { email: { $exists: true, $type: 'string', $gt: '' } } });
    } catch (error) {
      if (error.code !== 86) throw error; // Ignore index conflicts, re-throw other errors
    }
    console.log('Ensured email index on customers collection');
    
    // Create roles collection if it doesn't exist
    if (!collectionNames.includes('roles')) {
      await db.createCollection('roles', Role.getSchema());
      console.log('Created roles collection with validation schema');
    } else {
      console.log('Roles collection already exists, skipping validation update');
    }
    
    // Create indexes for roles collection
    await db.collection('roles').createIndex({ role_name: 1 }, { unique: true });
    console.log('Ensured role_name index on roles collection');
    
    // Create branches collection if it doesn't exist
    if (!collectionNames.includes('branches')) {
      await db.createCollection('branches', Branch.getSchema());
      console.log('Created branches collection with validation schema');
    } else {
      console.log('Branches collection already exists, skipping validation update');
    }
    
    // Create indexes for branches collection
    await db.collection('branches').createIndex({ branch_code: 1 }, { unique: true });
    console.log('Ensured branch_code index on branches collection');
    
    // Create work_orders collection if it doesn't exist
    if (!collectionNames.includes('work_orders')) {
      await db.createCollection('work_orders', WorkOrder.getSchema());
      console.log('Created work_orders collection with validation schema');
    } else {
      console.log('Work_orders collection already exists, skipping validation update');
    }
    
    // Create indexes for work_orders collection
    await db.collection('work_orders').createIndex({ work_order_number: 1 }, { unique: true });
    console.log('Ensured work_order_number index on work_orders collection');
    
    // Create invoices collection if it doesn't exist
    if (!collectionNames.includes('invoices')) {
      await db.createCollection('invoices', Invoice.getSchema());
      console.log('Created invoices collection with validation schema');
    } else {
      console.log('Invoices collection already exists, skipping validation update');
    }
    
    // Create indexes for invoices collection
    await db.collection('invoices').createIndex({ invoice_number: 1 }, { unique: true });
    console.log('Ensured invoice_number index on invoices collection');
    
    // Create stages collection if it doesn't exist
    if (!collectionNames.includes('stages')) {
      await db.createCollection('stages', Stage.getSchema());
      console.log('Created stages collection with validation schema');
    } else {
      console.log('Stages collection already exists, skipping validation update');
    }
    
    // Create indexes for stages collection
    await db.collection('stages').createIndex({ order: 1 });
    console.log('Ensured order index on stages collection');
    
    // Create variations collection if it doesn't exist
    if (!collectionNames.includes('variations')) {
      await db.createCollection('variations', Variation.getSchema());
      console.log('Created variations collection with validation schema');
    } else {
      console.log('Variations collection already exists, skipping validation update');
    }
    
    // Create indexes for variations collection
    await db.collection('variations').createIndex({ code: 1 }, { unique: true });
    console.log('Ensured code index on variations collection');
    
    // Create error_reports collection if it doesn't exist
    if (!collectionNames.includes('error_reports')) {
      await db.createCollection('error_reports', ErrorReport.getSchema());
      console.log('Created error_reports collection with validation schema');
    } else {
      console.log('Error_reports collection already exists, skipping validation update');
    }
    
    // Create indexes for error_reports collection
    await db.collection('error_reports').createIndex({ workOrderId: 1 });
    await db.collection('error_reports').createIndex({ partIndex: 1 });
    await db.collection('error_reports').createIndex({ reportingTechnicianId: 1 });
    await db.collection('error_reports').createIndex({ problematicTechnicianId: 1 });
    await db.collection('error_reports').createIndex({ timestamp: -1 });
    await db.collection('error_reports').createIndex({ status: 1 });
    console.log('Ensured indexes on error_reports collection');
    
    // Create cases collection if it doesn't exist
    if (!collectionNames.includes('cases')) {
      await db.createCollection('cases', Case.getSchema());
      console.log('Created cases collection with validation schema');
    } else {
      console.log('Cases collection already exists, skipping validation update');
    }
    
    // Create indexes for cases collection
    await db.collection('cases').createIndex({ title: 'text', description: 'text' });
    await db.collection('cases').createIndex({ status: 1 });
    await db.collection('cases').createIndex({ priority: 1 });
    await db.collection('cases').createIndex({ createdBy: 1 });
    await db.collection('cases').createIndex({ assignedTo: 1 });
    await db.collection('cases').createIndex({ 'linkedTo.type': 1, 'linkedTo.id': 1 });
    await db.collection('cases').createIndex({ tags: 1 });
    await db.collection('cases').createIndex({ createdAt: -1 });
    await db.collection('cases').createIndex({ dueDate: 1 });
    console.log('Ensured indexes on cases collection');

    // Create case_logs collection if it doesn't exist
    if (!collectionNames.includes('case_logs')) {
      await db.createCollection('case_logs', CaseLog.getSchema());
      console.log('Created case_logs collection with validation schema');
    } else {
      // Update validation for existing collection
      await db.command({
        collMod: 'case_logs',
        validator: CaseLog.getSchema().validator
      });
      console.log('Updated case_logs collection validation schema');
    }
    
    // Create indexes for case_logs collection
    await db.collection('case_logs').createIndex({ user_id: 1 });
    await db.collection('case_logs').createIndex({ entity_id: 1 });
    await db.collection('case_logs').createIndex({ entity_type: 1 });
    await db.collection('case_logs').createIndex({ timestamp: -1 });
    await db.collection('case_logs').createIndex({ action: 1 });
    await db.collection('case_logs').createIndex({ severity: 1 });
    await db.collection('case_logs').createIndex({ category: 1 });
    await db.collection('case_logs').createIndex({ branch_id: 1 });
    console.log('Ensured indexes on case_logs collection');

    
    // Create payroll_audit_log collection if it doesn't exist
    if (!collectionNames.includes('payroll_audit_log')) {
      await db.createCollection('payroll_audit_log', PayrollAuditLog.getSchema());
      console.log('Created payroll_audit_log collection with validation schema');
    } else {
      console.log('Payroll_audit_log collection already exists, skipping validation update');
    }
    
    // Create indexes for payroll_audit_log collection
    await db.collection('payroll_audit_log').createIndex({ user_id: 1 });
    await db.collection('payroll_audit_log').createIndex({ entity_id: 1 });
    await db.collection('payroll_audit_log').createIndex({ timestamp: -1 });
    await db.collection('payroll_audit_log').createIndex({ action: 1 });
    await db.collection('payroll_audit_log').createIndex({ entity_type: 1 });
    await db.collection('payroll_audit_log').createIndex({ severity: 1 });
    console.log('Ensured indexes on payroll_audit_log collection');
    
    // Create payroll_deduction_types collection if it doesn't exist
    if (!collectionNames.includes('payroll_deduction_types')) {
      await db.createCollection('payroll_deduction_types', PayrollDeductionType.getSchema());
      console.log('Created payroll_deduction_types collection with validation schema');
    } else {
      console.log('Payroll_deduction_types collection already exists, skipping validation update');
    }
    
    // Create indexes for payroll_deduction_types collection (handle existing indexes)
    try {
      await db.collection('payroll_deduction_types').createIndex({ name: 1 }, { unique: true });
    } catch (error) {
      if (error.code !== 86) throw error; // Ignore index conflicts, re-throw other errors
    }
    try {
      await db.collection('payroll_deduction_types').createIndex({ type: 1 });
    } catch (error) {
      if (error.code !== 86) throw error;
    }
    try {
      await db.collection('payroll_deduction_types').createIndex({ active: 1 });
    } catch (error) {
      if (error.code !== 86) throw error;
    }
    try {
      await db.collection('payroll_deduction_types').createIndex({ is_system_type: 1 });
    } catch (error) {
      if (error.code !== 86) throw error;
    }
    console.log('Ensured indexes on payroll_deduction_types collection');
    
    // Create payroll_employee_deductions collection if it doesn't exist
    if (!collectionNames.includes('payroll_employee_deductions')) {
      await db.createCollection('payroll_employee_deductions', PayrollEmployeeDeduction.getSchema());
      console.log('Created payroll_employee_deductions collection with validation schema');
    } else {
      console.log('Payroll_employee_deductions collection already exists, skipping validation update');
    }
    
    // Create indexes for payroll_employee_deductions collection (handle existing indexes)
    const empDeductionIndexes = [
      { key: { employee_id: 1 } },
      { key: { employee_id: 1, status: 1 } },
      { key: { deduction_type_id: 1 } },
      { key: { status: 1 } },
      { key: { start_date: 1 } },
      { key: { end_date: 1 } },
      { key: { priority: 1 } },
      { key: { created_by: 1 } }
    ];
    
    for (const indexSpec of empDeductionIndexes) {
      try {
        await db.collection('payroll_employee_deductions').createIndex(indexSpec.key, indexSpec.options || {});
      } catch (error) {
        if (error.code !== 86) throw error; // Ignore index conflicts
      }
    }
    console.log('Ensured indexes on payroll_employee_deductions collection');
    
    // Create payroll_deduction_history collection if it doesn't exist
    if (!collectionNames.includes('payroll_deduction_history')) {
      await db.createCollection('payroll_deduction_history', PayrollDeductionHistory.getSchema());
      console.log('Created payroll_deduction_history collection with validation schema');
    } else {
      console.log('Payroll_deduction_history collection already exists, skipping validation update');
    }
    
    // Create indexes for payroll_deduction_history collection (handle existing indexes)
    const historyIndexes = [
      { key: { employee_id: 1 } },
      { key: { employee_deduction_id: 1 } },
      { key: { pay_period_start: 1 } },
      { key: { processed_at: -1 } },
      { key: { employee_id: 1, pay_period_start: 1 } }
    ];
    
    for (const indexSpec of historyIndexes) {
      try {
        await db.collection('payroll_deduction_history').createIndex(indexSpec.key, indexSpec.options || {});
      } catch (error) {
        if (error.code !== 86) throw error; // Ignore index conflicts
      }
    }
    console.log('Ensured indexes on payroll_deduction_history collection');
    
    // Create timesheets collection if it doesn't exist
    if (!collectionNames.includes('timesheets')) {
      await db.createCollection('timesheets', TimeSheet.getSchema());
      console.log('Created timesheets collection with validation schema');
    } else {
      console.log('Timesheets collection already exists, skipping validation update');
    }
    
    // Create indexes for timesheets collection
    const timesheetIndexes = [
      { key: { employee_id: 1 } },
      { key: { employee_id: 1, work_date: 1 }, options: { unique: true } },
      { key: { work_date: 1 } },
      { key: { status: 1 } },
      { key: { submitted_at: 1 } },
      { key: { approved_at: 1 } },
      { key: { created_by: 1 } }
    ];
    
    for (const indexSpec of timesheetIndexes) {
      try {
        await db.collection('timesheets').createIndex(indexSpec.key, indexSpec.options || {});
      } catch (error) {
        if (error.code !== 86) throw error; // Ignore index conflicts
      }
    }
    console.log('Ensured indexes on timesheets collection');
    
    // Create pay_periods collection if it doesn't exist
    if (!collectionNames.includes('pay_periods')) {
      await db.createCollection('pay_periods', PayPeriod.getSchema());
      console.log('Created pay_periods collection with validation schema');
    } else {
      console.log('Pay_periods collection already exists, skipping validation update');
    }
    
    // Create indexes for pay_periods collection
    const payPeriodIndexes = [
      { key: { year: 1, frequency: 1, period_number: 1 }, options: { unique: true } },
      { key: { start_date: 1 } },
      { key: { end_date: 1 } },
      { key: { status: 1 } },
      { key: { frequency: 1 } },
      { key: { created_by: 1 } }
    ];
    
    for (const indexSpec of payPeriodIndexes) {
      try {
        await db.collection('pay_periods').createIndex(indexSpec.key, indexSpec.options || {});
      } catch (error) {
        if (error.code !== 86) throw error; // Ignore index conflicts
      }
    }
    console.log('Ensured indexes on pay_periods collection');
    
    // Create payroll_calculations collection if it doesn't exist
    if (!collectionNames.includes('payroll_calculations')) {
      await db.createCollection('payroll_calculations', PayrollCalculation.getSchema());
      console.log('Created payroll_calculations collection with validation schema');
    } else {
      console.log('Payroll_calculations collection already exists, skipping validation update');
    }
    
    // Create indexes for payroll_calculations collection
    const calculationIndexes = [
      { key: { employee_id: 1, pay_period_id: 1 }, options: { unique: true } },
      { key: { pay_period_id: 1 } },
      { key: { employee_id: 1 } },
      { key: { status: 1 } },
      { key: { calculation_date: 1 } },
      { key: { approved_at: 1 } },
      { key: { paid_at: 1 } },
      { key: { created_by: 1 } }
    ];
    
    for (const indexSpec of calculationIndexes) {
      try {
        await db.collection('payroll_calculations').createIndex(indexSpec.key, indexSpec.options || {});
      } catch (error) {
        if (error.code !== 86) throw error; // Ignore index conflicts
      }
    }
    console.log('Ensured indexes on payroll_calculations collection');
    
    // Create pay_stubs collection if it doesn't exist
    if (!collectionNames.includes('pay_stubs')) {
      await db.createCollection('pay_stubs', PayStub.getSchema());
      console.log('Created pay_stubs collection with validation schema');
    } else {
      console.log('Pay_stubs collection already exists, skipping validation update');
    }
    
    // Create indexes for pay_stubs collection
    const payStubIndexes = [
      { key: { employee_id: 1 } },
      { key: { pay_period_id: 1 } },
      { key: { payroll_calculation_id: 1 }, options: { unique: true } },
      { key: { stub_number: 1 }, options: { unique: true } },
      { key: { issue_date: 1 } },
      { key: { status: 1 } },
      { key: { employee_id: 1, issue_date: -1 } }
    ];
    
    for (const indexSpec of payStubIndexes) {
      try {
        await db.collection('pay_stubs').createIndex(indexSpec.key, indexSpec.options || {});
      } catch (error) {
        if (error.code !== 86) throw error; // Ignore index conflicts
      }
    }
    console.log('Ensured indexes on pay_stubs collection');
    
    // Create reports collection if it doesn't exist
    if (!collectionNames.includes('reports')) {
      await db.createCollection('reports', Report.getSchema());
      console.log('Created reports collection with validation schema');
    } else {
      console.log('Reports collection already exists, skipping validation update');
    }
    
    // Create indexes for reports collection
    const reportIndexes = [
      { key: { generated_by: 1 } },
      { key: { report_type: 1 } },
      { key: { status: 1 } },
      { key: { generation_date: -1 } },
      { key: { expiry_date: 1 } },
      { key: { 'shared_with.user_id': 1 } }
    ];
    
    for (const indexSpec of reportIndexes) {
      try {
        await db.collection('reports').createIndex(indexSpec.key, indexSpec.options || {});
      } catch (error) {
        if (error.code !== 86) throw error; // Ignore index conflicts
      }
    }
    console.log('Ensured indexes on reports collection');
    
    // Create alerts collection if it doesn't exist
    if (!collectionNames.includes('alerts')) {
      await db.createCollection('alerts', Alert.getSchema());
      console.log('Created alerts collection with validation schema');
    } else {
      console.log('Alerts collection already exists, skipping validation update');
    }
    
    // Create indexes for alerts collection
    const alertIndexes = [
      { key: { target_users: 1 } },
      { key: { target_roles: 1 } },
      { key: { created_by: 1 } },
      { key: { alert_type: 1 } },
      { key: { status: 1 } },
      { key: { severity: 1 } },
      { key: { created_at: -1 } },
      { key: { expires_at: 1 } },
      { key: { 'related_entity.entity_type': 1, 'related_entity.entity_id': 1 } }
    ];
    
    for (const indexSpec of alertIndexes) {
      try {
        await db.collection('alerts').createIndex(indexSpec.key, indexSpec.options || {});
      } catch (error) {
        if (error.code !== 86) throw error; // Ignore index conflicts
      }
    }
    console.log('Ensured indexes on alerts collection');
    
    // Create budgets collection if it doesn't exist
    if (!collectionNames.includes('budgets')) {
      await db.createCollection('budgets', Budget.getSchema());
      console.log('Created budgets collection with validation schema');
    } else {
      console.log('Budgets collection already exists, skipping validation update');
    }
    
    // Create indexes for budgets collection
    const budgetIndexes = [
      { key: { budget_type: 1 } },
      { key: { status: 1 } },
      { key: { period_start: 1 } },
      { key: { period_end: 1 } },
      { key: { created_by: 1 } },
      { key: { 'scope.scope_type': 1 } },
      { key: { period_start: 1, period_end: 1 } }
    ];
    
    for (const indexSpec of budgetIndexes) {
      try {
        await db.collection('budgets').createIndex(indexSpec.key, indexSpec.options || {});
      } catch (error) {
        if (error.code !== 86) throw error; // Ignore index conflicts
      }
    }
    console.log('Ensured indexes on budgets collection');

    // Create expenses collection if it doesn't exist
    if (!collectionNames.includes('expenses')) {
      await db.createCollection('expenses', Expense.getSchema());
      console.log('Created expenses collection with validation schema');
    } else {
      console.log('Expenses collection already exists, skipping validation update');
    }
    
    // Create indexes for expenses collection
    const expenseIndexes = [
      { key: { expense_number: 1 }, options: { unique: true } },
      { key: { created_by: 1 } },
      { key: { branch_id: 1 } },
      { key: { expense_type: 1 } },
      { key: { status: 1 } },
      { key: { approval_status: 1 } },
      { key: { date: 1 } },
      { key: { amount: 1 } },
      { key: { work_order_id: 1 } },
      { key: { project_id: 1 } },
      { key: { vendor: 1 } },
      { key: { tags: 1 } },
      { key: { created_at: -1 } },
      { key: { approved_by: 1 } },
      { key: { approval_date: 1 } }
    ];
    
    for (const indexSpec of expenseIndexes) {
      try {
        await db.collection('expenses').createIndex(indexSpec.key, indexSpec.options || {});
      } catch (error) {
        if (error.code !== 86) throw error; // Ignore index conflicts
      }
    }
    console.log('Ensured indexes on expenses collection');

    // Create expense_logs collection if it doesn't exist
    if (!collectionNames.includes('expense_logs')) {
      await db.createCollection('expense_logs', ExpenseLog.getSchema());
      console.log('Created expense_logs collection with validation schema');
    } else {
      console.log('Expense_logs collection already exists, skipping validation update');
    }
    
    // Create indexes for expense_logs collection
    const expenseLogIndexes = [
      { key: { user_id: 1 } },
      { key: { entity_id: 1 } },
      { key: { timestamp: -1 } },
      { key: { action: 1 } },
      { key: { entity_type: 1 } },
      { key: { severity: 1 } },
      { key: { branch_id: 1 } },
      { key: { category: 1 } },
      { key: { user_id: 1, timestamp: -1 } },
      { key: { entity_id: 1, timestamp: -1 } },
      { key: { branch_id: 1, timestamp: -1 } }
    ];
    
    for (const indexSpec of expenseLogIndexes) {
      try {
        await db.collection('expense_logs').createIndex(indexSpec.key, indexSpec.options || {});
      } catch (error) {
        if (error.code !== 86) throw error; // Ignore index conflicts
      }
    }
    console.log('Ensured indexes on expense_logs collection');

    // Create customer_reviews collection if it doesn't exist
    if (!collectionNames.includes('customer_reviews')) {
      await db.createCollection('customer_reviews', CustomerReview.getSchema());
      console.log('Created customer_reviews collection with validation schema');
    } else {
      // Update validation for existing collection
      await db.command({
        collMod: 'customer_reviews',
        validator: CustomerReview.getSchema().validator
      });
      console.log('Updated customer_reviews collection validation schema');
    }
    
    // Create indexes for customer_reviews collection
    const customerReviewIndexes = [
      { key: { phone_number: 1 } },
      { key: { rating: 1 } },
      { key: { created_at: -1 } },
      { key: { phone_number: 1, created_at: -1 } },
      { key: { rating: 1, created_at: -1 } }
    ];
    
    for (const indexSpec of customerReviewIndexes) {
      try {
        await db.collection('customer_reviews').createIndex(indexSpec.key, indexSpec.options || {});
      } catch (error) {
        if (error.code !== 86) throw error; // Ignore index conflicts
      }
    }
    console.log('Ensured indexes on customer_reviews collection');

    // Create workordersqa collection if it doesn't exist
    if (!collectionNames.includes('workordersqa')) {
      await db.createCollection('workordersqa', WorkOrderQA.getSchema());
      console.log('Created workordersqa collection with validation schema');
    } else {
      console.log('Workordersqa collection already exists, skipping validation update');
    }
    
    // Create indexes for workordersqa collection
    const workOrderQAIndexes = [
      { key: { WO_ID: 1 } },
      { key: { person_name: 1 } },
      { key: { passed: 1 } },
      { key: { created_at: -1 } },
      { key: { WO_ID: 1, created_at: -1 } },
      { key: { passed: 1, created_at: -1 } }
    ];
    
    for (const indexSpec of workOrderQAIndexes) {
      try {
        await db.collection('workordersqa').createIndex(indexSpec.key, indexSpec.options || {});
      } catch (error) {
        if (error.code !== 86) throw error; // Ignore index conflicts
      }
    }
    console.log('Ensured indexes on workordersqa collection');

    // Create conversations collection if it doesn't exist
    if (!collectionNames.includes('conversations')) {
      await db.createCollection('conversations', Conversation.getSchema());
      console.log('Created conversations collection with validation schema');
    } else {
      console.log('Conversations collection already exists, skipping validation update');
    }
    
    // Create indexes for conversations collection
    const conversationIndexes = Conversation.getIndexes();
    for (const indexSpec of conversationIndexes) {
      try {
        if (typeof indexSpec === 'object' && !Array.isArray(indexSpec)) {
          if (indexSpec.key && indexSpec.options) {
            await db.collection('conversations').createIndex(indexSpec.key, indexSpec.options);
          } else if (indexSpec.key) {
            await db.collection('conversations').createIndex(indexSpec.key);
          } else {
            await db.collection('conversations').createIndex(indexSpec);
          }
        }
      } catch (error) {
        if (error.code !== 86) throw error; // Ignore index conflicts
      }
    }
    console.log('Ensured indexes on conversations collection');

    // Create messages collection if it doesn't exist
    if (!collectionNames.includes('messages')) {
      await db.createCollection('messages', Message.getSchema());
      console.log('Created messages collection with validation schema');
    } else {
      console.log('Messages collection already exists, skipping validation update');
    }
    
    // Create indexes for messages collection
    const messageIndexes = Message.getIndexes();
    for (const indexSpec of messageIndexes) {
      try {
        if (typeof indexSpec === 'object' && !Array.isArray(indexSpec)) {
          await db.collection('messages').createIndex(indexSpec);
        }
      } catch (error) {
        if (error.code !== 86) throw error; // Ignore index conflicts
      }
    }
    console.log('Ensured indexes on messages collection');

    
  } catch (error) {
    console.error('Database initialization error:', error);
    throw error;
  }
}

module.exports = {
  User,
  Customer,
  CustomerReview,
  Role,
  Branch,
  Invoice,
  WorkOrder,
  Stage,
  Variation,
  ErrorReport,
  Case,
  CaseLog,
  PayrollAuditLog,
  PayrollDeductionType,
  PayrollEmployeeDeduction,
  PayrollDeductionHistory,
  TimeSheet,
  PayPeriod,
  PayrollCalculation,
  PayStub,
  Report,
  Alert,
  Budget,
  Expense,
  ExpenseLog,
  Finance,
  WorkOrderQA,
  Message,
  Conversation,
  CarPart,

  initializeDatabase
};
