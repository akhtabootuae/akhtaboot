const mongoose = require('mongoose');

const carPartSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Car part name is required'],
    trim: true
  },
  category: {
    type: String,
    required: [true, 'Category is required'],
    enum: ['Exterior', 'Glass', 'Mechanical', 'Interior'],
    default: 'Exterior'
  }
}, {
  timestamps: true
});

// Create indexes for better performance
carPartSchema.index({ name: 1 });
carPartSchema.index({ category: 1 });

// Prevent duplicate part names within the same category
carPartSchema.index({ name: 1, category: 1 }, { unique: true });

const CarPart = mongoose.model('CarPart', carPartSchema);

module.exports = CarPart;