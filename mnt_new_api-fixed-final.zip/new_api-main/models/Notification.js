const { ObjectId } = require('mongodb');

/**
 * Notification Model
 * Provides structure and methods for Notification data
 */
class Notification {
  /**
   * Get MongoDB schema validation for notifications collection
   * @returns {Object} MongoDB schema validation object
   */
  static getSchema() {
    return {
      validator: {
        $jsonSchema: {
          bsonType: "object",
          required: ["type", "title", "message", "status", "createdAt"],
          properties: {
            type: {
              enum: ["time_alert", "deadline_warning", "status_change", "assignment", "general"],
              description: "Type of notification"
            },
            title: {
              bsonType: "string",
              description: "Notification title"
            },
            message: {
              bsonType: "string",
              description: "Notification message content"
            },
            workOrderId: {
              bsonType: ["objectId", "string"],
              description: "Related work order ID"
            },
            stageId: {
              bsonType: "string",
              description: "Related stage ID"
            },
            recipientType: {
              enum: ["supervisor", "technician", "owner", "admin", "all"],
              description: "Who should receive this notification"
            },
            recipientId: {
              bsonType: "objectId",
              description: "Specific recipient user ID"
            },
            priority: {
              enum: ["low", "medium", "high", "urgent"],
              description: "Notification priority level"
            },
            status: {
              enum: ["unread", "read", "archived"],
              description: "Notification read status"
            },
            percentComplete: {
              bsonType: "number",
              minimum: 0,
              maximum: 100,
              description: "For time alerts, the percentage of completion"
            },
            metadata: {
              bsonType: "object",
              description: "Additional notification metadata"
            },
            createdAt: {
              bsonType: "date",
              description: "Notification creation timestamp"
            },
            readAt: {
              bsonType: "date",
              description: "When notification was read"
            },
            expiresAt: {
              bsonType: "date",
              description: "When notification should expire"
            },
            employeeId: {
              bsonType: ["objectId", "string"],
              description: "Related employee ID"
            },
            timesheetId: {
              bsonType: ["objectId", "string"],
              description: "Related timesheet ID"
            },
            deductionId: {
              bsonType: ["objectId", "string"],
              description: "Related deduction ID"
            }
          }
        }
      }
    };
  }

  /**
   * Create a new notification
   * @param {Object} db MongoDB database connection
   * @param {Object} notificationData Notification data to create
   * @returns {Object} Created notification
   */
  static async create(db, notificationData) {
    const timestamp = new Date();
    
    // Convert workOrderId to ObjectId if it's a string
    if (notificationData.workOrderId && typeof notificationData.workOrderId === 'string') {
      try {
        notificationData.workOrderId = new ObjectId(notificationData.workOrderId);
      } catch (error) {
        // Keep as string if not a valid ObjectId
        console.warn('Invalid ObjectId for workOrderId:', notificationData.workOrderId);
      }
    }
    
    // Convert recipientId to ObjectId if it's a string
    if (notificationData.recipientId && typeof notificationData.recipientId === 'string') {
      notificationData.recipientId = new ObjectId(notificationData.recipientId);
    }
    
    // Convert employeeId to ObjectId if it's a string
    if (notificationData.employeeId && typeof notificationData.employeeId === 'string') {
      try {
        notificationData.employeeId = new ObjectId(notificationData.employeeId);
      } catch (error) {
        console.warn('Invalid ObjectId for employeeId:', notificationData.employeeId);
      }
    }
    
    // Convert timesheetId to ObjectId if it's a string
    if (notificationData.timesheetId && typeof notificationData.timesheetId === 'string') {
      try {
        notificationData.timesheetId = new ObjectId(notificationData.timesheetId);
      } catch (error) {
        console.warn('Invalid ObjectId for timesheetId:', notificationData.timesheetId);
      }
    }
    
    // Convert deductionId to ObjectId if it's a string
    if (notificationData.deductionId && typeof notificationData.deductionId === 'string') {
      try {
        notificationData.deductionId = new ObjectId(notificationData.deductionId);
      } catch (error) {
        console.warn('Invalid ObjectId for deductionId:', notificationData.deductionId);
      }
    }
    
    const newNotification = {
      ...notificationData,
      status: notificationData.status || 'unread',
      priority: notificationData.priority || 'medium',
      createdAt: timestamp,
      // Set expiration to 30 days by default if not specified
      expiresAt: notificationData.expiresAt || new Date(timestamp.getTime() + (30 * 24 * 60 * 60 * 1000))
    };
    
    const result = await db.collection('notifications').insertOne(newNotification);
    return { ...newNotification, _id: result.insertedId };
  }

  /**
   * Get notifications by recipient
   * @param {Object} db MongoDB database connection
   * @param {string} recipientType Type of recipient
   * @param {string} recipientId Specific recipient ID (optional)
   * @param {Object} options Query options
   * @returns {Array} Array of notifications
   */
  static async getByRecipient(db, recipientType, recipientId = null, options = {}) {
    const query = { recipientType };
    
    if (recipientId) {
      query.recipientId = new ObjectId(recipientId);
    }
    
    // Don't show expired notifications by default
    if (!options.includeExpired) {
      query.expiresAt = { $gt: new Date() };
    }
    
    // Filter by status if specified
    if (options.status) {
      query.status = options.status;
    }
    
    const notifications = await db.collection('notifications')
      .find(query)
      .sort({ createdAt: -1 })
      .limit(options.limit || 100)
      .toArray();
    
    return notifications;
  }

  /**
   * Mark notification as read
   * @param {Object} db MongoDB database connection
   * @param {string} notificationId Notification ID
   * @returns {Object} Update result
   */
  static async markAsRead(db, notificationId) {
    return db.collection('notifications').updateOne(
      { _id: new ObjectId(notificationId) },
      { 
        $set: { 
          status: 'read',
          readAt: new Date()
        } 
      }
    );
  }

  /**
   * Delete expired notifications
   * @param {Object} db MongoDB database connection
   * @returns {Object} Delete result
   */
  static async deleteExpired(db) {
    return db.collection('notifications').deleteMany({
      expiresAt: { $lt: new Date() }
    });
  }

  /**
   * Get notification statistics
   * @param {Object} db MongoDB database connection
   * @param {string} recipientType Type of recipient
   * @param {string} recipientId Specific recipient ID (optional)
   * @returns {Object} Notification stats
   */
  static async getStats(db, recipientType, recipientId = null) {
    const matchStage = { recipientType };
    
    if (recipientId) {
      matchStage.recipientId = new ObjectId(recipientId);
    }
    
    const stats = await db.collection('notifications').aggregate([
      { $match: matchStage },
      {
        $group: {
          _id: null,
          total: { $sum: 1 },
          unread: {
            $sum: {
              $cond: [{ $eq: ["$status", "unread"] }, 1, 0]
            }
          },
          high_priority: {
            $sum: {
              $cond: [{ $eq: ["$priority", "high"] }, 1, 0]
            }
          }
        }
      }
    ]).toArray();
    
    return stats[0] || { total: 0, unread: 0, high_priority: 0 };
  }
}

module.exports = Notification;