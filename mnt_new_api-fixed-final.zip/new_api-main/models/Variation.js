const { ObjectId } = require('mongodb');

/**
 * Variation Model
 * Provides structure and methods for Variation data
 */
class Variation {
  /**
   * Get MongoDB schema validation for variations collection
   * @returns {Object} MongoDB schema validation object
   */
  static getSchema() {
    return {
      validator: {
        $jsonSchema: {
          bsonType: "object",
          required: ["code", "description", "defaultLaborHours", "defaultStages", "created_at", "updated_at"],
          properties: {
            code: {
              bsonType: "string",
              description: "Unique service code (e.g. 'PDR')"
            },
            description: {
              bsonType: "string",
              description: "What this service entails"
            },
            notes: {
              bsonType: "string",
              description: "Additional notes about this service"
            },
            specialRequirements: {
              bsonType: "string",
              description: "Special requirements or instructions for this service"
            },
            defaultLaborHours: {
              bsonType: ["double", "int", "decimal"],
              description: "Estimated hours if needed"
            },
            defaultStages: {
              bsonType: "array",
              description: "Ordered list of stage _id's for this service",
              items: {
                bsonType: "objectId"
              },
              minItems: 1
            },
            created_at: {
              bsonType: "date",
              description: "Date when the variation was created"
            },
            updated_at: {
              bsonType: "date",
              description: "Date when the variation was last updated"
            }
          }
        }
      }
    };
  }

  /**
   * Create a new variation
   * @param {Object} db - MongoDB database instance
   * @param {Object} variationData - Variation data to create
   * @returns {Object} Created variation
   */
  static async create(db, variationData) {
    // Convert stage IDs to ObjectId if they are strings
    if (variationData.defaultStages) {
      variationData.defaultStages = variationData.defaultStages.map(stageId => 
        typeof stageId === 'string' ? new ObjectId(stageId) : stageId
      );
    }

    const now = new Date();
    const newVariation = {
      ...variationData,
      created_at: now,
      updated_at: now
    };

    const result = await db.collection('variations').insertOne(newVariation);
    return { _id: result.insertedId, ...newVariation };
  }

  /**
   * Get all variations
   * @param {Object} db - MongoDB database instance
   * @returns {Array} Array of variations
   */
  static async getAll(db) {
    return await db.collection('variations').find().toArray();
  }

  /**
   * Get variation by ID
   * @param {Object} db - MongoDB database instance
   * @param {String} id - Variation ID
   * @returns {Object} Variation document
   */
  static async getById(db, id) {
    return await db.collection('variations').findOne({ _id: new ObjectId(id) });
  }

  /**
   * Get variation by code
   * @param {Object} db - MongoDB database instance
   * @param {String} code - Variation code
   * @returns {Object} Variation document
   */
  static async getByCode(db, code) {
    return await db.collection('variations').findOne({ code });
  }

  /**
   * Get variation with populated stages
   * @param {Object} db - MongoDB database instance
   * @param {String} id - Variation ID
   * @returns {Object} Variation document with stages
   */
  static async getWithStages(db, id) {
    const variation = await db.collection('variations').findOne({ _id: new ObjectId(id) });
    
    if (!variation) return null;
    
    // Lookup stages
    variation.stages = await db.collection('stages')
      .find({ _id: { $in: variation.defaultStages } })
      .sort({ order: 1 })
      .toArray();
      
    return variation;
  }

  /**
   * Update a variation
   * @param {Object} db - MongoDB database instance
   * @param {String} id - Variation ID
   * @param {Object} variationData - Updated variation data
   * @returns {Object} Updated variation
   */
  static async update(db, id, variationData) {
    // Convert stage IDs to ObjectId if they are strings
    if (variationData.defaultStages) {
      variationData.defaultStages = variationData.defaultStages.map(stageId => 
        typeof stageId === 'string' ? new ObjectId(stageId) : stageId
      );
    }

    const updatedVariation = {
      ...variationData,
      updated_at: new Date()
    };

    await db.collection('variations').updateOne(
      { _id: new ObjectId(id) },
      { $set: updatedVariation }
    );

    return { _id: new ObjectId(id), ...updatedVariation };
  }

  /**
   * Delete a variation
   * @param {Object} db - MongoDB database instance
   * @param {String} id - Variation ID
   * @returns {Boolean} True if successful
   */
  static async delete(db, id) {
    const result = await db.collection('variations').deleteOne({ _id: new ObjectId(id) });
    return result.deletedCount > 0;
  }
}

module.exports = Variation;
