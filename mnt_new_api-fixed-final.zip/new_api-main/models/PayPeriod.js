const { ObjectId } = require('mongodb');
const moment = require('moment');

class PayPeriod {
  /**
   * Get collection validation schema for MongoDB
   */
  static getSchema() {
    return {
      validator: {
        $jsonSchema: {
          bsonType: "object",
          required: ["period_name", "start_date", "end_date", "pay_date", "frequency", "year"],
          properties: {
            period_name: {
              bsonType: "string",
              maxLength: 100,
              description: "Name/identifier for the pay period (e.g., 'January 2024 - Week 1')"
            },
            start_date: {
              bsonType: "date",
              description: "Start date of the pay period"
            },
            end_date: {
              bsonType: "date",
              description: "End date of the pay period"
            },
            pay_date: {
              bsonType: "date",
              description: "Date when employees get paid"
            },
            frequency: {
              bsonType: "string",
              enum: ["weekly", "bi-weekly", "monthly", "semi-monthly"],
              description: "Pay frequency"
            },
            year: {
              bsonType: "int",
              minimum: 2020,
              maximum: 2050,
              description: "Year of the pay period"
            },
            period_number: {
              bsonType: "int",
              minimum: 1,
              maximum: 53,
              description: "Period number within the year"
            },
            status: {
              bsonType: "string",
              enum: ["draft", "open", "processing", "calculated", "approved", "closed", "cancelled"],
              description: "Status of the pay period"
            },
            cutoff_date: {
              bsonType: "date",
              description: "Cutoff date for timesheet submissions"
            },
            total_employees: {
              bsonType: "int",
              minimum: 0,
              description: "Total number of employees in this period"
            },
            total_hours: {
              bsonType: "number",
              minimum: 0,
              description: "Total hours worked across all employees"
            },
            total_gross_pay: {
              bsonType: "number",
              minimum: 0,
              description: "Total gross pay for the period"
            },
            total_deductions: {
              bsonType: "number",
              minimum: 0,
              description: "Total deductions for the period"
            },
            total_net_pay: {
              bsonType: "number",
              minimum: 0,
              description: "Total net pay for the period"
            },
            processed_at: {
              bsonType: "date",
              description: "When the period was processed"
            },
            processed_by: {
              bsonType: "objectId",
              description: "Who processed the period"
            },
            closed_at: {
              bsonType: "date",
              description: "When the period was closed"
            },
            closed_by: {
              bsonType: "objectId",
              description: "Who closed the period"
            },
            notes: {
              bsonType: "string",
              maxLength: 500,
              description: "Notes about the pay period"
            },
            created_at: {
              bsonType: "date",
              description: "Creation timestamp"
            },
            updated_at: {
              bsonType: "date",
              description: "Last update timestamp"
            },
            created_by: {
              bsonType: "objectId",
              description: "User who created the pay period"
            },
            updated_by: {
              bsonType: "objectId",
              description: "User who last updated the pay period"
            }
          }
        }
      }
    };
  }

  /**
   * Create a new pay period
   */
  static async create(db, periodData) {
    // Validate required fields
    if (!periodData.start_date || !periodData.end_date || !periodData.pay_date) {
      throw new Error('Start date, end date, and pay date are required');
    }

    const startDate = new Date(periodData.start_date);
    const endDate = new Date(periodData.end_date);
    const payDate = new Date(periodData.pay_date);

    // Validate date logic
    if (startDate >= endDate) {
      throw new Error('Start date must be before end date');
    }

    if (payDate < endDate) {
      throw new Error('Pay date must be on or after end date');
    }

    // Check for overlapping periods
    const overlapping = await db.collection('pay_periods').findOne({
      $or: [
        {
          start_date: { $lte: endDate },
          end_date: { $gte: startDate }
        }
      ],
      status: { $ne: 'cancelled' }
    });

    if (overlapping) {
      throw new Error('Pay period overlaps with existing period');
    }

    // Generate period name if not provided
    let periodName = periodData.period_name;
    if (!periodName) {
      const year = startDate.getFullYear();
      const month = moment(startDate).format('MMMM');
      const weekNumber = await this.getNextPeriodNumber(db, year, periodData.frequency);
      
      switch (periodData.frequency) {
        case 'weekly':
          periodName = `${month} ${year} - Week ${weekNumber}`;
          break;
        case 'bi-weekly':
          periodName = `${month} ${year} - Period ${weekNumber}`;
          break;
        case 'monthly':
          periodName = `${month} ${year}`;
          break;
        case 'semi-monthly':
          periodName = `${month} ${year} - ${weekNumber <= 15 ? '1st' : '2nd'} Half`;
          break;
        default:
          periodName = `${month} ${year} - Period ${weekNumber}`;
      }
    }

    // Calculate cutoff date (default to end date)
    const cutoffDate = periodData.cutoff_date ? 
      new Date(periodData.cutoff_date) : 
      new Date(endDate.getTime() + (24 * 60 * 60 * 1000)); // End date + 1 day

    const periodNumber = await this.getNextPeriodNumber(db, startDate.getFullYear(), periodData.frequency);

    const payPeriod = {
      period_name: periodName,
      start_date: startDate,
      end_date: endDate,
      pay_date: payDate,
      frequency: periodData.frequency,
      year: startDate.getFullYear(),
      period_number: periodNumber,
      status: periodData.status || 'draft',
      cutoff_date: cutoffDate,
      total_employees: 0,
      total_hours: 0,
      total_gross_pay: 0,
      total_deductions: 0,
      total_net_pay: 0,
      notes: periodData.notes || '',
      created_at: new Date(),
      updated_at: new Date(),
      created_by: new ObjectId(periodData.created_by)
    };

    const result = await db.collection('pay_periods').insertOne(payPeriod);
    return { ...payPeriod, _id: result.insertedId };
  }

  /**
   * Get next period number for the year and frequency
   */
  static async getNextPeriodNumber(db, year, frequency) {
    const lastPeriod = await db.collection('pay_periods')
      .findOne(
        { year: year, frequency: frequency },
        { sort: { period_number: -1 } }
      );

    return lastPeriod ? lastPeriod.period_number + 1 : 1;
  }

  /**
   * Find pay period by ID
   */
  static async findById(db, periodId) {
    return await db.collection('pay_periods').findOne({
      _id: new ObjectId(periodId)
    });
  }

  /**
   * Find pay periods by criteria
   */
  static async find(db, criteria = {}, options = {}) {
    const filter = {};

    if (criteria.year) {
      filter.year = criteria.year;
    }

    if (criteria.frequency) {
      filter.frequency = criteria.frequency;
    }

    if (criteria.status) {
      filter.status = criteria.status;
    }

    if (criteria.startDate || criteria.endDate) {
      filter.start_date = {};
      if (criteria.startDate) filter.start_date.$gte = new Date(criteria.startDate);
      if (criteria.endDate) filter.start_date.$lte = new Date(criteria.endDate);
    }

    return await db.collection('pay_periods')
      .find(filter)
      .sort({ start_date: -1 })
      .limit(options.limit || 50)
      .skip(options.skip || 0)
      .toArray();
  }

  /**
   * Find current active pay period
   */
  static async findCurrent(db) {
    const today = new Date();
    return await db.collection('pay_periods').findOne({
      start_date: { $lte: today },
      end_date: { $gte: today },
      status: { $in: ['open', 'processing'] }
    });
  }

  /**
   * Open pay period for timesheet submissions
   */
  static async open(db, periodId, openedBy) {
    const result = await db.collection('pay_periods').updateOne(
      { 
        _id: new ObjectId(periodId),
        status: 'draft'
      },
      {
        $set: {
          status: 'open',
          updated_at: new Date(),
          updated_by: new ObjectId(openedBy)
        }
      }
    );

    return result.modifiedCount > 0;
  }

  /**
   * Start processing the pay period
   */
  static async startProcessing(db, periodId, processedBy) {
    const result = await db.collection('pay_periods').updateOne(
      { 
        _id: new ObjectId(periodId),
        status: 'open'
      },
      {
        $set: {
          status: 'processing',
          processed_at: new Date(),
          processed_by: new ObjectId(processedBy),
          updated_at: new Date(),
          updated_by: new ObjectId(processedBy)
        }
      }
    );

    return result.modifiedCount > 0;
  }

  /**
   * Close pay period
   */
  static async close(db, periodId, closedBy) {
    const result = await db.collection('pay_periods').updateOne(
      { 
        _id: new ObjectId(periodId),
        status: 'processing'
      },
      {
        $set: {
          status: 'closed',
          closed_at: new Date(),
          closed_by: new ObjectId(closedBy),
          updated_at: new Date(),
          updated_by: new ObjectId(closedBy)
        }
      }
    );

    return result.modifiedCount > 0;
  }

  /**
   * Update pay period totals
   */
  static async updateTotals(db, periodId, totals) {
    const result = await db.collection('pay_periods').updateOne(
      { _id: new ObjectId(periodId) },
      {
        $set: {
          total_employees: totals.total_employees || 0,
          total_hours: totals.total_hours || 0,
          total_gross_pay: totals.total_gross_pay || 0,
          total_deductions: totals.total_deductions || 0,
          total_net_pay: totals.total_net_pay || 0,
          updated_at: new Date()
        }
      }
    );

    return result.modifiedCount > 0;
  }

  /**
   * Calculate period totals exclusively from payroll calculations
   */
  static async calculateTotals(db, periodId) {
    try {
      const period = await this.findById(db, periodId);
      if (!period) {
        throw new Error('Pay period not found');
      }

      // Get all totals exclusively from payroll calculations
      const calculationTotals = await db.collection('payroll_calculations').aggregate([
        {
          $match: {
            pay_period_id: new ObjectId(periodId),
            status: { $in: ['calculated', 'approved', 'paid'] } // Include calculated, approved, and paid calculations
          }
        },
        {
          $group: {
            _id: null,
            total_employees: { $addToSet: '$employee_id' },
            total_hours: { $sum: '$total_hours' },
            regular_hours: { $sum: '$regular_hours' },
            overtime_hours: { $sum: '$overtime_hours' },
            total_gross_pay: { $sum: '$gross_pay' },
            total_deductions: { $sum: '$total_deductions' },
            total_net_pay: { $sum: '$net_pay' }
          }
        },
        {
          $project: {
            total_employees: { $size: '$total_employees' },
            total_hours: 1,
            regular_hours: 1,
            overtime_hours: 1,
            total_gross_pay: 1,
            total_deductions: 1,
            total_net_pay: 1
          }
        }
      ]).toArray();

      // If no calculations exist, return zero totals
      const result = calculationTotals[0];
      if (!result) {
        const zeroTotals = {
          total_employees: 0,
          total_hours: 0,
          regular_hours: 0,
          overtime_hours: 0,
          total_gross_pay: 0,
          total_deductions: 0,
          total_net_pay: 0
        };
        
        await this.updateTotals(db, periodId, zeroTotals);
        return zeroTotals;
      }

      const totals = {
        total_employees: result.total_employees || 0,
        total_hours: result.total_hours || 0,
        regular_hours: result.regular_hours || 0,
        overtime_hours: result.overtime_hours || 0,
        total_gross_pay: result.total_gross_pay || 0,
        total_deductions: result.total_deductions || 0,
        total_net_pay: result.total_net_pay || 0
      };

      // Validate that net pay calculation is correct
      const expectedNetPay = totals.total_gross_pay - totals.total_deductions;
      if (Math.abs(totals.total_net_pay - expectedNetPay) > 0.01) {
        console.warn(`Pay period ${periodId}: Net pay calculation mismatch. Expected: ${expectedNetPay}, Actual: ${totals.total_net_pay}`);
        // Use the calculated value to ensure consistency
        totals.total_net_pay = expectedNetPay;
      }

      await this.updateTotals(db, periodId, totals);
      return totals;
    } catch (error) {
      console.error(`Error calculating totals for pay period ${periodId}:`, error);
      throw new Error(`Failed to calculate pay period totals: ${error.message}`);
    }
  }

  /**
   * Get pay period statistics
   */
  static async getStatistics(db, year) {
    const pipeline = [
      {
        $match: {
          year: year || new Date().getFullYear(),
          status: { $ne: 'cancelled' }
        }
      },
      {
        $group: {
          _id: '$frequency',
          count: { $sum: 1 },
          total_gross_pay: { $sum: '$total_gross_pay' },
          total_deductions: { $sum: '$total_deductions' },
          total_net_pay: { $sum: '$total_net_pay' },
          total_hours: { $sum: '$total_hours' },
          total_employees: { $max: '$total_employees' }
        }
      }
    ];

    return await db.collection('pay_periods').aggregate(pipeline).toArray();
  }

  /**
   * Update pay period
   */
  static async update(db, periodId, updateData) {
    // Don't allow updates to closed periods
    const period = await this.findById(db, periodId);
    if (!period) {
      throw new Error('Pay period not found');
    }

    if (period.status === 'closed') {
      throw new Error('Cannot update closed pay period');
    }

    // Handle date updates with validation
    if (updateData.start_date || updateData.end_date) {
      const startDate = updateData.start_date ? new Date(updateData.start_date) : period.start_date;
      const endDate = updateData.end_date ? new Date(updateData.end_date) : period.end_date;

      if (startDate >= endDate) {
        throw new Error('Start date must be before end date');
      }

      updateData.start_date = startDate;
      updateData.end_date = endDate;
    }

    if (updateData.pay_date) {
      updateData.pay_date = new Date(updateData.pay_date);
    }

    if (updateData.cutoff_date) {
      updateData.cutoff_date = new Date(updateData.cutoff_date);
    }

    const result = await db.collection('pay_periods').updateOne(
      { _id: new ObjectId(periodId) },
      {
        $set: {
          ...updateData,
          updated_at: new Date(),
          updated_by: new ObjectId(updateData.updated_by)
        }
      }
    );

    return result.modifiedCount > 0;
  }

  /**
   * Delete pay period (only if draft and no associated data)
   */
  static async delete(db, periodId) {
    // Check if period has any associated timesheets or calculations
    const timesheetCount = await db.collection('timesheets').countDocuments({
      work_date: {
        $gte: (await this.findById(db, periodId)).start_date,
        $lte: (await this.findById(db, periodId)).end_date
      }
    });

    if (timesheetCount > 0) {
      throw new Error('Cannot delete pay period with associated timesheets');
    }

    const calculationCount = await db.collection('payroll_calculations').countDocuments({
      pay_period_id: new ObjectId(periodId)
    });

    if (calculationCount > 0) {
      throw new Error('Cannot delete pay period with associated calculations');
    }

    const result = await db.collection('pay_periods').deleteOne({
      _id: new ObjectId(periodId),
      status: 'draft'
    });

    return result.deletedCount > 0;
  }
}

module.exports = PayPeriod;