const { ObjectId } = require('mongodb');

/**
 * Message Model
 * Provides structure and methods for Message data
 */
class Message {
  /**
   * Get MongoDB schema validation for messages collection
   * @returns {Object} MongoDB schema validation object
   */
  static getSchema() {
    return {
      validator: {
        $jsonSchema: {
          bsonType: "object",
          required: [
            "conversation_id", "sender_id", "content_encrypted", 
            "message_type", "created_at", "updated_at"
          ],
          properties: {
            conversation_id: { bsonType: "objectId" },
            sender_id: { bsonType: "objectId" },
            
            // Encrypted message content
            content_encrypted: { bsonType: "string" },
            
            // Message metadata
            message_type: { 
              bsonType: "string",
              enum: ["text", "system", "announcement", "image", "voice_note"],
              description: "Type of message"
            },
            
            // File metadata (only for image and voice_note message types)
            file_id: { bsonType: "string" },
            original_name: { bsonType: "string" },
            mime_type: { bsonType: "string" },
            file_size: { bsonType: "number" },
            s3_key: { bsonType: "string" },
            duration: { 
              anyOf: [
                { bsonType: "number" },
                { bsonType: "null" }
              ]
            }, // For voice notes only
            
            // Sender information (denormalized for performance)
            sender: {
              bsonType: "object",
              required: ["name", "email"],
              properties: {
                name: { bsonType: "string" },
                email: { bsonType: "string" },
                branch_name: { 
                  anyOf: [
                    { bsonType: "string" },
                    { bsonType: "null" }
                  ]
                }
              }
            },
            
            // Optional fields
            parent_message_id: { 
              anyOf: [
                { bsonType: "objectId" },
                { bsonType: "null" }
              ]
            }, // For replies
            edited_at: { bsonType: "date" },
            deleted_at: { bsonType: "date" },
            
            // Timestamps
            created_at: { bsonType: "date" },
            updated_at: { bsonType: "date" }
          }
        }
      }
    };
  }

  /**
   * Get indexes for messages collection
   * @returns {Array} Array of index specifications
   */
  static getIndexes() {
    return [
      { conversation_id: 1, created_at: -1 }, // For fetching conversation messages
      { sender_id: 1, created_at: -1 },       // For user's message history
      { created_at: -1 },                     // For general sorting
      { deleted_at: 1 }                       // For filtering deleted messages
    ];
  }

  /**
   * Create a new message document
   * @param {Object} messageData Message data
   * @returns {Object} Formatted message document
   */
  static create(messageData) {
    const now = new Date();
    
    const message = {
      conversation_id: new ObjectId(messageData.conversation_id),
      sender_id: new ObjectId(messageData.sender_id),
      content_encrypted: messageData.content_encrypted,
      message_type: messageData.message_type || 'text',
      sender: {
        name: messageData.sender.name,
        email: messageData.sender.email,
        branch_name: messageData.sender.branch_name || null
      },
      parent_message_id: messageData.parent_message_id ? new ObjectId(messageData.parent_message_id) : null,
      created_at: now,
      updated_at: now
    };

    // Add file metadata if this is an image or voice note message
    if (messageData.message_type === 'image' || messageData.message_type === 'voice_note') {
      if (messageData.file_id) {
        message.file_id = messageData.file_id;
        message.original_name = messageData.original_name;
        message.mime_type = messageData.mime_type;
        message.file_size = messageData.file_size;
        message.s3_key = messageData.s3_key;
        
        // Only add duration for voice notes
        if (messageData.message_type === 'voice_note') {
          message.duration = messageData.duration || null;
        }
      }
    }

    return message;
  }

  /**
   * Validate message data
   * @param {Object} messageData Message data to validate
   * @returns {Object} Validation result
   */
  static validate(messageData) {
    const errors = [];

    if (!messageData.conversation_id) {
      errors.push('conversation_id is required');
    }

    if (!messageData.sender_id) {
      errors.push('sender_id is required');
    }

    if (!messageData.content_encrypted) {
      errors.push('content_encrypted is required');
    }

    if (!messageData.sender || !messageData.sender.name || !messageData.sender.email) {
      errors.push('sender information (name, email) is required');
    }

    const validTypes = ['text', 'system', 'announcement', 'image', 'voice_note'];
    if (messageData.message_type && !validTypes.includes(messageData.message_type)) {
      errors.push('message_type must be one of: ' + validTypes.join(', '));
    }

    // Validate file data for image and voice note messages
    if (messageData.message_type === 'image' || messageData.message_type === 'voice_note') {
      if (!messageData.file_id) {
        errors.push('file_id is required for image and voice note messages');
      }
      if (!messageData.s3_key) {
        errors.push('s3_key is required for image and voice note messages');
      }
      if (!messageData.original_name) {
        errors.push('original_name is required for image and voice note messages');
      }
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }
}

module.exports = Message;
