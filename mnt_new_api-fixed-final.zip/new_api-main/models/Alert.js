const { ObjectId } = require('mongodb');
const moment = require('moment');

class Alert {
  /**
   * Get collection validation schema for MongoDB
   */
  static getSchema() {
    return {
      validator: {
        $jsonSchema: {
          bsonType: "object",
          required: ["alert_type", "title", "message", "severity", "created_by"],
          properties: {
            alert_type: {
              bsonType: "string",
              enum: [
                "payroll_overdue", "timesheet_missing", "approval_pending", 
                "deduction_overdue", "budget_exceeded", "rate_change_needed",
                "system_error", "compliance_issue", "custom_alert"
              ],
              description: "Type of alert"
            },
            title: {
              bsonType: "string",
              maxLength: 200,
              description: "Alert title"
            },
            message: {
              bsonType: "string",
              maxLength: 1000,
              description: "Alert message content"
            },
            severity: {
              bsonType: "string",
              enum: ["low", "medium", "high", "critical"],
              description: "Alert severity level"
            },
            status: {
              bsonType: "string",
              enum: ["active", "acknowledged", "resolved", "dismissed"],
              description: "Alert status"
            },
            related_entity: {
              bsonType: "object",
              properties: {
                entity_type: {
                  bsonType: "string",
                  enum: ["employee", "pay_period", "timesheet", "calculation", "deduction", "system"],
                  description: "Type of related entity"
                },
                entity_id: {
                  bsonType: "objectId",
                  description: "ID of related entity"
                },
                entity_name: {
                  bsonType: "string",
                  description: "Name or identifier of related entity"
                }
              },
              description: "Entity this alert relates to"
            },
            target_users: {
              bsonType: "array",
              items: {
                bsonType: "objectId"
              },
              description: "Users who should receive this alert"
            },
            target_roles: {
              bsonType: "array",
              items: {
                bsonType: "string"
              },
              description: "Roles that should receive this alert"
            },
            auto_generated: {
              bsonType: "bool",
              description: "Whether this alert was automatically generated"
            },
            trigger_conditions: {
              bsonType: "object",
              properties: {
                condition_type: {
                  bsonType: "string",
                  enum: ["schedule", "threshold", "deadline", "event", "manual"]
                },
                threshold_value: {
                  bsonType: "number",
                  description: "Threshold value for triggered alerts"
                },
                deadline_date: {
                  bsonType: "date",
                  description: "Deadline that triggered the alert"
                },
                check_frequency: {
                  bsonType: "string",
                  enum: ["hourly", "daily", "weekly", "monthly"],
                  description: "How often to check this condition"
                }
              },
              description: "Conditions that triggered this alert"
            },
            action_required: {
              bsonType: "bool",
              description: "Whether this alert requires user action"
            },
            action_items: {
              bsonType: "array",
              items: {
                bsonType: "object",
                properties: {
                  action: {
                    bsonType: "string",
                    description: "Required action"
                  },
                  assigned_to: {
                    bsonType: "objectId",
                    description: "User assigned to complete this action"
                  },
                  due_date: {
                    bsonType: "date",
                    description: "When this action should be completed"
                  },
                  completed: {
                    bsonType: "bool",
                    description: "Whether action has been completed"
                  },
                  completed_at: {
                    bsonType: "date",
                    description: "When action was completed"
                  }
                }
              },
              description: "Actions required to resolve this alert"
            },
            notification_sent: {
              bsonType: "bool",
              description: "Whether notification has been sent"
            },
            notification_methods: {
              bsonType: "array",
              items: {
                bsonType: "string",
                enum: ["email", "sms", "push", "dashboard"]
              },
              description: "Methods used to notify users"
            },
            acknowledged_by: {
              bsonType: "objectId",
              description: "User who acknowledged the alert"
            },
            acknowledged_at: {
              bsonType: "date",
              description: "When alert was acknowledged"
            },
            resolved_by: {
              bsonType: "objectId",
              description: "User who resolved the alert"
            },
            resolved_at: {
              bsonType: "date",
              description: "When alert was resolved"
            },
            resolution_notes: {
              bsonType: "string",
              maxLength: 500,
              description: "Notes about how alert was resolved"
            },
            expires_at: {
              bsonType: "date",
              description: "When alert expires if not resolved"
            },
            recurring: {
              bsonType: "bool",
              description: "Whether this is a recurring alert"
            },
            recurrence_pattern: {
              bsonType: "object",
              properties: {
                frequency: {
                  bsonType: "string",
                  enum: ["daily", "weekly", "monthly", "quarterly"]
                },
                next_occurrence: {
                  bsonType: "date",
                  description: "When next alert should trigger"
                },
                last_triggered: {
                  bsonType: "date",
                  description: "When alert was last triggered"
                }
              },
              description: "Recurrence settings for repeating alerts"
            },
            metadata: {
              bsonType: "object",
              description: "Additional data specific to alert type"
            },
            created_at: {
              bsonType: "date",
              description: "Creation timestamp"
            },
            updated_at: {
              bsonType: "date",
              description: "Last update timestamp"
            },
            created_by: {
              bsonType: "objectId",
              description: "User who created the alert"
            },
            updated_by: {
              bsonType: "objectId",
              description: "User who last updated the alert"
            }
          }
        }
      }
    };
  }

  /**
   * Create a new alert
   */
  static async create(db, alertData) {
    const alert = {
      alert_type: alertData.alert_type,
      title: alertData.title,
      message: alertData.message,
      severity: alertData.severity,
      status: alertData.status || 'active',
      related_entity: alertData.related_entity || null,
      target_users: alertData.target_users ? 
        alertData.target_users.map(id => new ObjectId(id)) : [],
      target_roles: alertData.target_roles || [],
      auto_generated: alertData.auto_generated || false,
      trigger_conditions: alertData.trigger_conditions || null,
      action_required: alertData.action_required || false,
      action_items: alertData.action_items || [],
      notification_sent: false,
      notification_methods: alertData.notification_methods || ['dashboard'],
      recurring: alertData.recurring || false,
      recurrence_pattern: alertData.recurrence_pattern || null,
      metadata: alertData.metadata || {},
      created_at: new Date(),
      updated_at: new Date(),
      created_by: new ObjectId(alertData.created_by)
    };

    // Set expiration date if not provided
    if (alertData.expires_at) {
      alert.expires_at = new Date(alertData.expires_at);
    } else {
      // Default expiration based on severity
      const hoursToExpire = {
        'critical': 24,
        'high': 72,
        'medium': 168, // 1 week
        'low': 720 // 30 days
      };
      
      const hours = hoursToExpire[alertData.severity] || 168;
      alert.expires_at = new Date(Date.now() + (hours * 60 * 60 * 1000));
    }

    const result = await db.collection('alerts').insertOne(alert);
    return { ...alert, _id: result.insertedId };
  }

  /**
   * Create payroll overdue alert
   */
  static async createPayrollOverdueAlert(db, payPeriod, createdBy) {
    return await this.create(db, {
      alert_type: 'payroll_overdue',
      title: `Payroll Overdue: ${payPeriod.period_name}`,
      message: `Payroll for pay period ${payPeriod.period_name} is overdue. Pay date was ${moment(payPeriod.pay_date).format('MMM DD, YYYY')}.`,
      severity: 'high',
      related_entity: {
        entity_type: 'pay_period',
        entity_id: payPeriod._id,
        entity_name: payPeriod.period_name
      },
      target_roles: ['Admin', 'Supervisor'],
      auto_generated: true,
      trigger_conditions: {
        condition_type: 'deadline',
        deadline_date: payPeriod.pay_date,
        check_frequency: 'daily'
      },
      action_required: true,
      action_items: [
        {
          action: 'Process payroll calculations',
          due_date: new Date(Date.now() + (24 * 60 * 60 * 1000)), // 24 hours
          completed: false
        },
        {
          action: 'Generate pay stubs',
          due_date: new Date(Date.now() + (24 * 60 * 60 * 1000)),
          completed: false
        }
      ],
      notification_methods: ['email', 'dashboard'],
      created_by: createdBy
    });
  }

  /**
   * Create missing timesheet alert
   */
  static async createMissingTimesheetAlert(db, employee, payPeriod, createdBy) {
    return await this.create(db, {
      alert_type: 'timesheet_missing',
      title: `Missing Timesheet: ${employee.first_name} ${employee.last_name}`,
      message: `Employee ${employee.first_name} ${employee.last_name} has not submitted timesheet for pay period ${payPeriod.period_name}.`,
      severity: 'medium',
      related_entity: {
        entity_type: 'employee',
        entity_id: employee._id,
        entity_name: `${employee.first_name} ${employee.last_name}`
      },
      target_users: [employee._id],
      target_roles: ['Supervisor'],
      auto_generated: true,
      trigger_conditions: {
        condition_type: 'deadline',
        deadline_date: payPeriod.cutoff_date,
        check_frequency: 'daily'
      },
      action_required: true,
      action_items: [
        {
          action: 'Submit timesheet',
          assigned_to: employee._id,
          due_date: payPeriod.cutoff_date,
          completed: false
        }
      ],
      notification_methods: ['email', 'dashboard'],
      created_by: createdBy
    });
  }

  /**
   * Create approval pending alert
   */
  static async createApprovalPendingAlert(db, entityType, entityId, entityName, approverRole, createdBy) {
    const entityTypes = {
      'timesheet': 'Timesheet approval pending',
      'deduction': 'Deduction approval pending',
      'calculation': 'Payroll calculation approval pending'
    };

    return await this.create(db, {
      alert_type: 'approval_pending',
      title: entityTypes[entityType] || 'Approval pending',
      message: `${entityName} requires approval before processing can continue.`,
      severity: 'medium',
      related_entity: {
        entity_type: entityType,
        entity_id: new ObjectId(entityId),
        entity_name: entityName
      },
      target_roles: [approverRole],
      auto_generated: true,
      trigger_conditions: {
        condition_type: 'event',
        check_frequency: 'daily'
      },
      action_required: true,
      action_items: [
        {
          action: `Review and approve ${entityType}`,
          due_date: new Date(Date.now() + (48 * 60 * 60 * 1000)), // 48 hours
          completed: false
        }
      ],
      notification_methods: ['dashboard'],
      created_by: createdBy
    });
  }

  /**
   * Create budget exceeded alert
   */
  static async createBudgetExceededAlert(db, budget, actualAmount, createdBy) {
    const exceededBy = actualAmount - budget.amount;
    const percentageOver = ((exceededBy / budget.amount) * 100).toFixed(1);

    return await this.create(db, {
      alert_type: 'budget_exceeded',
      title: `Budget Exceeded: ${budget.name}`,
      message: `Budget "${budget.name}" has been exceeded by $${exceededBy.toFixed(2)} (${percentageOver}%). Actual: $${actualAmount.toFixed(2)}, Budget: $${budget.amount.toFixed(2)}.`,
      severity: 'high',
      related_entity: {
        entity_type: 'budget',
        entity_id: budget._id,
        entity_name: budget.name
      },
      target_roles: ['Admin', 'Supervisor'],
      auto_generated: true,
      trigger_conditions: {
        condition_type: 'threshold',
        threshold_value: budget.amount,
        check_frequency: 'daily'
      },
      action_required: true,
      action_items: [
        {
          action: 'Review budget allocation',
          due_date: new Date(Date.now() + (24 * 60 * 60 * 1000)),
          completed: false
        },
        {
          action: 'Adjust spending or increase budget',
          due_date: new Date(Date.now() + (72 * 60 * 60 * 1000)),
          completed: false
        }
      ],
      notification_methods: ['email', 'dashboard'],
      metadata: {
        budget_amount: budget.amount,
        actual_amount: actualAmount,
        exceeded_by: exceededBy,
        percentage_over: parseFloat(percentageOver)
      },
      created_by: createdBy
    });
  }

  /**
   * Find alert by ID
   */
  static async findById(db, alertId) {
    return await db.collection('alerts').findOne({
      _id: new ObjectId(alertId)
    });
  }

  /**
   * Find alerts for user
   */
  static async findForUser(db, userId, options = {}) {
    const filter = {
      $or: [
        { target_users: new ObjectId(userId) },
        { created_by: new ObjectId(userId) }
      ]
    };

    // Add role-based alerts if user has specific roles
    if (options.userRoles && options.userRoles.length > 0) {
      filter.$or.push({ target_roles: { $in: options.userRoles } });
    }

    if (options.status) {
      filter.status = options.status;
    }

    if (options.severity) {
      filter.severity = options.severity;
    }

    if (options.alert_type) {
      filter.alert_type = options.alert_type;
    }

    // Only show active alerts by default
    if (!options.include_expired) {
      filter.expires_at = { $gt: new Date() };
    }

    return await db.collection('alerts')
      .find(filter)
      .sort({ created_at: -1, severity: -1 })
      .limit(options.limit || 100)
      .skip(options.skip || 0)
      .toArray();
  }

  /**
   * Acknowledge alert
   */
  static async acknowledge(db, alertId, acknowledgedBy) {
    const result = await db.collection('alerts').updateOne(
      { 
        _id: new ObjectId(alertId),
        status: 'active'
      },
      {
        $set: {
          status: 'acknowledged',
          acknowledged_by: new ObjectId(acknowledgedBy),
          acknowledged_at: new Date(),
          updated_at: new Date(),
          updated_by: new ObjectId(acknowledgedBy)
        }
      }
    );

    return result.modifiedCount > 0;
  }

  /**
   * Resolve alert
   */
  static async resolve(db, alertId, resolvedBy, resolutionNotes = '') {
    const result = await db.collection('alerts').updateOne(
      { 
        _id: new ObjectId(alertId),
        status: { $in: ['active', 'acknowledged'] }
      },
      {
        $set: {
          status: 'resolved',
          resolved_by: new ObjectId(resolvedBy),
          resolved_at: new Date(),
          resolution_notes: resolutionNotes,
          updated_at: new Date(),
          updated_by: new ObjectId(resolvedBy)
        }
      }
    );

    return result.modifiedCount > 0;
  }

  /**
   * Dismiss alert
   */
  static async dismiss(db, alertId, dismissedBy) {
    const result = await db.collection('alerts').updateOne(
      { 
        _id: new ObjectId(alertId),
        status: { $in: ['active', 'acknowledged'] }
      },
      {
        $set: {
          status: 'dismissed',
          updated_at: new Date(),
          updated_by: new ObjectId(dismissedBy)
        }
      }
    );

    return result.modifiedCount > 0;
  }

  /**
   * Mark notification as sent
   */
  static async markNotificationSent(db, alertId) {
    const result = await db.collection('alerts').updateOne(
      { _id: new ObjectId(alertId) },
      {
        $set: {
          notification_sent: true,
          updated_at: new Date()
        }
      }
    );

    return result.modifiedCount > 0;
  }

  /**
   * Update action item
   */
  static async updateActionItem(db, alertId, actionIndex, completed, completedBy = null) {
    const updateData = {
      [`action_items.${actionIndex}.completed`]: completed,
      updated_at: new Date()
    };

    if (completed && completedBy) {
      updateData[`action_items.${actionIndex}.completed_at`] = new Date();
    }

    const result = await db.collection('alerts').updateOne(
      { _id: new ObjectId(alertId) },
      { $set: updateData }
    );

    // Check if all actions are completed and auto-resolve
    if (completed) {
      const alert = await this.findById(db, alertId);
      if (alert && alert.action_items) {
        const allCompleted = alert.action_items.every((item, index) => 
          index === actionIndex ? true : item.completed
        );
        
        if (allCompleted) {
          await this.resolve(db, alertId, completedBy, 'Auto-resolved: All action items completed');
        }
      }
    }

    return result.modifiedCount > 0;
  }

  /**
   * Get alert statistics
   */
  static async getStatistics(db, options = {}) {
    const matchStage = {};
    
    if (options.user_id) {
      matchStage.$or = [
        { target_users: new ObjectId(options.user_id) },
        { created_by: new ObjectId(options.user_id) }
      ];
    }

    if (options.start_date || options.end_date) {
      matchStage.created_at = {};
      if (options.start_date) matchStage.created_at.$gte = new Date(options.start_date);
      if (options.end_date) matchStage.created_at.$lte = new Date(options.end_date);
    }

    const pipeline = [
      { $match: matchStage },
      {
        $group: {
          _id: '$status',
          count: { $sum: 1 },
          by_severity: {
            $push: {
              severity: '$severity',
              alert_type: '$alert_type'
            }
          }
        }
      }
    ];

    const statusStats = await db.collection('alerts').aggregate(pipeline).toArray();

    // Get severity breakdown
    const severityPipeline = [
      { $match: matchStage },
      {
        $group: {
          _id: '$severity',
          count: { $sum: 1 }
        }
      }
    ];

    const severityStats = await db.collection('alerts').aggregate(severityPipeline).toArray();

    return {
      by_status: statusStats,
      by_severity: severityStats
    };
  }

  /**
   * Clean up expired alerts
   */
  static async cleanupExpired(db) {
    const result = await db.collection('alerts').deleteMany({
      expires_at: { $lt: new Date() },
      status: { $in: ['resolved', 'dismissed'] }
    });

    return result.deletedCount;
  }

  /**
   * Get alerts requiring action
   */
  static async getActionRequired(db, userId, userRoles = []) {
    const filter = {
      action_required: true,
      status: { $in: ['active', 'acknowledged'] },
      expires_at: { $gt: new Date() },
      $or: [
        { target_users: new ObjectId(userId) },
        { target_roles: { $in: userRoles } },
        { 'action_items.assigned_to': new ObjectId(userId) }
      ]
    };

    return await db.collection('alerts')
      .find(filter)
      .sort({ severity: -1, created_at: -1 })
      .toArray();
  }

  /**
   * Check for recurring alerts that need to be triggered
   */
  static async checkRecurringAlerts(db) {
    const now = new Date();
    
    const recurringAlerts = await db.collection('alerts').find({
      recurring: true,
      'recurrence_pattern.next_occurrence': { $lte: now },
      status: { $ne: 'dismissed' }
    }).toArray();

    const triggeredAlerts = [];

    for (const alert of recurringAlerts) {
      // Create new instance of the alert
      const newAlert = {
        ...alert,
        _id: undefined,
        status: 'active',
        acknowledged_by: undefined,
        acknowledged_at: undefined,
        resolved_by: undefined,
        resolved_at: undefined,
        resolution_notes: undefined,
        notification_sent: false,
        created_at: now,
        updated_at: now
      };

      const result = await db.collection('alerts').insertOne(newAlert);
      triggeredAlerts.push({ ...newAlert, _id: result.insertedId });

      // Update next occurrence
      const frequency = alert.recurrence_pattern.frequency;
      let nextOccurrence;
      
      switch (frequency) {
        case 'daily':
          nextOccurrence = moment(now).add(1, 'day').toDate();
          break;
        case 'weekly':
          nextOccurrence = moment(now).add(1, 'week').toDate();
          break;
        case 'monthly':
          nextOccurrence = moment(now).add(1, 'month').toDate();
          break;
        case 'quarterly':
          nextOccurrence = moment(now).add(3, 'months').toDate();
          break;
        default:
          nextOccurrence = moment(now).add(1, 'day').toDate();
      }

      await db.collection('alerts').updateOne(
        { _id: alert._id },
        {
          $set: {
            'recurrence_pattern.next_occurrence': nextOccurrence,
            'recurrence_pattern.last_triggered': now,
            updated_at: now
          }
        }
      );
    }

    return triggeredAlerts;
  }
}

module.exports = Alert;