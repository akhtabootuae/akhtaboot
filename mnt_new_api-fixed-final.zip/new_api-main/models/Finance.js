const { ObjectId } = require('mongodb');
const moment = require('moment');

/**
 * Finance Model
 * Provides financial calculation methods and analytics
 */
class Finance {
  constructor(db) {
    this.db = db;
  }

  /**
   * Calculate revenue for a given period and branch
   * @param {Object} filters - Date range, branch_id, etc.
   * @returns {Object} Revenue breakdown
   */
  async calculateRevenue(filters = {}) {
    const { start_date, end_date, branch_id } = filters;
    
    const matchStage = {};
    
    // Date filtering
    if (start_date || end_date) {
      matchStage.invoice_date = {};
      if (start_date) matchStage.invoice_date.$gte = new Date(start_date);
      if (end_date) matchStage.invoice_date.$lte = new Date(end_date);
    }
    
    // Branch filtering
    if (branch_id) {
      matchStage.branch_id = new ObjectId(branch_id);
    }

    const pipeline = [
      { $match: matchStage },
      {
        $group: {
          _id: null,
          total_invoices: { $sum: 1 },
          total_revenue: { $sum: "$total_price" },
          total_revenue_before_vat: { $sum: "$price_before_vat" },
          total_vat_amount: { $sum: "$vat_amount" },
          average_invoice_value: { $avg: "$total_price" },
          total_paid: {
            $sum: {
              $reduce: {
                input: "$payment_records",
                initialValue: 0,
                in: { $add: ["$$value", "$$this.amount"] }
              }
            }
          },
          total_real_value: { $sum: "$real_value" }
        }
      },
      {
        $addFields: {
          outstanding_amount: { $subtract: ["$total_revenue", "$total_paid"] }
        }
      }
    ];

    const result = await this.db.collection('invoices').aggregate(pipeline).toArray();
    
    return result[0] || {
      total_invoices: 0,
      total_revenue: 0,
      total_revenue_before_vat: 0,
      total_vat_amount: 0,
      average_invoice_value: 0,
      total_paid: 0,
      total_real_value: 0,
      outstanding_amount: 0
    };
  }

  /**
   * Calculate expenses for a given period and branch
   * @param {Object} filters - Date range, branch_id, expense_type, etc.
   * @returns {Object} Expense breakdown
   */
  async calculateExpenses(filters = {}) {
    const { start_date, end_date, branch_id, expense_type } = filters;
    
    const matchStage = {};
    
    // Date filtering
    if (start_date || end_date) {
      matchStage.date = {};
      if (start_date) matchStage.date.$gte = new Date(start_date);
      if (end_date) matchStage.date.$lte = new Date(end_date);
    }
    
    // Branch filtering
    if (branch_id) {
      matchStage.branch_id = new ObjectId(branch_id);
    }
    
    // Expense type filtering
    if (expense_type) {
      matchStage.expense_type = expense_type;
    }

    const pipeline = [
      { $match: matchStage },
      {
        $group: {
          _id: null,
          total_expenses: { $sum: 1 },
          total_amount: { $sum: "$amount" },
          average_expense: { $avg: "$amount" },
          expense_breakdown: {
            $push: {
              expense_type: "$expense_type",
              amount: "$amount"
            }
          }
        }
      }
    ];

    // Get expenses by category
    const categoryPipeline = [
      { $match: matchStage },
      {
        $group: {
          _id: "$expense_type",
          total_amount: { $sum: "$amount" },
          count: { $sum: 1 },
          average_amount: { $avg: "$amount" }
        }
      },
      { $sort: { total_amount: -1 } }
    ];

    const [totalResult, categoryResult] = await Promise.all([
      this.db.collection('expenses').aggregate(pipeline).toArray(),
      this.db.collection('expenses').aggregate(categoryPipeline).toArray()
    ]);

    return {
      summary: totalResult[0] || {
        total_expenses: 0,
        total_amount: 0,
        average_expense: 0
      },
      by_category: categoryResult
    };
  }

  /**
   * Calculate payroll costs for a given period and branch
   * @param {Object} filters - Date range, branch_id, etc.
   * @returns {Object} Payroll breakdown
   */
  async calculatePayrollCosts(filters = {}) {
    const { start_date, end_date, branch_id } = filters;
    
    const matchStage = {};
    
    // For payroll, we need to join with users to get branch information
    const pipeline = [
      {
        $lookup: {
          from: 'users',
          localField: 'employee_id',
          foreignField: '_id',
          as: 'employee'
        }
      },
      { $unwind: '$employee' }
    ];

    // Branch filtering
    if (branch_id) {
      pipeline.push({
        $match: { 'employee.branch.branch_id': new ObjectId(branch_id) }
      });
    }

    // Date filtering would need to be based on pay_period - this is a simplified version
    if (start_date || end_date) {
      const dateMatch = {};
      if (start_date) dateMatch.$gte = new Date(start_date);
      if (end_date) dateMatch.$lte = new Date(end_date);
      pipeline.push({
        $match: { created_at: dateMatch }
      });
    }

    pipeline.push({
      $group: {
        _id: null,
        total_employees: { $addToSet: '$employee_id' },
        total_gross_pay: { $sum: '$gross_pay' },
        total_deductions: { $sum: '$total_deductions' },
        total_net_pay: { $sum: '$net_pay' },
        total_regular_pay: { $sum: '$regular_pay' },
        total_overtime_pay: { $sum: '$overtime_pay' },
        total_hours: { $sum: '$total_hours' },
        total_overtime_hours: { $sum: '$overtime_hours' }
      }
    });

    pipeline.push({
      $addFields: {
        employee_count: { $size: '$total_employees' },
        average_gross_pay: { $divide: ['$total_gross_pay', { $size: '$total_employees' }] },
        average_net_pay: { $divide: ['$total_net_pay', { $size: '$total_employees' }] }
      }
    });

    const result = await this.db.collection('payroll_calculations').aggregate(pipeline).toArray();
    
    return result[0] || {
      employee_count: 0,
      total_gross_pay: 0,
      total_deductions: 0,
      total_net_pay: 0,
      total_regular_pay: 0,
      total_overtime_pay: 0,
      total_hours: 0,
      total_overtime_hours: 0,
      average_gross_pay: 0,
      average_net_pay: 0
    };
  }

  /**
   * Calculate profit/loss for a given period
   * @param {Object} filters - Date range, branch_id, etc.
   * @returns {Object} Profit/loss analysis
   */
  async calculateProfitLoss(filters = {}) {
    const [revenue, expenses, payroll] = await Promise.all([
      this.calculateRevenue(filters),
      this.calculateExpenses(filters),
      this.calculatePayrollCosts(filters)
    ]);

    const total_costs = expenses.summary.total_amount + payroll.total_gross_pay;
    const gross_profit = revenue.total_revenue - total_costs;
    const net_profit = revenue.total_paid - total_costs; // Based on actual payments received
    
    const profit_margin = revenue.total_revenue > 0 ? (gross_profit / revenue.total_revenue) * 100 : 0;
    const net_profit_margin = revenue.total_paid > 0 ? (net_profit / revenue.total_paid) * 100 : 0;

    return {
      period_summary: {
        total_revenue: revenue.total_revenue,
        total_paid: revenue.total_paid,
        outstanding_amount: revenue.outstanding_amount,
        total_expenses: expenses.summary.total_amount,
        total_payroll_costs: payroll.total_gross_pay,
        total_costs: total_costs,
        gross_profit: gross_profit,
        net_profit: net_profit,
        profit_margin: profit_margin,
        net_profit_margin: net_profit_margin
      },
      revenue_breakdown: revenue,
      expense_breakdown: expenses,
      payroll_breakdown: payroll
    };
  }

  /**
   * Get financial dashboard data
   * @param {Object} filters - Date range, branch_id, etc.
   * @returns {Object} Dashboard metrics
   */
  async getDashboardMetrics(filters = {}) {
    const currentPeriod = await this.calculateProfitLoss(filters);
    
    // Calculate previous period for comparison (assuming monthly comparison)
    const prevFilters = { ...filters };
    if (filters.start_date && filters.end_date) {
      const start = moment(filters.start_date);
      const end = moment(filters.end_date);
      const duration = end.diff(start);
      
      prevFilters.start_date = start.subtract(duration).format('YYYY-MM-DD');
      prevFilters.end_date = moment(filters.start_date).format('YYYY-MM-DD');
    }
    
    const previousPeriod = await this.calculateProfitLoss(prevFilters);
    
    // Calculate growth percentages
    const calculateGrowth = (current, previous) => {
      if (previous === 0) return current > 0 ? 100 : 0;
      return ((current - previous) / previous) * 100;
    };

    return {
      current_period: currentPeriod,
      previous_period: previousPeriod,
      growth_metrics: {
        revenue_growth: calculateGrowth(
          currentPeriod.period_summary.total_revenue,
          previousPeriod.period_summary.total_revenue
        ),
        profit_growth: calculateGrowth(
          currentPeriod.period_summary.gross_profit,
          previousPeriod.period_summary.gross_profit
        ),
        expense_growth: calculateGrowth(
          currentPeriod.period_summary.total_expenses,
          previousPeriod.period_summary.total_expenses
        )
      }
    };
  }

  /**
   * Get cash flow analysis
   * @param {Object} filters - Date range, branch_id, etc.
   * @returns {Object} Cash flow breakdown
   */
  async getCashFlow(filters = {}) {
    const { start_date, end_date, branch_id } = filters;
    
    // Cash inflows (actual payments received)
    const inflows = await this.calculateRevenue(filters);
    
    // Cash outflows (expenses and payroll)
    const [expenses, payroll] = await Promise.all([
      this.calculateExpenses(filters),
      this.calculatePayrollCosts(filters)
    ]);

    const total_inflows = inflows.total_paid;
    const total_outflows = expenses.summary.total_amount + payroll.total_net_pay; // Use net pay for actual cash out
    const net_cash_flow = total_inflows - total_outflows;

    return {
      cash_inflows: {
        total: total_inflows,
        from_invoices: inflows.total_paid,
        pending_receivables: inflows.outstanding_amount
      },
      cash_outflows: {
        total: total_outflows,
        expenses: expenses.summary.total_amount,
        payroll: payroll.total_net_pay
      },
      net_cash_flow: net_cash_flow,
      cash_flow_ratio: total_outflows > 0 ? total_inflows / total_outflows : 0
    };
  }
}

module.exports = Finance;
