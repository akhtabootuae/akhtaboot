const { ObjectId, Double } = require('mongodb');

/**
 * Expense Model
 * Provides structure and methods for Expense data
 */
class Expense {
  /**
   * Get MongoDB schema validation for expenses collection
   * @returns {Object} MongoDB schema validation object
   */
  static getSchema() {
    return {
      validator: {
        $jsonSchema: {
          bsonType: "object",
          required: [
            "expense_number",
            "title",
            "amount",
            "expense_type",
            "date",
            "created_by",
            "branch_id",
            "status",
            "invoice_image",
            "created_at",
            "updated_at"
          ],
          properties: {
            expense_number: {
              bsonType: "string",
              pattern: "^EXP-[0-9]{7}$",
              description: "must be a string in format EXP-XXXXXXX where X is a digit and is required"
            },
            title: {
              bsonType: "string",
              minLength: 1,
              maxLength: 200,
              description: "must be a string and is required"
            },
            description: {
              bsonType: "string",
              description: "detailed description of the expense"
            },
            amount: {
              bsonType: "double",
              minimum: 0,
              description: "must be a positive number and is required"
            },
            expense_type: {
              bsonType: "string",
              enum: [
                "office_supplies",
                "equipment",
                "utilities",
                "rent",
                "maintenance",
                "fuel",
                "travel",
                "meals",
                "marketing",
                "insurance",
                "professional_services",
                "software_licenses",
                "telecommunications",
                "training",
                "repairs",
                "inventory",
                "external_service",
                "overtime_compensation",
                "miscellaneous"
              ],
              description: "must be one of the predefined expense types"
            },
            date: {
              bsonType: "date",
              description: "date when the expense occurred and is required"
            },
            created_by: {
              bsonType: "objectId",
              description: "must be an objectId reference to the user who created the expense and is required"
            },
            branch_id: {
              bsonType: "objectId",
              description: "must be an objectId reference to a branch and is required"
            },
            vendor: {
              bsonType: "string",
              description: "name of the vendor or supplier"
            },
            invoice_number: {
              bsonType: "string",
              description: "vendor's invoice number if applicable"
            },
            receipt_images: {
              bsonType: "array",
              description: "array of receipt/invoice image documents",
              items: {
                bsonType: "object",
                required: ["url", "upload_date"],
                properties: {
                  url: {
                    bsonType: "string",
                    description: "URL to the image file"
                  },
                  title: {
                    bsonType: "string",
                    description: "title/name of the image"
                  },
                  description: {
                    bsonType: "string",
                    description: "description of the image"
                  },
                  upload_date: {
                    bsonType: "date",
                    description: "date when image was uploaded"
                  }
                }
              }
            },
            invoice_image: {
              bsonType: "object",
              description: "main invoice image document (required for expense creation)",
              required: ["s3Key", "url", "filename", "uploadedAt"],
              properties: {
                s3Key: {
                  bsonType: "string",
                  description: "S3 key for the invoice image file"
                },
                url: {
                  bsonType: "string",
                  description: "URL to the invoice image file"
                },
                filename: {
                  bsonType: "string",
                  description: "original filename of the invoice image"
                },
                mimetype: {
                  bsonType: "string",
                  description: "MIME type of the invoice image"
                },
                size: {
                  bsonType: "int",
                  description: "file size in bytes"
                },
                uploadedAt: {
                  bsonType: "date",
                  description: "date when invoice image was uploaded"
                }
              }
            },
            approval_status: {
              bsonType: "string",
              enum: ["pending", "approved", "rejected"],
              description: "approval status of the expense"
            },
            approved_by: {
              bsonType: "objectId",
              description: "user who approved/rejected the expense"
            },
            approval_date: {
              bsonType: "date",
              description: "date when expense was approved/rejected"
            },
            approval_notes: {
              bsonType: "string",
              description: "notes from the approver"
            },
            status: {
              bsonType: "string",
              enum: ["draft", "submitted", "approved", "rejected", "paid"],
              description: "current status of the expense"
            },
            payment_method: {
              bsonType: "string",
              enum: ["cash", "card", "bank_transfer", "check", "petty_cash", "digital_wallet", "other"],
              description: "method used to pay for the expense"
            },
            payment_reference: {
              bsonType: "string",
              description: "payment reference number or transaction ID"
            },
            tags: {
              bsonType: "array",
              description: "array of tags for categorization",
              items: {
                bsonType: "string"
              }
            },
            project_id: {
              bsonType: "objectId",
              description: "reference to project if expense is project-related"
            },
            work_order_id: {
              bsonType: "objectId",
              description: "reference to work order if expense is work order-related"
            },
            related_invoice_id: {
              bsonType: "objectId",
              description: "reference to invoice if expense is invoice-related (e.g., external service cost)"
            },
            notes: {
              bsonType: "string",
              description: "additional notes about the expense"
            },
            created_at: {
              bsonType: "date",
              description: "When the expense record was created"
            },
            updated_at: {
              bsonType: "date",
              description: "When the expense record was last updated"
            }
          }
        }
      }
    };
  }

  /**
   * Generate a unique expense number in the format EXP-XXXXXXX
   * @param {Object} db MongoDB database connection
   * @returns {string} Unique expense number
   */
  static async generateExpenseNumber(db) {
    const count = await db.collection('expenses').countDocuments();
    const expenseNumber = `EXP-${String(count + 1).padStart(7, '0')}`;
    
    // Check if this number already exists (unlikely but safe)
    const existing = await db.collection('expenses').findOne({ expense_number: expenseNumber });
    if (existing) {
      // If it exists, get the current max and increment
      const maxExpense = await db.collection('expenses')
        .findOne({}, { sort: { expense_number: -1 } });
      
      if (maxExpense) {
        const maxNumber = parseInt(maxExpense.expense_number.replace('EXP-', ''));
        return `EXP-${String(maxNumber + 1).padStart(7, '0')}`;
      }
    }
    
    return expenseNumber;
  }

  /**
   * Create a new expense
   * @param {Object} db MongoDB database connection
   * @param {Object} expenseData Expense data to create
   * @returns {Object} Created expense
   */
  static async create(db, expenseData) {
    const timestamp = new Date();
    
    // Generate expense number if not provided
    if (!expenseData.expense_number) {
      expenseData.expense_number = await Expense.generateExpenseNumber(db);
    }

    // Set default values
    if (!expenseData.status) {
      expenseData.status = 'approved'; // Default to approved status
    }

    if (!expenseData.approval_status) {
      expenseData.approval_status = 'approved'; // Default to approved
      
      // Set approval metadata when auto-approving
      if (!expenseData.approved_by && expenseData.created_by) {
        expenseData.approved_by = expenseData.created_by; // Auto-approve by creator
      }
      
      if (!expenseData.approval_date) {
        expenseData.approval_date = timestamp; // Set approval date to creation time
      }
    }

    // Ensure receipt_images array exists
    if (!expenseData.receipt_images) {
      expenseData.receipt_images = [];
    }

    // Ensure tags array exists and handle string conversion
    if (!expenseData.tags) {
      expenseData.tags = [];
    } else if (typeof expenseData.tags === 'string') {
      try {
        // Parse JSON string to array
        expenseData.tags = JSON.parse(expenseData.tags);
        // Ensure it's actually an array
        if (!Array.isArray(expenseData.tags)) {
          expenseData.tags = [];
        }
      } catch (error) {
        console.warn('Failed to parse tags string, setting to empty array:', error);
        expenseData.tags = [];
      }
    }

    // Convert string IDs to ObjectIds
    if (typeof expenseData.created_by === 'string') {
      expenseData.created_by = new ObjectId(expenseData.created_by);
    }

    if (typeof expenseData.branch_id === 'string') {
      expenseData.branch_id = new ObjectId(expenseData.branch_id);
    }

    if (expenseData.approved_by && typeof expenseData.approved_by === 'string') {
      expenseData.approved_by = new ObjectId(expenseData.approved_by);
    }

    if (expenseData.project_id && typeof expenseData.project_id === 'string') {
      expenseData.project_id = new ObjectId(expenseData.project_id);
    }

    if (expenseData.work_order_id && typeof expenseData.work_order_id === 'string') {
      expenseData.work_order_id = new ObjectId(expenseData.work_order_id);
    }

    // Set default branch if not provided
    if (!expenseData.branch_id) {
      // Get the default Sharjah branch
      const defaultBranch = await db.collection('branches').findOne({ branch_code: "SJH" });
      if (defaultBranch) {
        expenseData.branch_id = defaultBranch._id;
      } else {
        // Fallback to any available branch
        const anyBranch = await db.collection('branches').findOne({});
        if (anyBranch) {
          expenseData.branch_id = anyBranch._id;
        }
      }
    }

    // Convert date strings to Date objects
    if (expenseData.date && typeof expenseData.date === 'string') {
      expenseData.date = new Date(expenseData.date);
    }

    if (expenseData.approval_date) {
      if (typeof expenseData.approval_date === 'string') {
        expenseData.approval_date = new Date(expenseData.approval_date);
      }
      // If approval_date is already a Date object (from our auto-approval above), leave it as is
    }

    // Ensure amount is a Double type as required by schema
    if (expenseData.amount !== undefined) {
      expenseData.amount = new Double(expenseData.amount);
    }

    const newExpense = {
      ...expenseData,
      created_at: timestamp,
      updated_at: timestamp
    };

    try {
      const result = await db.collection('expenses').insertOne(newExpense);
      return { ...newExpense, _id: result.insertedId };
    } catch (error) {
      console.error('Expense creation error:', error);
      
      if (error.code === 121) {
        console.error('Validation error details:', JSON.stringify(error.errInfo?.details, null, 2));
      }
      
      throw error;
    }
  }

  /**
   * Get all expenses with optional filters
   * @param {Object} db MongoDB database connection
   * @param {Object} filters Filter options
   * @returns {Array} Array of expense documents
   */
  static async getAll(db, filters = {}) {
    const query = {};
    
    if (filters.created_by) {
      query.created_by = new ObjectId(filters.created_by);
    }
    
    if (filters.branch_id) {
      query.branch_id = new ObjectId(filters.branch_id);
    }
    
    if (filters.expense_type) {
      query.expense_type = filters.expense_type;
    }
    
    if (filters.status) {
      query.status = filters.status;
    }
    
    if (filters.approval_status) {
      query.approval_status = filters.approval_status;
    }
    
    if (filters.date_from || filters.date_to) {
      query.date = {};
      
      if (filters.date_from) {
        query.date.$gte = new Date(filters.date_from);
      }
      
      if (filters.date_to) {
        query.date.$lte = new Date(filters.date_to);
      }
    }

    if (filters.work_order_id) {
      query.work_order_id = new ObjectId(filters.work_order_id);
    }

    if (filters.project_id) {
      query.project_id = new ObjectId(filters.project_id);
    }

    if (filters.vendor) {
      query.vendor = { $regex: filters.vendor, $options: 'i' };
    }

    if (filters.tags && filters.tags.length > 0) {
      query.tags = { $in: filters.tags };
    }

    // Add text search if search term provided
    if (filters.search) {
      query.$or = [
        { title: { $regex: filters.search, $options: 'i' } },
        { description: { $regex: filters.search, $options: 'i' } },
        { vendor: { $regex: filters.search, $options: 'i' } },
        { notes: { $regex: filters.search, $options: 'i' } }
      ];
    }

    return db.collection('expenses').find(query).sort({ created_at: -1 }).toArray();
  }

  /**
   * Get expense by ID
   * @param {Object} db MongoDB database connection
   * @param {string} id Expense ID
   * @returns {Object} Expense document
   */
  static async getById(db, id) {
    return db.collection('expenses').findOne({ _id: new ObjectId(id) });
  }

  /**
   * Get expense by expense number
   * @param {Object} db MongoDB database connection
   * @param {string} expenseNumber Expense number
   * @returns {Object} Expense document
   */
  static async getByExpenseNumber(db, expenseNumber) {
    return db.collection('expenses').findOne({ expense_number: expenseNumber });
  }

  /**
   * Update expense by ID
   * @param {Object} db MongoDB database connection
   * @param {string} id Expense ID
   * @param {Object} updateData Update data
   * @returns {Object} Update result
   */
  static async updateById(db, id, updateData) {
    const timestamp = new Date();
    
    // Don't allow direct updates to receipt_images array
    const { receipt_images, ...updates } = updateData;
    
    // Convert string IDs to ObjectIds if provided
    if (updates.branch_id && typeof updates.branch_id === 'string') {
      updates.branch_id = new ObjectId(updates.branch_id);
    }
    
    if (updates.approved_by && typeof updates.approved_by === 'string') {
      updates.approved_by = new ObjectId(updates.approved_by);
    }

    if (updates.project_id && typeof updates.project_id === 'string') {
      updates.project_id = new ObjectId(updates.project_id);
    }

    if (updates.work_order_id && typeof updates.work_order_id === 'string') {
      updates.work_order_id = new ObjectId(updates.work_order_id);
    }

    // Convert date strings to Date objects
    if (updates.date && typeof updates.date === 'string') {
      updates.date = new Date(updates.date);
    }

    if (updates.approval_date && typeof updates.approval_date === 'string') {
      updates.approval_date = new Date(updates.approval_date);
    }

    // Ensure amount is a Double type if provided
    if (updates.amount !== undefined) {
      updates.amount = new Double(updates.amount);
    }

    // Handle tags array conversion from string if needed
    if (updates.tags !== undefined) {
      if (typeof updates.tags === 'string') {
        try {
          // Parse JSON string to array
          updates.tags = JSON.parse(updates.tags);
          // Ensure it's actually an array
          if (!Array.isArray(updates.tags)) {
            updates.tags = [];
          }
        } catch (error) {
          console.warn('Failed to parse tags string in update, setting to empty array:', error);
          updates.tags = [];
        }
      } else if (!Array.isArray(updates.tags)) {
        updates.tags = [];
      }
    }

    const result = await db.collection('expenses').updateOne(
      { _id: new ObjectId(id) },
      { 
        $set: {
          ...updates,
          updated_at: timestamp
        } 
      }
    );
    
    return result;
  }

  /**
   * Delete expense by ID
   * @param {Object} db MongoDB database connection
   * @param {string} id Expense ID
   * @returns {Object} Delete result
   */
  static async deleteById(db, id) {
    return db.collection('expenses').deleteOne({ _id: new ObjectId(id) });
  }

  /**
   * Add a receipt image to an expense
   * @param {Object} db MongoDB database connection
   * @param {string} expenseId Expense ID
   * @param {Object} imageData Image data
   * @returns {Object} Update result
   */
  static async addReceiptImage(db, expenseId, imageData) {
    const timestamp = new Date();
    
    const imageRecord = {
      url: imageData.url,
      title: imageData.title || 'Receipt Image',
      description: imageData.description || '',
      upload_date: timestamp
    };
    
    const result = await db.collection('expenses').updateOne(
      { _id: new ObjectId(expenseId) },
      {
        $push: { receipt_images: imageRecord },
        $set: { updated_at: timestamp }
      }
    );
    
    return result;
  }

  /**
   * Remove a receipt image from an expense
   * @param {Object} db MongoDB database connection
   * @param {string} expenseId Expense ID
   * @param {string} imageUrl Image URL to remove
   * @returns {Object} Update result
   */
  static async removeReceiptImage(db, expenseId, imageUrl) {
    const timestamp = new Date();
    
    const result = await db.collection('expenses').updateOne(
      { _id: new ObjectId(expenseId) },
      {
        $pull: { receipt_images: { url: imageUrl } },
        $set: { updated_at: timestamp }
      }
    );
    
    return result;
  }

  /**
   * Approve or reject an expense
   * @param {Object} db MongoDB database connection
   * @param {string} expenseId Expense ID
   * @param {Object} approvalData Approval data
   * @returns {Object} Update result
   */
  static async updateApprovalStatus(db, expenseId, approvalData) {
    const timestamp = new Date();
    
    const updateData = {
      approval_status: approvalData.approval_status,
      approved_by: new ObjectId(approvalData.approved_by),
      approval_date: timestamp,
      approval_notes: approvalData.approval_notes || '',
      updated_at: timestamp
    };

    // If approved, also update status to approved
    if (approvalData.approval_status === 'approved') {
      updateData.status = 'approved';
    } else if (approvalData.approval_status === 'rejected') {
      updateData.status = 'rejected';
    }

    const result = await db.collection('expenses').updateOne(
      { _id: new ObjectId(expenseId) },
      { $set: updateData }
    );
    
    return result;
  }

  /**
   * Get expenses by creator
   * @param {Object} db MongoDB database connection
   * @param {string} userId User ID
   * @returns {Array} Array of expense documents
   */
  static async getByCreator(db, userId) {
    return db.collection('expenses')
      .find({ created_by: new ObjectId(userId) })
      .sort({ created_at: -1 })
      .toArray();
  }

  /**
   * Get expenses by branch
   * @param {Object} db MongoDB database connection
   * @param {string} branchId Branch ID
   * @returns {Array} Array of expense documents
   */
  static async getByBranch(db, branchId) {
    return db.collection('expenses')
      .find({ branch_id: new ObjectId(branchId) })
      .sort({ created_at: -1 })
      .toArray();
  }

  /**
   * Get expense statistics
   * @param {Object} db MongoDB database connection
   * @param {Object} filters Filter options
   * @returns {Object} Statistics object
   */
  static async getStatistics(db, filters = {}) {
    const matchStage = {};
    
    if (filters.branch_id) {
      matchStage.branch_id = new ObjectId(filters.branch_id);
    }
    
    if (filters.created_by) {
      matchStage.created_by = new ObjectId(filters.created_by);
    }
    
    if (filters.date_from || filters.date_to) {
      matchStage.date = {};
      
      if (filters.date_from) {
        matchStage.date.$gte = new Date(filters.date_from);
      }
      
      if (filters.date_to) {
        matchStage.date.$lte = new Date(filters.date_to);
      }
    }

    const pipeline = [
      { $match: matchStage },
      {
        $group: {
          _id: null,
          totalExpenses: { $sum: 1 },
          totalAmount: { $sum: '$amount' },
          averageAmount: { $avg: '$amount' },
          pendingApproval: {
            $sum: { $cond: [{ $eq: ['$approval_status', 'pending'] }, 1, 0] }
          },
          approved: {
            $sum: { $cond: [{ $eq: ['$approval_status', 'approved'] }, 1, 0] }
          },
          rejected: {
            $sum: { $cond: [{ $eq: ['$approval_status', 'rejected'] }, 1, 0] }
          },
          approvedAmount: {
            $sum: { $cond: [{ $eq: ['$approval_status', 'approved'] }, '$amount', 0] }
          }
        }
      }
    ];

    const result = await db.collection('expenses').aggregate(pipeline).toArray();
    
    if (result.length === 0) {
      return {
        totalExpenses: 0,
        totalAmount: 0,
        averageAmount: 0,
        pendingApproval: 0,
        approved: 0,
        rejected: 0,
        approvedAmount: 0
      };
    }

    return result[0];
  }

  /**
   * Get expenses by type aggregation
   * @param {Object} db MongoDB database connection
   * @param {Object} filters Filter options
   * @returns {Array} Array of expense type aggregations
   */
  static async getExpensesByType(db, filters = {}) {
    const matchStage = {};
    
    if (filters.branch_id) {
      matchStage.branch_id = new ObjectId(filters.branch_id);
    }
    
    if (filters.date_from || filters.date_to) {
      matchStage.date = {};
      
      if (filters.date_from) {
        matchStage.date.$gte = new Date(filters.date_from);
      }
      
      if (filters.date_to) {
        matchStage.date.$lte = new Date(filters.date_to);
      }
    }

    const pipeline = [
      { $match: matchStage },
      {
        $group: {
          _id: '$expense_type',
          count: { $sum: 1 },
          totalAmount: { $sum: '$amount' },
          averageAmount: { $avg: '$amount' }
        }
      },
      { $sort: { totalAmount: -1 } }
    ];

    return db.collection('expenses').aggregate(pipeline).toArray();
  }
}

module.exports = Expense;
