const bcrypt = require('bcryptjs');
const { ObjectId, Int32 } = require('mongodb');

/**
 * User Model
 * Provides structure and methods for User data
 */
class User {
  /**
   * Get MongoDB schema validation for users collection
   * @returns {Object} MongoDB schema validation object
   */
  static getSchema() {
    return {
      validator: {
        $jsonSchema: {
          bsonType: "object",
          required: [
            "first_name", "last_name", "email",
            "password_hash", "role_id", "role_name",
            "created_at", "updated_at"
          ],
          properties: {
            first_name:    { bsonType: "string" },
            last_name:     { bsonType: "string" },
            email:         { bsonType: "string", description: "must be a string and is required" },
            phone:         { bsonType: "string" },
            password_hash: { bsonType: "string" },
            is_active:     { bsonType: "bool",   description: "active flag" },
            staff_code:    { bsonType: "string" },
            speciality:    { 
              bsonType: "string",
              enum: ["PDR", "Fix/Remove", "Paint", "Body Work", "Mechanical", "Electrical", "General", "Denter", "Polish", "PDR & Paint Supervision", "System Administration", "Supervision", "Management", "Other"],
              description: "User specialty or role-specific designation"
            },

            branch: {
              bsonType: "object",
              required: ["branch_id", "branch_name"],
              properties: {
                branch_id:   { bsonType: "objectId" },
                branch_name: { bsonType: "string" },
                branch_code: { bsonType: "string" },
                location:    { bsonType: "string" }
              }
            },

            // now just a reference + denormalized fields:
            role_id:          { bsonType: "objectId" },
            role_name:        { bsonType: "string" },
            role_description: { bsonType: "string" },

            permissions: {
              bsonType: "array",
              items: {
                bsonType: "object",
                required: ["permission_id", "permission_name", "granted"],
                properties: {
                  permission_id:          { bsonType: "string" },
                  permission_name:        { bsonType: "string" },
                  permission_description: { bsonType: "string" },
                  category:               { bsonType: "string" },
                  granted:                { bsonType: "bool" }
                }
              }
            },

            permission_logs: {
              bsonType: "array",
              items: {
                bsonType: "object",
                required: [
                  "log_id", "target_type", "target_id",
                  "permission_id", "action", "created_at"
                ],
                properties: {
                  log_id:        { bsonType: "string" },
                  target_type:   { enum: ["user", "role"] },
                  target_id:     { bsonType: "objectId" },
                  permission_id: { bsonType: "string" },
                  action:        { enum: ["grant", "revoke"] },
                  created_at:    { bsonType: "date" },
                  details:       { bsonType: "string" }
                }
              }
            },

            manner_evaluations: {
              bsonType: "array",
              items: {
                bsonType: "object",
                required: [
                  "_id", "category", "rating", "notes", "created_at", "updated_at"
                ],
                properties: {
                  _id:           { bsonType: "objectId" },
                  category:      { bsonType: "string" },
                  rating:        { bsonType: "int", minimum: 1, maximum: 5 },
                  notes:         { bsonType: "string" },
                  work_order_id: { bsonType: "objectId" },
                  created_at:    { bsonType: "date" },
                  updated_at:    { bsonType: "date" }
                }
              }
            },

            manner_evaluation_logs: {
              bsonType: "array",
              items: {
                bsonType: "object",
                required: [
                  "log_id", "action", "category", "rating", "notes", "evaluator_id", "created_at"
                ],
                properties: {
                  log_id:         { bsonType: "objectId" },
                  action:         { enum: ["added", "updated", "deleted"] },
                  category:       { bsonType: "string" },
                  rating:         { bsonType: "int", minimum: 1, maximum: 5 },
                  work_order_id:  { bsonType: "objectId" },
                  evaluation_id:  { bsonType: "objectId" },
                  evaluator_id:   { bsonType: "objectId" },
                  notes:          { bsonType: "string" },
                  created_at:     { bsonType: "date" }
                }
              }
            },

            payroll_info: {
              bsonType: "object",
              properties: {
                payroll_eligible: { 
                  bsonType: "bool",
                  description: "Whether user is eligible for payroll processing"
                },
                employee_number: {
                  bsonType: "string",
                  description: "Unique employee identifier for payroll"
                },
                hire_date: {
                  bsonType: ["date", "null"],
                  description: "Employee hire date"
                },
                employment_type: {
                  bsonType: "string",
                  enum: ["full_time", "part_time", "contract", "temporary"],
                  description: "Type of employment"
                },
                monthly_salary: {
                  bsonType: ["number", "null"],
                  description: "Current monthly salary for the employee"
                },
                last_pay_date: {
                  bsonType: ["date", "null"],
                  description: "Date of last payroll payment"
                },
                last_rate_update: {
                  bsonType: ["date", "null"],
                  description: "Date of last rate change"
                },
                updated_by: {
                  bsonType: "string",
                  description: "User ID who last updated payroll info"
                }
              }
            },

            created_at: { bsonType: "date" },
            updated_at: { bsonType: "date" }
          }
        }
      }
    };
  }

  /**
   * Build a new user object with all required fields
   * @param {Object} userData User data 
   * @returns {Object} Properly formatted user object
   */
  static async buildUser(userData) {
    const {
      first_name, last_name, email, phone, password,
      is_active, staff_code, speciality, role, branch
    } = userData;

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const password_hash = await bcrypt.hash(password, salt);

    return {
      first_name,
      last_name,
      email,
      phone: phone || "",
      password_hash,
      is_active: is_active !== undefined ? is_active : true,
      staff_code: staff_code || "",
      speciality: speciality || "",

      // Branch subdocument with properly formatted fields from branches collection
      branch: {
        branch_id:   branch?._id || new ObjectId(), // Use _id from branch document
        branch_name: branch?.branch_name || "Main Branch",
        branch_code: branch?.branch_code || "",
        location:    branch?.location || ""
      },

      // Reference + denormalized role - using the exact role object from the database
      role_id:          role?._id || new ObjectId(),
      role_name:        role?.role_name || "User",
      role_description: role?.description || "",

      permissions:              [],
      permission_logs:          [],
      manner_evaluations:       [],
      manner_evaluation_logs:   [],
      created_at:               new Date(),
      updated_at:               new Date()
    };
  }

  /**
   * Find user by ID
   */
  static async findById(db, id) {
    return db.collection('users').findOne({ _id: new ObjectId(id) });
  }

  /**
   * Find user by email
   */
  static async findByEmail(db, email) {
    return db.collection('users').findOne({ email });
  }

  /**
   * Generate a permission log entry
   */
  static createPermissionLog(user, permission, granted, admin) {
    return {
      log_id:        Date.now() + Math.floor(Math.random() * 1000),
      target_type:   "user",
      target_id:     user._id,
      permission_id: permission.permission_id,
      action:        granted ? "grant" : "revoke",
      created_at:    new Date(),
      details:       `Permission '${permission.permission_name}' `
                   + `${granted ? 'granted' : 'revoked'} `
                   + `by ${admin.first_name} ${admin.last_name}`
    };
  }

  /**
   * Sanitize user object for public response
   */
  static sanitize(user) {
    const { password_hash, permission_logs, ...safeUser } = user;
    return safeUser;
  }

  /**
   * Check if user has a specific permission
   */
  static hasPermission(user, permissionName) {
    // Admin shortcut by name
    if (user.role_name === 'Admin') {
      return true;
    }

    return user.permissions?.some(p =>
      p.permission_name === permissionName && p.granted
    ) || false;
  }

  /**
   * Check if user has all specified permissions
   */
  static hasAllPermissions(user, names) {
    if (user.role_name === 'Admin') {
      return true;
    }
    return names.every(n => this.hasPermission(user, n));
  }

  /**
   * Check if user has any of the specified permissions
   */
  static hasAnyPermission(user, names) {
    if (user.role_name === 'Admin') {
      return true;
    }
    return names.some(n => this.hasPermission(user, n));
  }

  /**
   * Add a new manner evaluation to a user
   */
  static async addMannerEvaluation(db, userId, evaluationData, evaluatorId) {
    const { category, rating, notes, work_order_id } = evaluationData;
    const now = new Date();
    
    // Create the evaluation object
    const evaluation = {
      _id: new ObjectId(),
      category,
      rating: new Int32(parseInt(rating)),
      notes: notes,
      created_at: now,
      updated_at: now
    };
    
    // Only include work_order_id if it's provided and not null
    if (work_order_id && work_order_id !== null) {
      evaluation.work_order_id = new ObjectId(work_order_id);
    }
    
    // Create the log entry
    const logEntry = {
      log_id: new ObjectId(),
      action: "added",
      category,
      rating: new Int32(parseInt(rating)),
      evaluation_id: evaluation._id,
      evaluator_id: new ObjectId(evaluatorId),
      notes: notes,
      created_at: now
    };
    
    // Only include work_order_id if it's provided and not null
    if (work_order_id && work_order_id !== null) {
      logEntry.work_order_id = new ObjectId(work_order_id);
    }
    
    // Update the user document
    const result = await db.collection('users').updateOne(
      { _id: new ObjectId(userId) },
      {
        $push: {
          manner_evaluations: evaluation,
          manner_evaluation_logs: logEntry
        },
        $set: { updated_at: now }
      }
    );
    
    return { success: result.modifiedCount > 0, evaluationId: evaluation._id };
  }

  /**
   * Update an existing manner evaluation
   */
  static async updateMannerEvaluation(db, userId, evaluationId, updateData, evaluatorId) {
    const { category, rating, notes, work_order_id } = updateData;
    const now = new Date();
    
    // Create the log entry for the update
    const logEntry = {
      log_id: new ObjectId(),
      action: "updated",
      category,
      rating: new Int32(parseInt(rating)),
      evaluation_id: new ObjectId(evaluationId),
      evaluator_id: new ObjectId(evaluatorId),
      notes: notes,
      created_at: now
    };
    
    // Only include work_order_id if it's provided and not null
    if (work_order_id && work_order_id !== null) {
      logEntry.work_order_id = new ObjectId(work_order_id);
    }
    
    // Prepare the update fields
    const updateFields = {
      'manner_evaluations.$.category': category,
      'manner_evaluations.$.rating': new Int32(parseInt(rating)),
      'manner_evaluations.$.notes': notes,
      'manner_evaluations.$.updated_at': now,
      updated_at: now
    };
    
    // Only include work_order_id if it's provided and not null
    if (work_order_id && work_order_id !== null) {
      updateFields['manner_evaluations.$.work_order_id'] = new ObjectId(work_order_id);
    }
    // Note: If work_order_id is not provided, we don't modify it (leave it as is)
    
    // Update the evaluation and add log entry
    const result = await db.collection('users').updateOne(
      { 
        _id: new ObjectId(userId),
        'manner_evaluations._id': new ObjectId(evaluationId)
      },
      {
        $set: updateFields,
        $push: {
          manner_evaluation_logs: logEntry
        }
      }
    );
    
    return { success: result.modifiedCount > 0 };
  }

  /**
   * Delete a manner evaluation
   */
  static async deleteMannerEvaluation(db, userId, evaluationId, evaluatorId) {
    const now = new Date();
    
    // First get the evaluation to log what was deleted
    const user = await db.collection('users').findOne(
      { _id: new ObjectId(userId) },
      { projection: { manner_evaluations: 1 } }
    );
    
    const evaluation = user?.manner_evaluations?.find(e => e._id.toString() === evaluationId);
    if (!evaluation) {
      return { success: false, error: 'Evaluation not found' };
    }
    
    // Create the log entry for the deletion
    const logEntry = {
      log_id: new ObjectId(),
      action: "deleted",
      category: evaluation.category,
      rating: evaluation.rating,
      evaluation_id: new ObjectId(evaluationId),
      evaluator_id: new ObjectId(evaluatorId),
      notes: `Deleted evaluation: ${evaluation.notes || 'No notes'}`,
      created_at: now
    };
    
    // Only include work_order_id if it existed in the original evaluation
    if (evaluation.work_order_id) {
      logEntry.work_order_id = evaluation.work_order_id;
    }
    
    // Remove the evaluation and add log entry
    const result = await db.collection('users').updateOne(
      { _id: new ObjectId(userId) },
      {
        $pull: {
          manner_evaluations: { _id: new ObjectId(evaluationId) }
        },
        $push: {
          manner_evaluation_logs: logEntry
        },
        $set: { updated_at: now }
      }
    );
    
    return { success: result.modifiedCount > 0 };
  }
}

module.exports = User;