const { ObjectId } = require('mongodb');
const moment = require('moment');

class PayStub {
  /**
   * Get collection validation schema for MongoDB
   */
  static getSchema() {
    return {
      validator: {
        $jsonSchema: {
          bsonType: "object",
          required: ["employee_id", "pay_period_id", "payroll_calculation_id", "stub_number", "issue_date"],
          properties: {
            employee_id: {
              bsonType: "objectId",
              description: "Reference to employee in users collection"
            },
            pay_period_id: {
              bsonType: "objectId",
              description: "Reference to pay period"
            },
            payroll_calculation_id: {
              bsonType: "objectId",
              description: "Reference to payroll calculation"
            },
            stub_number: {
              bsonType: "string",
              maxLength: 50,
              description: "Unique pay stub number"
            },
            issue_date: {
              bsonType: "date",
              description: "Date the pay stub was issued"
            },
            pay_date: {
              bsonType: "date",
              description: "Date of payment"
            },
            employee_info: {
              bsonType: "object",
              required: ["employee_id", "full_name", "email"],
              properties: {
                employee_id: {
                  bsonType: "string",
                  description: "Employee identifier"
                },
                full_name: {
                  bsonType: "string",
                  description: "Employee full name"
                },
                email: {
                  bsonType: "string",
                  description: "Employee email"
                },
                department: {
                  bsonType: "string",
                  description: "Employee department"
                },
                position: {
                  bsonType: "string",
                  description: "Employee position"
                },
                hire_date: {
                  bsonType: "date",
                  description: "Employee hire date"
                }
              },
              description: "Employee information snapshot"
            },
            pay_period_info: {
              bsonType: "object",
              required: ["start_date", "end_date", "frequency"],
              properties: {
                start_date: {
                  bsonType: "date",
                  description: "Pay period start date"
                },
                end_date: {
                  bsonType: "date",
                  description: "Pay period end date"
                },
                frequency: {
                  bsonType: "string",
                  enum: ["weekly", "bi-weekly", "monthly", "semi-monthly"],
                  description: "Pay frequency"
                },
                period_name: {
                  bsonType: "string",
                  description: "Pay period name"
                }
              },
              description: "Pay period information"
            },
            earnings: {
              bsonType: "object",
              required: ["gross_pay", "net_pay"],
              properties: {
                regular_hours: {
                  bsonType: "number",
                  minimum: 0,
                  description: "Regular hours worked"
                },
                overtime_hours: {
                  bsonType: "number",
                  minimum: 0,
                  description: "Overtime hours worked"
                },
                total_hours: {
                  bsonType: "number",
                  minimum: 0,
                  description: "Total hours worked"
                },
                daily_rate: {
                  bsonType: "number",
                  minimum: 0,
                  description: "Daily rate"
                },
                hourly_rate: {
                  bsonType: "number",
                  minimum: 0,
                  description: "Hourly rate"
                },
                regular_pay: {
                  bsonType: "number",
                  minimum: 0,
                  description: "Regular pay amount"
                },
                overtime_pay: {
                  bsonType: "number",
                  minimum: 0,
                  description: "Overtime pay amount"
                },
                gross_pay: {
                  bsonType: "number",
                  minimum: 0,
                  description: "Total gross pay"
                },
                net_pay: {
                  bsonType: "number",
                  minimum: 0,
                  description: "Net pay after deductions"
                }
              },
              description: "Earnings breakdown"
            },
            deductions: {
              bsonType: "array",
              items: {
                bsonType: "object",
                required: ["name", "amount"],
                properties: {
                  name: {
                    bsonType: "string",
                    description: "Deduction name"
                  },
                  amount: {
                    bsonType: "number",
                    minimum: 0,
                    description: "Deduction amount"
                  },
                  type: {
                    bsonType: "string",
                    enum: ["tax", "insurance", "retirement", "loan", "advance", "other"],
                    description: "Deduction category"
                  },
                  calculation_method: {
                    bsonType: "string",
                    enum: ["fixed", "percentage", "formula"],
                    description: "How deduction was calculated"
                  },
                  ytd_amount: {
                    bsonType: "number",
                    minimum: 0,
                    description: "Year-to-date deduction amount"
                  }
                }
              },
              description: "List of deductions"
            },
            taxes: {
              bsonType: "object",
              properties: {
                federal_tax: {
                  bsonType: "number",
                  minimum: 0,
                  description: "Federal tax amount"
                },
                state_tax: {
                  bsonType: "number",
                  minimum: 0,
                  description: "State tax amount"
                },
                social_security: {
                  bsonType: "number",
                  minimum: 0,
                  description: "Social security tax"
                },
                medicare: {
                  bsonType: "number",
                  minimum: 0,
                  description: "Medicare tax"
                },
                other_taxes: {
                  bsonType: "number",
                  minimum: 0,
                  description: "Other tax amounts"
                },
                total_taxes: {
                  bsonType: "number",
                  minimum: 0,
                  description: "Total tax amount"
                }
              },
              description: "Tax breakdown"
            },
            ytd_totals: {
              bsonType: "object",
              properties: {
                ytd_gross_pay: {
                  bsonType: "number",
                  minimum: 0,
                  description: "Year-to-date gross pay"
                },
                ytd_deductions: {
                  bsonType: "number",
                  minimum: 0,
                  description: "Year-to-date total deductions"
                },
                ytd_taxes: {
                  bsonType: "number",
                  minimum: 0,
                  description: "Year-to-date total taxes"
                },
                ytd_net_pay: {
                  bsonType: "number",
                  minimum: 0,
                  description: "Year-to-date net pay"
                },
                ytd_hours: {
                  bsonType: "number",
                  minimum: 0,
                  description: "Year-to-date hours worked"
                }
              },
              description: "Year-to-date totals"
            },
            company_info: {
              bsonType: "object",
              properties: {
                name: {
                  bsonType: "string",
                  description: "Company name"
                },
                address: {
                  bsonType: "string",
                  description: "Company address"
                },
                phone: {
                  bsonType: "string",
                  description: "Company phone"
                },
                tax_id: {
                  bsonType: "string",
                  description: "Company tax ID"
                }
              },
              description: "Company information"
            },
            pdf_path: {
              bsonType: "string",
              description: "Path to generated PDF file"
            },
            status: {
              bsonType: "string",
              enum: ["draft", "issued", "delivered", "viewed"],
              description: "Pay stub status"
            },
            delivery_method: {
              bsonType: "string",
              enum: ["email", "print", "portal", "other"],
              description: "How pay stub was delivered"
            },
            delivered_at: {
              bsonType: "date",
              description: "When pay stub was delivered"
            },
            viewed_at: {
              bsonType: "date",
              description: "When employee viewed pay stub"
            },
            notes: {
              bsonType: "string",
              maxLength: 500,
              description: "Additional notes"
            },
            created_at: {
              bsonType: "date",
              description: "Creation timestamp"
            },
            updated_at: {
              bsonType: "date",
              description: "Last update timestamp"
            },
            created_by: {
              bsonType: "objectId",
              description: "User who created the pay stub"
            },
            updated_by: {
              bsonType: "objectId",
              description: "User who last updated the pay stub"
            }
          }
        }
      }
    };
  }

  /**
   * Generate unique pay stub number
   */
  static generateStubNumber(employeeId, payPeriodId, issueDate = new Date()) {
    const year = issueDate.getFullYear();
    const month = String(issueDate.getMonth() + 1).padStart(2, '0');
    const empId = employeeId.toString().slice(-4);
    const periodId = payPeriodId.toString().slice(-4);
    
    return `PS-${year}${month}-${empId}-${periodId}`;
  }

  /**
   * Create pay stub from payroll calculation
   */
  static async create(db, payrollCalculationId, createdBy, options = {}) {
    // Get payroll calculation with related data
    const calculation = await db.collection('payroll_calculations').aggregate([
      { $match: { _id: new ObjectId(payrollCalculationId) } },
      {
        $lookup: {
          from: 'users',
          localField: 'employee_id',
          foreignField: '_id',
          as: 'employee'
        }
      },
      {
        $lookup: {
          from: 'pay_periods',
          localField: 'pay_period_id',
          foreignField: '_id',
          as: 'pay_period'
        }
      },
      { $unwind: '$employee' },
      { $unwind: '$pay_period' }
    ]).toArray();

    if (calculation.length === 0) {
      throw new Error('Payroll calculation not found');
    }

    const calc = calculation[0];
    const employee = calc.employee;
    const payPeriod = calc.pay_period;

    // Check if pay stub already exists
    const existing = await db.collection('pay_stubs').findOne({
      payroll_calculation_id: new ObjectId(payrollCalculationId)
    });

    if (existing) {
      throw new Error('Pay stub already exists for this calculation');
    }

    // Generate stub number
    const stubNumber = this.generateStubNumber(
      calc.employee_id, 
      calc.pay_period_id, 
      options.issue_date || new Date()
    );

    // Get YTD totals for employee
    const ytdTotals = await this.calculateYTDTotals(db, calc.employee_id, payPeriod.end_date);

    // Prepare pay stub data
    const payStub = {
      employee_id: calc.employee_id,
      pay_period_id: calc.pay_period_id,
      payroll_calculation_id: new ObjectId(payrollCalculationId),
      stub_number: stubNumber,
      issue_date: options.issue_date ? new Date(options.issue_date) : new Date(),
      pay_date: payPeriod.pay_date,
      
      employee_info: {
        employee_id: employee.payroll_info?.employee_id || employee._id.toString(),
        full_name: `${employee.first_name} ${employee.last_name}`,
        email: employee.email,
        department: employee.department || 'General',
        position: employee.position || 'Employee',
        hire_date: employee.payroll_info?.hire_date || employee.created_at
      },
      
      pay_period_info: {
        start_date: payPeriod.start_date,
        end_date: payPeriod.end_date,
        frequency: payPeriod.frequency,
        period_name: payPeriod.period_name
      },
      
      earnings: {
        regular_hours: calc.regular_hours || 0,
        overtime_hours: calc.overtime_hours || 0,
        total_hours: calc.total_hours || 0,
        daily_rate: calc.daily_rate || 0,
        hourly_rate: calc.hourly_rate || 0,
        regular_pay: calc.regular_pay || 0,
        overtime_pay: calc.overtime_pay || 0,
        gross_pay: calc.gross_pay || 0,
        net_pay: calc.net_pay || 0
      },
      
      deductions: calc.deductions || [],
      
      taxes: calc.taxes || {
        federal_tax: 0,
        state_tax: 0,
        social_security: 0,
        medicare: 0,
        other_taxes: 0,
        total_taxes: 0
      },
      
      ytd_totals: ytdTotals,
      
      company_info: options.company_info || {
        name: 'Your Company Name',
        address: '123 Company St, City, State 12345',
        phone: '(555) 123-4567',
        tax_id: '12-3456789'
      },
      
      status: options.status || 'draft',
      delivery_method: options.delivery_method || 'email',
      notes: options.notes || '',
      created_at: new Date(),
      updated_at: new Date(),
      created_by: new ObjectId(createdBy)
    };

    const result = await db.collection('pay_stubs').insertOne(payStub);
    return { ...payStub, _id: result.insertedId };
  }

  /**
   * Calculate YTD totals for employee
   */
  static async calculateYTDTotals(db, employeeId, endDate) {
    const startOfYear = new Date(endDate.getFullYear(), 0, 1);
    
    const pipeline = [
      {
        $match: {
          employee_id: new ObjectId(employeeId),
          issue_date: {
            $gte: startOfYear,
            $lte: endDate
          },
          status: { $in: ['issued', 'delivered', 'viewed'] }
        }
      },
      {
        $group: {
          _id: null,
          ytd_gross_pay: { $sum: '$earnings.gross_pay' },
          ytd_deductions: { $sum: { $sum: '$deductions.amount' } },
          ytd_taxes: { $sum: '$taxes.total_taxes' },
          ytd_net_pay: { $sum: '$earnings.net_pay' },
          ytd_hours: { $sum: '$earnings.total_hours' }
        }
      }
    ];

    const result = await db.collection('pay_stubs').aggregate(pipeline).toArray();
    
    return result[0] ? {
      ytd_gross_pay: parseFloat((result[0].ytd_gross_pay || 0).toFixed(2)),
      ytd_deductions: parseFloat((result[0].ytd_deductions || 0).toFixed(2)),
      ytd_taxes: parseFloat((result[0].ytd_taxes || 0).toFixed(2)),
      ytd_net_pay: parseFloat((result[0].ytd_net_pay || 0).toFixed(2)),
      ytd_hours: parseFloat((result[0].ytd_hours || 0).toFixed(2))
    } : {
      ytd_gross_pay: 0,
      ytd_deductions: 0,
      ytd_taxes: 0,
      ytd_net_pay: 0,
      ytd_hours: 0
    };
  }

  /**
   * Find pay stub by ID
   */
  static async findById(db, payStubId) {
    return await db.collection('pay_stubs').findOne({
      _id: new ObjectId(payStubId)
    });
  }

  /**
   * Find pay stubs by employee
   */
  static async findByEmployee(db, employeeId, options = {}) {
    const filter = { employee_id: new ObjectId(employeeId) };
    
    if (options.year) {
      const startOfYear = new Date(options.year, 0, 1);
      const endOfYear = new Date(options.year, 11, 31, 23, 59, 59);
      filter.issue_date = { $gte: startOfYear, $lte: endOfYear };
    }
    
    if (options.status) {
      filter.status = options.status;
    }

    return await db.collection('pay_stubs')
      .find(filter)
      .sort({ issue_date: -1 })
      .limit(options.limit || 50)
      .skip(options.skip || 0)
      .toArray();
  }

  /**
   * Find pay stubs by pay period
   */
  static async findByPayPeriod(db, payPeriodId, options = {}) {
    const filter = { pay_period_id: new ObjectId(payPeriodId) };
    
    if (options.status) {
      filter.status = options.status;
    }

    return await db.collection('pay_stubs')
      .find(filter)
      .sort({ 'employee_info.full_name': 1 })
      .limit(options.limit || 100)
      .skip(options.skip || 0)
      .toArray();
  }

  /**
   * Update pay stub status
   */
  static async updateStatus(db, payStubId, status, updatedBy) {
    const validStatuses = ['draft', 'issued', 'delivered', 'viewed'];
    if (!validStatuses.includes(status)) {
      throw new Error('Invalid status');
    }

    const updateData = {
      status: status,
      updated_at: new Date(),
      updated_by: new ObjectId(updatedBy)
    };

    // Add timestamp for specific status changes
    if (status === 'delivered') {
      updateData.delivered_at = new Date();
    } else if (status === 'viewed') {
      updateData.viewed_at = new Date();
    }

    const result = await db.collection('pay_stubs').updateOne(
      { _id: new ObjectId(payStubId) },
      { $set: updateData }
    );

    return result.modifiedCount > 0;
  }

  /**
   * Mark pay stub as viewed by employee
   */
  static async markAsViewed(db, payStubId, viewedAt = new Date()) {
    const result = await db.collection('pay_stubs').updateOne(
      { _id: new ObjectId(payStubId) },
      {
        $set: {
          status: 'viewed',
          viewed_at: viewedAt,
          updated_at: new Date()
        }
      }
    );

    return result.modifiedCount > 0;
  }

  /**
   * Update PDF path
   */
  static async updatePdfPath(db, payStubId, pdfPath, updatedBy) {
    const result = await db.collection('pay_stubs').updateOne(
      { _id: new ObjectId(payStubId) },
      {
        $set: {
          pdf_path: pdfPath,
          updated_at: new Date(),
          updated_by: new ObjectId(updatedBy)
        }
      }
    );

    return result.modifiedCount > 0;
  }

  /**
   * Get pay stub statistics
   */
  static async getStatistics(db, options = {}) {
    const matchStage = {};
    
    if (options.year) {
      const startOfYear = new Date(options.year, 0, 1);
      const endOfYear = new Date(options.year, 11, 31, 23, 59, 59);
      matchStage.issue_date = { $gte: startOfYear, $lte: endOfYear };
    }

    if (options.pay_period_id) {
      matchStage.pay_period_id = new ObjectId(options.pay_period_id);
    }

    const pipeline = [
      { $match: matchStage },
      {
        $group: {
          _id: '$status',
          count: { $sum: 1 },
          total_gross_pay: { $sum: '$earnings.gross_pay' },
          total_net_pay: { $sum: '$earnings.net_pay' },
          avg_gross_pay: { $avg: '$earnings.gross_pay' },
          avg_net_pay: { $avg: '$earnings.net_pay' }
        }
      }
    ];

    return await db.collection('pay_stubs').aggregate(pipeline).toArray();
  }

  /**
   * Delete pay stub (only if draft)
   */
  static async delete(db, payStubId) {
    const result = await db.collection('pay_stubs').deleteOne({
      _id: new ObjectId(payStubId),
      status: 'draft'
    });

    return result.deletedCount > 0;
  }

  /**
   * Batch create pay stubs for pay period
   */
  static async batchCreate(db, payPeriodId, createdBy, options = {}) {
    // Get all approved calculations for the pay period
    const calculations = await db.collection('payroll_calculations').find({
      pay_period_id: new ObjectId(payPeriodId),
      status: 'approved'
    }).toArray();

    const results = {
      successful: [],
      failed: [],
      skipped: []
    };

    for (const calculation of calculations) {
      try {
        // Check if pay stub already exists
        const existing = await db.collection('pay_stubs').findOne({
          payroll_calculation_id: calculation._id
        });

        if (existing) {
          results.skipped.push({
            employee_id: calculation.employee_id.toString(),
            calculation_id: calculation._id.toString(),
            reason: 'Pay stub already exists'
          });
          continue;
        }

        const payStub = await this.create(db, calculation._id.toString(), createdBy, options);
        
        results.successful.push({
          employee_id: calculation.employee_id.toString(),
          calculation_id: calculation._id.toString(),
          pay_stub_id: payStub._id.toString(),
          stub_number: payStub.stub_number
        });

      } catch (error) {
        results.failed.push({
          employee_id: calculation.employee_id.toString(),
          calculation_id: calculation._id.toString(),
          error: error.message
        });
      }
    }

    return results;
  }
}

module.exports = PayStub;