const { ObjectId } = require('mongodb');

/**
 * PayrollDeductionHistory Model
 * Provides structure and methods for PayrollDeductionHistory data
 */
class PayrollDeductionHistory {
  /**
   * Get MongoDB schema validation for payroll_deduction_history collection
   * @returns {Object} MongoDB schema validation object
   */
  static getSchema() {
    return {
      validator: {
        $jsonSchema: {
          bsonType: "object",
          required: ["employee_deduction_id", "employee_id", "pay_period_start", "pay_period_end", "gross_pay_amount", "amount_deducted", "processed_at"],
          properties: {
            employee_deduction_id: { 
              bsonType: "objectId",
              description: "Reference to payroll_employee_deductions - must be a valid ObjectId and is required"
            },
            employee_id: { 
              bsonType: "objectId",
              description: "Reference to users collection - must be a valid ObjectId and is required"
            },
            pay_period_start: { 
              bsonType: "date",
              description: "Start of pay period - must be a valid date and is required"
            },
            pay_period_end: { 
              bsonType: "date",
              description: "End of pay period - must be a valid date and is required"
            },
            gross_pay_amount: { 
              bsonType: "number",
              minimum: 0,
              description: "Employee's gross pay for period - must be positive and is required"
            },
            amount_deducted: { 
              bsonType: "number",
              minimum: 0,
              description: "Amount actually deducted - must be positive and is required"
            },
            reason_for_variance: { 
              bsonType: "string",
              maxLength: 500,
              description: "If amount differs from configured amount"
            },
            remaining_balance_after: { 
              bsonType: ["number", "null"],
              minimum: 0,
              description: "Balance after this deduction"
            },
            processed_by: { 
              bsonType: ["objectId", "null"],
              description: "User who processed payroll"
            },
            processed_at: { 
              bsonType: "date",
              description: "When processed - must be a valid date and is required"
            }
          }
        }
      }
    };
  }

  /**
   * Create a new deduction history entry
   * @param {Object} db MongoDB database connection
   * @param {Object} historyData History data
   * @returns {Object} Created history entry
   */
  static async create(db, historyData) {
    const history = {
      ...historyData,
      _id: new ObjectId(),
      employee_deduction_id: new ObjectId(historyData.employee_deduction_id),
      employee_id: new ObjectId(historyData.employee_id),
      processed_by: historyData.processed_by ? new ObjectId(historyData.processed_by) : null,
      processed_at: new Date()
    };

    const result = await db.collection('payroll_deduction_history').insertOne(history);
    return { ...history, _id: result.insertedId };
  }

  /**
   * Find deduction history by employee
   * @param {Object} db MongoDB database connection
   * @param {string} employeeId Employee ObjectId
   * @param {Object} options Query options
   * @returns {Array} Array of history entries with joined data
   */
  static async findByEmployee(db, employeeId, options = {}) {
    const { limit = 50, skip = 0, startDate, endDate } = options;
    
    const query = { employee_id: new ObjectId(employeeId) };
    
    if (startDate || endDate) {
      query.pay_period_start = {};
      if (startDate) query.pay_period_start.$gte = new Date(startDate);
      if (endDate) query.pay_period_start.$lte = new Date(endDate);
    }

    return await db.collection('payroll_deduction_history')
      .aggregate([
        { $match: query },
        {
          $lookup: {
            from: 'payroll_employee_deductions',
            localField: 'employee_deduction_id',
            foreignField: '_id',
            as: 'deduction'
          }
        },
        { $unwind: '$deduction' },
        {
          $lookup: {
            from: 'payroll_deduction_types',
            localField: 'deduction.deduction_type_id',
            foreignField: '_id',
            as: 'deduction_type'
          }
        },
        { $unwind: '$deduction_type' },
        {
          $lookup: {
            from: 'users',
            localField: 'processed_by',
            foreignField: '_id',
            as: 'processed_by_user'
          }
        },
        { $unwind: { path: '$processed_by_user', preserveNullAndEmptyArrays: true } },
        { $sort: { processed_at: -1 } },
        { $skip: skip },
        { $limit: limit }
      ])
      .toArray();
  }

  /**
   * Find history by specific deduction
   * @param {Object} db MongoDB database connection
   * @param {string} deductionId Deduction ObjectId
   * @returns {Array} Array of history entries for the deduction
   */
  static async findByDeduction(db, deductionId) {
    return await db.collection('payroll_deduction_history')
      .find({ employee_deduction_id: new ObjectId(deductionId) })
      .sort({ processed_at: -1 })
      .toArray();
  }

  /**
   * Get deduction summary for an employee
   * @param {Object} db MongoDB database connection
   * @param {string} employeeId Employee ObjectId
   * @param {Object} options Query options
   * @returns {Array} Summary of deductions by type
   */
  static async getDeductionSummary(db, employeeId, options = {}) {
    const { startDate, endDate } = options;
    
    const matchQuery = { employee_id: new ObjectId(employeeId) };
    
    if (startDate || endDate) {
      matchQuery.pay_period_start = {};
      if (startDate) matchQuery.pay_period_start.$gte = new Date(startDate);
      if (endDate) matchQuery.pay_period_start.$lte = new Date(endDate);
    }

    return await db.collection('payroll_deduction_history')
      .aggregate([
        { $match: matchQuery },
        {
          $lookup: {
            from: 'payroll_employee_deductions',
            localField: 'employee_deduction_id',
            foreignField: '_id',
            as: 'deduction'
          }
        },
        { $unwind: '$deduction' },
        {
          $lookup: {
            from: 'payroll_deduction_types',
            localField: 'deduction.deduction_type_id',
            foreignField: '_id',
            as: 'deduction_type'
          }
        },
        { $unwind: '$deduction_type' },
        {
          $group: {
            _id: '$deduction_type.name',
            total_deducted: { $sum: '$amount_deducted' },
            deduction_count: { $sum: 1 },
            average_deduction: { $avg: '$amount_deducted' },
            deduction_type: { $first: '$deduction_type' },
            latest_deduction: { $max: '$processed_at' }
          }
        },
        { $sort: { total_deducted: -1 } }
      ])
      .toArray();
  }

  /**
   * Get payroll summary for a period
   * @param {Object} db MongoDB database connection
   * @param {Date} payPeriodStart Start of pay period
   * @param {Date} payPeriodEnd End of pay period
   * @param {Object} options Query options
   * @returns {Object} Payroll summary statistics
   */
  static async getPayrollSummary(db, payPeriodStart, payPeriodEnd, options = {}) {
    const { branchId } = options;
    
    const pipeline = [
      {
        $match: {
          pay_period_start: { $gte: new Date(payPeriodStart) },
          pay_period_end: { $lte: new Date(payPeriodEnd) }
        }
      }
    ];

    // Add branch filter if specified
    if (branchId) {
      pipeline.push({
        $lookup: {
          from: 'users',
          localField: 'employee_id',
          foreignField: '_id',
          as: 'employee'
        }
      });
      pipeline.push({ $unwind: '$employee' });
      pipeline.push({
        $match: {
          'employee.branch.branch_id': new ObjectId(branchId)
        }
      });
    }

    pipeline.push({
      $group: {
        _id: null,
        total_employees: { $addToSet: '$employee_id' },
        total_gross_pay: { $sum: '$gross_pay_amount' },
        total_deductions: { $sum: '$amount_deducted' },
        deduction_count: { $sum: 1 },
        average_deduction: { $avg: '$amount_deducted' }
      }
    });

    pipeline.push({
      $project: {
        total_employees: { $size: '$total_employees' },
        total_gross_pay: 1,
        total_deductions: 1,
        deduction_count: 1,
        average_deduction: 1,
        net_pay: { $subtract: ['$total_gross_pay', '$total_deductions'] }
      }
    });

    const result = await db.collection('payroll_deduction_history')
      .aggregate(pipeline)
      .toArray();

    return result[0] || {
      total_employees: 0,
      total_gross_pay: 0,
      total_deductions: 0,
      deduction_count: 0,
      average_deduction: 0,
      net_pay: 0
    };
  }

  /**
   * Get deduction trends over time
   * @param {Object} db MongoDB database connection
   * @param {Object} options Query options
   * @returns {Array} Deduction trends by month
   */
  static async getDeductionTrends(db, options = {}) {
    const { employeeId, deductionTypeId, months = 12 } = options;
    
    const startDate = new Date();
    startDate.setMonth(startDate.getMonth() - months);
    
    const matchQuery = {
      processed_at: { $gte: startDate }
    };
    
    if (employeeId) {
      matchQuery.employee_id = new ObjectId(employeeId);
    }
    
    if (deductionTypeId) {
      matchQuery['deduction.deduction_type_id'] = new ObjectId(deductionTypeId);
    }

    return await db.collection('payroll_deduction_history')
      .aggregate([
        { $match: matchQuery },
        {
          $lookup: {
            from: 'payroll_employee_deductions',
            localField: 'employee_deduction_id',
            foreignField: '_id',
            as: 'deduction'
          }
        },
        { $unwind: '$deduction' },
        {
          $group: {
            _id: {
              year: { $year: '$processed_at' },
              month: { $month: '$processed_at' }
            },
            total_deducted: { $sum: '$amount_deducted' },
            deduction_count: { $sum: 1 },
            unique_employees: { $addToSet: '$employee_id' }
          }
        },
        {
          $project: {
            year: '$_id.year',
            month: '$_id.month',
            total_deducted: 1,
            deduction_count: 1,
            unique_employees: { $size: '$unique_employees' }
          }
        },
        { $sort: { year: 1, month: 1 } }
      ])
      .toArray();
  }

  /**
   * Find all deduction history records with pagination and filtering
   * @param {Object} db MongoDB database connection
   * @param {Object} options Query options including pagination and filters
   * @returns {Array} Array of all history entries with joined data
   */
  static async findAll(db, options = {}) {
    const { limit = 50, skip = 0, startDate, endDate, employeeId, deductionTypeId } = options;
    
    const query = {};
    
    // Add date filtering
    if (startDate || endDate) {
      query.pay_period_start = {};
      if (startDate) query.pay_period_start.$gte = new Date(startDate);
      if (endDate) query.pay_period_start.$lte = new Date(endDate);
    }
    
    // Add employee filtering
    if (employeeId) {
      query.employee_id = new ObjectId(employeeId);
    }

    return await db.collection('payroll_deduction_history')
      .aggregate([
        { $match: query },
        {
          $lookup: {
            from: 'payroll_employee_deductions',
            localField: 'employee_deduction_id',
            foreignField: '_id',
            as: 'deduction'
          }
        },
        { $unwind: '$deduction' },
        {
          $lookup: {
            from: 'payroll_deduction_types',
            localField: 'deduction.deduction_type_id',
            foreignField: '_id',
            as: 'deduction_type'
          }
        },
        { $unwind: '$deduction_type' },
        // Add employee information
        {
          $lookup: {
            from: 'users',
            localField: 'employee_id',
            foreignField: '_id',
            as: 'employee'
          }
        },
        { $unwind: '$employee' },
        {
          $lookup: {
            from: 'users',
            localField: 'processed_by',
            foreignField: '_id',
            as: 'processed_by_user'
          }
        },
        { $unwind: { path: '$processed_by_user', preserveNullAndEmptyArrays: true } },
        // Filter by deduction type if specified
        ...(deductionTypeId ? [{ $match: { 'deduction_type._id': new ObjectId(deductionTypeId) } }] : []),
        {
          $project: {
            _id: 1,
            employee_deduction_id: 1,
            employee_id: 1,
            pay_period_start: 1,
            pay_period_end: 1,
            gross_pay_amount: 1,
            amount_deducted: 1,
            processed_at: 1,
            reason_for_variance: 1,
            remaining_balance_after: 1,
            employee: {
              _id: '$employee._id',
              full_name: '$employee.full_name',
              email: '$employee.email',
              staff_code: '$employee.staff_code'
            },
            deduction_type: {
              _id: '$deduction_type._id',
              name: '$deduction_type.name',
              type: '$deduction_type.type',
              description: '$deduction_type.description'
            },
            processed_by_user: {
              _id: '$processed_by_user._id',
              full_name: '$processed_by_user.full_name',
              email: '$processed_by_user.email'
            }
          }
        },
        { $sort: { processed_at: -1 } },
        { $skip: skip },
        { $limit: limit }
      ])
      .toArray();
  }

  /**
   * Count history entries with filters
   * @param {Object} db MongoDB database connection
   * @param {Object} filters Filter criteria
   * @returns {number} Count of matching entries
   */
  static async count(db, filters = {}) {
    const query = {};
    
    if (filters.employeeId) {
      query.employee_id = new ObjectId(filters.employeeId);
    }
    
    if (filters.startDate || filters.endDate) {
      query.pay_period_start = {};
      if (filters.startDate) query.pay_period_start.$gte = new Date(filters.startDate);
      if (filters.endDate) query.pay_period_start.$lte = new Date(filters.endDate);
    }

    return await db.collection('payroll_deduction_history').countDocuments(query);
  }
}

module.exports = PayrollDeductionHistory;