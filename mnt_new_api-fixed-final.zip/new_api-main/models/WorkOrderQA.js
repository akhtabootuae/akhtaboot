const { ObjectId } = require('mongodb');
const { EventEmitter } = require('events');

class WorkOrderQA extends EventEmitter {
  constructor(db) {
    super();
    this.db = db;
    this.collection = db.collection('workordersqa');
  }

  /**
   * Get MongoDB collection validation schema
   * @returns {Object} MongoDB validation schema
   */
  static getSchema() {
    return {
      validator: {
        $jsonSchema: {
          bsonType: "object",
          required: ["WO_ID", "person_name", "passed", "images", "description"],
          properties: {
            _id: {
              bsonType: "objectId"
            },
            WO_ID: {
              bsonType: "string",
              description: "Work Order ID is required"
            },
            person_name: {
              bsonType: "string",
              minLength: 2,
              maxLength: 100,
              description: "Person name is required and must be 2-100 characters"
            },
            passed: {
              bsonType: "bool",
              description: "QA pass/fail status is required"
            },
            images: {
              bsonType: "array",
              minItems: 3,
              maxItems: 5,
              items: {
                bsonType: "object",
                required: ["s3_key", "original_name", "size", "mime_type", "upload_date"],
                properties: {
                  s3_key: {
                    bsonType: "string",
                    description: "S3 file key is required"
                  },
                  original_name: {
                    bsonType: "string",
                    description: "Original filename is required"
                  },
                  size: {
                    bsonType: "number",
                    minimum: 1,
                    description: "File size in bytes is required"
                  },
                  mime_type: {
                    bsonType: "string",
                    pattern: "^image/",
                    description: "MIME type must be an image type"
                  },
                  upload_date: {
                    bsonType: "date",
                    description: "Upload date is required"
                  }
                }
              },
              description: "Images array must contain 3-5 image objects"
            },
            description: {
              bsonType: "string",
              minLength: 10,
              maxLength: 1000,
              description: "Description is required and must be 10-1000 characters"
            },
            created_at: {
              bsonType: "date",
              description: "Creation timestamp"
            },
            updated_at: {
              bsonType: "date",
              description: "Last update timestamp"
            }
          }
        }
      }
    };
  }

  /**
   * Create a new QA record
   * @param {Object} qaData - QA data object
   * @returns {Promise<Object>} Created QA record
   */
  async create(qaData) {
    try {
      const now = new Date();
      const document = {
        ...qaData,
        created_at: now,
        updated_at: now
      };

      const result = await this.collection.insertOne(document);
      const createdQA = await this.collection.findOne({ _id: result.insertedId });
      
      this.emit('created', createdQA);
      return createdQA;
    } catch (error) {
      this.emit('error', error);
      throw error;
    }
  }

  /**
   * Find QA records by work order ID
   * @param {string} woId - Work Order ID
   * @returns {Promise<Array>} Array of QA records
   */
  async findByWorkOrderId(woId) {
    try {
      const qaRecords = await this.collection.find({ WO_ID: woId }).toArray();
      return qaRecords;
    } catch (error) {
      this.emit('error', error);
      throw error;
    }
  }

  /**
   * Find QA record by ID
   * @param {string} id - QA record ID
   * @returns {Promise<Object|null>} QA record or null
   */
  async findById(id) {
    try {
      const qaRecord = await this.collection.findOne({ _id: new ObjectId(id) });
      return qaRecord;
    } catch (error) {
      this.emit('error', error);
      throw error;
    }
  }

  /**
   * Update QA record
   * @param {string} id - QA record ID
   * @param {Object} updateData - Update data
   * @returns {Promise<Object|null>} Updated QA record
   */
  async update(id, updateData) {
    try {
      const updateDoc = {
        ...updateData,
        updated_at: new Date()
      };

      const result = await this.collection.findOneAndUpdate(
        { _id: new ObjectId(id) },
        { $set: updateDoc },
        { returnDocument: 'after' }
      );

      if (result.value) {
        this.emit('updated', result.value);
      }
      
      return result.value;
    } catch (error) {
      this.emit('error', error);
      throw error;
    }
  }

  /**
   * Delete QA record
   * @param {string} id - QA record ID
   * @returns {Promise<Object|null>} Deleted QA record
   */
  async delete(id) {
    try {
      const qaRecord = await this.collection.findOneAndDelete({ _id: new ObjectId(id) });
      
      if (qaRecord.value) {
        this.emit('deleted', qaRecord.value);
      }
      
      return qaRecord.value;
    } catch (error) {
      this.emit('error', error);
      throw error;
    }
  }

  /**
   * Get all QA records with pagination
   * @param {Object} options - Query options
   * @param {number} options.page - Page number (default: 1)
   * @param {number} options.limit - Records per page (default: 10)
   * @param {Object} options.filter - Filter criteria
   * @returns {Promise<Object>} Paginated results
   */
  async findAll(options = {}) {
    try {
      const { page = 1, limit = 10, filter = {} } = options;
      const skip = (page - 1) * limit;

      const [qaRecords, total] = await Promise.all([
        this.collection.find(filter).skip(skip).limit(limit).toArray(),
        this.collection.countDocuments(filter)
      ]);

      return {
        data: qaRecords,
        pagination: {
          page,
          limit,
          total,
          pages: Math.ceil(total / limit)
        }
      };
    } catch (error) {
      this.emit('error', error);
      throw error;
    }
  }

  /**
   * Get QA statistics
   * @returns {Promise<Object>} QA statistics
   */
  async getStats() {
    try {
      const [total, passed, failed] = await Promise.all([
        this.collection.countDocuments(),
        this.collection.countDocuments({ passed: true }),
        this.collection.countDocuments({ passed: false })
      ]);

      return {
        total,
        passed,
        failed,
        pass_rate: total > 0 ? (passed / total * 100).toFixed(2) : 0
      };
    } catch (error) {
      this.emit('error', error);
      throw error;
    }
  }
}

module.exports = WorkOrderQA;