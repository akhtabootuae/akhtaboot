const { ObjectId } = require('mongodb');
const moment = require('moment');

class PayrollCalculation {
  /**
   * Get collection validation schema for MongoDB
   */
  static getSchema() {
    return {
      validator: {
        $jsonSchema: {
          bsonType: "object",
          required: ["employee_id", "pay_period_id", "gross_pay", "total_deductions", "net_pay"],
          properties: {
            employee_id: {
              bsonType: "objectId",
              description: "Reference to employee in users collection"
            },
            pay_period_id: {
              bsonType: "objectId",
              description: "Reference to pay period"
            },
            gross_pay: {
              bsonType: "number",
              minimum: 0,
              description: "Total gross pay before deductions"
            },
            monthly_salary: {
              bsonType: "number",
              minimum: 0,
              description: "Employee's monthly salary"
            },
            days_worked: {
              bsonType: "int",
              minimum: 0,
              description: "Number of days worked in the period"
            },
            deductions: {
              bsonType: "array",
              items: {
                bsonType: "object",
                required: ["deduction_type_id", "amount"],
                properties: {
                  deduction_type_id: {
                    bsonType: "objectId",
                    description: "Reference to deduction type"
                  },
                  deduction_name: {
                    bsonType: "string",
                    description: "Name of the deduction"
                  },
                  amount: {
                    bsonType: "number",
                    minimum: 0,
                    description: "Deduction amount"
                  },
                  calculation_method: {
                    bsonType: "string",
                    enum: ["fixed", "percentage", "formula"],
                    description: "How the deduction was calculated"
                  },
                  percentage: {
                    bsonType: "number",
                    minimum: 0,
                    maximum: 100,
                    description: "Percentage if percentage-based deduction"
                  },
                  notes: {
                    bsonType: "string",
                    maxLength: 200,
                    description: "Notes about this deduction"
                  }
                }
              },
              description: "List of deductions applied"
            },
            total_deductions: {
              bsonType: "number",
              minimum: 0,
              description: "Total amount of all deductions"
            },
            net_pay: {
              bsonType: "number",
              minimum: 0,
              description: "Final pay after deductions"
            },
            taxes: {
              bsonType: "object",
              properties: {
                federal_tax: {
                  bsonType: "number",
                  minimum: 0,
                  description: "Federal tax amount"
                },
                state_tax: {
                  bsonType: "number",
                  minimum: 0,
                  description: "State tax amount"
                },
                social_security: {
                  bsonType: "number",
                  minimum: 0,
                  description: "Social security tax"
                },
                medicare: {
                  bsonType: "number",
                  minimum: 0,
                  description: "Medicare tax"
                },
                other_taxes: {
                  bsonType: "number",
                  minimum: 0,
                  description: "Other tax amounts"
                }
              },
              description: "Tax breakdown (future enhancement)"
            },
            status: {
              bsonType: "string",
              enum: ["draft", "calculated", "reviewed", "approved", "paid"],
              description: "Status of the calculation"
            },
            calculation_date: {
              bsonType: "date",
              description: "When the calculation was performed"
            },
            approved_at: {
              bsonType: "date",
              description: "When calculation was approved"
            },
            approved_by: {
              bsonType: "objectId",
              description: "Who approved the calculation"
            },
            paid_at: {
              bsonType: "date",
              description: "When employee was paid"
            },
            pay_method: {
              bsonType: "string",
              enum: ["bank_transfer", "check", "cash", "other"],
              description: "Method of payment"
            },
            notes: {
              bsonType: "string",
              maxLength: 500,
              description: "Additional notes"
            },
            created_at: {
              bsonType: "date",
              description: "Creation timestamp"
            },
            updated_at: {
              bsonType: "date",
              description: "Last update timestamp"
            },
            created_by: {
              bsonType: "objectId",
              description: "User who created the calculation"
            },
            updated_by: {
              bsonType: "objectId",
              description: "User who last updated the calculation"
            }
          }
        }
      }
    };
  }

  /**
   * Create payroll calculation for employee
   */
  static async create(db, calculationData) {
    // Validate required fields
    if (!calculationData.employee_id || !calculationData.pay_period_id) {
      throw new Error('Employee ID and pay period ID are required');
    }

    // Check if calculation already exists
    const existing = await db.collection('payroll_calculations').findOne({
      employee_id: new ObjectId(calculationData.employee_id),
      pay_period_id: new ObjectId(calculationData.pay_period_id)
    });

    if (existing) {
      throw new Error('Payroll calculation already exists for this employee and period');
    }

    // Get pay period details
    const payPeriod = await db.collection('pay_periods').findOne({
      _id: new ObjectId(calculationData.pay_period_id)
    });

    if (!payPeriod) {
      throw new Error('Pay period not found');
    }

    // Calculate payroll data
    const calculatedData = await this.calculatePayroll(db, calculationData, payPeriod);

    const calculation = {
      employee_id: new ObjectId(calculationData.employee_id),
      pay_period_id: new ObjectId(calculationData.pay_period_id),
      ...calculatedData,
      status: calculationData.status || 'calculated',
      calculation_date: new Date(),
      pay_method: calculationData.pay_method || 'bank_transfer',
      notes: calculationData.notes || '',
      created_at: new Date(),
      updated_at: new Date(),
      created_by: new ObjectId(calculationData.created_by)
    };

    const result = await db.collection('payroll_calculations').insertOne(calculation);
    return { ...calculation, _id: result.insertedId };
  }

  /**
   * Calculate payroll for employee in given period
   */
  static async calculatePayroll(db, calculationData, payPeriod) {
    const employeeId = calculationData.employee_id;
    
    // Get employee details
    const employee = await db.collection('users').findOne({
      _id: new ObjectId(employeeId)
    });

    if (!employee || !employee.payroll_info?.payroll_eligible) {
      throw new Error('Employee not found or not eligible for payroll');
    }

    // Get approved timesheets for this period (just for attendance tracking)
    const timesheets = await db.collection('timesheets').find({
      employee_id: new ObjectId(employeeId),
      work_date: {
        $gte: payPeriod.start_date,
        $lte: payPeriod.end_date
      },
      status: 'approved'
    }).toArray();

    const daysWorked = timesheets.length;

    // Get monthly salary
    const monthlySalary = employee.payroll_info.monthly_salary || 0;
    
    // Gross pay is the monthly salary (overtime handled separately as expenses)
    const grossPay = monthlySalary;

    // Get active deductions for this employee
    const activeDeductions = await db.collection('payroll_employee_deductions').find({
      employee_id: new ObjectId(employeeId),
      status: 'approved',
      $or: [
        { end_date: null },
        { end_date: { $gte: payPeriod.end_date } }
      ],
      start_date: { $lte: payPeriod.start_date }
    }).toArray();

    // Calculate deductions
    const deductions = [];
    let totalDeductions = 0;

    for (const deduction of activeDeductions) {
      // Get deduction type details
      const deductionType = await db.collection('payroll_deduction_types').findOne({
        _id: deduction.deduction_type_id
      });

      if (!deductionType || !deductionType.active) continue;

      let deductionAmount = 0;
      let calculationMethod = 'fixed';

      switch (deductionType.calculation_method) {
        case 'fixed':
          deductionAmount = deduction.amount || 0;
          calculationMethod = 'fixed';
          break;
        
        case 'percentage':
          const percentage = deduction.percentage || deductionType.default_percentage || 0;
          deductionAmount = grossPay * (percentage / 100);
          calculationMethod = 'percentage';
          break;
        
        case 'formula':
          // For now, treat formula as fixed amount
          // TODO: Implement formula parsing in future
          deductionAmount = deduction.amount || 0;
          calculationMethod = 'formula';
          break;
        
        default:
          deductionAmount = deduction.amount || 0;
          calculationMethod = 'fixed';
      }

      // Apply frequency adjustment if needed
      if (deductionType.frequency !== payPeriod.frequency) {
        // Adjust deduction amount based on frequency mismatch
        // For now, assume all deductions match pay period frequency
      }

      // Apply min/max limits
      if (deductionType.min_amount && deductionAmount < deductionType.min_amount) {
        deductionAmount = deductionType.min_amount;
      }
      if (deductionType.max_amount && deductionAmount > deductionType.max_amount) {
        deductionAmount = deductionType.max_amount;
      }

      // Check remaining balance for loans/advances
      if (deductionType.type === 'loan' || deductionType.type === 'advance') {
        const remainingBalance = deduction.remaining_balance || 0;
        if (deductionAmount > remainingBalance) {
          deductionAmount = remainingBalance;
        }
      }

      if (deductionAmount > 0) {
        deductions.push({
          deduction_type_id: deduction.deduction_type_id,
          deduction_name: deductionType.name,
          amount: parseFloat(deductionAmount.toFixed(2)),
          calculation_method: calculationMethod,
          percentage: deduction.percentage || null,
          notes: deduction.notes || ''
        });

        totalDeductions += deductionAmount;
      }
    }

    // Calculate net pay
    const netPay = grossPay - totalDeductions;

    // Initialize taxes object (for future tax calculation features)
    const taxes = {
      federal_tax: 0,
      state_tax: 0,
      social_security: 0,
      medicare: 0,
      other_taxes: 0
    };

    return {
      gross_pay: parseFloat(grossPay.toFixed(2)),
      monthly_salary: monthlySalary,
      days_worked: daysWorked,
      deductions: deductions,
      total_deductions: parseFloat(totalDeductions.toFixed(2)),
      net_pay: parseFloat(netPay.toFixed(2)),
      taxes: taxes
    };
  }

  /**
   * Find calculation by ID
   */
  static async findById(db, calculationId) {
    return await db.collection('payroll_calculations').findOne({
      _id: new ObjectId(calculationId)
    });
  }

  /**
   * Find calculations by pay period
   */
  static async findByPayPeriod(db, payPeriodId, options = {}) {
    const pipeline = [
      { $match: { pay_period_id: new ObjectId(payPeriodId) } },
      {
        $lookup: {
          from: 'users',
          localField: 'employee_id',
          foreignField: '_id',
          as: 'employee'
        }
      },
      { $unwind: '$employee' },
      {
        $project: {
          employee_id: 1,
          gross_pay: 1,
          total_deductions: 1,
          net_pay: 1,
          days_worked: 1,
          status: 1,
          calculation_date: 1,
          approved_at: 1,
          paid_at: 1,
          'employee.email': 1,
          'employee.first_name': 1,
          'employee.last_name': 1,
          'employee.payroll_info.employee_id': 1
        }
      },
      { $sort: { 'employee.last_name': 1, 'employee.first_name': 1 } }
    ];

    if (options.limit) {
      pipeline.push({ $limit: options.limit });
    }
    if (options.skip) {
      pipeline.push({ $skip: options.skip });
    }

    return await db.collection('payroll_calculations').aggregate(pipeline).toArray();
  }

  /**
   * Find calculations by employee
   */
  static async findByEmployee(db, employeeId, options = {}) {
    const filter = { employee_id: new ObjectId(employeeId) };
    
    if (options.status) {
      filter.status = options.status;
    }

    if (options.startDate || options.endDate) {
      const payPeriodFilter = {};
      if (options.startDate) payPeriodFilter.$gte = new Date(options.startDate);
      if (options.endDate) payPeriodFilter.$lte = new Date(options.endDate);
      
      // Get pay periods in date range
      const payPeriods = await db.collection('pay_periods').find({
        start_date: payPeriodFilter
      }).toArray();
      
      filter.pay_period_id = { $in: payPeriods.map(p => p._id) };
    }

    return await db.collection('payroll_calculations')
      .find(filter)
      .sort({ calculation_date: -1 })
      .limit(options.limit || 50)
      .skip(options.skip || 0)
      .toArray();
  }

  /**
   * Approve calculation
   */
  static async approve(db, calculationId, approvedBy) {
    const result = await db.collection('payroll_calculations').updateOne(
      { 
        _id: new ObjectId(calculationId),
        status: { $in: ['calculated', 'reviewed'] }
      },
      {
        $set: {
          status: 'approved',
          approved_at: new Date(),
          approved_by: new ObjectId(approvedBy),
          updated_at: new Date(),
          updated_by: new ObjectId(approvedBy)
        }
      }
    );

    return result.modifiedCount > 0;
  }

  /**
   * Mark as paid
   */
  static async markPaid(db, calculationId, paidBy, payMethod = 'bank_transfer') {
    const result = await db.collection('payroll_calculations').updateOne(
      { 
        _id: new ObjectId(calculationId),
        status: 'approved'
      },
      {
        $set: {
          status: 'paid',
          paid_at: new Date(),
          pay_method: payMethod,
          updated_at: new Date(),
          updated_by: new ObjectId(paidBy)
        }
      }
    );

    // Update deduction balances for loans/advances
    if (result.modifiedCount > 0) {
      await this.updateDeductionBalances(db, calculationId);
    }

    return result.modifiedCount > 0;
  }

  /**
   * Update deduction balances after payment
   */
  static async updateDeductionBalances(db, calculationId) {
    const calculation = await this.findById(db, calculationId);
    if (!calculation) return;

    for (const deduction of calculation.deductions) {
      const deductionType = await db.collection('payroll_deduction_types').findOne({
        _id: deduction.deduction_type_id
      });

      if (deductionType && (deductionType.type === 'loan' || deductionType.type === 'advance')) {
        // Update remaining balance
        await db.collection('payroll_employee_deductions').updateOne(
          {
            employee_id: calculation.employee_id,
            deduction_type_id: deduction.deduction_type_id,
            status: 'approved'
          },
          {
            $inc: { remaining_balance: -deduction.amount },
            $set: { updated_at: new Date() }
          }
        );

        // Record deduction history
        await db.collection('payroll_deduction_history').insertOne({
          employee_id: calculation.employee_id,
          employee_deduction_id: calculation._id, // Link to calculation
          deduction_type_id: deduction.deduction_type_id,
          amount: deduction.amount,
          pay_period_start: calculation.pay_period_start,
          pay_period_end: calculation.pay_period_end,
          processed_at: new Date(),
          notes: `Processed with payroll calculation ${calculation._id}`
        });
      }
    }
  }

  /**
   * Get calculation summary for pay period
   */
  static async getPayPeriodSummary(db, payPeriodId) {
    const pipeline = [
      { $match: { pay_period_id: new ObjectId(payPeriodId) } },
      {
        $group: {
          _id: null,
          total_employees: { $sum: 1 },
          total_gross_pay: { $sum: '$gross_pay' },
          total_deductions: { $sum: '$total_deductions' },
          total_net_pay: { $sum: '$net_pay' },
          avg_gross_pay: { $avg: '$gross_pay' },
          status_breakdown: {
            $push: '$status'
          }
        }
      }
    ];

    const result = await db.collection('payroll_calculations').aggregate(pipeline).toArray();
    
    if (result.length === 0) {
      return {
        total_employees: 0,
        total_gross_pay: 0,
        total_deductions: 0,
        total_net_pay: 0,
        avg_gross_pay: 0,
        status_breakdown: {}
      };
    }

    const summary = result[0];
    
    // Process status breakdown
    const statusCounts = {};
    summary.status_breakdown.forEach(status => {
      statusCounts[status] = (statusCounts[status] || 0) + 1;
    });
    
    summary.status_breakdown = statusCounts;
    
    return summary;
  }

  /**
   * Batch approve calculations
   */
  static async batchApprove(db, calculationIds, approvedBy) {
    const result = await db.collection('payroll_calculations').updateMany(
      { 
        _id: { $in: calculationIds.map(id => new ObjectId(id)) },
        status: { $in: ['calculated', 'reviewed'] }
      },
      {
        $set: {
          status: 'approved',
          approved_at: new Date(),
          approved_by: new ObjectId(approvedBy),
          updated_at: new Date(),
          updated_by: new ObjectId(approvedBy)
        }
      }
    );

    return result.modifiedCount;
  }

  /**
   * Delete calculation (only if draft or calculated)
   */
  static async delete(db, calculationId) {
    const result = await db.collection('payroll_calculations').deleteOne({
      _id: new ObjectId(calculationId),
      status: { $in: ['draft', 'calculated'] }
    });

    return result.deletedCount > 0;
  }

  /**
   * Recalculate existing calculation
   */
  static async recalculate(db, calculationId, recalculatedBy) {
    const calculation = await this.findById(db, calculationId);
    if (!calculation) {
      throw new Error('Calculation not found');
    }

    if (calculation.status === 'paid') {
      throw new Error('Cannot recalculate paid payroll');
    }

    // Get pay period
    const payPeriod = await db.collection('pay_periods').findOne({
      _id: calculation.pay_period_id
    });

    if (!payPeriod) {
      throw new Error('Pay period not found');
    }

    // Recalculate
    const recalculatedData = await this.calculatePayroll(db, {
      employee_id: calculation.employee_id.toString(),
      pay_period_id: calculation.pay_period_id.toString()
    }, payPeriod);

    // Update calculation
    const result = await db.collection('payroll_calculations').updateOne(
      { _id: new ObjectId(calculationId) },
      {
        $set: {
          ...recalculatedData,
          status: 'calculated',
          calculation_date: new Date(),
          updated_at: new Date(),
          updated_by: new ObjectId(recalculatedBy),
          // Clear approval data
          approved_at: null,
          approved_by: null,
          paid_at: null
        }
      }
    );

    return result.modifiedCount > 0;
  }

  /**
   * Create batch calculations for all employees in a pay period
   */
  static async createBatchCalculations(db, options) {
    const { pay_period_id, start_date, end_date, created_by } = options;

    try {
      // Find all employees with timesheets in this period
      const timesheets = await db.collection('timesheets').find({
        work_date: {
          $gte: new Date(start_date),
          $lte: new Date(end_date)
        },
        status: { $in: ['approved', 'submitted'] }
      }).toArray();

      // Group by employee
      const employeeTimesheets = {};
      timesheets.forEach(ts => {
        const empId = ts.employee_id.toString();
        if (!employeeTimesheets[empId]) {
          employeeTimesheets[empId] = [];
        }
        employeeTimesheets[empId].push(ts);
      });

      const results = {
        successful_calculations: 0,
        errors: []
      };

      // Create calculations for each employee
      for (const [employeeId, empTimesheets] of Object.entries(employeeTimesheets)) {
        try {
          // Get employee's monthly salary
          const employee = await db.collection('users').findOne({
            _id: new ObjectId(employeeId)
          });

          if (!employee || !employee.payroll_info?.payroll_eligible) {
            results.errors.push({
              employee_id: employeeId,
              error: 'Employee not found or not eligible for payroll'
            });
            continue;
          }

          const monthlySalary = employee.payroll_info.monthly_salary || 0;
          const grossPay = monthlySalary;

          // Get employee deductions
          const deductions = await db.collection('payroll_employee_deductions').find({
            employee_id: new ObjectId(employeeId),
            status: 'active'
          }).toArray();

          // Populate deduction details
          const deductionDetails = [];
          let totalDeductions = 0;

          for (const deduction of deductions) {
            // Get deduction type details
            const deductionType = await db.collection('payroll_deduction_types').findOne({
              _id: deduction.deduction_type_id
            });

            const deductionAmount = deduction.amount || 0;
            totalDeductions += deductionAmount;

            deductionDetails.push({
              deduction_id: deduction._id,
              deduction_name: deductionType?.name || 'Unknown Deduction',
              amount: deductionAmount,
              notes: deduction.notes || ''
            });
          }

          const netPay = grossPay - totalDeductions;

          // Create calculation record
          const calculationData = {
            employee_id: new ObjectId(employeeId),
            pay_period_id: new ObjectId(pay_period_id),
            monthly_salary: monthlySalary,
            days_worked: empTimesheets.length,
            gross_pay: grossPay,
            deductions: deductionDetails,
            total_deductions: totalDeductions,
            net_pay: netPay,
            status: 'calculated',
            calculation_date: new Date(),
            created_by: new ObjectId(created_by),
            created_at: new Date(),
            timesheet_ids: empTimesheets.map(ts => ts._id)
          };

          await this.create(db, calculationData);
          results.successful_calculations++;

        } catch (error) {
          console.error(`Error calculating payroll for employee ${employeeId}:`, error);
          results.errors.push({
            employee_id: employeeId,
            error: error.message
          });
        }
      }

      return results;
    } catch (error) {
      console.error('Batch calculation failed:', error);
      throw new Error(`Batch calculation failed: ${error.message}`);
    }
  }
}

module.exports = PayrollCalculation;