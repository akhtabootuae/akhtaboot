const { ObjectId } = require('mongodb');

/**
 * PayrollEmployeeDeduction Model
 * Provides structure and methods for PayrollEmployeeDeduction data
 */
class PayrollEmployeeDeduction {
  /**
   * Get MongoDB schema validation for payroll_employee_deductions collection
   * @returns {Object} MongoDB schema validation object
   */
  static getSchema() {
    // No validation schema to avoid validation errors
    return {};
  }

  /**
   * Find deductions by employee with joined data
   * @param {Object} db MongoDB database connection
   * @param {string} employeeId Employee ObjectId
   * @param {Object} filters Filter criteria
   * @returns {Array} Array of employee deductions with joined data
   */
  static async findByEmployee(db, employeeId, filters = {}) {
    const query = { employee_id: new ObjectId(employeeId) };
    
    if (filters.status) query.status = filters.status;
    if (filters.active_only) query.status = 'active';
    
    return await db.collection('payroll_employee_deductions')
      .aggregate([
        { $match: query },
        {
          $lookup: {
            from: 'payroll_deduction_types',
            localField: 'deduction_type_id',
            foreignField: '_id',
            as: 'deduction_type'
          }
        },
        { $unwind: '$deduction_type' },
        {
          $lookup: {
            from: 'users',
            localField: 'created_by',
            foreignField: '_id',
            as: 'created_by_user'
          }
        },
        { $unwind: { path: '$created_by_user', preserveNullAndEmptyArrays: true } },
        { $sort: { priority: 1, created_at: -1 } }
      ])
      .toArray();
  }

  /**
   * Find deduction by ID with joined data
   * @param {Object} db MongoDB database connection
   * @param {string} id Deduction ID
   * @returns {Object|null} Deduction with joined data or null
   */
  static async findById(db, id) {
    const result = await db.collection('payroll_employee_deductions')
      .aggregate([
        { $match: { _id: new ObjectId(id) } },
        {
          $lookup: {
            from: 'payroll_deduction_types',
            localField: 'deduction_type_id',
            foreignField: '_id',
            as: 'deduction_type'
          }
        },
        { $unwind: '$deduction_type' },
        {
          $lookup: {
            from: 'users',
            localField: 'employee_id',
            foreignField: '_id',
            as: 'employee'
          }
        },
        { $unwind: '$employee' }
      ])
      .toArray();

    return result[0] || null;
  }

  /**
   * Create a new employee deduction
   * @param {Object} db MongoDB database connection
   * @param {Object} deductionData Deduction data
   * @returns {Object} Created deduction
   */
  static async create(db, deductionData) {
    // Simple deduction creation - no validation
    const deduction = {
      employee_id: new ObjectId(deductionData.employee_id),
      deduction_type_id: new ObjectId(deductionData.deduction_type_id),
      amount: parseFloat(deductionData.amount || 0),
      frequency: deductionData.frequency || 'monthly',
      start_date: new Date(deductionData.start_date),
      end_date: deductionData.end_date ? new Date(deductionData.end_date) : null,
      status: deductionData.status || 'active',
      notes: deductionData.notes || '',
      priority: parseInt(deductionData.priority || 5),
      max_total_amount: deductionData.max_total_amount ? parseFloat(deductionData.max_total_amount) : null,
      total_deducted: 0,
      remaining_balance: deductionData.max_total_amount ? parseFloat(deductionData.max_total_amount) : null,
      legal_required: deductionData.legal_required || false,
      reference_number: deductionData.reference_number || '',
      created_by: new ObjectId(deductionData.created_by),
      created_at: new Date(),
      updated_at: new Date()
    };

    const result = await db.collection('payroll_employee_deductions').insertOne(deduction);
    return { ...deduction, _id: result.insertedId };
  }

  /**
   * Update an existing deduction
   * @param {Object} db MongoDB database connection
   * @param {string} id Deduction ID
   * @param {Object} updateData Update data
   * @returns {boolean} Success status
   */
  static async update(db, id, updateData) {
    const updatedData = {
      ...updateData,
      updated_at: new Date()
    };

    // Remove fields that shouldn't be updated directly
    delete updatedData._id;
    delete updatedData.total_deducted;

    const result = await db.collection('payroll_employee_deductions').updateOne(
      { _id: new ObjectId(id) },
      { $set: updatedData }
    );

    return result.modifiedCount > 0;
  }

  /**
   * Approve a pending deduction
   * @param {Object} db MongoDB database connection
   * @param {string} id Deduction ID
   * @param {string} approvedBy User ID who approved
   * @returns {boolean} Success status
   */
  static async approve(db, id, approvedBy) {
    const result = await db.collection('payroll_employee_deductions').updateOne(
      { _id: new ObjectId(id), status: 'pending_approval' },
      {
        $set: {
          status: 'active',
          approved_by: new ObjectId(approvedBy),
          approved_at: new Date(),
          updated_at: new Date()
        }
      }
    );

    return result.modifiedCount > 0;
  }

  /**
   * Update deduction balance after processing
   * @param {Object} db MongoDB database connection
   * @param {string} id Deduction ID
   * @param {number} amountDeducted Amount that was deducted
   * @returns {boolean} Success status
   */
  static async updateBalance(db, id, amountDeducted) {
    const deduction = await db.collection('payroll_employee_deductions')
      .findOne({ _id: new ObjectId(id) });

    if (!deduction) {
      throw new Error('Deduction not found');
    }

    const newTotalDeducted = deduction.total_deducted + amountDeducted;
    const newRemainingBalance = deduction.max_total_amount ? 
      deduction.max_total_amount - newTotalDeducted : null;

    const updateData = {
      total_deducted: newTotalDeducted,
      remaining_balance: newRemainingBalance,
      updated_at: new Date()
    };

    // Mark as completed if balance reaches zero
    if (newRemainingBalance !== null && newRemainingBalance <= 0) {
      updateData.status = 'completed';
      updateData.end_date = new Date();
    }

    const result = await db.collection('payroll_employee_deductions').updateOne(
      { _id: new ObjectId(id) },
      { $set: updateData }
    );

    return result.modifiedCount > 0;
  }

  /**
   * Validate business rules for deduction creation/update
   * @param {Object} db MongoDB database connection
   * @param {Object} deductionData Deduction data to validate
   * @throws {Error} If validation fails
   */
  static async validateBusinessRules(db, deductionData) {
    const errors = [];

    // Check if employee exists and is payroll eligible
    const employee = await db.collection('users').findOne({
      _id: new ObjectId(deductionData.employee_id),
      'payroll_info.payroll_eligible': true
    });

    if (!employee) {
      errors.push('Employee not found or not payroll eligible');
    }

    // Check if deduction type exists and is active
    const deductionType = await db.collection('payroll_deduction_types').findOne({
      _id: new ObjectId(deductionData.deduction_type_id),
      active: true
    });

    if (!deductionType) {
      errors.push('Deduction type not found or inactive');
    }

    // Validate amount and percentage limits
    if (deductionType && deductionType.max_percentage_of_pay) {
      if (deductionType.type === 'percentage' && 
          deductionData.amount > deductionType.max_percentage_of_pay) {
        errors.push(`Deduction percentage cannot exceed ${deductionType.max_percentage_of_pay}%`);
      }
    }

    // Validate date range
    if (deductionData.end_date && new Date(deductionData.end_date) <= new Date(deductionData.start_date)) {
      errors.push('End date must be after start date');
    }

    // Validate priority
    if (deductionData.priority && (deductionData.priority < 1 || deductionData.priority > 10)) {
      errors.push('Priority must be between 1 and 10');
    }

    if (errors.length > 0) {
      throw new Error(errors.join(', '));
    }
  }

  /**
   * Get active deductions for payroll processing
   * @param {Object} db MongoDB database connection
   * @param {string} employeeId Employee ObjectId
   * @param {Date} payPeriodStart Pay period start date
   * @param {Date} payPeriodEnd Pay period end date
   * @returns {Array} Array of active deductions for the pay period
   */
  static async getActiveDeductionsForPayroll(db, employeeId, payPeriodStart, payPeriodEnd) {
    return await db.collection('payroll_employee_deductions')
      .find({
        employee_id: new ObjectId(employeeId),
        status: 'active',
        start_date: { $lte: new Date(payPeriodEnd) },
        $or: [
          { end_date: null },
          { end_date: { $gte: new Date(payPeriodStart) } }
        ]
      })
      .sort({ priority: 1 })
      .toArray();
  }

  /**
   * Get deductions pending approval
   * @param {Object} db MongoDB database connection
   * @param {Object} options Query options
   * @returns {Array} Array of pending deductions
   */
  static async getPendingApprovals(db, options = {}) {
    const { limit = 50, skip = 0 } = options;
    
    return await db.collection('payroll_employee_deductions')
      .aggregate([
        { $match: { status: 'pending_approval' } },
        {
          $lookup: {
            from: 'payroll_deduction_types',
            localField: 'deduction_type_id',
            foreignField: '_id',
            as: 'deduction_type'
          }
        },
        { $unwind: '$deduction_type' },
        {
          $lookup: {
            from: 'users',
            localField: 'employee_id',
            foreignField: '_id',
            as: 'employee'
          }
        },
        { $unwind: '$employee' },
        {
          $lookup: {
            from: 'users',
            localField: 'created_by',
            foreignField: '_id',
            as: 'created_by_user'
          }
        },
        { $unwind: '$created_by_user' },
        { $sort: { created_at: -1 } },
        { $skip: skip },
        { $limit: limit }
      ])
      .toArray();
  }
}

module.exports = PayrollEmployeeDeduction;