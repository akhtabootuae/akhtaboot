const { ObjectId } = require('mongodb');

/**
 * Branch Model
 * Provides structure and methods for Branch data
 */
class Branch {
  /**
   * Get MongoDB schema validation for branches collection
   * @returns {Object} MongoDB schema validation object
   */
  static getSchema() {
    return {
      validator: {
        $jsonSchema: {
          bsonType: "object",
          required: ["branch_name", "branch_code", "created_at", "updated_at"],
          properties: {
            branch_name: {
              bsonType: "string",
              description: "Name of the branch"
            },
            branch_code: {
              bsonType: "string",
              description: "Unique code for the branch"
            },
            branch_name_ar: {
              bsonType: "string",
              description: "Arabic name for the branch"
            },
            location: {
              bsonType: "string",
              description: "Physical location of the branch"
            },
            trn: {
              bsonType: "string",
              description: "Tax Registration Number of the branch"
            },
            created_at: {
              bsonType: "date",
              description: "When the branch was created"
            },
            updated_at: {
              bsonType: "date",
              description: "When the branch was last updated"
            }
          }
        }
      }
    };
  }

  /**
   * Create a new branch
   * @param {Object} db MongoDB database connection
   * @param {Object} branchData Branch data to create
   * @returns {Object} Created branch
   */
  static async create(db, branchData) {
    const timestamp = new Date();
    
    const newBranch = {
      ...branchData,
      created_at: timestamp,
      updated_at: timestamp
    };
    
    const result = await db.collection('branches').insertOne(newBranch);
    return { ...newBranch, _id: result.insertedId };
  }

  /**
   * Get all branches
   * @param {Object} db MongoDB database connection
   * @returns {Array} Array of branches
   */
  static async getAll(db) {
    return await db.collection('branches').find().toArray();
  }

  /**
   * Get branch by ID
   * @param {Object} db MongoDB database connection
   * @param {string} id Branch ID
   * @returns {Object} Branch document
   */
  static async getById(db, id) {
    return await db.collection('branches').findOne({ _id: new ObjectId(id) });
  }

  /**
   * Get branch by code
   * @param {Object} db MongoDB database connection
   * @param {string} branchCode Branch code
   * @returns {Object} Branch document
   */
  static async getByCode(db, branchCode) {
    return await db.collection('branches').findOne({ branch_code: branchCode });
  }

  /**
   * Get branch by Arabic name
   * @param {Object} db MongoDB database connection
   * @param {string} branchNameAr Arabic branch name
   * @returns {Object} Branch document
   */
  static async getByArabicName(db, branchNameAr) {
    return await db.collection('branches').findOne({ branch_name_ar: branchNameAr });
  }

  /**
   * Update branch by ID
   * @param {Object} db MongoDB database connection
   * @param {string} id Branch ID
   * @param {Object} updateData Update data
   * @returns {Object} Update result
   */
  static async updateById(db, id, updateData) {
    const timestamp = new Date();
    
    const result = await db.collection('branches').updateOne(
      { _id: new ObjectId(id) },
      { 
        $set: {
          ...updateData,
          updated_at: timestamp
        } 
      }
    );
    
    return result;
  }

  /**
   * Delete branch by ID
   * @param {Object} db MongoDB database connection
   * @param {string} id Branch ID
   * @returns {Object} Delete result
   */
  static async deleteById(db, id) {
    return await db.collection('branches').deleteOne({ _id: new ObjectId(id) });
  }
}

module.exports = Branch;
