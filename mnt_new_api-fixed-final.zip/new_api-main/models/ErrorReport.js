const { ObjectId } = require('mongodb');

class ErrorReport {
  static getSchema() {
    return {
      validator: {
        $jsonSchema: {
          bsonType: "object",
          required: [
            "workOrderId", "partIndex", "stageIndex", "reportedStageId",
            "problematicStageIndex", "reportingTechnicianId", "problematicTechnicianId",
            "reportType", "issueDescription", "imageUrl", "timestamp", "status"
          ],
          properties: {
            workOrderId: {
              bsonType: "objectId",
              description: "Reference to main work order"
            },
            partIndex: {
              bsonType: "int",
              description: "Index of part in work order parts array"
            },
            stageIndex: {
              bsonType: "int",
              description: "Index of stage where error was reported"
            },
            reportedStageId: {
              bsonType: "objectId",
              description: "Stage ID where error was reported"
            },
            problematicStageIndex: {
              bsonType: "int",
              description: "Index of stage that has the issue"
            },
            reportingTechnicianId: {
              bsonType: "objectId",
              description: "Technician who reported the issue"
            },
            problematicTechnicianId: {
              bsonType: "objectId",
              description: "Technician who worked on problematic stage"
            },
            reportType: {
              bsonType: "string",
              enum: ["forward", "revert"],
              description: "forward: reported when starting next stage, revert: reported for current/past stage"
            },
            issueDescription: {
              bsonType: "string",
              minLength: 10,
              description: "Detailed description of the issue"
            },
            imageUrl: {
              bsonType: "string",
              description: "URL of uploaded evidence image"
            },
            imageS3Key: {
              bsonType: "string",
              description: "S3 key for the uploaded image"
            },
            imageName: {
              bsonType: "string",
              description: "Original name of the uploaded image"
            },
            imageSize: {
              bsonType: "int",
              description: "Size of the uploaded image in bytes"
            },
            timestamp: {
              bsonType: "date",
              description: "When error was reported"
            },
            status: {
              bsonType: "string",
              enum: ["pending", "acknowledged", "resolved"],
              description: "Current status of error report"
            },
            stagesToRedo: {
              bsonType: "array",
              items: {
                bsonType: "int"
              },
              description: "Array of stage indices that need to be redone"
            },
            // Verification-related fields
            requiresVerification: {
              bsonType: "bool",
              description: "Whether this error report requires verification before resolution"
            },
            verifyingTechnicianId: {
              bsonType: "objectId",
              description: "Reference to User who is performing the verification"
            },
            verificationStatus: {
              bsonType: "string",
              enum: ["pending", "in_progress", "verified_good", "verified_bad", "admin_verified"],
              description: "Current status of the verification process"
            },
            verificationResult: {
              bsonType: "object",
              description: "Results of the verification process",
              properties: {
                verdict: {
                  bsonType: "string",
                  enum: ["good_standard", "not_good_standard"],
                  description: "Verification verdict on whether work meets standards"
                },
                notes: {
                  bsonType: "string",
                  description: "Additional notes from the verification process"
                },
                verifiedAt: {
                  bsonType: "date",
                  description: "Timestamp when verification was completed"
                },
                verifiedBy: {
                  bsonType: "objectId",
                  description: "Reference to User who completed the verification"
                }
              }
            },
            revertToStageIndex: {
              bsonType: "int",
              description: "Stage index to revert to if verification verdict is 'not_good_standard'"
            },
            adminVerificationReason: {
              bsonType: "string",
              description: "Reason why admin had to perform the verification instead of another technician"
            },
            created_at: {
              bsonType: "date",
              description: "Document creation timestamp"
            },
            updated_at: {
              bsonType: "date",
              description: "Document last update timestamp"
            }
          }
        }
      }
    };
  }

  static async create(db, data) {
    const timestamp = new Date();
    
    // Build error report object with only defined values
    const newErrorReport = {
      workOrderId: data.workOrderId,
      partIndex: data.partIndex,
      stageIndex: data.stageIndex,
      reportedStageId: data.reportedStageId,
      problematicStageIndex: data.problematicStageIndex,
      reportingTechnicianId: data.reportingTechnicianId,
      problematicTechnicianId: data.problematicTechnicianId,
      reportType: data.reportType,
      issueDescription: data.issueDescription,
      imageUrl: data.imageUrl,
      imageS3Key: data.imageS3Key,
      imageName: data.imageName,
      imageSize: data.imageSize,
      timestamp: timestamp,
      status: data.status || 'pending',
      stagesToRedo: data.stagesToRedo || [],
      requiresVerification: data.requiresVerification || false,
      created_at: timestamp,
      updated_at: timestamp
    };

    // Only add optional fields if they have values
    if (data.requiresVerification) {
      newErrorReport.verificationStatus = data.verificationStatus || 'pending';
    }
    
    if (data.verifyingTechnicianId) {
      newErrorReport.verifyingTechnicianId = data.verifyingTechnicianId;
    }
    
    if (data.verificationResult) {
      newErrorReport.verificationResult = data.verificationResult;
    }
    
    if (data.revertToStageIndex !== undefined && data.revertToStageIndex !== null) {
      newErrorReport.revertToStageIndex = data.revertToStageIndex;
    }
    
    if (data.adminVerificationReason) {
      newErrorReport.adminVerificationReason = data.adminVerificationReason;
    }
    
    // Log the data being inserted for debugging
    console.log('Creating error report with data:', JSON.stringify(newErrorReport, null, 2));
    
    try {
      const result = await db.collection('error_reports').insertOne(newErrorReport);
      
      // Update the work order stage with error info
      // Extract integer values from Int32 objects if needed
      const partIndexValue = data.partIndex.value !== undefined ? data.partIndex.value : data.partIndex;
      const stageIndexValue = data.problematicStageIndex.value !== undefined ? data.problematicStageIndex.value : data.problematicStageIndex;
      await this.updateWorkOrderStage(db, data.workOrderId, stageIndexValue, partIndexValue, result.insertedId);
      
      return { ...newErrorReport, _id: result.insertedId };
    } catch (error) {
      console.error('MongoDB insertOne error:', error);
      
      // Log detailed validation error info
      if (error.code === 121) {
        console.error('Validation Error Code:', error.code);
        console.error('Error Message:', error.message);
        if (error.errInfo && error.errInfo.details) {
          console.error('Validation Details:', JSON.stringify(error.errInfo.details, null, 2));
          
          // Log specific field failures
          if (error.errInfo.details.schemaRulesNotSatisfied) {
            error.errInfo.details.schemaRulesNotSatisfied.forEach(rule => {
              console.error(`Failed rule:`, JSON.stringify(rule, null, 2));
            });
          }
        }
      }
      
      throw error;
    }
  }

  static async updateWorkOrderStage(db, workOrderId, stageIndex, partIndex, errorReportId) {
    const updatePath = `parts.${partIndex}.stages.${stageIndex}`;
    
    await db.collection('work_orders').updateOne(
      { _id: new ObjectId(workOrderId) },
      {
        $set: {
          [`${updatePath}.hasIssue`]: true,
          [`${updatePath}.updatedAt`]: new Date()
        },
        $push: {
          [`${updatePath}.errorReportIds`]: errorReportId
        }
      }
    );
  }

  static async getById(db, id) {
    return db.collection('error_reports').findOne({ _id: new ObjectId(id) });
  }

  static async getByWorkOrder(db, workOrderId) {
    return db.collection('error_reports')
      .find({ workOrderId: new ObjectId(workOrderId) })
      .sort({ timestamp: -1 })
      .toArray();
  }

  static async getByTechnician(db, technicianId, type = 'reported') {
    const query = type === 'reported' 
      ? { reportingTechnicianId: new ObjectId(technicianId) }
      : { problematicTechnicianId: new ObjectId(technicianId) };
    
    return db.collection('error_reports')
      .find(query)
      .sort({ timestamp: -1 })
      .toArray();
  }

  static async acknowledge(db, id, acknowledgedBy) {
    const timestamp = new Date();
    const result = await db.collection('error_reports').updateOne(
      { _id: new ObjectId(id) },
      {
        $set: {
          status: 'acknowledged',
          acknowledgedBy: new ObjectId(acknowledgedBy),
          acknowledgedAt: timestamp,
          updated_at: timestamp
        }
      }
    );
    
    return result.modifiedCount > 0;
  }

  static async resolve(db, id, resolvedBy, resolution) {
    const timestamp = new Date();
    const result = await db.collection('error_reports').updateOne(
      { _id: new ObjectId(id) },
      {
        $set: {
          status: 'resolved',
          resolvedBy: new ObjectId(resolvedBy),
          resolution: resolution,
          resolvedAt: timestamp,
          updated_at: timestamp
        }
      }
    );
    
    return result.modifiedCount > 0;
  }

  static async markStagesForRedo(db, workOrderId, partIndex, stageIndices) {
    const workOrder = await db.collection('work_orders').findOne({ _id: new ObjectId(workOrderId) });
    if (!workOrder) throw new Error('Work order not found');

    const updates = {};
    const timestamp = new Date();

    // Mark specified stages as needing redo
    stageIndices.forEach(stageIndex => {
      const stagePath = `parts.${partIndex}.stages.${stageIndex}`;
      updates[`${stagePath}.needsRedo`] = true;
      updates[`${stagePath}.status`] = 'pending';
      updates[`${stagePath}.assignedTo`] = null;
      updates[`${stagePath}.updatedAt`] = timestamp;
      
      // Store original completion time if stage was completed
      const stage = workOrder.parts[partIndex].stages[stageIndex];
      if (stage.status === 'completed' && stage.updatedAt) {
        updates[`${stagePath}.originalCompletionTime`] = stage.updatedAt;
      }
    });

    await db.collection('work_orders').updateOne(
      { _id: new ObjectId(workOrderId) },
      { $set: updates }
    );

    return true;
  }

  static async getErrorSummary(db, workOrderId) {
    const errors = await this.getByWorkOrder(db, workOrderId);
    
    const summary = {
      total: errors.length,
      pending: errors.filter(e => e.status === 'pending').length,
      acknowledged: errors.filter(e => e.status === 'acknowledged').length,
      resolved: errors.filter(e => e.status === 'resolved').length,
      byStage: {},
      byTechnician: {}
    };

    errors.forEach(error => {
      // Count by stage
      const stageKey = `stage_${error.problematicStageIndex}`;
      summary.byStage[stageKey] = (summary.byStage[stageKey] || 0) + 1;

      // Count by technician
      const techKey = error.problematicTechnicianId.toString();
      summary.byTechnician[techKey] = (summary.byTechnician[techKey] || 0) + 1;
    });

    return summary;
  }

  // Verification-related methods
  static async startVerification(db, errorReportId, verifyingTechnicianId) {
    const timestamp = new Date();
    const result = await db.collection('error_reports').updateOne(
      { _id: new ObjectId(errorReportId) },
      {
        $set: {
          verificationStatus: 'in_progress',
          verifyingTechnicianId: new ObjectId(verifyingTechnicianId),
          updated_at: timestamp
        }
      }
    );
    
    return result.modifiedCount > 0;
  }

  static async completeVerification(db, errorReportId, verificationData) {
    const timestamp = new Date();
    const { verdict, notes, verifiedBy, revertToStageIndex } = verificationData;
    
    // Determine verification status based on verdict
    const verificationStatus = verdict === 'good_standard' ? 'verified_good' : 'verified_bad';
    
    const updateData = {
      verificationStatus,
      verificationResult: {
        verdict,
        notes,
        verifiedAt: timestamp,
        verifiedBy: new ObjectId(verifiedBy)
      },
      updated_at: timestamp
    };
    
    // Add revertToStageIndex if verdict is 'not_good_standard'
    if (verdict === 'not_good_standard' && revertToStageIndex !== undefined) {
      updateData.revertToStageIndex = revertToStageIndex;
    }
    
    const result = await db.collection('error_reports').updateOne(
      { _id: new ObjectId(errorReportId) },
      { $set: updateData }
    );
    
    return result.modifiedCount > 0;
  }

  static async adminVerification(db, errorReportId, adminId, reason, verificationData) {
    const timestamp = new Date();
    const { verdict, notes, revertToStageIndex } = verificationData;
    
    const updateData = {
      verificationStatus: 'admin_verified',
      adminVerificationReason: reason,
      verificationResult: {
        verdict,
        notes,
        verifiedAt: timestamp,
        verifiedBy: new ObjectId(adminId)
      },
      updated_at: timestamp
    };
    
    // Add revertToStageIndex if verdict is 'not_good_standard'
    if (verdict === 'not_good_standard' && revertToStageIndex !== undefined) {
      updateData.revertToStageIndex = revertToStageIndex;
    }
    
    const result = await db.collection('error_reports').updateOne(
      { _id: new ObjectId(errorReportId) },
      { $set: updateData }
    );
    
    return result.modifiedCount > 0;
  }

  static async getVerificationPending(db) {
    return db.collection('error_reports')
      .find({ 
        requiresVerification: true,
        verificationStatus: 'pending'
      })
      .sort({ timestamp: -1 })
      .toArray();
  }

  static async getVerificationInProgress(db, technicianId = null) {
    const query = {
      requiresVerification: true,
      verificationStatus: 'in_progress'
    };
    
    if (technicianId) {
      query.verifyingTechnicianId = new ObjectId(technicianId);
    }
    
    return db.collection('error_reports')
      .find(query)
      .sort({ timestamp: -1 })
      .toArray();
  }
}

module.exports = ErrorReport;