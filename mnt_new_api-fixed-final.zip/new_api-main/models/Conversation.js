const { ObjectId } = require('mongodb');

/**
 * Conversation Model
 * Provides structure and methods for Conversation data
 */
class Conversation {
  /**
   * Get MongoDB schema validation for conversations collection
   * @returns {Object} MongoDB schema validation object
   */
  static getSchema() {
    return {
      validator: {
        $jsonSchema: {
          bsonType: "object",
          required: [
            "conversation_type", "participants", "created_by",
            "created_at", "updated_at"
          ],
          properties: {
            // Conversation metadata
            conversation_type: {
              bsonType: "string",
              enum: ["private", "group", "announcement"],
              description: "Type of conversation"
            },
            
            title: { 
              anyOf: [
                { bsonType: "string" },
                { bsonType: "null" }
              ]
            }, // For group conversations and announcements
            description: { 
              anyOf: [
                { bsonType: "string" },
                { bsonType: "null" }
              ]
            },
            
            // Participants array
            participants: {
              bsonType: "array",
              items: {
                bsonType: "object",
                required: ["user_id", "name", "email", "joined_at"],
                properties: {
                  user_id: { bsonType: "objectId" },
                  name: { bsonType: "string" },
                  email: { bsonType: "string" },
                  branch_name: { 
                    anyOf: [
                      { bsonType: "string" },
                      { bsonType: "null" }
                    ]
                  },
                  role_name: { 
                    anyOf: [
                      { bsonType: "string" },
                      { bsonType: "null" }
                    ]
                  },
                  joined_at: { bsonType: "date" },
                  left_at: { bsonType: "date" },
                  is_admin: { bsonType: "bool" } // For group admins
                }
              }
            },
            
            // Creator information
            created_by: { bsonType: "objectId" },
            
            // Last message info (denormalized for performance)
            last_message: {
              bsonType: "object",
              properties: {
                message_id: { bsonType: "objectId" },
                content_preview: { bsonType: "string" }, // First 100 chars, unencrypted
                sender_name: { bsonType: "string" },
                sent_at: { bsonType: "date" }
              }
            },
            
            // Settings
            settings: {
              bsonType: "object",
              properties: {
                is_active: { bsonType: "bool" },
                allow_join: { bsonType: "bool" }, // For groups
                max_participants: { bsonType: "int" }
              }
            },
            
            // Timestamps
            created_at: { bsonType: "date" },
            updated_at: { bsonType: "date" },
            archived_at: { bsonType: "date" },
            expiresAt: { bsonType: "date" } // For announcement expiration
          }
        }
      }
    };
  }

  /**
   * Get indexes for conversations collection
   * @returns {Array} Array of index specifications
   */
  static getIndexes() {
    return [
      { key: { "participants.user_id": 1, updated_at: -1 } }, // For user's conversations
      { key: { conversation_type: 1, created_at: -1 } },      // For filtering by type
      { key: { created_by: 1, created_at: -1 } },             // For creator's conversations
      { key: { "settings.is_active": 1, updated_at: -1 } },   // For active conversations
      { key: { archived_at: 1 } },                             // For filtering archived
      { key: { expiresAt: 1 }, options: { expireAfterSeconds: 0 } } // TTL index for auto-expiry
    ];
  }

  /**
   * Create a new conversation document
   * @param {Object} conversationData Conversation data
   * @returns {Object} Formatted conversation document
   */
  static create(conversationData) {
    const now = new Date();
    
    return {
      conversation_type: conversationData.conversation_type,
      title: conversationData.title || null,
      description: conversationData.description || null,
      participants: conversationData.participants.map(p => ({
        user_id: new ObjectId(p.user_id),
        name: p.name,
        email: p.email,
        branch_name: p.branch_name || null,
        role_name: p.role_name || null,
        joined_at: p.joined_at || now,
        is_admin: p.is_admin || false
      })),
      created_by: new ObjectId(conversationData.created_by),
      settings: {
        is_active: conversationData.settings?.is_active !== false,
        allow_join: conversationData.settings?.allow_join || false,
        max_participants: conversationData.settings?.max_participants || 50
      },
      created_at: now,
      updated_at: now
    };
  }

  /**
   * Create a private conversation between two users
   * @param {Object} user1 First user data
   * @param {Object} user2 Second user data
   * @returns {Object} Formatted private conversation document
   */
  static createPrivate(user1, user2) {
    return this.create({
      conversation_type: 'private',
      participants: [
        {
          user_id: user1._id,
          name: `${user1.first_name} ${user1.last_name}`,
          email: user1.email,
          branch_name: user1.branch?.branch_name,
          role_name: user1.role_name
        },
        {
          user_id: user2._id,
          name: `${user2.first_name} ${user2.last_name}`,
          email: user2.email,
          branch_name: user2.branch?.branch_name,
          role_name: user2.role_name
        }
      ],
      created_by: user1._id,
      settings: {
        is_active: true,
        allow_join: false,
        max_participants: 2
      }
    });
  }

  /**
   * Create an announcement conversation (admin broadcasts)
   * @param {Object} admin Admin user data
   * @param {Array} allUsers Array of all users
   * @param {String} title Announcement title
   * @returns {Object} Formatted announcement conversation document
   */
  static createAnnouncement(admin, allUsers, title, expiresAt) {
    const participants = allUsers.map(user => ({
      user_id: user._id,
      name: `${user.first_name} ${user.last_name}`,
      email: user.email,
      branch_name: user.branch?.branch_name,
      role_name: user.role_name
    }));

    const doc = this.create({
      conversation_type: 'announcement',
      title: title || 'System Announcement',
      participants,
      created_by: admin._id,
      settings: {
        is_active: true,
        allow_join: false,
        max_participants: 1000
      }
    });
    if (expiresAt) doc.expiresAt = expiresAt;
    return doc;
  }

  /**
   * Validate conversation data
   * @param {Object} conversationData Conversation data to validate
   * @returns {Object} Validation result
   */
  static validate(conversationData) {
    const errors = [];

    const validTypes = ['private', 'group', 'announcement'];
    if (!conversationData.conversation_type || !validTypes.includes(conversationData.conversation_type)) {
      errors.push('conversation_type must be one of: ' + validTypes.join(', '));
    }

    if (!conversationData.participants || !Array.isArray(conversationData.participants) || conversationData.participants.length === 0) {
      errors.push('participants array is required and must not be empty');
    }

    if (!conversationData.created_by) {
      errors.push('created_by is required');
    }

    // Type-specific validations
    if (conversationData.conversation_type === 'private' && conversationData.participants?.length !== 2) {
      errors.push('private conversations must have exactly 2 participants');
    }

    if (conversationData.conversation_type === 'group' && !conversationData.title) {
      errors.push('group conversations must have a title');
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }
}

module.exports = Conversation;
