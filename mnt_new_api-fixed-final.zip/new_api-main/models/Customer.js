const { ObjectId } = require('mongodb');

/**
 * Customer Model
 * Provides structure and methods for Customer data
 */
class Customer {
  /**
   * Get MongoDB schema validation for customers collection
   * @returns {Object} MongoDB schema validation object
   */
  static getSchema() {
    return {
      validator: {
        $jsonSchema: {
          bsonType: "object",
          required: [
            "first_name",
            "last_name",
            "vehicles",
            "created_at",
            "updated_at"
          ],
          properties: {
            first_name: {
              bsonType: "string",
              description: "must be a string and is required"
            },
            last_name: {
              bsonType: "string",
              description: "must be a string and is required"
            },
            email: {
              anyOf: [
                { bsonType: "null" },
                { type: "string", minLength: 0, maxLength: 0 },
                { 
                  bsonType: "string", 
                  pattern: "^.+@.+\\..+$",
                  minLength: 1
                }
              ],
              description: "must be a valid email address when provided, or empty/null"
            },
            phone: {
              bsonType: "string",
              description: "must be a string"
            },
            city: {
              bsonType: "string",
              description: "must be a string"
            },
            country: {
              bsonType: "string",
              description: "must be a string"
            },
            branch: {
              bsonType: "object",
              required: ["branch_id", "branch_name"],
              properties: {
                branch_id: { bsonType: "objectId" },
                branch_name: { bsonType: "string" },
                branch_code: { bsonType: "string" },
                location: { bsonType: "string" }
              }
            },
            vehicles: {
              bsonType: "array",
              description: "array of vehicle sub-documents",
              items: {
                bsonType: "object",
                required: ["vin", "make", "model", "year"],
                properties: {
                  vehicle_id: {
                    bsonType: "int",
                    description: "RDBMS ID, must be an integer"
                  },
                  vin: {
                    bsonType: "string",
                    description: "Vehicle Identification Number"
                  },
                  make: {
                    bsonType: "string",
                    description: "Vehicle make"
                  },
                  model: {
                    bsonType: "string",
                    description: "Vehicle model"
                  },
                  year: {
                    bsonType: "int",
                    description: "Manufacture year"
                  },
                  license_plate: {
                    bsonType: "string",
                    description: "License plate number"
                  },
                  color: {
                    bsonType: "string",
                    description: "Vehicle color"
                  },
                  vehicle_type: {
                    bsonType: "string",
                    description: "Type/category of vehicle"
                  },
                  created_at: {
                    bsonType: "date",
                    description: "When the vehicle record was created"
                  },
                  updated_at: {
                    bsonType: "date",
                    description: "When the vehicle record was last updated"
                  }
                }
              }
            },
            created_at: {
              bsonType: "date",
              description: "When the customer record was created"
            },
            updated_at: {
              bsonType: "date",
              description: "When the customer record was last updated"
            }
          }
        }
      }
    };
  }

  /**
   * Create a new customer
   * @param {Object} db MongoDB database connection
   * @param {Object} customerData Customer data to create
   * @returns {Object} Created customer
   */
  static async create(db, customerData) {
    // Add timestamps
    const timestamp = new Date();
    
    const newCustomer = {
      ...customerData,
      created_at: timestamp,
      updated_at: timestamp,
      // Ensure vehicles array exists
      vehicles: customerData.vehicles || []
    };
    
    // Add timestamps and vehicle_id to each vehicle
    if (newCustomer.vehicles.length > 0) {
      newCustomer.vehicles = newCustomer.vehicles.map((vehicle, index) => ({
        ...vehicle,
        vehicle_id: index + 1, // Assign sequential vehicle_ids starting from 1
        created_at: timestamp,
        updated_at: timestamp
      }));
    }
    
    const result = await db.collection('customers').insertOne(newCustomer);
    return { ...newCustomer, _id: result.insertedId };
  }

  /**
   * Get customer by ID
   * @param {Object} db MongoDB database connection
   * @param {string} id Customer ID
   * @returns {Object} Customer document
   */
  static async getById(db, id) {
    return db.collection('customers').findOne({ _id: new ObjectId(id) });
  }

  /**
   * Update customer by ID
   * @param {Object} db MongoDB database connection
   * @param {string} id Customer ID
   * @param {Object} updateData Update data
   * @returns {Object} Update result
   */
  static async updateById(db, id, updateData) {
    const timestamp = new Date();
    
    // Don't allow direct updates to vehicles array
    const { vehicles, ...updates } = updateData;
    
    const result = await db.collection('customers').updateOne(
      { _id: new ObjectId(id) },
      { 
        $set: {
          ...updates,
          updated_at: timestamp
        } 
      }
    );
    
    return result;
  }

  /**
   * Delete customer by ID
   * @param {Object} db MongoDB database connection
   * @param {string} id Customer ID
   * @returns {Object} Delete result
   */
  static async deleteById(db, id) {
    return db.collection('customers').deleteOne({ _id: new ObjectId(id) });
  }
  
  /**
   * Add a vehicle to a customer
   * @param {Object} db MongoDB database connection
   * @param {string} customerId Customer ID
   * @param {Object} vehicleData Vehicle data
   * @returns {Object} Update result
   */
  static async addVehicle(db, customerId, vehicleData) {
    const timestamp = new Date();
    
    // Get the next vehicle_id
    const customer = await Customer.getById(db, customerId);
    const vehicleId = customer.vehicles.length > 0 
      ? Math.max(...customer.vehicles.map(v => v.vehicle_id)) + 1 
      : 1;
    
    const newVehicle = {
      ...vehicleData,
      vehicle_id: vehicleId,
      created_at: timestamp,
      updated_at: timestamp
    };
    
    return db.collection('customers').updateOne(
      { _id: new ObjectId(customerId) },
      { 
        $push: { vehicles: newVehicle },
        $set: { updated_at: timestamp }
      }
    );
  }
  
  /**
   * Update a vehicle in a customer document
   * @param {Object} db MongoDB database connection
   * @param {string} customerId Customer ID
   * @param {number} vehicleId Vehicle ID
   * @param {Object} updateData Vehicle update data
   * @returns {Object} Update result
   */
  static async updateVehicle(db, customerId, vehicleId, updateData) {
    const timestamp = new Date();
    
    // First find the vehicle in the array to get its position
    const customer = await Customer.getById(db, customerId);
    const vehicleIndex = customer.vehicles.findIndex(v => v.vehicle_id === parseInt(vehicleId));
    
    if (vehicleIndex === -1) {
      throw new Error('Vehicle not found');
    }
    
    // Create update object with dot notation for the specific array element
    const updates = {};
    Object.entries(updateData).forEach(([key, value]) => {
      updates[`vehicles.${vehicleIndex}.${key}`] = value;
    });
    
    // Add updated_at timestamps
    updates[`vehicles.${vehicleIndex}.updated_at`] = timestamp;
    updates.updated_at = timestamp;
    
    return db.collection('customers').updateOne(
      { _id: new ObjectId(customerId) },
      { $set: updates }
    );
  }
  
  /**
   * Remove a vehicle from a customer
   * @param {Object} db MongoDB database connection
   * @param {string} customerId Customer ID
   * @param {number} vehicleId Vehicle ID
   * @returns {Object} Update result
   */
  static async removeVehicle(db, customerId, vehicleId) {
    const timestamp = new Date();
    
    return db.collection('customers').updateOne(
      { _id: new ObjectId(customerId) },
      { 
        $pull: { vehicles: { vehicle_id: parseInt(vehicleId) } },
        $set: { updated_at: timestamp }
      }
    );
  }

  /**
   * Update customer branch
   * @param {Object} db MongoDB database connection
   * @param {string} id Customer ID
   * @param {Object} branchData Branch data
   * @returns {Object} Update result
   */
  static async updateBranch(db, id, branchData) {
    const timestamp = new Date();
    
    // Validate branch data
    if (!branchData.branch_id || !branchData.branch_name) {
      throw new Error('Branch ID and branch name are required');
    }
    
    // Convert branch_id to ObjectId if it's a string
    if (typeof branchData.branch_id === 'string') {
      branchData.branch_id = new ObjectId(branchData.branch_id);
    }
    
    return db.collection('customers').updateOne(
      { _id: new ObjectId(id) },
      { 
        $set: {
          branch: branchData,
          updated_at: timestamp
        } 
      }
    );
  }

  /**
   * Get vehicle details by customer ID and vehicle ID
   * @param {Object} db MongoDB database connection
   * @param {string} customerId Customer ID
   * @param {number} vehicleId Vehicle ID
   * @returns {Object} Vehicle details or null if not found
   */
  static async getVehicleDetails(db, customerId, vehicleId) {
    // Ensure customerId is an ObjectId
    const customerObjId = typeof customerId === 'string' 
      ? new ObjectId(customerId) 
      : customerId;
    
    // Find the customer
    const customer = await db.collection('customers').findOne({ _id: customerObjId });
    if (!customer || !customer.vehicles) {
      return null;
    }
    
    // Find the vehicle
    const vehicle = customer.vehicles.find(v => v.vehicle_id === parseInt(vehicleId));
    
    return vehicle || null;
  }
}

module.exports = Customer;
