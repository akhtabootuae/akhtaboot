const { ObjectId } = require('mongodb');

/**
 * PayrollDeductionType Model
 * Provides structure and methods for PayrollDeductionType data
 */
class PayrollDeductionType {
  /**
   * Get MongoDB schema validation for payroll_deduction_types collection
   * @returns {Object} MongoDB schema validation object
   */
  static getSchema() {
    // No validation schema to avoid validation errors
    return {};
  }

  /**
   * Find all deduction types with optional filters
   * @param {Object} db MongoDB database connection
   * @param {Object} filters Filter criteria
   * @returns {Array} Array of deduction types
   */
  static async findAll(db, filters = {}) {
    const query = {};
    if (filters.active !== undefined) query.active = filters.active;
    if (filters.type) query.type = filters.type;
    
    return await db.collection('payroll_deduction_types')
      .find(query)
      .sort({ name: 1 })
      .toArray();
  }

  /**
   * Find deduction type by ID
   * @param {Object} db MongoDB database connection
   * @param {string} id Deduction type ID
   * @returns {Object|null} Deduction type or null
   */
  static async findById(db, id) {
    return await db.collection('payroll_deduction_types')
      .findOne({ _id: new ObjectId(id) });
  }

  /**
   * Create a new deduction type
   * @param {Object} db MongoDB database connection
   * @param {Object} deductionTypeData Deduction type data
   * @returns {Object} Created deduction type
   */
  static async create(db, deductionTypeData) {
    const deductionType = {
      ...deductionTypeData,
      _id: new ObjectId(),
      created_at: new Date(),
      updated_at: new Date()
    };

    const result = await db.collection('payroll_deduction_types').insertOne(deductionType);
    return { ...deductionType, _id: result.insertedId };
  }

  /**
   * Update an existing deduction type
   * @param {Object} db MongoDB database connection
   * @param {string} id Deduction type ID
   * @param {Object} updateData Update data
   * @returns {boolean} Success status
   */
  static async update(db, id, updateData) {
    const updatedData = {
      ...updateData,
      updated_at: new Date()
    };

    const result = await db.collection('payroll_deduction_types').updateOne(
      { _id: new ObjectId(id) },
      { $set: updatedData }
    );

    return result.modifiedCount > 0;
  }

  /**
   * Delete a deduction type (with business rule validation)
   * @param {Object} db MongoDB database connection
   * @param {string} id Deduction type ID
   * @returns {boolean} Success status
   */
  static async delete(db, id) {
    // Check if it's a system type
    const deductionType = await this.findById(db, id);
    if (deductionType?.is_system_type) {
      throw new Error('Cannot delete system deduction types');
    }

    // Check if any active deductions use this type
    const activeDeductions = await db.collection('payroll_employee_deductions')
      .countDocuments({
        deduction_type_id: new ObjectId(id),
        status: 'active'
      });

    if (activeDeductions > 0) {
      throw new Error('Cannot delete deduction type with active deductions');
    }

    const result = await db.collection('payroll_deduction_types').deleteOne({
      _id: new ObjectId(id)
    });

    return result.deletedCount > 0;
  }

  /**
   * Validate deduction type data
   * @param {Object} data Deduction type data to validate
   * @returns {Array} Array of validation errors (empty if valid)
   */
  static validateDeductionType(data) {
    const errors = [];

    if (!data.name || data.name.trim().length === 0) {
      errors.push('Name is required');
    }

    if (data.name && data.name.length > 100) {
      errors.push('Name cannot exceed 100 characters');
    }

    if (!data.type || !['fixed_amount', 'percentage', 'conditional'].includes(data.type)) {
      errors.push('Valid type is required (fixed_amount, percentage, or conditional)');
    }

    if (data.type === 'fixed_amount' && data.default_amount !== null && data.default_amount < 0) {
      errors.push('Default amount must be positive');
    }

    if (data.type === 'percentage' && data.default_percentage !== null && 
        (data.default_percentage < 0 || data.default_percentage > 100)) {
      errors.push('Default percentage must be between 0 and 100');
    }

    if (data.frequency && !['daily', 'weekly', 'monthly', 'per_pay_period', 'one_time'].includes(data.frequency)) {
      errors.push('Invalid frequency specified');
    }

    if (data.max_percentage_of_pay !== null && data.max_percentage_of_pay !== undefined && 
        (data.max_percentage_of_pay < 0 || data.max_percentage_of_pay > 100)) {
      errors.push('Max percentage of pay must be between 0 and 100');
    }

    if (data.description && data.description.length > 500) {
      errors.push('Description cannot exceed 500 characters');
    }

    return errors;
  }

  /**
   * Get system deduction types (pre-defined types)
   * @param {Object} db MongoDB database connection
   * @returns {Array} Array of system deduction types
   */
  static async getSystemTypes(db) {
    return await db.collection('payroll_deduction_types')
      .find({ is_system_type: true })
      .sort({ name: 1 })
      .toArray();
  }

  /**
   * Get custom deduction types (user-created types)
   * @param {Object} db MongoDB database connection
   * @returns {Array} Array of custom deduction types
   */
  static async getCustomTypes(db) {
    return await db.collection('payroll_deduction_types')
      .find({ is_system_type: false })
      .sort({ name: 1 })
      .toArray();
  }
}

module.exports = PayrollDeductionType;