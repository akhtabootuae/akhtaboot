const { ObjectId } = require('mongodb');
const { EventEmitter } = require('events');

class Case extends EventEmitter {
  constructor(db) {
    super();
    this.db = db;
    this.collection = db.collection('cases');
  }

  /**
   * Get MongoDB collection validation schema
   * @returns {Object} MongoDB validation schema
   */
  static getSchema() {
    return {
      validator: {
        $jsonSchema: {
          bsonType: "object",
          required: ["title", "description", "status", "priority", "createdBy"],
          properties: {
            _id: {
              bsonType: "objectId"
            },
            title: {
              bsonType: "string",
              minLength: 3,
              maxLength: 200,
              description: "Case title is required and must be 3-200 characters"
            },
            description: {
              bsonType: "string",
              minLength: 10,
              maxLength: 2000,
              description: "Case description is required and must be 10-2000 characters"
            },
            status: {
              bsonType: "string",
              enum: ["open", "in-progress", "pending", "resolved", "closed"],
              description: "Status must be one of: open, in-progress, pending, resolved, closed"
            },
            priority: {
              bsonType: "string",
              enum: ["low", "medium", "high", "urgent"],
              description: "Priority must be one of: low, medium, high, urgent"
            },
            linkedTo: {
              bsonType: "object",
              properties: {
                type: {
                  bsonType: "string",
                  description: "Type of linked entity (e.g., 'customer', 'workorder', 'user', 'invoice')"
                },
                id: {
                  bsonType: "objectId",
                  description: "ObjectId of the linked entity"
                },
                reference: {
                  bsonType: "string",
                  description: "Optional reference identifier or name"
                }
              },
              additionalProperties: false,
              description: "Optional link to another entity"
            },
            createdBy: {
              bsonType: "objectId",
              description: "User who created the case"
            },
            assignedTo: {
              bsonType: "objectId",
              description: "User assigned to handle the case"
            },
            resolvedBy: {
              bsonType: "objectId",
              description: "User who resolved the case"
            },
            notes: {
              bsonType: "array",
              items: {
                bsonType: "object",
                properties: {
                  content: {
                    bsonType: "string",
                    minLength: 1,
                    maxLength: 1000
                  },
                  addedBy: {
                    bsonType: "objectId"
                  },
                  addedAt: {
                    bsonType: "date"
                  }
                },
                required: ["content", "addedBy", "addedAt"],
                additionalProperties: false
              },
              description: "Array of case notes"
            },
            attachments: {
              bsonType: "array",
              items: {
                bsonType: "object",
                properties: {
                  filename: {
                    bsonType: "string"
                  },
                  originalName: {
                    bsonType: "string"
                  },
                  mimetype: {
                    bsonType: "string"
                  },
                  size: {
                    bsonType: "number"
                  },
                  s3Key: {
                    bsonType: "string",
                    description: "S3 object key for secure file storage"
                  },
                  s3Url: {
                    bsonType: "string",
                    description: "S3 object URL (for reference, actual access via signed URLs)"
                  },
                  uploadedBy: {
                    bsonType: "objectId"
                  },
                  uploadedAt: {
                    bsonType: "date"
                  }
                },
                required: ["filename", "originalName", "mimetype", "size", "s3Key", "uploadedBy", "uploadedAt"],
                additionalProperties: false
              },
              description: "Array of case attachments stored in S3"
            },
            tags: {
              bsonType: "array",
              items: {
                bsonType: "string"
              },
              description: "Array of tags for categorization"
            },
            dueDate: {
              bsonType: "date",
              description: "Optional due date for the case"
            },
            resolvedAt: {
              bsonType: "date",
              description: "Timestamp when the case was resolved"
            },
            closedAt: {
              bsonType: "date",
              description: "Timestamp when the case was closed"
            },
            createdAt: {
              bsonType: "date",
              description: "Creation timestamp"
            },
            updatedAt: {
              bsonType: "date",
              description: "Last update timestamp"
            }
          },
          additionalProperties: false
        }
      }
    };
  }

  /**
   * Create a new case
   * @param {Object} caseData Case data
   * @param {Object} user User creating the case
   * @returns {Object} Created case
   */
  async createCase(caseData, user) {
    try {
      const now = new Date();
      
      const newCase = {
        title: caseData.title,
        description: caseData.description,
        status: caseData.status || 'open',
        priority: caseData.priority || 'medium',
        createdBy: new ObjectId(user._id),
        notes: [],
        attachments: [],
        tags: caseData.tags || [],
        createdAt: now,
        updatedAt: now
      };

      // Add optional fields
      if (caseData.linkedTo) {
        newCase.linkedTo = {
          type: caseData.linkedTo.type,
          id: new ObjectId(caseData.linkedTo.id),
          reference: caseData.linkedTo.reference
        };
      }

      if (caseData.assignedTo) {
        newCase.assignedTo = new ObjectId(caseData.assignedTo);
      }

      if (caseData.dueDate) {
        newCase.dueDate = new Date(caseData.dueDate);
      }

      const result = await this.collection.insertOne(newCase);
      const createdCase = await this.collection.findOne({ _id: result.insertedId });

      // Create notifications for all admin users
      await this.notifyAdminsOfNewCase(createdCase, user);

      // Emit event
      this.emit('caseCreated', {
        case: createdCase,
        user: user
      });

      return createdCase;
    } catch (error) {
      console.error('Error creating case:', error);
      throw new Error('Failed to create case');
    }
  }

  /**
   * Create notification for all admin users when a case is created
   * @param {Object} caseData The created case
   * @param {Object} createdBy User who created the case
   * @returns {Promise<void>}
   */
  async notifyAdminsOfNewCase(caseData, createdBy) {
    try {
      // Find all active admin users
      const adminUsers = await this.db.collection('users').find({
        role_name: 'Admin',
        is_active: { $ne: false }
      }).toArray();

      if (adminUsers.length === 0) {
        console.log('No active admin users found to notify');
        return;
      }

      // Create notifications for each admin
      const notifications = adminUsers.map(admin => ({
        type: 'general',
        title: 'New Case Created',
        message: `A new case "${caseData.title}" has been created by ${createdBy.first_name} ${createdBy.last_name}. Priority: ${caseData.priority}.`,
        recipientType: 'admin',
        recipientId: admin._id,
        priority: caseData.priority === 'urgent' ? 'high' : 'medium',
        status: 'unread',
        metadata: {
          caseId: caseData._id.toString(),
          caseTitle: caseData.title,
          casePriority: caseData.priority,
          caseStatus: caseData.status,
          createdBy: createdBy.first_name + ' ' + createdBy.last_name,
          createdByUserId: createdBy._id.toString()
        },
        createdAt: new Date(),
        expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // 30 days from now
      }));

      // Insert all notifications at once
      if (notifications.length > 0) {
        await this.db.collection('notifications').insertMany(notifications);
        console.log(`Created ${notifications.length} notifications for admin users about new case: ${caseData.title}`);
      }
    } catch (error) {
      console.error('Error creating admin notifications for new case:', error);
      // Don't throw error to avoid disrupting case creation
    }
  }

  /**
   * Get case by ID
   * @param {string} caseId Case ID
   * @returns {Object|null} Case object or null
   */
  async getCaseById(caseId) {
    try {
      if (!ObjectId.isValid(caseId)) {
        throw new Error('Invalid case ID format');
      }

      const caseDoc = await this.collection.findOne({ _id: new ObjectId(caseId) });
      return caseDoc;
    } catch (error) {
      console.error('Error getting case by ID:', error);
      throw new Error('Failed to retrieve case');
    }
  }

  /**
   * Get cases with filtering and pagination
   * @param {Object} filters Filters for cases
   * @param {Object} options Pagination and sorting options
   * @returns {Object} Cases with pagination info
   */
  async getCases(filters = {}, options = {}) {
    try {
      const {
        page = 1,
        limit = 10,
        sortBy = 'createdAt',
        sortOrder = -1,
        populate = false
      } = options;

      const skip = (page - 1) * limit;
      
      // Build query
      const query = {};
      
      if (filters.status) {
        query.status = filters.status;
      }
      
      if (filters.priority) {
        query.priority = filters.priority;
      }
      
      if (filters.createdBy) {
        query.createdBy = new ObjectId(filters.createdBy);
      }
      
      if (filters.assignedTo) {
        query.assignedTo = new ObjectId(filters.assignedTo);
      }
      
      if (filters.linkedTo) {
        if (filters.linkedTo.type) {
          query['linkedTo.type'] = filters.linkedTo.type;
        }
        if (filters.linkedTo.id) {
          query['linkedTo.id'] = new ObjectId(filters.linkedTo.id);
        }
      }
      
      if (filters.tags && filters.tags.length > 0) {
        query.tags = { $in: filters.tags };
      }

      if (filters.search) {
        query.$or = [
          { title: { $regex: filters.search, $options: 'i' } },
          { description: { $regex: filters.search, $options: 'i' } }
        ];
      }

      // Date range filters
      if (filters.dateFrom || filters.dateTo) {
        query.createdAt = {};
        if (filters.dateFrom) {
          query.createdAt.$gte = new Date(filters.dateFrom);
        }
        if (filters.dateTo) {
          query.createdAt.$lte = new Date(filters.dateTo);
        }
      }

      const sortOptions = {};
      sortOptions[sortBy] = sortOrder;

      const [cases, totalCount] = await Promise.all([
        this.collection
          .find(query)
          .sort(sortOptions)
          .skip(skip)
          .limit(limit)
          .toArray(),
        this.collection.countDocuments(query)
      ]);

      const totalPages = Math.ceil(totalCount / limit);

      return {
        cases,
        pagination: {
          currentPage: page,
          totalPages,
          totalCount,
          hasNextPage: page < totalPages,
          hasPrevPage: page > 1
        }
      };
    } catch (error) {
      console.error('Error getting cases:', error);
      throw new Error('Failed to retrieve cases');
    }
  }

  /**
   * Update case
   * @param {string} caseId Case ID
   * @param {Object} updateData Update data
   * @param {Object} user User making the update
   * @returns {Object} Updated case
   */
  async updateCase(caseId, updateData, user) {
    try {
      if (!ObjectId.isValid(caseId)) {
        throw new Error('Invalid case ID format');
      }

      const existingCase = await this.getCaseById(caseId);
      if (!existingCase) {
        throw new Error('Case not found');
      }

      const now = new Date();
      const update = {
        updatedAt: now
      };

      // Update allowed fields
      const allowedFields = ['title', 'description', 'priority', 'assignedTo', 'tags', 'dueDate'];
      allowedFields.forEach(field => {
        if (updateData[field] !== undefined) {
          if (field === 'assignedTo' && updateData[field]) {
            update[field] = new ObjectId(updateData[field]);
          } else if (field === 'dueDate' && updateData[field]) {
            update[field] = new Date(updateData[field]);
          } else {
            update[field] = updateData[field];
          }
        }
      });

      // Handle status updates with special logic
      if (updateData.status && updateData.status !== existingCase.status) {
        update.status = updateData.status;
        
        if (updateData.status === 'resolved') {
          update.resolvedAt = now;
          update.resolvedBy = new ObjectId(user._id);
        } else if (updateData.status === 'closed') {
          update.closedAt = now;
          if (!existingCase.resolvedAt) {
            update.resolvedAt = now;
            update.resolvedBy = new ObjectId(user._id);
          }
        }
      }

      const result = await this.collection.updateOne(
        { _id: new ObjectId(caseId) },
        { $set: update }
      );

      if (result.matchedCount === 0) {
        throw new Error('Case not found');
      }

      const updatedCase = await this.getCaseById(caseId);

      // Emit event
      this.emit('caseUpdated', {
        case: updatedCase,
        previousCase: existingCase,
        user: user,
        changes: update
      });

      return updatedCase;
    } catch (error) {
      console.error('Error updating case:', error);
      throw new Error('Failed to update case');
    }
  }

  /**
   * Add note to case
   * @param {string} caseId Case ID
   * @param {string} content Note content
   * @param {Object} user User adding the note
   * @returns {Object} Updated case
   */
  async addNote(caseId, content, user) {
    try {
      if (!ObjectId.isValid(caseId)) {
        throw new Error('Invalid case ID format');
      }

      const note = {
        content: content.trim(),
        addedBy: new ObjectId(user._id),
        addedAt: new Date()
      };

      const result = await this.collection.updateOne(
        { _id: new ObjectId(caseId) },
        {
          $push: { notes: note },
          $set: { updatedAt: new Date() }
        }
      );

      if (result.matchedCount === 0) {
        throw new Error('Case not found');
      }

      const updatedCase = await this.getCaseById(caseId);

      // Emit event
      this.emit('noteAdded', {
        case: updatedCase,
        note: note,
        user: user
      });

      return updatedCase;
    } catch (error) {
      console.error('Error adding note:', error);
      throw new Error('Failed to add note');
    }
  }

  /**
   * Delete case
   * @param {string} caseId Case ID
   * @param {Object} user User deleting the case
   * @returns {boolean} Success status
   */
  async deleteCase(caseId, user) {
    try {
      if (!ObjectId.isValid(caseId)) {
        throw new Error('Invalid case ID format');
      }

      const existingCase = await this.getCaseById(caseId);
      if (!existingCase) {
        throw new Error('Case not found');
      }

      const result = await this.collection.deleteOne({ _id: new ObjectId(caseId) });

      if (result.deletedCount === 0) {
        throw new Error('Case not found');
      }

      // Emit event
      this.emit('caseDeleted', {
        case: existingCase,
        user: user
      });

      return true;
    } catch (error) {
      console.error('Error deleting case:', error);
      throw new Error('Failed to delete case');
    }
  }

  /**
   * Get case statistics
   * @param {Object} filters Optional filters
   * @returns {Object} Case statistics
   */
  async getCaseStats(filters = {}) {
    try {
      const matchStage = {};
      
      if (filters.dateFrom || filters.dateTo) {
        matchStage.createdAt = {};
        if (filters.dateFrom) {
          matchStage.createdAt.$gte = new Date(filters.dateFrom);
        }
        if (filters.dateTo) {
          matchStage.createdAt.$lte = new Date(filters.dateTo);
        }
      }

      if (filters.assignedTo) {
        matchStage.assignedTo = new ObjectId(filters.assignedTo);
      }

      const pipeline = [
        ...(Object.keys(matchStage).length > 0 ? [{ $match: matchStage }] : []),
        {
          $group: {
            _id: null,
            totalCases: { $sum: 1 },
            openCases: {
              $sum: { $cond: [{ $eq: ['$status', 'open'] }, 1, 0] }
            },
            inProgressCases: {
              $sum: { $cond: [{ $eq: ['$status', 'in-progress'] }, 1, 0] }
            },
            pendingCases: {
              $sum: { $cond: [{ $eq: ['$status', 'pending'] }, 1, 0] }
            },
            resolvedCases: {
              $sum: { $cond: [{ $eq: ['$status', 'resolved'] }, 1, 0] }
            },
            closedCases: {
              $sum: { $cond: [{ $eq: ['$status', 'closed'] }, 1, 0] }
            },
            urgentCases: {
              $sum: { $cond: [{ $eq: ['$priority', 'urgent'] }, 1, 0] }
            },
            highPriorityCases: {
              $sum: { $cond: [{ $eq: ['$priority', 'high'] }, 1, 0] }
            }
          }
        }
      ];

      const result = await this.collection.aggregate(pipeline).toArray();
      
      return result[0] || {
        totalCases: 0,
        openCases: 0,
        inProgressCases: 0,
        pendingCases: 0,
        resolvedCases: 0,
        closedCases: 0,
        urgentCases: 0,
        highPriorityCases: 0
      };
    } catch (error) {
      console.error('Error getting case stats:', error);
      throw new Error('Failed to retrieve case statistics');
    }
  }
}

module.exports = Case;
