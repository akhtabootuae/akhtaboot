const { ObjectId } = require('mongodb');

/**
 * ExpenseLog Model
 * Provides structure and methods for Expense audit logging
 */
class ExpenseLog {
  /**
   * Get MongoDB schema validation for expense_logs collection
   * @returns {Object} MongoDB schema validation object
   */
  static getSchema() {
    return {
      validator: {
        $jsonSchema: {
          bsonType: "object",
          required: [
            "user_id", "action", "entity_type", "timestamp"
          ],
          additionalProperties: true,
          properties: {
            user_id: { 
              bsonType: "objectId",
              description: "User who performed the action - must be a valid ObjectId and is required"
            },
            user_email: {
              bsonType: ["string", "null"],
              description: "Email of the user who performed the action"
            },
            action: {
              bsonType: "string",
              enum: [
                "create_expense", "update_expense", "delete_expense", "submit_expense",
                "approve_expense", "reject_expense", "add_receipt", "remove_receipt",
                "view_expense", "view_expenses", "export_expenses", "view_expense_analytics",
                "generate_expense_pdf", "update_invoice_image"
              ],
              description: "Action performed - must be one of the specified values and is required"
            },
            entity_type: {
              bsonType: "string",
              enum: ["expense", "expense_system", "expense_analytics"],
              description: "Type of entity affected - must be one of the specified values and is required"
            },
            entity_id: {
              bsonType: ["objectId", "string", "null"],
              description: "ID of the entity affected (can be ObjectId, string, or null)"
            },
            timestamp: {
              bsonType: "date",
              description: "When the action occurred - must be a valid date and is required"
            },
            ip_address: {
              bsonType: ["string", "null"],
              description: "IP address from which the action was performed"
            },
            user_agent: {
              bsonType: ["string", "null"],
              description: "User agent string from the request"
            },
            details: {
              bsonType: "object",
              description: "Additional details about the action",
              additionalProperties: true,
              properties: {
                old_values: {
                  bsonType: ["object", "null"],
                  description: "Previous values before the change"
                },
                new_values: {
                  bsonType: ["object", "null"],
                  description: "New values after the change"
                },
                request_method: {
                  bsonType: ["string", "null"],
                  description: "HTTP method used (GET, POST, PUT, DELETE)"
                },
                endpoint: {
                  bsonType: ["string", "null"],
                  description: "API endpoint that was called"
                },
                error_message: {
                  bsonType: ["string", "null"],
                  description: "Error message if action failed"
                },
                success: {
                  bsonType: "bool",
                  description: "Whether the action was successful"
                },
                expense_number: {
                  bsonType: ["string", "null"],
                  description: "Expense number for reference"
                },
                amount: {
                  bsonType: ["number", "null"],
                  description: "Expense amount if relevant"
                },
                expense_type: {
                  bsonType: ["string", "null"],
                  description: "Type of expense if relevant"
                }
              }
            },
            session_id: {
              bsonType: ["string", "null"],
              description: "Session ID for tracking user sessions"
            },
            severity: {
              bsonType: "string",
              enum: ["low", "medium", "high", "critical"],
              description: "Severity level of the audit event"
            },
            category: {
              bsonType: "string",
              enum: ["authentication", "authorization", "data_access", "data_modification", "system", "document_generation"],
              description: "Category of the audit event"
            },
            branch_id: {
              bsonType: ["objectId", "null"],
              description: "Branch ID associated with the expense action"
            }
          }
        }
      }
    };
  }

  /**
   * Create a new expense log entry
   * @param {Object} db MongoDB database connection
   * @param {Object} logData Expense log data
   * @returns {Object} Insert result
   */
  static async createLogEntry(db, logData) {
    // Log entry creation for monitoring
    console.log('Creating expense log entry:', logData.action, 'on', logData.entity_type);

    // Comprehensive validation before any processing
    const preValidationErrors = this.validateLogData(logData);
    if (preValidationErrors.length > 0) {
      console.error('Pre-validation failed:', preValidationErrors);
      throw new Error(`Expense log data pre-validation failed: ${preValidationErrors.join(', ')}`);
    }

    // Handle case where user_id might be undefined or invalid
    if (!logData.user_id) {
      const error = new Error('user_id is required for expense log entry');
      console.error('Missing user_id:', error.message);
      throw error;
    }
    
    // Ensure user_id is an ObjectId with comprehensive validation
    let userId;
    try {
      if (logData.user_id instanceof ObjectId) {
        userId = logData.user_id;
      } else if (typeof logData.user_id === 'string') {
        if (logData.user_id.length !== 24) {
          throw new Error(`Invalid ObjectId string length: ${logData.user_id.length}, expected 24`);
        }
        if (!/^[0-9a-fA-F]{24}$/.test(logData.user_id)) {
          throw new Error(`Invalid ObjectId string format: ${logData.user_id}`);
        }
        userId = new ObjectId(logData.user_id);
      } else {
        throw new Error(`user_id must be ObjectId or valid ObjectId string, got ${typeof logData.user_id}: ${logData.user_id}`);
      }
    } catch (error) {
      console.error('user_id validation failed:', {
        originalUserId: logData.user_id,
        type: typeof logData.user_id,
        error: error.message
      });
      throw new Error(`Invalid user_id format: ${error.message}`);
    }

    // Handle entity_id with proper validation
    let entityId = null;
    if (logData.entity_id) {
      if (logData.entity_id instanceof ObjectId) {
        entityId = logData.entity_id;
      } else if (typeof logData.entity_id === 'string') {
        if (logData.entity_id.length === 24 && /^[0-9a-fA-F]{24}$/.test(logData.entity_id)) {
          try {
            entityId = new ObjectId(logData.entity_id);
          } catch (entityError) {
            // Keep as string if ObjectId conversion fails
            console.warn('Entity ID kept as string due to conversion error:', entityError.message);
            entityId = logData.entity_id;
          }
        } else {
          // Keep non-ObjectId strings as strings
          entityId = logData.entity_id;
        }
      } else {
        console.warn('Unexpected entity_id type:', typeof logData.entity_id);
        entityId = logData.entity_id;
      }
    }

    // Handle branch_id validation
    let branchId = null;
    if (logData.branch_id) {
      if (logData.branch_id instanceof ObjectId) {
        branchId = logData.branch_id;
      } else if (typeof logData.branch_id === 'string') {
        if (logData.branch_id.length === 24 && /^[0-9a-fA-F]{24}$/.test(logData.branch_id)) {
          try {
            branchId = new ObjectId(logData.branch_id);
          } catch (branchError) {
            console.warn('Branch ID kept as string due to conversion error:', branchError.message);
            branchId = logData.branch_id;
          }
        } else {
          branchId = logData.branch_id;
        }
      } else {
        branchId = logData.branch_id;
      }
    }
    
    const logEntry = {
      user_id: userId,
      user_email: logData.user_email || 'unknown',
      action: logData.action,
      entity_type: logData.entity_type,
      entity_id: entityId,
      timestamp: new Date(),
      ip_address: logData.ip_address || 'unknown',
      user_agent: logData.user_agent || 'unknown',
      details: logData.details || {},
      severity: logData.severity || 'low',
      category: logData.category || 'data_access',
      branch_id: branchId
    };

    // Only add session_id if it's a non-empty string
    if (logData.session_id && typeof logData.session_id === 'string') {
      logEntry.session_id = logData.session_id;
    }

    // Log final validation check
    console.log('Validating expense log entry before insertion');

    // Final validation against schema before inserting
    const finalValidationErrors = this.validateLogData(logEntry);
    if (finalValidationErrors.length > 0) {
      console.error('Final validation failed:', finalValidationErrors);
      throw new Error(`Expense log data final validation failed: ${finalValidationErrors.join(', ')}`);
    }

    try {
      const result = await db.collection('expense_logs').insertOne(logEntry);
      console.log('✅ Expense log entry created successfully with ID:', result.insertedId);
      return result;
    } catch (insertError) {
      console.error('❌ MongoDB expense log insertion failed:', insertError.message);
      
      // If we have detailed validation errors, log them for debugging
      if (insertError.errInfo?.details?.schemaRulesNotSatisfied) {
        console.error('Schema validation errors:', 
          JSON.stringify(insertError.errInfo.details.schemaRulesNotSatisfied, null, 2)
        );
      }
      
      throw insertError;
    }
  }

  /**
   * Find expense logs with filters
   * @param {Object} db MongoDB database connection
   * @param {Object} filters Filter criteria
   * @param {Object} options Query options (limit, skip, sort)
   * @returns {Array} Array of expense log entries
   */
  static async findExpenseLogs(db, filters = {}, options = {}) {
    const { limit = 50, skip = 0, sort = { timestamp: -1 } } = options;
    
    const query = {};
    
    // Add filters
    if (filters.user_id) {
      query.user_id = new ObjectId(filters.user_id);
    }
    
    if (filters.action) {
      query.action = filters.action;
    }
    
    if (filters.entity_type) {
      query.entity_type = filters.entity_type;
    }
    
    if (filters.entity_id) {
      query.entity_id = typeof filters.entity_id === 'string' ? 
        filters.entity_id : new ObjectId(filters.entity_id);
    }

    if (filters.branch_id) {
      query.branch_id = new ObjectId(filters.branch_id);
    }
    
    if (filters.start_date || filters.end_date) {
      query.timestamp = {};
      if (filters.start_date) {
        query.timestamp.$gte = new Date(filters.start_date);
      }
      if (filters.end_date) {
        query.timestamp.$lte = new Date(filters.end_date);
      }
    }
    
    if (filters.severity) {
      query.severity = filters.severity;
    }
    
    if (filters.category) {
      query.category = filters.category;
    }

    return await db.collection('expense_logs')
      .find(query)
      .sort(sort)
      .limit(limit)
      .skip(skip)
      .toArray();
  }

  /**
   * Count expense logs with filters
   * @param {Object} db MongoDB database connection
   * @param {Object} filters Filter criteria
   * @returns {Number} Count of matching expense log entries
   */
  static async countExpenseLogs(db, filters = {}) {
    const query = {};
    
    // Add filters (same logic as findExpenseLogs)
    if (filters.user_id) {
      query.user_id = new ObjectId(filters.user_id);
    }
    
    if (filters.action) {
      query.action = filters.action;
    }
    
    if (filters.entity_type) {
      query.entity_type = filters.entity_type;
    }
    
    if (filters.entity_id) {
      query.entity_id = typeof filters.entity_id === 'string' ? 
        filters.entity_id : new ObjectId(filters.entity_id);
    }

    if (filters.branch_id) {
      query.branch_id = new ObjectId(filters.branch_id);
    }
    
    if (filters.start_date || filters.end_date) {
      query.timestamp = {};
      if (filters.start_date) {
        query.timestamp.$gte = new Date(filters.start_date);
      }
      if (filters.end_date) {
        query.timestamp.$lte = new Date(filters.end_date);
      }
    }
    
    if (filters.severity) {
      query.severity = filters.severity;
    }
    
    if (filters.category) {
      query.category = filters.category;
    }

    return await db.collection('expense_logs').countDocuments(query);
  }

  /**
   * Find expense logs for a specific expense
   * @param {Object} db MongoDB database connection
   * @param {ObjectId} expenseId Expense ObjectId
   * @param {Object} options Query options (limit, skip, sort)
   * @returns {Array} Array of expense log entries for the expense
   */
  static async findExpenseLogsByExpenseId(db, expenseId, options = {}) {
    const { limit = 20, skip = 0, sort = { timestamp: -1 } } = options;
    
    return await db.collection('expense_logs')
      .find({ 
        entity_id: new ObjectId(expenseId),
        entity_type: 'expense'
      })
      .sort(sort)
      .limit(limit)
      .skip(skip)
      .toArray();
  }

  /**
   * Find recent expense activity
   * @param {Object} db MongoDB database connection
   * @param {Number} hours Number of hours to look back (default 24)
   * @param {Number} limit Maximum number of entries to return
   * @returns {Array} Array of recent expense log entries
   */
  static async findRecentActivity(db, hours = 24, limit = 100) {
    const startDate = new Date(Date.now() - (hours * 60 * 60 * 1000));
    
    return await db.collection('expense_logs')
      .find({ 
        timestamp: { $gte: startDate }
      })
      .sort({ timestamp: -1 })
      .limit(limit)
      .toArray();
  }

  /**
   * Get expense log statistics
   * @param {Object} db MongoDB database connection
   * @param {Date} startDate Start date for statistics
   * @param {Date} endDate End date for statistics
   * @returns {Object} Expense log statistics
   */
  static async getExpenseLogStatistics(db, startDate, endDate) {
    const pipeline = [
      {
        $match: {
          timestamp: {
            $gte: new Date(startDate),
            $lte: new Date(endDate)
          }
        }
      },
      {
        $group: {
          _id: null,
          total_actions: { $sum: 1 },
          unique_users: { $addToSet: "$user_id" },
          actions_by_type: {
            $push: "$action"
          },
          severity_counts: {
            $push: "$severity"
          }
        }
      },
      {
        $project: {
          total_actions: 1,
          unique_user_count: { $size: "$unique_users" },
          actions_by_type: 1,
          severity_counts: 1
        }
      }
    ];

    const result = await db.collection('expense_logs').aggregate(pipeline).toArray();
    return result[0] || {
      total_actions: 0,
      unique_user_count: 0,
      actions_by_type: [],
      severity_counts: []
    };
  }

  /**
   * Delete old expense logs (for data retention)
   * @param {Object} db MongoDB database connection
   * @param {Date} beforeDate Delete logs before this date
   * @returns {Object} Delete result
   */
  static async deleteOldLogs(db, beforeDate) {
    return await db.collection('expense_logs').deleteMany({
      timestamp: { $lt: new Date(beforeDate) }
    });
  }

  /**
   * Validate expense log data
   * @param {Object} logData Expense log data to validate
   * @returns {Array} Array of validation errors (empty if valid)
   */
  static validateLogData(logData) {
    const errors = [];

    if (!logData.user_id) {
      errors.push('User ID is required');
    }

    if (!logData.action) {
      errors.push('Action is required');
    }

    if (!logData.entity_type) {
      errors.push('Entity type is required');
    }

    const validActions = [
      'create_expense', 'update_expense', 'delete_expense', 'submit_expense',
      'approve_expense', 'reject_expense', 'add_receipt', 'remove_receipt',
      'view_expense', 'view_expenses', 'export_expenses', 'view_expense_analytics',
      'generate_expense_pdf', 'update_invoice_image'
    ];
    if (logData.action && !validActions.includes(logData.action)) {
      errors.push(`Action must be one of: ${validActions.join(', ')}`);
    }

    const validEntityTypes = ['expense', 'expense_system', 'expense_analytics'];
    if (logData.entity_type && !validEntityTypes.includes(logData.entity_type)) {
      errors.push(`Entity type must be one of: ${validEntityTypes.join(', ')}`);
    }

    const validCategories = ['authentication', 'authorization', 'data_access', 'data_modification', 'system', 'document_generation'];
    if (logData.category && !validCategories.includes(logData.category)) {
      errors.push(`Category must be one of: ${validCategories.join(', ')}`);
    }

    return errors;
  }

  /**
   * Get expense log summary for a specific user
   * @param {Object} db MongoDB database connection
   * @param {ObjectId} userId User ObjectId
   * @param {Number} days Number of days to look back
   * @returns {Object} User activity summary
   */
  static async getUserActivitySummary(db, userId, days = 30) {
    const startDate = new Date(Date.now() - (days * 24 * 60 * 60 * 1000));
    
    const pipeline = [
      {
        $match: {
          user_id: new ObjectId(userId),
          timestamp: { $gte: startDate }
        }
      },
      {
        $group: {
          _id: "$action",
          count: { $sum: 1 },
          last_action: { $max: "$timestamp" }
        }
      },
      {
        $sort: { count: -1 }
      }
    ];
    
    const actionSummary = await db.collection('expense_logs').aggregate(pipeline).toArray();
    
    // Get total actions
    const totalActions = await db.collection('expense_logs').countDocuments({
      user_id: new ObjectId(userId),
      timestamp: { $gte: startDate }
    });
    
    return {
      user_id: userId,
      period_days: days,
      total_actions: totalActions,
      actions_breakdown: actionSummary
    };
  }

  /**
   * Get most active users in expense system
   * @param {Object} db MongoDB database connection
   * @param {Number} days Number of days to look back
   * @param {Number} limit Maximum number of users to return
   * @returns {Array} Array of most active users
   */
  static async getMostActiveUsers(db, days = 30, limit = 10) {
    const startDate = new Date(Date.now() - (days * 24 * 60 * 60 * 1000));
    
    const pipeline = [
      {
        $match: {
          timestamp: { $gte: startDate }
        }
      },
      {
        $group: {
          _id: "$user_id",
          user_email: { $first: "$user_email" },
          action_count: { $sum: 1 },
          unique_actions: { $addToSet: "$action" },
          last_activity: { $max: "$timestamp" }
        }
      },
      {
        $project: {
          user_id: "$_id",
          user_email: 1,
          action_count: 1,
          unique_action_count: { $size: "$unique_actions" },
          unique_actions: 1,
          last_activity: 1
        }
      },
      {
        $sort: { action_count: -1 }
      },
      {
        $limit: limit
      }
    ];
    
    return await db.collection('expense_logs').aggregate(pipeline).toArray();
  }

  /**
   * Get expense activity timeline for a specific expense
   * @param {Object} db MongoDB database connection
   * @param {ObjectId} expenseId Expense ObjectId
   * @returns {Array} Timeline of actions on the expense
   */
  static async getExpenseActivityTimeline(db, expenseId) {
    const pipeline = [
      {
        $match: {
          entity_id: new ObjectId(expenseId),
          entity_type: 'expense'
        }
      },
      {
        $lookup: {
          from: 'users',
          localField: 'user_id',
          foreignField: '_id',
          as: 'user_info'
        }
      },
      {
        $addFields: {
          user_name: {
            $concat: [
              { $arrayElemAt: ["$user_info.first_name", 0] },
              " ",
              { $arrayElemAt: ["$user_info.last_name", 0] }
            ]
          }
        }
      },
      {
        $project: {
          timestamp: 1,
          action: 1,
          user_email: 1,
          user_name: 1,
          severity: 1,
          details: 1,
          ip_address: 1
        }
      },
      {
        $sort: { timestamp: 1 }
      }
    ];
    
    return await db.collection('expense_logs').aggregate(pipeline).toArray();
  }

  /**
   * Get system-wide expense activity trends
   * @param {Object} db MongoDB database connection
   * @param {Number} days Number of days to analyze
   * @returns {Object} Activity trends data
   */
  static async getActivityTrends(db, days = 30) {
    const startDate = new Date(Date.now() - (days * 24 * 60 * 60 * 1000));
    
    // Daily activity trend
    const dailyTrend = await db.collection('expense_logs').aggregate([
      {
        $match: {
          timestamp: { $gte: startDate }
        }
      },
      {
        $group: {
          _id: {
            $dateToString: { format: "%Y-%m-%d", date: "$timestamp" }
          },
          total_actions: { $sum: 1 },
          unique_users: { $addToSet: "$user_id" },
          actions_by_type: { $push: "$action" }
        }
      },
      {
        $project: {
          date: "$_id",
          total_actions: 1,
          unique_user_count: { $size: "$unique_users" }
        }
      },
      {
        $sort: { date: 1 }
      }
    ]).toArray();
    
    // Hourly pattern (average activity by hour)
    const hourlyPattern = await db.collection('expense_logs').aggregate([
      {
        $match: {
          timestamp: { $gte: startDate }
        }
      },
      {
        $group: {
          _id: { $hour: "$timestamp" },
          avg_actions: { $sum: 1 }
        }
      },
      {
        $project: {
          hour: "$_id",
          avg_actions: { $divide: ["$avg_actions", days] }
        }
      },
      {
        $sort: { hour: 1 }
      }
    ]).toArray();
    
    return {
      period_days: days,
      daily_trend: dailyTrend,
      hourly_pattern: hourlyPattern
    };
  }

  /**
   * Search expense logs with text search
   * @param {Object} db MongoDB database connection
   * @param {String} searchTerm Search term
   * @param {Object} filters Additional filters
   * @param {Object} options Query options
   * @returns {Array} Array of matching expense log entries
   */
  static async searchExpenseLogs(db, searchTerm, filters = {}, options = {}) {
    const { limit = 50, skip = 0, sort = { timestamp: -1 } } = options;
    
    const query = {
      $or: [
        { user_email: { $regex: searchTerm, $options: 'i' } },
        { action: { $regex: searchTerm, $options: 'i' } },
        { 'details.expense_number': { $regex: searchTerm, $options: 'i' } },
        { 'details.endpoint': { $regex: searchTerm, $options: 'i' } },
        { ip_address: { $regex: searchTerm, $options: 'i' } }
      ]
    };
    
    // Add additional filters
    if (filters.user_id) {
      query.user_id = new ObjectId(filters.user_id);
    }
    
    if (filters.action) {
      query.action = filters.action;
    }
    
    if (filters.start_date || filters.end_date) {
      query.timestamp = {};
      if (filters.start_date) {
        query.timestamp.$gte = new Date(filters.start_date);
      }
      if (filters.end_date) {
        query.timestamp.$lte = new Date(filters.end_date);
      }
    }
    
    return await db.collection('expense_logs')
      .find(query)
      .sort(sort)
      .limit(limit)
      .skip(skip)
      .toArray();
  }
}

module.exports = ExpenseLog;