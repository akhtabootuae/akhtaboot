const { MongoClient } = require('mongodb');

async function checkCollectionSchema() {
  let client;
  
  try {
    // Connect to MongoDB
    const uri = process.env.MONGO_URI || 'mongodb://localhost:27017/GMS_DB';
    client = new MongoClient(uri);
    await client.connect();
    
    const db = client.db();
    console.log('Connected to MongoDB');
    
    // Get collection information
    console.log('\n=== Collection Information ===');
    const collections = await db.listCollections({ name: 'payroll_audit_log' }).toArray();
    
    if (collections.length === 0) {
      console.log('❌ payroll_audit_log collection does not exist');
      return;
    }
    
    const collection = collections[0];
    console.log('✅ Collection exists');
    
    // Show collection options
    console.log('\n=== Collection Options ===');
    console.log(JSON.stringify(collection.options, null, 2));
    
    // Show validator if it exists
    if (collection.options && collection.options.validator) {
      console.log('\n=== Validator Schema ===');
      const validator = collection.options.validator;
      console.log(JSON.stringify(validator, null, 2));
      
      // Show specific requirements
      if (validator.$jsonSchema) {
        console.log('\n=== Schema Requirements ===');
        console.log('Required fields:', validator.$jsonSchema.required);
        
        if (validator.$jsonSchema.properties) {
          console.log('\n=== Field Properties ===');
          Object.keys(validator.$jsonSchema.properties).forEach(field => {
            const prop = validator.$jsonSchema.properties[field];
            console.log(`${field}:`, {
              type: prop.bsonType,
              enum: prop.enum,
              required: validator.$jsonSchema.required?.includes(field)
            });
          });
        }
      }
    } else {
      console.log('❌ No validator found on collection');
    }
    
    // Try to get validation errors by testing a known bad document
    console.log('\n=== Testing Validation ===');
    try {
      await db.collection('payroll_audit_log').insertOne({
        invalid_field: 'test'
      });
      console.log('❌ Validation test failed - bad document was accepted');
    } catch (validationError) {
      console.log('✅ Validation is working - bad document was rejected');
      if (validationError.errInfo?.details?.schemaRulesNotSatisfied) {
        console.log('Sample validation error details:');
        console.log(JSON.stringify(validationError.errInfo.details.schemaRulesNotSatisfied, null, 2));
      }
    }
    
  } catch (error) {
    console.error('Error:', error);
  } finally {
    if (client) {
      await client.close();
      console.log('\nDisconnected from MongoDB');
    }
  }
}

// Run the check
checkCollectionSchema().catch(console.error);