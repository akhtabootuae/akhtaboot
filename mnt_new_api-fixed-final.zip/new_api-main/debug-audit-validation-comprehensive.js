const { MongoClient, ObjectId } = require('mongodb');
const PayrollAuditLog = require('./models/PayrollAuditLog');

async function debugAuditValidation() {
  let client;
  
  try {
    // Connect to MongoDB using environment variable or default
    const uri = process.env.MONGO_URI || 'mongodb://localhost:27017/GMS_DB';
    client = new MongoClient(uri);
    await client.connect();
    
    const db = client.db();
    console.log('Connected to MongoDB');
    
    // Test 1: Test exact scenario that was failing
    console.log('\n=== Test 1: Exact Failing Scenario ===');
    try {
      const failingData = {
        user_id: new ObjectId('507f1f77bcf86cd799439011'), // Valid ObjectId
        user_email: 'test@example.com',
        action: 'update_rate',
        entity_type: 'payroll_rate',
        entity_id: '683a145823ca00ab8e4dc96c', // String ObjectId from error
        ip_address: '::1',
        user_agent: 'PostmanRuntime/7.26.8',
        details: {
          request_method: 'PUT',
          endpoint: '/api/payroll/employees/683a145823ca00ab8e4dc96c/rate',
          success: true
        },
        severity: 'low',
        category: 'data_modification'
      };
      
      console.log('Input data:', JSON.stringify(failingData, null, 2));
      const result = await PayrollAuditLog.createAuditEntry(db, failingData);
      console.log('✓ Test 1 passed - audit entry created with ID:', result.insertedId);
    } catch (error) {
      console.error('✗ Test 1 failed:', error.message);
      if (error.errInfo) {
        console.error('MongoDB validation details:', JSON.stringify(error.errInfo, null, 2));
      }
    }
    
    // Test 2: Test with undefined user_id (should fail gracefully)
    console.log('\n=== Test 2: Undefined user_id ===');
    try {
      const undefinedUserData = {
        user_id: undefined,
        action: 'update_rate',
        entity_type: 'payroll_rate'
      };
      
      await PayrollAuditLog.createAuditEntry(db, undefinedUserData);
      console.log('✗ Test 2 unexpectedly passed (should have failed)');
    } catch (error) {
      console.log('✓ Test 2 correctly failed:', error.message);
    }
    
    // Test 3: Test with null user_id
    console.log('\n=== Test 3: Null user_id ===');
    try {
      const nullUserData = {
        user_id: null,
        action: 'update_rate',
        entity_type: 'payroll_rate'
      };
      
      await PayrollAuditLog.createAuditEntry(db, nullUserData);
      console.log('✗ Test 3 unexpectedly passed (should have failed)');
    } catch (error) {
      console.log('✓ Test 3 correctly failed:', error.message);
    }
    
    // Test 4: Test with invalid ObjectId string
    console.log('\n=== Test 4: Invalid ObjectId string ===');
    try {
      const invalidIdData = {
        user_id: 'invalid_objectid',
        action: 'update_rate',
        entity_type: 'payroll_rate'
      };
      
      await PayrollAuditLog.createAuditEntry(db, invalidIdData);
      console.log('✗ Test 4 unexpectedly passed (should have failed)');
    } catch (error) {
      console.log('✓ Test 4 correctly failed:', error.message);
    }
    
    // Test 5: Test with number as user_id
    console.log('\n=== Test 5: Number as user_id ===');
    try {
      const numberUserData = {
        user_id: 12345,
        action: 'update_rate',
        entity_type: 'payroll_rate'
      };
      
      await PayrollAuditLog.createAuditEntry(db, numberUserData);
      console.log('✗ Test 5 unexpectedly passed (should have failed)');
    } catch (error) {
      console.log('✓ Test 5 correctly failed:', error.message);
    }
    
    // Test 6: Test direct MongoDB insertion to verify schema
    console.log('\n=== Test 6: Direct MongoDB insertion ===');
    try {
      const directEntry = {
        user_id: new ObjectId(),
        user_email: 'direct@example.com',
        action: 'view_payroll',
        entity_type: 'payroll_system',
        entity_id: null,
        timestamp: new Date(),
        ip_address: '127.0.0.1',
        user_agent: 'Direct Test',
        details: {},
        session_id: null,
        severity: 'low',
        category: 'data_access'
      };
      
      const result = await db.collection('payroll_audit_log').insertOne(directEntry);
      console.log('✓ Test 6 passed - direct insertion ID:', result.insertedId);
    } catch (error) {
      console.error('✗ Test 6 failed:', error.message);
      if (error.errInfo) {
        console.error('MongoDB validation details:', JSON.stringify(error.errInfo, null, 2));
      }
    }
    
    // Test 7: Test with invalid action enum
    console.log('\n=== Test 7: Invalid action enum ===');
    try {
      const invalidActionData = {
        user_id: new ObjectId(),
        action: 'invalid_action',
        entity_type: 'payroll_rate'
      };
      
      await PayrollAuditLog.createAuditEntry(db, invalidActionData);
      console.log('✗ Test 7 unexpectedly passed (should have failed)');
    } catch (error) {
      console.log('✓ Test 7 correctly failed:', error.message);
    }
    
    // Test 8: Check collection validation schema
    console.log('\n=== Test 8: Collection Validation Schema ===');
    const collections = await db.listCollections({ name: 'payroll_audit_log' }).toArray();
    if (collections.length > 0) {
      console.log('✓ Collection exists');
      const options = collections[0].options;
      if (options && options.validator) {
        console.log('✓ Collection has validation schema');
        console.log('Required fields:', options.validator.$jsonSchema.required);
        console.log('Action enum values:', options.validator.$jsonSchema.properties.action.enum);
        console.log('Entity type enum values:', options.validator.$jsonSchema.properties.entity_type.enum);
      } else {
        console.log('✗ Collection missing validation schema');
      }
    } else {
      console.log('✗ Collection does not exist');
    }
    
    // Test 9: Test recent audit logs count
    console.log('\n=== Test 9: Recent audit logs ===');
    try {
      const count = await db.collection('payroll_audit_log').countDocuments({});
      console.log(`✓ Total audit logs in collection: ${count}`);
      
      const recentLogs = await db.collection('payroll_audit_log')
        .find({})
        .sort({ timestamp: -1 })
        .limit(3)
        .toArray();
      
      console.log('Recent audit logs:');
      recentLogs.forEach((log, index) => {
        console.log(`  ${index + 1}. ${log.action} on ${log.entity_type} by ${log.user_email} at ${log.timestamp}`);
      });
    } catch (error) {
      console.error('✗ Error checking recent logs:', error.message);
    }
    
  } catch (error) {
    console.error('Fatal error:', error);
  } finally {
    if (client) {
      await client.close();
      console.log('\nDisconnected from MongoDB');
    }
  }
}

// Run the debug script
debugAuditValidation().catch(console.error);