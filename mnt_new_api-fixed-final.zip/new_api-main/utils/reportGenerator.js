const PDFDocument = require('pdfkit');
const fs = require('fs-extra');
const path = require('path');
const moment = require('moment');
const createCsvWriter = require('csv-writer').createObjectCsvWriter;
const xl = require('excel4node');

/**
 * Report Generator Utility
 * Generates reports in various formats (PDF, CSV, Excel)
 */
class ReportGenerator {
  /**
   * Generate PDF report
   */
  static async generatePDF(reportData, outputPath) {
    return new Promise((resolve, reject) => {
      try {
        const doc = new PDFDocument({ margin: 50 });
        const stream = fs.createWriteStream(outputPath);
        doc.pipe(stream);

        // Add header
        this.addPDFHeader(doc, reportData);
        
        // Add content based on report type
        switch (reportData.report_type) {
          case 'payroll_summary':
            this.addPayrollSummaryContent(doc, reportData);
            break;
          case 'employee_earnings':
            this.addEmployeeEarningsContent(doc, reportData);
            break;
          case 'deduction_summary':
            this.addDeductionSummaryContent(doc, reportData);
            break;
          case 'attendance_summary':
            this.addAttendanceSummaryContent(doc, reportData);
            break;
          default:
            this.addGenericContent(doc, reportData);
        }

        // Add footer
        this.addPDFFooter(doc);

        doc.end();

        stream.on('finish', () => {
          resolve({
            file_path: outputPath,
            file_size: fs.statSync(outputPath).size
          });
        });

        stream.on('error', reject);

      } catch (error) {
        reject(error);
      }
    });
  }

  /**
   * Add PDF header
   */
  static addPDFHeader(doc, reportData) {
    // Company logo placeholder
    doc.fontSize(20)
       .text('Payroll Report', 50, 50)
       .fontSize(16)
       .text(reportData.report_name, 50, 80)
       .fontSize(12)
       .text(`Generated: ${moment().format('MMMM DD, YYYY')}`, 50, 110)
       .text(`Report Type: ${reportData.report_type}`, 50, 130);

    // Add line separator
    doc.moveTo(50, 160)
       .lineTo(550, 160)
       .stroke();
  }

  /**
   * Add payroll summary content to PDF
   */
  static addPayrollSummaryContent(doc, reportData) {
    let yPosition = 180;
    const summary = reportData.data.summary;

    doc.fontSize(14)
       .text('Payroll Summary', 50, yPosition);
    
    yPosition += 30;

    // Summary statistics
    const summaryItems = [
      ['Total Employees', summary.total_employees],
      ['Total Gross Pay', `$${summary.total_gross_pay.toLocaleString()}`],
      ['Total Deductions', `$${summary.total_deductions.toLocaleString()}`],
      ['Total Net Pay', `$${summary.total_net_pay.toLocaleString()}`],
      ['Total Hours', summary.total_hours.toLocaleString()],
      ['Average Daily Rate', `$${summary.avg_daily_rate.toFixed(2)}`]
    ];

    summaryItems.forEach(([label, value]) => {
      doc.fontSize(10)
         .text(label, 50, yPosition)
         .text(value, 250, yPosition);
      yPosition += 20;
    });

    yPosition += 20;

    // Employee details table
    if (reportData.data.details && reportData.data.details.length > 0) {
      doc.fontSize(12)
         .text('Employee Details', 50, yPosition);
      
      yPosition += 30;

      // Table headers
      doc.fontSize(9)
         .text('Employee', 50, yPosition)
         .text('Gross Pay', 200, yPosition)
         .text('Deductions', 280, yPosition)
         .text('Net Pay', 360, yPosition)
         .text('Hours', 440, yPosition);

      yPosition += 20;

      // Table data
      reportData.data.details.slice(0, 20).forEach(employee => { // Limit to first 20
        if (yPosition > 700) { // New page if needed
          doc.addPage();
          yPosition = 50;
        }

        doc.fontSize(8)
           .text(employee.employee_name, 50, yPosition)
           .text(`$${employee.gross_pay.toFixed(2)}`, 200, yPosition)
           .text(`$${employee.deductions.toFixed(2)}`, 280, yPosition)
           .text(`$${employee.net_pay.toFixed(2)}`, 360, yPosition)
           .text(employee.hours.toFixed(1), 440, yPosition);

        yPosition += 15;
      });
    }
  }

  /**
   * Add employee earnings content to PDF
   */
  static addEmployeeEarningsContent(doc, reportData) {
    let yPosition = 180;
    const summary = reportData.data.summary;

    doc.fontSize(14)
       .text('Employee Earnings Report', 50, yPosition);
    
    yPosition += 30;

    doc.fontSize(10)
       .text(`Period: ${summary.report_period}`, 50, yPosition)
       .text(`Total Employees: ${summary.total_employees}`, 50, yPosition + 15);

    yPosition += 50;

    // Employee earnings table
    if (reportData.data.details && reportData.data.details.length > 0) {
      // Table headers
      doc.fontSize(9)
         .text('Employee', 50, yPosition)
         .text('Total Gross', 180, yPosition)
         .text('Total Net', 260, yPosition)
         .text('Hours', 340, yPosition)
         .text('Pay Periods', 420, yPosition);

      yPosition += 20;

      reportData.data.details.forEach(employee => {
        if (yPosition > 700) {
          doc.addPage();
          yPosition = 50;
        }

        doc.fontSize(8)
           .text(employee.employee_name, 50, yPosition)
           .text(`$${employee.total_gross_pay.toFixed(2)}`, 180, yPosition)
           .text(`$${employee.total_net_pay.toFixed(2)}`, 260, yPosition)
           .text(employee.total_hours.toFixed(1), 340, yPosition)
           .text(employee.pay_periods_count.toString(), 420, yPosition);

        yPosition += 15;
      });
    }
  }

  /**
   * Add deduction summary content to PDF
   */
  static addDeductionSummaryContent(doc, reportData) {
    let yPosition = 180;
    const summary = reportData.data.summary;

    doc.fontSize(14)
       .text('Deduction Summary Report', 50, yPosition);
    
    yPosition += 30;

    doc.fontSize(10)
       .text(`Period: ${summary.report_period}`, 50, yPosition)
       .text(`Total Deduction Types: ${summary.total_deduction_types}`, 50, yPosition + 15)
       .text(`Total Deduction Amount: $${summary.total_deduction_amount.toLocaleString()}`, 50, yPosition + 30);

    yPosition += 60;

    // Deduction details table
    if (reportData.data.details && reportData.data.details.length > 0) {
      doc.fontSize(9)
         .text('Deduction Type', 50, yPosition)
         .text('Total Amount', 200, yPosition)
         .text('Count', 300, yPosition)
         .text('Average', 380, yPosition);

      yPosition += 20;

      reportData.data.details.forEach(deduction => {
        if (yPosition > 700) {
          doc.addPage();
          yPosition = 50;
        }

        doc.fontSize(8)
           .text(deduction.deduction_name, 50, yPosition)
           .text(`$${deduction.total_amount.toFixed(2)}`, 200, yPosition)
           .text(deduction.count.toString(), 300, yPosition)
           .text(`$${deduction.avg_amount.toFixed(2)}`, 380, yPosition);

        yPosition += 15;
      });
    }
  }

  /**
   * Add attendance summary content to PDF
   */
  static addAttendanceSummaryContent(doc, reportData) {
    let yPosition = 180;
    const summary = reportData.data.summary;

    doc.fontSize(14)
       .text('Attendance Summary Report', 50, yPosition);
    
    yPosition += 30;

    doc.fontSize(10)
       .text(`Period: ${summary.report_period}`, 50, yPosition)
       .text(`Total Employees: ${summary.total_employees}`, 50, yPosition + 15)
       .text(`Total Hours Worked: ${summary.total_hours_worked.toLocaleString()}`, 50, yPosition + 30)
       .text(`Total Days Worked: ${summary.total_days_worked.toLocaleString()}`, 50, yPosition + 45);

    yPosition += 80;

    // Attendance details table
    if (reportData.data.details && reportData.data.details.length > 0) {
      doc.fontSize(9)
         .text('Employee', 50, yPosition)
         .text('Days', 180, yPosition)
         .text('Total Hours', 240, yPosition)
         .text('Regular Hours', 320, yPosition)
         .text('Overtime', 400, yPosition)
         .text('Avg/Day', 480, yPosition);

      yPosition += 20;

      reportData.data.details.forEach(employee => {
        if (yPosition > 700) {
          doc.addPage();
          yPosition = 50;
        }

        doc.fontSize(8)
           .text(employee.employee_name, 50, yPosition)
           .text(employee.days_worked.toString(), 180, yPosition)
           .text(employee.total_hours.toFixed(1), 240, yPosition)
           .text(employee.regular_hours.toFixed(1), 320, yPosition)
           .text(employee.overtime_hours.toFixed(1), 400, yPosition)
           .text(employee.avg_hours_per_day.toFixed(1), 480, yPosition);

        yPosition += 15;
      });
    }
  }

  /**
   * Add generic content to PDF
   */
  static addGenericContent(doc, reportData) {
    let yPosition = 180;

    doc.fontSize(12)
       .text('Report Data', 50, yPosition);
    
    yPosition += 30;

    // Display JSON data in a readable format
    const dataString = JSON.stringify(reportData.data, null, 2);
    doc.fontSize(8)
       .text(dataString, 50, yPosition, { width: 500 });
  }

  /**
   * Add PDF footer
   */
  static addPDFFooter(doc) {
    const pages = doc.bufferedPageRange();
    for (let i = 0; i < pages.count; i++) {
      doc.switchToPage(i);
      
      // Add page number
      doc.fontSize(8)
         .text(`Page ${i + 1} of ${pages.count}`, 
               doc.page.width - 100, 
               doc.page.height - 50);
      
      // Add generation info
      doc.text('Generated by Payroll System', 
               50, 
               doc.page.height - 50);
    }
  }

  /**
   * Generate CSV report
   */
  static async generateCSV(reportData, outputPath) {
    try {
      let records = [];
      let headers = [];

      // Extract data based on report type
      switch (reportData.report_type) {
        case 'payroll_summary':
          headers = [
            { id: 'employee_name', title: 'Employee' },
            { id: 'employee_email', title: 'Email' },
            { id: 'gross_pay', title: 'Gross Pay' },
            { id: 'deductions', title: 'Deductions' },
            { id: 'net_pay', title: 'Net Pay' },
            { id: 'hours', title: 'Hours' },
            { id: 'daily_rate', title: 'Daily Rate' }
          ];
          records = reportData.data.details || [];
          break;

        case 'employee_earnings':
          headers = [
            { id: 'employee_name', title: 'Employee' },
            { id: 'total_gross_pay', title: 'Total Gross Pay' },
            { id: 'total_deductions', title: 'Total Deductions' },
            { id: 'total_net_pay', title: 'Total Net Pay' },
            { id: 'total_hours', title: 'Total Hours' },
            { id: 'pay_periods_count', title: 'Pay Periods' }
          ];
          records = reportData.data.details || [];
          break;

        case 'deduction_summary':
          headers = [
            { id: 'deduction_name', title: 'Deduction Type' },
            { id: 'total_amount', title: 'Total Amount' },
            { id: 'count', title: 'Count' },
            { id: 'avg_amount', title: 'Average Amount' },
            { id: 'min_amount', title: 'Minimum' },
            { id: 'max_amount', title: 'Maximum' }
          ];
          records = reportData.data.details || [];
          break;

        case 'attendance_summary':
          headers = [
            { id: 'employee_name', title: 'Employee' },
            { id: 'days_worked', title: 'Days Worked' },
            { id: 'total_hours', title: 'Total Hours' },
            { id: 'regular_hours', title: 'Regular Hours' },
            { id: 'overtime_hours', title: 'Overtime Hours' },
            { id: 'avg_hours_per_day', title: 'Avg Hours/Day' }
          ];
          records = reportData.data.details || [];
          break;

        default:
          // Generic format
          if (reportData.data.details && reportData.data.details.length > 0) {
            const firstRecord = reportData.data.details[0];
            headers = Object.keys(firstRecord).map(key => ({
              id: key,
              title: key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())
            }));
            records = reportData.data.details;
          }
      }

      if (records.length === 0) {
        throw new Error('No data available for CSV export');
      }

      const csvWriter = createCsvWriter({
        path: outputPath,
        header: headers
      });

      await csvWriter.writeRecords(records);

      return {
        file_path: outputPath,
        file_size: fs.statSync(outputPath).size
      };

    } catch (error) {
      throw new Error(`CSV generation failed: ${error.message}`);
    }
  }

  /**
   * Generate Excel report
   */
  static async generateExcel(reportData, outputPath) {
    try {
      const wb = new xl.Workbook();
      const ws = wb.addWorksheet('Report');

      // Define styles
      const headerStyle = wb.createStyle({
        font: { bold: true, color: '#FFFFFF' },
        fill: { type: 'pattern', patternType: 'solid', fgColor: '#366092' }
      });

      const numberStyle = wb.createStyle({
        numberFormat: '#,##0.00'
      });

      let currentRow = 1;

      // Add report header
      ws.cell(currentRow, 1).string(reportData.report_name).style(headerStyle);
      ws.cell(currentRow, 2).string(`Generated: ${moment().format('MMMM DD, YYYY')}`);
      currentRow += 2;

      // Add summary if available
      if (reportData.data.summary) {
        ws.cell(currentRow, 1).string('Summary').style(headerStyle);
        currentRow++;

        Object.entries(reportData.data.summary).forEach(([key, value]) => {
          ws.cell(currentRow, 1).string(key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()));
          
          if (typeof value === 'number') {
            ws.cell(currentRow, 2).number(value).style(numberStyle);
          } else {
            ws.cell(currentRow, 2).string(value.toString());
          }
          currentRow++;
        });

        currentRow += 2;
      }

      // Add detailed data
      if (reportData.data.details && reportData.data.details.length > 0) {
        ws.cell(currentRow, 1).string('Detailed Data').style(headerStyle);
        currentRow++;

        const details = reportData.data.details;
        const headers = Object.keys(details[0]);

        // Add headers
        headers.forEach((header, index) => {
          ws.cell(currentRow, index + 1)
            .string(header.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()))
            .style(headerStyle);
        });
        currentRow++;

        // Add data rows
        details.forEach(row => {
          headers.forEach((header, index) => {
            const value = row[header];
            
            if (typeof value === 'number') {
              ws.cell(currentRow, index + 1).number(value).style(numberStyle);
            } else {
              ws.cell(currentRow, index + 1).string(value ? value.toString() : '');
            }
          });
          currentRow++;
        });
      }

      // Write file
      await new Promise((resolve, reject) => {
        wb.write(outputPath, (err, stats) => {
          if (err) reject(err);
          else resolve(stats);
        });
      });

      return {
        file_path: outputPath,
        file_size: fs.statSync(outputPath).size
      };

    } catch (error) {
      throw new Error(`Excel generation failed: ${error.message}`);
    }
  }

  /**
   * Generate report in specified format
   */
  static async generate(reportData, format = 'pdf', outputDir = './reports') {
    try {
      // Ensure output directory exists
      await fs.ensureDir(outputDir);

      // Generate filename
      const timestamp = moment().format('YYYYMMDD_HHmmss');
      const filename = `${reportData.report_type}_${timestamp}.${format}`;
      const outputPath = path.join(outputDir, filename);

      let result;

      switch (format.toLowerCase()) {
        case 'pdf':
          result = await this.generatePDF(reportData, outputPath);
          break;
        case 'csv':
          result = await this.generateCSV(reportData, outputPath);
          break;
        case 'xlsx':
        case 'excel':
          result = await this.generateExcel(reportData, outputPath);
          break;
        default:
          throw new Error(`Unsupported format: ${format}`);
      }

      return {
        ...result,
        format: format,
        filename: filename
      };

    } catch (error) {
      throw new Error(`Report generation failed: ${error.message}`);
    }
  }

  /**
   * Clean up old report files
   */
  static async cleanupOldFiles(outputDir = './reports', maxAgeDays = 30) {
    try {
      const files = await fs.readdir(outputDir);
      const cutoffTime = Date.now() - (maxAgeDays * 24 * 60 * 60 * 1000);
      let deletedCount = 0;

      for (const file of files) {
        const filePath = path.join(outputDir, file);
        const stats = await fs.stat(filePath);
        
        if (stats.mtime.getTime() < cutoffTime) {
          await fs.remove(filePath);
          deletedCount++;
        }
      }

      return deletedCount;

    } catch (error) {
      throw new Error(`Cleanup failed: ${error.message}`);
    }
  }
}

module.exports = ReportGenerator;