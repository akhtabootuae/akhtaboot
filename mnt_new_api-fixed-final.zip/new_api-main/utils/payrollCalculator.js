const moment = require('moment');
const { ObjectId } = require('mongodb');

/**
 * Payroll Calculator Utility
 * Provides comprehensive payroll calculation functions
 */
class PayrollCalculator {
  /**
   * Calculate hours worked from time in/out with break duration
   */
  static calculateHoursWorked(timeIn, timeOut, breakDuration = 0) {
    if (!timeIn || !timeOut) {
      throw new Error('Time in and time out are required');
    }

    const start = moment(timeIn);
    const end = moment(timeOut);
    
    if (end.isBefore(start)) {
      throw new Error('Time out cannot be before time in');
    }

    const totalMinutes = end.diff(start, 'minutes');
    const workMinutes = totalMinutes - (breakDuration || 0);
    
    if (workMinutes < 0) {
      throw new Error('Break duration cannot exceed total time worked');
    }

    return parseFloat((workMinutes / 60).toFixed(2));
  }

  /**
   * Calculate basic timesheet totals (hours only, no pay calculation)
   */
  static calculateTimesheetTotals(timeIn, timeOut, breakDuration) {
    // Calculate total hours
    const totalHours = this.calculateHoursWorked(timeIn, timeOut, breakDuration);

    return {
      totalHours
    };
  }

  /**
   * Calculate deduction amount based on method and parameters
   */
  static calculateDeductionAmount(deductionType, employeeDeduction, grossPay) {
    let amount = 0;

    switch (deductionType.calculation_method) {
      case 'fixed':
        amount = employeeDeduction.amount || 0;
        break;
      
      case 'percentage':
        const percentage = employeeDeduction.percentage || deductionType.default_percentage || 0;
        amount = grossPay * (percentage / 100);
        break;
      
      case 'formula':
        // For now, treat as fixed amount
        // TODO: Implement formula parsing
        amount = employeeDeduction.amount || 0;
        break;
      
      default:
        amount = employeeDeduction.amount || 0;
    }

    // Apply min/max limits
    if (deductionType.min_amount && amount < deductionType.min_amount) {
      amount = deductionType.min_amount;
    }
    if (deductionType.max_amount && amount > deductionType.max_amount) {
      amount = deductionType.max_amount;
    }

    // Check remaining balance for loans/advances
    if ((deductionType.type === 'loan' || deductionType.type === 'advance') && 
        employeeDeduction.remaining_balance !== undefined) {
      amount = Math.min(amount, employeeDeduction.remaining_balance);
    }

    return parseFloat(amount.toFixed(2));
  }

  /**
   * Calculate payroll for an employee in a pay period
   */
  static async calculateEmployeePayroll(db, employeeId, payPeriod) {
    // Get employee details
    const employee = await db.collection('users').findOne({
      _id: new ObjectId(employeeId)
    });

    if (!employee || !employee.payroll_info?.payroll_eligible) {
      throw new Error('Employee not found or not eligible for payroll');
    }

    // Get approved timesheets for this period (for attendance tracking only)
    const timesheets = await db.collection('timesheets').find({
      employee_id: new ObjectId(employeeId),
      work_date: {
        $gte: payPeriod.start_date,
        $lte: payPeriod.end_date
      },
      status: 'approved'
    }).toArray();

    const daysWorked = timesheets.length;

    // Get monthly salary
    const monthlySalary = employee.payroll_info.monthly_salary || 0;
    
    // Gross pay is the monthly salary (overtime handled separately as expenses)
    const grossPay = monthlySalary;

    // Get active deductions
    const activeDeductions = await db.collection('payroll_employee_deductions').find({
      employee_id: new ObjectId(employeeId),
      status: 'approved',
      $or: [
        { end_date: null },
        { end_date: { $gte: payPeriod.end_date } }
      ],
      start_date: { $lte: payPeriod.start_date }
    }).toArray();

    // Calculate deductions
    const deductions = [];
    let totalDeductions = 0;

    for (const deduction of activeDeductions) {
      // Get deduction type
      const deductionType = await db.collection('payroll_deduction_types').findOne({
        _id: deduction.deduction_type_id
      });

      if (!deductionType || !deductionType.active) continue;

      const deductionAmount = this.calculateDeductionAmount(deductionType, deduction, grossPay);

      if (deductionAmount > 0) {
        deductions.push({
          deduction_type_id: deduction.deduction_type_id,
          deduction_name: deductionType.name,
          amount: deductionAmount,
          calculation_method: deductionType.calculation_method,
          percentage: deduction.percentage || null,
          notes: deduction.notes || ''
        });

        totalDeductions += deductionAmount;
      }
    }

    // Calculate net pay
    const netPay = grossPay - totalDeductions;

    // Initialize taxes (for future implementation)
    const taxes = {
      federal_tax: 0,
      state_tax: 0,
      social_security: 0,
      medicare: 0,
      other_taxes: 0
    };

    return {
      employee_id: employeeId,
      pay_period_id: payPeriod._id,
      gross_pay: parseFloat(grossPay.toFixed(2)),
      monthly_salary: monthlySalary,
      days_worked: daysWorked,
      deductions: deductions,
      total_deductions: parseFloat(totalDeductions.toFixed(2)),
      net_pay: parseFloat(netPay.toFixed(2)),
      taxes: taxes,
      timesheets: timesheets.map(t => t._id)
    };
  }

  /**
   * Calculate payroll summary for multiple employees
   */
  static calculatePayrollSummary(calculations) {
    const summary = {
      total_employees: calculations.length,
      total_gross_pay: 0,
      total_deductions: 0,
      total_net_pay: 0,
      avg_gross_pay: 0,
      avg_net_pay: 0
    };

    calculations.forEach(calc => {
      summary.total_gross_pay += calc.gross_pay || 0;
      summary.total_deductions += calc.total_deductions || 0;
      summary.total_net_pay += calc.net_pay || 0;
    });

    // Calculate averages
    if (summary.total_employees > 0) {
      summary.avg_gross_pay = summary.total_gross_pay / summary.total_employees;
      summary.avg_net_pay = summary.total_net_pay / summary.total_employees;
    }

    // Round to 2 decimal places
    Object.keys(summary).forEach(key => {
      if (typeof summary[key] === 'number' && key !== 'total_employees') {
        summary[key] = parseFloat(summary[key].toFixed(2));
      }
    });

    return summary;
  }

  /**
   * Calculate year-to-date totals for an employee
   */
  static async calculateYTDTotals(db, employeeId, endDate = new Date()) {
    const startOfYear = new Date(endDate.getFullYear(), 0, 1);
    
    const pipeline = [
      {
        $match: {
          employee_id: new ObjectId(employeeId),
          calculation_date: {
            $gte: startOfYear,
            $lte: endDate
          },
          status: { $in: ['approved', 'paid'] }
        }
      },
      {
        $group: {
          _id: null,
          ytd_gross_pay: { $sum: '$gross_pay' },
          ytd_deductions: { $sum: '$total_deductions' },
          ytd_net_pay: { $sum: '$net_pay' },
          total_pay_periods: { $sum: 1 }
        }
      }
    ];

    const result = await db.collection('payroll_calculations').aggregate(pipeline).toArray();
    
    if (result.length === 0) {
      return {
        ytd_gross_pay: 0,
        ytd_deductions: 0,
        ytd_net_pay: 0,
        total_pay_periods: 0
      };
    }

    const ytd = result[0];
    delete ytd._id;
    
    // Round to 2 decimal places
    Object.keys(ytd).forEach(key => {
      if (typeof ytd[key] === 'number' && key !== 'total_pay_periods') {
        ytd[key] = parseFloat(ytd[key].toFixed(2));
      }
    });

    return ytd;
  }

  /**
   * Validate payroll calculation data
   */
  static validateCalculation(calculation) {
    const errors = [];

    // Check required fields
    if (!calculation.employee_id) errors.push('Employee ID is required');
    if (!calculation.pay_period_id) errors.push('Pay period ID is required');
    if (calculation.gross_pay === undefined) errors.push('Gross pay is required');
    if (calculation.net_pay === undefined) errors.push('Net pay is required');

    // Check numeric values
    if (calculation.gross_pay < 0) errors.push('Gross pay cannot be negative');
    if (calculation.net_pay < 0) errors.push('Net pay cannot be negative');
    if (calculation.total_hours < 0) errors.push('Total hours cannot be negative');
    if (calculation.total_deductions < 0) errors.push('Total deductions cannot be negative');

    // Check logical consistency
    if (calculation.gross_pay > 0 && calculation.total_deductions > calculation.gross_pay) {
      errors.push('Total deductions cannot exceed gross pay');
    }

    if (calculation.net_pay > calculation.gross_pay) {
      errors.push('Net pay cannot exceed gross pay');
    }

    return {
      isValid: errors.length === 0,
      errors: errors
    };
  }

  /**
   * Calculate tax withholdings (placeholder for future implementation)
   */
  static calculateTaxes(grossPay, employeeInfo, taxYear = new Date().getFullYear()) {
    // This is a placeholder for future tax calculation implementation
    // Would integrate with tax tables and employee tax information
    
    return {
      federal_tax: 0,
      state_tax: 0,
      social_security: 0,
      medicare: 0,
      other_taxes: 0,
      total_taxes: 0
    };
  }

  /**
   * Calculate accruals (vacation, sick time, etc.)
   */
  static calculateAccruals(hoursWorked, accrualRates) {
    const accruals = {};
    
    if (accrualRates) {
      Object.keys(accrualRates).forEach(accrualType => {
        const rate = accrualRates[accrualType]; // hours per hour worked
        accruals[accrualType] = parseFloat((hoursWorked * rate).toFixed(2));
      });
    }

    return accruals;
  }

  /**
   * Generate payroll calculation ID
   */
  static generateCalculationId(employeeId, payPeriodId, timestamp = new Date()) {
    const dateStr = moment(timestamp).format('YYYYMMDD');
    const empId = employeeId.toString().slice(-4);
    const periodId = payPeriodId.toString().slice(-4);
    
    return `CALC-${dateStr}-${empId}-${periodId}`;
  }
}

module.exports = PayrollCalculator;