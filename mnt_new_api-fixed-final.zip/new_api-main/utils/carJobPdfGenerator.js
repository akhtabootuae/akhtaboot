const PDFDocument = require('pdfkit');
const { ObjectId } = require('mongodb');
const fs = require('fs-extra');
const path = require('path');
const sharp = require('sharp');
const Invoice = require('../models/Invoice');
const fontPathArabic = path.join(__dirname, '../fonts/Cairo-Regular.ttf');

/**
 * Detects if text contains Arabic characters
 * @param {string} text - Text to check
 * @returns {boolean} - True if text contains Arabic characters
 */
const hasArabicText = (text) => {
  if (!text || typeof text !== 'string') return false;
  // Arabic Unicode range: 0x0600-0x06FF, 0x0750-0x077F, 0x08A0-0x08FF, 0xFB50-0xFDFF, 0xFE70-0xFEFF
  const arabicRegex = /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/;
  return arabicRegex.test(text);
};

/**
 * Smart text rendering that automatically chooses the appropriate font based on text content
 * @param {Object} doc - PDFKit document instance
 * @param {string} text - Text to render
 * @param {number} x - X coordinate
 * @param {number} y - Y coordinate
 * @param {Object} options - Text rendering options
 * @returns {Object} - PDFKit document instance for chaining
 */
const renderSmartText = (doc, text, x, y, options = {}) => {
  if (!text || typeof text !== 'string') {
    text = '';
  }
  
  const isArabic = hasArabicText(text);
  
  if (isArabic) {
    doc.font('ArabicFont');
    // For Arabic text, adjust positioning and ensure RTL features are enabled
    const arabicOptions = {
      ...options,
      features: ['rtl']
    };
    
    // If no specific alignment is provided, use right alignment for Arabic
    if (!arabicOptions.align) {
      arabicOptions.align = 'right';
      // If width is not specified, calculate a reasonable width for right alignment
      if (!arabicOptions.width) {
        arabicOptions.width = 200; // Default width for Arabic text
      }
    }
    
    return doc.text(text, x, y, arabicOptions);
  } else {
    doc.font('Helvetica');
    return doc.text(text, x, y, options);
  }
};

/**
 * Prepares an image for use with PDFKit by converting it to PNG format
 * @param {string} imagePath - Path to the image file
 * @returns {Promise<Buffer>} - PNG image buffer
 */
const prepareImageForPDF = async (imagePath) => {
  try {
    return await sharp(imagePath)
      .png()
      .toBuffer();
  } catch (error) {
    console.error(`Error converting image ${imagePath}:`, error);
    throw error;
  }
};

/**
 * Fetch service routes data for a car job
 * @param {Object} db - MongoDB database connection
 * @param {string} invoiceId - The ID of the invoice
 * @returns {Object} Service routes data
 */
const getServiceRoutesForCarJob = async (db, invoiceId) => {
  try {
    const invoice = await Invoice.getById(db, invoiceId);
    
    if (!invoice || !invoice.work_order_id) {
      return { serviceRoutes: [], summary: { totalParts: 0, totalServices: 0 } };
    }

    // Get the work order
    const workOrder = await db.collection('work_orders').findOne({ _id: new ObjectId(invoice.work_order_id) });
    
    if (!workOrder) {
      return { serviceRoutes: [], summary: { totalParts: 0, totalServices: 0 } };
    }

    // Build service routes data
    const serviceRoutes = [];
    const cancelledServices = [];

    for (const part of workOrder.parts) {
      // Get variation (service) details
      const variation = await db.collection('variations').findOne({ _id: part.variationId });
      
      if (variation) {
        // Get stage details for this part
        const stageDetails = [];
        
        for (const stage of part.stages) {
          const stageInfo = await db.collection('stages').findOne({ _id: stage.stageId });
          if (stageInfo) {
            stageDetails.push({
              stageId: stage.stageId,
              stageName: stageInfo.name,
              stageDescription: stageInfo.description,
              stageOrder: stageInfo.order,
              status: stage.status
            });
          }
        }

        // Sort stages by order
        stageDetails.sort((a, b) => a.stageOrder - b.stageOrder);

        serviceRoutes.push({
          partName: part.partName,
          partStatus: part.status,
          service: {
            code: variation.code,
            description: variation.description,
            defaultLaborHours: variation.defaultLaborHours
          },
          stages: stageDetails
        });
      }
    }

    // Process cancelled parts if they exist
    if (workOrder.cancelledParts && workOrder.cancelledParts.length > 0) {
      for (const cancelledPart of workOrder.cancelledParts) {
        cancelledServices.push({
          partName: cancelledPart.partName,
          partStatus: 'cancelled',
          reason: cancelledPart.reason,
          cancelledBy: cancelledPart.cancelledBy,
          cancelledAt: cancelledPart.cancelledAt
        });
      }
    }

    return {
      serviceRoutes,
      cancelledServices,
      summary: {
        totalParts: serviceRoutes.length,
        totalServices: [...new Set(serviceRoutes.map(sr => sr.service.code))].length,
        totalCancelledParts: cancelledServices.length
      }
    };
  } catch (error) {
    console.error('Error fetching service routes:', error);
    return { serviceRoutes: [], summary: { totalParts: 0, totalServices: 0 } };
  }
};

/**
 * Generate a car job PDF from the database
 * @param {Object} db - MongoDB database connection
 * @param {string} invoiceId - The ID of the invoice to generate PDF for
 * @param {Object} response - Express response object to pipe the PDF to
 */
const generateCarJobPDFFromDB = async (db, invoiceId, response, isQuotation = false) => {
  try {
    // Get combined invoice data with customer and vehicle details
    const data = await Invoice.getInvoiceDataForPDF(db, invoiceId);
    
    // Get service routes data
    const serviceRoutesData = await getServiceRoutesForCarJob(db, invoiceId);
    
    // Call the car job PDF generator with the retrieved data
    return generateCarJobPDF(data.invoice, data.customer, data.branch, response, serviceRoutesData, isQuotation);
  } catch (error) {
    console.error('Error generating car job PDF from DB:', error);
    throw error;
  }
};

/**
 * Generate a car job PDF from provided data
 * @param {Object} invoice - The invoice data
 * @param {Object} customer - The customer data
 * @param {Object} branch - The branch data
 * @param {Object} response - Express response object to pipe the PDF to
 * @param {Object} serviceRoutesData - Service routes data (optional)
 */
const generateCarJobPDF = async (invoice, customer, branch, response, serviceRoutesData = null, isQuotation = false) => {
  try {
    // Page tracking variables to prevent blank pages
    let pageCount = 1;
    let lastContentY = 0;
    const maxPages = 2; // Enforce 2-page maximum

    // Debug information
    console.log('Car Job PDF Generation - Processing invoice:', invoice.invoice_number);
    
    // Ensure customer is an object
    if (!customer || typeof customer !== 'object') {
      console.warn('Customer data is missing or not an object, creating empty customer object');
      customer = { name: '', phone: '', email: '', city: '', country: '' };
    }
    
    // Create a PDF document with A4 size and RTL support - reduced margins for more content
    const doc = new PDFDocument({
      margin: 40,
      size: 'A4',
      autoFirstPage: true,
      features: {
        isForceRTL: true
      }
    });

    doc.registerFont('ArabicFont', fontPathArabic);
    
    // Set response headers for PDF download
    response.setHeader('Content-Type', 'application/pdf');
    response.setHeader('Content-Disposition', `attachment; filename=carjob-${invoice.invoice_number}.pdf`);
    
    // Pipe the PDF document to the response
    doc.pipe(response);
    
    // Define margins and constants - reduced for more content
    const margin = 40;
    const pageWidth = doc.page.width - 2 * margin;
    const lineHeight = 18; // Reduced line height
    let currentY = 35;
    
    // Define X positions for labels and values
    const labelXLeft = margin;
    const valueXLeft = margin + 120;
    const labelXRight = doc.page.width - margin - 140;
    
    // Header section with logo on left and company name on right
    const logoPath = path.join(__dirname, '../assets/Final-logo.webp');
    
    // Save initial Y position to return to for company text
    const initialY = currentY;
    
    // Define header area - divided into left (logo) and right (text)
    // Reduced height for space optimization
    const headerHeight = branch ? 100 : 60;
    
    try {
      // Check if the logo exists
      if (fs.existsSync(logoPath)) {
        // Convert WEBP to PNG (in memory) and use it in the document
        const logoBuffer = await prepareImageForPDF(logoPath);
        
        // Position the logo on the left side of the header
        doc.image(logoBuffer, margin, initialY, { width: 100 });
      } else {
        // If logo doesn't exist, leave a space where it would be
        console.log('Logo file not found at:', logoPath);
      }
    } catch (err) {
      console.error('Error processing logo:', err);
      // Continue without the logo if there's an error
    }

    // Calculate text positioning to match the image - move text closer to logo
    const logoWidth = 100;
    
    // Position Arabic company name text - reduce font size and move up significantly
    doc.font('ArabicFont').fontSize(18);
    // Force RTL direction for Arabic text
    doc.text('الاخطبوط الذهبي لصيانة و إصلاح السيارات ذ م م',
             doc.page.width - margin - 350, initialY - 5, {
               align: 'right',
               width: 350,
               features: ['rtl']  // Explicitly set right-to-left for this text
             });

    // Company phone number between Arabic and English names
    doc.font('Helvetica').fontSize(12);
    doc.text('Phone: +971 50 123 4567',
             doc.page.width - margin - 360, initialY + 40, {
               align: 'right',
               width: 350
             });

    // English company name beneath phone number
    doc.fontSize(14);
    doc.text('Al Akhtaboot Althabi Auto.maint & Repair LLC',
             doc.page.width - margin - 360, initialY + 65, {
               align: 'right',
               width: 350
             });

    // Add branch information if available
    if (branch) {
      doc.fontSize(10);

      // Branch name in Arabic (if available)
      if (branch.branch_name_ar) {
        doc.font('ArabicFont');
        doc.text(branch.branch_name_ar,
                 doc.page.width - margin - 360, initialY + 85, {
                   align: 'right',
                   width: 350,
                   features: ['rtl']
                 });
      }

      // Branch name in English
      if (branch.branch_name) {
        doc.font('Helvetica');
        doc.text(branch.branch_name,
                 doc.page.width - margin - 360, initialY + 100, { 
                   align: 'right',
                   width: 350
                 });
      }
      
      // Branch phone number
      if (branch.phone) {
        doc.text(`Phone: ${branch.phone}`, 
                 doc.page.width - margin - 360, initialY + 115, { 
                   align: 'right',
                   width: 350
                 });
      }
    }
    
    // Move current Y position to below the header area
    currentY = initialY + headerHeight;

    // Add "Car Job Order" or "QUOTATION" text centered - reduced font and spacing
    doc.fontSize(14).font('Helvetica-Bold');
    let documentTitle;
    if (isQuotation) {
      documentTitle = 'QUOTATION';
      doc.fillColor('#FF6B35'); // Orange color for quotations
    } else {
      documentTitle = 'Car Job Order';
      doc.fillColor('#000000'); // Black for regular car jobs
    }
    doc.text(documentTitle, 0, currentY, { align: 'center', width: doc.page.width });
    doc.fillColor('#000000'); // Reset to black
    currentY += 20;

    // Draw fields at the top with Arabic labels on the right and English on the left
    doc.fontSize(12).font('Helvetica-Bold');
    
    // Phone Number (رقم الهاتف)
    doc.text('Phone Number', labelXLeft, currentY);
    const phoneText = customer && customer.phone ? customer.phone : '';
    if (hasArabicText(phoneText)) {
      renderSmartText(doc, phoneText, valueXLeft, currentY, { width: 150, align: 'left' });
    } else {
      renderSmartText(doc, phoneText, valueXLeft, currentY);
    }
    doc.font('ArabicFont').text('رقم الهاتف', labelXRight, currentY, { align: 'right', width: 140, features: ['rtl'] });
    doc.font('Helvetica');
    currentY += lineHeight;

    // Name (اسم العميل)
    doc.text('Name', labelXLeft, currentY);
    const customerName = customer && customer.name ? customer.name : '';
    if (hasArabicText(customerName)) {
      renderSmartText(doc, customerName, valueXLeft, currentY, { width: 150, align: 'left' });
    } else {
      renderSmartText(doc, customerName, valueXLeft, currentY);
    }
    doc.font('ArabicFont').text('اسم العميل', labelXRight, currentY, { align: 'right', width: 140, features: ['rtl'] });
    doc.font('Helvetica');
    currentY += lineHeight;

    // Date (التاريخ)
    const invoiceDate = invoice.invoice_date ? new Date(invoice.invoice_date).toLocaleDateString('en-GB') : '';
    doc.text('Date', labelXLeft, currentY);
    doc.text(invoiceDate, valueXLeft, currentY);
    doc.font('ArabicFont').text('التاريخ', labelXRight, currentY, { align: 'right', width: 140, features: ['rtl'] });
    doc.font('Helvetica');
    currentY += lineHeight;

    // Invoice Number (رقم الفاتورة)
    const invoiceNumber = invoice.invoice_number || '';
    doc.text('Invoice Number', labelXLeft, currentY);
    doc.text(invoiceNumber, valueXLeft, currentY);
    doc.font('ArabicFont').text('رقم الفاتورة', labelXRight, currentY, { align: 'right', width: 140, features: ['rtl'] });
    doc.font('Helvetica');
    currentY += lineHeight;

    // Expected Delivery Date (تاريخ التسليم المتوقع)
    if (invoice.expected_delivery_date) {
      doc.text('Expected Delivery', labelXLeft, currentY);
      const deliveryDate = new Date(invoice.expected_delivery_date).toLocaleDateString('en-GB');
      doc.text(deliveryDate, valueXLeft, currentY);
      doc.font('ArabicFont').text('تاريخ التسليم المتوقع', labelXRight, currentY, { align: 'right', width: 140, features: ['rtl'] });
      doc.font('Helvetica');
      currentY += lineHeight;
    }

    // Add minimal space before the table
    currentY += 5;

    // Draw a horizontal line below header info
    doc.moveTo(margin, currentY).lineTo(doc.page.width - margin, currentY).stroke();
    currentY += 5;

    // Service details table for car jobs - matching invoice format
    const sectionLabelsArabic = ['موديل السيارة', 'رقم اللوحة', 'نوع الخدمة', 'النسبة', 'السعر (قبل الضريبة)', 'السعر الإجمالي'];
    const sectionLabelsEnglish = ['Car Model', 'License Plate', 'Service Type', 'Ratio', 'Price (Before VAT)', 'Total Price'];

    // For job orders, show both the base price and total with VAT
    const displayPrice = invoice.price || 0;
    const vatAmount = displayPrice * 0.05; // 5% VAT
    const totalPrice = displayPrice + vatAmount;

    // Separate car model and license plate
    const carModelText = (invoice.car_type && invoice.car_type !== 'undefined') ? invoice.car_type : '';
    const licensePlateText = (invoice.license_plate && invoice.license_plate !== 'undefined') ? invoice.license_plate : '';

    const sectionValues = [
      carModelText,
      licensePlateText,
      invoice.presented_service_type || invoice.service_type || '',
      invoice.ratio ? `${invoice.ratio}%` : '',
      `${displayPrice.toFixed(2)} AED`,
      `${totalPrice.toFixed(2)} AED`
    ];

    // Define table dimensions
    const tableWidth = doc.page.width - 100;
    const tableX = 50;
    const columnWidth = tableWidth / 3;
    const rowHeight = lineHeight * 1.5; // Reduced height for space optimization
    
    // Draw table header with background
    doc.fillColor('#e8e8e8');
    doc.rect(tableX, currentY, tableWidth, rowHeight).fill();
    doc.fillColor('#000000');

    // Draw header borders
    doc.lineWidth(1);
    doc.strokeColor('#333333');
    doc.rect(tableX, currentY, tableWidth, rowHeight).stroke();
    doc.moveTo(tableX + columnWidth, currentY).lineTo(tableX + columnWidth, currentY + rowHeight).stroke();
    doc.moveTo(tableX + (columnWidth * 2), currentY).lineTo(tableX + (columnWidth * 2), currentY + rowHeight).stroke();

    // Draw header text
    doc.fillColor('#000000');
    doc.font('Helvetica-Bold').fontSize(12);
    doc.text('English', tableX + 10, currentY + 7, { width: columnWidth - 20 });
    doc.text('Value', tableX + columnWidth + 10, currentY + 7, { width: columnWidth - 20, align: 'center' });
    doc.font('ArabicFont');
    doc.text('عربي', tableX + (columnWidth * 2) + 10, currentY + 7, {
      align: 'right',
      width: columnWidth - 20,
      features: ['rtl']
    });

    currentY += rowHeight;
    
    // Draw table rows
    for (let i = 0; i < sectionLabelsEnglish.length; i++) {
      // Draw row background (alternating colors)
      doc.fillColor(i % 2 === 0 ? '#ffffff' : '#fafafa');
      doc.rect(tableX, currentY, tableWidth, rowHeight).fill();
      doc.fillColor('#000000');

      // Draw cell borders
      doc.lineWidth(0.5);
      doc.strokeColor('#cccccc');
      doc.rect(tableX, currentY, tableWidth, rowHeight).stroke();
      doc.moveTo(tableX + columnWidth, currentY).lineTo(tableX + columnWidth, currentY + rowHeight).stroke();
      doc.moveTo(tableX + (columnWidth * 2), currentY).lineTo(tableX + (columnWidth * 2), currentY + rowHeight).stroke();
      doc.strokeColor('#000000'); // Reset stroke color

      // Draw row text
      doc.font('Helvetica-Bold').fontSize(11);
      doc.text(sectionLabelsEnglish[i], tableX + 10, currentY + 7, { width: columnWidth - 20 });

      // Use smart text rendering for values that might contain Arabic
      const cellValue = sectionValues[i];
      if (hasArabicText(cellValue)) {
        renderSmartText(doc, cellValue, tableX + columnWidth + 10, currentY + 7, {
          width: columnWidth - 20,
          align: 'left',
          lineBreak: true,
          height: rowHeight - 10
        });
      } else {
        doc.font('Helvetica');
        doc.text(cellValue, tableX + columnWidth + 10, currentY + 7, {
          width: columnWidth - 20,
          lineBreak: true,
          height: rowHeight - 10
        });
      }

      doc.font('ArabicFont').fontSize(11);
      doc.text(sectionLabelsArabic[i], tableX + (columnWidth * 2) + 10, currentY + 7, {
        align: 'right',
        width: columnWidth - 20,
        features: ['rtl']
      });
      
      currentY += rowHeight;
    }
    
    // Draw bottom border for the table
    doc.lineWidth(1);
    doc.strokeColor('#333333');
    doc.moveTo(tableX, currentY).lineTo(tableX + tableWidth, currentY).stroke();
    doc.strokeColor('#000000'); // Reset stroke color

    // Add Service Routes section if available
    if (serviceRoutesData && serviceRoutesData.serviceRoutes && serviceRoutesData.serviceRoutes.length > 0) {
      currentY += 25;

      // Service Details Header
      doc.fontSize(14).font('Helvetica-Bold');
      doc.text('Service Details', tableX, currentY);
      doc.font('ArabicFont');
      doc.text('تفاصيل الخدمات', tableX + tableWidth - 100, currentY, { 
        align: 'right', 
        width: 100,
        features: ['rtl'] 
      });
      currentY += 25;

      // Service Details Table
      const serviceTableWidth = tableWidth;
      const serviceColumnWidths = [
        serviceTableWidth * 0.3,  // Part Name
        serviceTableWidth * 0.4,  // Service
        serviceTableWidth * 0.3   // Notes (expanded to include special requirements)
      ];

      // Service table header
      doc.fillColor('#e8e8e8');
      doc.rect(tableX, currentY, serviceTableWidth, rowHeight).fill();
      doc.fillColor('#000000');
      
      doc.fontSize(10).font('Helvetica-Bold');
      let headerX = tableX;
      doc.text('Part Name', headerX + 5, currentY + 5, { width: serviceColumnWidths[0] - 10 });
      headerX += serviceColumnWidths[0];
      doc.text('Service', headerX + 5, currentY + 5, { width: serviceColumnWidths[1] - 10 });
      headerX += serviceColumnWidths[1];
      doc.text('Notes', headerX + 5, currentY + 5, { width: serviceColumnWidths[2] - 10 });
      doc.fontSize(10);

      // Draw header borders
      doc.lineWidth(0.5);
      doc.rect(tableX, currentY, serviceTableWidth, rowHeight).stroke();
      let borderX = tableX;
      for (let i = 0; i < serviceColumnWidths.length - 1; i++) {
        borderX += serviceColumnWidths[i];
        doc.moveTo(borderX, currentY).lineTo(borderX, currentY + rowHeight).stroke();
      }

      currentY += rowHeight;

      // Service routes data - first draw all part rows
      const startRowY = currentY;
      for (let i = 0; i < serviceRoutesData.serviceRoutes.length; i++) {
        const serviceRoute = serviceRoutesData.serviceRoutes[i];
        
        // Draw row background for Part Name and Service columns only
        doc.fillColor(i % 2 === 0 ? '#ffffff' : '#f9f9f9');
        doc.rect(tableX, currentY, serviceColumnWidths[0] + serviceColumnWidths[1], rowHeight).fill();
        doc.fillColor('#000000');
        
        // Draw service route data
        doc.fontSize(9);
        let dataX = tableX;
        
        // Part Name
        const partName = serviceRoute.partName || '';
        if (hasArabicText(partName)) {
          renderSmartText(doc, partName, dataX + 5, currentY + 5, { 
            width: serviceColumnWidths[0] - 10,
            align: 'left'
          });
        } else {
          doc.font('Helvetica');
          doc.text(partName, dataX + 5, currentY + 5, { width: serviceColumnWidths[0] - 10 });
        }
        dataX += serviceColumnWidths[0];
        
        // Service
        const serviceText = serviceRoute.service ? `${serviceRoute.service.code} - ${serviceRoute.service.description}` : '';
        if (hasArabicText(serviceText)) {
          renderSmartText(doc, serviceText, dataX + 5, currentY + 5, { 
            width: serviceColumnWidths[1] - 10,
            align: 'left'
          });
        } else {
          doc.font('Helvetica');
          doc.text(serviceText, dataX + 5, currentY + 5, { width: serviceColumnWidths[1] - 10 });
        }

        // Draw row borders for Part Name and Service columns only
        doc.lineWidth(0.5);
        doc.rect(tableX, currentY, serviceColumnWidths[0], rowHeight).stroke();
        doc.rect(tableX + serviceColumnWidths[0], currentY, serviceColumnWidths[1], rowHeight).stroke();

        currentY += rowHeight;
      }
      
      // Now draw merged cell for Notes (includes both notes and special requirements)
      const mergedCellHeight = currentY - startRowY;
      const notesX = tableX + serviceColumnWidths[0] + serviceColumnWidths[1];

      // Draw merged Notes cell
      doc.fillColor('#ffffff');
      doc.rect(notesX, startRowY, serviceColumnWidths[2], mergedCellHeight).fill();
      doc.fillColor('#000000');
      doc.rect(notesX, startRowY, serviceColumnWidths[2], mergedCellHeight).stroke();

      // Combine notes and special requirements text
      let combinedNotesText = invoice.notes || '';
      if (invoice.special_requests && invoice.special_requests.trim() !== '') {
        if (combinedNotesText) {
          combinedNotesText += '\n\n' + invoice.special_requests;
        } else {
          combinedNotesText = invoice.special_requests;
        }
      }
      combinedNotesText = combinedNotesText || '-';

      // Draw combined Notes text
      doc.fontSize(9);
      if (hasArabicText(combinedNotesText)) {
        renderSmartText(doc, combinedNotesText, notesX + 5, startRowY + 5, {
          width: serviceColumnWidths[2] - 10,
          height: mergedCellHeight - 10,
          align: 'left'
        });
      } else {
        renderSmartText(doc, combinedNotesText, notesX + 5, startRowY + 5, {
          width: serviceColumnWidths[2] - 10,
          height: mergedCellHeight - 10
        });
      }
      
      // Summary
      currentY += 10;
      doc.fontSize(10).font('Helvetica-Bold');
      const summaryText = `Total Parts: ${serviceRoutesData.summary.totalParts} | Total Services: ${serviceRoutesData.summary.totalServices}`;
      doc.text(summaryText, tableX, currentY);
      currentY += 10;
    }

    // Add Cancelled Services section if available
    if (serviceRoutesData && serviceRoutesData.cancelledServices && serviceRoutesData.cancelledServices.length > 0) {
      currentY += 20;
      
      // Cancelled Services Header
      doc.fontSize(12).font('Helvetica-Bold');
      doc.text('Cancelled Services', tableX, currentY);
      doc.font('ArabicFont');
      doc.text('الخدمات الملغاة', tableX + tableWidth - 100, currentY, { 
        align: 'right', 
        width: 100,
        features: ['rtl'] 
      });
      currentY += 20;

      // Cancelled services table
      const cancelTableWidth = tableWidth;
      const cancelColumnWidths = [
        cancelTableWidth * 0.4, // Part Name
        cancelTableWidth * 0.6  // Reason
      ];

      // Cancelled table header
      doc.fillColor('#ffebee');
      doc.rect(tableX, currentY, cancelTableWidth, rowHeight).fill();
      doc.fillColor('#000000');
      
      doc.fontSize(10).font('Helvetica-Bold');
      doc.text('Part Name', tableX + 5, currentY + 5, { width: cancelColumnWidths[0] - 10 });
      doc.text('Cancellation Reason', tableX + cancelColumnWidths[0] + 5, currentY + 5, { width: cancelColumnWidths[1] - 10 });

      // Draw header borders
      doc.lineWidth(0.5);
      doc.rect(tableX, currentY, cancelTableWidth, rowHeight).stroke();
      doc.moveTo(tableX + cancelColumnWidths[0], currentY).lineTo(tableX + cancelColumnWidths[0], currentY + rowHeight).stroke();

      currentY += rowHeight;

      // Cancelled services data
      for (let i = 0; i < serviceRoutesData.cancelledServices.length; i++) {
        const cancelledService = serviceRoutesData.cancelledServices[i];
        
        // Draw row background
        doc.fillColor(i % 2 === 0 ? '#ffebee' : '#fce4ec');
        doc.rect(tableX, currentY, cancelTableWidth, rowHeight).fill();
        doc.fillColor('#000000');
        
        // Draw cancelled service data
        doc.fontSize(9);
        const cancelledPartName = cancelledService.partName || '';
        if (hasArabicText(cancelledPartName)) {
          renderSmartText(doc, cancelledPartName, tableX + 5, currentY + 5, { 
            width: cancelColumnWidths[0] - 10,
            align: 'left'
          });
        } else {
          doc.font('Helvetica');
          doc.text(cancelledPartName, tableX + 5, currentY + 5, { width: cancelColumnWidths[0] - 10 });
        }
        
        const cancelReason = cancelledService.reason || '';
        if (hasArabicText(cancelReason)) {
          renderSmartText(doc, cancelReason, tableX + cancelColumnWidths[0] + 5, currentY + 5, { 
            width: cancelColumnWidths[1] - 10,
            align: 'left'
          });
        } else {
          doc.font('Helvetica');
          doc.text(cancelReason, tableX + cancelColumnWidths[0] + 5, currentY + 5, { width: cancelColumnWidths[1] - 10 });
        }

        // Draw row borders
        doc.lineWidth(0.5);
        doc.rect(tableX, currentY, cancelTableWidth, rowHeight).stroke();
        doc.moveTo(tableX + cancelColumnWidths[0], currentY).lineTo(tableX + cancelColumnWidths[0], currentY + rowHeight).stroke();

        currentY += rowHeight;
      }
    }

    // Service summary in Arabic - removed to save space since it's redundant
    // This content is already covered in the service table

    // Default notes section removed to save space


    // Special requests section removed - now combined with notes in the service table

    // Only add new page for terms if under 2 page limit and absolutely necessary
    if (currentY > doc.page.height - 200 && pageCount < maxPages) {
      doc.addPage();
      pageCount++;
      currentY = 40;
    } else {
      // Add minimal space before terms if staying on same page
      currentY += 15;
    }

    // Terms and Conditions header - with proper spacing
    doc.fontSize(12).font('Helvetica-Bold');
    doc.text('Terms and Conditions', margin, currentY, { align: 'left' });
    doc.font('ArabicFont').fontSize(12);
    // Adjusted position to prevent overlap - moved further right
    doc.text('الشروط والأحكام', doc.page.width - margin, currentY, { align: 'right', width: 150, features: ['rtl'] });
    currentY += 20; // Increased spacing after title

    // Arabic Terms (exact same as invoice generator)
    const arabicTerms = [
      '1 - خدمة tniaP hcuoT مجانا ولا تتحمل الشركة اي مسئولية عن نتيجة tniaP hcuoT - يجب العلم هناك فرق بين )tniaP hcuoT( و )tniaP tramS(',
      '2 - الشركة تتعهد في خدمة RDP حسب النسبة المذكورة ولا تتحمل اي مسئولية عن الخدوش العمل يتم على تعديل الضربة فقط',
      '3 - الشركة لا تتحمل اي مسئولية عن اي اعطال كهربائية او ميكانيكية داخل السيارة',
      '4 - احيانا يتطلب العمل على السيارة اجراء فتحة في بعض المناطق في السيارة اذا لزم الامر - احيانا نلتجأ الي فك بعض اجزاء السيارة',
      '5 - لا تتحمل الشركة اي مسؤلية عن اي خدش داخل السيارة لان شركة الاخطبوط الذهبي اختصاصها هيكل السيارة الخارجي',
      '6 - العربون المدفوع لا يسترد',
      '7 - من الممكن حدوث كسر في الصبغ، اذا حدث ستتكفل الشركة بعمل الصبغ الذكي مجانا',
      '8 - اذا كان هناك قطع غيار تالفة فالشركة غير معنية بها',
      '9 - في اغلب الاحيان يتم فك الديكور الداخلي للسيارة',
      '01 - الشركه غير مسئوله عن ازاله الجلاد او الحمايه عن اجزاء السياره',
      '11 - في بعض الاحيان ليتناسق اللون في الصبغ نلجأ الي سحب بعض من الصبغ الي القطعه الملاصقه للضربه',
      '21 - السعر غير شامل ثمن القطع',
      '31 - عند انتهاء العمل على السيارة واخبار العميل بذلك بعد استغراق 84 ساعة الشركة لا تتحمل اي مسؤلية عن الحوادث الطبيعية او وقوع اي اضرار بالسيارة',
      '41 - عند عمل صبغ سمارت بينت لاي قطعة في السيارة اجباري وضع لكر لكامل القطعة',
      '51 - عند انتهاء العمل على السياره واخبار العميل بذلك بعد استغراق 84 ساعه يحسب على كل يوم 05 درهم حساب باركنج',
      '61 - يجب العلم بأن تكنولوجيه الصبغ ان كانت سمارت بينت او صبغ كامل القطعة (بأستثناء القطع الوكالة) يكون على مراحل بدايه تعديل الضربة ثم معجون ثم برايمر ثم صبغ ثم اللكر',
      '71 - الشركه غير مسئوله عن درجه فحص القياس',
      '81 - في حالة امضاء العميل فانه يوافق على جميع بنود الخدمه',
      '91 - الشركه لا تتحمل اي مقتنيات داخل السياره',
      '02 - ضمان الصبغ خمس سنوات ولا يشمل الضمان على الحوادث'
    ];

    // English Terms (exact same as invoice generator)
    const englishTerms = [
      '1 - The Touch Paint service is free of charge and the company does not bear any responsibility for the result of Touch Paint - you must know that there is a difference between (Touch Paint) and (Smart Paint)',
      '2 - The company undertakes to provide the PDR service according to the mentioned percentage and does not bear any responsibility for scratches. The work is done on adjusting the strike only',
      '3 - The company does not bear any responsibility for any electrical or mechanical malfunctions inside the car',
      '4 - Sometimes working on the car requires making an opening in some areas of the car if necessary - sometimes we resort to dismantling some parts of the car.',
      '5 - The company does not bear any responsibility for any scratch inside the car because Golden Octopus Company specializes in the exterior car body',
      '6 - The deposit paid is non-refundable',
      '7 - It is possible for the dye to break. If it happens, the company will take care of the smart dyeing for free',
      '8 - If there are damaged spare parts, the company is not concerned with them',
      '9 - In most cases, the interior decoration of the car is removed',
      '10 - The company is not responsible for removing the switch or protection from the car parts',
      '11 - Sometimes, in order for the color to be consistent in dyeing, we resort to pulling some of the dye onto the piece adjacent to the stroke.',
      '12 - The price does not include the price of the parts',
      '13 - When work on the car is completed and the customer is informed of this after 48 hours, the company does not bear any responsibility for natural accidents or any damage to the car.',
      '14 - When applying Smart Paint to any part of the car, it is mandatory to apply lacquer to the entire piece',
      '15 - When the work on the car is finished and the customer is informed of that after 48 hours, 50 dirhams are charged per day for parking.',
      '16 - It must be known that the dyeing technology, whether it is Smart Paint or dyeing the entire piece (except for the agency pieces), is in stages, starting with adjusting the stroke, then putty, then primer, then dye, then lacquer.',
      '17 - The company is not responsible for the degree of measurement inspection',
      '18 - If the customer signs, he agrees to all terms of service',
      '19 - The company is not responsible for any belongings inside the car',
      '20 - The paint is guaranteed for five years, but the warranty does not cover accidents.'
    ];

    // Display terms in both languages - balanced spacing for readability
    doc.fontSize(7); // Better font size for readability
    const baseLineHeight = 9; // Improved line height
    const minSpacing = 16; // More comfortable minimum spacing
    const maxSpacing = 35; // Adequate maximum spacing
    const termsColumnWidth = (doc.page.width - 100) / 2;
    
    for (let i = 0; i < arabicTerms.length; i++) {
      // Balanced spacing calculation for better readability
      const arabicTextLength = arabicTerms[i].length;
      const englishTextLength = englishTerms[i].length;
      const maxTextLength = Math.max(arabicTextLength, englishTextLength);

      // Better estimation for 7pt font
      let estimatedLines = Math.ceil(maxTextLength / 55);
      estimatedLines = Math.max(1, estimatedLines);

      // Improved dynamic height with better spacing
      let dynamicHeight;
      if (estimatedLines <= 2) {
        dynamicHeight = minSpacing;
      } else if (estimatedLines <= 3) {
        dynamicHeight = minSpacing + 6;
      } else {
        dynamicHeight = Math.min(maxSpacing, minSpacing + (estimatedLines * 5));
      }
      
      // Check if we need a new page - but stay within 2 page limit
      if (currentY + dynamicHeight + 60 > doc.page.height && pageCount < maxPages) {
        doc.addPage();
        pageCount++;
        currentY = 40;
      } else if (currentY + dynamicHeight + 60 > doc.page.height && pageCount >= maxPages) {
        // If we've hit page limit, stop adding terms
        break;
      }
      
      // Arabic term on the right
      doc.font('ArabicFont');
      doc.text(arabicTerms[i], (doc.page.width / 2) + 10, currentY, { 
        align: 'right',
        width: termsColumnWidth,
        features: ['rtl']
      });
      
      // English term on the left
      doc.font('Helvetica');
      doc.text(englishTerms[i], 50, currentY, { 
        width: termsColumnWidth
      });
      
      currentY += dynamicHeight;
    }

    // Only add signature if we have space or are under page limit
    if (currentY + 80 > doc.page.height && pageCount < maxPages) {
      doc.addPage();
      pageCount++;
      currentY = 40;
    } else if (currentY + 80 > doc.page.height && pageCount >= maxPages) {
      // If no space and at page limit, skip signature section
      console.log('Warning: Signature section omitted due to 2-page limit');
      doc.end();
      return;
    }

    // Add minimal space before signature section
    currentY += 10;

    // Compact customer acknowledgment section
    doc.fontSize(10).font('Helvetica-Bold');
    doc.text('Customer Acknowledgment:', margin, currentY);
    doc.font('ArabicFont').fontSize(10);
    doc.text('إقرار العميل:', doc.page.width - 180, currentY, {
      align: 'right',
      width: 140,
      features: ['rtl']
    });

    currentY += 20;

    doc.fontSize(9).font('Helvetica');
    doc.text('Customer Signature: ____________________', margin, currentY);
    doc.font('ArabicFont').fontSize(9);
    doc.text('توقيع العميل: ____________________', doc.page.width - 260, currentY, {
      align: 'right',
      width: 220,
      features: ['rtl']
    });

    // Track the last content position
    lastContentY = currentY + 30;
    
    // Check if we're on a mostly empty page at the end
    const pageUsage = lastContentY / doc.page.height;
    if (pageCount > 1 && pageUsage < 0.25) {
      console.log(`Note: Car Job last page appears mostly empty (${Math.round(pageUsage * 100)}% used)`);
    }

    // Finalize PDF
    doc.end();
  } catch (error) {
    console.error('Car Job PDF Generation Error:', error);
    throw error;
  }
};

module.exports = {
  generateCarJobPDF,
  generateCarJobPDFFromDB,
  getServiceRoutesForCarJob
};
