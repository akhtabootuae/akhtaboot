const PDFDocument = require('pdfkit');
const { ObjectId } = require('mongodb');
const fs = require('fs-extra');
const path = require('path');
const sharp = require('sharp');
const Invoice = require('../models/Invoice');
const fontPathArabic = path.join(__dirname, '../fonts/Cairo-Regular.ttf');

/**
 * Detects if text contains Arabic characters
 * @param {string} text - Text to check
 * @returns {boolean} - True if text contains Arabic characters
 */
const hasArabicText = (text) => {
  if (!text || typeof text !== 'string') return false;
  // Arabic Unicode range: 0x0600-0x06FF, 0x0750-0x077F, 0x08A0-0x08FF, 0xFB50-0xFDFF, 0xFE70-0xFEFF
  const arabicRegex = /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/;
  return arabicRegex.test(text);
};

/**
 * Smart text rendering that automatically chooses the appropriate font based on text content
 * @param {Object} doc - PDFKit document instance
 * @param {string} text - Text to render
 * @param {number} x - X coordinate
 * @param {number} y - Y coordinate
 * @param {Object} options - Text rendering options
 * @returns {Object} - PDFKit document instance for chaining
 */
const renderSmartText = (doc, text, x, y, options = {}) => {
  if (!text || typeof text !== 'string') {
    text = '';
  }
  
  const isArabic = hasArabicText(text);
  
  if (isArabic) {
    doc.font('ArabicFont');
    // For Arabic text, adjust positioning and ensure RTL features are enabled
    const arabicOptions = {
      ...options,
      features: ['rtl']
    };
    
    // If no specific alignment is provided, use right alignment for Arabic
    if (!arabicOptions.align) {
      arabicOptions.align = 'right';
      // If width is not specified, calculate a reasonable width for right alignment
      if (!arabicOptions.width) {
        arabicOptions.width = 200; // Default width for Arabic text
      }
    }
    
    return doc.text(text, x, y, arabicOptions);
  } else {
    doc.font('Helvetica');
    return doc.text(text, x, y, options);
  }
};

/**
 * Prepares an image for use with PDFKit by converting it to PNG format
 * @param {string} imagePath - Path to the image file
 * @returns {Promise<Buffer>} - PNG image buffer
 */
const prepareImageForPDF = async (imagePath) => {
  try {
    return await sharp(imagePath)
      .png()
      .toBuffer();
  } catch (error) {
    console.error(`Error converting image ${imagePath}:`, error);
    throw error;
  }
};

/**
 * Fetch service routes data for an invoice
 * @param {Object} db - MongoDB database connection
 * @param {string} invoiceId - The ID of the invoice
 * @returns {Object} Service routes data
 */
const getServiceRoutesForInvoice = async (db, invoiceId) => {
  try {
    const invoice = await Invoice.getById(db, invoiceId);
    
    if (!invoice || !invoice.work_order_id) {
      return { serviceRoutes: [], summary: { totalParts: 0, totalServices: 0 } };
    }

    // Get the work order
    const workOrder = await db.collection('work_orders').findOne({ _id: new ObjectId(invoice.work_order_id) });
    
    if (!workOrder) {
      return { serviceRoutes: [], summary: { totalParts: 0, totalServices: 0 } };
    }

    // Build service routes data
    const serviceRoutes = [];
    const cancelledServices = [];

    for (const part of workOrder.parts) {
      // Get variation (service) details
      const variation = await db.collection('variations').findOne({ _id: part.variationId });
      
      if (variation) {
        // Get stage details for this part
        const stageDetails = [];
        
        for (const stage of part.stages) {
          const stageInfo = await db.collection('stages').findOne({ _id: stage.stageId });
          if (stageInfo) {
            stageDetails.push({
              stageId: stage.stageId,
              stageName: stageInfo.name,
              stageDescription: stageInfo.description,
              stageOrder: stageInfo.order,
              status: stage.status
            });
          }
        }

        // Sort stages by order
        stageDetails.sort((a, b) => a.stageOrder - b.stageOrder);

        serviceRoutes.push({
          partName: part.partName,
          partStatus: part.status,
          service: {
            code: variation.code,
            description: variation.description,
            defaultLaborHours: variation.defaultLaborHours
          },
          stages: stageDetails
        });
      }
    }

    // Process cancelled parts if they exist
    if (workOrder.cancelledParts && workOrder.cancelledParts.length > 0) {
      for (const cancelledPart of workOrder.cancelledParts) {
        cancelledServices.push({
          partName: cancelledPart.partName,
          partStatus: 'cancelled',
          reason: cancelledPart.reason,
          cancelledBy: cancelledPart.cancelledBy,
          cancelledAt: cancelledPart.cancelledAt
        });
      }
    }

    return {
      serviceRoutes,
      cancelledServices,
      summary: {
        totalParts: serviceRoutes.length,
        totalServices: [...new Set(serviceRoutes.map(sr => sr.service.code))].length,
        totalCancelledParts: cancelledServices.length
      }
    };
  } catch (error) {
    console.error('Error fetching service routes:', error);
    return { serviceRoutes: [], summary: { totalParts: 0, totalServices: 0 } };
  }
};

/**
 * Generate a PDF invoice from the database
 * @param {Object} db - MongoDB database connection
 * @param {string} invoiceId - The ID of the invoice to generate PDF for
 * @param {Object} response - Express response object to pipe the PDF to
 */
const generateInvoicePDFFromDB = async (db, invoiceId, response, isTaxed = true, isQuotation = false) => {
  try {
    // Get combined invoice data with customer and vehicle details
    const data = await Invoice.getInvoiceDataForPDF(db, invoiceId);
    
    // Get service routes data
    const serviceRoutesData = await getServiceRoutesForInvoice(db, invoiceId);
    
    // Log the data to make sure it contains customer info
    // console.log('Invoice data for PDF:', {
    //   invoiceId,
    //   hasInvoice: !!data.invoice,
    //   hasCustomer: !!data.customer,
    //   customerName: data.customer?.name
    // });
    
    // Call the original generateInvoicePDF with the retrieved data including service routes
    return generateInvoicePDF(data.invoice, data.customer, data.branch, response, serviceRoutesData, isTaxed, isQuotation);
  } catch (error) {
    console.error('Error generating invoice PDF from DB:', error);
    throw error;
  }
};

/**
 * Generate a PDF invoice from provided data
 * @param {Object} invoice - The invoice data
 * @param {Object} customer - The customer data
 * @param {Object} branch - The branch data
 * @param {Object} response - Express response object to pipe the PDF to
 * @param {Object} serviceRoutesData - Service routes data (optional)
 * @param {boolean} isTaxed - Whether the invoice is taxable (optional, defaults to true)
 */
const generateInvoicePDF = async (invoice, customer, branch, response, serviceRoutesData = null, isTaxed = true, isQuotation = false) => {
  try {
    // Page tracking variables to prevent blank pages
    let pageCount = 1;
    let contentOnCurrentPage = 0;
    let lastContentY = 0;
    const maxPages = 2; // Enforce 2-page maximum
    
    // Debug information
    // console.log('PDF Generation - Customer data type:', typeof customer);
    // console.log('PDF Generation - Customer data:', JSON.stringify(customer, null, 2));
    // console.log('PDF Generation - Invoice data:', JSON.stringify({
    //   invoice_number: invoice.invoice_number,
    //   work_order_number: invoice.work_order_number,
    //   customer_id: invoice.customer_id
    // }, null, 2));
    
    // Ensure customer is an object
    if (!customer || typeof customer !== 'object') {
      console.warn('Customer data is missing or not an object, creating empty customer object');
      customer = { name: '', phone: '', email: '', city: '', country: '' };
    }
    
    // Create a PDF document with A4 size and RTL support - reduced margins
    const doc = new PDFDocument({
      margin: 40,
      size: 'A4',
      autoFirstPage: true,
      // Add RTL text direction for Arabic
      features: {
        isForceRTL: true
      }
    });

    doc.registerFont('ArabicFont', fontPathArabic);
    
    // Set response headers for PDF download
    response.setHeader('Content-Type', 'application/pdf');
    response.setHeader('Content-Disposition', `attachment; filename=invoice-${invoice.invoice_number}.pdf`);
    
    // Pipe the PDF document to the response
    doc.pipe(response);
    
    // Define margins and constants - reduced for more content
    const margin = 40;
    const pageWidth = doc.page.width - 2 * margin;
    const lineHeight = 18; // Reduced line height
    let currentY = 35;
    
    // Define X positions for labels and values
    const labelXLeft = margin;
    const valueXLeft = margin + 120;
    const labelXRight = doc.page.width - margin - 120;
    
    // Header section with logo on left and company name on right
    const logoPath = path.join(__dirname, '../assets/Final-logo.webp');
    
    // Save initial Y position to return to for company text
    const initialY = currentY;
    
    // Define header area - divided into left (logo) and right (text)
    // Optimized height for space
    const headerHeight = branch ? 100 : 60;
    
    try {
      // Check if the logo exists
      if (fs.existsSync(logoPath)) {
        // Convert WEBP to PNG (in memory) and use it in the document
        const logoBuffer = await prepareImageForPDF(logoPath);
        
        // Position the logo on the left side of the header
        doc.image(logoBuffer, margin, initialY, { width: 100 });
      } else {
        // If logo doesn't exist, leave a space where it would be
        console.log('Logo file not found at:', logoPath);
      }
    } catch (err) {
      console.error('Error processing logo:', err);
      // Continue without the logo if there's an error
    }

    // Calculate text positioning to match the image - move text closer to logo
    const logoWidth = 100;
    
    // Position Arabic company name text - reduce font size and move up significantly
    doc.font('ArabicFont').fontSize(18);
    // Force RTL direction for Arabic text
    doc.text('الاخطبوط الذهبي لصيانة و إصلاح السيارات ذ م م',
             doc.page.width - margin - 350, initialY - 5, {
               align: 'right',
               width: 350,
               features: ['rtl']  // Explicitly set right-to-left for this text
             });

    // Company phone number between Arabic and English names
    doc.font('Helvetica').fontSize(12);
    doc.text('Phone: +971 50 123 4567',
             doc.page.width - margin - 360, initialY + 28, {
               align: 'right',
               width: 350
             });

    // English company name beneath phone number
    doc.fontSize(14);
    doc.text('Al Akhtaboot Althabi Auto.maint & Repair LLC',
             doc.page.width - margin - 360, initialY + 45, {
               align: 'right',
               width: 350
             });

    // Add branch information if available
    if (branch) {
      doc.fontSize(10);
      // Branch name in English
      if (branch.branch_name) {
        doc.text(branch.branch_name,
                 doc.page.width - margin - 360, initialY + 65, {
                   align: 'right',
                   width: 350
                 });
      }
      // Branch name in Arabic if available
      if (branch.branch_name_ar) {
        doc.font('ArabicFont');
        doc.text(branch.branch_name_ar,
                 doc.page.width - margin - 360, initialY + 80, {
                   align: 'right',
                   width: 350,
                   features: ['rtl']
                 });
        doc.font('Helvetica');
      }
      // Branch location
      if (branch.location) {
        doc.fontSize(9);
        doc.text(branch.location,
                 doc.page.width - margin - 360, initialY + 95, {
                   align: 'right',
                   width: 350
                 });
      }
    }

    // Reset currentY to below both the logo and company name - add more space
    currentY = initialY + headerHeight + 10;

    // Add minimal space after header
    currentY += 15;

    // Add "Tax Invoice", "Job Order", or "QUOTATION" text centered - reduced size
    doc.fontSize(14).font('Helvetica-Bold');
    let documentTitle;
    if (isQuotation) {
      documentTitle = 'QUOTATION';
      doc.fillColor('#FF6B35'); // Orange color for quotations
    } else {
      documentTitle = isTaxed ? 'Tax Invoice' : 'Job Order';
      doc.fillColor('#000000'); // Black for regular invoices
    }
    doc.text(documentTitle, 0, currentY, { align: 'center', width: doc.page.width });
    doc.fillColor('#000000'); // Reset to black
    currentY += 20;

    // Draw fields at the top with Arabic labels on the right and English on the left
    doc.fontSize(12).font('Helvetica-Bold');
    
    // TRN No - only display for taxed invoices
    if (isTaxed) {
      doc.text('TRN No', labelXLeft, currentY);
      renderSmartText(doc, invoice.branch_trn || '', valueXLeft, currentY);
      doc.font('ArabicFont').text('رقم التسجيل الضريبي', labelXRight - 20, currentY, { align: 'right', width: 120, features: ['rtl'] });
      doc.font('Helvetica');
      currentY += lineHeight;
    }

    // Phone Number (رقم الهاتف)
    doc.text('Phone Number', labelXLeft, currentY);
    const phoneText = customer && customer.phone ? customer.phone : '';
    if (hasArabicText(phoneText)) {
      renderSmartText(doc, phoneText, valueXLeft, currentY, { width: 150, align: 'left' });
    } else {
      renderSmartText(doc, phoneText, valueXLeft, currentY);
    }
    doc.font('ArabicFont').text('رقم الهاتف', labelXRight, currentY, { align: 'right', width: 100, features: ['rtl'] });
    doc.font('Helvetica');
    currentY += lineHeight;

    // Name (اسم العميل)
    doc.text('Name', labelXLeft, currentY);
    // Ensure customer name is displayed properly by checking for its existence and logging it
    // console.log("Customer name to display:", customer?.name);
    const customerName = customer && customer.name ? customer.name : '';
    if (hasArabicText(customerName)) {
      renderSmartText(doc, customerName, valueXLeft, currentY, { width: 150, align: 'left' });
    } else {
      renderSmartText(doc, customerName, valueXLeft, currentY);
    }
    doc.font('ArabicFont').text('اسم العميل', labelXRight, currentY, { align: 'right', width: 100, features: ['rtl'] });
    doc.font('Helvetica');
    currentY += lineHeight;

    // Date (التاريخ)
    const invoiceDate = invoice.invoice_date ? new Date(invoice.invoice_date).toLocaleDateString('en-GB') : '';
    doc.text('Date', labelXLeft, currentY);
    doc.text(invoiceDate, valueXLeft, currentY);
    doc.font('ArabicFont').text('التاريخ', labelXRight, currentY, { align: 'right', width: 100, features: ['rtl'] });
    doc.font('Helvetica');
    currentY += lineHeight;

    // Invoice Number and Job Number - only show for taxed invoices (not for car jobs)
    if (isTaxed) {
      // Invoice Number (رقم الفاتورة)
      doc.text('Invoice Number', labelXLeft, currentY);
      renderSmartText(doc, invoice.invoice_number || '', valueXLeft, currentY);
      doc.font('ArabicFont').text('رقم الفاتورة', labelXRight, currentY, { align: 'right', width: 100, features: ['rtl'] });
      doc.font('Helvetica');
      currentY += lineHeight;

      // Job Number (workorder number as reference) - show N/A for quotations
      doc.text('Job Number', labelXLeft, currentY);
      const jobNumber = isQuotation ? 'N/A' : (invoice.work_order_number || '');
      renderSmartText(doc, jobNumber, valueXLeft, currentY);
      doc.font('ArabicFont').text('رقم الوظيفة', labelXRight, currentY, { align: 'right', width: 100, features: ['rtl'] });
      doc.font('Helvetica');
      currentY += lineHeight;
    }

    // Add minimal space before the table
    currentY += 5;

    // Draw a horizontal line below header info
    doc.moveTo(margin, currentY).lineTo(doc.page.width - margin, currentY).stroke();
    currentY += 5;

    // Section with Car Model, License Plate, Service Type, Ratio, Price, VAT, Total Price as a table
    const sectionLabelsArabic = ['موديل السيارة', 'رقم اللوحة', 'نوع الخدمة', 'النسبة', 'السعر (قبل الضريبة)', 'الضريبة', 'السعر الاجمالي'];
    const sectionLabelsEnglish = ['Car Model', 'License Plate', 'Service Type', 'Ratio', 'Price (Before VAT)', 'VAT', 'Total Price'];

    // Use stored VAT values instead of calculating them dynamically
    const displayPrice = invoice.price_before_vat || invoice.price || 0;
    const displayVatAmount = invoice.vat_amount || 0;
    const displayTotal = invoice.total_price || invoice.price || 0;
    const vatPercentage = invoice.vat || 5;

    // Separate car model and license plate
    const carModelText = (invoice.car_type && invoice.car_type !== 'undefined') ? invoice.car_type : '';
    const licensePlateText = (invoice.license_plate && invoice.license_plate !== 'undefined') ? invoice.license_plate : '';

    const sectionValues = [
      carModelText,
      licensePlateText,
      invoice.presented_service_type || invoice.service_type || '',
      invoice.ratio ? `${invoice.ratio}%` : '',
      `${displayPrice.toFixed(2)} AED`,
      `${vatPercentage}%`,
      `${displayTotal.toFixed(2)} AED`
    ];

    // Define table dimensions
    const tableWidth = doc.page.width - 100;
    const tableX = 50;
    const columnWidth = tableWidth / 3;
    const baseRowHeight = lineHeight * 1.5; // Base height for single-line content
    
    // Draw table header with background
    const tableHeaderHeight = baseRowHeight;
    doc.fillColor('#e8e8e8');
    doc.rect(tableX, currentY, tableWidth, tableHeaderHeight).fill();
    doc.fillColor('#000000');

    // Draw header borders
    doc.lineWidth(1);
    doc.strokeColor('#333333');
    doc.rect(tableX, currentY, tableWidth, tableHeaderHeight).stroke();
    doc.moveTo(tableX + columnWidth, currentY).lineTo(tableX + columnWidth, currentY + tableHeaderHeight).stroke();
    doc.moveTo(tableX + (columnWidth * 2), currentY).lineTo(tableX + (columnWidth * 2), currentY + tableHeaderHeight).stroke();

    // Draw header text
    doc.fillColor('#000000');
    doc.font('Helvetica-Bold').fontSize(12);
    doc.text('English', tableX + 10, currentY + 7, { width: columnWidth - 20 });
    doc.text('Value', tableX + columnWidth + 10, currentY + 7, { width: columnWidth - 20, align: 'center' });
    doc.font('ArabicFont');
    doc.text('عربي', tableX + (columnWidth * 2) + 10, currentY + 7, {
      align: 'right',
      width: columnWidth - 20,
      features: ['rtl']
    });

    currentY += tableHeaderHeight;
    
    // Draw table rows
    for (let i = 0; i < sectionLabelsEnglish.length; i++) {
      const cellValue = sectionValues[i];

      // Calculate row height based on content
      let rowHeight = baseRowHeight;

      // No special height needed since car model and license plate are now separate rows

      // Draw row background (alternating colors)
      doc.fillColor(i % 2 === 0 ? '#ffffff' : '#fafafa');
      doc.rect(tableX, currentY, tableWidth, rowHeight).fill();
      doc.fillColor('#000000');

      // Draw cell borders
      doc.lineWidth(0.5);
      doc.strokeColor('#cccccc');
      doc.rect(tableX, currentY, tableWidth, rowHeight).stroke();
      doc.moveTo(tableX + columnWidth, currentY).lineTo(tableX + columnWidth, currentY + rowHeight).stroke();
      doc.moveTo(tableX + (columnWidth * 2), currentY).lineTo(tableX + (columnWidth * 2), currentY + rowHeight).stroke();
      doc.strokeColor('#000000'); // Reset stroke color

      // Draw cell content
      doc.fontSize(11).font('Helvetica-Bold');
      doc.text(sectionLabelsEnglish[i], tableX + 10, currentY + 7, { width: columnWidth - 20 });

      doc.fontSize(11).font('Helvetica');
      // Use smart text rendering for values that might contain Arabic
      if (hasArabicText(cellValue)) {
        renderSmartText(doc, cellValue, tableX + columnWidth + 10, currentY + 7, {
          width: columnWidth - 20,
          align: 'left',
          lineBreak: true,
          height: rowHeight - 10
        });
      } else {
        doc.font('Helvetica');
        doc.text(cellValue, tableX + columnWidth + 10, currentY + 7, {
          width: columnWidth - 20,
          lineBreak: true,
          height: rowHeight - 10
        });
      }

      doc.fontSize(11).font('ArabicFont');
      doc.text(sectionLabelsArabic[i], tableX + (columnWidth * 2) + 10, currentY + 7, {
        align: 'right',
        width: columnWidth - 20,
        features: ['rtl']
      });

      currentY += rowHeight;
    }
    
    // Draw bottom border for the table
    doc.lineWidth(1);
    doc.strokeColor('#333333');
    doc.moveTo(tableX, currentY).lineTo(tableX + tableWidth, currentY).stroke();
    doc.strokeColor('#000000'); // Reset stroke color

    // Add Payment Records section if available
    if (invoice.payment_records && invoice.payment_records.length > 0) {
      currentY += 20;
      // Payment Records Header
      doc.fontSize(14).font('Helvetica-Bold');
      doc.text('Payment Records', tableX, currentY);
      doc.font('ArabicFont');
      doc.text('سجل المدفوعات', tableX + tableWidth - 100, currentY, { 
        align: 'right', 
        width: 100,
        features: ['rtl'] 
      });
      currentY += 25;

      // Payment Records Table
      const paymentTableWidth = tableWidth;
      const paymentColumnWidths = [
        paymentTableWidth * 0.25, // Date
        paymentTableWidth * 0.25, // Amount
        paymentTableWidth * 0.25, // Method
        paymentTableWidth * 0.25  // Reference
      ];

      // Payment table header
      doc.fillColor('#e8f5e8');
      doc.rect(tableX, currentY, paymentTableWidth, baseRowHeight).fill();
      doc.fillColor('#000000');
      
      doc.fontSize(10).font('Helvetica-Bold');
      let headerX = tableX;
      doc.text('Payment Date', headerX + 5, currentY + 5, { width: paymentColumnWidths[0] - 10 });
      headerX += paymentColumnWidths[0];
      doc.text('Amount', headerX + 5, currentY + 5, { width: paymentColumnWidths[1] - 10 });
      headerX += paymentColumnWidths[1];
      doc.text('Method', headerX + 5, currentY + 5, { width: paymentColumnWidths[2] - 10 });
      headerX += paymentColumnWidths[2];
      doc.text('Reference', headerX + 5, currentY + 5, { width: paymentColumnWidths[3] - 10 });

      // Draw header borders
      doc.lineWidth(0.5);
      doc.rect(tableX, currentY, paymentTableWidth, baseRowHeight).stroke();
      let borderX = tableX;
      for (let i = 0; i < paymentColumnWidths.length - 1; i++) {
        borderX += paymentColumnWidths[i];
        doc.moveTo(borderX, currentY).lineTo(borderX, currentY + baseRowHeight).stroke();
      }

      currentY += baseRowHeight;

      // Payment records data
      let totalPaid = 0;
      for (let i = 0; i < invoice.payment_records.length; i++) {
        const payment = invoice.payment_records[i];
        
        // Draw row background
        doc.fillColor(i % 2 === 0 ? '#ffffff' : '#f9fff9');
        doc.rect(tableX, currentY, paymentTableWidth, baseRowHeight).fill();
        doc.fillColor('#000000');

        // Draw cell content
        doc.fontSize(9);
        let cellX = tableX;
        
        // Payment Date
        const paymentDate = payment.payment_date ? new Date(payment.payment_date).toLocaleDateString('en-GB') : '';
        renderSmartText(doc, paymentDate, cellX + 5, currentY + 5, { 
          width: paymentColumnWidths[0] - 10,
          height: baseRowHeight - 10,
          align: 'left'
        });
        cellX += paymentColumnWidths[0];
        
        // Amount
        const amount = payment.amount || 0;
        totalPaid += amount;
        renderSmartText(doc, `${amount.toFixed(2)} AED`, cellX + 5, currentY + 5, { 
          width: paymentColumnWidths[1] - 10,
          height: baseRowHeight - 10,
          align: 'left'
        });
        cellX += paymentColumnWidths[1];
        
        // Payment Method
        const paymentMethod = payment.payment_method || '';
        if (hasArabicText(paymentMethod)) {
          renderSmartText(doc, paymentMethod, cellX + 5, currentY + 5, { 
            width: paymentColumnWidths[2] - 10,
            height: baseRowHeight - 10,
            align: 'left'
          });
        } else {
          renderSmartText(doc, paymentMethod, cellX + 5, currentY + 5, { 
            width: paymentColumnWidths[2] - 10,
            height: baseRowHeight - 10
          });
        }
        cellX += paymentColumnWidths[2];
        
        // Reference
        const reference = payment.reference || '';
        if (hasArabicText(reference)) {
          renderSmartText(doc, reference, cellX + 5, currentY + 5, { 
            width: paymentColumnWidths[3] - 10,
            height: baseRowHeight - 10,
            align: 'left'
          });
        } else {
          renderSmartText(doc, reference, cellX + 5, currentY + 5, { 
            width: paymentColumnWidths[3] - 10,
            height: baseRowHeight - 10
          });
        }

        // Draw row borders
        doc.lineWidth(0.5);
        doc.rect(tableX, currentY, paymentTableWidth, baseRowHeight).stroke();
        let rowBorderX = tableX;
        for (let j = 0; j < paymentColumnWidths.length - 1; j++) {
          rowBorderX += paymentColumnWidths[j];
          doc.moveTo(rowBorderX, currentY).lineTo(rowBorderX, currentY + baseRowHeight).stroke();
        }

        currentY += baseRowHeight;
      }

      // Payment Summary
      currentY += 10;
      doc.fontSize(10).font('Helvetica-Bold');
      const remainingBalance = (invoice.total_price || 0) - totalPaid;
      const paymentSummaryText = `Total Paid: ${totalPaid.toFixed(2)} AED | Remaining Balance: ${remainingBalance.toFixed(2)} AED | Payment Status: ${invoice.payment_status || 'Unknown'}`;
      doc.text(paymentSummaryText, tableX, currentY);
      currentY += 20;
    }

    // Add External Services section if available
    if (invoice.external_services && invoice.external_services.length > 0) {
      currentY += 20;
      // External Services Header
      doc.fontSize(14).font('Helvetica-Bold');
      doc.text('External Services', tableX, currentY);
      doc.font('ArabicFont');
      doc.text('الخدمات الخارجية', tableX + tableWidth - 100, currentY, { 
        align: 'right', 
        width: 100,
        features: ['rtl'] 
      });
      currentY += 25;

      // External Services Table
      const externalServiceTableWidth = tableWidth;
      const externalServiceColumnWidths = [
        externalServiceTableWidth * 0.3, // Total Amount
        externalServiceTableWidth * 0.7  // Notes
      ];

      // External Services table header
      doc.fillColor('#e8f0ff');
      doc.rect(tableX, currentY, externalServiceTableWidth, baseRowHeight).fill();
      doc.fillColor('#000000');
      
      doc.fontSize(10).font('Helvetica-Bold');
      let externalHeaderX = tableX;
      doc.text('Total Amount (AED)', externalHeaderX + 5, currentY + 5, { width: externalServiceColumnWidths[0] - 10 });
      externalHeaderX += externalServiceColumnWidths[0];
      doc.text('Notes', externalHeaderX + 5, currentY + 5, { width: externalServiceColumnWidths[1] - 10 });

      // Draw header borders
      doc.lineWidth(0.5);
      doc.rect(tableX, currentY, externalServiceTableWidth, baseRowHeight).stroke();
      let externalBorderX = tableX;
      for (let j = 0; j < externalServiceColumnWidths.length - 1; j++) {
        externalBorderX += externalServiceColumnWidths[j];
        doc.moveTo(externalBorderX, currentY).lineTo(externalBorderX, currentY + baseRowHeight).stroke();
      }

      currentY += baseRowHeight;

      // External Services data
      let totalExternalAmount = 0;
      
      for (let i = 0; i < invoice.external_services.length; i++) {
        const externalService = invoice.external_services[i];
        const serviceCost = parseFloat(externalService.cost) || 0;
        const serviceProfit = parseFloat(externalService.profit) || 0;
        const serviceTotal = serviceCost + serviceProfit;
        
        totalExternalAmount += serviceTotal;

        // Row background (alternating colors)
        doc.fillColor(i % 2 === 0 ? '#ffffff' : '#f9f9f9');
        doc.rect(tableX, currentY, externalServiceTableWidth, baseRowHeight).fill();
        doc.fillColor('#000000');

        doc.fontSize(9);
        let externalCellX = tableX;
        
        // Total Amount
        renderSmartText(doc, `${serviceTotal.toFixed(2)}`, externalCellX + 5, currentY + 5, { 
          width: externalServiceColumnWidths[0] - 10,
          height: baseRowHeight - 10,
          align: 'left'
        });
        externalCellX += externalServiceColumnWidths[0];
        
        // Notes
        const notes = externalService.notes || 'No notes provided';
        if (hasArabicText(notes)) {
          renderSmartText(doc, notes, externalCellX + 5, currentY + 5, { 
            width: externalServiceColumnWidths[1] - 10,
            height: baseRowHeight - 10,
            align: 'left'
          });
        } else {
          renderSmartText(doc, notes, externalCellX + 5, currentY + 5, { 
            width: externalServiceColumnWidths[1] - 10,
            height: baseRowHeight - 10
          });
        }

        // Draw row borders
        doc.lineWidth(0.5);
        doc.rect(tableX, currentY, externalServiceTableWidth, baseRowHeight).stroke();
        let externalRowBorderX = tableX;
        for (let j = 0; j < externalServiceColumnWidths.length - 1; j++) {
          externalRowBorderX += externalServiceColumnWidths[j];
          doc.moveTo(externalRowBorderX, currentY).lineTo(externalRowBorderX, currentY + baseRowHeight).stroke();
        }

        currentY += baseRowHeight;
      }

      // External Services Summary
      currentY += 10;
      doc.fontSize(10).font('Helvetica-Bold');
      const externalSummaryText = `External Services Total: ${totalExternalAmount.toFixed(2)} AED`;
      doc.text(externalSummaryText, tableX, currentY);
      currentY += 20;

      // If there are external services with images, add note about image attachments
      const servicesWithImages = invoice.external_services.filter(service => service.invoice_image && service.invoice_image.url);
      if (servicesWithImages.length > 0) {
        doc.fontSize(9).font('Helvetica');
        doc.text(`Note: ${servicesWithImages.length} external service(s) have attached invoice images.`, tableX, currentY);
        currentY += 15;
      }
    }

    // Check if we need a new page before service routes - respect 2 page limit
    const hasServiceRoutes = serviceRoutesData && serviceRoutesData.serviceRoutes && serviceRoutesData.serviceRoutes.length > 0;
    if (hasServiceRoutes && currentY > doc.page.height - 120 && pageCount < maxPages) {
      // Add new page only if under page limit
      doc.addPage();
      pageCount++;
      currentY = 40; // Reset Y position for new page
      contentOnCurrentPage = 0;
    }

    // Add Service Routes section if available
    if (hasServiceRoutes) {
      currentY += 20;
      // Service Routes Header
      doc.fontSize(14).font('Helvetica-Bold');
      doc.text('Service Details', tableX, currentY);
      doc.font('ArabicFont');
      doc.text('تفاصيل الخدمات', tableX + tableWidth - 100, currentY, { 
        align: 'right', 
        width: 100,
        features: ['rtl'] 
      });
      currentY += 25;

      // Service Routes Table
      const serviceTableWidth = tableWidth;
      const serviceColumnWidths = [
        serviceTableWidth * 0.3,  // Part Name
        serviceTableWidth * 0.4,  // Service
        serviceTableWidth * 0.3   // Notes (expanded to include special requirements)
      ];

      // Service table header
      doc.fillColor('#e8e8e8');
      doc.rect(tableX, currentY, serviceTableWidth, baseRowHeight).fill();
      doc.fillColor('#000000');
      
      doc.fontSize(10).font('Helvetica-Bold');
      let headerX = tableX;
      doc.text('Part Name', headerX + 5, currentY + 5, { width: serviceColumnWidths[0] - 10 });
      headerX += serviceColumnWidths[0];
      doc.text('Service', headerX + 5, currentY + 5, { width: serviceColumnWidths[1] - 10 });
      headerX += serviceColumnWidths[1];
      doc.text('Notes', headerX + 5, currentY + 5, { width: serviceColumnWidths[2] - 10 });
      doc.fontSize(10);

      // Draw header borders
      doc.lineWidth(0.5);
      doc.rect(tableX, currentY, serviceTableWidth, baseRowHeight).stroke();
      let borderX = tableX;
      for (let i = 0; i < serviceColumnWidths.length - 1; i++) {
        borderX += serviceColumnWidths[i];
        doc.moveTo(borderX, currentY).lineTo(borderX, currentY + baseRowHeight).stroke();
      }

      currentY += baseRowHeight;

      // Service routes data - first draw all part rows
      const startRowY = currentY;
      for (let i = 0; i < serviceRoutesData.serviceRoutes.length; i++) {
        const route = serviceRoutesData.serviceRoutes[i];
        
        // Calculate row height based on content length
        const estimatedHeight = baseRowHeight;
        
        // Draw row background for Part Name and Service columns only
        doc.fillColor(i % 2 === 0 ? '#ffffff' : '#f9f9f9');
        doc.rect(tableX, currentY, serviceColumnWidths[0] + serviceColumnWidths[1], estimatedHeight).fill();
        doc.fillColor('#000000');

        // Draw cell content
        doc.fontSize(9);
        let cellX = tableX;
        
        // Part Name
        const partName = route.partName;
        if (hasArabicText(partName)) {
          renderSmartText(doc, partName, cellX + 5, currentY + 5, { 
            width: serviceColumnWidths[0] - 10,
            height: estimatedHeight - 10,
            align: 'left'
          });
        } else {
          renderSmartText(doc, partName, cellX + 5, currentY + 5, { 
            width: serviceColumnWidths[0] - 10,
            height: estimatedHeight - 10
          });
        }
        cellX += serviceColumnWidths[0];
        
        // Service
        let serviceText;
        if (route.service) {
          // Full service object with code and description (invoices)
          serviceText = `${route.service.code} - ${route.service.description}`;
        } else {
          // Simple service name (quotations)
          serviceText = route.serviceName || '';
        }
        if (hasArabicText(serviceText)) {
          renderSmartText(doc, serviceText, cellX + 5, currentY + 5, { 
            width: serviceColumnWidths[1] - 10,
            height: estimatedHeight - 10,
            align: 'left'
          });
        } else {
          renderSmartText(doc, serviceText, cellX + 5, currentY + 5, { 
            width: serviceColumnWidths[1] - 10,
            height: estimatedHeight - 10
          });
        }
        
        // Draw row borders for Part Name and Service columns only
        doc.lineWidth(0.5);
        doc.rect(tableX, currentY, serviceColumnWidths[0], estimatedHeight).stroke();
        doc.rect(tableX + serviceColumnWidths[0], currentY, serviceColumnWidths[1], estimatedHeight).stroke();

        currentY += estimatedHeight;
      }
      
      // Now draw merged cell for Notes (includes both notes and special requirements)
      const mergedCellHeight = currentY - startRowY;
      const notesX = tableX + serviceColumnWidths[0] + serviceColumnWidths[1];

      // Draw merged Notes cell
      doc.fillColor('#ffffff');
      doc.rect(notesX, startRowY, serviceColumnWidths[2], mergedCellHeight).fill();
      doc.fillColor('#000000');
      doc.rect(notesX, startRowY, serviceColumnWidths[2], mergedCellHeight).stroke();

      // Combine notes and special requirements text
      let combinedNotesText = invoice.notes || '';
      if (invoice.special_requests && invoice.special_requests.trim() !== '') {
        if (combinedNotesText) {
          combinedNotesText += '\n\n' + invoice.special_requests;
        } else {
          combinedNotesText = invoice.special_requests;
        }
      }
      combinedNotesText = combinedNotesText || '-';

      // Draw combined Notes text
      doc.fontSize(9);
      if (hasArabicText(combinedNotesText)) {
        renderSmartText(doc, combinedNotesText, notesX + 5, startRowY + 5, {
          width: serviceColumnWidths[2] - 10,
          height: mergedCellHeight - 10,
          align: 'left'
        });
      } else {
        renderSmartText(doc, combinedNotesText, notesX + 5, startRowY + 5, {
          width: serviceColumnWidths[2] - 10,
          height: mergedCellHeight - 10
        });
      }

      // Summary
      currentY += 10;
      doc.fontSize(10).font('Helvetica-Bold');
      const summaryText = `Total Parts: ${serviceRoutesData.summary.totalParts} | Total Services: ${serviceRoutesData.summary.totalServices}`;
      doc.text(summaryText, tableX, currentY);
      currentY += 20;

      // Add Cancelled Services section if available
      if (serviceRoutesData.cancelledServices && serviceRoutesData.cancelledServices.length > 0) {
        // Cancelled Services Header
        doc.fontSize(12).font('Helvetica-Bold');
        doc.text('Cancelled Services', tableX, currentY);
        doc.font('ArabicFont');
        doc.text('الخدمات الملغاة', tableX + tableWidth - 100, currentY, { 
          align: 'right', 
          width: 100,
          features: ['rtl'] 
        });
        currentY += 20;

        // Cancelled services table
        const cancelTableWidth = tableWidth;
        const cancelColumnWidths = [
          cancelTableWidth * 0.4, // Part Name
          cancelTableWidth * 0.6  // Reason
        ];

        // Cancelled table header
        doc.fillColor('#ffebee');
        doc.rect(tableX, currentY, cancelTableWidth, baseRowHeight).fill();
        doc.fillColor('#000000');
        
        doc.fontSize(10).font('Helvetica-Bold');
        doc.text('Part Name', tableX + 5, currentY + 5, { width: cancelColumnWidths[0] - 10 });
        doc.text('Cancellation Reason', tableX + cancelColumnWidths[0] + 5, currentY + 5, { width: cancelColumnWidths[1] - 10 });

        // Draw header borders
        doc.lineWidth(0.5);
        doc.rect(tableX, currentY, cancelTableWidth, baseRowHeight).stroke();
        doc.moveTo(tableX + cancelColumnWidths[0], currentY).lineTo(tableX + cancelColumnWidths[0], currentY + baseRowHeight).stroke();

        currentY += baseRowHeight;

        // Cancelled services data
        for (let i = 0; i < serviceRoutesData.cancelledServices.length; i++) {
          const cancelledService = serviceRoutesData.cancelledServices[i];
          
          // Draw row background
          doc.fillColor(i % 2 === 0 ? '#ffebee' : '#fce4ec');
          doc.rect(tableX, currentY, cancelTableWidth, baseRowHeight).fill();
          doc.fillColor('#000000');

          // Draw cell content
          doc.fontSize(9);
          
          // Part Name
          const cancelledPartName = cancelledService.partName;
          if (hasArabicText(cancelledPartName)) {
            renderSmartText(doc, cancelledPartName, tableX + 5, currentY + 5, { 
              width: cancelColumnWidths[0] - 10,
              height: baseRowHeight - 10,
              align: 'left'
            });
          } else {
            renderSmartText(doc, cancelledPartName, tableX + 5, currentY + 5, { 
              width: cancelColumnWidths[0] - 10,
              height: baseRowHeight - 10
            });
          }
          
          // Reason
          const reason = cancelledService.reason || 'No reason provided';
          if (hasArabicText(reason)) {
            renderSmartText(doc, reason, tableX + cancelColumnWidths[0] + 5, currentY + 5, { 
              width: cancelColumnWidths[1] - 10,
              height: baseRowHeight - 10,
              align: 'left'
            });
          } else {
            renderSmartText(doc, reason, tableX + cancelColumnWidths[0] + 5, currentY + 5, { 
              width: cancelColumnWidths[1] - 10,
              height: baseRowHeight - 10
            });
          }

          // Draw row borders
          doc.lineWidth(0.5);
          doc.rect(tableX, currentY, cancelTableWidth, baseRowHeight).stroke();
          doc.moveTo(tableX + cancelColumnWidths[0], currentY).lineTo(tableX + cancelColumnWidths[0], currentY + baseRowHeight).stroke();

          currentY += baseRowHeight;
        }

        // Update summary
        currentY += 10;
        doc.fontSize(10).font('Helvetica-Bold');
        const updatedSummaryText = `Total Parts: ${serviceRoutesData.summary.totalParts} | Total Services: ${serviceRoutesData.summary.totalServices} | Cancelled Parts: ${serviceRoutesData.summary.totalCancelledParts}`;
        doc.text(updatedSummaryText, tableX, currentY);
        currentY += 20;
      }
    }

    // Service summary in Arabic (only add spacing if we had service routes or other sections)
    const hasContentAbove = (invoice.payment_records && invoice.payment_records.length > 0) || 
                           (invoice.external_services && invoice.external_services.length > 0) || 
                           hasServiceRoutes;
    
    if (hasContentAbove) {
      currentY += 10;
    }

    // Service summary removed to save space - already shown in service details


    // Check if we need a new page for terms and conditions
    const hasExternalServices = invoice.external_services && invoice.external_services.length > 0;
    
    // Calculate remaining space on current page
    const remainingSpace = doc.page.height - currentY - 50; // 50 for bottom margin
    const minTermsSpace = 150; // Minimum space needed for terms section
    
    // Only add new page if we absolutely need it and are under page limit
    const needsNewPage = remainingSpace < (minTermsSpace - 30);

    if (needsNewPage && pageCount < maxPages) {
      doc.addPage();
      pageCount++;
      currentY = 40;
      contentOnCurrentPage = 0;
    } else if (!needsNewPage) {
      // Add minimal space before terms if staying on same page
      currentY += 10;
    }

    // Terms and Conditions Title - with proper spacing
    doc.fontSize(12).font('Helvetica-Bold');
    doc.text('Terms and Conditions', margin, currentY, { align: 'left' });
    doc.font('ArabicFont').fontSize(12);
    // Adjusted position to prevent overlap - moved further right
    doc.text('الشروط والأحكام', doc.page.width - margin, currentY, { align: 'right', width: 150, features: ['rtl'] });
    currentY += 20; // Increased spacing after title

    // Arabic Terms
    const arabicTerms = [
      '1 - خدمة tniaP hcuoT مجانا ولا تتحمل الشركة اي مسئولية عن نتيجة tniaP hcuoT - يجب العلم هناك فرق بين )tniaP hcuoT( و )tniaP tramS(',
      '2 - الشركة تتعهد في خدمة RDP حسب النسبة المذكورة ولا تتحمل اي مسئولية عن الخدوش العمل يتم على تعديل الضربة فقط',
      '3 - الشركة لا تتحمل اي مسئولية عن اي اعطال كهربائية او ميكانيكية داخل السيارة',
      '4 - احيانا يتطلب العمل على السيارة اجراء فتحة في بعض المناطق في السيارة اذا لزم الامر - احيانا نلتجأ الي فك بعض اجزاء السيارة',
      '5 - لا تتحمل الشركة اي مسؤلية عن اي خدش داخل السيارة لان شركة الاخطبوط الذهبي اختصاصها هيكل السيارة الخارجي',
      '6 - العربون المدفوع لا يسترد',
      '7 - من الممكن حدوث كسر في الصبغ، اذا حدث ستتكفل الشركة بعمل الصبغ الذكي مجانا',
      '8 - اذا كان هناك قطع غيار تالفة فالشركة غير معنية بها',
      '9 - في اغلب الاحيان يتم فك الديكور الداخلي للسيارة',
      '10 - الشركه غير مسئوله عن ازاله الجلاد او الحمايه عن اجزاء السياره',
      '11 - في بعض الاحيان ليتناسق اللون في الصبغ نلجأ الي سحب بعض من الصبغ الي القطعه الملاصقه للضربه',
      '21 - السعر غير شامل ثمن القطع',
      '31 - عند انتهاء العمل على السيارة واخبار العميل بذلك بعد استغراق 84 ساعة الشركة لا تتحمل اي مسؤلية عن الحوادث الطبيعية او وقوع اي اضرار بالسيارة',
      '41 - عند عمل صبغ سمارت بينت لاي قطعة في السيارة اجباري وضع لكر لكامل القطعة',
      '51 - عند انتهاء العمل على السياره واخبار العميل بذلك بعد استغراق 84 ساعه يحسب على كل يوم 05 درهم حساب باركنج',
      '61 - يجب العلم بأن تكنولوجيه الصبغ ان كانت سمارت بينت او صبغ كامل القطعة (بأستثناء القطع الوكالة) يكون على مراحل بدايه تعديل الضربة ثم معجون ثم برايمر ثم صبغ ثم اللكر',
      '71 - الشركه غير مسئوله عن درجه فحص القياس',
      '81 - في حالة امضاء العميل فانه يوافق على جميع بنود الخدمه',
      '91 - الشركه لا تتحمل اي مقتنيات داخل السياره',
      '02 - ضمان الصبغ خمس سنوات ولا يشمل الضمان على الحوادث'
    ];

    // English Terms
    const englishTerms = [
      '1 - The Touch Paint service is free of charge and the company does not bear any responsibility for the result of Touch Paint - you must know that there is a difference between (Touch Paint) and (Smart Paint)',
      '2 - The company undertakes to provide the PDR service according to the mentioned percentage and does not bear any responsibility for scratches. The work is done on adjusting the strike only',
      '3 - The company does not bear any responsibility for any electrical or mechanical malfunctions inside the car',
      '4 - Sometimes working on the car requires making an opening in some areas of the car if necessary - sometimes we resort to dismantling some parts of the car.',
      '5 - The company does not bear any responsibility for any scratch inside the car because Golden Octopus Company specializes in the exterior car body',
      '6 - The deposit paid is non-refundable',
      '7 - It is possible for the dye to break. If it happens, the company will take care of the smart dyeing for free',
      '8 - If there are damaged spare parts, the company is not concerned with them',
      '9 - In most cases, the interior decoration of the car is removed',
      '10 - The company is not responsible for removing the switch or protection from the car parts',
      '11 - Sometimes, in order for the color to be consistent in dyeing, we resort to pulling some of the dye onto the piece adjacent to the stroke.',
      '12 - The price does not include the price of the parts',
      '13 - When work on the car is completed and the customer is informed of this after 48 hours, the company does not bear any responsibility for natural accidents or any damage to the car.',
      '14 - When applying Smart Paint to any part of the car, it is mandatory to apply lacquer to the entire piece',
      '15 - When the work on the car is finished and the customer is informed of that after 48 hours, 50 dirhams are charged per day for parking.',
      '16 - It must be known that the dyeing technology, whether it is Smart Paint or dyeing the entire piece (except for the agency pieces), is in stages, starting with adjusting the stroke, then putty, then primer, then dye, then lacquer.',
      '17 - The company is not responsible for the degree of measurement inspection',
      '18 - If the customer signs, he agrees to all terms of service',
      '19 - The company is not responsible for any belongings inside the car',
      '20 - The paint is guaranteed for five years, but the warranty does not cover accidents.'
    ];

    // Display terms in both languages - balanced spacing for readability
    doc.fontSize(7); // Slightly larger font for better readability
    const baseLineHeight = 9; // Better line height
    const minSpacing = 16; // More comfortable minimum spacing
    const maxSpacing = 35; // Adequate maximum spacing
    const termsColumnWidth = (doc.page.width - 100) / 2;
    
    for (let i = 0; i < arabicTerms.length; i++) {
      // Balanced spacing calculation for better readability
      const arabicTextLength = arabicTerms[i].length;
      const englishTextLength = englishTerms[i].length;
      const maxTextLength = Math.max(arabicTextLength, englishTextLength);

      // Better estimation for 7pt font
      let estimatedLines = Math.ceil(maxTextLength / 55);
      estimatedLines = Math.max(1, estimatedLines);

      // Improved dynamic height with better spacing
      let dynamicHeight;
      if (estimatedLines <= 2) {
        dynamicHeight = minSpacing;
      } else if (estimatedLines <= 3) {
        dynamicHeight = minSpacing + 6;
      } else {
        dynamicHeight = Math.min(maxSpacing, minSpacing + (estimatedLines * 5));
      }
      
      // Check if we need a new page - respect 2 page limit
      if (currentY + dynamicHeight + 60 > doc.page.height && pageCount < maxPages) {
        doc.addPage();
        pageCount++;
        currentY = 40;
        contentOnCurrentPage = 0;
      } else if (currentY + dynamicHeight + 60 > doc.page.height && pageCount >= maxPages) {
        // If we've hit page limit, stop adding terms
        break;
      }

      // Arabic term (right side)
      doc.font('ArabicFont');
      doc.text(arabicTerms[i], doc.page.width - 60 - termsColumnWidth, currentY, { 
        align: 'right',
        width: termsColumnWidth,
        features: ['rtl']
      });

      // English term (left side)
      doc.font('Helvetica');
      doc.text(englishTerms[i], 60, currentY, { 
        width: termsColumnWidth
      });

      // Move to next line with dynamic spacing
      currentY += dynamicHeight;
    }

    // Calculate space for signature section
    const signatureSectionHeight = 100; // Compact signature section

    // Only add page if under limit and absolutely necessary
    if (currentY + signatureSectionHeight > doc.page.height - 20 && pageCount < maxPages) {
      doc.addPage();
      pageCount++;
      currentY = 40;
      contentOnCurrentPage = 0;
    } else if (currentY + signatureSectionHeight > doc.page.height - 20 && pageCount >= maxPages) {
      // If no space and at page limit, use compressed signature
      console.log('Warning: Using compressed signature due to 2-page limit');
    }
    
    // Minimal space between terms and signatures
    currentY += 15;

    // Compact thank you message
    doc.fontSize(9).font('Helvetica');
    doc.text('Thank you for your business!', 0, currentY, { align: 'center', width: doc.page.width });
    currentY += 20;

    // Authorized Signature and Customer Signature labels with lines
    const signatureLineWidth = 150;
    const signatureLineY = currentY;
    const authorizedX = 100;
    const customerX = doc.page.width - 100 - signatureLineWidth;

    // Lines for signatures
    doc.moveTo(authorizedX, signatureLineY).lineTo(authorizedX + signatureLineWidth, signatureLineY).stroke();
    doc.moveTo(customerX, signatureLineY).lineTo(customerX + signatureLineWidth, signatureLineY).stroke();

    // Compact signature labels
    doc.fontSize(10).font('Helvetica-Bold');
    doc.text('Authorized Signature', authorizedX, signatureLineY + 8, { width: signatureLineWidth, align: 'center' });
    doc.text('Customer Signature', customerX, signatureLineY + 8, { width: signatureLineWidth, align: 'center' });
    // Arabic labels
    doc.font('ArabicFont').fontSize(9);
    doc.text('توقيع المخول', authorizedX, signatureLineY + 20, { width: signatureLineWidth, align: 'center', features: ['rtl'] });
    doc.text('توقيع العميل', customerX, signatureLineY + 20, { width: signatureLineWidth, align: 'center', features: ['rtl'] });

    // Track the last content position
    lastContentY = signatureLineY + 35;

    // Log if we successfully kept to 2 pages
    if (pageCount <= maxPages) {
      console.log(`Invoice PDF generated successfully in ${pageCount} page(s)`);
    } else {
      console.log(`Warning: Invoice PDF exceeded ${maxPages} page limit (${pageCount} pages)`);
    }

    // Finalize PDF
    doc.end();
  } catch (error) {
    console.error('PDF Generation Error:', error);
    throw error;
  }
};

/**
 * Generate a PDF document for expense signature
 * @param {Object} expenseData - The expense data from the request
 * @param {Object} branchData - The branch data
 * @param {Object} userData - The user data
 * @param {Object} response - Express response object to pipe the PDF to
 */
const generateExpenseSignaturePDF = async (expenseData, branchData, userData, response) => {
  try {
    const doc = new PDFDocument({ 
      margin: 50,
      size: 'A4'
    });

    // Set response headers for PDF download
    response.setHeader('Content-Type', 'application/pdf');
    response.setHeader('Content-Disposition', 'attachment; filename="expense-signature-document.pdf"');
    
    // Pipe PDF to response
    doc.pipe(response);

    // Register Arabic font if available
    try {
      if (fs.existsSync(fontPathArabic)) {
        doc.registerFont('ArabicFont', fontPathArabic);
      }
    } catch (fontError) {
      console.warn('Arabic font not available:', fontError.message);
    }

    // Document dimensions
    const pageWidth = doc.page.width;
    const pageHeight = doc.page.height;
    const margin = 50;
    const contentWidth = pageWidth - (margin * 2);

    // Header Section
    doc.fontSize(20).font('Helvetica-Bold');
    doc.text('EXPENSE SIGNATURE DOCUMENT', margin, margin, { 
      align: 'center',
      width: contentWidth 
    });

    // Draw header line
    doc.moveTo(margin, margin + 40)
       .lineTo(pageWidth - margin, margin + 40)
       .stroke();

    let yPosition = margin + 60;

    // Company/Branch Information
    doc.fontSize(14).font('Helvetica-Bold');
    doc.text('Company Information', margin, yPosition);
    yPosition += 25;

    doc.fontSize(11);
    if (branchData?.name) {
      renderSmartText(doc, `Branch: ${branchData.name}`, margin, yPosition);
      yPosition += 15;
    }
    if (branchData?.address) {
      renderSmartText(doc, `Address: ${branchData.address}`, margin, yPosition);
      yPosition += 15;
    }
    if (branchData?.phone) {
      renderSmartText(doc, `Phone: ${branchData.phone}`, margin, yPosition);
      yPosition += 15;
    }

    yPosition += 20;

    // Expense Information Section
    doc.fontSize(14).font('Helvetica-Bold');
    doc.text('Expense Information', margin, yPosition);
    yPosition += 25;

    // Create expense info table
    const leftColumnX = margin;
    const rightColumnX = pageWidth / 2 + 30;
    const labelWidth = 120;
    
    doc.fontSize(11);
    
    // First row - Description and Date
    doc.font('Helvetica-Bold').text('Description:', leftColumnX, yPosition);
    const descriptionText = expenseData.description || expenseData.title || 'N/A';
    const descriptionWidth = rightColumnX - leftColumnX - labelWidth - 20;
    
    // Calculate the height of the description text
    const descriptionHeight = doc.heightOfString(descriptionText, {
      width: descriptionWidth
    });
    
    renderSmartText(doc, descriptionText, leftColumnX + labelWidth, yPosition, {
      width: descriptionWidth
    });
    
    doc.font('Helvetica-Bold').text('Date:', rightColumnX, yPosition);
    renderSmartText(doc, expenseData.date ? new Date(expenseData.date).toLocaleDateString('en-GB') : new Date().toLocaleDateString('en-GB'), rightColumnX + 60, yPosition);
    
    // Use the calculated height with minimum spacing
    yPosition += Math.max(25, descriptionHeight + 10);

    // Second row - Amount and Type
    doc.font('Helvetica-Bold').text('Amount:', leftColumnX, yPosition);
    renderSmartText(doc, `$${parseFloat(expenseData.amount || 0).toFixed(2)}`, leftColumnX + labelWidth, yPosition);
    
    doc.font('Helvetica-Bold').text('Type:', rightColumnX, yPosition);
    renderSmartText(doc, expenseData.expense_type || expenseData.category || 'N/A', rightColumnX + 60, yPosition);
    yPosition += 25;

    // Third row - Vendor and Payment Method
    let rowHeight = 25; // Default row height
    
    if (expenseData.vendor) {
      doc.font('Helvetica-Bold').text('Vendor:', leftColumnX, yPosition);
      const vendorWidth = rightColumnX - leftColumnX - labelWidth - 20;
      const vendorHeight = doc.heightOfString(expenseData.vendor, {
        width: vendorWidth
      });
      
      renderSmartText(doc, expenseData.vendor, leftColumnX + labelWidth, yPosition, {
        width: vendorWidth
      });
      
      rowHeight = Math.max(rowHeight, vendorHeight + 10);
    }
    
    if (expenseData.payment_method) {
      doc.font('Helvetica-Bold').text('Payment Method:', rightColumnX, yPosition);
      renderSmartText(doc, expenseData.payment_method, rightColumnX + 110, yPosition);
    }
    yPosition += rowHeight;

    // Fourth row - Invoice Number (full width if present)
    if (expenseData.invoice_number) {
      doc.font('Helvetica-Bold').text('Invoice Number:', leftColumnX, yPosition);
      renderSmartText(doc, expenseData.invoice_number, leftColumnX + labelWidth, yPosition);
      yPosition += 25;
    }

    // Employee Information
    yPosition += 25;
    doc.fontSize(14).font('Helvetica-Bold');
    doc.text('Employee Information', margin, yPosition);
    yPosition += 25;

    doc.fontSize(11);
    doc.font('Helvetica-Bold').text('Name:', leftColumnX, yPosition);
    renderSmartText(doc, `${userData.first_name || ''} ${userData.last_name || ''}`.trim() || 'N/A', leftColumnX + 60, yPosition);
    
    doc.font('Helvetica-Bold').text('Email:', rightColumnX, yPosition);
    renderSmartText(doc, userData.email || 'N/A', rightColumnX + 60, yPosition);
    yPosition += 25;

    if (userData.employee_id) {
      doc.font('Helvetica-Bold').text('Employee ID:', leftColumnX, yPosition);
      renderSmartText(doc, userData.employee_id, leftColumnX + 100, yPosition);
      yPosition += 25;
    }

    // Additional Details Section
    if (expenseData.notes || expenseData.description) {
      yPosition += 25;
      doc.fontSize(14).font('Helvetica-Bold');
      doc.text('Additional Notes', margin, yPosition);
      yPosition += 25;

      doc.fontSize(11);
      const notesText = expenseData.notes || expenseData.description || '';
      
      // Calculate text height properly
      const textHeight = doc.heightOfString(notesText, { 
        width: contentWidth - 20,
        align: 'left'
      });
      
      renderSmartText(doc, notesText, margin, yPosition, { 
        width: contentWidth - 20,
        align: 'left'
      });
      yPosition += Math.max(25, textHeight + 10);
    }

    // Expense Details Box
    yPosition += 25;
    doc.rect(margin, yPosition, contentWidth, 80).stroke();
    
    doc.fontSize(12).font('Helvetica-Bold');
    doc.text('Expense Declaration', margin + 10, yPosition + 10);
    
    doc.fontSize(10).font('Helvetica');
    doc.text('I hereby certify that this expense was incurred for legitimate business purposes', 
             margin + 10, yPosition + 30, { width: contentWidth - 20 });
    doc.text('and that all information provided above is accurate and complete.',
             margin + 10, yPosition + 45, { width: contentWidth - 20 });

    // Signature Section
    yPosition += 120;
    
    // Ensure we have enough space for signatures, add new page if needed
    if (yPosition > pageHeight - 200) {
      doc.addPage();
      yPosition = margin;
    }

    doc.fontSize(14).font('Helvetica-Bold');
    doc.text('Signatures', margin, yPosition);
    yPosition += 40;

    // Employee signature
    const signatureWidth = 200;
    const signatureSpacing = (contentWidth - (signatureWidth * 2)) / 3;
    
    const employeeSignatureX = margin + signatureSpacing;
    const approverSignatureX = employeeSignatureX + signatureWidth + signatureSpacing;

    // Employee signature line
    doc.moveTo(employeeSignatureX, yPosition + 50)
       .lineTo(employeeSignatureX + signatureWidth, yPosition + 50)
       .stroke();

    // Approver signature line  
    doc.moveTo(approverSignatureX, yPosition + 50)
       .lineTo(approverSignatureX + signatureWidth, yPosition + 50)
       .stroke();

    // Signature labels
    doc.fontSize(10).font('Helvetica');
    doc.text('Employee Signature', employeeSignatureX, yPosition + 60, { 
      width: signatureWidth, 
      align: 'center' 
    });
    doc.text('Date: _______________', employeeSignatureX, yPosition + 75, { 
      width: signatureWidth, 
      align: 'center' 
    });

    doc.text('Supervisor/Manager Signature', approverSignatureX, yPosition + 60, { 
      width: signatureWidth, 
      align: 'center' 
    });
    doc.text('Date: _______________', approverSignatureX, yPosition + 75, { 
      width: signatureWidth, 
      align: 'center' 
    });

    // Footer
    yPosition += 120;
    doc.fontSize(8).font('Helvetica');
    doc.text('This document serves as a formal expense claim and requires proper authorization before processing.',
             margin, yPosition, { 
               width: contentWidth, 
               align: 'center' 
             });

    // Document generation timestamp
    yPosition += 20;
    doc.text(`Document generated on: ${new Date().toLocaleString()}`,
             margin, yPosition, { 
               width: contentWidth, 
               align: 'center' 
             });

    // Finalize PDF
    doc.end();
  } catch (error) {
    console.error('Expense PDF Generation Error:', error);
    throw error;
  }
};

module.exports = {
  generateInvoicePDF,
  generateInvoicePDFFromDB,
  getServiceRoutesForInvoice,
  generateExpenseSignaturePDF
};
