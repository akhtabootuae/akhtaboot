/**
 * Script to verify that seeded permissions match the updated case routes requirements
 */

const { MongoClient } = require('mongodb');
const { getDefaultPermissionsForRole } = require('./config/permissions');

// MongoDB connection string from environment
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/new_api';

/**
 * Verify seeded permissions against route requirements
 */
async function verifySeededPermissions() {
  let client;
  
  try {
    console.log('🔍 Verifying seeded permissions against case route requirements...\n');
    
    // Connect to MongoDB
    client = new MongoClient(MONGODB_URI);
    await client.connect();
    const db = client.db();
    
    // Get all users from database
    const users = await db.collection('users').find({}).toArray();
    
    console.log(`Found ${users.length} users in database\n`);
    
    // Required permissions for case routes
    const requiredCasePermissions = [
      'create_case',          // POST /cases
      'view_all_cases',       // GET /cases  
      'view_case',            // GET /cases/:id
      'view_case_stats',      // GET /cases/stats
      'update_case',          // PUT /cases/:id
      'resolve_case',         // Status change to resolved/closed
      'close_case',           // Status change to closed
      'add_case_notes',       // POST /cases/:id/notes
      'manage_case_attachments', // POST /cases/:id/attachments
      'delete_case'           // DELETE /cases/:id
    ];
    
    // Check each role's permissions
    const roles = ['Admin', 'Supervisor', 'Technician'];
    
    for (const roleName of roles) {
      console.log(`\n📋 Checking ${roleName} role permissions:`);
      console.log('=' .repeat(50));
      
      // Get default permissions for this role
      const defaultPermissions = getDefaultPermissionsForRole(roleName);
      
      // Check case-specific permissions
      console.log('\n🔐 Case Management Permissions:');
      requiredCasePermissions.forEach(permission => {
        const hasPermission = defaultPermissions.find(p => 
          p.permission_name === permission && p.granted === true
        );
        
        const status = hasPermission ? '✅' : '❌';
        console.log(`  ${status} ${permission}`);
      });
      
      // Find users with this role in database
      const roleUsers = users.filter(user => user.role_name === roleName);
      
      if (roleUsers.length > 0) {
        console.log(`\n👤 Found ${roleUsers.length} user(s) with ${roleName} role:`);
        
        roleUsers.forEach(user => {
          console.log(`  • ${user.first_name} ${user.last_name} (${user.email})`);
          
          // Check if user has all required case permissions
          const missingPermissions = requiredCasePermissions.filter(requiredPerm => {
            const userHasPermission = user.permissions?.find(p => 
              p.permission_name === requiredPerm && p.granted === true
            );
            return !userHasPermission;
          });
          
          if (missingPermissions.length > 0) {
            console.log(`    ⚠️  Missing permissions: ${missingPermissions.join(', ')}`);
          } else {
            console.log(`    ✅ Has all required case permissions`);
          }
        });
      } else {
        console.log(`\n⚠️  No users found with ${roleName} role in database`);
      }
    }
    
    // Check if there are any test users for authentication
    console.log('\n\n🔑 Test User Authentication Setup:');
    console.log('=' .repeat(50));
    
    const testEmails = [
      'admin@test.com',
      'supervisor@test.com', 
      'technician@test.com',
      'admin2@example.com',
      'supervisor@example.com',
      'technician1@example.com'
    ];
    
    for (const email of testEmails) {
      const user = users.find(u => u.email === email);
      if (user) {
        console.log(`✅ ${email} (${user.role_name}) - Ready for testing`);
      } else {
        console.log(`❌ ${email} - Not found in database`);
      }
    }
    
    // Summary recommendations
    console.log('\n\n📊 Summary & Recommendations:');
    console.log('=' .repeat(50));
    
    const adminPerms = getDefaultPermissionsForRole('Admin');
    const supervisorPerms = getDefaultPermissionsForRole('Supervisor');
    const technicianPerms = getDefaultPermissionsForRole('Technician');
    
    const adminCasePerms = adminPerms.filter(p => requiredCasePermissions.includes(p.permission_name) && p.granted);
    const supervisorCasePerms = supervisorPerms.filter(p => requiredCasePermissions.includes(p.permission_name) && p.granted);
    const technicianCasePerms = technicianPerms.filter(p => requiredCasePermissions.includes(p.permission_name) && p.granted);
    
    console.log(`\n• Admin: ${adminCasePerms.length}/${requiredCasePermissions.length} case permissions`);
    console.log(`• Supervisor: ${supervisorCasePerms.length}/${requiredCasePermissions.length} case permissions`);
    console.log(`• Technician: ${technicianCasePerms.length}/${requiredCasePermissions.length} case permissions`);
    
    // Check for missing critical permissions
    const technicianMissing = requiredCasePermissions.filter(perm => 
      !technicianPerms.find(p => p.permission_name === perm && p.granted)
    );
    
    if (technicianMissing.length > 0) {
      console.log(`\n⚠️  Technician role is missing: ${technicianMissing.join(', ')}`);
      console.log('   Consider adding view_all_cases and view_case_stats for better case management');
    }
    
    console.log('\n✅ Permission verification completed!');
    
  } catch (error) {
    console.error('❌ Error verifying permissions:', error);
  } finally {
    if (client) {
      await client.close();
    }
  }
}

// Run verification if this file is executed directly
if (require.main === module) {
  verifySeededPermissions();
}

module.exports = { verifySeededPermissions };
