# Variation API Documentation

Variations represent different service types that can be offered, each with its own set of stages.

## Schema

```javascript
{
  "_id": ObjectId,
  "code": String,            // Unique service code (e.g. 'PDR')
  "description": String,     // What this service entails
  "defaultLaborHours": Double, // Estimated hours if needed
  "defaultStages": [ObjectId], // Ordered list of stage _id's for this service
  "created_at": Date,
  "updated_at": Date
}
```

## Endpoints

### Get All Variations

```
GET /api/variations
```

Returns a list of all available service variations.

**Auth Required**: Yes (Any authenticated user)

**Response Example**:

```javascript
[
  {
    "_id": "6078f3a56821e33d1c21f260",
    "code": "PDR",
    "description": "Paintless Dent Repair",
    "defaultLaborHours": 2.5,
    "defaultStages": [
      "6078f2a56821e33d1c21f255",
      "6078f2c96821e33d1c21f256",
      "6078f2e56821e33d1c21f257"
    ],
    "created_at": "2025-05-22T10:40:15.000Z",
    "updated_at": "2025-05-22T10:40:15.000Z"
  },
  {
    "_id": "6078f3d26821e33d1c21f261",
    "code": "PNT",
    "description": "Paint Service",
    "defaultLaborHours": 4.0,
    "defaultStages": [
      "6078f2a56821e33d1c21f255",
      "6078f3156821e33d1c21f258",
      "6078f2e56821e33d1c21f257"
    ],
    "created_at": "2025-05-22T10:42:22.000Z",
    "updated_at": "2025-05-22T10:42:22.000Z"
  }
]
```

### Get Variation by ID

```
GET /api/variations/:id
```

Returns a single variation by its ID.

**Auth Required**: Yes (Any authenticated user)

**URL Parameters**:
- `id` - The MongoDB ObjectId of the variation

**Query Parameters**:
- `include=stages` - Optional. Include full stage objects instead of just IDs.

**Response Example** (without stages included):

```javascript
{
  "_id": "6078f3a56821e33d1c21f260",
  "code": "PDR",
  "description": "Paintless Dent Repair",
  "defaultLaborHours": 2.5,
  "defaultStages": [
    "6078f2a56821e33d1c21f255",
    "6078f2c96821e33d1c21f256",
    "6078f2e56821e33d1c21f257"
  ],
  "created_at": "2025-05-22T10:40:15.000Z",
  "updated_at": "2025-05-22T10:40:15.000Z"
}
```

**Response Example** (with stages included - `?include=stages`):

```javascript
{
  "_id": "6078f3a56821e33d1c21f260",
  "code": "PDR",
  "description": "Paintless Dent Repair",
  "defaultLaborHours": 2.5,
  "defaultStages": [
    "6078f2a56821e33d1c21f255",
    "6078f2c96821e33d1c21f256",
    "6078f2e56821e33d1c21f257"
  ],
  "created_at": "2025-05-22T10:40:15.000Z",
  "updated_at": "2025-05-22T10:40:15.000Z",
  "stages": [
    {
      "_id": "6078f2a56821e33d1c21f255",
      "name": "Disassembly",
      "description": "Remove damaged panels and components",
      "order": 1,
      "created_at": "2025-05-22T10:30:45.000Z",
      "updated_at": "2025-05-22T10:30:45.000Z"
    },
    {
      "_id": "6078f2c96821e33d1c21f256",
      "name": "Repair",
      "description": "Perform necessary repairs on components",
      "order": 2,
      "created_at": "2025-05-22T10:31:22.000Z",
      "updated_at": "2025-05-22T10:31:22.000Z"
    },
    {
      "_id": "6078f2e56821e33d1c21f257",
      "name": "Reassembly",
      "description": "Put all components back together",
      "order": 3,
      "created_at": "2025-05-22T10:32:15.000Z",
      "updated_at": "2025-05-22T10:35:30.000Z"
    }
  ]
}
```

### Get Variation by Code

```
GET /api/variations/code/:code
```

Returns a single variation by its unique code.

**Auth Required**: Yes (Any authenticated user)

**URL Parameters**:
- `code` - The unique service code (e.g. 'PDR')

**Response Example**:

```javascript
{
  "_id": "6078f3a56821e33d1c21f260",
  "code": "PDR",
  "description": "Paintless Dent Repair",
  "defaultLaborHours": 2.5,
  "defaultStages": [
    "6078f2a56821e33d1c21f255",
    "6078f2c96821e33d1c21f256",
    "6078f2e56821e33d1c21f257"
  ],
  "created_at": "2025-05-22T10:40:15.000Z",
  "updated_at": "2025-05-22T10:40:15.000Z"
}
```

### Create New Variation

```
POST /api/variations
```

Creates a new service variation.

**Auth Required**: Yes (Admin or user with `manage_variations` permission)

**Request Body**:

```javascript
{
  "code": "BMP",
  "description": "Bumper Replacement",
  "defaultLaborHours": 3.0,
  "defaultStages": [
    "6078f2a56821e33d1c21f255",
    "6078f3156821e33d1c21f258",
    "6078f2e56821e33d1c21f257"
  ]
}
```

**Response Example**:

```javascript
{
  "_id": "6078f4156821e33d1c21f262",
  "code": "BMP",
  "description": "Bumper Replacement",
  "defaultLaborHours": 3.0,
  "defaultStages": [
    "6078f2a56821e33d1c21f255",
    "6078f3156821e33d1c21f258",
    "6078f2e56821e33d1c21f257"
  ],
  "created_at": "2025-05-22T10:45:30.000Z",
  "updated_at": "2025-05-22T10:45:30.000Z"
}
```

### Update Variation

```
PUT /api/variations/:id
```

Updates an existing service variation.

**Auth Required**: Yes (Admin or user with `manage_variations` permission)

**URL Parameters**:
- `id` - The MongoDB ObjectId of the variation

**Request Body** (all fields optional):

```javascript
{
  "description": "Complete Bumper Replacement",
  "defaultLaborHours": 3.5,
  "defaultStages": [
    "6078f2a56821e33d1c21f255",
    "6078f3156821e33d1c21f258",
    "6078f3256821e33d1c21f259", 
    "6078f2e56821e33d1c21f257"
  ]
}
```

**Response Example**:

```javascript
{
  "_id": "6078f4156821e33d1c21f262",
  "code": "BMP",
  "description": "Complete Bumper Replacement",
  "defaultLaborHours": 3.5,
  "defaultStages": [
    "6078f2a56821e33d1c21f255",
    "6078f3156821e33d1c21f258",
    "6078f3256821e33d1c21f259",
    "6078f2e56821e33d1c21f257"
  ],
  "created_at": "2025-05-22T10:45:30.000Z",
  "updated_at": "2025-05-22T10:48:15.000Z"
}
```

### Delete Variation

```
DELETE /api/variations/:id
```

Deletes a service variation.

**Auth Required**: Yes (Admin or user with `manage_variations` permission)

**URL Parameters**:
- `id` - The MongoDB ObjectId of the variation

**Response Example**:

```javascript
{
  "message": "Variation deleted successfully"
}
```

**Error Responses**:

If the variation is used in any work orders:
```javascript
{
  "message": "Cannot delete variation that is used in work orders",
  "workOrders": [
    {
      "_id": "6078f5a56821e33d1c21f270",
      "number": "WO-2025-0123"
    }
  ]
}
```
