const { ObjectId } = require('mongodb');
const Expense = require('../models/Expense');

/**
 * Overtime Expense Automation Service
 * Automatically creates expense records for overtime hours when timesheets are approved
 */
class OvertimeExpenseService {

  /**
   * Process overtime from an approved timesheet
   * @param {Object} db Database connection
   * @param {Object} timesheet Approved timesheet
   * @returns {Object|null} Created expense or null if no overtime
   */
  static async processOvertimeFromTimesheet(db, timesheet) {
    // Calculate overtime hours (anything over 8 hours)
    const totalHours = timesheet.total_hours || 0;
    const regularHours = Math.min(totalHours, 8);
    const overtimeHours = Math.max(totalHours - 8, 0);

    if (overtimeHours <= 0) {
      return null; // No overtime to process
    }

    // Get employee details
    const employee = await db.collection('users').findOne({
      _id: new ObjectId(timesheet.employee_id)
    });

    if (!employee || !employee.payroll_info?.monthly_salary) {
      console.warn(`Cannot process overtime for employee ${timesheet.employee_id}: no monthly salary found`);
      return null;
    }

    // Calculate overtime payment amount
    const monthlySalary = employee.payroll_info.monthly_salary;
    const workingDaysPerMonth = 22; // Standard working days assumption
    const dailyRate = monthlySalary / workingDaysPerMonth;
    const hourlyRate = dailyRate / 8;
    const overtimeRate = hourlyRate * 1.5; // 1.5x multiplier for overtime
    const overtimeAmount = overtimeHours * overtimeRate;

    // Create expense data
    const expenseData = {
      title: `Overtime Compensation - ${employee.first_name} ${employee.last_name}`,
      description: `Overtime payment for ${overtimeHours} hours on ${timesheet.work_date.toISOString().split('T')[0]}`,
      amount: overtimeAmount,
      expense_type: 'overtime_compensation',
      date: timesheet.work_date,
      created_by: timesheet.approved_by || timesheet.created_by,
      branch_id: employee.branch?.branch_id,
      vendor: `${employee.first_name} ${employee.last_name}`,
      notes: `Auto-generated from timesheet ${timesheet._id}. Regular hours: ${regularHours}, Overtime hours: ${overtimeHours}, Overtime rate: AED ${overtimeRate.toFixed(2)}/hour`,
      // Create a simple invoice image placeholder since it's required
      invoice_image: {
        s3Key: 'system/overtime-receipt-placeholder.png',
        url: '/placeholder/overtime-receipt.png',
        filename: 'overtime-receipt-placeholder.png',
        mimetype: 'image/png',
        size: 1024,
        uploadedAt: new Date()
      },
      // Link to the timesheet for reference
      timesheet_id: timesheet._id,
      target_employee_id: timesheet.employee_id
    };

    try {
      // Create the expense record
      const createdExpense = await Expense.create(db, expenseData);
      
      console.log(`Created overtime expense ${createdExpense.expense_number} for employee ${employee.first_name} ${employee.last_name} - AED ${overtimeAmount.toFixed(2)}`);
      
      return createdExpense;
    } catch (error) {
      console.error('Error creating overtime expense:', error);
      throw error;
    }
  }

  /**
   * Process overtime for multiple approved timesheets
   * @param {Object} db Database connection
   * @param {Array} timesheets Array of approved timesheets
   * @returns {Object} Summary of processed overtime
   */
  static async processBatchOvertimeFromTimesheets(db, timesheets) {
    const results = {
      processed: 0,
      skipped: 0,
      errors: [],
      total_overtime_amount: 0
    };

    for (const timesheet of timesheets) {
      try {
        const expense = await this.processOvertimeFromTimesheet(db, timesheet);
        if (expense) {
          results.processed++;
          results.total_overtime_amount += expense.amount;
        } else {
          results.skipped++;
        }
      } catch (error) {
        results.errors.push({
          timesheet_id: timesheet._id,
          employee_id: timesheet.employee_id,
          error: error.message
        });
      }
    }

    return results;
  }

  /**
   * Hook to automatically process overtime when timesheet is approved
   * Call this from timesheet approval workflow
   * @param {Object} db Database connection
   * @param {String} timesheetId Timesheet ID that was approved
   */
  static async onTimesheetApproved(db, timesheetId) {
    try {
      // Get the approved timesheet
      const timesheet = await db.collection('timesheets').findOne({
        _id: new ObjectId(timesheetId),
        status: 'approved'
      });

      if (!timesheet) {
        console.warn(`Timesheet ${timesheetId} not found or not approved`);
        return null;
      }

      // Check if overtime expense already exists for this timesheet
      const existingExpense = await db.collection('expenses').findOne({
        timesheet_id: new ObjectId(timesheetId),
        expense_type: 'overtime_compensation'
      });

      if (existingExpense) {
        console.log(`Overtime expense already exists for timesheet ${timesheetId}`);
        return existingExpense;
      }

      // Process overtime
      return await this.processOvertimeFromTimesheet(db, timesheet);
    } catch (error) {
      console.error(`Error processing overtime for timesheet ${timesheetId}:`, error);
      throw error;
    }
  }

  /**
   * Find overtime expenses for a specific employee
   * @param {Object} db Database connection
   * @param {String} employeeId Employee ID
   * @param {Object} options Query options
   * @returns {Array} Array of overtime expense records
   */
  static async findOvertimeExpensesByEmployee(db, employeeId, options = {}) {
    const filter = {
      expense_type: 'overtime_compensation',
      target_employee_id: new ObjectId(employeeId)
    };

    if (options.startDate || options.endDate) {
      filter.date = {};
      if (options.startDate) filter.date.$gte = new Date(options.startDate);
      if (options.endDate) filter.date.$lte = new Date(options.endDate);
    }

    return await db.collection('expenses')
      .find(filter)
      .sort({ date: -1 })
      .limit(options.limit || 50)
      .skip(options.skip || 0)
      .toArray();
  }

  /**
   * Get overtime expense summary for a date range
   * @param {Object} db Database connection
   * @param {Object} options Filter options
   * @returns {Object} Summary statistics
   */
  static async getOvertimeExpenseSummary(db, options = {}) {
    const matchStage = {
      expense_type: 'overtime_compensation'
    };

    if (options.employeeId) {
      matchStage.target_employee_id = new ObjectId(options.employeeId);
    }

    if (options.startDate || options.endDate) {
      matchStage.date = {};
      if (options.startDate) matchStage.date.$gte = new Date(options.startDate);
      if (options.endDate) matchStage.date.$lte = new Date(options.endDate);
    }

    const pipeline = [
      { $match: matchStage },
      {
        $group: {
          _id: null,
          total_overtime_expenses: { $sum: 1 },
          total_overtime_amount: { $sum: '$amount' },
          average_overtime_amount: { $avg: '$amount' }
        }
      }
    ];

    const result = await db.collection('expenses').aggregate(pipeline).toArray();
    
    return result[0] || {
      total_overtime_expenses: 0,
      total_overtime_amount: 0,
      average_overtime_amount: 0
    };
  }
}

module.exports = OvertimeExpenseService;