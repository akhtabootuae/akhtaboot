const crypto = require('crypto');

/**
 * Message Encryption Service
 * Handles AES-256-CBC encryption/decryption for message content
 */
class MessageEncryption {
  constructor() {
    // Use a consistent key from environment or generate once and display for storage
    this.encryptionKey = this.getOrCreateEncryptionKey();
    this.algorithm = 'aes-256-cbc';
  }

  /**
   * Get or create a persistent encryption key
   * @returns {String} Base64 encoded encryption key
   */
  getOrCreateEncryptionKey() {
    // First, try to get key from environment
    if (process.env.MESSAGE_ENCRYPTION_KEY) {
      console.log('✅ Using MESSAGE_ENCRYPTION_KEY from environment');
      return process.env.MESSAGE_ENCRYPTION_KEY;
    }
    
    // If no key in environment, throw an error (production safety)
    throw new Error('MESSAGE_ENCRYPTION_KEY is required in environment variables. Please add it to your .env file.');

  }

  /**
   * Get the encryption key as a Buffer
   * @returns {Buffer} Encryption key buffer
   */
  getKeyBuffer() {
    return Buffer.from(this.encryptionKey, 'base64');
  }

  /**
   * Encrypt message content
   * @param {String} plaintext The message content to encrypt
   * @returns {String} Encrypted content with IV and auth tag (base64 encoded)
   */
  encrypt(plaintext) {
    try {
      if (!plaintext || typeof plaintext !== 'string') {
        throw new Error('Invalid plaintext for encryption');
      }

      // Generate a random initialization vector
      const iv = crypto.randomBytes(16); // 16 bytes for AES
      
      // Get the key as a buffer (32 bytes for AES-256)
      const key = this.getKeyBuffer();
      
      // Create cipher using createCipheriv (the current recommended method)
      const cipher = crypto.createCipheriv('aes-256-cbc', key, iv);
      
      // Encrypt the plaintext
      let encrypted = cipher.update(plaintext, 'utf8', 'hex');
      encrypted += cipher.final('hex');
      
      // Combine IV and encrypted data
      const result = iv.toString('hex') + ':' + encrypted;
      
      return Buffer.from(result).toString('base64');
    } catch (error) {
      console.error('Encryption error:', error);
      throw new Error('Failed to encrypt message content');
    }
  }

  /**
   * Decrypt message content
   * @param {String} encryptedData Base64 encoded encrypted content with IV and auth tag
   * @returns {String} Decrypted plaintext content
   */
  decrypt(encryptedData) {
    try {
      if (!encryptedData || typeof encryptedData !== 'string') {
        throw new Error('Invalid encrypted data for decryption');
      }

      // Decode from base64
      const decoded = Buffer.from(encryptedData, 'base64').toString();
      const parts = decoded.split(':');
      
      if (parts.length !== 2) {
        throw new Error('Invalid encrypted data format');
      }
      
      const iv = Buffer.from(parts[0], 'hex');
      const encrypted = parts[1];
      
      // Get the key as a buffer
      const key = this.getKeyBuffer();
      
      // Create decipher using createDecipheriv (the current recommended method)
      const decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);
      
      // Decrypt the data
      let decrypted = decipher.update(encrypted, 'hex', 'utf8');
      decrypted += decipher.final('utf8');
      
      return decrypted;
    } catch (error) {
      console.error('Decryption error:', error);
      throw new Error('Failed to decrypt message content');
    }
  }

  /**
   * Create a preview of the message content (for last_message in conversations)
   * This returns first 100 characters of decrypted content
   * @param {String} encryptedData Encrypted message content
   * @returns {String} Truncated preview of the message
   */
  createPreview(encryptedData) {
    try {
      const decrypted = this.decrypt(encryptedData);
      return decrypted.length > 100 ? decrypted.substring(0, 100) + '...' : decrypted;
    } catch (error) {
      return '[Message preview unavailable]';
    }
  }

  /**
   * Validate that content can be encrypted/decrypted
   * @param {String} content Content to validate
   * @returns {Boolean} True if content is valid for encryption
   */
  validateContent(content) {
    if (!content || typeof content !== 'string') {
      return false;
    }
    
    // Check if content is reasonable length (max 10KB per message)
    if (content.length > 10240) {
      return false;
    }
    
    return true;
  }
}

// Create singleton instance
const messageEncryption = new MessageEncryption();

module.exports = messageEncryption;
