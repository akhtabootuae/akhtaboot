const AWS = require('aws-sdk');

// Safely initialize S3 client - only if credentials are available
let s3 = null;

if (process.env.AWS_ACCESS_KEY_ID && process.env.AWS_SECRET_ACCESS_KEY && process.env.AWS_REGION) {
  s3 = new AWS.S3({
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
    region: process.env.AWS_REGION
  });
} else {
  console.warn('WARNING: AWS S3 credentials not configured. File uploads will be unavailable.');
}

module.exports = s3;