const { Server } = require('socket.io');
const jwt = require('jsonwebtoken');

class WebSocketService {
  constructor() {
    this.io = null;
    this.userSockets = new Map(); // userId -> socketId mapping
  }

  initialize(server) {
    this.io = new Server(server, {
      cors: {
        origin: process.env.ALLOW_ORIGINS ? process.env.ALLOW_ORIGINS.split(',') : ['http://localhost:3001'],
        credentials: true
      }
    });

    // Authentication middleware
    this.io.use((socket, next) => {
      const token = socket.handshake.auth.token || socket.handshake.headers.authorization?.replace('Bearer ', '');
      
      if (!token) {
        console.error('WebSocket: No authentication token provided');
        return next(new Error('Authentication error: No token provided'));
      }

      try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        
        // Handle different JWT token structures - your system uses payload.user.id
        socket.userId = decoded.user?.id || decoded.id || decoded._id || decoded.userId || decoded.user_id;
        
        if (!socket.userId) {
          console.error('WebSocket: No user ID found in token. Token structure:', decoded);
          return next(new Error('Authentication error: Invalid token structure'));
        }
        
        console.log(`WebSocket: User ${socket.userId} authenticated successfully`);
        next();
      } catch (err) {
        console.error('WebSocket: Token verification failed:', err.message);
        next(new Error('Authentication error: Invalid token'));
      }
    });

    this.io.on('connection', (socket) => {
      // Safety check for userId
      if (!socket.userId) {
        console.error('WebSocket: Connection attempt without valid userId');
        socket.disconnect();
        return;
      }

      console.log(`User ${socket.userId} connected`);
      
      // Store user socket mapping (ensure consistent ID format)
      this.userSockets.set(socket.userId.toString(), socket.id);

      // Join user to their personal room
      socket.join(`user_${socket.userId}`);

      // Handle joining conversation rooms
      socket.on('join_conversation', (conversationId) => {
        socket.join(`conversation_${conversationId}`);
        console.log(`User ${socket.userId} joined conversation ${conversationId}`);
      });

      // Handle leaving conversation rooms
      socket.on('leave_conversation', (conversationId) => {
        socket.leave(`conversation_${conversationId}`);
        console.log(`User ${socket.userId} left conversation ${conversationId}`);
      });

      socket.on('disconnect', () => {
        console.log(`User ${socket.userId} disconnected`);
        this.userSockets.delete(socket.userId.toString());
      });
    });

    console.log('WebSocket server initialized');
  }

  // Notify users in a conversation about new message
  notifyNewMessage(conversationId, message, participants, senderId = null) {
    if (!this.io) return;

    // Send to conversation room (preferred method) - exclude sender
    const roomName = `conversation_${conversationId}`;
    if (senderId) {
      // Get sender's socket to exclude them from room broadcast
      const senderSocketId = this.userSockets.get(senderId.toString());
      if (senderSocketId) {
        // Broadcast to all room members except the sender
        this.io.to(roomName).except(senderSocketId).emit('new_message', {
          conversationId,
          message
        });
      } else {
        // Sender not connected, broadcast to all room members
        this.io.to(roomName).emit('new_message', {
          conversationId,
          message
        });
      }
    } else {
      // No sender specified, broadcast to all room members
      this.io.to(roomName).emit('new_message', {
        conversationId,
        message
      });
    }

    // Fallback: notify individual users who might not be in the room yet (excluding sender)
    participants.forEach(participant => {
      const userId = participant.user_id.toString();
      
      // Skip the sender to avoid duplicate messages
      if (senderId && userId === senderId.toString()) {
        return;
      }
      
      const socketId = this.userSockets.get(userId);
      if (socketId) {
        // Check if user is already in the conversation room to avoid duplicates
        const socket = this.io.sockets.sockets.get(socketId);
        if (socket && !socket.rooms.has(roomName)) {
          // User not in room, send individual notification
          this.io.to(socketId).emit('new_message', {
            conversationId,
            message
          });
        }
      }
    });
  }

  // Notify user about new conversation
  notifyNewConversation(userId, conversation) {
    if (!this.io) return;

    const socketId = this.userSockets.get(userId.toString());
    if (socketId) {
      this.io.to(socketId).emit('new_conversation', conversation);
    }
  }

  // Auto-join users to conversation room when they get added
  joinUsersToConversation(conversationId, userIds) {
    if (!this.io) return;

    userIds.forEach(userId => {
      const socketId = this.userSockets.get(userId.toString());
      if (socketId) {
        const socket = this.io.sockets.sockets.get(socketId);
        if (socket) {
          socket.join(`conversation_${conversationId}`);
          console.log(`Auto-joined user ${userId} to conversation ${conversationId}`);
        }
      }
    });
  }

  // Remove user from conversation room when they leave or are removed
  removeUserFromConversation(conversationId, userId) {
    if (!this.io) return;

    const socketId = this.userSockets.get(userId.toString());
    if (socketId) {
      const socket = this.io.sockets.sockets.get(socketId);
      if (socket) {
        socket.leave(`conversation_${conversationId}`);
        console.log(`Removed user ${userId} from conversation ${conversationId}`);
      }
    }
  }

  // Notify user that they were removed from a group
  notifyUserRemovedFromGroup(userId, conversationId, groupTitle) {
    if (!this.io) return;

    const socketId = this.userSockets.get(userId.toString());
    if (socketId) {
      this.io.to(socketId).emit('removed_from_group', {
        conversationId,
        groupTitle,
        message: `You have been removed from the group "${groupTitle}"`
      });
      console.log(`Notified user ${userId} about removal from group ${conversationId}`);
    }
  }

  // Notify user that an announcement was deleted
  notifyAnnouncementDeleted(userId, conversationId, announcementTitle) {
    if (!this.io) return;

    const socketId = this.userSockets.get(userId.toString());
    if (socketId) {
      this.io.to(socketId).emit('announcement_deleted', {
        conversationId,
        announcementTitle,
        message: `The announcement "${announcementTitle}" has been deleted`
      });
      console.log(`Notified user ${userId} about deleted announcement ${conversationId}`);
    }
  }

  // Remove all users from a conversation room (for when conversation is deleted)
  removeAllUsersFromConversation(conversationId) {
    if (!this.io) return;

    // Get all sockets in the conversation room
    const room = this.io.sockets.adapter.rooms.get(`conversation_${conversationId}`);
    if (room) {
      // Remove all sockets from the room
      room.forEach(socketId => {
        const socket = this.io.sockets.sockets.get(socketId);
        if (socket) {
          socket.leave(`conversation_${conversationId}`);
        }
      });
      console.log(`Removed all users from conversation ${conversationId}`);
    }
  }

  // Get online users count
  getOnlineUsersCount() {
    return this.userSockets.size;
  }

  // Work Order Events - START

  // 1. Work Order Created
  notifyWorkOrderCreated(workOrder, targetUsers = null) {
    if (!this.io) return;
    
    // Ensure work order number is available - handle both naming conventions
    const workOrderNumber = workOrder.workOrderNumber
    
    const eventData = {
      type: 'work_order_created',
      workOrder: {
        _id: workOrder._id,
        work_order_number: workOrderNumber,
        workOrderNumber: workOrderNumber,  // Include both formats for compatibility
        customer_id: workOrder.customer_id,
        vehicle_id: workOrder.vehicle_id,
        status: workOrder.status,
        created_at: workOrder.created_at || workOrder.createdAt,
        updated_at: workOrder.updated_at || workOrder.updatedAt,
        total_amount: workOrder.total_amount,
        branch_id: workOrder.branch_id,
        description: workOrder.description,
        notes: workOrder.notes,
        // Include populated customer details
        customerDetails: workOrder.customerDetails || {
          name: workOrder.customer_info?.name,
          email: workOrder.customer_info?.email,
          phone: workOrder.customer_info?.phone
        },
        // Include populated vehicle details
        vehicleDetails: workOrder.vehicleDetails || {
          make: workOrder.vehicle?.make,
          model: workOrder.vehicle?.model,
          year: workOrder.vehicle?.year,
          color: workOrder.vehicle?.color,
          licensePlate: workOrder.vehicle?.licensePlate,
          vin: workOrder.vehicle?.vin
        },
        // Include parts with stages
        parts: workOrder.parts || [],
        // Include service variations if present
        service_variations: workOrder.service_variations || [],
        // Include assignment info
        assigned_technician: workOrder.assigned_technician,
        supervisor: workOrder.supervisor,
        // Include completion dates
        expected_completion_date: workOrder.expected_completion_date,
        actual_completion_date: workOrder.actual_completion_date,
        quality_ratio: workOrder.quality_ratio
      }
    };

    if (targetUsers) {
      // Send to specific users
      targetUsers.forEach(userId => {
        const socketId = this.userSockets.get(userId.toString());
        if (socketId) {
          this.io.to(socketId).emit('work_order_created', eventData);
        }
      });
      console.log(`Work order created event sent to ${targetUsers.length} specific users: ${workOrderNumber}`);
    } else {
      // Broadcast to all connected users
      this.io.emit('work_order_created', eventData);
      console.log(`Work order created event broadcasted to all users: ${workOrderNumber}`);
    }
  }

  // 2. Work Order Updated
  notifyWorkOrderUpdated(workOrder, changes, targetUsers = null) {
    if (!this.io) return;
    
    const eventData = {
      type: 'work_order_updated',
      workOrderId: workOrder._id,
      workOrder: {
        _id: workOrder._id,
        work_order_number: workOrder.work_order_number || workOrder.workOrderNumber,
        customer_id: workOrder.customer_id,
        vehicle_id: workOrder.vehicle_id,
        status: workOrder.status,
        created_at: workOrder.created_at || workOrder.createdAt,
        updated_at: workOrder.updated_at || workOrder.updatedAt || new Date(),
        total_amount: workOrder.total_amount,
        branch_id: workOrder.branch_id,
        description: workOrder.description,
        notes: workOrder.notes,
        // Include populated customer details
        customerDetails: workOrder.customerDetails || {
          name: workOrder.customer_info?.name,
          email: workOrder.customer_info?.email,
          phone: workOrder.customer_info?.phone
        },
        // Include populated vehicle details
        vehicleDetails: workOrder.vehicleDetails || {
          make: workOrder.vehicle?.make,
          model: workOrder.vehicle?.model,
          year: workOrder.vehicle?.year,
          color: workOrder.vehicle?.color,
          licensePlate: workOrder.vehicle?.licensePlate,
          vin: workOrder.vehicle?.vin
        },
        // Include parts with stages
        parts: workOrder.parts || [],
        // Include service variations if present
        service_variations: workOrder.service_variations || [],
        // Include assignment info
        assigned_technician: workOrder.assigned_technician,
        supervisor: workOrder.supervisor,
        // Include completion dates
        expected_completion_date: workOrder.expected_completion_date,
        actual_completion_date: workOrder.actual_completion_date,
        quality_ratio: workOrder.quality_ratio
      },
      changes: changes // What fields were changed
    };

    if (targetUsers) {
      targetUsers.forEach(userId => {
        const socketId = this.userSockets.get(userId.toString());
        if (socketId) {
          this.io.to(socketId).emit('work_order_updated', eventData);
        }
      });
      console.log(`Work order updated event sent to ${targetUsers.length} specific users: ${workOrder.work_order_number || workOrder.workOrderNumber}`);
    } else {
      this.io.emit('work_order_updated', eventData);
      console.log(`Work order updated event broadcasted to all users: ${workOrder.work_order_number || workOrder.workOrderNumber}`);
    }
  }

  // 3. Work Order Deleted
  notifyWorkOrderDeleted(workOrderId, workOrderNumber, targetUsers = null) {
    if (!this.io) return;
    
    const eventData = {
      type: 'work_order_deleted',
      workOrderId: workOrderId,
      workOrderNumber: workOrderNumber,
      deletedAt: new Date()
    };

    if (targetUsers) {
      targetUsers.forEach(userId => {
        const socketId = this.userSockets.get(userId.toString());
        if (socketId) {
          this.io.to(socketId).emit('work_order_deleted', eventData);
        }
      });
      console.log(`Work order deleted event sent to ${targetUsers.length} specific users: ${workOrderNumber}`);
    } else {
      this.io.emit('work_order_deleted', eventData);
      console.log(`Work order deleted event broadcasted to all users: ${workOrderNumber}`);
    }
  }

  // 4. Stage Updated - Enhanced with complete stage information
  async notifyStageUpdated(workOrderId, partIndex, stageIndex, stage, workOrderNumber = null, workOrder = null, targetUsers = null) {
    if (!this.io) return;
    
    try {
      // Extract part information if work order is provided
      let partName = null;
      let totalStages = 0;
      let currentStageNumber = stageIndex + 1;
      let progressPercentage = 0;
      
      if (workOrder && workOrder.parts && workOrder.parts[partIndex]) {
        const part = workOrder.parts[partIndex];
        partName = part.partName || part.part_name || `Part ${partIndex + 1}`;
        totalStages = part.stages ? part.stages.length : 0;
        
        // Calculate progress percentage
        if (totalStages > 0) {
          const completedStages = part.stages.filter(s => s.status === 'completed').length;
          const inProgressStages = part.stages.filter(s => s.status === 'in_progress').length;
          progressPercentage = Math.round(((completedStages + (inProgressStages * 0.5)) / totalStages) * 100);
        }
      }
      
      const eventData = {
        type: 'stage_updated',
        workOrderId: workOrderId,
        workOrderNumber: workOrderNumber,
        partIndex: partIndex,
        stageIndex: stageIndex,
        partName: partName,
        stage: {
          stage_id: stage.stage_id || stage.stageId,
          stage_name: stage.stage_name || stage.stageName || 'Unknown Stage',
          stage_description: stage.stage_description || stage.stageDescription || '',
          stage_order: stage.stage_order || stage.stageOrder || stageIndex + 1,
          status: stage.status,
          started_at: stage.started_at || stage.startedAt,
          completed_at: stage.completed_at || stage.completedAt,
          updated_at: stage.updated_at || stage.updatedAt || new Date(),
          assigned_to: stage.assigned_to || stage.assignedTo,
          assignedTo: stage.assigned_to || stage.assignedTo, // Keep both formats for compatibility
          notes: stage.notes || '',
          logs: stage.logs || []
        },
        progress: {
          current_stage: currentStageNumber,
          total_stages: totalStages,
          percentage: progressPercentage,
          stage_position: `${currentStageNumber}/${totalStages}`
        }
      };

      if (targetUsers) {
        targetUsers.forEach(userId => {
          const socketId = this.userSockets.get(userId.toString());
          if (socketId) {
            this.io.to(socketId).emit('stage_updated', eventData);
          }
        });
        console.log(`Enhanced stage updated event sent to ${targetUsers.length} specific users: WO ${workOrderNumber || workOrderId}, Part "${partName}", Stage "${eventData.stage.stage_name}" (${currentStageNumber}/${totalStages})`);
      } else {
        this.io.emit('stage_updated', eventData);
        console.log(`Enhanced stage updated event broadcasted to all users: WO ${workOrderNumber || workOrderId}, Part "${partName}", Stage "${eventData.stage.stage_name}" (${currentStageNumber}/${totalStages})`);
      }
    } catch (error) {
      console.error('Error in notifyStageUpdated:', error);
      
      // Fallback to basic event structure if enhancement fails
      const basicEventData = {
        type: 'stage_updated',
        workOrderId: workOrderId,
        workOrderNumber: workOrderNumber,
        partIndex: partIndex,
        stageIndex: stageIndex,
        stage: {
          stage_id: stage.stage_id || stage.stageId,
          status: stage.status,
          started_at: stage.started_at || stage.startedAt,
          completed_at: stage.completed_at || stage.completedAt,
          updated_at: stage.updated_at || stage.updatedAt || new Date()
        }
      };

      if (targetUsers) {
        targetUsers.forEach(userId => {
          const socketId = this.userSockets.get(userId.toString());
          if (socketId) {
            this.io.to(socketId).emit('stage_updated', basicEventData);
          }
        });
      } else {
        this.io.emit('stage_updated', basicEventData);
      }
      
      console.log(`Fallback stage updated event sent: WO ${workOrderNumber || workOrderId}, Part ${partIndex}, Stage ${stageIndex}`);
    }
  }

  // Work Order Events - END
}

module.exports = new WebSocketService();
