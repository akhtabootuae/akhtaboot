const PayrollAuditLog = require('../models/PayrollAuditLog');
const { ObjectId } = require('mongodb');

/**
 * Payroll audit logging middleware
 * Logs all payroll-related actions to the audit log collection
 */
const payrollAudit = (action, entityType = 'payroll_system') => {
  return async (req, res, next) => {
    // Store original res.json method
    const originalJson = res.json.bind(res);
    
    // Override res.json to capture response data
    res.json = async function(data) {
      try {
        // Only log successful operations (status < 400)
        if (res.statusCode < 400) {
          // Comprehensive user authentication validation
          if (!req.user) {
            console.warn('Audit logging skipped: req.user is null or undefined');
            return originalJson(data);
          }

          if (!req.user._id) {
            console.warn('Audit logging skipped: req.user._id is null or undefined', {
              userObject: req.user,
              hasId: !!req.user._id,
              idType: typeof req.user._id
            });
            return originalJson(data);
          }

          // Validate and convert user_id to ObjectId
          let userId;
          try {
            if (req.user._id instanceof ObjectId) {
              userId = req.user._id;
            } else if (typeof req.user._id === 'string' && req.user._id.length === 24) {
              userId = new ObjectId(req.user._id);
            } else {
              console.warn('Audit logging skipped: Invalid user_id format', {
                userId: req.user._id,
                type: typeof req.user._id,
                length: req.user._id?.length
              });
              return originalJson(data);
            }
          } catch (objectIdError) {
            console.error('Audit logging skipped: Error creating ObjectId from user_id', {
              userId: req.user._id,
              error: objectIdError.message
            });
            return originalJson(data);
          }

          // Validate and prepare entity_id
          let entityId = req.params.id || req.params.employeeId || null;
          if (entityId && typeof entityId === 'string' && entityId.length === 24) {
            try {
              entityId = new ObjectId(entityId);
            } catch (entityIdError) {
              // Keep as string if ObjectId conversion fails
              console.warn('Entity ID kept as string due to conversion error:', entityIdError.message);
            }
          }

          const auditData = {
            user_id: userId,
            user_email: req.user.email || 'unknown',
            action: action,
            entity_type: entityType,
            entity_id: entityId,
            ip_address: req.ip || req.connection?.remoteAddress || 'unknown',
            user_agent: req.get('User-Agent') || 'unknown',
            details: {
              request_method: req.method,
              endpoint: req.originalUrl,
              success: true
            },
            severity: 'low',
            category: req.method === 'GET' ? 'data_access' : 'data_modification'
          };

          // Log audit creation
          console.log('Creating audit log:', auditData.action, 'on', auditData.entity_type);

          // Use PayrollAuditLog model to create entry
          await PayrollAuditLog.createAuditEntry(req.app.locals.db, auditData);
        }
      } catch (error) {
        console.error('Audit logging error:', error);
        console.error('Error details:', {
          message: error.message,
          stack: error.stack,
          errInfo: error.errInfo
        });
        // Don't fail the request if audit logging fails
      }
      
      // Call original json method
      return originalJson(data);
    };
    
    next();
  };
};

module.exports = payrollAudit;