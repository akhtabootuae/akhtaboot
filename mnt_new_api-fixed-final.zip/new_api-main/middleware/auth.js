const jwt = require('jsonwebtoken');
const { ObjectId } = require('mongodb');

// JWT Secret - unified across the app via environment variable (set in app.js)
const JWT_SECRET = process.env.JWT_SECRET;

// Authentication middleware for all authenticated users
module.exports = async (req, res, next) => {
  const authHeader = req.header('Authorization');

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Authorization header missing or invalid' });
  }

  const token = authHeader.substring(7).trim();

  if (!token) {
    return res.status(401).json({ message: 'No token provided' });
  }

  try {
    if (!JWT_SECRET) {
      console.error('JWT_SECRET is not configured');
      return res.status(500).json({ message: 'Server configuration error' });
    }

    const decoded = jwt.verify(token, JWT_SECRET);

    if (!decoded.user || !decoded.user.id) {
      return res.status(401).json({ message: 'Invalid token payload' });
    }

    if (!ObjectId.isValid(decoded.user.id)) {
      return res.status(401).json({ message: 'Invalid user ID in token' });
    }

    const user = await req.app.locals.db.collection('users').findOne({
      _id: new ObjectId(decoded.user.id)
    });

    if (!user) {
      return res.status(401).json({ message: 'Token is not valid - user not found' });
    }

    if (user.is_active === false) {
      return res.status(401).json({ message: 'User account is inactive' });
    }

    req.user = user;
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ message: 'Token has expired', expired: true });
    }
    if (err.name === 'JsonWebTokenError') {
      return res.status(401).json({ message: 'Token is malformed' });
    }
    return res.status(401).json({ message: 'Token is not valid' });
  }
};
