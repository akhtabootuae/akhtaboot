/**
 * Payroll validation middleware
 * Provides comprehensive validation for payroll-related operations
 */

// PayrollRate model was removed during payroll system refactor

/**
 * Validation configuration
 */
const VALIDATION_CONFIG = {
  // Rate limits
  MIN_DAILY_RATE: 50,     // Minimum daily rate in currency units
  MAX_DAILY_RATE: 2000,   // Maximum daily rate in currency units
  
  // Date limits
  MAX_FUTURE_DAYS: 90,    // Maximum days in future for effective dates
  MAX_PAST_DAYS: 365,     // Maximum days in past for effective dates
  
  // Rate change frequency (in days)
  MIN_RATE_CHANGE_INTERVAL: 7, // Minimum days between rate changes
  
  // Required fields
  REQUIRED_RATE_FIELDS: ['daily_rate', 'effective_date'],
  
  // Employment types
  VALID_EMPLOYMENT_TYPES: ['full_time', 'part_time', 'contract', 'temporary']
};

/**
 * Validate rate update request
 */
const validateRateUpdate = (req, res, next) => {
  const { daily_rate, effective_date, reason } = req.body;
  const errors = [];

  // Required fields validation
  VALIDATION_CONFIG.REQUIRED_RATE_FIELDS.forEach(field => {
    if (!req.body[field]) {
      errors.push(`${field} is required`);
    }
  });

  // Daily rate validation
  if (daily_rate !== undefined) {
    const rate = parseFloat(daily_rate);
    
    if (isNaN(rate)) {
      errors.push('Daily rate must be a valid number');
    } else if (rate < VALIDATION_CONFIG.MIN_DAILY_RATE) {
      errors.push(`Daily rate must be at least ${VALIDATION_CONFIG.MIN_DAILY_RATE}`);
    } else if (rate > VALIDATION_CONFIG.MAX_DAILY_RATE) {
      errors.push(`Daily rate cannot exceed ${VALIDATION_CONFIG.MAX_DAILY_RATE}`);
    }
  }

  // Effective date validation
  if (effective_date) {
    const date = new Date(effective_date);
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    
    if (isNaN(date.getTime())) {
      errors.push('Effective date must be a valid date');
    } else {
      // Check future date limit
      const maxFutureDate = new Date(today);
      maxFutureDate.setDate(maxFutureDate.getDate() + VALIDATION_CONFIG.MAX_FUTURE_DAYS);
      
      if (date > maxFutureDate) {
        errors.push(`Effective date cannot be more than ${VALIDATION_CONFIG.MAX_FUTURE_DAYS} days in the future`);
      }
      
      // Check past date limit
      const maxPastDate = new Date(today);
      maxPastDate.setDate(maxPastDate.getDate() - VALIDATION_CONFIG.MAX_PAST_DAYS);
      
      if (date < maxPastDate) {
        errors.push(`Effective date cannot be more than ${VALIDATION_CONFIG.MAX_PAST_DAYS} days in the past`);
      }
    }
  }

  // Reason validation (optional but recommended)
  if (reason && typeof reason !== 'string') {
    errors.push('Reason must be a string');
  } else if (reason && reason.length > 500) {
    errors.push('Reason cannot exceed 500 characters');
  }

  if (errors.length > 0) {
    return res.status(400).json({
      message: 'Validation failed',
      errors: errors
    });
  }

  next();
};

/**
 * Validate payroll info update
 */
const validatePayrollInfo = (req, res, next) => {
  const { payroll_info } = req.body;
  const errors = [];

  if (payroll_info) {
    // Employment type validation
    if (payroll_info.employment_type && 
        !VALIDATION_CONFIG.VALID_EMPLOYMENT_TYPES.includes(payroll_info.employment_type)) {
      errors.push(`Employment type must be one of: ${VALIDATION_CONFIG.VALID_EMPLOYMENT_TYPES.join(', ')}`);
    }

    // Hire date validation
    if (payroll_info.hire_date) {
      const hireDate = new Date(payroll_info.hire_date);
      const now = new Date();
      
      if (isNaN(hireDate.getTime())) {
        errors.push('Hire date must be a valid date');
      } else if (hireDate > now) {
        errors.push('Hire date cannot be in the future');
      }
    }

    // Employee ID validation
    if (payroll_info.employee_id && typeof payroll_info.employee_id !== 'string') {
      errors.push('Employee ID must be a string');
    } else if (payroll_info.employee_id && payroll_info.employee_id.length > 50) {
      errors.push('Employee ID cannot exceed 50 characters');
    }

    // Eligible validation
    if (payroll_info.eligible !== undefined && typeof payroll_info.eligible !== 'boolean') {
      errors.push('Eligible must be a boolean value');
    }
  }

  if (errors.length > 0) {
    return res.status(400).json({
      message: 'Payroll info validation failed',
      errors: errors
    });
  }

  next();
};

/**
 * Validate rate change frequency
 * This middleware checks if the user is trying to change rates too frequently
 * 
 * NOTE: Rate limiting temporarily disabled for debugging and testing purposes
 */
const validateRateChangeFrequency = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    // PayrollRate model was removed - rate change validation temporarily disabled
    // TODO: Implement new rate change validation logic based on User model payroll_info
    
    // Commented out since PayrollRate model no longer exists
    /*
    const lastRateChange = await PayrollRate.findMostRecentRateChange(req.app.locals.db, id);

    if (lastRateChange) {
      const daysSinceLastChange = Math.floor(
        (new Date() - new Date(lastRateChange.created_at)) / (1000 * 60 * 60 * 24)
      );

      // COMMENTED OUT FOR DEBUGGING AND TESTING PURPOSES ONLY
      // This rate limiting check should be re-enabled in production
      
      if (daysSinceLastChange < VALIDATION_CONFIG.MIN_RATE_CHANGE_INTERVAL) {
        return res.status(400).json({
          message: 'Rate change frequency limit exceeded',
          error: `Rate can only be changed once every ${VALIDATION_CONFIG.MIN_RATE_CHANGE_INTERVAL} days. Last change was ${daysSinceLastChange} days ago.`
        });
      }
      
    }
    */

    next();
  } catch (error) {
    console.error('Error validating rate change frequency:', error);
    // Don't fail the request if validation check fails
    next();
  }
};

/**
 * Sanitize payroll input data
 */
const sanitizePayrollData = (req, res, next) => {
  // Sanitize rate data
  if (req.body.daily_rate) {
    req.body.daily_rate = parseFloat(req.body.daily_rate);
  }

  // Sanitize and normalize dates
  if (req.body.effective_date) {
    req.body.effective_date = new Date(req.body.effective_date);
  }

  // Trim string fields
  if (req.body.reason) {
    req.body.reason = req.body.reason.trim();
  }

  // Sanitize payroll_info
  if (req.body.payroll_info) {
    if (req.body.payroll_info.employee_id) {
      req.body.payroll_info.employee_id = req.body.payroll_info.employee_id.trim();
    }
    if (req.body.payroll_info.hire_date) {
      req.body.payroll_info.hire_date = new Date(req.body.payroll_info.hire_date);
    }
  }

  next();
};

/**
 * Validation error handler
 */
const handleValidationError = (error, req, res, next) => {
  if (error.name === 'ValidationError') {
    return res.status(400).json({
      message: 'Validation error',
      errors: Object.values(error.errors).map(err => err.message)
    });
  }
  next(error);
};

module.exports = {
  validateRateUpdate,
  validatePayrollInfo,
  validateRateChangeFrequency,
  sanitizePayrollData,
  handleValidationError,
  VALIDATION_CONFIG
};