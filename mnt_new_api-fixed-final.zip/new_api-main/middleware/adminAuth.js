const auth = require('./auth');

// Authentication middleware for admin users only
module.exports = async (req, res, next) => {
  try {
    // First run general authentication using Promise wrapper
    await new Promise((resolve, reject) => {
      auth(req, res, (err) => {
        if (err) return reject(err);
        resolve();
      });
    });

    // Check if auth middleware already sent a response
    if (res.headersSent) return;

    // Check if user is admin based on role_name (case-insensitive)
    if (req.user && req.user.role_name && req.user.role_name.toLowerCase() === 'admin') {
      next();
    } else {
      res.status(403).json({ message: 'Admin access required' });
    }
  } catch (err) {
    if (!res.headersSent) {
      res.status(401).json({ message: 'Authentication failed' });
    }
  }
};
