const multer = require('multer');
const multerS3 = require('multer-s3');
const s3 = require('../services/s3');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

/**
 * Create S3 upload middleware with customizable options
 * @param {Object} options - Configuration options
 * @param {string} options.folderName - S3 folder name (e.g., 'work-orders', 'error-reports')
 * @param {RegExp} options.allowedTypes - Regex for allowed file extensions
 * @param {RegExp} options.allowedMimeTypes - Regex for allowed MIME types
 * @param {number} options.maxSize - Maximum file size in bytes (default: 10MB)
 * @param {string} options.fieldName - Form field name (default: 'file')
 * @returns {Object} Multer upload middleware
 */
const createS3Upload = (options) => {
  if (!s3) {
    // Return a middleware that rejects uploads when S3 is not configured
    return (req, res, next) => {
      next(new Error('File upload is unavailable: S3 service is not configured. Check AWS credentials.'));
    };
  }

  const folderName = options.folderName;
  const allowedTypes = options.allowedTypes || /jpeg|jpg|png|gif|pdf|doc|docx|txt|csv|xlsx|xls/;
  const allowedMimeTypes = options.allowedMimeTypes || /image\/.*|application\/pdf|application\/msword|application\/vnd\..*|text\/plain|text\/csv/;
  const maxSize = options.maxSize || 10 * 1024 * 1024; // 10MB default
  const fieldName = options.fieldName || 'file';

  const storage = multerS3({
    s3: s3,
    bucket: process.env.S3_BUCKET_NAME,
    metadata: function (req, file, cb) {
      cb(null, {
        fieldName: file.fieldname,
        originalName: file.originalname,
        uploadedBy: req.user ? req.user._id.toString() : 'anonymous'
      });
    },
    key: function (req, file, cb) {
      const uniqueSuffix = uuidv4();
      const ext = path.extname(file.originalname).toLowerCase();
      const filename = `${folderName}/${Date.now()}-${uniqueSuffix}${ext}`;
      cb(null, filename);
    },
    contentType: multerS3.AUTO_CONTENT_TYPE,
    acl: 'private', // Keep files private, serve through signed URLs
    storageClass: 'ONEZONE_IA' // Use One Zone Infrequent Access storage class to save costs
  });

  const fileFilter = (req, file, cb) => {
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedMimeTypes.test(file.mimetype);

    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error(`Invalid file type. Allowed types: ${allowedTypes.source}`));
    }
  };

  return multer({
    storage: storage,
    limits: {
      fileSize: maxSize
    },
    fileFilter: fileFilter
  }).single(fieldName);
};


/**
 * Delete a file from S3
 * @param {string} fileKey - S3 file key
 * @returns {Promise} Delete operation promise
 */
const deleteFromS3 = async (fileKey) => {
  if (!s3) {
    throw new Error('S3 service is not configured. Cannot delete file.');
  }

  const params = {
    Bucket: process.env.S3_BUCKET_NAME,
    Key: fileKey
  };

  try {
    await s3.deleteObject(params).promise();
    console.log(`Successfully deleted file from S3: ${fileKey}`);
  } catch (error) {
    console.error(`Error deleting file from S3: ${fileKey}`, error);
    throw error;
  }
};

/**
 * Delete multiple files from S3
 * @param {Array<string>} fileKeys - Array of S3 file keys
 * @returns {Promise} Delete operation promise
 */
const deleteMultipleFromS3 = async (fileKeys) => {
  if (!fileKeys || fileKeys.length === 0) return;
  if (!s3) {
    throw new Error('S3 service is not configured. Cannot delete files.');
  }

  const params = {
    Bucket: process.env.S3_BUCKET_NAME,
    Delete: {
      Objects: fileKeys.map(key => ({ Key: key })),
      Quiet: false
    }
  };

  try {
    const result = await s3.deleteObjects(params).promise();
    console.log(`Successfully deleted ${result.Deleted.length} files from S3`);
    return result;
  } catch (error) {
    console.error('Error deleting files from S3:', error);
    throw error;
  }
};

/**
 * Generate a signed URL for private file access
 * @param {string} fileKey - S3 file key
 * @param {number} expiresIn - URL expiration time in seconds (default: 3600)
 * @param {Object} responseHeaders - Optional response headers for the signed URL
 * @returns {Promise<string>} Signed URL
 */
const getSignedUrl = async (fileKey, expiresIn = 3600, responseHeaders = {}) => {
  if (!s3) {
    throw new Error('S3 service is not configured. Cannot generate signed URL.');
  }

  const params = {
    Bucket: process.env.S3_BUCKET_NAME,
    Key: fileKey,
    Expires: expiresIn,
    ...responseHeaders
  };

  try {
    const url = await s3.getSignedUrlPromise('getObject', params);
    return url;
  } catch (error) {
    console.error(`Error generating signed URL for ${fileKey}:`, error);
    throw error;
  }
};

/**
 * Create S3 upload middleware for multiple files
 * @param {Object} options - Configuration options
 * @param {string} options.folderName - S3 folder name
 * @param {RegExp} options.allowedTypes - Regex for allowed file extensions
 * @param {RegExp} options.allowedMimeTypes - Regex for allowed MIME types
 * @param {number} options.maxSize - Maximum file size in bytes
 * @param {string} options.fieldName - Form field name
 * @param {number} options.maxCount - Maximum number of files
 * @returns {Object} Multer upload middleware for multiple files
 */
const createS3MultiUpload = (options) => {
  if (!s3) {
    // Return a middleware that rejects uploads when S3 is not configured
    return (req, res, next) => {
      next(new Error('File upload is unavailable: S3 service is not configured. Check AWS credentials.'));
    };
  }

  const folderName = options.folderName;
  const allowedTypes = options.allowedTypes || /jpeg|jpg|png|gif|webp/;
  const allowedMimeTypes = options.allowedMimeTypes || /image\/.*/;
  const maxSize = options.maxSize || 10 * 1024 * 1024; // 10MB default
  const fieldName = options.fieldName || 'images';
  const maxCount = options.maxCount || 5;

  const storage = multerS3({
    s3: s3,
    bucket: process.env.S3_BUCKET_NAME,
    metadata: function (req, file, cb) {
      cb(null, {
        fieldName: file.fieldname,
        originalName: file.originalname,
        uploadedBy: req.user ? req.user._id.toString() : 'anonymous'
      });
    },
    key: function (req, file, cb) {
      const uniqueSuffix = uuidv4();
      const ext = path.extname(file.originalname).toLowerCase();
      const filename = `${folderName}/${Date.now()}-${uniqueSuffix}${ext}`;
      cb(null, filename);
    },
    contentType: multerS3.AUTO_CONTENT_TYPE,
    acl: 'private',
    storageClass: 'ONEZONE_IA'
  });

  const fileFilter = (req, file, cb) => {
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedMimeTypes.test(file.mimetype);

    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error(`Invalid file type. Allowed types: ${allowedTypes.source}`));
    }
  };

  return multer({
    storage: storage,
    limits: {
      fileSize: maxSize,
      files: maxCount
    },
    fileFilter: fileFilter
  }).array(fieldName, maxCount);
};

/**
 * Predefined upload configurations for different file types
 */
const uploadConfigs = {
  // Images only (for error reports, cancellation approvals)
  images: {
    allowedTypes: /jpeg|jpg|png|gif|webp/,
    allowedMimeTypes: /image\/.*/,
    maxSize: 10 * 1024 * 1024 // 10MB
  },
  
  // Documents and images (for case attachments)
  documents: {
    allowedTypes: /jpeg|jpg|png|gif|pdf|doc|docx|txt|csv|xlsx|xls/,
    allowedMimeTypes: /image\/.*|application\/pdf|application\/msword|application\/vnd\..*|text\/plain|text\/csv/,
    maxSize: 25 * 1024 * 1024 // 25MB
  },
  
  // Receipts (images and PDFs)
  receipts: {
    allowedTypes: /jpeg|jpg|png|gif|pdf/,
    allowedMimeTypes: /image\/.*|application\/pdf/,
    maxSize: 10 * 1024 * 1024 // 10MB
  },

  // Invoice images (for expense invoice attachments)
  invoiceImages: {
    allowedTypes: /jpeg|jpg|png|gif|pdf/,
    allowedMimeTypes: /image\/.*|application\/pdf/,
    maxSize: 15 * 1024 * 1024 // 15MB
  },

  // QA Images (3-5 images for work order QA)
  qaImages: {
    allowedTypes: /jpeg|jpg|png|gif|webp/,
    allowedMimeTypes: /image\/.*/,
    maxSize: 10 * 1024 * 1024, // 10MB
    maxCount: 5,
    minCount: 3
  },

  // Voice notes for messaging
  voiceNotes: {
    allowedTypes: /mp3|wav|m4a|ogg|webm|aac|flac/,
    allowedMimeTypes: /audio\/.*/,
    maxSize: 50 * 1024 * 1024, // 50MB for voice notes
    maxCount: 1
  },

  // Images for messaging
  messagingImages: {
    allowedTypes: /jpeg|jpg|png|gif|webp/,
    allowedMimeTypes: /image\/.*/,
    maxSize: 25 * 1024 * 1024, // 25MB for images
    maxCount: 5
  }
};

/**
 * Wait for an S3 object to exist (for propagation safety)
 * @param {string} key - S3 object key
 * @param {number} maxWaitMs - Maximum wait time in ms
 * @param {number} intervalMs - Poll interval in ms
 * @returns {Promise<boolean>} Resolves true if object exists, throws if not found in time
 */
const waitForS3Object = async (key, maxWaitMs = 3000, intervalMs = 200) => {
  if (!s3) {
    throw new Error('S3 service is not configured. Cannot check for S3 object.');
  }

  const params = { Bucket: process.env.S3_BUCKET_NAME, Key: key };
  const start = Date.now();
  while (Date.now() - start < maxWaitMs) {
    try {
      await s3.headObject(params).promise();
      return true;
    } catch (err) {
      if (err.code === 'NotFound') {
        await new Promise(res => setTimeout(res, intervalMs));
      } else {
        throw err;
      }
    }
  }
  throw new Error('S3 file not found after upload');
};

module.exports = {
  createS3Upload,
  createS3MultiUpload,
  deleteFromS3,
  deleteMultipleFromS3,
  getSignedUrl,
  uploadConfigs,
  waitForS3Object
};