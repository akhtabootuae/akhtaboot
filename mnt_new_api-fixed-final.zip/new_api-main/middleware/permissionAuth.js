const auth = require('./auth');

/**
 * Permission-based authentication middleware
 * @param {String|Array} requiredPermissions - Permission name(s) required to access the route
 * @param {Object} options - Additional options
 * @returns {Function} Middleware function
 */
module.exports = (requiredPermissions, options = {}) => {
  // Convert single permission to array for consistent handling
  const permissions = Array.isArray(requiredPermissions)
    ? requiredPermissions
    : [requiredPermissions];

  const { requireSameBranch = false } = options;

  return async (req, res, next) => {
    try {
      // First run general authentication using Promise wrapper
      await new Promise((resolve, reject) => {
        auth(req, res, (err) => {
          if (err) return reject(err);
          resolve();
        });
      });

      // Check if auth middleware already sent a response
      if (res.headersSent) return;

      // Guard against missing user (auth may have sent a response already)
      if (!req.user) {
        return;
      }

      // Admin role bypasses permission check
      if (req.user.role_name === 'Admin') {
        return next();
      }

      // If user doesn't have any permissions, deny access
      if (!req.user.permissions || !Array.isArray(req.user.permissions)) {
        return res.status(403).json({ message: 'Access denied: Missing permissions' });
      }

      // Check branch restriction if needed
      if (requireSameBranch && req.params.branchId) {
        // For branch-specific operations, check that user belongs to that branch
        const userBranchId = req.user.branch?.branch_id?.toString();
        if (!userBranchId || userBranchId !== req.params.branchId) {
          return res.status(403).json({
            message: 'Access denied: You can only access data for your assigned branch'
          });
        }
      }

      // Check if user has ANY of the required permissions
      const hasPermission = permissions.some(permission => {
        const userPerm = req.user.permissions.find(p =>
          p.permission_name === permission && p.granted === true
        );
        return !!userPerm;
      });

      if (hasPermission) {
        next();
      } else {
        res.status(403).json({
          message: 'Access denied: Required permission not granted',
          requiredPermissions: permissions
        });
      }
    } catch (err) {
      console.error('Permission check error:', err);
      if (!res.headersSent) {
        res.status(401).json({ message: 'Authentication failed' });
      }
    }
  };
};
