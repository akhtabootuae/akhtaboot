# Work Order API Documentation

This document outlines the available endpoints for managing work orders in the system.

## Base URL

All endpoints are relative to `/api/work-orders`.

## Authentication

All routes require authentication. Include a valid JWT token in the Authorization header.

## Endpoints

### Create Work Order
- **URL**: `/`
- **Method**: `POST`
- **Description**: Creates a new work order
- **Required Permission**: `create_work_order`
- **Request Body**:
  ```json
  {
    "workOrderNumber": "WO-000001",  // Optional - will be auto-generated if not provided
    "customer_id": "63f889e4eab4d0fc9f0b4567",  // Optional reference to customer
    "vehicle": {
      "vin": "1HGCM82633A123456",
      "make": "Honda",
      "model": "Accord",
      "year": 2020
    },
    "status": "open",
    "description": "Detailed description of work to be done",
    "parts": [
      {
        "partName": "Left front door",
        "variationId": "63f889e4eab4d0fc9f0b4568",
        "status": "pending",
        "assignedTo": "63f889e4eab4d0fc9f0b4569",  // Optional technician ID
        "stages": [
          {
            "stageId": "63f889e4eab4d0fc9f0b456a", 
            "status": "pending",
            "assignedTo": "63f889e4eab4d0fc9f0b456b",  // Optional technician ID
            "logs": []  // Time tracking logs will be added later
          }
        ]
      }
    ]
  }
  ```
- **Success Response**:
  - **Code**: 201
  - **Content**: Created work order object

### Get All Work Orders
- **URL**: `/`
- **Method**: `GET`
- **Description**: Retrieves all work orders, with optional filters
- **Required Permission**: `view_all_work_orders`
- **Query Parameters**:
  - `customer_id`: Filter by customer ID
  - `status`: Filter by status
  - `vin`: Filter by vehicle VIN
  - `created_from`: Filter by creation date (start)
  - `created_to`: Filter by creation date (end)
- **Success Response**:
  - **Code**: 200
  - **Content**: Array of work order objects

### Get Work Order by ID
- **URL**: `/:id`
- **Method**: `GET`
- **Description**: Retrieves a specific work order by its ID
- **Required Permission**: `view_work_order`
- **Path Parameters**:
  - `id`: Work order ID
- **Success Response**:
  - **Code**: 200
  - **Content**: Work order object
- **Error Response**:
  - **Code**: 404
  - **Content**: `{ "message": "Work order not found" }`

### Get Work Order by Number
- **URL**: `/number/:workOrderNumber`
- **Method**: `GET`
- **Description**: Retrieves a specific work order by its number
- **Required Permission**: `view_work_order`
- **Path Parameters**:
  - `workOrderNumber`: Work order number (e.g., "WO-000001")
- **Success Response**:
  - **Code**: 200
  - **Content**: Work order object
- **Error Response**:
  - **Code**: 404
  - **Content**: `{ "message": "Work order not found" }`

### Get Work Orders by Customer
- **URL**: `/customer/:customerId`
- **Method**: `GET`
- **Description**: Retrieves all work orders for a specific customer
- **Required Permission**: `view_work_order`
- **Path Parameters**:
  - `customerId`: Customer ID
- **Success Response**:
  - **Code**: 200
  - **Content**: Array of work order objects

### Update Work Order
- **URL**: `/:id`
- **Method**: `PUT`
- **Description**: Updates a specific work order
- **Required Permission**: `update_work_order`
- **Path Parameters**:
  - `id`: Work order ID
- **Request Body**: Fields to update (excluding parts array)
  ```json
  {
    "status": "in_progress",
    "description": "Updated work description",
    "vehicle": {
      "vin": "1HGCM82633A123456",
      "make": "Honda",
      "model": "Accord",
      "year": 2021
    }
  }
  ```
- **Success Response**:
  - **Code**: 200
  - **Content**: Updated work order object
- **Error Response**:
  - **Code**: 404
  - **Content**: `{ "message": "Work order not found" }`

### Delete Work Order
- **URL**: `/:id`
- **Method**: `DELETE`
- **Description**: Deletes a specific work order
- **Required Permission**: `delete_work_order`
- **Path Parameters**:
  - `id`: Work order ID
- **Success Response**:
  - **Code**: 200
  - **Content**: `{ "message": "Work order deleted successfully" }`
- **Error Response**:
  - **Code**: 404
  - **Content**: `{ "message": "Work order not found" }`

### Update Work Order Status
- **URL**: `/:id/status`
- **Method**: `PUT`
- **Description**: Updates the status of a work order
- **Required Permission**: `update_work_order_status`
- **Path Parameters**:
  - `id`: Work order ID
- **Request Body**:
  ```json
  {
    "status": "in_progress"
  }
  ```
- **Success Response**:
  - **Code**: 200
  - **Content**: Updated work order object
- **Error Response**:
  - **Code**: 400
  - **Content**: `{ "message": "Status is required" }`
  - **Code**: 404
  - **Content**: `{ "message": "Work order not found" }`

## Parts Management

### Add Part to Work Order
- **URL**: `/:id/parts`
- **Method**: `POST`
- **Description**: Adds a new part to a work order
- **Required Permission**: `manage_work_order_parts`
- **Path Parameters**:
  - `id`: Work order ID
- **Request Body**:
  ```json
  {
    "partName": "Right rear door",
    "variationId": "63f889e4eab4d0fc9f0b4568",
    "status": "pending",
    "assignedTo": "63f889e4eab4d0fc9f0b4569", 
    "stages": [
      {
        "stageId": "63f889e4eab4d0fc9f0b456a",
        "status": "pending",
        "assignedTo": "63f889e4eab4d0fc9f0b456b"
      }
    ]
  }
  ```
- **Success Response**:
  - **Code**: 200
  - **Content**: Updated work order object
- **Error Response**:
  - **Code**: 404
  - **Content**: `{ "message": "Work order not found" }`

### Update Part
- **URL**: `/:id/parts/:partIndex`
- **Method**: `PUT`
- **Description**: Updates a specific part in a work order
- **Required Permission**: `manage_work_order_parts`
- **Path Parameters**:
  - `id`: Work order ID
  - `partIndex`: Index of the part in the array
- **Request Body**:
  ```json
  {
    "partName": "Updated part name",
    "assignedTo": "63f889e4eab4d0fc9f0b4571"
  }
  ```
- **Success Response**:
  - **Code**: 200
  - **Content**: Updated work order object
- **Error Response**:
  - **Code**: 404
  - **Content**: `{ "message": "Part not found" }`

### Update Part Status
- **URL**: `/:id/parts/:partIndex/status`
- **Method**: `PUT`
- **Description**: Updates the status of a part
- **Required Permission**: `update_work_order_part_status`
- **Path Parameters**:
  - `id`: Work order ID
  - `partIndex`: Index of the part in the array
- **Request Body**:
  ```json
  {
    "status": "in_progress"
  }
  ```
- **Success Response**:
  - **Code**: 200
  - **Content**: Updated work order object
- **Error Response**:
  - **Code**: 400
  - **Content**: `{ "message": "Status is required" }`
  - **Code**: 404
  - **Content**: `{ "message": "Part not found" }`

## Stages Management

### Add Stage to Part
- **URL**: `/:id/parts/:partIndex/stages`
- **Method**: `POST`
- **Description**: Adds a new stage to a part in a work order
- **Required Permission**: `manage_work_order_stages`
- **Path Parameters**:
  - `id`: Work order ID
  - `partIndex`: Index of the part in the array
- **Request Body**:
  ```json
  {
    "stageId": "63f889e4eab4d0fc9f0b456c",
    "status": "pending",
    "assignedTo": "63f889e4eab4d0fc9f0b456d"
  }
  ```
- **Success Response**:
  - **Code**: 200
  - **Content**: Updated work order object
- **Error Response**:
  - **Code**: 404
  - **Content**: `{ "message": "Part not found" }`

### Update Stage
- **URL**: `/:id/parts/:partIndex/stages/:stageIndex`
- **Method**: `PUT`
- **Description**: Updates a specific stage in a part
- **Required Permission**: `manage_work_order_stages`
- **Path Parameters**:
  - `id`: Work order ID
  - `partIndex`: Index of the part in the array
  - `stageIndex`: Index of the stage in the part's stages array
- **Request Body**:
  ```json
  {
    "assignedTo": "63f889e4eab4d0fc9f0b456e"
  }
  ```
- **Success Response**:
  - **Code**: 200
  - **Content**: Updated work order object
- **Error Response**:
  - **Code**: 404
  - **Content**: `{ "message": "Stage not found" }`

### Update Stage Status
- **URL**: `/:id/parts/:partIndex/stages/:stageIndex/status`
- **Method**: `PUT`
- **Description**: Updates the status of a stage
- **Required Permission**: `update_work_order_stage_status`
- **Path Parameters**:
  - `id`: Work order ID
  - `partIndex`: Index of the part in the array
  - `stageIndex`: Index of the stage in the part's stages array
- **Request Body**:
  ```json
  {
    "status": "in_progress"
  }
  ```
- **Success Response**:
  - **Code**: 200
  - **Content**: Updated work order object
- **Error Response**:
  - **Code**: 400
  - **Content**: `{ "message": "Status is required" }`
  - **Code**: 404
  - **Content**: `{ "message": "Stage not found" }`

## Time Tracking Logs

### Add Log Entry
- **URL**: `/:id/parts/:partIndex/stages/:stageIndex/logs`
- **Method**: `POST`
- **Description**: Adds a time tracking log entry to a stage
- **Required Permission**: `manage_work_order_logs`
- **Path Parameters**:
  - `id`: Work order ID
  - `partIndex`: Index of the part in the array
  - `stageIndex`: Index of the stage in the part's stages array
- **Request Body**:
  ```json
  {
    "action": "start",
    "note": "Starting work on this stage"
  }
  ```
- **Success Response**:
  - **Code**: 200
  - **Content**: Updated work order object
- **Error Response**:
  - **Code**: 400
  - **Content**: `{ "message": "Action is required for log entry" }`
  - **Code**: 404
  - **Content**: `{ "message": "Stage not found" }`

## Status Values

- **Work Order Status**: `open`, `in_progress`, `on_hold`, `completed`, `closed`
- **Part Status**: `pending`, `in_progress`, `completed`
- **Stage Status**: `pending`, `in_progress`, `completed`
- **Log Actions**: `start`, `pause`, `resume`, `complete`
