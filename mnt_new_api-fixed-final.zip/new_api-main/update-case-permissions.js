/**
 * Script to update existing users with the corrected case management permissions
 * This ensures all seeded users have the proper permissions according to the updated case routes
 */

const { MongoClient } = require('mongodb');
const { getDefaultPermissionsForRole } = require('./config/permissions');

// MongoDB connection string from environment or default
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/new_api';

/**
 * Update all users with the latest permissions for their roles
 */
async function updateUserPermissions() {
  let client;
  
  try {
    console.log('🔄 Updating user permissions for case management...\n');
    
    // Connect to MongoDB
    client = new MongoClient(MONGODB_URI);
    await client.connect();
    const db = client.db();
    
    // Get all users from database
    const users = await db.collection('users').find({}).toArray();
    console.log(`Found ${users.length} users to update\n`);
    
    let updateCount = 0;
    
    for (const user of users) {
      try {
        console.log(`Updating permissions for: ${user.first_name} ${user.last_name} (${user.role_name})`);
        
        // Get the latest default permissions for this user's role
        const latestPermissions = getDefaultPermissionsForRole(user.role_name);
        
        // Update the user's permissions in the database
        const result = await db.collection('users').updateOne(
          { _id: user._id },
          {
            $set: {
              permissions: latestPermissions,
              updated_at: new Date()
            }
          }
        );
        
        if (result.modifiedCount > 0) {
          updateCount++;
          
          // Show which case permissions were updated
          const casePermissions = latestPermissions
            .filter(p => p.permission_name.includes('case') && p.granted)
            .map(p => p.permission_name);
          
          console.log(`  ✅ Updated successfully`);
          console.log(`  📋 Case permissions: ${casePermissions.join(', ')}\n`);
        } else {
          console.log(`  ℹ️  No changes needed\n`);
        }
        
      } catch (error) {
        console.error(`  ❌ Failed to update ${user.email}:`, error.message);
      }
    }
    
    console.log(`\n🎉 Permission update completed!`);
    console.log(`Updated ${updateCount} out of ${users.length} users`);
    
    // Verify the updates by checking a few users
    console.log('\n🔍 Verification - Checking updated permissions:');
    console.log('=' .repeat(60));
    
    const updatedUsers = await db.collection('users').find({}).limit(3).toArray();
    
    for (const user of updatedUsers) {
      console.log(`\n👤 ${user.first_name} ${user.last_name} (${user.role_name}):`);
      
      const casePermissions = user.permissions
        .filter(p => p.permission_name.includes('case') && p.granted)
        .map(p => p.permission_name);
      
      console.log(`   Case permissions: ${casePermissions.join(', ')}`);
    }
    
    // Summary of permissions by role
    console.log('\n📊 Final Permission Summary by Role:');
    console.log('=' .repeat(60));
    
    const roles = ['Admin', 'Supervisor', 'Technician'];
    
    for (const roleName of roles) {
      const rolePermissions = getDefaultPermissionsForRole(roleName);
      const casePermissions = rolePermissions
        .filter(p => p.permission_name.includes('case') && p.granted)
        .map(p => p.permission_name);
      
      console.log(`\n${roleName}:`);
      casePermissions.forEach(perm => {
        console.log(`  ✅ ${perm}`);
      });
    }
    
  } catch (error) {
    console.error('❌ Error updating user permissions:', error);
  } finally {
    if (client) {
      await client.close();
    }
  }
}

/**
 * Verify that all required permissions for case routes are present
 */
async function verifyRequiredPermissions() {
  console.log('\n🔍 Verifying required permissions for case routes...\n');
  
  // Required permissions for case routes
  const requiredPermissions = [
    'create_case',          // POST /cases
    'view_all_cases',       // GET /cases  
    'view_case',            // GET /cases/:id
    'view_case_stats',      // GET /cases/stats
    'update_case',          // PUT /cases/:id
    'resolve_case',         // Status change to resolved/closed
    'close_case',           // Status change to closed
    'add_case_notes',       // POST /cases/:id/notes
    'manage_case_attachments', // POST /cases/:id/attachments
    'delete_case'           // DELETE /cases/:id
  ];
  
  const roles = ['Admin', 'Supervisor', 'Technician'];
  
  for (const roleName of roles) {
    console.log(`\n📋 ${roleName} Role Analysis:`);
    console.log('-' .repeat(40));
    
    const rolePermissions = getDefaultPermissionsForRole(roleName);
    
    requiredPermissions.forEach(reqPerm => {
      const hasPermission = rolePermissions.find(p => 
        p.permission_name === reqPerm && p.granted === true
      );
      
      const status = hasPermission ? '✅' : '❌';
      const note = hasPermission ? '' : ' (Consider adding for better functionality)';
      
      console.log(`  ${status} ${reqPerm}${note}`);
    });
  }
  
  console.log('\n💡 Recommendations:');
  console.log('• Admin: Has full access to all case operations');
  console.log('• Supervisor: Has full access to all case operations');
  console.log('• Technician: Has appropriate limited access for daily operations');
}

/**
 * Main execution function
 */
async function main() {
  console.log('🚀 Case Management Permissions Update Script');
  console.log('============================================\n');
  
  try {
    // First verify what permissions should be set
    await verifyRequiredPermissions();
    
    // Ask for confirmation before updating
    console.log('\n⚠️  This script will update all user permissions in the database.');
    console.log('Make sure you have a backup before proceeding.\n');
    
    // Update the permissions
    await updateUserPermissions();
    
    console.log('\n✅ All operations completed successfully!');
    console.log('\nNext steps:');
    console.log('1. Test the case routes with the updated permissions');
    console.log('2. Run the test-updated-case-routes.js script to verify functionality');
    console.log('3. Update frontend applications if needed');
    
  } catch (error) {
    console.error('❌ Script execution failed:', error);
    process.exit(1);
  }
}

// Run the script if executed directly
if (require.main === module) {
  main();
}

module.exports = {
  updateUserPermissions,
  verifyRequiredPermissions
};
