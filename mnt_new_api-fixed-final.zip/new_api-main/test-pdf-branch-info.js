// Test script to verify PDF generation includes branch info
const { MongoClient } = require('mongodb');
const fs = require('fs');
const path = require('path');
const { generateInvoicePDFFromDB } = require('./utils/pdfGenerator');
require('dotenv').config();

async function testPDFWithBranchInfo() {
  console.log('Testing PDF generation with branch information...');
  
  const client = new MongoClient(process.env.MONGO_URI);
  
  try {
    await client.connect();
    console.log('Connected to MongoDB');
    
    const db = client.db();
    
    // Get an invoice to test with
    const invoice = await db.collection('invoices').findOne(
      {},
      { sort: { created_at: -1 } }
    );
    
    if (!invoice) {
      console.log('No invoices found. Creating a test invoice...');
      
      // Get a customer and branch for testing
      const customer = await db.collection('customers').findOne({});
      const branch = await db.collection('branches').findOne({});
      
      if (!customer || !branch) {
        console.log('Need at least one customer and one branch to test');
        return;
      }
      
      // Create a test invoice
      const testInvoice = {
        invoice_number: 'INV-TEST001',
        customer_id: customer._id,
        branch_id: branch._id,
        vehicle_id: customer.vehicles?.[0]?.vehicle_id || 1,
        invoice_date: new Date(),
        price: 1000.00,
        vat: 5,
        payment_records: [],
        images: [],
        created_at: new Date(),
        updated_at: new Date()
      };
      
      const result = await db.collection('invoices').insertOne(testInvoice);
      console.log('Test invoice created:', result.insertedId);
      invoice = { ...testInvoice, _id: result.insertedId };
    }
    
    console.log(`\nTesting PDF generation for invoice: ${invoice.invoice_number}`);
    
    // Check branch information
    const branch = await db.collection('branches').findOne({ _id: invoice.branch_id });
    console.log('Branch information:');
    console.log(`  - Name: ${branch?.branch_name || 'Not found'}`);
    console.log(`  - Arabic Name: ${branch?.branch_name_ar || 'Not found'}`);
    console.log(`  - Code: ${branch?.branch_code || 'Not found'}`);
    console.log(`  - TRN: ${branch?.trn || 'Not found'}`);
    console.log(`  - Location: ${branch?.location || 'Not found'}`);
    
    // Create output file
    const outputPath = path.join(__dirname, `test-invoice-branch-${Date.now()}.pdf`);
    const outputStream = fs.createWriteStream(outputPath);
    
    // Generate PDF
    console.log('\nGenerating PDF...');
    await generateInvoicePDFFromDB(db, invoice._id.toString(), outputStream);
    
    // Wait for file to be written
    await new Promise((resolve) => {
      outputStream.on('finish', resolve);
    });
    
    console.log(`✅ PDF generated successfully: ${outputPath}`);
    console.log('Check the PDF to verify:');
    console.log('  - TRN field shows the branch TRN');
    console.log('  - Branch name appears in header');
    console.log('  - Arabic branch name appears in header');
    console.log('  - Branch location appears in header');
    
  } catch (error) {
    console.error('Test error:', error);
  } finally {
    await client.close();
  }
}

testPDFWithBranchInfo();
