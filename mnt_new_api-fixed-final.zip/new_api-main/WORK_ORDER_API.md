# Work Order API Documentation

This document outlines the available e**Response:**

Success (200 OK):
```json
{
  "_id": "60d5ec9f1c9d440000b1f3e9",
  "workOrderNumber": "WO-2025-0001",
  "customer_id": "60d5ec9f1c9d440000b1f3e4",
  "vehicle_id": 1,
  "vehicleDetails": {
    "vehicle_id": 1,
    "vin": "1HGCM82633A123456",
    "make": "Honda",
    "model": "Accord",
    "year": 2020,
    "license_plate": "ABC123"
  },for managing work orders in the system.

## Base URL

All endpoints are relative to `/api/work-orders`.

## Authentication

All routes require authentication. Include a valid JWT token in the Authorization header.

## Required Permissions

Different endpoints require different permissions:

- `create_work_order` - For creating work orders
- `view_all_work_orders` - For viewing work orders
- `update_work_order` - For updating work orders
- `delete_work_order` - For deleting work orders
- `manage_work_order_parts` - For managing parts within work orders
- `update_work_order_part_status` - For updating the status of parts
- `manage_work_order_stages` - For managing stages within parts
- `update_work_order_stage_status` - For updating the status of stages
- `manage_work_order_logs` - For managing time tracking logs

## Basic Operations

### Create a new work order

**Endpoint:** `POST /`

**Permission required:** `create_work_order`

**Important Note:** The vehicle ID specified in the work order MUST belong to the customer specified by customer_id. The system will validate this relationship.

**Request body:**

```json
{
  "workOrderNumber": "WO-2025-0001",  // Optional, will be generated if not provided
  "customer_id": "60d5ec9f1c9d440000b1f3e4",
  "vehicle_id": 1,  // Required - Must match a vehicle_id in customer's vehicles array
  "status": "open",
  "parts": [
    {
      "partName": "Front Bumper",
      "variationId": "60d5ec9f1c9d440000b1f3e5", 
      "status": "pending",
      "assignedTo": "60d5ec9f1c9d440000b1f3e6", // Optional
      "stages": [
        {
          "stageId": "60d5ec9f1c9d440000b1f3e7",
          "status": "pending",
          "assignedTo": "60d5ec9f1c9d440000b1f3e8", // Optional
          "logs": [
            {
              "timestamp": "2025-05-20T10:30:00Z",
              "action": "started",
              "note": "Initial inspection"
            }
          ]
        }
      ]
    }
  ],
  "notes": "Customer reported front damage after collision"
}
```

**Response:**

Success (201 Created):
```json
{
  "_id": "60d5ec9f1c9d440000b1f3e9",
  "workOrderNumber": "WO-2025-0001",
  "customer_id": "60d5ec9f1c9d440000b1f3e4",
  "vehicle_id": 1,
  "status": "open",
  "parts": [...],
  "notes": "Customer reported front damage after collision",
  "createdAt": "2025-05-22T12:30:45Z",
  "updatedAt": "2025-05-22T12:30:45Z"
}
```

Error (400 Bad Request):
```json
{
  "message": "The specified vehicle does not belong to this customer"
}
```

Error (400 Bad Request):
```json
{
  "message": "Customer ID is required"
}
```

Error (400 Bad Request):
```json
{
  "message": "Vehicle ID is required"
}
```

Error (400 Bad Request):
```json
{
  "message": "Vehicle ID must be a valid integer"
}
```

### Get all work orders

**Endpoint:** `GET /`

**Permission required:** `view_all_work_orders`

**Query parameters:**
- `customer_id` (optional) - Filter by customer ID
- `status` (optional) - Filter by status
- `created_from` (optional) - Filter by creation date (from)
- `created_to` (optional) - Filter by creation date (to)
- `vin` (optional) - Filter by vehicle VIN (special handling - searches through related customer vehicles)

**Response:**

Success (200 OK):
```json
[
  {
    "_id": "60d5ec9f1c9d440000b1f3e9",
    "workOrderNumber": "WO-2025-0001",
    "customer_id": "60d5ec9f1c9d440000b1f3e4",
    "vehicle": {...},
    "status": "open",
    "parts": [...],
    "createdAt": "2025-05-22T12:30:45Z",
    "updatedAt": "2025-05-22T12:30:45Z"
  },
  // More work orders...
]
```

### Get a work order by ID

**Endpoint:** `GET /:id`

**Permission required:** `view_all_work_orders`

**Response:**

Success (200 OK):
```json
{
  "_id": "60d5ec9f1c9d440000b1f3e9",
  "workOrderNumber": "WO-2025-0001",
  "customer_id": "60d5ec9f1c9d440000b1f3e4",
  "vehicle": {...},
  "status": "open",
  "parts": [...],
  "createdAt": "2025-05-22T12:30:45Z",
  "updatedAt": "2025-05-22T12:30:45Z"
}
```

Error (404 Not Found):
```json
{
  "message": "Work order not found"
}
```

### Update a work order

**Endpoint:** `PUT /:id`

**Permission required:** `update_work_order`

**Important Note:** If updating the vehicle_id, the new value must belong to the customer specified by customer_id. The system validates this relationship.

**Request body:**
```json
{
  "status": "in_progress",
  "notes": "Updated notes",
  "vehicle_id": 2  // Must match a vehicle_id in customer's vehicles array
}
```

**Response:**

Success (200 OK):
```json
{
  "_id": "60d5ec9f1c9d440000b1f3e9",
  "workOrderNumber": "WO-2025-0001",
  "status": "in_progress",
  "notes": "Updated notes",
  "vehicle": {
    "vehicle_id": 2,
    "make": "Toyota",
    "model": "Camry",
    "year": 2021
  },
  "updatedAt": "2025-05-22T14:45:12Z"
  // Other fields remain unchanged
}
```

Error (400 Bad Request):
```json
{
  "message": "The specified vehicle does not belong to this customer"
}
```

Error (400 Bad Request):
```json
{
  "message": "Vehicle ID must be a valid integer"
}
```

### Delete a work order

**Endpoint:** `DELETE /:id`

**Permission required:** `delete_work_order`

**Response:**

Success (204 No Content)

## Parts Management

### Add a part to a work order

**Endpoint:** `POST /:id/parts`

**Permission required:** `manage_work_order_parts`

**Request body:**
```json
{
  "partName": "Rear Bumper",
  "variationId": "60d5ec9f1c9d440000b1f3e5",
  "status": "pending",
  "assignedTo": "60d5ec9f1c9d440000b1f3e6"
}
```

**Response:**

Success (200 OK):
```json
{
  "_id": "60d5ec9f1c9d440000b1f3e9",
  "parts": [
    // Existing parts...
    {
      "partName": "Rear Bumper",
      "variationId": "60d5ec9f1c9d440000b1f3e5",
      "status": "pending",
      "assignedTo": "60d5ec9f1c9d440000b1f3e6",
      "stages": []
    }
  ],
  "updatedAt": "2025-05-22T15:20:33Z"
}
```

### Update a part in a work order

**Endpoint:** `PUT /:id/parts/:partIndex`

**Permission required:** `manage_work_order_parts`

**Request body:**
```json
{
  "partName": "Updated Part Name",
  "status": "in_progress"
}
```

**Response:**

Success (200 OK):
```json
{
  "_id": "60d5ec9f1c9d440000b1f3e9",
  "parts": [
    // Parts before the updated part
    {
      "partName": "Updated Part Name",
      "status": "in_progress"
      // Other fields remain unchanged
    }
    // Parts after the updated part
  ],
  "updatedAt": "2025-05-22T16:10:45Z"
}
```

### Update a part's status

**Endpoint:** `PATCH /:id/parts/:partIndex/status`

**Permission required:** `update_work_order_part_status`

**Request body:**
```json
{
  "status": "completed"
}
```

**Response:**

Success (200 OK):
```json
{
  "_id": "60d5ec9f1c9d440000b1f3e9",
  "parts": [
    // Parts with updated status
  ],
  "updatedAt": "2025-05-22T16:45:22Z"
}
```

### Remove a part from a work order

**Endpoint:** `DELETE /:id/parts/:partIndex`

**Permission required:** `manage_work_order_parts`

**Response:**

Success (200 OK):
```json
{
  "_id": "60d5ec9f1c9d440000b1f3e9",
  "parts": [
    // Remaining parts after deletion
  ],
  "updatedAt": "2025-05-22T17:05:18Z"
}
```

## Stages Management

### Add a stage to a part

**Endpoint:** `POST /:id/parts/:partIndex/stages`

**Permission required:** `manage_work_order_stages`

**Request body:**
```json
{
  "stageId": "60d5ec9f1c9d440000b1f3e7",
  "status": "pending",
  "assignedTo": "60d5ec9f1c9d440000b1f3e8"
}
```

**Response:**

Success (200 OK):
```json
{
  "part": {
    "partName": "Front Bumper",
    "stages": [
      // Existing stages...
      {
        "stageId": "60d5ec9f1c9d440000b1f3e7",
        "status": "pending",
        "assignedTo": "60d5ec9f1c9d440000b1f3e8",
        "logs": []
      }
    ]
  },
  "updatedAt": "2025-05-22T17:30:40Z"
}
```

### Update a stage

**Endpoint:** `PUT /:id/parts/:partIndex/stages/:stageIndex`

**Permission required:** `manage_work_order_stages`

**Request body:**
```json
{
  "status": "in_progress",
  "assignedTo": "60d5ec9f1c9d440000b1f3e8"
}
```

**Response:**

Success (200 OK):
```json
{
  "part": {
    "partName": "Front Bumper",
    "stages": [
      // Stages with the updated stage
    ]
  },
  "updatedAt": "2025-05-22T17:45:12Z"
}
```

### Update a stage's status

**Endpoint:** `PATCH /:id/parts/:partIndex/stages/:stageIndex/status`

**Permission required:** `update_work_order_stage_status`

**Request body:**
```json
{
  "status": "completed"
}
```

**Response:**

Success (200 OK):
```json
{
  "part": {
    "partName": "Front Bumper",
    "stages": [
      // Stages with updated status
    ]
  },
  "updatedAt": "2025-05-22T18:15:30Z"
}
```

### Remove a stage

**Endpoint:** `DELETE /:id/parts/:partIndex/stages/:stageIndex`

**Permission required:** `manage_work_order_stages`

**Response:**

Success (200 OK):
```json
{
  "part": {
    "partName": "Front Bumper",
    "stages": [
      // Remaining stages after deletion
    ]
  },
  "updatedAt": "2025-05-22T18:30:45Z"
}
```

## Time Tracking

### Add a time tracking log to a stage

**Endpoint:** `POST /:id/parts/:partIndex/stages/:stageIndex/logs`

**Permission required:** `manage_work_order_logs`

**Request body:**
```json
{
  "timestamp": "2025-05-22T19:00:00Z",
  "action": "started",
  "note": "Beginning repair work"
}
```

**Response:**

Success (200 OK):
```json
{
  "stage": {
    "stageId": "60d5ec9f1c9d440000b1f3e7",
    "status": "in_progress",
    "logs": [
      // Existing logs...
      {
        "timestamp": "2025-05-22T19:00:00Z",
        "action": "started",
        "note": "Beginning repair work"
      }
    ]
  },
  "updatedAt": "2025-05-22T19:00:05Z"
}
```

### Update a time tracking log

**Endpoint:** `PUT /:id/parts/:partIndex/stages/:stageIndex/logs/:logIndex`

**Permission required:** `manage_work_order_logs`

**Request body:**
```json
{
  "action": "paused",
  "note": "Waiting for parts"
}
```

**Response:**

Success (200 OK):
```json
{
  "stage": {
    "stageId": "60d5ec9f1c9d440000b1f3e7",
    "status": "in_progress",
    "logs": [
      // Logs with the updated log
    ]
  },
  "updatedAt": "2025-05-22T19:15:22Z"
}
```

### Remove a time tracking log

**Endpoint:** `DELETE /:id/parts/:partIndex/stages/:stageIndex/logs/:logIndex`

**Permission required:** `manage_work_order_logs`

**Response:**

Success (200 OK):
```json
{
  "stage": {
    "stageId": "60d5ec9f1c9d440000b1f3e7",
    "status": "in_progress",
    "logs": [
      // Remaining logs after deletion
    ]
  },
  "updatedAt": "2025-05-22T19:30:10Z"
}
```

## Status Values

### Work Order Status
- `open` - Work order has been created but work has not started
- `in_progress` - Work has started on at least one part
- `on_hold` - Work has been temporarily paused
- `completed` - All parts have been completed
- `closed` - Work order is finalized and closed

### Part Status
- `pending` - Part is awaiting work
- `in_progress` - Work has started on this part
- `on_hold` - Work has been temporarily paused
- `completed` - Work on this part is complete

### Stage Status
- `pending` - Stage is awaiting work
- `in_progress` - Work has started on this stage
- `on_hold` - Work has been temporarily paused
- `completed` - Work on this stage is complete

### Log Actions
- `started` - Work has started
- `paused` - Work has been paused
- `resumed` - Work has been resumed
- `completed` - Work has been completed
- `note` - General note/comment

## Vehicle Handling

Work orders reference vehicles by their `vehicle_id` rather than duplicating vehicle details. This approach has several advantages:

1. **Data Integrity** - Vehicle information is stored in a single place (the customer document), preventing inconsistencies
2. **Source of Truth** - If vehicle information is updated in the customer record, the work order automatically reflects the latest data
3. **Storage Efficiency** - Reduces data duplication across the database

### Vehicle Reference
When creating or updating work orders, only the `vehicle_id` is stored, not the complete vehicle details:

```json
{
  "customer_id": "60d5ec9f1c9d440000b1f3e4",
  "vehicle_id": 1
}
```

### Vehicle Details in Responses
Although only the `vehicle_id` is stored, API responses will include the complete vehicle details for convenience:

```json
{
  "customer_id": "60d5ec9f1c9d440000b1f3e4",
  "vehicle_id": 1,
  "vehicleDetails": {
    "vehicle_id": 1,
    "vin": "1HGCM82633A123456",
    "make": "Honda",
    "model": "Accord",
    "year": 2020,
    "license_plate": "ABC123",
    "color": "Black"
  }
}
```

### Vehicle Validation
The system enforces the following validation rules:

1. The `vehicle_id` must be an integer
2. The vehicle must belong to the specified customer
3. When creating a work order, both `customer_id` and `vehicle_id` are required

These validations ensure that work orders are always associated with valid vehicle/customer relationships.