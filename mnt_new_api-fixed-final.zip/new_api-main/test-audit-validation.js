const { MongoClient, ObjectId } = require('mongodb');

async function testAuditValidation() {
  let client;
  
  try {
    // Connect to MongoDB
    const uri = process.env.MONGODB_URI || 'mongodb://localhost:27017/your_database';
    client = new MongoClient(uri);
    await client.connect();
    
    const db = client.db();
    console.log('Connected to MongoDB');
    
    // First, let's check if the collection exists and has validation
    const collections = await db.listCollections({ name: 'payroll_audit_log' }).toArray();
    
    if (collections.length === 0) {
      console.log('\n=== Creating collection with validation ===');
      // Create the collection with validation
      await db.createCollection('payroll_audit_log', PayrollAuditLog.getSchema());
      console.log('Collection created with validation');
    }
    
    // Test various scenarios to identify the exact validation issue
    console.log('\n=== Testing user_id scenarios ===');
    
    // Test 1: user_id as undefined
    console.log('\nTest 1: user_id as undefined');
    try {
      await db.collection('payroll_audit_log').insertOne({
        user_id: undefined,
        action: 'update_rate',
        entity_type: 'payroll_rate',
        timestamp: new Date()
      });
      console.log('✓ Passed');
    } catch (error) {
      console.error('✗ Failed:', error.message);
    }
    
    // Test 2: user_id as null
    console.log('\nTest 2: user_id as null');
    try {
      await db.collection('payroll_audit_log').insertOne({
        user_id: null,
        action: 'update_rate',
        entity_type: 'payroll_rate',
        timestamp: new Date()
      });
      console.log('✓ Passed');
    } catch (error) {
      console.error('✗ Failed:', error.message);
    }
    
    // Test 3: user_id as string
    console.log('\nTest 3: user_id as string');
    try {
      await db.collection('payroll_audit_log').insertOne({
        user_id: '507f1f77bcf86cd799439011',
        action: 'update_rate',
        entity_type: 'payroll_rate',
        timestamp: new Date()
      });
      console.log('✓ Passed');
    } catch (error) {
      console.error('✗ Failed:', error.message);
    }
    
    // Test 4: user_id as ObjectId
    console.log('\nTest 4: user_id as ObjectId');
    try {
      await db.collection('payroll_audit_log').insertOne({
        user_id: new ObjectId(),
        action: 'update_rate',
        entity_type: 'payroll_rate',
        timestamp: new Date()
      });
      console.log('✓ Passed');
    } catch (error) {
      console.error('✗ Failed:', error.message);
    }
    
    // Test 5: Missing required fields one by one
    console.log('\n=== Testing missing required fields ===');
    
    const requiredFields = ['user_id', 'action', 'entity_type', 'timestamp'];
    
    for (const field of requiredFields) {
      console.log(`\nTesting without ${field}:`);
      const testDoc = {
        user_id: new ObjectId(),
        action: 'update_rate',
        entity_type: 'payroll_rate',
        timestamp: new Date()
      };
      
      delete testDoc[field];
      
      try {
        await db.collection('payroll_audit_log').insertOne(testDoc);
        console.log(`✓ Passed (${field} not required?)`);
      } catch (error) {
        console.error(`✗ Failed: ${error.message}`);
      }
    }
    
    // Test 6: Invalid enum values
    console.log('\n=== Testing invalid enum values ===');
    
    // Invalid action
    console.log('\nTest: Invalid action');
    try {
      await db.collection('payroll_audit_log').insertOne({
        user_id: new ObjectId(),
        action: 'invalid_action',
        entity_type: 'payroll_rate',
        timestamp: new Date()
      });
      console.log('✓ Passed (validation not enforced?)');
    } catch (error) {
      console.error('✗ Failed:', error.message);
    }
    
    // Invalid entity_type
    console.log('\nTest: Invalid entity_type');
    try {
      await db.collection('payroll_audit_log').insertOne({
        user_id: new ObjectId(),
        action: 'update_rate',
        entity_type: 'invalid_type',
        timestamp: new Date()
      });
      console.log('✓ Passed (validation not enforced?)');
    } catch (error) {
      console.error('✗ Failed:', error.message);
    }
    
  } catch (error) {
    console.error('Fatal error:', error);
  } finally {
    if (client) {
      await client.close();
      console.log('\nDisconnected from MongoDB');
    }
  }
}

// Import the schema
const PayrollAuditLog = require('./models/PayrollAuditLog');

// Run the test
testAuditValidation().catch(console.error);