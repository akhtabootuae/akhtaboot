# Garage Management System API

A comprehensive RESTful API built with Node.js, Express, and MongoDB for managing garage operations including users, customers, vehicles, and branches with a robust role-based and permission-based access control system.

## Features

- 🔐 **Advanced Authentication**: Secure JWT-based authentication with token expiration
- 👤 **User Management**: Complete user CRUD operations with profile management
- 🚗 **Customer & Vehicle**: Comprehensive customer and vehicle tracking system
- 🧾 **Invoicing System**: Detailed invoice management with payment tracking
- 📋 **Work Orders**: Track service requests and maintenance work orders
- 🔄 **Workflow Management**: Define custom workflow stages and service variations
- 🔑 **Role-based Access Control**: Flexible RBAC with Admin, Supervisor and Technician roles
- 📝 **Permission System**: Granular permission-based authorization with detailed access control
- 📊 **Activity Logging**: Permission modification logging and auditing capabilities
- 🔄 **Environment Configuration**: Easy setup with environment-based configuration
- 📤 **Data Export**: Export user and customer data in various formats
- 🏢 **Branch Management**: Multi-location support with branch-specific operations
- 🛠️ **Technician Management**: Specialized features for workshop technicians
- 📱 **API-First Design**: Built for seamless integration with web and mobile applications

## Tech Stack

- **Runtime**: Node.js (v14+)
- **Framework**: Express.js 4.x
- **Database**: MongoDB 4.4+ with native driver
- **Authentication**: JSON Web Tokens (JWT) for stateless auth
- **Password Security**: bcrypt for secure password hashing
- **Validation**: JSON Schema validation for data integrity
- **Documentation**: Markdown-based API documentation
- **Testing**: Postman collections for API testing

## Prerequisites

- Node.js (v14 or later)
- MongoDB (v4.4 or later)
- npm or yarn

## Getting Started

### Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/garage-management-api.git
   cd new_api
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Configure environment variables:
   ```bash
   cp .env.example .env
   ```
   Edit the `.env` file with your specific configuration (see Environment Variables section below).

4. Initialize the database:
   ```bash
   npm run init-db
   ```
   This will create all necessary collections, indexes, and seed initial data including an admin user.

5. Start the server:
   ```bash
   npm start
   ```

For development with auto-restart and live-reloading:
```bash
npm run dev
```

### Environment Variables

Key environment variables you need to configure in your `.env` file:

| Variable | Description | Example |
|----------|-------------|---------|
| `NODE_ENV` | Environment (development, production) | `development` |
| `PORT` | The port the server will run on | `3000` |
| `MONGO_URI` | MongoDB connection string | `mongodb://localhost:27017/garage_db` |
| `JWT_SECRET` | Secret key for JWT signing | `your-secure-secret-key` |
| `JWT_EXPIRE` | JWT token expiration time | `24h` |
| `ADMIN_EMAIL` | Default admin user email | `admin@example.com` |
| `ADMIN_PASSWORD` | Default admin user password | `StrongAdminPass123!` |
| `ADMIN_FIRST_NAME` | Default admin first name | `System` |
| `ADMIN_LAST_NAME` | Default admin last name | `Administrator` |

## Project Structure

```
new_api/
├── app.js                  # Entry point
├── config/                 # Configuration files
│   └── dbSeeder.js         # Database seed data
├── middleware/             # Express middleware
│   ├── adminAuth.js        # Admin authentication
│   ├── auth.js             # User authentication
│   └── permissionAuth.js   # Permission validation
├── models/                 # Database models
│   ├── Branch.js           # Branch model
│   ├── Customer.js         # Customer model
│   ├── Role.js             # Role model
│   ├── User.js             # User model
│   └── index.js            # Models entry point
└── routes/                 # API routes
    ├── branchRoutes.js     # Branch endpoints
    ├── customerRoutes.js   # Customer endpoints
    ├── roleRoutes.js       # Role endpoints
    ├── userRoleRoutes.js   # User role assignment
    └── userRoutes.js       # User endpoints
```

## API Documentation

The API is divided into several modules with comprehensive documentation:

### Core APIs

- **[User API](./USER_API.md)**: 
  - User authentication (login, register)
  - User management (CRUD operations)
  - User permissions and profile management
  - Password management

- **[Role API](./ROLE_API.md)**:
  - Role definition and management
  - Role assignment to users
  - Role-based permissions

- **[Branch API](./BRANCH_API.md)**:
  - Branch creation and management
  - User-branch assignments
  - Branch-specific operations
  - Multi-location support

- **[Customer API](./CUSTOMER_API.md)**:
  - Customer management
  - Vehicle management
  - Customer-vehicle relationship
  - Service history

- **[Invoice API](./INVOICE_API.md)**:
  - Invoice creation and management
  - Payment records tracking
  - Invoice image management
  - VAT calculation

- **[Work Order API](./WORK_ORDER_API.md)**:
  - Work order management
  - Work item tracking
  - Status management
  - Technician assignment

### API Design Principles

- RESTful design with standard HTTP methods
- Consistent error handling and status codes
- Comprehensive validation and sanitization
- Authentication and authorization checks
- Pagination for list endpoints
- Field filtering and sorting options

## Authentication & Authorization

### Authentication

Most endpoints require authentication via JWT. To authenticate requests:

1. Obtain a token via login or registration endpoint
2. Include the token in all subsequent request headers:

```
Authorization: Bearer your_jwt_token
```

Tokens are configured to expire after the duration specified in `JWT_EXPIRE`.

### Role-Based Access Control

The API implements a comprehensive role-based access control system:

- **Admin**: 
  - Full system access with all privileges
  - Can create/modify roles and permissions
  - Can manage all users and system settings

- **Supervisor**: 
  - Can manage technicians and oversee operations
  - Has access to most system features except admin-level configurations
  - Can generate reports and view operation analytics

- **Technician**: 
  - Field worker with limited administrative access
  - Can access customer and vehicle information
  - Can update service records and task status

## Permission System

The system implements a fine-grained permission model:

### Permission Levels
- **Role-based permissions**: Automatically assigned based on user role
- **User-specific permissions**: Can be granted or revoked on an individual basis
- **Branch-specific permissions**: Control access to branch-specific operations

### Permission Management
- Admin can manage permissions via `/api/users/:id/permissions` endpoints
- Permission changes are logged in the system for audit purposes
- Permission checks are enforced at the API level through middleware

### Security Best Practices
- All passwords are securely hashed using bcrypt
- JWT tokens are signed with a secure secret
- For production deployments, always use HTTPS
- Implement proper rate limiting and monitoring

## Branch Management

The system supports multi-branch operations:

- Each user is assigned to a specific branch (default: Sharjah Branch)
- Branch administrators can manage users within their branch
- Resource access can be limited to the user's assigned branch
- Cross-branch operations require specific permissions
- Branch data is stored in a dedicated MongoDB collection with schema validation

## Database Schema

The system uses MongoDB with schema validation for data integrity:

### Collections
- `users`: User accounts and profiles
- `roles`: Role definitions and permissions
- `branches`: Branch information and locations
- `customers`: Customer personal information
- `vehicles`: Vehicle details linked to customers
- `permissionLogs`: Audit trail of permission changes

### Indexes
- Unique indexes on email fields for users
- Unique indexes on branch_code field for branches
- Compound indexes for optimized querying

## Testing

The API includes comprehensive testing resources:

### API Testing
- **Jest & Supertest**: Unit and integration tests for all models and routes
- **MongoDB Memory Server**: In-memory MongoDB for isolated test environments
- **Automated Tests**: Test coverage for data validation, CRUD operations, and API endpoints

### Manual Testing
- **Postman Collections**: Ready-made request collections for each API module
- **Environment Variables**: Postman environment setup for testing
- **Test Scripts**: Basic test scripts included in Postman collections

### Running Tests

Run the test suite with:
```bash
npm test
```

For continuous testing during development:
```bash
npm run test:watch
```

## Development

### Adding New Features

To add new features to the API:

1. Create appropriate model files in `/models`
2. Add routes in `/routes`
3. Implement authentication and permission checks
4. Update documentation and test collections

### Contributing

Contributions are welcome! Please follow these steps:

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

Please ensure your code follows the project coding style and includes appropriate tests.

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- Node.js and Express.js communities
- MongoDB team for their excellent database
- All contributors to this project

## System Permissions

The API implements a comprehensive permission system:

### User Management Permissions
- `view_all_users`: View all users in the system
- `view_users`: View basic user information
- `create_user`: Create new users
- `update_user`: Update existing user information
- `delete_user`: Remove users from the system
- `manage_user_status`: Activate/deactivate user accounts

### Role & Permission Management
- `manage_permissions`: Assign or revoke user permissions
- `manage_roles`: Assign roles to users
- `view_permission_logs`: Access permission change history
- `manage_user_branches`: Change user branch assignments

### Customer & Vehicle Management
- `view_all_customers`: View all customers in the system
- `view_customer`: View specific customer details
- `create_customer`: Create new customer records
- `update_customer`: Update customer information
- `delete_customer`: Remove customers
- `manage_vehicles`: Add/update/remove customer vehicles

### Invoice Management
- `view_all_invoices`: View all invoices in the system
- `view_invoice`: View specific invoice details
- `create_invoice`: Create new invoice records
- `update_invoice`: Update invoice information
- `delete_invoice`: Remove invoices
- `manage_payments`: Add/update/remove payment records
- `manage_invoice_images`: Add/remove images related to invoices

### Work Order Management
- `view_all_work_orders`: View all work orders in the system
- `view_work_order`: View specific work order details
- `create_work_order`: Create new work order records
- `update_work_order`: Update work order information
- `delete_work_order`: Remove work orders
- `manage_work_items`: Add/update/remove work items
- `update_work_order_status`: Change the status of work orders

### Branch-specific Permissions
- `view_branch_data`: Access branch-specific information
- `manage_branch`: Update branch details
- `export_branch_data`: Export branch-specific reports

### System Administration
- `export_users`: Export user data
- `system_configuration`: Access system settings
- `view_system_logs`: Access system activity logs

_Note: Custom permissions can be added through the database._

## Development

### Project Structure

```
new_api/
├── config/          # Configuration files
├── middleware/      # Custom middleware
├── models/          # Data models
├── routes/          # API routes
├── .env             # Environment variables (not in repository)
├── .env.example     # Example environment variables
├── app.js           # Application entry point
└── README.md        # This file
```

### GMS Project Integration

This API serves as the backend interface for the GMS (Garage Management System) project. Currently, only the user management and authentication components have been implemented. Future modules will include:

- Vehicle management
- Service and repair tracking
- Inventory management
- Billing and invoicing
- Customer management
- Reporting and analytics

### Roadmap

1. ✅ User Authentication & Authorization - Complete with JWT implementation, role-based access control, and permission system
2. ✅ Branch Management - Implemented with MongoDB collections, user assignments, and branch-specific operations
3. ✅ Customer Management - Customer record creation, lookup, and customer history functionality
4. ✅ Vehicle Management - Vehicle registration, service history tracking, and owner relationships
5. ✅ Work Order Management - Service work orders, tracking, and completion status
6. ✅ Billing & Payments - Invoice generation, payment record tracking, and financial management
7. ✅ Automated Testing - Comprehensive testing suite for models and API endpoints with Jest and Supertest
8. ⬜ Frontend Integration - React/Vue.js components for invoice and work order management
9. ⬜ Service Management - Appointment scheduling, service records, and technician assignments
10. ⬜ Inventory Control - Parts tracking, stock management, and order processing
11. ⬜ Reporting System - Analytics dashboard, operational reports, and business intelligence
12. ⬜ Mobile Application Integration - API endpoints optimized for mobile clients
13. ⬜ Customer Portal - Self-service appointment booking and service history

### Adding New Endpoints

1. Create routes in the appropriate file in `routes/`
2. Use middleware for authentication and permission checks
3. Implement business logic and database operations
4. Return appropriate status codes and response data

## Testing with Postman

1. Import the Postman collection from the project directory
2. Register a new user or use the default admin user
3. Obtain a JWT token via the login endpoint
4. Use the token for authenticated requests

## Deployment

The API is designed to be deployed as part of the complete GMS system. For development and testing purposes, it can be run independently using the instructions in the Getting Started section.

## License

[Include your license information here]

## Contributors

Bashir Khadra Jr, Fahad Milhem, Begad Moussa 
