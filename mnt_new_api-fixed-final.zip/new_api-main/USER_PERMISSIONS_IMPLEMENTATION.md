# User Permissions Implementation

## Overview
The user creation system has been updated to automatically assign appropriate permissions to users based on their roles when they are created.

## Changes Made

### 1. Updated Database Seeder (`config/dbSeeder.js`)
- ✅ Admin users now get all permissions with `granted: true`
- ✅ Supervisor users get appropriate management permissions 
- ✅ Technician users get limited view-only permissions
- ✅ Added `updateExistingUserPermissions()` function to update existing users

### 2. Updated User Routes (`routes/userRoutes.js`)
- ✅ Added import for `getDefaultPermissionsForRole`
- ✅ Updated `POST /api/users` (create user) to assign permissions
- ✅ Updated `POST /api/users/register` (public registration) to assign permissions
- ✅ Updated `PUT /api/users/:id/role` (role update) to refresh permissions

### 3. Created Utility Script (`update-user-permissions.js`)
- ✅ Standalone script to update existing users with permissions
- ✅ Useful for migrating existing databases

## Permission Structure

Each user now has a `permissions` array with objects containing:
```javascript
{
  permission_id: "view_users",
  permission_name: "view_users", 
  permission_description: "View basic user information",
  granted: true/false
}
```

## Role-Based Permissions

### Admin
- Gets **ALL** permissions with `granted: true`
- Full system access

### Supervisor  
- Customer management (full access)
- Invoice management (full access)
- Work order management (full access)
- User viewing permissions
- Branch data access
- Export capabilities

### Technician
- Limited view permissions
- Work order status updates
- Customer viewing (limited)
- Branch data viewing

## Usage

### For New Users
When creating users via API endpoints, permissions are automatically assigned based on their role.

### For Existing Users
Run the update script to assign permissions to existing users:
```bash
node update-user-permissions.js
```

Or include it in the database seeding process:
```bash
# The seeder now includes updateExistingUserPermissions()
```

## API Endpoints That Now Assign Permissions

1. **POST /api/users** - Admin/create_user permission required
2. **POST /api/users/register** - Public registration (assigns Technician permissions)
3. **PUT /api/users/:id/role** - Role updates now refresh permissions

## Testing

You can verify permissions are working by:
1. Creating a new user via API
2. Checking the user document in MongoDB
3. Verifying the `permissions` array is populated
4. Confirming `granted` flags match the role expectations

## Notes

- The permission system is backwards compatible
- Existing users without permissions will be updated during seeding
- Permission changes are logged with timestamps
- Role changes automatically refresh user permissions
