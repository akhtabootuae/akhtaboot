# Payroll System Refactor Documentation

## Overview

The payroll system has been completely refactored to support the new business model:
- **Before**: Daily rates with overtime calculated in payroll
- **After**: Monthly salaries with overtime logged as automatic expenses

## Breaking Changes Summary

### 1. **Daily Rate System Removed**
- `PayrollRate` model deleted entirely
- All daily rate calculations removed
- Rate history functionality eliminated

### 2. **Monthly Salary System Implemented**
- User model now uses `payroll_info.monthly_salary` instead of `payroll_info.current_daily_rate`
- Payroll calculations simplified to `monthly_salary - deductions = net_pay`

### 3. **Overtime Handling Changed**
- Overtime no longer calculated in payroll
- Overtime automatically creates expense records when timesheets >8 hours are approved
- New expense type: `overtime_compensation`

### 4. **Timesheet Simplification**
- Timesheets now only track hours worked
- No pay calculations in timesheets
- Overtime detection happens during approval process

## API Endpoint Changes

### **REMOVED Endpoints**

```
❌ GET /api/payroll/employees/:id/rates
❌ PUT /api/payroll/employees/:id/rate
❌ GET /api/payroll/employees/:id/current-rate
```

### **NEW/UPDATED Endpoints**

#### 1. **GET /api/payroll/employees**
**Purpose**: Get all payroll-eligible employees with their monthly salaries

**Response Structure**:
```json
{
  "employees": [
    {
      "_id": "employee_id",
      "email": "employee@example.com",
      "first_name": "John",
      "last_name": "Doe",
      "branch": {
        "branch_id": "branch_id",
        "branch_name": "Sharjah",
        "branch_code": "SJH"
      },
      "payroll_info": {
        "payroll_eligible": true,
        "monthly_salary": 5000,
        "employee_number": "EMP001",
        "hire_date": "2024-01-01T00:00:00.000Z",
        "employment_type": "full_time",
        "last_pay_date": "2024-12-01T00:00:00.000Z",
        "last_rate_update": "2024-12-01T00:00:00.000Z",
        "updated_by": "admin@example.com"
      }
    }
  ],
  "pagination": {
    "current_page": 1,
    "total_pages": 5,
    "total_employees": 100,
    "per_page": 20
  }
}
```

#### 2. **PUT /api/payroll/employees/:id/salary**
**Purpose**: Update employee's monthly salary

**Request Body**:
```json
{
  "monthly_salary": 5500,
  "reason": "Annual salary increase"
}
```

**Response**:
```json
{
  "message": "Employee salary updated successfully",
  "employee_id": "employee_id",
  "old_salary": 5000,
  "new_salary": 5500,
  "updated_by": "admin@example.com"
}
```

#### 3. **GET /api/payroll/employees/:id/salary**
**Purpose**: Get employee's salary information

**Response**:
```json
{
  "employee": {
    "_id": "employee_id",
    "email": "employee@example.com",
    "first_name": "John",
    "last_name": "Doe"
  },
  "payroll_info": {
    "payroll_eligible": true,
    "monthly_salary": 5500,
    "employee_number": "EMP001",
    "hire_date": "2024-01-01T00:00:00.000Z",
    "employment_type": "full_time",
    "last_pay_date": "2024-12-01T00:00:00.000Z",
    "last_rate_update": "2024-12-01T00:00:00.000Z",
    "updated_by": "admin@example.com"
  }
}
```

### **Expense System Integration**

#### New Expense Type: `overtime_compensation`
The expense system now includes a new expense type for overtime payments.

#### Automatic Overtime Expense Creation
When a timesheet with >8 hours is approved, the system automatically:

1. **Calculates overtime hours**: `overtime_hours = total_hours - 8`
2. **Calculates overtime amount**: 
   ```javascript
   const workingDaysPerMonth = 22;
   const dailyRate = monthly_salary / workingDaysPerMonth;
   const hourlyRate = dailyRate / 8;
   const overtimeRate = hourlyRate * 1.5;
   const overtimeAmount = overtime_hours * overtimeRate;
   ```
3. **Creates expense record** with these fields:
   ```json
   {
     "title": "Overtime Compensation - John Doe",
     "description": "Overtime payment for 2.5 hours on 2024-12-15",
     "amount": 156.25,
     "expense_type": "overtime_compensation",
     "date": "2024-12-15",
     "vendor": "John Doe",
     "notes": "Auto-generated from timesheet. Regular hours: 8, Overtime hours: 2.5, Overtime rate: AED 62.50/hour",
     "timesheet_id": "timesheet_id",
     "target_employee_id": "employee_id"
   }
   ```

## Database Schema Changes

### **User Model Changes**
```javascript
// OLD
payroll_info: {
  current_daily_rate: 200, // REMOVED
  // ... other fields
}

// NEW
payroll_info: {
  monthly_salary: 5000, // NEW FIELD
  last_rate_update: Date, // NEW FIELD
  updated_by: "admin@example.com", // NEW FIELD
  // ... other fields
}
```

### **Expense Model Changes**
```javascript
// NEW expense type added to enum
expense_type: {
  enum: [
    // ... existing types
    "overtime_compensation", // NEW
    "miscellaneous"
  ]
}

// NEW optional fields for overtime expenses
{
  timesheet_id: ObjectId, // Links to source timesheet
  target_employee_id: ObjectId // Employee receiving overtime
}
```

### **TimeSheet Model Changes**
```javascript
// REMOVED FIELDS
{
  daily_rate: Number, // REMOVED
  total_pay: Number, // REMOVED
  regular_hours: Number, // REMOVED
  overtime_hours: Number, // REMOVED
}

// REMAINING FIELDS (simplified)
{
  employee_id: ObjectId,
  work_date: Date,
  time_in: Date,
  time_out: Date,
  total_hours: Number, // Only field for hours
  notes: String,
  status: String, // draft, submitted, approved, rejected
  // ... audit fields
}
```

### **PayrollCalculation Model Changes**
```javascript
// REMOVED FIELDS
{
  regular_hours: Number, // REMOVED
  overtime_hours: Number, // REMOVED
  total_hours: Number, // REMOVED
  regular_pay: Number, // REMOVED
  overtime_pay: Number, // REMOVED
  daily_rate: Number, // REMOVED
  hourly_rate: Number, // REMOVED
}

// NEW/UPDATED FIELDS
{
  monthly_salary: Number, // NEW
  days_worked: Number, // Attendance tracking
  gross_pay: Number, // Equal to monthly_salary
  // ... existing deduction and tax fields remain
}
```

## Frontend Implementation Guide

### **1. Employee Management UI Updates**

#### Salary Management Page
Replace the "Daily Rate" management with "Monthly Salary" management:

```javascript
// OLD - Rate History Component (REMOVE)
<RateHistoryTable employeeId={employeeId} />
<UpdateRateModal employeeId={employeeId} />

// NEW - Salary Management Component
<SalaryManagement employeeId={employeeId} />
```

#### Salary Management Component Implementation:
```javascript
const SalaryManagement = ({ employeeId }) => {
  const [salaryData, setSalaryData] = useState(null);
  const [loading, setLoading] = useState(true);

  // Fetch current salary
  useEffect(() => {
    fetchSalary();
  }, [employeeId]);

  const fetchSalary = async () => {
    try {
      const response = await api.get(`/api/payroll/employees/${employeeId}/salary`);
      setSalaryData(response.data);
    } catch (error) {
      console.error('Error fetching salary:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateSalary = async (newSalary, reason) => {
    try {
      await api.put(`/api/payroll/employees/${employeeId}/salary`, {
        monthly_salary: newSalary,
        reason: reason
      });
      await fetchSalary(); // Refresh data
    } catch (error) {
      console.error('Error updating salary:', error);
      throw error;
    }
  };

  if (loading) return <LoadingSpinner />;

  return (
    <div>
      <h3>Monthly Salary Management</h3>
      <div>
        <strong>Current Salary:</strong> AED {salaryData?.payroll_info?.monthly_salary || 0}
      </div>
      <div>
        <strong>Last Updated:</strong> {formatDate(salaryData?.payroll_info?.last_rate_update)}
      </div>
      <div>
        <strong>Updated By:</strong> {salaryData?.payroll_info?.updated_by}
      </div>
      <UpdateSalaryButton onUpdate={updateSalary} currentSalary={salaryData?.payroll_info?.monthly_salary} />
    </div>
  );
};
```

### **2. Timesheet UI Updates**

#### Remove Pay Calculations from Timesheets
```javascript
// OLD - Timesheet with pay calculations (REMOVE)
<TimesheetEntry>
  <HoursInput />
  <PayCalculation> // REMOVE THIS SECTION
    <div>Regular Hours: {regularHours}</div>
    <div>Overtime Hours: {overtimeHours}</div>
    <div>Total Pay: AED {totalPay}</div>
  </PayCalculation>
</TimesheetEntry>

// NEW - Simplified timesheet
<TimesheetEntry>
  <HoursInput />
  <div>Total Hours: {totalHours}</div>
  {totalHours > 8 && (
    <div className="overtime-notice">
      ⚠️ Overtime detected: {totalHours - 8} hours will be processed as expense upon approval
    </div>
  )}
</TimesheetEntry>
```

### **3. Employee List Updates**

Update the employee listing to show monthly salaries:

```javascript
// OLD
const EmployeeRow = ({ employee }) => (
  <tr>
    <td>{employee.first_name} {employee.last_name}</td>
    <td>AED {employee.current_rate}/day</td> {/* REMOVE */}
    <td>{employee.rate_effective_date}</td> {/* REMOVE */}
  </tr>
);

// NEW
const EmployeeRow = ({ employee }) => (
  <tr>
    <td>{employee.first_name} {employee.last_name}</td>
    <td>AED {employee.payroll_info?.monthly_salary || 0}/month</td>
    <td>{formatDate(employee.payroll_info?.last_rate_update)}</td>
  </tr>
);
```

### **4. Payroll Calculation UI Updates**

#### Remove Overtime from Payroll Display
```javascript
// OLD - Payroll calculation display (REMOVE OVERTIME SECTIONS)
<PayrollSummary>
  <div>Regular Hours: {regularHours}</div> // REMOVE
  <div>Overtime Hours: {overtimeHours}</div> // REMOVE
  <div>Regular Pay: AED {regularPay}</div> // REMOVE
  <div>Overtime Pay: AED {overtimePay}</div> // REMOVE
  <div>Gross Pay: AED {grossPay}</div>
</PayrollSummary>

// NEW - Simplified payroll display
<PayrollSummary>
  <div>Monthly Salary: AED {monthlySalary}</div>
  <div>Days Worked: {daysWorked}</div>
  <div>Gross Pay: AED {grossPay}</div>
  <div>Total Deductions: AED {totalDeductions}</div>
  <div>Net Pay: AED {netPay}</div>
</PayrollSummary>
```

### **5. Expense System Integration**

#### Overtime Expenses Display
Add a new section to show overtime expenses:

```javascript
const OvertimeExpenses = ({ employeeId, dateRange }) => {
  const [overtimeExpenses, setOvertimeExpenses] = useState([]);

  useEffect(() => {
    fetchOvertimeExpenses();
  }, [employeeId, dateRange]);

  const fetchOvertimeExpenses = async () => {
    try {
      const response = await api.get('/api/expenses', {
        params: {
          expense_type: 'overtime_compensation',
          target_employee_id: employeeId,
          date_from: dateRange.start,
          date_to: dateRange.end
        }
      });
      setOvertimeExpenses(response.data.expenses || []);
    } catch (error) {
      console.error('Error fetching overtime expenses:', error);
    }
  };

  return (
    <div>
      <h4>Overtime Expenses</h4>
      <table>
        <thead>
          <tr>
            <th>Date</th>
            <th>Hours</th>
            <th>Amount</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {overtimeExpenses.map(expense => (
            <tr key={expense._id}>
              <td>{formatDate(expense.date)}</td>
              <td>{extractOvertimeHours(expense.notes)}</td>
              <td>AED {expense.amount}</td>
              <td>{expense.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};
```

## Testing Checklist

### **Backend Testing**
- [ ] Verify daily rate endpoints return 404
- [ ] Test new salary endpoints
- [ ] Verify overtime expenses are created automatically
- [ ] Test payroll calculations use monthly salary
- [ ] Verify timesheet approval triggers overtime expense creation

### **Frontend Testing**
- [ ] Employee list shows monthly salaries
- [ ] Salary update functionality works
- [ ] Timesheets no longer show pay calculations
- [ ] Overtime warning appears for >8 hour timesheets
- [ ] Payroll calculations show simplified data
- [ ] Overtime expenses appear in expense reports

## Migration Considerations

### **Data Migration**
If you have existing data, you may need to:

1. **Convert daily rates to monthly estimates**:
   ```javascript
   // Rough conversion (adjust based on your business logic)
   monthly_salary = current_daily_rate * 22 // 22 working days per month
   ```

2. **Update existing timesheets** to remove pay fields (or handle them gracefully in UI)

3. **Archive existing PayrollRate data** before deletion if needed for historical records

### **Rollback Plan**
Keep backups of:
- PayrollRate collection
- Original User documents with daily rates
- Original TimeSheet documents with pay calculations

This allows rollback if issues are discovered during deployment.

## Support Notes

### **Common Issues**
1. **Missing monthly_salary**: Handle cases where employees don't have monthly salary set
2. **Timesheet approval errors**: Ensure overtime expense creation doesn't block timesheet approval
3. **Permission issues**: Update role permissions for new salary endpoints

### **Performance Considerations**
- Overtime expense creation is synchronous during timesheet approval
- Consider adding background processing if timesheet approval becomes slow
- Index the new `target_employee_id` field in expenses collection for faster queries

This refactor significantly simplifies the payroll system while providing better alignment with your business processes. The automatic overtime expense creation ensures accurate cost tracking without manual intervention.