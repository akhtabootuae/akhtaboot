const { MongoClient, ObjectId } = require('mongodb');
const PayrollAuditLog = require('./models/PayrollAuditLog');

async function debugAuditIssue() {
  let client;
  
  try {
    // Connect to MongoDB
    const uri = process.env.MONGODB_URI || 'mongodb://localhost:27017/your_database';
    client = new MongoClient(uri);
    await client.connect();
    
    const db = client.db();
    console.log('Connected to MongoDB\n');
    
    // Simulate the exact scenario from payrollRoutes.js line 227
    console.log('=== Simulating payrollRoutes.js scenario ===');
    
    // Simulate req.user object as it would be from auth middleware
    const mockUser = {
      _id: new ObjectId(),
      email: 'test@example.com',
      // Note: auth middleware sets req.user from database, which has _id, not user_id
    };
    
    // Test 1: What happens when user_id is undefined (from req.user?.user_id)
    console.log('\nTest 1: When req.user?.user_id is undefined');
    const auditData1 = {
      user_id: mockUser.user_id, // This will be undefined
      user_email: mockUser.email || 'Unknown',
      action: 'update_rate',
      entity_type: 'payroll_rate',
      entity_id: new ObjectId().toString(),
      ip_address: '127.0.0.1',
      user_agent: 'Mozilla/5.0',
      details: {
        old_values: { daily_rate: 100 },
        new_values: { daily_rate: 150 },
        request_method: 'PUT',
        endpoint: '/api/payroll/rates/123',
        success: true,
        effective_date: new Date(),
        reason: 'Annual raise',
        operation: 'update'
      },
      severity: 'medium',
      category: 'data_modification'
    };
    
    console.log('user_id value:', auditData1.user_id);
    console.log('user_id type:', typeof auditData1.user_id);
    
    try {
      await PayrollAuditLog.createAuditEntry(db, auditData1);
      console.log('✓ Success - This should not happen if validation is strict');
    } catch (error) {
      console.error('✗ Failed as expected:', error.message);
      if (error.code === 121) {
        console.error('Document validation error details:', JSON.stringify(error.errInfo, null, 2));
      }
    }
    
    // Test 2: Using the correct _id field
    console.log('\nTest 2: Using req.user._id (correct field)');
    const auditData2 = {
      user_id: mockUser._id.toString(), // Convert ObjectId to string
      user_email: mockUser.email || 'Unknown',
      action: 'update_rate',
      entity_type: 'payroll_rate',
      entity_id: new ObjectId().toString(),
      ip_address: '127.0.0.1',
      user_agent: 'Mozilla/5.0',
      details: {
        old_values: { daily_rate: 100 },
        new_values: { daily_rate: 150 },
        request_method: 'PUT',
        endpoint: '/api/payroll/rates/123',
        success: true,
        effective_date: new Date(),
        reason: 'Annual raise',
        operation: 'update'
      },
      severity: 'medium',
      category: 'data_modification'
    };
    
    console.log('user_id value:', auditData2.user_id);
    console.log('user_id type:', typeof auditData2.user_id);
    
    try {
      await PayrollAuditLog.createAuditEntry(db, auditData2);
      console.log('✓ Success - Audit entry created');
    } catch (error) {
      console.error('✗ Failed:', error.message);
      if (error.code === 121) {
        console.error('Document validation error details:', JSON.stringify(error.errInfo, null, 2));
      }
    }
    
    // Test 3: Check what PayrollAuditLog.createAuditEntry does with undefined user_id
    console.log('\nTest 3: Testing createAuditEntry with undefined user_id');
    console.log('Looking at PayrollAuditLog.createAuditEntry behavior...');
    
    // Let's trace what happens in createAuditEntry
    const testData = {
      user_id: undefined,
      action: 'update_rate',
      entity_type: 'payroll_rate'
    };
    
    console.log('Input user_id:', testData.user_id);
    console.log('After new ObjectId(undefined):', (() => {
      try {
        return new ObjectId(undefined);
      } catch (e) {
        return 'Error: ' + e.message;
      }
    })());
    
    // Test 4: Simulate the middleware scenario
    console.log('\n=== Simulating middleware scenario ===');
    const middlewareData = {
      user_id: mockUser._id || mockUser.user_id, // This pattern from middleware
      user_email: mockUser.email || 'Unknown',
      action: 'view_payroll',
      entity_type: 'payroll_system',
      entity_id: null,
      ip_address: '::1',
      user_agent: 'PostmanRuntime/7.26.8',
      details: {
        request_method: 'GET',
        endpoint: '/api/payroll/rates',
        success: true
      },
      severity: 'low',
      category: 'data_access'
    };
    
    console.log('Middleware user_id:', middlewareData.user_id);
    console.log('Middleware user_id type:', typeof middlewareData.user_id);
    
    try {
      await PayrollAuditLog.createAuditEntry(db, middlewareData);
      console.log('✓ Success - Middleware audit entry created');
    } catch (error) {
      console.error('✗ Failed:', error.message);
      if (error.code === 121) {
        console.error('Document validation error details:', JSON.stringify(error.errInfo, null, 2));
      }
    }
    
  } catch (error) {
    console.error('Fatal error:', error);
  } finally {
    if (client) {
      await client.close();
      console.log('\nDisconnected from MongoDB');
    }
  }
}

// Run the debug script
debugAuditIssue().catch(console.error);