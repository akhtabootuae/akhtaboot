# Customer API Documentation

This document provides comprehensive information about the Customer and Vehicle management API endpoints.

## Authentication

All API endpoints require JWT authentication. Include the JWT token in the Authorization header:

```
Authorization: Bearer YOUR_JWT_TOKEN
```

## Customer Model

The Customer model contains the following fields:

```javascript
{
  "first_name": "String",   // Required
  "last_name": "String",    // Required
  "email": "String",        // Required, unique, email format
  "phone": "String",
  "city": "String",
  "country": "String",
  
  // Branch information
  "branch": {
    "branch_id": ObjectId,  // Reference to branch
    "branch_name": "String",
    "branch_code": "String",
    "location": "String"
  },
  
  // Vehicle information
  "vehicles": [
    {
      "vehicle_id": Number,      // Optional RDBMS ID
      "vin": "String",           // Vehicle Identification Number (required)
      "make": "String",          // Vehicle make (required)
      "model": "String",         // Vehicle model (required)
      "year": Number,            // Manufacture year (required)
      "license_plate": "String", // License plate number
      "color": "String",         // Vehicle color
      "vehicle_type": "String",  // Type/category of vehicle
      "created_at": Date,
      "updated_at": Date
    }
  ],
  
  "created_at": Date,
  "updated_at": Date
}
```

## Customer Endpoints

### Get All Customers
- **URL**: `/api/customers`
- **Method**: GET
- **Required Permission**: view_all_customers
- **Description**: Retrieves a list of all customers
- **Query Parameters**:
  - `branch_id` (optional): Filter customers by branch ID
- **Response**:
```json
[
  {
    "_id": "60d21b4667d0d8992e610c87",
    "first_name": "John",
    "last_name": "Doe",
    "email": "john.doe@example.com",
    "phone": "123-456-7890",
    "city": "New York",
    "country": "USA",
    "branch": {
      "branch_id": "60d21b4667d0d8992e610c85",
      "branch_name": "Main Branch",
      "branch_code": "MB-001",
      "location": "Downtown"
    },
    "vehicles": [
      {
        "vin": "1HGCM82633A123456",
        "make": "Honda",
        "model": "Accord",
        "year": 2023,
        "license_plate": "ABC123",
        "color": "Blue",
        "vehicle_type": "Sedan"
      }
    ],
    "created_at": "2023-05-15T10:30:00.000Z",
    "updated_at": "2023-05-15T10:30:00.000Z"
  }
]
```

### Create Customer
- **URL**: `/api/customers`
- **Method**: POST
- **Required Permission**: create_customer
- **Description**: Creates a new customer
- **Request Body**:
```json
{
  "first_name": "John",
  "last_name": "Doe",
  "email": "john.doe@example.com",
  "phone": "123-456-7890",
  "city": "New York",
  "country": "USA",
  "branch": {
    "branch_id": "60d21b4667d0d8992e610c85",
    "branch_name": "Main Branch",
    "branch_code": "MB-001",
    "location": "Downtown"
  },
  "vehicles": [
    {
      "vin": "1HGCM82633A123456",
      "make": "Honda",
      "model": "Accord",
      "year": 2023,
      "license_plate": "ABC123",
      "color": "Blue",
      "vehicle_type": "Sedan"
    }
  ]
}
```
- **Response**: Returns the created customer object with an ID

### Get Customer by ID
- **URL**: `/api/customers/:id`
- **Method**: GET
- **Required Permission**: view_customer
- **Description**: Retrieves a specific customer by ID
- **Path Parameters**:
  - `id`: Customer ID (ObjectId)
- **Response**: Returns the customer object

### Update Customer
- **URL**: `/api/customers/:id`
- **Method**: PUT
- **Required Permission**: update_customer
- **Description**: Updates a customer's information
- **Path Parameters**:
  - `id`: Customer ID (ObjectId)
- **Request Body**:
```json
{
  "first_name": "John",
  "last_name": "Smith",
  "email": "john.smith@example.com",
  "phone": "987-654-3210",
  "city": "Los Angeles",
  "country": "USA",
  "branch": {
    "branch_id": "60d21b4667d0d8992e610c86",
    "branch_name": "West Branch",
    "branch_code": "WB-002",
    "location": "West Side"
  }
}
```
- **Response**: Returns the updated customer object

### Delete Customer
- **URL**: `/api/customers/:id`
- **Method**: DELETE
- **Required Permission**: delete_customer
- **Description**: Deletes a customer
- **Path Parameters**:
  - `id`: Customer ID (ObjectId)
- **Response**: Returns a success message

### Update Customer Branch
- **URL**: `/api/customers/:id/branch`
- **Method**: PATCH
- **Required Permission**: update_customer
- **Description**: Updates only the branch information for a customer
- **Request Body**:
```json
{
  "branch": {
    "branch_id": "60d21b4667d0d8992e610c85",
    "branch_name": "Main Branch",
    "branch_code": "MB-001",
    "location": "Downtown"
  }
}
```

## Vehicle Endpoints

### Get All Vehicles for Customer
- **URL**: `/api/customers/:customerId/vehicles`
- **Method**: GET
- **Required Permission**: view_customer
- **Description**: Retrieves all vehicles for a specific customer

### Get Vehicle by ID
- **URL**: `/api/customers/:customerId/vehicles/:vehicleId`
- **Method**: GET
- **Required Permission**: view_customer
- **Description**: Retrieves a specific vehicle for a customer

### Add Vehicle to Customer
- **URL**: `/api/customers/:id/vehicles`
- **Method**: POST
- **Required Permission**: update_customer
- **Description**: Adds a new vehicle to a customer's record
- **Path Parameters**:
  - `id`: Customer ID (ObjectId)
- **Request Body**:
```json
{
  "vin": "5YJSA1E63LF123456",
  "make": "Tesla",
  "model": "Model S",
  "year": 2022,
  "license_plate": "EV-123",
  "color": "Red",
  "vehicle_type": "Electric Sedan"
}
```
- **Response**: Returns the updated customer with the new vehicle

### Update Vehicle
- **URL**: `/api/customers/:customerId/vehicles/:vehicleVin`
- **Method**: PUT
- **Required Permission**: update_customer
- **Description**: Updates a vehicle's information
- **Path Parameters**:
  - `customerId`: Customer ID (ObjectId)
  - `vehicleVin`: Vehicle VIN (String)
- **Request Body**:
```json
{
  "license_plate": "EV-456",
  "color": "Black",
  "year": 2023
}
```
- **Response**: Returns the updated customer with the modified vehicle

### Delete Vehicle
- **URL**: `/api/customers/:customerId/vehicles/:vehicleVin`
- **Method**: DELETE
- **Required Permission**: update_customer
- **Description**: Removes a vehicle from a customer's record
- **Path Parameters**:
  - `customerId`: Customer ID (ObjectId)
  - `vehicleVin`: Vehicle VIN (String)
- **Response**: Returns the updated customer without the deleted vehicle

### Add Vehicle to Customer
- **URL**: `/api/customers/:customerId/vehicles`
- **Method**: POST
- **Required Permission**: manage_vehicles
- **Description**: Adds a new vehicle to a customer
- **Request Body**:
```json
{
  "vin": "5YJSA1E40FF123456",
  "make": "Tesla",
  "model": "Model S",
  "year": 2021,
  "license_plate": "EV1234",
  "color": "White", 
  "vehicle_type": "Electric Sedan"
}
```

### Update Vehicle
- **URL**: `/api/customers/:customerId/vehicles/:vehicleId`
- **Method**: PUT
- **Required Permission**: manage_vehicles
- **Description**: Updates a vehicle's information
- **Request Body**:
```json
{
  "license_plate": "NEW123",
  "color": "Red",
  "vehicle_type": "SUV"
}
```

### Delete Vehicle
- **URL**: `/api/customers/:customerId/vehicles/:vehicleId`
- **Method**: DELETE
- **Required Permission**: manage_vehicles
- **Description**: Removes a vehicle from a customer

## Searching and Filtering

### Search Customers
- **URL**: `/api/customers/search`
- **Method**: GET
- **Required Permission**: view_all_customers
- **Description**: Searches for customers based on various criteria
- **Query Parameters**:
  - `name`: Search by first or last name
  - `email`: Search by email
  - `phone`: Search by phone number
  - `city`: Filter by city
  - `country`: Filter by country
  - `branch_id`: Filter by branch

### Search Vehicles
- **URL**: `/api/customers/vehicles/search`
- **Method**: GET
- **Required Permission**: view_all_customers
- **Description**: Searches for vehicles across all customers
- **Query Parameters**:
  - `vin`: Search by VIN
  - `make`: Filter by vehicle make
  - `model`: Filter by vehicle model
  - `year`: Filter by manufacture year
  - `license_plate`: Search by license plate

## Error Handling

The API returns appropriate HTTP status codes:
- 200: Success
- 201: Resource created
- 400: Bad request (validation error)
- 401: Unauthorized
- 403: Forbidden (insufficient permissions)
- 404: Not found
- 500: Server error

## Error Responses

All API endpoints follow a standard error response format:

```json
{
  "message": "Error message",
  "error": "Detailed error information"
}
```

Common HTTP status codes:

- **200**: Success
- **201**: Created
- **400**: Bad Request (missing required fields, validation errors)
- **401**: Unauthorized (missing or invalid token)
- **403**: Forbidden (insufficient permissions)
- **404**: Not Found (resource not found)
- **500**: Server Error (unexpected errors)

## Data Validation

MongoDB schema validation ensures that:
- Customer requires first_name, last_name, email, and vehicles array
- Email must be in valid format
- Vehicles require vin, make, model, and year fields
- Year must be an integer
- The branch object's branch_id must be a valid MongoDB ObjectId (not a string)
  
> **Important**: When sending branch data, the API will automatically convert string branch_id to ObjectId. However, the branch_id must be a valid 24-character hex string (e.g., "60d21b4667d0d8992e610c85").

Example of validation error response:
```json
{
  "message": "Validation error",
  "error": "Document failed validation",
  "details": "Schema validation failed"
}
```
