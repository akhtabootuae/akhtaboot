/**
 * System-wide permission definitions for the application
 * These are the available permissions that can be assigned to users
 */

const PERMISSIONS = {
  // User Management
  USER_MANAGEMENT: [
    { id: "view_all_users", name: "view_all_users", description: "View all users in the system" },
    { id: "view_users", name: "view_users", description: "View basic user information" },
    { id: "create_user", name: "create_user", description: "Create new users" },
    { id: "update_user", name: "update_user", description: "Update existing user information" },
    { id: "delete_user", name: "delete_user", description: "Remove users from the system" },
    { id: "manage_user_status", name: "manage_user_status", description: "Activate/deactivate user accounts" },
    { id: "view_users_by_role", name: "view_users_by_role", description: "View users with a specific role" }
  ],

  // Role & Permission Management
  ROLE_MANAGEMENT: [
    { id: "manage_permissions", name: "manage_permissions", description: "Assign or revoke user permissions" },
    { id: "manage_roles", name: "manage_roles", description: "Assign roles to users" },
    { id: "view_permission_logs", name: "view_permission_logs", description: "Access permission change history" },
    { id: "manage_user_branches", name: "manage_user_branches", description: "Change user branch assignments" }
  ],

  // Customer & Vehicle Management
  CUSTOMER_MANAGEMENT: [
    { id: "view_all_customers", name: "view_all_customers", description: "View all customers in the system" },
    { id: "view_customer", name: "view_customer", description: "View specific customer details" },
    { id: "create_customer", name: "create_customer", description: "Create new customer records" },
    { id: "update_customer", name: "update_customer", description: "Update customer information" },
    { id: "delete_customer", name: "delete_customer", description: "Remove customers" },
    { id: "manage_vehicles", name: "manage_vehicles", description: "Add/update/remove customer vehicles" }
  ],

  // Customer Review Management
  CUSTOMER_REVIEW_MANAGEMENT: [
    { id: "view_customer_reviews", name: "view_customer_reviews", description: "View customer reviews and ratings" },
    { id: "create_customer_reviews", name: "create_customer_reviews", description: "Create new customer reviews" },
    { id: "update_customer_reviews", name: "update_customer_reviews", description: "Update existing customer reviews" },
    { id: "delete_customer_reviews", name: "delete_customer_reviews", description: "Delete customer reviews" },
    { id: "export_customer_reviews", name: "export_customer_reviews", description: "Export customer review data" },
    { id: "view_review_statistics", name: "view_review_statistics", description: "View customer review statistics and analytics" }
  ],

  // Invoice Management
  INVOICE_MANAGEMENT: [
    { id: "view_all_invoices", name: "view_all_invoices", description: "View all invoices in the system" },
    { id: "view_invoice", name: "view_invoice", description: "View specific invoice details" },
    { id: "create_invoice", name: "create_invoice", description: "Create new invoice records" },
    { id: "update_invoice", name: "update_invoice", description: "Update invoice information" },
    { id: "delete_invoice", name: "delete_invoice", description: "Remove invoices" },
    { id: "manage_payments", name: "manage_payments", description: "Add/update/remove payment records" },
    { id: "manage_invoice_images", name: "manage_invoice_images", description: "Add/remove images related to invoices" },
    { id: "manage_external_services", name: "manage_external_services", description: "Add/update/remove external services for invoices" },
    { id: "view_external_services", name: "view_external_services", description: "View external service details and images" },
    { id: "manage_signed_invoices", name: "manage_signed_invoices", description: "Upload/update/remove signed invoice documents" },
    { id: "view_signed_invoices", name: "view_signed_invoices", description: "View and download signed invoice documents" }
  ],

  // Work Order Management
  WORK_ORDER_MANAGEMENT: [
    { id: "view_all_work_orders", name: "view_all_work_orders", description: "View all work orders in the system" },
    { id: "view_work_order", name: "view_work_order", description: "View specific work order details" },
    { id: "create_work_order", name: "create_work_order", description: "Create new work order records" },
    { id: "update_work_order", name: "update_work_order", description: "Update work order information" },
    { id: "delete_work_order", name: "delete_work_order", description: "Remove work orders" },
    { id: "update_work_order_status", name: "update_work_order_status", description: "Change the status of work orders" },
    { id: "manage_work_order_parts", name: "manage_work_order_parts", description: "Add/update parts in work orders" },
    { id: "update_work_order_part_status", name: "update_work_order_part_status", description: "Change the status of parts in work orders" },
    { id: "manage_work_order_stages", name: "manage_work_order_stages", description: "Add/update stages in work order parts" },
    { id: "update_work_order_stage_status", name: "update_work_order_stage_status", description: "Change the status of stages in work order parts" },
    { id: "manage_work_order_logs", name: "manage_work_order_logs", description: "Add time tracking logs to work order stages" }
  ],

  // Error Reporting Management
  ERROR_REPORTING: [
    { id: "report_stage_error", name: "report_stage_error", description: "Report errors found in work order stages" },
    { id: "view_error_reports", name: "view_error_reports", description: "View error reports for work orders" },
    { id: "acknowledge_error_reports", name: "acknowledge_error_reports", description: "Acknowledge error reports as reviewed" },
    { id: "resolve_error_reports", name: "resolve_error_reports", description: "Mark error reports as resolved" },
    { id: "mark_stage_redo", name: "mark_stage_redo", description: "Mark stages as needing to be redone" }
  ],

  // Manner Evaluation Management
  MANNER_EVALUATION: [
    { id: "view_manner_evaluations", name: "view_manner_evaluations", description: "View manner evaluations for users" },
    { id: "manage_manner_evaluations", name: "manage_manner_evaluations", description: "Create, update, and delete manner evaluations for users" }
  ],
  
  // Stage Management
  STAGE_MANAGEMENT: [
    { id: "manage_stages", name: "manage_stages", description: "Create, update, or delete workflow stages" },
  ],
  
  // Variation Management
  VARIATION_MANAGEMENT: [
    { id: "manage_variations", name: "manage_variations", description: "Create, update, or delete service variations" },
  ],

  // Branch Management
  BRANCH_MANAGEMENT: [
    { id: "view_branch_data", name: "view_branch_data", description: "Access branch-specific information" },
    { id: "manage_branch", name: "manage_branch", description: "Update branch details" },
    { id: "export_branch_data", name: "export_branch_data", description: "Export branch-specific reports" }
  ],

// begad moussa
  // Case Management
  CASE_MANAGEMENT: [
    { id: "access_case_management", name: "access_case_management", description: "Access Case Management section in sidebar" },
    { id: "view_all_cases", name: "view_all_cases", description: "View all cases in the system" },
    { id: "view_case", name: "view_case", description: "View specific case details" },
    { id: "create_case", name: "create_case", description: "Create new case records" },
    { id: "update_case", name: "update_case", description: "Update case information" },
    { id: "delete_case", name: "delete_case", description: "Remove cases from the system" },
    { id: "resolve_case", name: "resolve_case", description: "Mark cases as resolved" },
    { id: "close_case", name: "close_case", description: "Close cases permanently" },
    { id: "assign_case", name: "assign_case", description: "Assign cases to users" },
    { id: "add_case_notes", name: "add_case_notes", description: "Add notes to cases" },
    { id: "manage_case_attachments", name: "manage_case_attachments", description: "Upload and manage case attachments" },
    { id: "view_case_attachments", name: "view_case_attachments", description: "View and download case attachments" },
    { id: "view_case_stats", name: "view_case_stats", description: "View case statistics and reports" }
  ],
  
  // Payroll Management
  PAYROLL_MANAGEMENT: [
    { id: "access_payroll", name: "access_payroll", description: "Access Payroll section in sidebar" },
    { id: "payroll_view", name: "payroll_view", description: "View payroll data and employee rates" },
    { id: "payroll_manage_rates", name: "payroll_manage_rates", description: "Manage employee daily rates" },
    { id: "payroll_manage_deductions", name: "payroll_manage_deductions", description: "Manage employee deductions" },
    { id: "payroll_view_deductions", name: "payroll_view_deductions", description: "View employee deductions" },
    { id: "payroll_manage_deduction_types", name: "payroll_manage_deduction_types", description: "Manage deduction types" },
    { id: "payroll_approve_deductions", name: "payroll_approve_deductions", description: "Approve employee deductions" },
    { id: "payroll_view_deduction_history", name: "payroll_view_deduction_history", description: "View deduction history and reports" },
    { id: "payroll_process", name: "payroll_process", description: "Process payroll calculations" },
    { id: "payroll_attendance", name: "payroll_attendance", description: "Manage attendance records" },
    
    // Phase 3: Attendance & Pay Calculation
    { id: "payroll_view_timesheets", name: "payroll_view_timesheets", description: "View employee timesheets" },
    { id: "payroll_manage_timesheets", name: "payroll_manage_timesheets", description: "Create and edit employee timesheets" },
    { id: "payroll_approve_timesheets", name: "payroll_approve_timesheets", description: "Approve or reject timesheets" },
    { id: "payroll_view_pay_periods", name: "payroll_view_pay_periods", description: "View pay periods" },
    { id: "payroll_manage_pay_periods", name: "payroll_manage_pay_periods", description: "Create and manage pay periods" },
    { id: "payroll_view_calculations", name: "payroll_view_calculations", description: "View payroll calculations" },
    { id: "payroll_approve", name: "payroll_approve", description: "Approve payroll calculations" },
    
    // Phase 4: Reporting & Paystubs
    { id: "payroll_view_reports", name: "payroll_view_reports", description: "View payroll reports" },
    { id: "payroll_generate_reports", name: "payroll_generate_reports", description: "Generate payroll reports" },
    { id: "payroll_view_paystubs", name: "payroll_view_paystubs", description: "View employee paystubs" },
    { id: "payroll_generate_paystubs", name: "payroll_generate_paystubs", description: "Generate employee paystubs" },
    
    // Phase 5: Advanced Features
    { id: "payroll_manage_alerts", name: "payroll_manage_alerts", description: "Manage payroll alerts and notifications" },
    { id: "payroll_view_alerts", name: "payroll_view_alerts", description: "View payroll alerts" },
    { id: "payroll_manage_budgets", name: "payroll_manage_budgets", description: "Manage payroll budgets" },
    { id: "payroll_view_budgets", name: "payroll_view_budgets", description: "View payroll budgets" },
    { id: "payroll_admin", name: "payroll_admin", description: "Full payroll system administration" }
  ],

  // Finance Management
  FINANCE_MANAGEMENT: [
    { id: "access_finance", name: "access_finance", description: "Access Finance section in sidebar" },
    { id: "view_financial_reports", name: "view_financial_reports", description: "View financial reports and dashboards" },
    { id: "manage_financial_data", name: "manage_financial_data", description: "Manage financial data and settings" },
    { id: "export_financial_data", name: "export_financial_data", description: "Export financial reports and data" }
  ],

  // Expense Management
  EXPENSE_MANAGEMENT: [
    { id: "view_all_expenses", name: "view_all_expenses", description: "View all expenses in the system" },
    { id: "view_expense", name: "view_expense", description: "View specific expense details" },
    { id: "create_expense", name: "create_expense", description: "Create new expense records" },
    { id: "edit_expense", name: "edit_expense", description: "Edit existing expense records" },
    { id: "delete_expense", name: "delete_expense", description: "Delete expense records" },
    { id: "delete_approved_expenses", name: "delete_approved_expenses", description: "Delete approved expense records" },
    { id: "approve_expenses", name: "approve_expenses", description: "Approve or reject expense records" },
    { id: "manage_expense_images", name: "manage_expense_images", description: "Add/remove receipt images from expenses" },
    { id: "view_expense_stats", name: "view_expense_stats", description: "View expense statistics and reports" },
    { id: "export_expenses", name: "export_expenses", description: "Export expense data and reports" }
  ],

  // Financial Management & Reporting
  FINANCIAL_MANAGEMENT: [
    { id: "view_financial_reports", name: "view_financial_reports", description: "View financial reports, analytics, and dashboard" },
    { id: "generate_financial_reports", name: "generate_financial_reports", description: "Generate and export financial reports" },
    { id: "view_profit_loss", name: "view_profit_loss", description: "View profit and loss statements" },
    { id: "view_cash_flow", name: "view_cash_flow", description: "View cash flow analysis and reports" },
    { id: "compare_branch_performance", name: "compare_branch_performance", description: "Compare financial performance across branches" }
  ],

  // Messaging & Communication
  MESSAGING_MANAGEMENT: [
    { id: "send_messages", name: "send_messages", description: "Send messages in conversations" },
    { id: "view_all_conversations", name: "view_all_conversations", description: "View all conversations in the system" },
    { id: "create_group_conversations", name: "create_group_conversations", description: "Create new group conversations" },
    { id: "send_announcements", name: "send_announcements", description: "Send system-wide announcements" },
    { id: "manage_group_conversations", name: "manage_group_conversations", description: "Manage group conversation settings and members" },
    { id: "view_conversation_history", name: "view_conversation_history", description: "View conversation message history" }
  ],

  // System Administration
  SYSTEM_ADMINISTRATION: [
    { id: "export_users", name: "export_users", description: "Export user data" },
    { id: "system_configuration", name: "system_configuration", description: "Access system settings" },
    { id: "view_system_logs", name: "view_system_logs", description: "Access system activity logs" }
  ]
};

/**
 * Get all permissions as a flat array
 * @returns {Array} All permissions from all categories
 */
function getAllPermissions() {
  return Object.values(PERMISSIONS).flat();
}

/**
 * Get default permissions for a specific role
 * @param {string} roleName The name of the role
 * @returns {Array} Array of permission objects with granted flag
 */
function getDefaultPermissionsForRole(roleName) {
  const allPermissions = getAllPermissions();
  
  // Define which permissions are granted by default for each role
  switch (roleName) {
    case 'Admin':
      // Admin has all permissions by default, but we still provide them explicitly 
      // so they appear in the permissions array
      return allPermissions.map(p => ({ 
        permission_id: p.id, 
        permission_name: p.name,
        permission_description: p.description,
        granted: true
      }));
    
    case 'Supervisor':
      return allPermissions.map(p => {
        // Define which permissions a supervisor should have
        const supervisorPermissions = [
          // User Management (partial)
          'view_all_users', 'view_users', 'view_users_by_role',
          
          // Customer Management (all)
          'view_all_customers', 'view_customer', 'create_customer', 
          'update_customer', 'manage_vehicles',
          
          // Customer Review Management (all)
          'view_customer_reviews', 'create_customer_reviews', 'update_customer_reviews',
          'delete_customer_reviews', 'export_customer_reviews', 'view_review_statistics',
          
          // Invoice Management (all)
          'view_all_invoices', 'view_invoice', 'create_invoice', 
          'update_invoice', 'delete_invoice', 'manage_payments', 
          'manage_invoice_images',
          
          // Work Order Management (all)
          'view_all_work_orders', 'view_work_order', 'create_work_order', 
          'update_work_order', 'delete_work_order', 'manage_work_items', 
          'update_work_order_status', 'manage_work_order_parts', 'manage_work_order_stages',
          'update_work_order_stage_status', 'manage_work_order_logs',
          
          // Error Reporting (all)
          'report_stage_error', 'view_error_reports', 'acknowledge_error_reports',
          'resolve_error_reports', 'mark_stage_redo',
          
          // Case Management (all - but NO sidebar access by default)
          'view_all_cases', 'view_case', 'create_case', 'update_case', 
          'delete_case', 'resolve_case', 'close_case', 'assign_case',
          'add_case_notes', 'manage_case_attachments', 'view_case_attachments', 'view_case_stats',

          // Manner Evaluation Management (all)
          'view_manner_evaluations', 'manage_manner_evaluations',

          // Expense Management (all)
          'view_all_expenses', 'view_expense', 'create_expense', 'edit_expense', 
          'delete_expense', 'delete_approved_expenses', 'approve_expenses', 
          'manage_expense_images', 'view_expense_stats', 'export_expenses',

          // Financial Management & Reporting (all)
          'view_financial_reports', 'generate_financial_reports', 'view_profit_loss',
          'view_cash_flow', 'compare_branch_performance',

          // Messaging & Communication (all)
          'send_messages', 'view_all_conversations', 'create_group_conversations', 
          'send_announcements', 'manage_group_conversations', 'view_conversation_history',

          // Branch Management (partial)
          'view_branch_data', 'export_branch_data',
          
          // Payroll Management (partial - but NO sidebar access by default)
          'payroll_view', 'payroll_manage_rates', 'payroll_view_deductions', 
          'payroll_manage_deductions', 'payroll_approve_deductions', 'payroll_view_deduction_history',
          'payroll_view_timesheets', 'payroll_manage_timesheets', 'payroll_approve_timesheets',
          'payroll_view_pay_periods', 'payroll_manage_pay_periods', 'payroll_view_calculations',
          'payroll_approve', 'payroll_process', 'payroll_view_reports', 'payroll_generate_reports',
          'payroll_view_paystubs', 'payroll_generate_paystubs',
          
          // Finance Management (partial - but NO sidebar access by default)
          'view_financial_reports', 'manage_financial_data', 'export_financial_data',

          // Messaging & Communication (limited)
          'send_messages', 'create_group_conversations', 'view_conversation_history',

          // System Administration (partial)
          'export_users'
        ];
        
        return { 
          permission_id: p.id, 
          permission_name: p.name,
          permission_description: p.description,
          granted: supervisorPermissions.includes(p.name)
        };
      });
    
    case 'Accountant':
      return allPermissions.map(p => {
        // Define which permissions an accountant should have
        const accountantPermissions = [
          // User Management (limited - viewing only)
          'view_all_users', 'view_users', 'view_users_by_role',
          
          // Customer Management (full access for registration and invoicing)
          'view_all_customers', 'view_customer', 'create_customer', 
          'update_customer', 'manage_vehicles',
          
          // Work Order Management (creation and viewing for invoice purposes)
          'view_all_work_orders', 'view_work_order', 'create_work_order',
          'update_work_order', 'manage_work_order_parts',
          
          // Invoice Management (full access)
          'view_all_invoices', 'view_invoice', 'create_invoice', 
          'update_invoice', 'delete_invoice', 'manage_payments', 
          'manage_invoice_images', 'manage_external_services', 'view_external_services',
          'manage_signed_invoices', 'view_signed_invoices',
          
          // Financial Management & Reporting (full access)
          'access_finance', 'view_financial_reports', 'generate_financial_reports', 
          'view_profit_loss', 'view_cash_flow', 'compare_branch_performance',
          'manage_financial_data', 'export_financial_data',

          // Expense Management (full access)
          'view_all_expenses', 'view_expense', 'create_expense', 'edit_expense', 
          'delete_expense', 'delete_approved_expenses', 'approve_expenses', 
          'manage_expense_images', 'view_expense_stats', 'export_expenses',

          // Payroll Management (full access)
          'access_payroll', 'payroll_view', 'payroll_manage_rates', 'payroll_view_deductions', 
          'payroll_manage_deductions', 'payroll_manage_deduction_types', 'payroll_approve_deductions', 
          'payroll_view_deduction_history', 'payroll_process', 'payroll_attendance',
          'payroll_view_timesheets', 'payroll_manage_timesheets', 'payroll_approve_timesheets',
          'payroll_view_pay_periods', 'payroll_manage_pay_periods', 'payroll_view_calculations',
          'payroll_approve', 'payroll_view_reports', 'payroll_generate_reports',
          'payroll_view_paystubs', 'payroll_generate_paystubs', 'payroll_manage_alerts',
          'payroll_view_alerts', 'payroll_manage_budgets', 'payroll_view_budgets',

          // Branch Management (view only for financial analysis)
          'view_branch_data', 'export_branch_data',

          // Messaging & Communication (limited)
          'send_messages', 'view_conversation_history',

          // System Administration (limited)
          'export_users'
        ];
        
        return { 
          permission_id: p.id, 
          permission_name: p.name,
          permission_description: p.description,
          granted: accountantPermissions.includes(p.name)
        };
      });
    
    case 'Technician':
      return allPermissions.map(p => {
        // Define which permissions a technician should have
        const technicianPermissions = [
          // User Management (limited)
          'view_users',
          
          // Customer Management (limited)
          'view_customer', 'view_all_customers',
          
          // Customer Review Management (view only)
          'view_customer_reviews', 'view_review_statistics',
          
          // Invoice Management (limited)
          'view_invoice',
          
          // Work Order Management (partial)
          'view_work_order', 'view_all_work_orders',
          'update_work_order_status', 'manage_work_items',
          'update_work_order_stage_status', 'manage_work_order_logs',
          
          // Error Reporting (partial - can report but not manage)
          'report_stage_error', 'view_error_reports',

          // Case Management (limited - but NO sidebar access by default)
          'view_all_cases', 'view_case', 'create_case', 'update_case', 
          'add_case_notes', 'manage_case_attachments', 'view_case_attachments', 'view_case_stats',

          // Manner Evaluation Management (limited - view only)
          'view_manner_evaluations',

          // Expense Management (limited - can view and create but not approve)
          'view_all_expenses', 'view_expense', 'create_expense', 'edit_expense', 
          'manage_expense_images', 'view_expense_stats',

          // Messaging & Communication (limited)
          'send_messages', 'view_conversation_history',

          // Branch Management (limited)
          'view_branch_data'
        ];
        
        return { 
          permission_id: p.id, 
          permission_name: p.name,
          permission_description: p.description,
          granted: technicianPermissions.includes(p.name)
        };
      });
      
    case 'Customer':
      return allPermissions.map(p => {
        // Define which permissions a customer should have (very limited)
        const customerPermissions = [
          // Customer Review Management (create only)
          'create_customer_reviews'
        ];
        
        return { 
          permission_id: p.id, 
          permission_name: p.name,
          permission_description: p.description,
          granted: customerPermissions.includes(p.name)
        };
      });

    case 'Feedback Screen':
      return allPermissions.map(p => {
        // Define which permissions a feedback role should have
        const feedbackPermissions = [
          // User Management (limited - view users for feedback purposes)
          'view_users'
        ];
        
        return { 
          permission_id: p.id, 
          permission_name: p.name,
          permission_description: p.description,
          granted: feedbackPermissions.includes(p.name)
        };
      });
      
    default:
      // Default case returns all permissions as not granted
      return allPermissions.map(p => ({ 
        permission_id: p.id, 
        permission_name: p.name,
        permission_description: p.description,
        granted: false
      }));
  }
}

module.exports = {
  PERMISSIONS,
  getAllPermissions,
  getDefaultPermissionsForRole
};
