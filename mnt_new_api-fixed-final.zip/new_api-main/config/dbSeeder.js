const bcrypt = require('bcryptjs');
const { ObjectId } = require('mongodb');
const { User, Role, Branch, Customer, WorkOrder, Variation, WorkOrderQA } = require('../models');
const { getDefaultPermissionsForRole } = require('./permissions');

/**
 * Seeds the database with initial data including the default admin user
 * @param {Object} db MongoDB database connection
 */
async function seedDatabase(db) {
  try {
    // First seed roles, then create admin user with reference to the Admin role
    await seedRoles(db);
    await seedBranches(db);
    await seedAdminUser(db);
    await seedTechnicians(db);
    await seedCustomerUser(db);
    await updateExistingUserRoles(db);
    await updateExistingUserBranches(db);
    await updateExistingUserPermissions(db);
    await updateExistingUsersMannerEvaluations(db);
    await seedStages(db);
    await seedVariations(db);
    await seedCustomers(db);
    await seedWorkOrders(db);
    await seedNotifications(db);
    await updateWorkOrdersValidation(db);
    await initializePayrollForUsers(db);
    await seedPayrollCollections(db);
    await seedPayrollAuditLogs(db);
    await seedWorkOrderQA(db);
  } catch (error) {
    console.error('Error seeding database:', error);
    throw error;
  }
}

/**
 * Seeds the database with the default admin user
 * @param {Object} db MongoDB database connection
 */
async function seedAdminUser(db) {
  try {
    console.log('Checking if admin user exists...');
    
    // Check if admin user already exists
    const adminExists = await db.collection('users').findOne({ 
      email: process.env.ADMIN_EMAIL 
    });
    
    if (adminExists) {
      console.log('Admin user already exists, skipping creation');
      return;
    }
    
    // Get the Admin role from the roles collection
    const adminRole = await db.collection('roles').findOne({ role_name: "Admin" });
    
    if (!adminRole) {
      console.error('Admin role not found. Please make sure roles are seeded first.');
      return;
    }
    
    console.log('Creating default admin user...');
    
    // Generate salt and hash password
    const salt = await bcrypt.genSalt(10);
    const password_hash = await bcrypt.hash(process.env.ADMIN_PASSWORD, salt);
    
    // Get the Sharjah Branch from the branches collection
    const mainBranch = await db.collection('branches').findOne({ branch_code: "SJH" });
    
    if (!mainBranch) {
      console.error('Sharjah Branch not found. Please make sure branches are seeded first.');
      return;
    }
    
    // Get default permissions for Admin role
    const adminPermissions = getDefaultPermissionsForRole("Admin");
    
    // Create admin user with environment variables
    const adminUser = {
      first_name: process.env.ADMIN_FIRST_NAME,
      last_name: process.env.ADMIN_LAST_NAME,
      email: process.env.ADMIN_EMAIL,
      password_hash, // Use the hashed password
      phone: "",
      is_active: true,
      staff_code: "ADMIN001",

      // Admin users don't have specialties - only technicians do
      // Using the Admin role from the roles collection
      role_id: adminRole._id,
      role_name: adminRole.role_name,
      role_description: adminRole.description,
      // Using Main Branch from the branches collection
      branch: {
        branch_id: mainBranch._id,
        branch_name: mainBranch.branch_name,
        branch_code: mainBranch.branch_code,
        branch_name_ar: mainBranch.branch_name_ar,
        location: mainBranch.location
      },
      permissions: adminPermissions,
      permission_logs: [],
      manner_evaluations: [],
      manner_evaluation_logs: [],
      created_at: new Date(),
      updated_at: new Date()
    };
    
    // Insert admin user
    const result = await db.collection('users').insertOne(adminUser);
    
    console.log(`Default admin user created successfully with ID: ${result.insertedId}`);
    
  } catch (error) {
    console.error('Error seeding admin user:', error);
    throw error;
  }
}

/**
 * Seeds the database with more users for all roles
 * @param {Object} db MongoDB database connection
 */
async function seedTechnicians(db) {
  try {
    console.log('Checking if users exist...');
    
    // Check if users already exist
    const usersExist = await db.collection('users').findOne({ 
      $or: [
        { email: 'supervisor@example.com' },
        { email: 'technician1@example.com' },
        { email: 'technician2@example.com' },
        { email: 'supervisor2@example.com' },
        { email: 'technician3@example.com' },
        { email: 'technician4@example.com' },
        { email: 'admin2@example.com' }
      ]
    });
    
    if (usersExist) {
      console.log('Additional users already exist, skipping creation');
      return;
    }
    
    // Get all roles
    const adminRole = await db.collection('roles').findOne({ role_name: "Admin" });
    const supervisorRole = await db.collection('roles').findOne({ role_name: "Supervisor" });
    const technicianRole = await db.collection('roles').findOne({ role_name: "Technician" });
    
    if (!adminRole || !supervisorRole || !technicianRole) {
      console.error('Required roles not found. Please make sure roles are seeded first.');
      return;
    }
    
    // Get the Sharjah Branch
    const mainBranch = await db.collection('branches').findOne({ branch_code: "SJH" });
    
    if (!mainBranch) {
      console.error('Sharjah Branch not found. Please make sure branches are seeded first.');
      return;
    }
    
    console.log('Creating more users for all roles...');
    
    // Generate hashed password (using same password for all test users)
    const salt = await bcrypt.genSalt(10);
    const password_hash = await bcrypt.hash('password123', salt);
    
    const now = new Date();
    
    // Get default permissions for each role
    const adminPermissions = getDefaultPermissionsForRole("Admin");
    const supervisorPermissions = getDefaultPermissionsForRole("Supervisor");
    const technicianPermissions = getDefaultPermissionsForRole("Technician");
    
    // Create additional admin user
    const adminUser2 = {
      first_name: "Omar",
      last_name: "Hassan",
      email: "admin2@example.com",
      password_hash,
      phone: "+971506789012",
      is_active: true,
      staff_code: "ADMIN002",
      // Admin users don't have specialties - only technicians do
      role_id: adminRole._id,
      role_name: adminRole.role_name,
      role_description: adminRole.description,
      branch: {
        branch_id: mainBranch._id,
        branch_name: mainBranch.branch_name,
        branch_code: mainBranch.branch_code,
        branch_name_ar: mainBranch.branch_name_ar,
        location: mainBranch.location
      },
      permissions: adminPermissions,
      permission_logs: [],
      created_at: now,
      updated_at: now
    };
    
    // Create first supervisor user
    const supervisorUser = {
      first_name: "Sarah",
      last_name: "Ahmed",
      email: "supervisor@example.com",
      password_hash,
      phone: "+971501234567",
      is_active: true,
      staff_code: "SUP001",
      role_id: supervisorRole._id,
      role_name: supervisorRole.role_name,
      role_description: supervisorRole.description,
      branch: {
        branch_id: mainBranch._id,
        branch_name: mainBranch.branch_name,
        branch_code: mainBranch.branch_code,
        branch_name_ar: mainBranch.branch_name_ar,
        location: mainBranch.location
      },
      permissions: supervisorPermissions,
      permission_logs: [],
      manner_evaluations: [],
      manner_evaluation_logs: [],
      created_at: now,
      updated_at: now
    };
    
    // Create second supervisor user
    const supervisorUser2 = {
      first_name: "Nadia",
      last_name: "Al-Rashid",
      email: "supervisor2@example.com",
      password_hash,
      phone: "+971507890123",
      is_active: true,
      staff_code: "SUP002",
      role_id: supervisorRole._id,
      role_name: supervisorRole.role_name,
      role_description: supervisorRole.description,
      branch: {
        branch_id: mainBranch._id,
        branch_name: mainBranch.branch_name,
        branch_code: mainBranch.branch_code,
        branch_name_ar: mainBranch.branch_name_ar,
        location: mainBranch.location
      },
      permissions: supervisorPermissions,
      permission_logs: [],
      created_at: now,
      updated_at: now
    };
    
    // Create technician users
    const technicians = [
      {
        first_name: "Mohammed",
        last_name: "Ali",
        email: "technician1@example.com",
        password_hash,
        phone: "+971502345678",
        is_active: true,
        staff_code: "TECH001",
        speciality: "PDR",
        role_id: technicianRole._id,
        role_name: technicianRole.role_name,
        role_description: technicianRole.description,
        branch: {
          branch_id: mainBranch._id,
          branch_name: mainBranch.branch_name,
          branch_code: mainBranch.branch_code,
          branch_name_ar: mainBranch.branch_name_ar,
          location: mainBranch.location
        },
        permissions: technicianPermissions,
        permission_logs: [],
        manner_evaluations: [],
        manner_evaluation_logs: [],
        created_at: now,
        updated_at: now
      },
      {
        first_name: "Ahmed",
        last_name: "Khalid",
        email: "technician2@example.com",
        password_hash,
        phone: "+971503456789",
        is_active: true,
        staff_code: "TECH002",
        speciality: "Paint",
        role_id: technicianRole._id,
        role_name: technicianRole.role_name,
        role_description: technicianRole.description,
        branch: {
          branch_id: mainBranch._id,
          branch_name: mainBranch.branch_name,
          branch_code: mainBranch.branch_code,
          branch_name_ar: mainBranch.branch_name_ar,
          location: mainBranch.location
        },
        permissions: technicianPermissions,
        permission_logs: [],
        manner_evaluations: [],
        manner_evaluation_logs: [],
        created_at: now,
        updated_at: now
      },
      {
        first_name: "Youssef",
        last_name: "Ibrahim",
        email: "technician3@example.com",
        password_hash,
        phone: "+971508901234",
        is_active: true,
        staff_code: "TECH003",
        speciality: "Fix/Remove",
        role_id: technicianRole._id,
        role_name: technicianRole.role_name,
        role_description: technicianRole.description,
        branch: {
          branch_id: mainBranch._id,
          branch_name: mainBranch.branch_name,
          branch_code: mainBranch.branch_code,
          branch_name_ar: mainBranch.branch_name_ar,
          location: mainBranch.location
        },
        permissions: technicianPermissions,
        permission_logs: [],
        created_at: now,
        updated_at: now
      },
      {
        first_name: "Rashid",
        last_name: "Hokal",
        email: "technician4@example.com",
        password_hash,
        phone: "+971509012345",
        is_active: true,
        staff_code: "TECH004",
        speciality: "Body Work",
        role_id: technicianRole._id,
        role_name: technicianRole.role_name,
        role_description: technicianRole.description,
        branch: {
          branch_id: mainBranch._id,
          branch_name: mainBranch.branch_name,
          branch_code: mainBranch.branch_code,
          branch_name_ar: mainBranch.branch_name_ar,
          location: mainBranch.location
        },
        permissions: technicianPermissions,
        permission_logs: [],
        created_at: now,
        updated_at: now
      }
    ];
    
    // Insert additional admin
    const adminResult2 = await db.collection('users').insertOne(adminUser2);
    console.log(`Additional admin user created with ID: ${adminResult2.insertedId}`);
    
    // Insert supervisors
    const supervisorResult = await db.collection('users').insertOne(supervisorUser);
    console.log(`Supervisor user created with ID: ${supervisorResult.insertedId}`);
    
    const supervisorResult2 = await db.collection('users').insertOne(supervisorUser2);
    console.log(`Second supervisor user created with ID: ${supervisorResult2.insertedId}`);
    
    // Insert technicians
    const technicianResult = await db.collection('users').insertMany(technicians);
    console.log(`${technicianResult.insertedCount} technician users created successfully`);
    
    return {
      admin: { ...adminUser2, _id: adminResult2.insertedId },
      supervisors: [
        { ...supervisorUser, _id: supervisorResult.insertedId },
        { ...supervisorUser2, _id: supervisorResult2.insertedId }
      ],
      technicians: technicians.map((tech, index) => ({
        ...tech,
        _id: technicianResult.insertedIds[index]
      }))
    };
    
  } catch (error) {
    console.error('Error seeding users:', error);
    throw error;
  }
}

/**
 * Seeds the database with a customer user for frontend access
 * @param {Object} db MongoDB database connection
 */
async function seedCustomerUser(db) {
  try {
    console.log('Checking if customer user exists...');
    
    // Check if customer user already exists
    const customerUserExists = await db.collection('users').findOne({ 
      email: 'customer@example.com'
    });
    
    if (customerUserExists) {
      console.log('Customer user already exists, skipping creation');
      return;
    }
    
    // Get Feedback Screen role
    const customerRole = await db.collection('roles').findOne({ 
      role_name: "Feedback Screen" 
    });
    
    if (!customerRole) {
      console.error('Feedback Screen role not found. Please make sure roles are seeded first.');
      return;
    }
    
    // Get the Sharjah Branch
    const mainBranch = await db.collection('branches').findOne({ branch_code: "SJH" });
    
    if (!mainBranch) {
      console.error('Sharjah Branch not found. Please make sure branches are seeded first.');
      return;
    }
    
    console.log('Creating customer user...');
    
    // Generate salt and hash password
    const salt = await bcrypt.genSalt(10);
    const password_hash = await bcrypt.hash('customer123', salt);
    
    // Get default permissions for Feedback Screen role (should be all false)
    const customerPermissions = getDefaultPermissionsForRole("Feedback Screen");
    
    const now = new Date();
    
    // Create customer user
    const customerUser = {
      first_name: "John",
      last_name: "Customer",
      name: "John Customer",
      email: "customer@example.com",
      phone: "+971501111111",
      password_hash,
      is_active: true,
      staff_code: "CUST001",
      
      // Customer role info
      role_id: customerRole._id,
      role_name: customerRole.role_name,
      role_description: customerRole.description,
      
      // Branch info
      branch: {
        branch_id: mainBranch._id,
        branch_name: mainBranch.branch_name,
        branch_code: mainBranch.branch_code,
        branch_name_ar: mainBranch.branch_name_ar,
        location: mainBranch.location
      },
      
      // Permissions (all false for Customer role)
      permissions: customerPermissions,
      permission_logs: [],
      manner_evaluations: [],
      manner_evaluation_logs: [],
      
      created_at: now,
      updated_at: now
    };
    
    const result = await db.collection('users').insertOne(customerUser);
    
    if (result.insertedId) {
      console.log(`Customer user created successfully with ID: ${result.insertedId}`);
      console.log('Login credentials:');
      console.log('  Email: customer@example.com');
      console.log('  Password: customer123');
      console.log(`  Role: ${customerRole.role_name}`);
      
      // Show permissions summary
      const grantedPerms = customerPermissions.filter(p => p.granted).length;
      const totalPerms = customerPermissions.length;
      console.log(`  Permissions: ${grantedPerms}/${totalPerms} granted (read-only access)`);
    }
    
  } catch (error) {
    console.error('Error seeding customer user:', error);
    throw error;
  }
}

/**
 * Seeds the database with default roles: Admin, Supervisor, and Technician
 * @param {Object} db MongoDB database connection
 */
async function seedRoles(db) {
  try {
    console.log('Checking if roles exist...');
    
    // Check if roles already exist
    const rolesExist = await db.collection('roles').findOne({});
    
    if (rolesExist) {
      console.log('Roles already exist, skipping creation');
      return;
    }
    
    console.log('Creating default roles...');
    
    const now = new Date();
    
    // Create the five requested roles
    const roles = [
      {
        role_name: "Admin",
        description: "Full system access with all privileges",
        created_at: now,
        updated_at: now
      },
      {
        role_name: "Supervisor",
        description: "Manages technicians and oversees operations",
        created_at: now,
        updated_at: now
      },
      {
        role_name: "Technician",
        description: "Field worker with limited administrative access",
        created_at: now,
        updated_at: now
      },
      {
        role_name: "Accountant",
        description: "Financial management specialist with access to accounting, payroll, and expense systems",
        created_at: now,
        updated_at: now
      },
      {
        role_name: "Feedback Screen",
        description: "Customer role with no system permissions",
        created_at: now,
        updated_at: now
      }
    ];
    
    // Insert roles
    const result = await db.collection('roles').insertMany(roles);
    
    console.log(`${result.insertedCount} default roles created successfully`);
    
  } catch (error) {
    console.error('Error seeding roles:', error);
    throw error;
  }
}

/**
 * Seeds the database with default branches
 * @param {Object} db MongoDB database connection
 */
async function seedBranches(db) {
  try {
    console.log('Checking if branches exist...');
    
    // Check if branches already exist
    const branchesExist = await db.collection('branches').findOne({});
    
    if (branchesExist) {
      console.log('Branches already exist, skipping creation');
      return;
    }
    
    console.log('Creating Sharjah Branch...');
    
    const now = new Date();
    
    // Create only Sharjah Branch as the main branch
    const branches = [
      {
        branch_name: "Sharjah Branch",
        branch_code: "SJH",
        branch_name_ar: "فرع الشارقة",
        location: "Industrial Area 2, Sharjah, UAE",
        trn: "100123456700003",
        created_at: now,
        updated_at: now
      }
    ];
    
    // Insert branches
    const result = await db.collection('branches').insertMany(branches);
    
    console.log(`${result.insertedCount} default branches created successfully`);
    
  } catch (error) {
    console.error('Error seeding branches:', error);
    throw error;
  }
}

/**
 * Updates existing users to use roles from the roles collection
 * @param {Object} db MongoDB database connection
 */
async function updateExistingUserRoles(db) {
  try {
    console.log('Checking for users with outdated role references...');
    
    // Get all roles from the roles collection
    const roles = await db.collection('roles').find().toArray();
    
    // Create a map of role_name to role object for easy lookup
    const roleMap = {};
    roles.forEach(role => {
      roleMap[role.role_name] = role;
    });
    
    // Find all users
    const users = await db.collection('users').find().toArray();
    
    let updatedCount = 0;
    
    for (const user of users) {
      // If the user has a role_name that exists in our roles collection
      if (user.role_name && roleMap[user.role_name]) {
        const correctRole = roleMap[user.role_name];
        
        // Check if the user's role_id doesn't match the correct ID from the roles collection
        if (!user.role_id.equals(correctRole._id)) {
          // Update the user with the correct role information
          await db.collection('users').updateOne(
            { _id: user._id },
            { 
              $set: {
                role_id: correctRole._id,
                role_description: correctRole.description,
                updated_at: new Date()
              } 
            }
          );
          updatedCount++;
        }
      }
    }
    
    if (updatedCount > 0) {
      console.log(`Updated role references for ${updatedCount} existing users`);
    } else {
      console.log('No users needed role reference updates');
    }
  } catch (error) {
    console.error('Error updating user role references:', error);
  }
}

/**
 * Updates existing users to use branches from the branches collection
 * @param {Object} db MongoDB database connection
 */
async function updateExistingUserBranches(db) {
  try {
    console.log('Checking for users with outdated branch references...');
    
    // Get all branches from the branches collection
    const branches = await db.collection('branches').find().toArray();
    
    // Create a map of branch_name to branch object for easy lookup
    const branchMap = {};
    branches.forEach(branch => {
      branchMap[branch.branch_name] = branch;
    });
    
    // Default to Sharjah Branch as the main branch
    const defaultBranch = branches.find(b => b.branch_code === "SJH") || branches[0];
    
    // Find all users
    const users = await db.collection('users').find().toArray();
    
    let updatedCount = 0;
    
    for (const user of users) {
      // Skip users without branch info
      if (!user.branch) continue;
      
      // If the user has a branch_name that exists in our branches collection
      const matchingBranch = branchMap[user.branch.branch_name];
      if (matchingBranch) {
        // Check if the user's branch_id doesn't match the correct ID from the branches collection
        if (!user.branch.branch_id.equals(matchingBranch._id)) {
          // Update the user with the correct branch information
          await db.collection('users').updateOne(
            { _id: user._id },
            { 
              $set: {
                "branch.branch_id": matchingBranch._id,
                "branch.branch_code": matchingBranch.branch_code,
                "branch.branch_name_ar": matchingBranch.branch_name_ar,
                "branch.location": matchingBranch.location,
                updated_at: new Date()
              } 
            }
          );
          updatedCount++;
        }
      } else {
        // If we can't find a matching branch, set to default branch
        await db.collection('users').updateOne(
          { _id: user._id },
          { 
            $set: {
              "branch.branch_id": defaultBranch._id,
              "branch.branch_name": defaultBranch.branch_name,
              "branch.branch_code": defaultBranch.branch_code,
              "branch.branch_name_ar": defaultBranch.branch_name_ar,
              "branch.location": defaultBranch.location,
              updated_at: new Date()
            } 
          }
        );
        updatedCount++;
      }
    }
    
    if (updatedCount > 0) {
      console.log(`Updated branch references for ${updatedCount} existing users`);
    } else {
      console.log('No users needed branch reference updates');
    }
  } catch (error) {
    console.error('Error updating user branch references:', error);
  }
}

/**
 * Updates existing users to have the appropriate permissions for their roles
 * @param {Object} db MongoDB database connection
 */
async function updateExistingUserPermissions(db) {
  try {
    console.log('Checking for users without proper permissions...');
    
    // Find all users who either have empty permissions or no permissions field
    const usersWithoutPermissions = await db.collection('users').find({
      $or: [
        { permissions: { $exists: false } },
        { permissions: { $size: 0 } },
        { permissions: [] }
      ]
    }).toArray();
    
    if (usersWithoutPermissions.length === 0) {
      console.log('All users already have permissions assigned');
      return;
    }
    
    console.log(`Found ${usersWithoutPermissions.length} users without permissions. Updating...`);
    
    let updatedCount = 0;
    
    for (const user of usersWithoutPermissions) {
      if (user.role_name) {
        // Get default permissions for this user's role
        const permissions = getDefaultPermissionsForRole(user.role_name);
        
        // Update the user with the permissions
        await db.collection('users').updateOne(
          { _id: user._id },
          {
            $set: {
              permissions: permissions,
              updated_at: new Date()
            }
          }
        );
        
        updatedCount++;
        console.log(`Updated permissions for ${user.first_name} ${user.last_name} (${user.role_name})`);
      } else {
        console.log(`Skipping user ${user.email} - no role assigned`);
      }
    }
    
    console.log(`Successfully updated permissions for ${updatedCount} users`);
    
  } catch (error) {
    console.error('Error updating user permissions:', error);
    throw error;
  }
}

/**
 * Updates existing users to include manner evaluation arrays
 * @param {Object} db MongoDB database connection
 */
async function updateExistingUsersMannerEvaluations(db) {
  try {
    console.log('Checking for users without manner evaluation arrays...');
    
    // Find users that don't have the manner evaluation arrays
    const usersWithoutArrays = await db.collection('users').find({
      $or: [
        { manner_evaluations: { $exists: false } },
        { manner_evaluation_logs: { $exists: false } }
      ]
    }).toArray();
    
    if (usersWithoutArrays.length === 0) {
      console.log('All users already have manner evaluation arrays');
      return;
    }
    
    console.log(`Found ${usersWithoutArrays.length} users without manner evaluation arrays. Updating...`);
    
    // Update all users to include the arrays
    const result = await db.collection('users').updateMany(
      {
        $or: [
          { manner_evaluations: { $exists: false } },
          { manner_evaluation_logs: { $exists: false } }
        ]
      },
      {
        $set: {
          manner_evaluations: [],
          manner_evaluation_logs: [],
          updated_at: new Date()
        }
      }
    );
    
    console.log(`Successfully updated ${result.modifiedCount} users with manner evaluation arrays`);
    
    // Verify the update
    const remainingUsers = await db.collection('users').find({
      $or: [
        { manner_evaluations: { $exists: false } },
        { manner_evaluation_logs: { $exists: false } }
      ]
    }).count();
    
    if (remainingUsers === 0) {
      console.log('✅ All users now have manner evaluation arrays');
    } else {
      console.log(`⚠️  Warning: ${remainingUsers} users still missing the arrays`);
    }
    
  } catch (error) {
    console.error('Error updating users with manner evaluation arrays:', error);
    throw error;
  }
}

/**
 * Initialize payroll information for existing users
 * @param {Object} db MongoDB database connection
 */
async function initializePayrollForUsers(db) {
  try {
    console.log('Checking if users need payroll info initialization...');
    
    // Find users without payroll_info
    const usersWithoutPayroll = await db.collection('users').find({
      payroll_info: { $exists: false }
    }).toArray();
    
    if (usersWithoutPayroll.length === 0) {
      console.log('All users already have payroll info initialized');
      return;
    }
    
    console.log(`Initializing payroll info for ${usersWithoutPayroll.length} users...`);
    
    const now = new Date();
    let updatedCount = 0;
    
    for (const user of usersWithoutPayroll) {
      // Determine if user should be eligible for payroll
      // Typically, all non-admin users are eligible for payroll
      const isEligible = user.role_name !== 'Admin';
      
      // Generate unique employee ID based on staff code or email
      const employeeId = user.staff_code || `EMP${user.email.split('@')[0].toUpperCase()}`;
      
      // Determine employment type based on role
      let employmentType = 'full_time';
      if (user.role_name === 'Technician') {
        employmentType = 'full_time';
      } else if (user.role_name === 'Supervisor') {
        employmentType = 'full_time';
      } else {
        employmentType = 'contract'; // Default for others
      }
      
      // Estimate hire date (use created_at or default to 3 months ago)
      const hireDate = user.created_at || new Date(Date.now() - (90 * 24 * 60 * 60 * 1000));
      
      const payrollInfo = {
        payroll_eligible: isEligible,
        employee_number: employeeId,
        hire_date: hireDate,
        current_daily_rate: 0,
        last_pay_date: null
      };
      
      // Update user with payroll info
      await db.collection('users').updateOne(
        { _id: user._id },
        {
          $set: {
            payroll_info: payrollInfo,
            updated_at: now
          }
        }
      );
      
      updatedCount++;
      console.log(`Initialized payroll info for ${user.first_name} ${user.last_name} (${user.role_name}) - Eligible: ${isEligible}`);
    }
    
    console.log(`Successfully initialized payroll info for ${updatedCount} users`);
    
    // Create initial rates for eligible users
    console.log('Creating initial daily rates for eligible employees...');
    
    const eligibleUsers = await db.collection('users').find({
      'payroll_info.payroll_eligible': true
    }).toArray();
    
    let ratesCreated = 0;
    
    for (const user of eligibleUsers) {
      // Check if user already has a rate
      const existingRate = await db.collection('payroll_rates').findOne({
        employee_id: user._id
      });
      
      if (existingRate) {
        continue; // Skip if rate already exists
      }
      
      // Set default daily rates based on role
      let defaultRate = 150; // Default rate
      if (user.role_name === 'Supervisor') {
        defaultRate = 300;
      } else if (user.role_name === 'Technician') {
        // Different rates based on specialty
        if (user.speciality?.includes('PDR')) {
          defaultRate = 250;
        } else if (user.speciality?.includes('Paint')) {
          defaultRate = 200;
        } else {
          defaultRate = 180;
        }
      }
      
      // Create initial rate record
      const initialRate = {
        employee_id: user._id,
        daily_rate: defaultRate,
        rate_type: 'regular',
        effective_date: user.payroll_info.hire_date,
        end_date: null,
        created_by: user._id, // Use admin user ID in real implementation
        created_at: now,
        notes: 'Initial rate setup'
      };
      
      await db.collection('payroll_rates').insertOne(initialRate);
      
      // Update user's current_daily_rate
      await db.collection('users').updateOne(
        { _id: user._id },
        {
          $set: {
            'payroll_info.current_daily_rate': defaultRate,
            'payroll_info.last_pay_date': now
          }
        }
      );
      
      ratesCreated++;
      console.log(`Created initial rate of ${defaultRate} for ${user.first_name} ${user.last_name}`);
    }
    
    console.log(`Successfully created initial rates for ${ratesCreated} eligible employees`);
    
  } catch (error) {
    console.error('Error initializing payroll for users:', error);
    // Don't fail the entire seeding process
  }
}

/**
 * Seeds the database with initial workflow stages
 * @param {Object} db MongoDB database connection
 */
async function seedStages(db) {
  try {
    console.log('Checking if stages exist...');
    
    // Check if stages already exist
    const stagesCount = await db.collection('stages').countDocuments();
    
    if (stagesCount > 0) {
      console.log(`${stagesCount} stages already exist, skipping creation`);
      return;
    }
    
    console.log('Creating default workflow stages...');
    
    const now = new Date();
    
    // Default stages data
    const stages = [
      {
        name: "Remove",
        description: "Remove damaged parts and prepare for repair",
        order: 1,
        created_at: now,
        updated_at: now
      },
      {
        name: "PDR",
        description: "Paintless Dent Repair technique",
        order: 2,
        created_at: now,
        updated_at: now
      },
      {
        name: "Denter",
        description: "Traditional dent repair using tools",
        order: 3,
        created_at: now,
        updated_at: now
      },
      {
        name: "Fix",
        description: "Final fixing and adjustments",
        order: 4,
        created_at: now,
        updated_at: now
      },
      {
        name: "Polish",
        description: "Surface polishing and finishing",
        order: 5,
        created_at: now,
        updated_at: now
      },
      {
        name: "Magoon",
        description: "Apply filler to repair surface",
        order: 6,
        created_at: now,
        updated_at: now
      },
      {
        name: "Primer",
        description: "Apply primer before painting",
        order: 7,
        created_at: now,
        updated_at: now
      },
      {
        name: "Paint",
        description: "Apply paint layers",
        order: 8,
        created_at: now,
        updated_at: now
      }
    ];
    
    // Insert stages
    const result = await db.collection('stages').insertMany(stages);
    
    console.log(`Created ${result.insertedCount} default workflow stages`);
    return result.insertedIds;
  } catch (error) {
    console.error('Error seeding stages:', error);
  }
}

/**
 * Seeds the database with initial service variations
 * @param {Object} db MongoDB database connection
 */
async function seedVariations(db) {
  try {
    console.log('Checking if variations exist...');
    
    // Check if variations already exist
    const variationsCount = await db.collection('variations').countDocuments();
    
    if (variationsCount > 0) {
      console.log(`${variationsCount} variations already exist, skipping creation`);
      return;
    }
    
    // Get all stages
    const stages = await db.collection('stages').find({}).sort({ order: 1 }).toArray();
    
    if (stages.length === 0) {
      console.log('No stages found, skipping variation creation');
      return;
    }
    
    console.log('Creating default service variations...');
    
    // Log available stages for variations
    console.log('Available stages for variations:');
    stages.forEach(stage => {
      console.log(`- ${stage.name}: ${stage._id}`);
    });
    
    // Create a map for easier lookup
    const stageMap = {};
    stages.forEach(stage => {
      stageMap[stage.name] = stage._id;
    });
    
    const now = new Date();
    
    // Try each variation individually to isolate any issues
    try {
      console.log('Creating variation: P');
      await db.collection('variations').insertOne({
        code: "P",
        description: "Basic PDR Service",
        defaultLaborHours: 2.0,
        defaultStages: [
          stageMap["Remove"],
          stageMap["PDR"], 
          stageMap["Fix"], 
          stageMap["Polish"]
        ],
        created_at: now,
        updated_at: now
      });
      console.log('Successfully created variation: P');
      
      console.log('Creating variation: PS');
      await db.collection('variations').insertOne({
        code: "PS",
        description: "PDR with Paint Service",
        defaultLaborHours: 5.0,
        defaultStages: [
          stageMap["Remove"],
          stageMap["PDR"],
          stageMap["Magoon"],
          stageMap["Primer"],
          stageMap["Paint"],
          stageMap["Polish"],
          stageMap["Fix"]
        ],
        created_at: now,
        updated_at: now
      });
      console.log('Successfully created variation: PS');
      
      console.log('Creating variation: DP');
      await db.collection('variations').insertOne({
        code: "DP",
        description: "Denter with PDR",
        defaultLaborHours: 3.5,
        defaultStages: [
          stageMap["Remove"],
          stageMap["Denter"],
          stageMap["PDR"],
          stageMap["Fix"],
          stageMap["Polish"]
        ],
        created_at: now,
        updated_at: now
      });
      console.log('Successfully created variation: DP');
      
      console.log('Creating variation: PDS');
      await db.collection('variations').insertOne({
        code: "PDS",
        description: "Complete Dent Repair and Paint Service",
        defaultLaborHours: 6.5,
        defaultStages: [
          stageMap["Remove"],
          stageMap["PDR"],
          stageMap["Denter"],
          stageMap["Denter"],
          stageMap["Magoon"],
          stageMap["Primer"],
          stageMap["Paint"],
          stageMap["Polish"],
          stageMap["Fix"]
        ],
        created_at: now,
        updated_at: now
      });
      console.log('Successfully created variation: PDS');
      
      console.log('Creating variation: B');
      await db.collection('variations').insertOne({
        code: "B",
        description: "Body Work Service",
        defaultLaborHours: 5.0,
        defaultStages: [
          stageMap["Remove"],
          stageMap["Denter"],
          stageMap["Magoon"],
          stageMap["Primer"],
          stageMap["Paint"],
          stageMap["Polish"],
          stageMap["Fix"]
        ],
        created_at: now,
        updated_at: now
      });
      console.log('Successfully created variation: B');
      
      console.log('Creating variation: DS');
      await db.collection('variations').insertOne({
        code: "DS",
        description: "Direct Paint Service",
        defaultLaborHours: 4.0,
        defaultStages: [
          stageMap["Remove"],
          stageMap["Magoon"],
          stageMap["Primer"],
          stageMap["Paint"],
          stageMap["Polish"],
          stageMap["Fix"]
        ],
        created_at: now,
        updated_at: now
      });
      console.log('Successfully created variation: DS');
      
      console.log('Created 6 default service variations');
    } catch (dbError) {
      console.error('Error inserting variation:', dbError);
      if (dbError.code === 121) {
        console.log('Validation error details:', JSON.stringify(dbError.errInfo?.details?.schemaRulesNotSatisfied, null, 2));
      }
    }
  } catch (error) {
    console.error('Error seeding variations:', error);
  }
}

/**
 * Seeds the database with dummy customers
 * @param {Object} db MongoDB database connection
 */
async function seedCustomers(db) {
  try {
    console.log('Checking if customers exist...');
    
    // Check if customers already exist
    const customersExist = await db.collection('customers').findOne({});
    
    if (customersExist) {
      console.log('Customers already exist, skipping creation');
      return customersExist;
    }
    
    console.log('Creating dummy customers...');
    
    // Get branch
    const mainBranch = await db.collection('branches').findOne({ branch_code: "SJH" });
    
    if (!mainBranch) {
      console.error('Sharjah Branch not found. Please make sure branches are seeded first.');
      return;
    }
    
    const now = new Date();
    
    // Create dummy customers with vehicles
    const customers = [
      {
        first_name: "Fatima",
        last_name: "Al-Mansoori",
        email: "fatima.almansoori@example.com",
        phone: "+971504567890",
        city: "Dubai",
        country: "UAE",
        branch: {
          branch_id: mainBranch._id,
          branch_name: mainBranch.branch_name,
          branch_code: mainBranch.branch_code,
          location: mainBranch.location
        },
        vehicles: [
          {
            vehicle_id: 1,
            vin: "1HGCM82633A123456",
            make: "Nissan",
            model: "Patrol",
            year: 2022,
            license_plate: "DUBAI 54321",
            color: "White",
            vehicle_type: "SUV",
            created_at: now,
            updated_at: now
          },
          {
            vehicle_id: 2,
            vin: "5TDDK3DC4DS123789",
            make: "Toyota",
            model: "Land Cruiser",
            year: 2023,
            license_plate: "DUBAI 98765",
            color: "Black",
            vehicle_type: "SUV",
            created_at: now,
            updated_at: now
          }
        ],
        created_at: now,
        updated_at: now
      },
      {
        first_name: "Khalid",
        last_name: "Al-Zaabi",
        email: "khalid.alzaabi@example.com",
        phone: "+971505678901",
        city: "Sharjah",
        country: "UAE",
        branch: {
          branch_id: mainBranch._id,
          branch_name: mainBranch.branch_name,
          branch_code: mainBranch.branch_code,
          location: mainBranch.location
        },
        vehicles: [
          {
            vehicle_id: 1,
            vin: "JN8AZ2NC4B9123456",
            make: "BMW",
            model: "X5",
            year: 2021,
            license_plate: "SHJ 12345",
            color: "Silver",
            vehicle_type: "SUV",
            created_at: now,
            updated_at: now
          }
        ],
        created_at: now,
        updated_at: now
      },
      {
        first_name: "Amina",
        last_name: "Al-Falasi",
        email: "amina.alfalasi@example.com",
        phone: "+971506789012",
        city: "Abu Dhabi",
        country: "UAE",
        branch: {
          branch_id: mainBranch._id,
          branch_name: mainBranch.branch_name,
          branch_code: mainBranch.branch_code,
          location: mainBranch.location
        },
        vehicles: [
          {
            vehicle_id: 1,
            vin: "WBAFR7C50BC123789",
            make: "Mercedes-Benz",
            model: "C-Class",
            year: 2023,
            license_plate: "AUH 67890",
            color: "Pearl White",
            vehicle_type: "Sedan",
            created_at: now,
            updated_at: now
          },
          {
            vehicle_id: 2,
            vin: "1FTFW1ET5DFC45678",
            make: "Audi",
            model: "Q7",
            year: 2022,
            license_plate: "AUH 11111",
            color: "Metallic Blue",
            vehicle_type: "SUV",
            created_at: now,
            updated_at: now
          }
        ],
        created_at: now,
        updated_at: now
      }
    ];
    
    // Insert customers
    const result = await db.collection('customers').insertMany(customers);
    
    console.log(`Created ${result.insertedCount} dummy customers with vehicles`);
    
    // Return the inserted customers with their IDs for use in seedWorkOrders
    return {
      customers: customers.map((customer, index) => ({
        ...customer,
        _id: result.insertedIds[index]
      }))
    };
    
  } catch (error) {
    console.error('Error seeding customers:', error);
  }
}

/**
 * Seeds the database with work orders for dummy customers
 * @param {Object} db MongoDB database connection
 */
async function seedWorkOrders(db) {
  try {
    console.log('Checking if work orders exist...');
    
    // Check if work orders already exist
    const workOrdersExist = await db.collection('work_orders').findOne({});
    
    if (workOrdersExist) {
      console.log('Work orders already exist, skipping creation');
      return;
    }
    
    // Get customers
    const customers = await db.collection('customers').find().toArray();
    
    if (customers.length === 0) {
      console.error('No customers found. Please make sure customers are seeded first.');
      return;
    }
    
    // Get variations
    const variations = await db.collection('variations').find().toArray();
    
    if (variations.length === 0) {
      console.error('No variations found. Please make sure variations are seeded first.');
      return;
    }
    
    // Get technicians
    const technicians = await db.collection('users').find({
      role_name: "Technician"
    }).toArray();
    
    if (technicians.length === 0) {
      console.error('No technicians found. Please make sure technicians are seeded first.');
      return;
    }
    
    console.log('Creating work orders for customers...');
    
    const now = new Date();
    
    // Insert work orders one by one to avoid bulk insertion issues
    for (let i = 0; i < customers.length; i++) {
      const customer = customers[i];
      const vehicle = customer.vehicles[0]; // Use the first vehicle for each customer
      
      // Generate a unique work order number - simple incremental approach
      const workOrderCount = await db.collection('work_orders').countDocuments();
      const nextNumber = workOrderCount + 1;
      
      // Format the work order number with leading zeros
      const workOrderNumber = `WO-${nextNumber.toString().padStart(6, '0')}`;
      
      console.log(`Creating work order ${workOrderNumber} for customer ${customer.first_name} ${customer.last_name}`);
      
      // Select different variations for each customer
      const variation1 = variations[i % variations.length];
      const variation2 = variations[(i + 2) % variations.length];
      
      // Get stages for each variation
      const stages1 = await db.collection('stages')
        .find({ _id: { $in: variation1.defaultStages } })
        .sort({ order: 1 })
        .toArray();
        
      const stages2 = await db.collection('stages')
        .find({ _id: { $in: variation2.defaultStages } })
        .sort({ order: 1 })
        .toArray();
      
      // Assign different technicians to different parts
      const technician1 = technicians[i % technicians.length];
      const technician2 = technicians[(i + 1) % technicians.length];
      
      // Create work order with parts
      const workOrder = {
        workOrderNumber: workOrderNumber,
        work_order_number: workOrderNumber, // For the index
        customer_id: customer._id,
        vehicle_id: vehicle.vehicle_id,
        status: "open", // All work orders are "open" as requested
        description: `Repair work for ${customer.first_name} ${customer.last_name}'s ${vehicle.make} ${vehicle.model}`,
        createdAt: now,
        updatedAt: now,
        parts: [
          {
            partName: i === 0 ? "Front Bumper" : "Right Front Door",
            variationId: variation1._id,
            status: "pending",
            assignedTo: technician1._id,
            createdAt: now,
            updatedAt: now,
            stages: stages1.map(stage => ({
              stageId: stage._id,
              status: "pending",
              assignedTo: technician1._id,
              createdAt: now,
              updatedAt: now,
              logs: [],
              hasError: false,
              errorReportId: null,
              errorReportedAt: null,
              errorResolvedAt: null,
              requiresRedo: false,
              pausedAt: null,
              resumedAt: null,
              totalPausedDuration: 0
            }))
          },
          {
            partName: i === 0 ? "Hood" : "Left Rear Quarter Panel",
            variationId: variation2._id,
            status: "pending",
            assignedTo: technician2._id,
            createdAt: now,
            updatedAt: now,
            stages: stages2.map(stage => ({
              stageId: stage._id,
              status: "pending",
              assignedTo: technician2._id,
              createdAt: now,
              updatedAt: now,
              logs: [],
              hasError: false,
              errorReportId: null,
              errorReportedAt: null,
              errorResolvedAt: null,
              requiresRedo: false,
              pausedAt: null,
              resumedAt: null,
              totalPausedDuration: 0
            }))
          }
        ]
      };
      
      try {
        // Insert one work order at a time
        const result = await db.collection('work_orders').insertOne(workOrder);
        console.log(`Created work order with ID: ${result.insertedId}`);
      } catch (insertError) {
        console.error(`Error creating work order ${workOrderNumber}:`, insertError);
        // Continue with next work order even if one fails
      }
    }
    
    console.log(`Finished creating work orders for ${customers.length} customers`);
    
  } catch (error) {
    console.error('Error seeding work orders:', error);
  }
}

/**
 * Seeds the database with notifications collection
 * @param {Object} db MongoDB database connection
 */
async function seedNotifications(db) {
  try {
    console.log('Checking if notifications collection exists...');
    
    // Check if collection exists
    const collections = await db.listCollections({ name: 'notifications' }).toArray();
    
    if (collections.length > 0) {
      console.log('Notifications collection already exists, skipping creation');
      return;
    }
    
    console.log('Creating notifications collection with validation...');
    
    // Create notifications collection with schema validation
    await db.createCollection('notifications', {
      validator: {
        $jsonSchema: {
          bsonType: 'object',
          required: ['type', 'title', 'message', 'priority', 'status', 'createdAt'],
          properties: {
            type: {
              enum: ['time_alert', 'deadline_warning', 'status_change', 'assignment', 'general'],
              description: 'Type of notification'
            },
            title: {
              bsonType: 'string',
              description: 'Notification title'
            },
            message: {
              bsonType: 'string',
              description: 'Notification message content'
            },
            workOrderId: {
              bsonType: ['string', 'null'],
              description: 'Related work order ID'
            },
            stageId: {
              bsonType: ['string', 'null'],
              description: 'Related stage ID'
            },
            recipientType: {
              enum: ['supervisor', 'technician', 'owner', 'admin', 'all', null],
              description: 'Type of recipient'
            },
            recipientId: {
              bsonType: ['objectId', 'null'],
              description: 'Specific recipient user ID'
            },
            priority: {
              enum: ['low', 'medium', 'high', 'urgent'],
              description: 'Notification priority level'
            },
            status: {
              enum: ['unread', 'read', 'archived'],
              description: 'Notification status'
            },
            percentComplete: {
              bsonType: ['number', 'null'],
              minimum: 0,
              maximum: 100,
              description: 'Progress percentage for time alerts'
            },
            metadata: {
              bsonType: ['object', 'null'],
              description: 'Additional notification metadata'
            },
            createdAt: {
              bsonType: 'date',
              description: 'When the notification was created'
            },
            readAt: {
              bsonType: ['date', 'null'],
              description: 'When the notification was read'
            },
            expiresAt: {
              bsonType: ['date', 'null'],
              description: 'When the notification expires'
            }
          }
        }
      }
    });
    
    console.log('Creating indexes for notifications...');
    
    // Create indexes
    await db.collection('notifications').createIndex({ recipientType: 1, recipientId: 1, status: 1 });
    await db.collection('notifications').createIndex({ workOrderId: 1 });
    await db.collection('notifications').createIndex({ createdAt: -1 });
    await db.collection('notifications').createIndex({ status: 1, priority: 1 });
    await db.collection('notifications').createIndex({ expiresAt: 1 }, { expireAfterSeconds: 0 });
    await db.collection('notifications').createIndex({ 
      recipientType: 1, 
      status: 1, 
      type: 1, 
      priority: 1, 
      createdAt: -1 
    });
    
    console.log('Notifications collection created successfully!');
    
  } catch (error) {
    console.error('Error creating notifications collection:', error);
  }
}

/**
 * Updates work orders to include error reporting fields
 * @param {Object} db MongoDB database connection
 */
async function updateWorkOrdersValidation(db) {
  try {
    console.log('Updating work orders with error reporting fields...');
    
    // Check if work_orders collection exists
    const collections = await db.listCollections({ name: 'work_orders' }).toArray();
    
    if (collections.length === 0) {
      console.log('Work orders collection does not exist yet, skipping update');
      return;
    }
    
    // Add error reporting fields to existing stages
    console.log('Adding error reporting fields to existing work order stages...');
    
    // First, let's update all stages that don't have these fields
    const updateResult = await db.collection('work_orders').updateMany(
      {
        'parts.stages': { $exists: true }
      },
      {
        $set: {
          'parts.$[].stages.$[stage].hasError': false,
          'parts.$[].stages.$[stage].errorReportId': null,
          'parts.$[].stages.$[stage].errorReportedAt': null,
          'parts.$[].stages.$[stage].errorResolvedAt': null,
          'parts.$[].stages.$[stage].requiresRedo': false
        }
      },
      {
        arrayFilters: [
          { 
            $or: [
              { 'stage.hasError': { $exists: false } },
              { 'stage.errorReportId': { $exists: false } },
              { 'stage.requiresRedo': { $exists: false } }
            ]
          }
        ]
      }
    );
    
    console.log(`Updated ${updateResult.modifiedCount} work orders with error reporting fields`);
    
    // Also ensure pausedAt, resumedAt, and totalPausedDuration fields exist
    const pauseFieldsResult = await db.collection('work_orders').updateMany(
      {
        'parts.stages': { $exists: true }
      },
      {
        $set: {
          'parts.$[].stages.$[stage].pausedAt': null,
          'parts.$[].stages.$[stage].resumedAt': null,
          'parts.$[].stages.$[stage].totalPausedDuration': 0
        }
      },
      {
        arrayFilters: [
          { 
            $or: [
              { 'stage.pausedAt': { $exists: false } },
              { 'stage.resumedAt': { $exists: false } },
              { 'stage.totalPausedDuration': { $exists: false } }
            ]
          }
        ]
      }
    );
    
    console.log(`Updated ${pauseFieldsResult.modifiedCount} work orders with pause tracking fields`);
    
    // Create error_reports collection if it doesn't exist
    const errorReportsExists = await db.listCollections({ name: 'error_reports' }).toArray();
    
    if (errorReportsExists.length === 0) {
      console.log('Creating error_reports collection...');
      
      await db.createCollection('error_reports', {
        validator: {
          $jsonSchema: {
            bsonType: 'object',
            required: ['workOrderId', 'partIndex', 'stageIndex', 'reportingTechnicianId', 'description', 'status', 'createdAt'],
            properties: {
              workOrderId: {
                bsonType: 'objectId',
                description: 'Reference to work order'
              },
              partIndex: {
                bsonType: 'number',
                description: 'Index of the part in work order'
              },
              stageIndex: {
                bsonType: 'number',
                description: 'Index of the stage in part'
              },
              reportingTechnicianId: {
                bsonType: 'objectId',
                description: 'Technician who reported the error'
              },
              problematicTechnicianId: {
                bsonType: ['objectId', 'null'],
                description: 'Technician who caused the error'
              },
              description: {
                bsonType: 'string',
                description: 'Error description'
              },
              images: {
                bsonType: 'array',
                items: {
                  bsonType: 'string'
                },
                description: 'Array of image URLs'
              },
              status: {
                enum: ['pending', 'acknowledged', 'resolved'],
                description: 'Error report status'
              },
              severity: {
                enum: ['low', 'medium', 'high', 'critical'],
                description: 'Error severity'
              },
              acknowledgedBy: {
                bsonType: ['objectId', 'null'],
                description: 'User who acknowledged the error'
              },
              acknowledgedAt: {
                bsonType: ['date', 'null'],
                description: 'When error was acknowledged'
              },
              resolvedBy: {
                bsonType: ['objectId', 'null'],
                description: 'User who resolved the error'
              },
              resolvedAt: {
                bsonType: ['date', 'null'],
                description: 'When error was resolved'
              },
              resolution: {
                bsonType: ['string', 'null'],
                description: 'Resolution description'
              },
              createdAt: {
                bsonType: 'date',
                description: 'When error was reported'
              },
              updatedAt: {
                bsonType: 'date',
                description: 'Last update time'
              }
            }
          }
        }
      });
      
      // Create indexes for error_reports
      await db.collection('error_reports').createIndex({ workOrderId: 1, partIndex: 1, stageIndex: 1 });
      await db.collection('error_reports').createIndex({ reportingTechnicianId: 1 });
      await db.collection('error_reports').createIndex({ problematicTechnicianId: 1 });
      await db.collection('error_reports').createIndex({ status: 1 });
      await db.collection('error_reports').createIndex({ createdAt: -1 });
      
      console.log('Error reports collection created successfully!');
    }
    
    console.log('Work orders update completed successfully!');
    
  } catch (error) {
    console.error('Error updating work orders:', error);
    // Don't fail the entire seeding process
  }
}

/**
 * Seeds all payroll collections with initial data
 * @param {Object} db MongoDB database connection
 */
async function seedPayrollCollections(db) {
  try {
    console.log('Starting comprehensive payroll collection seeding...');
    
    // Seed in dependency order
    await seedPayrollDeductionTypes(db);
    await seedPayPeriods(db);
    await seedPayrollEmployeeDeductions(db);
    await seedPayrollCalculations(db);
    await seedPayStubs(db);
    await seedPayrollDeductionHistory(db);
    await seedTimesheets(db);
    
    console.log('Completed payroll collection seeding successfully!');
  } catch (error) {
    console.error('Error seeding payroll collections:', error);
    // Don't fail the entire seeding process
  }
}

/**
 * Seeds payroll deduction types
 * @param {Object} db MongoDB database connection
 */
async function seedPayrollDeductionTypes(db) {
  try {
    console.log('Checking if payroll deduction types exist...');
    
    const deductionTypesExist = await db.collection('payroll_deduction_types').findOne({});
    
    if (deductionTypesExist) {
      console.log('Payroll deduction types already exist, skipping creation');
      return;
    }
    
    console.log('Creating payroll deduction types...');
    
    const now = new Date();
    
    const deductionTypes = [
      {
        name: "UAE Pension Fund",
        description: "UAE national pension contribution",
        type: "percentage",
        default_percentage: 5,
        frequency: "monthly",
        requires_approval: false,
        is_system_type: true,
        active: true,
        created_at: now,
        updated_at: now
      },
      {
        name: "Housing Allowance Adjustment",
        description: "Housing allowance adjustment",
        type: "fixed_amount",
        default_amount: 0,
        frequency: "monthly",
        requires_approval: true,
        is_system_type: false,
        active: true,
        created_at: now,
        updated_at: now
      },
      {
        name: "Health Insurance",
        description: "Employee health insurance premium",
        type: "fixed_amount",
        default_amount: 200,
        frequency: "monthly",
        requires_approval: false,
        is_system_type: true,
        active: true,
        created_at: now,
        updated_at: now
      },
      {
        name: "Gratuity Fund",
        description: "End of service gratuity contribution",
        type: "percentage",
        default_percentage: 0,
        frequency: "monthly",
        requires_approval: false,
        is_system_type: true,
        active: true,
        created_at: now,
        updated_at: now
      },
      {
        name: "Dental Insurance",
        description: "Dental insurance premium",
        type: "fixed_amount",
        default_amount: 50,
        frequency: "monthly",
        requires_approval: false,
        is_system_type: false,
        active: true,
        created_at: now,
        updated_at: now
      },
      {
        name: "Loan Repayment",
        description: "Company loan repayment",
        type: "fixed_amount",
        default_amount: 0,
        frequency: "monthly",
        requires_approval: true,
        is_system_type: false,
        active: true,
        created_at: now,
        updated_at: now
      },
      {
        name: "Conduct Deduction",
        description: "Deduction for conduct or manners violations",
        type: "fixed_amount",
        default_amount: 0,
        frequency: "monthly",
        requires_approval: true,
        is_system_type: false,
        active: true,
        created_at: now,
        updated_at: now
      }
    ];
    
    try {
      const result = await db.collection('payroll_deduction_types').insertMany(deductionTypes);
      console.log(`Created ${result.insertedCount} payroll deduction types`);
    } catch (insertError) {
      console.error('Error inserting deduction types:', insertError);
      if (insertError.writeErrors) {
        insertError.writeErrors.forEach((err, index) => {
          console.error(`Validation error for document ${index}:`, err.err);
        });
      }
      throw insertError;
    }
    
  } catch (error) {
    console.error('Error seeding payroll deduction types:', error);
    throw error;
  }
}

/**
 * Seeds pay periods
 * @param {Object} db MongoDB database connection
 */
async function seedPayPeriods(db) {
  try {
    console.log('Checking if pay periods exist...');
    
    const payPeriodsExist = await db.collection('pay_periods').findOne({});
    
    if (payPeriodsExist) {
      console.log('Pay periods already exist, skipping creation');
      return;
    }
    
    console.log('Creating pay periods...');
    
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth();
    
    // Create pay periods for the last 3 months and next month
    const payPeriods = [];
    
    // Monthly pay periods
    for (let i = -3; i <= 1; i++) {
      const periodDate = new Date(currentYear, currentMonth + i, 1);
      const year = periodDate.getFullYear();
      const month = periodDate.getMonth();
      const monthName = periodDate.toLocaleString('en-US', { month: 'long' });
      
      const startDate = new Date(year, month, 1);
      const endDate = new Date(year, month + 1, 0); // Last day of month
      const payrollDate = new Date(year, month + 1, 5); // 5th of next month
      
      const status = i < 0 ? 'processed' : i === 0 ? 'active' : 'draft';
      
      payPeriods.push({
        period_name: `${monthName} ${year}`,
        start_date: startDate,
        end_date: endDate,
        pay_date: payrollDate,
        frequency: "monthly",
        year: year,
        period_number: month + 1, // Period number within year (1-12 for monthly)
        status: status === 'processed' ? 'closed' : status === 'active' ? 'open' : 'draft',
        cutoff_date: new Date(endDate.getTime() + (24 * 60 * 60 * 1000)), // End date + 1 day
        total_employees: 0,
        total_hours: 0,
        total_gross_pay: 0,
        total_deductions: 0,
        total_net_pay: 0,
        notes: `Monthly payroll period for ${monthName} ${year}`,
        created_at: now,
        updated_at: now,
        created_by: new ObjectId(),
        ...(status === 'processed' ? {
          processed_at: new Date(year, month + 1, 1),
          processed_by: new ObjectId(),
          closed_at: new Date(year, month + 1, 1),
          closed_by: new ObjectId()
        } : {})
      });
    }
    
    try {
      const result = await db.collection('pay_periods').insertMany(payPeriods);
      console.log(`Created ${result.insertedCount} pay periods`);
    } catch (insertError) {
      console.error('Error inserting pay periods:', insertError);
      if (insertError.writeErrors) {
        insertError.writeErrors.forEach((err, index) => {
          console.error(`Validation error for pay period ${index}:`, err.err);
          console.error('Document that failed:', JSON.stringify(payPeriods[index], null, 2));
        });
      }
      throw insertError;
    }
    
  } catch (error) {
    console.error('Error seeding pay periods:', error);
    throw error;
  }
}

/**
 * Seeds payroll employee deductions
 * @param {Object} db MongoDB database connection
 */
async function seedPayrollEmployeeDeductions(db) {
  try {
    console.log('Checking if employee deductions exist...');
    
    const employeeDeductionsExist = await db.collection('payroll_employee_deductions').findOne({});
    
    if (employeeDeductionsExist) {
      console.log('Employee deductions already exist, skipping creation');
      return;
    }
    
    console.log('Creating employee deductions...');
    
    // Get all payroll eligible employees
    const employees = await db.collection('users').find({
      'payroll_info.payroll_eligible': true
    }).toArray();
    
    if (employees.length === 0) {
      console.log('No payroll eligible employees found, skipping employee deductions');
      return;
    }
    
    // Get all deduction types
    const deductionTypes = await db.collection('payroll_deduction_types').find({}).toArray();
    
    if (deductionTypes.length === 0) {
      console.log('No deduction types found, skipping employee deductions');
      return;
    }
    
    const now = new Date();
    const employeeDeductions = [];
    
    // Assign deductions to each employee
    for (const employee of employees) {
      // In UAE, health insurance is typically employer-provided but shown as a benefit
      // All employees get health insurance
      const healthInsurance = deductionTypes.find(dt => dt.name === 'Health Insurance');
      if (healthInsurance) {
        employeeDeductions.push({
          employee_id: employee._id,
          deduction_type_id: healthInsurance._id,
          amount: 0, // Fully covered by employer in this example
          frequency: "monthly",
          start_date: employee.payroll_info.hire_date || now,
          end_date: null,
          status: "active",
          notes: `Company-provided health insurance for ${employee.first_name} ${employee.last_name}`,
          created_at: now,
          updated_at: now,
          created_by: new ObjectId()
        });
      }
      
      // Some employees get additional deductions
      if (employee.role_name === 'Supervisor' || Math.random() > 0.5) {
        // Dental insurance (optional benefit)
        const dentalInsurance = deductionTypes.find(dt => dt.name === 'Dental Insurance');
        if (dentalInsurance && Math.random() > 0.3) {
          employeeDeductions.push({
            employee_id: employee._id,
            deduction_type_id: dentalInsurance._id,
            amount: dentalInsurance.default_amount || dentalInsurance.default_percentage || 0,
            frequency: "monthly",
            start_date: employee.payroll_info.hire_date || now,
            end_date: null,
            status: "active",
            notes: `Dental insurance for ${employee.first_name} ${employee.last_name}`,
            created_at: now,
            updated_at: now,
            created_by: new ObjectId()
          });
        }
        
        // UAE Pension for UAE nationals (simulated randomly here)
        const uaePension = deductionTypes.find(dt => dt.name === 'UAE Pension Fund');
        if (uaePension && Math.random() > 0.7) { // Simulate some employees being UAE nationals
          employeeDeductions.push({
            employee_id: employee._id,
            deduction_type_id: uaePension._id,
            amount: uaePension.default_amount || uaePension.default_percentage || 0,
            frequency: "monthly",
            start_date: employee.payroll_info.hire_date || now,
            end_date: null,
            status: "active",
            notes: `UAE pension contribution for ${employee.first_name} ${employee.last_name}`,
            created_at: now,
            updated_at: now,
            created_by: new ObjectId()
          });
        }
        
        // Personal loan repayment for some employees
        const loanRepayment = deductionTypes.find(dt => dt.name === 'Loan Repayment');
        if (loanRepayment && Math.random() > 0.8) { // Some employees have loans
          employeeDeductions.push({
            employee_id: employee._id,
            deduction_type_id: loanRepayment._id,
            amount: Math.floor(Math.random() * 500) + 100, // Random loan amount 100-600 AED
            frequency: "monthly",
            start_date: employee.payroll_info.hire_date || now,
            end_date: null,
            status: "active",
            notes: `Company loan repayment for ${employee.first_name} ${employee.last_name}`,
            created_at: now,
            updated_at: now,
            created_by: new ObjectId()
          });
        }
      }
    }
    
    if (employeeDeductions.length > 0) {
      const result = await db.collection('payroll_employee_deductions').insertMany(employeeDeductions);
      console.log(`Created ${result.insertedCount} employee deductions`);
    }
    
  } catch (error) {
    console.error('Error seeding employee deductions:', error);
    throw error;
  }
}

/**
 * Seeds payroll calculations
 * @param {Object} db MongoDB database connection
 */
async function seedPayrollCalculations(db) {
  try {
    console.log('Checking if payroll calculations exist...');
    
    const calculationsExist = await db.collection('payroll_calculations').findOne({});
    
    if (calculationsExist) {
      console.log('Payroll calculations already exist, skipping creation');
      return;
    }
    
    console.log('Creating payroll calculations...');
    
    // Get closed pay periods 
    const processedPeriods = await db.collection('pay_periods').find({
      status: 'closed'
    }).sort({ start_date: 1 }).toArray();
    
    if (processedPeriods.length === 0) {
      console.log('No processed pay periods found, skipping calculations');
      return;
    }
    
    // Get all payroll eligible employees with rates
    const employees = await db.collection('users').find({
      'payroll_info.payroll_eligible': true,
      'payroll_info.current_daily_rate': { $gt: 0 }
    }).toArray();
    
    if (employees.length === 0) {
      console.log('No payroll eligible employees with rates found');
      return;
    }
    
    // Get employee deductions
    const employeeDeductions = await db.collection('payroll_employee_deductions')
      .find({ status: 'active' })
      .toArray();
    
    // Get deduction types
    const deductionTypes = await db.collection('payroll_deduction_types').find({}).toArray();
    const deductionTypeMap = {};
    deductionTypes.forEach(dt => {
      deductionTypeMap[dt._id.toString()] = dt;
    });
    
    const now = new Date();
    const calculations = [];
    
    // Create calculations for each employee for each processed period
    for (const period of processedPeriods) {
      // Calculate working days in the period (excluding weekends)
      const workingDays = calculateWorkingDays(period.start_date, period.end_date);
      
      for (const employee of employees) {
        const dailyRate = employee.payroll_info.current_daily_rate || 0;
        const basicPay = dailyRate * workingDays;
        
        // Calculate deductions for this employee
        const empDeductions = employeeDeductions.filter(
          ed => ed.employee_id.toString() === employee._id.toString()
        );
        
        let totalDeductions = 0;
        const deductions = [];
        
        for (const empDed of empDeductions) {
          const deductionType = deductionTypeMap[empDed.deduction_type_id.toString()];
          if (!deductionType) continue;
          
          let amount = 0;
          if (deductionType.type === 'percentage') {
            amount = (basicPay * empDed.amount) / 100;
          } else if (deductionType.type === 'fixed_amount') {
            amount = empDed.amount;
          } else {
            amount = empDed.amount; // conditional type - use amount as-is
          }
          
          totalDeductions += amount;
          // Map deduction type to calculation method enum
          let calculationMethod = 'fixed';
          if (deductionType.type === 'percentage') {
            calculationMethod = 'percentage';
          } else if (deductionType.type === 'fixed_amount') {
            calculationMethod = 'fixed';
          }
          
          const deduction = {
            deduction_type_id: empDed.deduction_type_id,
            deduction_name: deductionType.name,
            amount: amount,
            calculation_method: calculationMethod,
            notes: empDed.notes || ''
          };
          
          // Only add percentage field if it's a percentage-based deduction
          if (deductionType.type === 'percentage') {
            deduction.percentage = empDed.amount;
          }
          
          deductions.push(deduction);
        }
        
        // Add some overtime for technicians randomly
        let overtimeHours = 0;
        let overtimePay = 0;
        if (employee.role_name === 'Technician' && Math.random() > 0.6) {
          overtimeHours = Math.floor(Math.random() * 20) + 5; // 5-25 hours
          overtimePay = (dailyRate / 8) * 1.5 * overtimeHours; // 1.5x hourly rate
        }
        
        const totalEarnings = basicPay + overtimePay;
        const netPay = totalEarnings - totalDeductions;
        
        const hourlyRate = dailyRate / 8; // Calculate hourly rate
        
        // Create taxes object as per validation schema
        const taxes = {
          federal_tax: 0,
          state_tax: 0,
          social_security: 0,
          medicare: 0,
          other_taxes: 0
        };
        
        calculations.push({
          employee_id: employee._id,
          pay_period_id: period._id,
          gross_pay: totalEarnings,
          regular_hours: workingDays * 8,
          overtime_hours: overtimeHours,
          total_hours: (workingDays * 8) + overtimeHours,
          regular_pay: basicPay,
          overtime_pay: overtimePay,
          daily_rate: dailyRate, // Add missing daily_rate field
          hourly_rate: hourlyRate, // Add missing hourly_rate field
          days_worked: parseInt(workingDays), // Add missing days_worked field as integer
          deductions: deductions,
          total_deductions: totalDeductions,
          net_pay: netPay,
          taxes: taxes, // Add missing taxes object
          status: 'paid', // Mark as paid for closed periods
          calculation_date: new Date(period.end_date.getTime() + (24 * 60 * 60 * 1000)), // Day after period end
          paid_at: new Date(period.end_date.getTime() + (5 * 24 * 60 * 60 * 1000)), // 5 days after period end
          pay_method: 'bank_transfer',
          created_at: new Date(period.end_date.getTime() + (24 * 60 * 60 * 1000)),
          updated_at: now,
          created_by: new ObjectId()
        });
      }
    }
    
    if (calculations.length > 0) {
      try {
        const result = await db.collection('payroll_calculations').insertMany(calculations);
        console.log(`Created ${result.insertedCount} payroll calculations`);
      } catch (insertError) {
        console.error('\n=== Error inserting payroll calculations ===');
        console.error('Error type:', insertError.name);
        console.error('Error code:', insertError.code);
        
        if (insertError.writeErrors && insertError.writeErrors.length > 0) {
          insertError.writeErrors.forEach((err, index) => {
            console.error(`\n--- Validation error for calculation ${index} ---`);
            
            if (err.err.errInfo && err.err.errInfo.details) {
              const details = err.err.errInfo.details;
              if (details.schemaRulesNotSatisfied) {
                console.error('Schema validation failures:');
                details.schemaRulesNotSatisfied.forEach(rule => {
                  if (rule.propertiesNotSatisfied) {
                    rule.propertiesNotSatisfied.forEach(prop => {
                      console.error(`  Field: ${prop.propertyName}`);
                      console.error(`  Issue: ${JSON.stringify(prop.details || prop)}`);
                    });
                  }
                });
              }
            }
            
            console.error('\nDocument that failed:', JSON.stringify(calculations[index], null, 2));
          });
        }
        throw insertError;
      }
    }
    
  } catch (error) {
    console.error('Error seeding payroll calculations:', error);
    throw error;
  }
}

/**
 * Calculate working days between two dates (excluding weekends)
 */
function calculateWorkingDays(startDate, endDate) {
  let count = 0;
  const current = new Date(startDate);
  
  while (current <= endDate) {
    const dayOfWeek = current.getDay();
    if (dayOfWeek !== 0 && dayOfWeek !== 6) { // Not Sunday or Saturday
      count++;
    }
    current.setDate(current.getDate() + 1);
  }
  
  return count;
}

/**
 * Seeds pay stubs
 * @param {Object} db MongoDB database connection
 */
async function seedPayStubs(db) {
  try {
    console.log('Checking if pay stubs exist...');
    
    const payStubsExist = await db.collection('pay_stubs').findOne({});
    
    if (payStubsExist) {
      console.log('Pay stubs already exist, skipping creation');
      return;
    }
    
    console.log('Creating pay stubs...');
    
    // Get all paid calculations
    const calculations = await db.collection('payroll_calculations').find({
      status: 'paid'
    }).toArray();
    
    if (calculations.length === 0) {
      console.log('No paid calculations found, skipping pay stubs');
      return;
    }
    
    // Get pay periods map
    const payPeriods = await db.collection('pay_periods').find({}).toArray();
    const payPeriodMap = {};
    payPeriods.forEach(pp => {
      payPeriodMap[pp._id.toString()] = pp;
    });
    
    // Get employees map
    const employees = await db.collection('users').find({}).toArray();
    const employeeMap = {};
    employees.forEach(emp => {
      employeeMap[emp._id.toString()] = emp;
    });
    
    const now = new Date();
    const payStubs = [];
    
    for (const calc of calculations) {
      const employee = employeeMap[calc.employee_id.toString()];
      const payPeriod = payPeriodMap[calc.pay_period_id.toString()];
      
      if (!employee || !payPeriod) continue;
      
      const stubNumber = `STUB-${payPeriod.start_date.getFullYear()}${(payPeriod.start_date.getMonth() + 1).toString().padStart(2, '0')}-${employee.staff_code || employee._id.toString().slice(-6)}`;
      
      payStubs.push({
        stub_number: stubNumber,
        employee_id: calc.employee_id,
        payroll_calculation_id: calc._id,
        pay_period_id: calc.pay_period_id,
        issue_date: calc.calculation_date || now,
        status: "issued",
        generated_at: calc.paid_at || calc.calculation_date,
        delivery_status: "sent",
        delivery_method: "email",
        sent_at: calc.paid_at || calc.calculation_date,
        sent_to: employee.email,
        viewed_at: new Date((calc.paid_at || calc.calculation_date).getTime() + (24 * 60 * 60 * 1000)), // Next day
        pdf_url: `/paystubs/${stubNumber}.pdf`,
        notes: `Pay stub for ${payPeriod.period_name}`,
        created_at: calc.paid_at || calc.calculation_date,
        updated_at: now
      });
    }
    
    if (payStubs.length > 0) {
      const result = await db.collection('pay_stubs').insertMany(payStubs);
      console.log(`Created ${result.insertedCount} pay stubs`);
    }
    
  } catch (error) {
    console.error('Error seeding pay stubs:', error);
    throw error;
  }
}

/**
 * Seeds payroll deduction history
 * @param {Object} db MongoDB database connection
 */
async function seedPayrollDeductionHistory(db) {
  try {
    console.log('Checking if payroll deduction history exists...');
    
    const historyExist = await db.collection('payroll_deduction_history').findOne({});
    
    if (historyExist) {
      console.log('Payroll deduction history already exists, skipping creation');
      return;
    }
    
    console.log('Creating payroll deduction history...');
    
    // Get all paid calculations with deductions
    const calculations = await db.collection('payroll_calculations').find({
      status: 'paid',
      'deductions.0': { $exists: true }
    }).toArray();
    
    if (calculations.length === 0) {
      console.log('No calculations with deductions found, skipping history');
      return;
    }
    
    const deductionHistory = [];
    
    // Get pay periods for reference
    const payPeriods = await db.collection('pay_periods').find({}).toArray();
    const payPeriodMap = {};
    payPeriods.forEach(pp => {
      payPeriodMap[pp._id.toString()] = pp;
    });
    
    // Get employee deductions map
    const empDeductions = await db.collection('payroll_employee_deductions').find({}).toArray();
    const empDeductionMap = {};
    empDeductions.forEach(ed => {
      const key = `${ed.employee_id.toString()}_${ed.deduction_type_id.toString()}`;
      empDeductionMap[key] = ed;
    });
    
    for (const calc of calculations) {
      if (!calc.deductions || calc.deductions.length === 0) continue;
      
      const payPeriod = payPeriodMap[calc.pay_period_id.toString()];
      if (!payPeriod) continue;
      
      for (const deduction of calc.deductions) {
        // Find the corresponding employee deduction
        const key = `${calc.employee_id.toString()}_${deduction.deduction_type_id.toString()}`;
        const empDeduction = empDeductionMap[key];
        
        if (!empDeduction) continue;
        
        const historyEntry = {
          employee_deduction_id: empDeduction._id,
          employee_id: calc.employee_id,
          pay_period_start: payPeriod.start_date,
          pay_period_end: payPeriod.end_date,
          gross_pay_amount: calc.gross_pay,
          amount_deducted: deduction.amount,
          processed_at: calc.paid_at || calc.calculation_date,
          ...(calc.created_by && { processed_by: calc.created_by })
        };
        
        deductionHistory.push(historyEntry);
      }
    }
    
    if (deductionHistory.length > 0) {
      const result = await db.collection('payroll_deduction_history').insertMany(deductionHistory);
      console.log(`Created ${result.insertedCount} deduction history records`);
    }
    
  } catch (error) {
    console.error('Error seeding payroll deduction history:', error);
    
    // Log validation errors in detail
    if (error.writeErrors && error.writeErrors.length > 0) {
      error.writeErrors.forEach((writeError, index) => {
        console.error(`\n--- Validation error for deduction history ${index} ---`);
        
        if (writeError.err.errInfo && writeError.err.errInfo.details) {
          const details = writeError.err.errInfo.details;
          if (details.schemaRulesNotSatisfied) {
            console.error('Schema validation failures:');
            details.schemaRulesNotSatisfied.forEach(rule => {
              if (rule.propertiesNotSatisfied) {
                rule.propertiesNotSatisfied.forEach(prop => {
                  console.error(`  Field: ${prop.propertyName}`);
                  console.error(`  Issue: ${JSON.stringify(prop.details || prop)}`);
                });
              }
            });
          }
        }
        
        // Document details not shown due to scope issue
      });
    }
    throw error;
  }
}

/**
 * Seeds timesheet data with comprehensive test scenarios
 * @param {Object} db MongoDB database connection
 */
async function seedTimesheets(db) {
  try {
    console.log('Checking if timesheets exist...');
    
    const timesheetsExist = await db.collection('timesheets').findOne({});
    
    if (timesheetsExist) {
      console.log('Timesheets already exist, skipping creation');
      return;
    }
    
    console.log('Creating comprehensive timesheet test data...');
    
    // Get eligible employees (those with payroll_info.payroll_eligible = true)
    const employees = await db.collection('users').find({
      'payroll_info.payroll_eligible': true
    }).toArray();
    
    if (employees.length === 0) {
      console.log('No eligible employees found for timesheet creation');
      return;
    }
    
    // Get some work orders for association
    const workOrders = await db.collection('work_orders').find({}).limit(3).toArray();
    
    // Get payroll rates for employees
    const payrollRates = await db.collection('payroll_rates').find({}).toArray();
    const rateMap = {};
    payrollRates.forEach(rate => {
      rateMap[rate.employee_id.toString()] = rate.daily_rate;
    });
    
    const timesheets = [];
    const now = new Date();
    
    // Generate timesheets for the past 30 days
    for (let dayOffset = 30; dayOffset >= 0; dayOffset--) {
      const workDate = new Date(now);
      workDate.setDate(workDate.getDate() - dayOffset);
      
      // Skip weekends for most employees (simulate regular work schedule)
      const dayOfWeek = workDate.getDay();
      if (dayOfWeek === 0 || dayOfWeek === 6) {
        // Only create weekend timesheets for 20% of employees randomly
        if (Math.random() > 0.2) continue;
      }
      
      // Randomly select 60-90% of employees to have timesheets each day
      const participationRate = 0.6 + Math.random() * 0.3;
      const shuffledEmployees = [...employees].sort(() => Math.random() - 0.5);
      const activeEmployees = shuffledEmployees.slice(0, Math.floor(employees.length * participationRate));
      
      for (const employee of activeEmployees) {
        const dailyRate = rateMap[employee._id.toString()] || 200;
        const hourlyRate = dailyRate / 8; // Assume 8-hour standard day
        
        // Create different timesheet scenarios
        const scenario = Math.random();
        let timesheet;
        
        if (scenario < 0.4) {
          // Scenario 1: Regular 8-hour day (40%)
          timesheet = createRegularTimesheet(employee, workDate, dailyRate, hourlyRate, workOrders);
        } else if (scenario < 0.6) {
          // Scenario 2: Overtime day (20%)
          timesheet = createOvertimeTimesheet(employee, workDate, dailyRate, hourlyRate, workOrders);
        } else if (scenario < 0.8) {
          // Scenario 3: Partial day (20%)
          timesheet = createPartialTimesheet(employee, workDate, dailyRate, hourlyRate, workOrders);
        } else {
          // Scenario 4: Manual hours entry (20%)
          timesheet = createManualTimesheet(employee, workDate, dailyRate, hourlyRate, workOrders);
        }
        
        // Set timesheet status based on how recent it is
        if (dayOffset <= 3) {
          // Last 3 days: mix of draft and submitted
          timesheet.status = Math.random() > 0.5 ? 'draft' : 'submitted';
        } else if (dayOffset <= 7) {
          // Last week: mostly submitted, some approved
          timesheet.status = Math.random() > 0.3 ? 'approved' : 'submitted';
        } else {
          // Older: mostly approved
          timesheet.status = Math.random() > 0.1 ? 'approved' : 'submitted';
        }
        
        // Add approval details for approved timesheets
        if (timesheet.status === 'approved') {
          const supervisors = await db.collection('users').find({ role_name: 'Supervisor' }).limit(1).toArray();
          if (supervisors.length > 0) {
            timesheet.approved_by = supervisors[0]._id;
            timesheet.approved_at = new Date(workDate.getTime() + (24 * 60 * 60 * 1000)); // Next day
          }
        }
        
        // Add audit fields
        timesheet.created_at = new Date(workDate.getTime() + (18 * 60 * 60 * 1000)); // 6 PM same day
        timesheet.updated_at = timesheet.created_at;
        
        timesheets.push(timesheet);
      }
    }
    
    // Insert all timesheets
    if (timesheets.length > 0) {
      try {
        const result = await db.collection('timesheets').insertMany(timesheets);
        console.log(`Created ${result.insertedCount} timesheet records`);
        
        // Log status distribution
        const statusCounts = {};
        timesheets.forEach(ts => {
          statusCounts[ts.status] = (statusCounts[ts.status] || 0) + 1;
        });
        console.log('Timesheet status distribution:', statusCounts);
      } catch (insertError) {
        console.error('\n=== Error inserting timesheets ===');
        console.error('Error type:', insertError.name);
        console.error('Error code:', insertError.code);
        
        if (insertError.writeErrors && insertError.writeErrors.length > 0) {
          insertError.writeErrors.forEach((writeError, index) => {
            console.error(`\n--- Validation error for timesheet ${index} ---`);
            
            if (writeError.err.errInfo && writeError.err.errInfo.details) {
              const details = writeError.err.errInfo.details;
              if (details.schemaRulesNotSatisfied) {
                console.error('Schema validation failures:');
                details.schemaRulesNotSatisfied.forEach(rule => {
                  if (rule.propertiesNotSatisfied) {
                    rule.propertiesNotSatisfied.forEach(prop => {
                      console.error(`  Field: ${prop.propertyName}`);
                      console.error(`  Issue: ${JSON.stringify(prop.details || prop)}`);
                    });
                  }
                });
              }
            }
            
            console.error('\nDocument that failed:', JSON.stringify(timesheets[insertError.result.insertedCount], null, 2));
          });
        }
        throw insertError;
      }
    }
    
  } catch (error) {
    console.error('Error seeding timesheets:', error);
    throw error;
  }
}

/**
 * Create a regular 8-hour timesheet
 */
function createRegularTimesheet(employee, workDate, dailyRate, hourlyRate, workOrders) {
  const timeIn = new Date(workDate);
  timeIn.setHours(8, 0, 0, 0); // 8:00 AM
  
  const timeOut = new Date(workDate);
  timeOut.setHours(17, 0, 0, 0); // 5:00 PM
  
  const breakDuration = 60; // 1 hour lunch break
  const totalHours = 8;
  const regularHours = 8;
  const overtimeHours = 0;
  
  return {
    employee_id: employee._id,
    work_date: workDate,
    time_in: timeIn,
    time_out: timeOut,
    break_duration: breakDuration,
    total_hours: totalHours,
    regular_hours: regularHours,
    overtime_hours: overtimeHours,
    daily_rate: dailyRate,
    total_pay: regularHours * hourlyRate,
    work_order_ids: workOrders.length > 0 && Math.random() > 0.5 ? [workOrders[Math.floor(Math.random() * workOrders.length)]._id] : [],
    notes: 'Regular 8-hour workday',
    status: 'draft'
  };
}

/**
 * Create an overtime timesheet (10+ hours)
 */
function createOvertimeTimesheet(employee, workDate, dailyRate, hourlyRate, workOrders) {
  const timeIn = new Date(workDate);
  timeIn.setHours(7, 30, 0, 0); // 7:30 AM
  
  const timeOut = new Date(workDate);
  timeOut.setHours(19, 0, 0, 0); // 7:00 PM
  
  const breakDuration = 90; // 1.5 hour total breaks
  const totalHours = 10;
  const regularHours = 8;
  const overtimeHours = 2;
  
  return {
    employee_id: employee._id,
    work_date: workDate,
    time_in: timeIn,
    time_out: timeOut,
    break_duration: breakDuration,
    total_hours: totalHours,
    regular_hours: regularHours,
    overtime_hours: overtimeHours,
    daily_rate: dailyRate,
    total_pay: (regularHours * hourlyRate) + (overtimeHours * hourlyRate * 1.5),
    work_order_ids: workOrders.length > 0 ? [workOrders[Math.floor(Math.random() * workOrders.length)]._id] : [],
    notes: 'Overtime work - project deadline',
    status: 'draft'
  };
}

/**
 * Create a partial day timesheet (4-6 hours)
 */
function createPartialTimesheet(employee, workDate, dailyRate, hourlyRate, workOrders) {
  const hours = 4 + Math.random() * 2; // 4-6 hours
  const roundedHours = Math.round(hours * 2) / 2; // Round to nearest 0.5
  
  const timeIn = new Date(workDate);
  timeIn.setHours(8, 0, 0, 0); // 8:00 AM
  
  const timeOut = new Date(workDate);
  timeOut.setHours(8 + roundedHours, 0, 0, 0);
  
  const breakDuration = roundedHours > 5 ? 30 : 0; // Short break if over 5 hours
  
  return {
    employee_id: employee._id,
    work_date: workDate,
    time_in: timeIn,
    time_out: timeOut,
    break_duration: breakDuration,
    total_hours: roundedHours,
    regular_hours: roundedHours,
    overtime_hours: 0,
    daily_rate: dailyRate,
    total_pay: roundedHours * hourlyRate,
    work_order_ids: workOrders.length > 0 && Math.random() > 0.7 ? [workOrders[Math.floor(Math.random() * workOrders.length)]._id] : [],
    notes: roundedHours < 5 ? 'Half day - personal appointment' : 'Partial day work',
    status: 'draft'
  };
}

/**
 * Create a manual hours timesheet (no time in/out)
 */
function createManualTimesheet(employee, workDate, dailyRate, hourlyRate, workOrders) {
  const totalHours = 7.5 + Math.random() * 2; // 7.5-9.5 hours
  const roundedHours = Math.round(totalHours * 2) / 2; // Round to nearest 0.5
  
  const regularHours = Math.min(roundedHours, 8);
  const overtimeHours = Math.max(0, roundedHours - 8);
  
  // Only include fields that have valid values - omit time_in, time_out, break_duration
  return {
    employee_id: employee._id,
    work_date: workDate,
    total_hours: roundedHours,
    regular_hours: regularHours,
    overtime_hours: overtimeHours,
    daily_rate: dailyRate,
    total_pay: (regularHours * hourlyRate) + (overtimeHours * hourlyRate * 1.5),
    work_order_ids: workOrders.length > 0 && Math.random() > 0.6 ? [workOrders[Math.floor(Math.random() * workOrders.length)]._id] : [],
    notes: 'Manual hours entry - field work',
    status: 'draft'
  };
}

/**
 * Seeds the database with initial payroll audit log entries that match the new validation schema
 * @param {Object} db MongoDB database connection
 */
async function seedPayrollAuditLogs(db) {
  try {
    console.log('Checking if payroll audit logs collection needs seeding...');
    
    // Check if payroll audit logs already exist
    const auditLogsExist = await db.collection('payroll_audit_logs').findOne({});
    
    if (auditLogsExist) {
      console.log('Payroll audit logs already exist, skipping creation');
      return;
    }

    // Get a user to use for sample audit entries
    const adminUser = await db.collection('users').findOne({ role_name: "Admin" });
    
    if (!adminUser) {
      console.log('No admin user found, skipping audit log seeding');
      return;
    }

    console.log('Creating sample payroll audit log entries...');
    
    const now = new Date();
    const pastDate = new Date(Date.now() - (24 * 60 * 60 * 1000)); // 1 day ago
    
    // Create sample audit log entries that conform to the new schema
    const auditLogs = [
      {
        user_id: adminUser._id,
        user_email: adminUser.email,
        action: "login",
        entity_type: "payroll_system",
        entity_id: null,
        timestamp: pastDate,
        ip_address: "192.168.1.100",
        user_agent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
        details: {
          old_values: null,
          new_values: null,
          request_method: "POST",
          endpoint: "/api/auth/login",
          error_message: null,
          success: true
        },
        session_id: "sess_" + Date.now(),
        severity: "low",
        category: "authentication"
      },
      {
        user_id: adminUser._id,
        user_email: adminUser.email,
        action: "view_payroll",
        entity_type: "payroll_system",
        entity_id: null,
        timestamp: now,
        ip_address: "192.168.1.100",
        user_agent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
        details: {
          old_values: null,
          new_values: null,
          request_method: "GET",
          endpoint: "/api/payroll/dashboard",
          error_message: null,
          success: true
        },
        session_id: "sess_" + Date.now(),
        severity: "low",
        category: "data_access"
      }
    ];

    // Get a technician for rate-related audit logs
    const techUser = await db.collection('users').findOne({ role_name: "Technician" });
    
    if (techUser) {
      auditLogs.push({
        user_id: adminUser._id,
        user_email: adminUser.email,
        action: "create_rate",
        entity_type: "payroll_rate",
        entity_id: techUser._id.toString(),
        timestamp: pastDate,
        ip_address: "192.168.1.100",
        user_agent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
        details: {
          old_values: null,
          new_values: {
            employee_id: techUser._id,
            daily_rate: 200,
            rate_type: "regular"
          },
          request_method: "POST",
          endpoint: "/api/payroll/rates",
          error_message: null,
          success: true
        },
        session_id: "sess_" + Date.now(),
        severity: "medium",
        category: "data_modification"
      });
    }

    // Insert audit log entries
    const result = await db.collection('payroll_audit_logs').insertMany(auditLogs);
    
    console.log(`Created ${result.insertedCount} sample payroll audit log entries`);
    
  } catch (error) {
    console.error('Error seeding payroll audit logs:', error);
    // Don't fail the entire seeding process
  }
}

/**
 * Seeds the database with sample Work Order QA records
 * @param {Object} db MongoDB database connection
 */
async function seedWorkOrderQA(db) {
  try {
    console.log('Seeding Work Order QA data...');
    
    // Check if WorkOrderQA collection already has data
    const existingQACount = await db.collection('workordersqa').countDocuments();
    
    if (existingQACount > 0) {
      console.log(`WorkOrderQA collection already has ${existingQACount} records, skipping seeding`);
      return;
    }
    
    // Get some work orders to reference
    const workOrders = await db.collection('work_orders').find({}).limit(5).toArray();
    
    if (workOrders.length === 0) {
      console.log('No work orders found, skipping WorkOrderQA seeding');
      return;
    }
    
    // Get admin user for creating QA records
    const adminUser = await db.collection('users').findOne({ 
      email: process.env.ADMIN_EMAIL 
    });
    
    // Sample QA records
    const qaRecords = [];
    
    // Create sample QA records for each work order
    workOrders.forEach((workOrder, index) => {
      const qaRecord = {
        WO_ID: workOrder.work_order_number || workOrder._id.toString(),
        person_name: index % 2 === 0 ? 'John Smith' : 'Jane Doe',
        passed: index % 3 !== 0, // 2 out of 3 pass
        images: [
          {
            s3_key: `qa-images/sample-${index}-1.jpg`,
            original_name: `qa_image_${index}_1.jpg`,
            size: 1024000 + (index * 100000),
            mime_type: 'image/jpeg',
            upload_date: new Date()
          },
          {
            s3_key: `qa-images/sample-${index}-2.jpg`,
            original_name: `qa_image_${index}_2.jpg`,
            size: 1200000 + (index * 120000),
            mime_type: 'image/jpeg',
            upload_date: new Date()
          },
          {
            s3_key: `qa-images/sample-${index}-3.jpg`,
            original_name: `qa_image_${index}_3.jpg`,
            size: 950000 + (index * 90000),
            mime_type: 'image/jpeg',
            upload_date: new Date()
          }
        ],
        description: index % 3 === 0 
          ? 'Work quality did not meet standards. Issues found with finishing and alignment.'
          : 'Work completed to high standards. All measurements within tolerance.',
        created_at: new Date(),
        updated_at: new Date()
      };
      
      qaRecords.push(qaRecord);
    });
    
    // Insert QA records
    const result = await db.collection('workordersqa').insertMany(qaRecords);
    
    console.log(`Created ${result.insertedCount} sample Work Order QA records`);
    
  } catch (error) {
    console.error('Error seeding Work Order QA data:', error);
    // Don't fail the entire seeding process
  }
}

module.exports = { seedDatabase };