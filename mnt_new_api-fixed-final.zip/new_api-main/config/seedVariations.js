/**
 * Seeds the database with initial service variations
 * @param {Object} db MongoDB database connection
 */
async function seedVariations(db) {
  try {
    console.log('Checking if variations exist...');
    
    // Check if variations already exist
    const variationsCount = await db.collection('variations').countDocuments();
    
    if (variationsCount > 0) {
      console.log(`${variationsCount} variations already exist, skipping creation`);
      return;
    }
    
    // Get all stages
    const stages = await db.collection('stages').find({}).sort({ order: 1 }).toArray();
    
    if (stages.length === 0) {
      console.log('No stages found, skipping variation creation');
      return;
    }
    
    console.log('Creating default service variations...');
    
    // Log available stages for debugging
    console.log('Available stages for variations:');
    stages.forEach(stage => {
      console.log(`- ${stage.name}: ${stage._id}`);
    });
    
    // Create a map for easier lookup
    const stageMap = {};
    stages.forEach(stage => {
      stageMap[stage.name] = stage._id;
    });
    
    const now = new Date();
    
    // Try each variation individually to isolate any issues
    try {
      console.log('Creating variation: P');
      await db.collection('variations').insertOne({
        code: "P",
        description: "Basic PDR Service",
        defaultLaborHours: 2.0,
        defaultStages: [
          stageMap["Remove"],
          stageMap["PDR"], 
          stageMap["Fix"], 
          stageMap["Polish"]
        ],
        created_at: now,
        updated_at: now
      });
      console.log('Successfully created variation: P');
      
      console.log('Creating variation: PS');
      await db.collection('variations').insertOne({
        code: "PS",
        description: "PDR with Paint Service",
        defaultLaborHours: 5.0,
        defaultStages: [
          stageMap["Remove"],
          stageMap["PDR"],
          stageMap["Magoon"],
          stageMap["Primer"],
          stageMap["Paint"],
          stageMap["Polish"],
          stageMap["Fix"]
        ],
        created_at: now,
        updated_at: now
      });
      console.log('Successfully created variation: PS');
      
      console.log('Creating variation: DP');
      await db.collection('variations').insertOne({
        code: "DP",
        description: "Denter with PDR",
        defaultLaborHours: 3.5,
        defaultStages: [
          stageMap["Remove"],
          stageMap["Denter"],
          stageMap["PDR"],
          stageMap["Fix"],
          stageMap["Polish"]
        ],
        created_at: now,
        updated_at: now
      });
      console.log('Successfully created variation: DP');
      
      console.log('Creating variation: PDS');
      await db.collection('variations').insertOne({
        code: "PDS",
        description: "Complete Dent Repair and Paint Service",
        defaultLaborHours: 6.5,
        defaultStages: [
          stageMap["Remove"],
          stageMap["PDR"],
          stageMap["Denter"],
          stageMap["Denter"],
          stageMap["Magoon"],
          stageMap["Primer"],
          stageMap["Paint"],
          stageMap["Polish"],
          stageMap["Fix"]
        ],
        created_at: now,
        updated_at: now
      });
      console.log('Successfully created variation: PDS');
      
      console.log('Creating variation: B');
      await db.collection('variations').insertOne({
        code: "B",
        description: "Body Work Service",
        defaultLaborHours: 5.0,
        defaultStages: [
          stageMap["Remove"],
          stageMap["Denter"],
          stageMap["Magoon"],
          stageMap["Primer"],
          stageMap["Paint"],
          stageMap["Polish"],
          stageMap["Fix"]
        ],
        created_at: now,
        updated_at: now
      });
      console.log('Successfully created variation: B');
      
      console.log('Creating variation: DS');
      await db.collection('variations').insertOne({
        code: "DS",
        description: "Direct Paint Service",
        defaultLaborHours: 4.0,
        defaultStages: [
          stageMap["Remove"],
          stageMap["Magoon"],
          stageMap["Primer"],
          stageMap["Paint"],
          stageMap["Polish"],
          stageMap["Fix"]
        ],
        created_at: now,
        updated_at: now
      });
      console.log('Successfully created variation: DS');
      
      console.log('Created 6 default service variations');
    } catch (dbError) {
      console.error('Error inserting variation:', dbError);
      if (dbError.code === 121) {
        console.log('Validation error details:', JSON.stringify(dbError.errInfo?.details?.schemaRulesNotSatisfied, null, 2));
      }
    }
  } catch (error) {
    console.error('Error seeding variations:', error);
  }
}
