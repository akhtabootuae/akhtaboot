const { MongoClient } = require('mongodb');
const User = require('./models/User');
const PayrollAuditLog = require('./models/PayrollAuditLog');

const MONGODB_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/GMS_DB';

async function updateSchemas() {
  const client = new MongoClient(MONGODB_URI);
  
  try {
    await client.connect();
    const db = client.db();
    
    console.log('Connected to MongoDB');
    
    // First, remove validation to update documents
    console.log('Temporarily removing users collection validation...');
    try {
      await db.command({
        collMod: 'users',
        validator: {}
      });
      console.log('✓ Validation temporarily removed');
    } catch (error) {
      console.error('Error removing validation:', error.message);
    }
    
    // Update PayrollAuditLog collection schema
    console.log('Updating payroll_audit_log collection schema...');
    try {
      // First, create the collection if it doesn't exist
      const collections = await db.listCollections({ name: 'payroll_audit_log' }).toArray();
      if (collections.length === 0) {
        await db.createCollection('payroll_audit_log', PayrollAuditLog.getSchema());
        console.log('✓ payroll_audit_log collection created with schema');
      } else {
        await db.command({
          collMod: 'payroll_audit_log',
          validator: PayrollAuditLog.getSchema().validator
        });
        console.log('✓ payroll_audit_log collection schema updated successfully');
      }
    } catch (error) {
      console.error('Error updating payroll_audit_log schema:', error.message);
    }
    
    // Update existing user documents to have the new payroll_info structure
    console.log('Updating existing user documents...');
    const users = await db.collection('users').find({}).toArray();
    
    for (const user of users) {
      const updateData = {};
      
      // Migrate old payroll_info structure to new one
      if (user.payroll_info) {
        const newPayrollInfo = {
          payroll_eligible: user.payroll_info.payroll_eligible || user.payroll_info.eligible || false,
          employee_number: user.payroll_info.employee_number || user.payroll_info.employee_id || '',
          hire_date: user.payroll_info.hire_date || null,
          current_daily_rate: user.payroll_info.current_daily_rate || 0,
          last_pay_date: user.payroll_info.last_pay_date || null,
          employment_type: user.payroll_info.employment_type || undefined,
          last_rate_update: user.payroll_info.last_rate_update || null,
          updated_by: user.payroll_info.updated_by || undefined
        };
        
        // Remove undefined values
        Object.keys(newPayrollInfo).forEach(key => {
          if (newPayrollInfo[key] === undefined) {
            delete newPayrollInfo[key];
          }
        });
        
        updateData.payroll_info = newPayrollInfo;
      } else {
        // If no payroll_info exists, create a default one
        updateData.payroll_info = {
          payroll_eligible: false,
          employee_number: '',
          hire_date: null,
          current_daily_rate: 0,
          last_pay_date: null
        };
      }
      
      await db.collection('users').updateOne(
        { _id: user._id },
        { $set: updateData }
      );
    }
    
    console.log(`✓ Updated ${users.length} user documents`);
    
    // Now re-apply the validation
    console.log('Re-applying users collection validation...');
    try {
      await db.command({
        collMod: 'users',
        validator: User.getSchema().validator
      });
      console.log('✓ Users collection schema updated successfully');
    } catch (error) {
      console.error('Error updating users schema:', error.message);
    }
    
    console.log('\nSchema update complete!');
    
  } catch (error) {
    console.error('Error:', error);
  } finally {
    await client.close();
  }
}

// Run the update
updateSchemas().catch(console.error);