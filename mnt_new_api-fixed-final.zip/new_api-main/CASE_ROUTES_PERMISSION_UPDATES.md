# Case Routes Permission Updates - Summary

## Overview
This document summarizes the changes made to the case routes (`/routes/caseRoutes.js`) to ensure correct role naming and permission usage according to the established permissions system.

## Changes Made

### 1. Role Name Corrections
**Before:** Using lowercase role names
- `user.role === 'admin'`
- `user.role === 'supervisor'`

**After:** Using proper case role names (matching database)
- `user.role === 'Admin'`
- `user.role === 'Supervisor'`

### 2. Permission Name Corrections
**Before:** Using dot notation permissions
- `cases.read`
- `cases.stats`
- `cases.delete`
- `cases.resolve`

**After:** Using underscore notation permissions (matching permissions.js)
- `view_case` / `view_all_cases`
- `view_case_stats`
- `delete_case`
- `resolve_case`

### 3. Custom Permission Middleware Updates
Updated the `checkCasePermissions` middleware to:
- Use a permission mapping system to translate actions to correct permission names
- Use proper case role names ('Admin', 'Supervisor')
- Maintain backward compatibility with existing functionality

### 4. Route-Level Permission Updates

#### POST /api/cases (Create Case)
- Added: `permissionAuth(['create_case'])`
- Ensures users have the `create_case` permission before creating cases

#### GET /api/cases (List Cases)
- Added: `permissionAuth(['view_all_cases', 'view_case'])`
- Users need either permission to view cases list

#### GET /api/cases/stats (Case Statistics)
- Updated: `permissionAuth(['view_case_stats'])` (was `['cases.read', 'cases.stats']`)
- Now uses the correct permission name

#### GET /api/cases/:id (View Specific Case)
- Uses: `checkCasePermissions('read')` (updated to map to `view_case`)

#### PUT /api/cases/:id (Update Case)
- Uses: `checkCasePermissions('update')` (updated to map to `update_case`)
- Status change validation uses proper role names and `resolve_case` permission

#### POST /api/cases/:id/notes (Add Notes)
- Added: `permissionAuth(['add_case_notes', 'update_case'])`
- Users need either permission to add notes

#### POST /api/cases/:id/attachments (Upload Attachments)
- Added: `permissionAuth(['manage_case_attachments', 'update_case'])`
- Users need either permission to upload attachments

#### DELETE /api/cases/:id (Delete Case)
- Updated: `permissionAuth(['delete_case'])` (was `['cases.delete']`)
- Now uses the correct permission name

## Permission Mapping

The updated `checkCasePermissions` middleware now uses this mapping:

```javascript
const permissionMap = {
  'read': 'view_case',
  'update': 'update_case',
  'resolve': 'resolve_case',
  'close': 'close_case'
};
```

## Role Hierarchy

The routes now correctly recognize the role hierarchy as defined in the database:
- **Admin**: Full access to all case operations
- **Supervisor**: Can view, create, update, resolve, and close cases
- **Technician**: Limited access based on assigned permissions

## Backward Compatibility

The changes maintain backward compatibility by:
- Preserving the ownership/assignment logic for case access
- Maintaining the same API endpoints and request/response formats
- Keeping the custom permission checking logic for complex scenarios

## Testing

A comprehensive test script has been created (`test-updated-case-routes.js`) to verify:
- Authentication with different role types
- Case creation permissions
- Case viewing permissions
- Case statistics access
- Case resolution restrictions
- Case deletion permissions

## Files Modified

1. **`/routes/caseRoutes.js`** - Main case routes file with permission updates
2. **`test-updated-case-routes.js`** - Test script for verification (new file)

## Next Steps

1. Run the test script to verify all permissions are working correctly
2. Update any frontend applications to use the correct permission names
3. Review other route files for similar permission inconsistencies
4. Update API documentation to reflect the correct permission requirements

## Permissions Reference

### Case Management Permissions (from `/config/permissions.js`)
- `view_all_cases` - View all cases in the system
- `view_case` - View specific case details
- `create_case` - Create new case records
- `update_case` - Update case information
- `delete_case` - Remove cases from the system
- `resolve_case` - Mark cases as resolved
- `close_case` - Close cases permanently
- `assign_case` - Assign cases to users
- `add_case_notes` - Add notes to cases
- `manage_case_attachments` - Upload and manage case attachments
- `view_case_stats` - View case statistics and reports
