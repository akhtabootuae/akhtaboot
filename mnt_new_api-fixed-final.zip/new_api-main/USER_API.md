# User API Documentation

This document provides detailed information about the User Management API endpoints.

## Authentication

Most endpoints require JWT authentication. Include the JWT token in the Authorization header:

```
Authorization: Bearer YOUR_JWT_TOKEN
```

## User Model

The User model contains the following fields:

```javascript
{
  "first_name": "String",   // Required
  "last_name": "String",    // Required
  "email": "String",        // Required, unique
  "phone": "String",
  "password_hash": "String", // Required (system-generated)
  "is_active": Boolean,     // Default: true
  "staff_code": "String",
  "speciality": "String",
  
  // Branch information
  "branch": {
    "branch_id": ObjectId,
    "branch_name": "String",
    "branch_code": "String",
    "location": "String"
  },
  
  // Role information
  "role": {
    "role_id": Number,      // 1 = Admin, etc.
    "role_name": "String",
    "description": "String"
  },
  
  // User permissions
  "permissions": [
    {
      "permission_id": Number,
      "permission_name": "String",
      "category": "String",
      "granted": Boolean
    }
  ],
  
  // Permission audit logs
  "permission_logs": [
    {
      "log_id": Number,
      "target_type": "user"|"role",
      "target_id": ObjectId,
      "permission_id": Number,
      "action": "grant"|"revoke",
      "created_at": Date,
      "details": "String"
    }
  ],
  
  "created_at": Date,
  "updated_at": Date
}
```

## Authentication Endpoints

### Register User
- **URL**: `/api/users/register`
- **Method**: POST
- **Access**: Public
- **Description**: Register a new user
- **Request Body**:
```json
{
  "first_name": "John",
  "last_name": "Doe",
  "email": "john.doe@example.com",
  "phone": "123-456-7890",
  "password": "securepassword123",
  "staff_code": "EMP001",
  "speciality": "Sales"
}
```
- **Response**: Returns user object with JWT token

### Login
- **URL**: `/api/users/login`
- **Method**: POST
- **Access**: Public
- **Description**: Authenticate user & get token
- **Request Body**:
```json
{
  "email": "john.doe@example.com",
  "password": "securepassword123"
}
```
- **Response**: Returns JWT token and user information

## User Management Endpoints

### Get All Users
- **URL**: `/api/users`
- **Method**: GET
- **Access**: Admin or users with view_all_users permission
- **Description**: Retrieve a list of all users
- **Query Parameters**:
  - None

### Get User by ID
- **URL**: `/api/users/:id`
- **Method**: GET
- **Access**: Admin, Self, or users with view_users permission
- **Description**: Retrieve a specific user by ID
- **Path Parameters**:
  - `id`: User ID (ObjectId)

### Create User
- **URL**: `/api/users`
- **Method**: POST
- **Access**: Admin or users with create_user permission
- **Description**: Create a new user
- **Request Body**:
```json
{
  "first_name": "Jane",
  "last_name": "Smith",
  "email": "jane.smith@example.com",
  "phone": "987-654-3210",
  "password": "securepassword456",
  "staff_code": "EMP002",
  "speciality": "Support",
  "branch": {
    "branch_id": "60d21b4667d0d8992e610c85",
    "branch_name": "Downtown Branch"
  },
  "role": {
    "role_id": 2,
    "role_name": "Manager"
  }
}
```

### Update User
- **URL**: `/api/users/:id`
- **Method**: PUT
- **Access**: Admin, Self, or users with update_user permission
- **Description**: Update a user's information
- **Path Parameters**:
  - `id`: User ID (ObjectId)
- **Request Body**:
```json
{
  "first_name": "Jane",
  "last_name": "Updated",
  "phone": "987-654-3210",
  "speciality": "Technical Support"
}
```

### Delete User
- **URL**: `/api/users/:id`
- **Method**: DELETE
- **Access**: Admin or users with delete_user permission
- **Description**: Delete a user
- **Path Parameters**:
  - `id`: User ID (ObjectId)

### Activate/Deactivate User
- **URL**: `/api/users/:id/activate`
- **Method**: PUT
- **Access**: Admin or users with manage_user_status permission
- **Description**: Activate or deactivate a user account
- **Path Parameters**:
  - `id`: User ID (ObjectId)
- **Request Body**:
```json
{
  "is_active": true
}
```

### Update User Permissions
- **URL**: `/api/users/:id/permissions`
- **Method**: PUT
- **Access**: Admin or users with manage_permissions permission
- **Description**: Update user permissions
- **Path Parameters**:
  - `id`: User ID (ObjectId)
- **Request Body**:
```json
{
  "permissions": [
    {
      "permission_id": 1,
      "permission_name": "view_all_users",
      "granted": true
    },
    {
      "permission_id": 2,
      "permission_name": "create_user",
      "granted": false
    }
  ]
}
```

### Update User Role
- **URL**: `/api/users/:id/role`
- **Method**: PUT
- **Access**: Admin or users with manage_roles permission
- **Description**: Update a user's role
- **Path Parameters**:
  - `id`: User ID (ObjectId)
- **Request Body**:
```json
{
  "role": {
    "role_id": 3,
    "role_name": "Staff"
  }
}
```

### Get User Permission Logs
- **URL**: `/api/users/:id/permission-logs`
- **Method**: GET
- **Access**: Admin or users with view_permission_logs permission
- **Description**: Get permission change logs for a user
- **Path Parameters**:
  - `id`: User ID (ObjectId)

### Export Users
- **URL**: `/api/users/export`
- **Method**: GET
- **Access**: Admin or users with export_users permission
- **Description**: Export users data as CSV
- **Response**: CSV file with user data

### Update User Branch
- **URL**: `/api/users/:id/branch`
- **Method**: PUT
- **Access**: Admin or users with manage_user_branches permission
- **Description**: Update a user's branch assignment
- **Path Parameters**:
  - `id`: User ID (ObjectId)
- **Request Body**:
```json
{
  "branch": {
    "branch_id": "60d21b4667d0d8992e610c85",
    "branch_name": "North Branch",
    "branch_code": "NB"
  }
}
```
- **Note**: You only need to provide one of `branch_id`, `branch_name`, or `branch_code` to identify the branch. The system will look up the complete branch information.

### Assign Multiple Users to Branch
- **URL**: `/api/branches/:id/assign-users`
- **Method**: POST
- **Access**: Admin only
- **Description**: Assign multiple users to a specific branch at once
- **Path Parameters**:
  - `id`: Branch ID (ObjectId)
- **Request Body**:
```json
{
  "userIds": ["60d21b4667d0d8992e610c86", "60d21b4667d0d8992e610c87"]
}
```
- **Response**: 
```json
{
  "message": "Users assigned to branch successfully",
  "matchedCount": 2,
  "modifiedCount": 2,
  "branch": {
    "branch_id": "60d21b4667d0d8992e610c85",
    "branch_name": "North Branch",
    "branch_code": "NB",
    "location": "456 North Avenue, North District"
  }
}
```

## User Role Management

### Assign Role to User

```
PUT /api/users/:userId/role
```

**Description**: Assign a role to a user.

**Authorization**: Requires valid JWT token and Admin privileges.

**Parameters**:
- `userId`: The MongoDB ObjectId of the user

**Request Body**:

```json
{
  "roleId": "60d21b4667d0d8992e610c85"
}
```

**Response**:

```json
{
  "message": "User role updated successfully"
}
```

### Get Users by Role

```
GET /api/users/role/:roleId
```

**Description**: Get all users with a specific role.

**Authorization**: Requires valid JWT token and 'view_users_by_role' permission.

**Parameters**:
- `roleId`: The MongoDB ObjectId of the role

**Response**:

```json
[
  {
    "_id": "60d21b4667d0d8992e610c90",
    "first_name": "John",
    "last_name": "Doe",
    "email": "john.doe@example.com",
    "role_id": "60d21b4667d0d8992e610c85",
    "role_name": "Admin",
    "role_description": "Full system access with all privileges",
    // other user fields...
  },
  // more users with the same role...
]
```

## Error Responses

All API endpoints follow a standard error response format:

```json
{
  "message": "Error message",
  "error": "Detailed error information"
}
```

Common HTTP status codes:

- **200**: Success
- **201**: Created
- **400**: Bad Request (missing required fields, validation errors)
- **401**: Unauthorized (missing or invalid token)
- **403**: Forbidden (insufficient permissions)
- **404**: Not Found (resource not found)
- **500**: Server Error (unexpected errors)

Additional error responses for User Role Management:

```json
{
  "message": "User not found"
}
```

```json
{
  "message": "Role not found"
}
```

```json
{
  "message": "Role ID is required"
}
```
