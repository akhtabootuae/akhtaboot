# Employee Management Endpoints Documentation

This document outlines the employee management endpoints available in the payroll system, providing functionality for retrieving employee statistics, counts, and detailed listings.

## Overview

All endpoints in this documentation are prefixed with `/api/payroll/employees/` and require appropriate permissions:
- `payroll_view_employees` - View employee information
- `payroll_manage_deductions` - Manage employee deductions (also grants view access)

## Endpoints

### 1. GET /api/payroll/employees/count

Retrieves count statistics for employees with detailed breakdowns.

#### Authentication & Permissions
- **Required**: Bearer token
- **Permissions**: `payroll_view_employees` OR `payroll_manage_deductions`

#### Query Parameters
| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `active_only` | string | `'true'` | Filter to active employees only (`'true'`/`'false'`) |
| `branch_id` | string | - | Filter by specific branch ID |
| `role_name` | string | - | Filter by specific role name |
| `payroll_eligible_only` | string | `'false'` | Filter to payroll eligible employees only |
| `include_terminated` | string | `'false'` | Include terminated employees in count |

#### Response Format
```json
{
  "message": "Employee count retrieved successfully",
  "total_employees": 45,
  "breakdown": {
    "by_role": [
      {
        "_id": "Technician",
        "count": 25
      },
      {
        "_id": "Supervisor", 
        "count": 15
      }
    ],
    "by_payroll_eligibility": [
      {
        "eligible": "Yes",
        "count": 35
      },
      {
        "eligible": "No", 
        "count": 10
      }
    ],
    "by_branch": [
      {
        "branch_id": "60f1b2e4c8d4e12345678901",
        "branch_name": "Downtown Branch",
        "count": 20
      }
    ]
  },
  "filters_applied": {
    "active_only": true,
    "branch_id": null,
    "role_name": null,
    "payroll_eligible_only": false,
    "include_terminated": false
  }
}
```

### 2. GET /api/payroll/employees/summary

Provides comprehensive statistical summary of employees including percentages.

#### Authentication & Permissions  
- **Required**: Bearer token
- **Permissions**: `payroll_view_employees` OR `payroll_manage_deductions`

#### Query Parameters
| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `branch_id` | string | - | Filter by specific branch ID |

#### Response Format
```json
{
  "message": "Employee summary retrieved successfully", 
  "summary": {
    "total_employees": 45,
    "active_employees": 40,
    "inactive_employees": 5,
    "payroll_eligible": 35,
    "payroll_ineligible": 10,
    "with_deductions": 15,
    "percentages": {
      "active": 89,
      "payroll_eligible": 78,
      "with_deductions": 33
    }
  },
  "filters_applied": {
    "branch_id": null
  }
}
```

### 3. GET /api/payroll/employees/list

Retrieves paginated list of employees with detailed information and optional daily rate data.

#### Authentication & Permissions
- **Required**: Bearer token  
- **Permissions**: `payroll_view_employees` OR `payroll_manage_deductions`

#### Query Parameters
| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `page` | number | `1` | Page number for pagination |
| `limit` | number | `50` | Number of records per page |
| `active_only` | string | `'true'` | Filter to active employees only |
| `branch_id` | string | - | Filter by specific branch ID |
| `role_name` | string | - | Filter by specific role name |
| `payroll_eligible_only` | string | `'false'` | Filter to payroll eligible employees only |
| `include_rates` | string | `'false'` | **NEW**: Include daily rate information from payroll_rates collection |
| `search` | string | - | Search in name, email, staff_code, or employee_id |

#### Response Format (without rates)
```json
{
  "message": "Employee list retrieved successfully",
  "employees": [
    {
      "_id": "60f1b2e4c8d4e12345678901",
      "employee_id": "EMP001",
      "first_name": "John",
      "last_name": "Doe", 
      "full_name": "John Doe",
      "email": "john.doe@company.com",
      "phone": "+1234567890",
      "staff_code": "ST001",
      "speciality": "PDR",
      "role_name": "Technician",
      "is_active": true,
      "branch": {
        "branch_id": "60f1b2e4c8d4e12345678902",
        "branch_name": "Downtown Branch",
        "branch_code": "DT001"
      },
      "payroll_info": {
        "eligible": true,
        "employee_id": "EMP001", 
        "hire_date": "2023-01-15T00:00:00.000Z",
        "employment_type": "full_time"
      },
      "created_at": "2023-01-10T08:30:00.000Z",
      "updated_at": "2023-12-01T10:15:00.000Z"
    }
  ],
  "pagination": {
    "current_page": 1,
    "total_pages": 3,
    "total_records": 45,
    "limit": 50,
    "has_next": true,
    "has_prev": false
  },
  "filters_applied": {
    "active_only": true,
    "branch_id": null,
    "role_name": null, 
    "payroll_eligible_only": false,
    "include_rates": false,
    "search": null,
    "excludes_admin": true
  }
}
```

#### Response Format (with rates when include_rates=true)
When `include_rates=true`, each employee object includes an additional `daily_rate` field:

```json
{
  "message": "Employee list retrieved successfully",
  "employees": [
    {
      "_id": "60f1b2e4c8d4e12345678901",
      "employee_id": "EMP001",
      "first_name": "John",
      "last_name": "Doe",
      "full_name": "John Doe", 
      "email": "john.doe@company.com",
      "phone": "+1234567890",
      "staff_code": "ST001",
      "speciality": "PDR",
      "role_name": "Technician",
      "is_active": true,
      "branch": {
        "branch_id": "60f1b2e4c8d4e12345678902",
        "branch_name": "Downtown Branch",
        "branch_code": "DT001"
      },
      "payroll_info": {
        "eligible": true,
        "employee_id": "EMP001",
        "hire_date": "2023-01-15T00:00:00.000Z", 
        "employment_type": "full_time"
      },
      "daily_rate": {
        "rate_id": "60f1b2e4c8d4e12345678903",
        "daily_rate": 250.00,
        "rate_type": "regular",
        "effective_date": "2023-01-15T00:00:00.000Z",
        "end_date": null,
        "created_at": "2023-01-15T09:00:00.000Z",
        "notes": "Initial rate setup"
      },
      "created_at": "2023-01-10T08:30:00.000Z",
      "updated_at": "2023-12-01T10:15:00.000Z"
    }
  ],
  "pagination": {
    "current_page": 1,
    "total_pages": 3,
    "total_records": 45,
    "limit": 50,
    "has_next": true,
    "has_prev": false
  },
  "filters_applied": {
    "active_only": true,
    "branch_id": null,
    "role_name": null,
    "payroll_eligible_only": false,
    "include_rates": true,
    "search": null,
    "excludes_admin": true
  }
}
```

## Key Features

### Admin User Exclusion
All endpoints automatically exclude users with `role_name: 'Admin'` from results.

### Search Functionality (List Endpoint)
The search parameter supports partial matching across:
- `first_name`
- `last_name`  
- `email`
- `staff_code`
- `payroll_info.employee_id`

### Rate Information Integration
When `include_rates=true` is specified in the list endpoint:
- Fetches current active daily rates from the `payroll_rates` collection
- Uses efficient aggregation pipeline for batch processing
- Only includes rates that are currently effective (within date range)
- Returns `null` for `daily_rate` field if no current rate exists

### Pagination
The list endpoint supports robust pagination with:
- Configurable page size (via `limit` parameter)
- Page navigation indicators (`has_next`, `has_prev`)
- Total record counts and page calculations

### Filtering Options
Multiple filtering options are available:
- **Active Status**: Filter active/inactive employees
- **Branch**: Filter by specific branch
- **Role**: Filter by employee role
- **Payroll Eligibility**: Filter payroll-eligible employees
- **Termination Status**: Include/exclude terminated employees (count endpoint)

## Performance Considerations

### Batch Rate Retrieval
When `include_rates=true`:
- Uses MongoDB aggregation pipeline for efficient batch processing
- Retrieves all required rates in a single query
- Creates in-memory map for O(1) lookup performance
- Minimizes database round trips

### Database Indexes
Recommended indexes for optimal performance:
```javascript
// Users collection
db.users.createIndex({ "role_name": 1 })
db.users.createIndex({ "is_active": 1 })
db.users.createIndex({ "branch.branch_id": 1 })
db.users.createIndex({ "payroll_info.eligible": 1 })

// Payroll rates collection  
db.payroll_rates.createIndex({ "employee_id": 1, "effective_date": -1 })
db.payroll_rates.createIndex({ "end_date": 1 })
```

## Error Handling

All endpoints return consistent error responses:

```json
{
  "message": "Error description",
  "error": "Detailed error message"
}
```

Common HTTP status codes:
- `200` - Success
- `400` - Bad request (invalid parameters)
- `401` - Unauthorized (missing/invalid token)
- `403` - Forbidden (insufficient permissions)
- `500` - Internal server error

## Usage Examples

### Get employee count by role
```bash
GET /api/payroll/employees/count?role_name=Technician
```

### Get paginated active employees with rates
```bash
GET /api/payroll/employees/list?page=1&limit=25&active_only=true&include_rates=true
```

### Search for specific employee
```bash
GET /api/payroll/employees/list?search=john&include_rates=true
```

### Get summary for specific branch
```bash
GET /api/payroll/employees/summary?branch_id=60f1b2e4c8d4e12345678902
```

## Changelog

### Latest Update
- **NEW**: Added `include_rates` parameter to the `/list` endpoint
- When `include_rates=true`, the endpoint now fetches and includes daily rate information from the `payroll_rates` collection
- Uses efficient batch processing with MongoDB aggregation pipelines
- Provides complete rate details including rate_id, daily_rate, rate_type, effective_date, end_date, created_at, and notes
- Maintains backward compatibility - existing functionality unchanged when parameter is not provided or set to `false`

## New Endpoints

### 1. Get Employee Count

**GET** `/api/payroll/employees/count`

Get the count of employees (non-admin users) with various filtering options.

**Query Parameters:**
- `active_only` (string, default: 'true') - Filter for active employees only
- `branch_id` (string, optional) - Filter by specific branch ID
- `role_name` (string, optional) - Filter by specific role name
- `payroll_eligible_only` (string, default: 'false') - Filter for payroll-eligible employees only
- `include_terminated` (string, default: 'false') - Include terminated employees

**Required Permissions:**
- `payroll_view_employees` OR `payroll_manage_deductions`

**Response Example:**
```json
{
  "message": "Employee count retrieved successfully",
  "total_employees": 45,
  "breakdown": {
    "by_role": [
      {
        "_id": "Technician",
        "count": 25
      },
      {
        "_id": "Supervisor",
        "count": 15
      },
      {
        "_id": "Manager",
        "count": 5
      }
    ],
    "by_payroll_eligibility": [
      {
        "eligible": "Yes",
        "count": 40
      },
      {
        "eligible": "No",
        "count": 5
      }
    ],
    "by_branch": [
      {
        "branch_id": "60f7b1b9e4b0b8a1c8d4e5f6",
        "branch_name": "Main Branch",
        "count": 30
      },
      {
        "branch_id": "60f7b1b9e4b0b8a1c8d4e5f7",
        "branch_name": "North Branch",
        "count": 15
      }
    ]
  },
  "filters_applied": {
    "active_only": true,
    "branch_id": null,
    "role_name": null,
    "payroll_eligible_only": false,
    "include_terminated": false
  }
}
```

### 2. Get Employee Summary

**GET** `/api/payroll/employees/summary`

Get summary statistics about employees including counts and percentages.

**Query Parameters:**
- `branch_id` (string, optional) - Filter by specific branch ID

**Required Permissions:**
- `payroll_view_employees` OR `payroll_manage_deductions`

**Response Example:**
```json
{
  "message": "Employee summary retrieved successfully",
  "summary": {
    "total_employees": 45,
    "active_employees": 42,
    "inactive_employees": 3,
    "payroll_eligible": 40,
    "payroll_ineligible": 5,
    "with_deductions": 25,
    "percentages": {
      "active": 93,
      "payroll_eligible": 89,
      "with_deductions": 56
    }
  },
  "filters_applied": {
    "branch_id": null,
    "excludes_admin": true
  }
}
```

### 3. Get Employee List

**GET** `/api/payroll/employees/list`

Get a paginated list of employees with detailed information and filtering options.

**Query Parameters:**
- `page` (number, default: 1) - Page number for pagination
- `limit` (number, default: 50) - Number of records per page
- `active_only` (string, default: 'true') - Filter for active employees only
- `branch_id` (string, optional) - Filter by specific branch ID
- `role_name` (string, optional) - Filter by specific role name
- `payroll_eligible_only` (string, default: 'false') - Filter for payroll-eligible employees only
- `search` (string, optional) - Search across name, email, staff code, and employee ID

**Required Permissions:**
- `payroll_view_employees` OR `payroll_manage_deductions`

**Response Example:**
```json
{
  "message": "Employee list retrieved successfully",
  "employees": [
    {
      "_id": "60f7b1b9e4b0b8a1c8d4e5f8",
      "employee_id": "EMP001",
      "first_name": "John",
      "last_name": "Doe",
      "full_name": "John Doe",
      "email": "john.doe@company.com",
      "phone": "+1234567890",
      "staff_code": "TECH001",
      "speciality": "PDR",
      "role_name": "Technician",
      "is_active": true,
      "branch": {
        "branch_id": "60f7b1b9e4b0b8a1c8d4e5f6",
        "branch_name": "Main Branch",
        "branch_code": "MAIN"
      },
      "payroll_info": {
        "eligible": true,
        "employee_id": "EMP001",
        "hire_date": "2025-01-15T00:00:00.000Z",
        "employment_type": "full_time"
      },
      "created_at": "2025-01-10T10:30:00.000Z",
      "updated_at": "2025-06-01T15:45:00.000Z"
    }
  ],
  "pagination": {
    "current_page": 1,
    "total_pages": 1,
    "total_records": 45,
    "limit": 50,
    "has_next": false,
    "has_prev": false
  },
  "filters_applied": {
    "active_only": true,
    "branch_id": null,
    "role_name": null,
    "payroll_eligible_only": false,
    "search": null,
    "excludes_admin": true
  }
}
```

## Key Features

### Admin Exclusion
All endpoints automatically exclude users with `role_name: "Admin"` to focus specifically on employees.

### Security
- All endpoints require appropriate payroll permissions
- Branch breakdown is only provided to admins or users with `view_all_employees` permission
- Sensitive data (password_hash, permission_logs, permissions) is excluded from responses

### Filtering Options
- **Active Status**: Filter for active/inactive employees
- **Branch**: Filter by specific branch
- **Role**: Filter by specific role
- **Payroll Eligibility**: Filter for payroll-eligible employees
- **Search**: Text search across multiple fields
- **Terminated Employees**: Option to include/exclude terminated employees

### Pagination
The list endpoint supports pagination with:
- Configurable page size (default: 50 records)
- Total count and page calculations
- Navigation indicators (has_next, has_prev)

### Data Breakdown
The count endpoint provides detailed breakdowns by:
- Role
- Payroll eligibility
- Branch (for authorized users)

## Usage Examples

### Get total employee count
```bash
curl -X GET "http://localhost:3000/api/payroll/employees/count" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

### Get active technicians only
```bash
curl -X GET "http://localhost:3000/api/payroll/employees/count?role_name=Technician&active_only=true" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

### Get employees from specific branch
```bash
curl -X GET "http://localhost:3000/api/payroll/employees/list?branch_id=60f7b1b9e4b0b8a1c8d4e5f6&page=1&limit=25" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

### Search for employees
```bash
curl -X GET "http://localhost:3000/api/payroll/employees/list?search=john&active_only=true" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

### Get payroll-eligible employees summary
```bash
curl -X GET "http://localhost:3000/api/payroll/employees/summary?payroll_eligible_only=true" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

## Error Responses

### 403 Forbidden
```json
{
  "message": "Access denied. Insufficient permissions."
}
```

### 500 Internal Server Error
```json
{
  "message": "Failed to retrieve employee count",
  "error": "Detailed error message"
}
```

## Route Organization

These endpoints are mounted under `/api/payroll/employees/` through the payroll route structure:
- Main payroll routes: `/api/payroll/`
- Employee deduction routes: `/api/payroll/employees/`
- New count/list endpoints: `/api/payroll/employees/count`, `/api/payroll/employees/list`, `/api/payroll/employees/summary`

## Database Considerations

### Performance
- Uses MongoDB aggregation pipelines for efficient counting and grouping
- Includes proper indexing suggestions:
  - `role_name` index for admin exclusion
  - `is_active` index for active status filtering
  - `branch.branch_id` index for branch filtering
  - Compound index on `(role_name, is_active, branch.branch_id)` for common queries

### Data Integrity
- Handles missing fields gracefully with default values
- Excludes sensitive information from responses
- Proper ObjectId handling for MongoDB operations
