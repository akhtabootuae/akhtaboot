require('dotenv').config();
const { MongoClient, ObjectId } = require('mongodb');

async function seedTestNotifications() {
  const client = new MongoClient(process.env.MONGO_URI);
  
  try {
    await client.connect();
    const db = client.db();
    const notificationsCollection = db.collection('notifications');
    
    // Clear existing test notifications
    await notificationsCollection.deleteMany({ title: { $regex: /^Test/ } });
    
    // Create test notifications
    const testNotifications = [
      {
        type: 'time_alert',
        title: 'Test: Work Order Progress Update',
        message: 'Work order #WO-2024-001 is 75% complete. Expected completion in 2 hours.',
        workOrderId: 'WO-2024-001',
        recipientType: 'all',
        priority: 'medium',
        status: 'unread',
        percentComplete: 75,
        metadata: {
          customerName: 'John Doe',
          vehicleMake: 'Toyota',
          vehicleModel: 'Camry'
        },
        createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
        readAt: null,
        expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
      },
      {
        type: 'deadline_warning',
        title: 'Test: Urgent Deadline Approaching',
        message: 'Work order #WO-2024-002 is due in 30 minutes. Please prioritize completion.',
        workOrderId: 'WO-2024-002',
        recipientType: 'technician',
        priority: 'urgent',
        status: 'unread',
        metadata: {
          deadline: new Date(Date.now() + 30 * 60 * 1000).toISOString(),
          customerName: 'Jane Smith'
        },
        createdAt: new Date(Date.now() - 30 * 60 * 1000), // 30 minutes ago
        readAt: null,
        expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
      },
      {
        type: 'status_change',
        title: 'Test: Work Order Status Updated',
        message: 'Work order #WO-2024-003 status changed from "In Progress" to "Quality Check".',
        workOrderId: 'WO-2024-003',
        recipientType: 'all',
        priority: 'low',
        status: 'read',
        metadata: {
          previousStatus: 'In Progress',
          newStatus: 'Quality Check',
          changedBy: 'Tech Lead'
        },
        createdAt: new Date(Date.now() - 3 * 60 * 60 * 1000), // 3 hours ago
        readAt: new Date(Date.now() - 2 * 60 * 60 * 1000), // Read 2 hours ago
        expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
      },
      {
        type: 'assignment',
        title: 'Test: New Work Order Assigned',
        message: 'You have been assigned to work order #WO-2024-004 for brake pad replacement.',
        workOrderId: 'WO-2024-004',
        recipientType: 'technician',
        priority: 'high',
        status: 'unread',
        metadata: {
          service: 'Brake Pad Replacement',
          estimatedDuration: '2 hours',
          customerName: 'Bob Johnson'
        },
        createdAt: new Date(Date.now() - 1 * 60 * 60 * 1000), // 1 hour ago
        readAt: null,
        expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
      },
      {
        type: 'general',
        title: 'Test: System Maintenance Scheduled',
        message: 'The system will undergo scheduled maintenance on Sunday from 2:00 AM to 4:00 AM.',
        recipientType: 'all',
        priority: 'medium',
        status: 'unread',
        metadata: {
          maintenanceWindow: 'Sunday 2:00 AM - 4:00 AM',
          affectedServices: ['Work Orders', 'Reporting']
        },
        createdAt: new Date(),
        readAt: null,
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
      }
    ];
    
    const result = await notificationsCollection.insertMany(testNotifications);
    console.log(`Successfully inserted ${result.insertedCount} test notifications`);
    
    // Display the inserted notifications
    const insertedNotifications = await notificationsCollection
      .find({ _id: { $in: Object.values(result.insertedIds) } })
      .toArray();
    
    console.log('\nInserted notifications:');
    insertedNotifications.forEach(notification => {
      console.log(`- ${notification.title} (${notification.type}, ${notification.priority})`);
    });
    
  } catch (error) {
    console.error('Error seeding test notifications:', error);
  } finally {
    await client.close();
  }
}

// Run the seeder
seedTestNotifications();