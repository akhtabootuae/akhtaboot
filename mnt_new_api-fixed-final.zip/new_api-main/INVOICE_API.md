# Invoice API Documentation

This document outlines the available endpoints for managing invoices in the system.

## Base URL

All endpoints are relative to `/api/invoices`.

## Authentication

All routes require authentication. Include a valid JWT token in the Authorization header.

## Endpoints

### Create Invoice
- **URL**: `/`
- **Method**: `POST`
- **Description**: Creates a new invoice
- **Request Body**:
  ```json
  {
    "customer_id": "ObjectId",
    "branch_id": "ObjectId",
    "vehicle_id": 1,
    "work_order_id": "ObjectId (optional)",
    "invoice_date": "2023-04-01",
    "expected_delivery_date": "2023-04-10 (optional)",
    "price": 1000.00,
    "vat": 5,
    "isTaxed": true,
    "ratio": 0.75,
    "notes": "Optional notes",
    "special_requests": "Optional special requests",
    "payment_records": [
      {
        "payment_date": "2023-04-01",
        "amount": 500.00,
        "payment_method": "card",
        "is_downpayment": true,
        "notes": "Downpayment"
      }
    ],
    "images": [
      {
        "url": "https://example.com/image.jpg",
        "title": "Invoice Image",
        "description": "Front page of invoice",
        "upload_date": "2023-04-01"
      }
    ]
  }
  ```
- **Success Response**:
  - **Code**: 201
  - **Content**: Created invoice object

### Get Invoice List (Formatted)
- **URL**: `/list`
- **Method**: `GET`  
- **Description**: Get a formatted list of invoices with customer and vehicle details
- **Required Permission**: `view_all_invoices`
- **Query Parameters**:
  - `customer_id` (optional): Filter by customer ID
  - `branch_id` (optional): Filter by branch ID  
  - `invoice_number` (optional): Filter by invoice number
  - `date_from` (optional): Filter invoices from this date (YYYY-MM-DD)
  - `date_to` (optional): Filter invoices up to this date (YYYY-MM-DD)
  - `work_order_id` (optional): Filter by work order ID
  - `limit` (optional): Number of results per page (default: 50)
  - `offset` (optional): Number of results to skip (default: 0)
- **Response**:
  ```json
  {
    "invoices": [
      {
        "invoice_id": "ObjectId",
        "invoice_number": "INV-0000001",
        "license_plate": "DUBAI 54321",
        "customer": "Fatima Al-Mansoori",
        "customer_id": "ObjectId",
        "car_info": "Nissan Patrol (2022)",
        "total": 1050.00,
        "price_before_vat": 1000.00,
        "vat_amount": 50.00,
        "vat_percentage": 5,
        "is_taxed": true,
        "total_paid": 500.00,
        "remaining_balance": 550.00,
        "payment_status": "PARTIAL",
        "payment_count": 1,
        "created_at": "2025-06-11T17:07:49.056Z",
        "invoice_date": "2025-06-11T17:07:49.047Z",
        "vehicle_id": 1,
        "work_order_id": null
      }
    ],
    "pagination": {
      "total": 1,
      "limit": 50,
      "offset": 0,
      "hasMore": false
    }
  }
  ```
- **Payment Status Values**:
  - `UNPAID`: No payments made
  - `PARTIAL`: Some payments made but balance remaining
  - `PAID`: Fully paid (total paid >= total amount)
- **Features**:
  - Automatic customer name formatting from first_name + last_name
  - Vehicle details lookup from customer's vehicles array
  - Automatic payment status calculation
  - Total price calculation including VAT
  - Pagination support
  - Same filtering options as the main invoices endpoint

### Get All Invoices
- **URL**: `/`
- **Method**: `GET`
- **Description**: Retrieves all invoices, with optional filters
- **Query Parameters**:
  - `customer_id` - Filter by customer ID
  - `branch_id` - Filter by branch ID
  - `invoice_number` - Filter by invoice number
  - `date_from` - Filter invoices from this date (format: YYYY-MM-DD)
  - `date_to` - Filter invoices to this date (format: YYYY-MM-DD)
  - `work_order_id` - Filter by work order ID
- **Success Response**:
  - **Code**: 200
  - **Content**: Array of invoice objects

### Get Invoice by ID
- **URL**: `/:id`
- **Method**: `GET`
- **Description**: Retrieves an invoice by its ID
- **URL Parameters**:
  - `id` - The ID of the invoice
- **Success Response**:
  - **Code**: 200
  - **Content**: Invoice object
- **Error Response**:
  - **Code**: 404
  - **Content**: `{ "message": "Invoice not found" }`

### Get Invoice by Invoice Number
- **URL**: `/number/:invoice_number`
- **Method**: `GET`
- **Description**: Retrieves an invoice by its invoice number
- **URL Parameters**:
  - `invoice_number` - The invoice number (format: INV-XXXXXXX)
- **Success Response**:
  - **Code**: 200
  - **Content**: Invoice object
- **Error Response**:
  - **Code**: 404
  - **Content**: `{ "message": "Invoice not found" }`

### Get Invoices by Customer
- **URL**: `/customer/:customerId`
- **Method**: `GET`
- **Description**: Retrieves all invoices for a specific customer
- **URL Parameters**:
  - `customerId` - The customer ID
- **Success Response**:
  - **Code**: 200
  - **Content**: Array of invoice objects

### Get Invoices by Branch
- **URL**: `/branch/:branchId`
- **Method**: `GET`
- **Description**: Retrieves all invoices for a specific branch
- **URL Parameters**:
  - `branchId` - The branch ID
- **Success Response**:
  - **Code**: 200
  - **Content**: Array of invoice objects

### Update Invoice
- **URL**: `/:id`
- **Method**: `PUT`
- **Description**: Updates an invoice by its ID
- **URL Parameters**:
  - `id` - The ID of the invoice
- **Request Body**: Any invoice fields to update
- **Success Response**:
  - **Code**: 200
  - **Content**: Updated invoice object
- **Error Response**:
  - **Code**: 404
  - **Content**: `{ "message": "Invoice not found" }`

### Delete Invoice
- **URL**: `/:id`
- **Method**: `DELETE`
- **Description**: Deletes an invoice by its ID
- **URL Parameters**:
  - `id` - The ID of the invoice
- **Success Response**:
  - **Code**: 200
  - **Content**: `{ "message": "Invoice deleted successfully" }`
- **Error Response**:
  - **Code**: 404
  - **Content**: `{ "message": "Invoice not found" }`

### Add Payment Record
- **URL**: `/:id/payments`
- **Method**: `POST`
- **Description**: Adds a payment record to an invoice
- **URL Parameters**:
  - `id` - The ID of the invoice
- **Request Body**:
  ```json
  {
    "payment_date": "2023-04-05",
    "amount": 500.00,
    "payment_method": "cash",
    "is_downpayment": false,
    "notes": "Final payment"
  }
  ```
  **Note**: The `reference` field is auto-generated and should not be included in the request body.
- **Success Response**:
  - **Code**: 200
  - **Content**: Updated invoice object
- **Error Response**:
  - **Code**: 404
  - **Content**: `{ "message": "Invoice not found" }`

### Update Payment Record
- **URL**: `/:id/payments/:index`
- **Method**: `PUT`
- **Description**: Updates a payment record in an invoice
- **URL Parameters**:
  - `id` - The ID of the invoice
  - `index` - The index of the payment record
- **Request Body**: Any payment record fields to update
- **Success Response**:
  - **Code**: 200
  - **Content**: Updated invoice object
- **Error Response**:
  - **Code**: 404
  - **Content**: `{ "message": "Invoice not found" }` or `{ "message": "Payment record not found" }`

### Remove Payment Record
- **URL**: `/:id/payments/:index`
- **Method**: `DELETE`
- **Description**: Removes a payment record from an invoice
- **URL Parameters**:
  - `id` - The ID of the invoice
  - `index` - The index of the payment record
- **Success Response**:
  - **Code**: 200
  - **Content**: Updated invoice object
- **Error Response**:
  - **Code**: 404
  - **Content**: `{ "message": "Invoice not found" }` or `{ "message": "Payment record not found" }`

### Add Image
- **URL**: `/:id/images`
- **Method**: `POST`
- **Description**: Adds an image to an invoice
- **URL Parameters**:
  - `id` - The ID of the invoice
- **Request Body**:
  ```json
  {
    "url": "https://example.com/image2.jpg",
    "title": "Receipt Image",
    "description": "Image of receipt",
    "upload_date": "2023-04-05"
  }
  ```
- **Success Response**:
  - **Code**: 200
  - **Content**: Updated invoice object
- **Error Response**:
  - **Code**: 404
  - **Content**: `{ "message": "Invoice not found" }`

### Remove Image
- **URL**: `/:id/images`
- **Method**: `DELETE`
- **Description**: Removes an image from an invoice
- **URL Parameters**:
  - `id` - The ID of the invoice
- **Request Body**:
  ```json
  {
    "imageUrl": "https://example.com/image2.jpg"
  }
  ```
- **Success Response**:
  - **Code**: 200
  - **Content**: Updated invoice object
- **Error Response**:
  - **Code**: 404
  - **Content**: `{ "message": "Invoice not found" }`

## Data Models

### Invoice

```javascript
{
  "_id": "ObjectId",
  "invoice_number": "INV-0000001", // Format: INV-XXXXXXX
  "customer_id": "ObjectId",
  "vehicle_id": 1,
  "work_order_id": "ObjectId",
  "invoice_date": "Date",
  "expected_delivery_date": "Date",
  "price": 1000.00, // Base price before VAT
  "isTaxed": true, // Whether VAT should be applied
  "price_before_vat": 1000.00, // Same as price (stored for consistency)
  "vat_amount": 50.00, // Calculated VAT amount (stored)
  "total_price": 1050.00, // Final total including VAT (stored)
  "vat": 5, // VAT percentage (0-100)
  "ratio": 0.75,
  "payment_records": [
    {
      "payment_date": "Date",
      "amount": 500.00,
      "payment_method": "card",
      "is_downpayment": true,
      "reference": "PAY-000001", // Auto-generated in format PAY-XXXXXX
      "notes": "Downpayment"
    }
  ],
  "images": [
    {
      "url": "https://example.com/image.jpg",
      "title": "Invoice Image",
      "description": "Front page of invoice",
      "upload_date": "Date"
    }
  ],
  "notes": "General notes about the invoice",
  "special_requests": "Special requests related to this invoice",
  "created_at": "Date",
  "updated_at": "Date"
}
```
