# Report Generation API Documentation

## Overview

The Report Generation API provides comprehensive functionality for generating, managing, and downloading payroll reports in multiple formats (PDF, CSV, Excel). This system integrates with the existing payroll data to create professional reports with audit trails and security controls.

## Features

- **Multiple Format Support**: Generate reports in PDF, CSV, and Excel formats
- **Direct Generation**: Generate and download reports immediately without storing
- **File Management**: Store generated files with metadata tracking
- **Audit Trails**: Complete logging of all report generation and access activities
- **Security**: Permission-based access control and user ownership validation
- **Cleanup**: Automated cleanup of old report files
- **Sharing**: Share reports with other users with permission controls

## API Endpoints

### 1. Generate Report File

**POST** `/api/payroll/reports/:id/generate-file`

Generate a report file in the specified format from an existing report.

**Parameters:**
- `id`: Report ID (path parameter)
- `format`: File format (`pdf`, `csv`, `xlsx`) - Request body

**Response:**
```json
{
  "message": "PDF file generated successfully",
  "file": {
    "filename": "payroll_summary_20250607_143022.pdf",
    "format": "pdf",
    "size": 245760,
    "download_url": "/api/payroll/reports/12345/download-file/payroll_summary_20250607_143022.pdf"
  }
}
```

### 2. Download Generated File

**GET** `/api/payroll/reports/:id/download-file/:filename`

Download a previously generated report file.

**Parameters:**
- `id`: Report ID (path parameter)
- `filename`: File name (path parameter)

**Response:** File stream with appropriate content headers

### 3. Generate Direct Report

**POST** `/api/payroll/reports/generate-direct`

Generate and immediately download a report without storing it permanently.

**Request Body:**
```json
{
  "report_type": "payroll_summary",
  "parameters": {
    "start_date": "2025-05-01",
    "end_date": "2025-05-31",
    "branch_id": "60f7b1b9e4b0b8a1c8d4e5f6"
  },
  "format": "pdf",
  "report_name": "May 2025 Payroll Summary"
}
```

**Response:** Direct file download

### 4. Cleanup Old Files

**POST** `/api/payroll/reports/cleanup`

Clean up old report files (Admin only).

**Request Body:**
```json
{
  "max_age_days": 30
}
```

**Response:**
```json
{
  "message": "Report cleanup completed. 15 files deleted.",
  "deleted_files": 15
}
```

## Report Types

### 1. Payroll Summary (`payroll_summary`)

Comprehensive overview of payroll data including:
- Total employees
- Total gross/net pay
- Total deductions
- Total hours worked
- Employee details with individual pay information

**Required Parameters:**
- `start_date`: Report start date
- `end_date`: Report end date

**Optional Parameters:**
- `branch_id`: Filter by specific branch
- `department`: Filter by department

### 2. Employee Earnings (`employee_earnings`)

Detailed earnings breakdown for employees including:
- Individual employee earnings
- Pay period summaries
- Hours worked details
- Year-to-date totals

**Required Parameters:**
- `start_date`: Report start date
- `end_date`: Report end date

**Optional Parameters:**
- `employee_ids`: Array of specific employee IDs

### 3. Deduction Summary (`deduction_summary`)

Summary of all deductions including:
- Deduction types and amounts
- Employee-specific deductions
- Statistical analysis (min, max, average)

**Required Parameters:**
- `start_date`: Report start date
- `end_date`: Report end date

### 4. Attendance Summary (`attendance_summary`)

Employee attendance and time tracking including:
- Days worked
- Total hours
- Regular vs overtime hours
- Average hours per day

**Required Parameters:**
- `start_date`: Report start date
- `end_date`: Report end date

**Optional Parameters:**
- `employee_ids`: Array of specific employee IDs

## File Formats

### PDF Format
- Professional layout with headers and footers
- Page numbering
- Company branding placeholder
- Formatted tables and summaries
- Suitable for printing and formal documentation

### CSV Format
- Comma-separated values
- Headers with descriptive column names
- Compatible with Excel and other spreadsheet applications
- Ideal for data import/export operations

### Excel Format (XLSX)
- Formatted spreadsheet with styles
- Multiple worksheets for complex data
- Number formatting for currency and percentages
- Headers with professional styling
- Suitable for advanced data analysis

## Security and Permissions

### Required Permissions
- `payroll_view_reports`: View existing reports
- `payroll_generate_reports`: Generate new reports and manage files

### Access Control
- Users can only access reports they created or reports shared with them
- File downloads require proper permissions
- Admin users have additional cleanup capabilities

### Audit Logging
All operations are logged with:
- User identification
- Action performed
- Timestamp
- IP address and user agent
- Detailed parameters and results

## File Management

### Storage Location
Generated files are stored in: `/uploads/reports/`

### File Naming Convention
Format: `{report_type}_{timestamp}.{extension}`
Example: `payroll_summary_20250607_143022.pdf`

### Cleanup Policy
- Default cleanup after 30 days
- Configurable retention period
- Admin-only cleanup operation
- Automatic cleanup on file stream completion for direct downloads

## Error Handling

### Common Error Responses

**400 Bad Request**
```json
{
  "message": "Unsupported format. Supported formats: pdf, csv, xlsx"
}
```

**403 Forbidden**
```json
{
  "message": "Access denied to this report"
}
```

**404 Not Found**
```json
{
  "message": "Report not found"
}
```

**500 Internal Server Error**
```json
{
  "message": "Failed to generate report file",
  "error": "Detailed error message"
}
```

## Usage Examples

### Generate PDF Payroll Summary
```bash
curl -X POST "http://localhost:3000/api/payroll/reports/generate-direct" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "report_type": "payroll_summary",
    "parameters": {
      "start_date": "2025-05-01",
      "end_date": "2025-05-31"
    },
    "format": "pdf",
    "report_name": "May 2025 Payroll Summary"
  }' \
  --output "payroll_summary.pdf"
```

### Generate Excel Employee Earnings Report
```bash
curl -X POST "http://localhost:3000/api/payroll/reports/generate-direct" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "report_type": "employee_earnings",
    "parameters": {
      "start_date": "2025-01-01",
      "end_date": "2025-05-31",
      "employee_ids": ["60f7b1b9e4b0b8a1c8d4e5f6"]
    },
    "format": "xlsx"
  }' \
  --output "employee_earnings.xlsx"
```

## Dependencies

The report generation system requires the following npm packages:
- `pdfkit`: PDF generation
- `csv-writer`: CSV file creation
- `excel4node`: Excel file generation
- `fs-extra`: Enhanced file system operations
- `moment`: Date formatting and manipulation

## Performance Considerations

- Large reports may take time to generate
- Direct downloads clean up temporary files automatically
- Consider implementing background job processing for very large reports
- File size limits may apply based on server configuration

## Future Enhancements

Potential improvements could include:
- Background job processing for large reports
- Email delivery of generated reports
- Custom report templates
- Data visualization charts in PDFs
- Bulk report generation
- Report scheduling and automation
