# Payment Reference Auto-Generation Implementation

## Overview
This document describes the implementation of automatic payment reference generation for invoice payment records in the API system.

## Changes Made

### 1. Auto-Generation Function
- **File**: `models/Invoice.js`
- **Function**: `generatePaymentReference(db)`
- **Format**: `PAY-XXXXXX` (6 digits with leading zeros)
- **Logic**: Scans all existing payment records across all invoices to find the highest reference number and increments it

### 2. Updated Invoice Model Methods

#### `addPaymentRecord(db, invoiceId, paymentData)`
- Now automatically generates a reference number if not provided in `paymentData`
- Maintains backward compatibility (if reference is manually provided, it will be used)

#### `updatePaymentRecord(db, invoiceId, index, updateData)`
- Automatically generates a new reference if the update data doesn't include one or if it's empty
- Prevents accidental deletion of reference numbers

#### `create(db, invoiceData)`
- Processes payment records during invoice creation to auto-generate references
- Uses async processing to ensure unique reference generation

### 3. Updated Routes

#### POST `/api/invoices/:id/payments`
- Filters out any manually provided `reference` field from request body
- Reference is auto-generated in the model layer

#### PUT `/api/invoices/:id/payments/:index`
- Filters out any manually provided `reference` field from request body
- Reference is auto-generated if needed in the model layer

#### POST `/api/invoices`
- Filters out any `reference` fields from payment records in the request body
- References are auto-generated during invoice creation

### 4. Updated Documentation

#### API Documentation (`INVOICE_API.md`)
- Updated request body examples to remove `reference` field
- Added notes explaining that references are auto-generated
- Updated data model documentation to show the new reference format

#### Postman Collection (`postman_invoices_collection.json`)
- Removed `reference` fields from all payment record examples
- Updated both invoice creation and payment addition examples

## Usage Examples

### Adding a Payment Record
```json
POST /api/invoices/{id}/payments
{
  "payment_date": "2025-05-29",
  "amount": 500.00,
  "payment_method": "cash",
  "is_downpayment": false,
  "notes": "Final payment"
}
```
**Result**: Payment record will be created with auto-generated reference like `PAY-000001`

### Creating an Invoice with Payment Records
```json
POST /api/invoices
{
  "customer_id": "ObjectId",
  "vehicle_id": 1,
  "price": 1000.00,
  "payment_records": [
    {
      "payment_date": "2025-05-29",
      "amount": 500.00,
      "payment_method": "card",
      "is_downpayment": true,
      "notes": "Downpayment"
    }
  ]
}
```
**Result**: Invoice created with payment record having auto-generated reference

## Reference Number Format
- **Format**: `PAY-XXXXXX`
- **Example**: `PAY-000001`, `PAY-000002`, etc.
- **Uniqueness**: Global across all invoices and payment records
- **Sequence**: Incremental, starting from 1

## Backward Compatibility
- Existing payment records with manual references remain unchanged
- The system will continue the sequence from the highest existing reference number
- Manual references provided in requests are ignored to ensure uniqueness

## Testing
- Created test script: `test-payment-reference-generation.js`
- Verifies reference generation format and uniqueness
- Tests integration with invoice operations

## Benefits
1. **Automatic**: No need for users to manually generate references
2. **Unique**: Guaranteed unique references across the system
3. **Consistent**: Standardized format for all payment references
4. **Traceable**: Easy to track and audit payment records
5. **User-Friendly**: Reduces potential for errors in manual entry
