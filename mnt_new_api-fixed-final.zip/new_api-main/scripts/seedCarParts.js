require('dotenv').config();
const mongoose = require('mongoose');
const CarPart = require('../models/CarPart');

const defaultCarParts = [
  // Exterior Parts
  { name: "Front Bumper", category: "Exterior" },
  { name: "Rear Bumper", category: "Exterior" },
  { name: "Left Front Door", category: "Exterior" },
  { name: "Right Front Door", category: "Exterior" },
  { name: "Left Rear Door", category: "Exterior" },
  { name: "Right Rear Door", category: "Exterior" },
  { name: "Hood", category: "Exterior" },
  { name: "Trunk", category: "Exterior" },
  { name: "Left Front Fender", category: "Exterior" },
  { name: "Right Front Fender", category: "Exterior" },
  { name: "Left Rear Fender", category: "Exterior" },
  { name: "Right Rear Fender", category: "Exterior" },
  { name: "Roof", category: "Exterior" },
  
  // Glass Parts
  { name: "Windshield", category: "Glass" },
  { name: "Rear Window", category: "Glass" },
  { name: "Left Front Window", category: "Glass" },
  { name: "Right Front Window", category: "Glass" },
  { name: "Left Rear Window", category: "Glass" },
  { name: "Right Rear Window", category: "Glass" },
  
  // Mechanical Parts
  { name: "Engine", category: "Mechanical" },
  { name: "Transmission", category: "Mechanical" },
  { name: "Front Suspension", category: "Mechanical" },
  { name: "Rear Suspension", category: "Mechanical" },
  { name: "Front Brakes", category: "Mechanical" },
  { name: "Rear Brakes", category: "Mechanical" },
  { name: "Exhaust System", category: "Mechanical" },
  
  // Interior Parts
  { name: "Seats", category: "Interior" },
  { name: "Dashboard", category: "Interior" },
  { name: "Carpet", category: "Interior" },
  { name: "Headliner", category: "Interior" },
];

async function seedCarParts() {
  try {
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGO_URI, {
      serverSelectionTimeoutMS: 5000,
      socketTimeoutMS: 45000
    });
    
    console.log('Connected to MongoDB');
    
    // Check if car parts already exist
    const existingCount = await CarPart.countDocuments();
    
    if (existingCount > 0) {
      console.log(`Found ${existingCount} existing car parts. Checking for missing parts...`);
      
      // Add only missing parts
      let addedCount = 0;
      for (const part of defaultCarParts) {
        const exists = await CarPart.findOne({ 
          name: part.name, 
          category: part.category 
        });
        
        if (!exists) {
          await CarPart.create(part);
          console.log(`Added: ${part.name} (${part.category})`);
          addedCount++;
        }
      }
      
      if (addedCount > 0) {
        console.log(`\nAdded ${addedCount} new car parts`);
      } else {
        console.log('\nAll default car parts already exist');
      }
    } else {
      // Seed all parts
      console.log('No car parts found. Seeding default parts...');
      
      const createdParts = await CarPart.insertMany(defaultCarParts);
      console.log(`\nSuccessfully seeded ${createdParts.length} car parts`);
      
      // Display seeded parts by category
      const categories = ['Exterior', 'Glass', 'Mechanical', 'Interior'];
      for (const category of categories) {
        const categoryParts = createdParts.filter(p => p.category === category);
        console.log(`\n${category} (${categoryParts.length} parts):`);
        categoryParts.forEach(part => {
          console.log(`  - ${part.name}`);
        });
      }
    }
    
    // Show total count
    const totalCount = await CarPart.countDocuments();
    console.log(`\nTotal car parts in database: ${totalCount}`);
    
  } catch (error) {
    console.error('Error seeding car parts:', error);
    process.exit(1);
  } finally {
    await mongoose.disconnect();
    console.log('\nDisconnected from MongoDB');
    process.exit(0);
  }
}

// Run the seed function
seedCarParts();