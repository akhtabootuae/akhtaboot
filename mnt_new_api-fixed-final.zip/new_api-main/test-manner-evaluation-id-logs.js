const { MongoClient } = require('mongodb');
const User = require('./models/User');

/**
 * Test script to verify that evaluation_id is properly logged in manner evaluation operations
 */
const testEvaluationIdLogging = async () => {
  console.log('🧪 Testing Evaluation ID Logging in Manner Evaluations...\n');
  
  let client, db;
  
  try {
    // Connect to MongoDB
    client = new MongoClient(process.env.MONGODB_URI || 'mongodb://localhost:27017/gms_new_5');
    await client.connect();
    db = client.db();
    
    // Find a test user
    const testUser = await db.collection('users').findOne({ 
      role_name: 'Technician', 
    });
    
    if (!testUser) {
      console.log('❌ No technician user found for testing.');
      return;
    }
    
    console.log(`✅ Using test user: ${testUser.first_name} ${testUser.last_name} (${testUser.email})`);
    
    // Clear existing evaluations and logs for clean testing
    await db.collection('users').updateOne(
      { _id: testUser._id },
      {
        $set: {
          manner_evaluations: [],
          manner_evaluation_logs: []
        }
      }
    );
    
    console.log('🧹 Cleared existing evaluations and logs for clean testing');
    
    // Test 1: Add a new evaluation and check if evaluation_id is in the log
    console.log('\n📋 Test 1: Adding new evaluation and checking log for evaluation_id');
    
    const evaluationData = {
      category: 'Customer Service',
      rating: 4,
      notes: 'Good interaction with customers during test',
      work_order_id: null
    };
    
    const addResult = await User.addMannerEvaluation(
      db, 
      testUser._id.toString(), 
      evaluationData, 
      testUser._id.toString() // Using same user as evaluator for testing
    );
    
    if (addResult.success) {
      console.log(`✅ Evaluation added successfully with ID: ${addResult.evaluationId}`);
      
      // Check the log
      const userAfterAdd = await db.collection('users').findOne(
        { _id: testUser._id },
        { projection: { manner_evaluation_logs: 1, manner_evaluations: 1 } }
      );
      
      const addLog = userAfterAdd.manner_evaluation_logs[0];
      console.log(`📝 Add Log:`, {
        action: addLog.action,
        evaluation_id: addLog.evaluation_id?.toString(),
        category: addLog.category,
        rating: addLog.rating,
        has_evaluation_id: !!addLog.evaluation_id
      });
      
      // Test 2: Update the evaluation and check if evaluation_id is in the log
      console.log('\n📋 Test 2: Updating evaluation and checking log for evaluation_id');
      
      const updateData = {
        category: 'Customer Service',
        rating: 5,
        notes: 'Excellent customer service during test - updated',
        work_order_id: null
      };
      
      const updateResult = await User.updateMannerEvaluation(
        db,
        testUser._id.toString(),
        addResult.evaluationId.toString(),
        updateData,
        testUser._id.toString()
      );
      
      if (updateResult.success) {
        console.log('✅ Evaluation updated successfully');
        
        // Check the update log
        const userAfterUpdate = await db.collection('users').findOne(
          { _id: testUser._id },
          { projection: { manner_evaluation_logs: 1 } }
        );
        
        const updateLog = userAfterUpdate.manner_evaluation_logs.find(log => log.action === 'updated');
        console.log(`📝 Update Log:`, {
          action: updateLog.action,
          evaluation_id: updateLog.evaluation_id?.toString(),
          original_evaluation_id: addResult.evaluationId.toString(),
          matches_original: updateLog.evaluation_id?.toString() === addResult.evaluationId.toString(),
          category: updateLog.category,
          rating: updateLog.rating,
          has_evaluation_id: !!updateLog.evaluation_id
        });
        
        // Test 3: Delete the evaluation and check if evaluation_id is in the log
        console.log('\n📋 Test 3: Deleting evaluation and checking log for evaluation_id');
        
        const deleteResult = await User.deleteMannerEvaluation(
          db,
          testUser._id.toString(),
          addResult.evaluationId.toString(),
          testUser._id.toString()
        );
        
        if (deleteResult.success) {
          console.log('✅ Evaluation deleted successfully');
          
          // Check the delete log
          const userAfterDelete = await db.collection('users').findOne(
            { _id: testUser._id },
            { projection: { manner_evaluation_logs: 1 } }
          );
          
          const deleteLog = userAfterDelete.manner_evaluation_logs.find(log => log.action === 'deleted');
          console.log(`📝 Delete Log:`, {
            action: deleteLog.action,
            evaluation_id: deleteLog.evaluation_id?.toString(),
            original_evaluation_id: addResult.evaluationId.toString(),
            matches_original: deleteLog.evaluation_id?.toString() === addResult.evaluationId.toString(),
            category: deleteLog.category,
            rating: deleteLog.rating,
            has_evaluation_id: !!deleteLog.evaluation_id
          });
          
          // Test 4: Verify all logs have evaluation_id
          console.log('\n📋 Test 4: Verifying all logs have evaluation_id field');
          
          const allLogs = userAfterDelete.manner_evaluation_logs;
          console.log(`Total logs: ${allLogs.length}`);
          
          allLogs.forEach((log, index) => {
            console.log(`Log ${index + 1}:`, {
              action: log.action,
              has_evaluation_id: !!log.evaluation_id,
              evaluation_id: log.evaluation_id?.toString()
            });
          });
          
          const logsWithEvaluationId = allLogs.filter(log => !!log.evaluation_id);
          console.log(`\n✅ Logs with evaluation_id: ${logsWithEvaluationId.length}/${allLogs.length}`);
          
          if (logsWithEvaluationId.length === allLogs.length) {
            console.log('🎉 SUCCESS: All logs contain evaluation_id field!');
          } else {
            console.log('⚠️  WARNING: Some logs are missing evaluation_id field');
          }
          
        } else {
          console.log('❌ Failed to delete evaluation');
        }
      } else {
        console.log('❌ Failed to update evaluation');
      }
    } else {
      console.log('❌ Failed to add evaluation');
    }
    
  } catch (error) {
    console.error('❌ Test failed:', error);
  } finally {
    if (client) {
      await client.close();
    }
  }
};

// Run the test
if (require.main === module) {
  testEvaluationIdLogging().catch(console.error);
}

module.exports = { testEvaluationIdLogging };
