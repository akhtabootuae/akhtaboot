const axios = require('axios');
require('dotenv').config();

// Configuration
const API_BASE_URL = process.env.API_BASE_URL || 'http://localhost:3000/api';
const ADMIN_EMAIL = 'admin@example.com';
const ADMIN_PASSWORD = 'change_this_password';

// Test data
const TEST_USERS = [
  { email: 'technician1@example.com', password: 'password123'},
  { email: 'technician2@example.com', password: 'password123'},
  { email: 'technician3@example.com', password: 'password123' }
];

// Known test user IDs (fallback if profile lookup fails)
const KNOWN_USER_IDS = {
  'technician1@example.com': '60f7b3b3b3b3b3b3b3b3b3b1',
  'technician2@example.com': '60f7b3b3b3b3b3b3b3b3b3b2', 
  'technician3@example.com': '60f7b3b3b3b3b3b3b3b3b3b3'
};

let adminToken = '';
let userTokens = {};
let userIds = {};
let conversationIds = {};

/**
 * Helper function to make authenticated API requests with detailed error logging
 */
async function apiRequest(method, endpoint, data = null, token = null) {
  const config = {
    method,
    url: `${API_BASE_URL}${endpoint}`,
    headers: {}
  };
  
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  
  if (data) {
    config.data = data;
    config.headers['Content-Type'] = 'application/json';
  }
  
  console.log(`🌐 API Request: ${method} ${endpoint}`);
  if (data) {
    console.log(`📤 Request Data:`, JSON.stringify(data, null, 2));
  }
  
  try {
    const response = await axios(config);
    console.log(`✅ API Response: ${response.status} ${response.statusText}`);
    return { success: true, data: response.data };
  } catch (error) {
    console.log(`❌ API Error: ${error.response?.status || 'NO_STATUS'} - ${error.response?.statusText || 'NO_STATUS_TEXT'}`);
    console.log(`📥 Error Response:`, JSON.stringify(error.response?.data || error.message, null, 2));
    
    // For 500 errors, log additional details
    if (error.response?.status === 500) {
      console.log(`🔍 500 Error Details:`);
      console.log(`   URL: ${config.url}`);
      console.log(`   Method: ${method}`);
      console.log(`   Headers:`, JSON.stringify(config.headers, null, 2));
      if (data) {
        console.log(`   Body:`, JSON.stringify(data, null, 2));
      }
    }
    
    return { 
      success: false, 
      error: error.response?.data || error.message,
      status: error.response?.status,
      fullError: error.response || error
    };
  }
}

// Store user data from login to avoid profile endpoint
let userData = {};

/**
 * Login and get authentication token
 */
async function login(email, password) {
  console.log(`🔐 Logging in as ${email}...`);
  const result = await apiRequest('POST', '/users/login', { email, password });
  
  if (result.success && result.data.token) {
    console.log(`✅ Login successful for ${email}`);
    // Store user data from login response
    userData[email] = result.data.user;
    console.log(`   User ID: ${result.data.user.id}`);
    console.log(`   User Name: ${result.data.user.name}`);
    console.log(`   User Role: ${result.data.user.role_name}`);
    return result.data.token;
  } else {
    console.log(`❌ Login failed for ${email}`);
    console.log(`   Status: ${result.status}`);
    console.log(`   Error:`, JSON.stringify(result.error, null, 2));
    if (result.fullError) {
      console.log(`   Full Error:`, JSON.stringify(result.fullError, null, 2));
    }
    throw new Error(`Login failed for ${email}: ${JSON.stringify(result.error)}`);
  }
}

/**
 * Get user information (using cached login data)
 */
async function getUserInfo(token, email) {
  // Use cached user data from login instead of API call
  if (email && userData[email]) {
    return userData[email];
  } 
  
  // Fallback: try to search for user by email
  try {
    const users = await searchUsers(token, email);
    const user = users.find(u => u.email === email);
    if (user) {
      return user;
    }
  } catch (error) {
    console.log(`   Warning: Could not search for user ${email}`);
  }
  
  // Last resort: use known hardcoded IDs
  if (KNOWN_USER_IDS[email]) {
    return { 
      id: KNOWN_USER_IDS[email], 
      _id: KNOWN_USER_IDS[email],
      email: email 
    };
  }
  
  throw new Error('Failed to get user info - no cached data available');
}

/**
 * Search for users
 */
async function searchUsers(token, query = '') {
  console.log(`🔍 Searching for users...`);
  const result = await apiRequest('GET', `/messaging/users/search?q=${query}`, null, token);
  
  if (result.success) {
    console.log(`✅ Found ${result.data.data.length} users`);
    return result.data.data;
  } else {
    console.log(`❌ User search failed:`, result.error);
    throw new Error('User search failed');
  }
}

/**
 * Test Case 1: Admin Announcement to All Technicians
 */
async function testAdminAnnouncement() {
  console.log('\n📢 === TEST CASE 1: ADMIN ANNOUNCEMENT ===');
  
  try {
    // Create announcement conversation
    console.log('📝 Creating announcement conversation...');
    const announcementData = {
      title: 'System Maintenance Notice',
      description: 'Important system maintenance scheduled for this weekend'
    };
    
    const result = await apiRequest(
      'POST', 
      '/messaging/conversations/announcement', 
      announcementData, 
      adminToken
    );
    
    if (result.success) {
      conversationIds.announcement = result.data.data._id;
      console.log(`✅ Announcement conversation created: ${conversationIds.announcement}`);
      console.log(`   Title: ${result.data.data.title}`);
      console.log(`   Participants: ${result.data.data.participants.length}`);
    } else {
      console.log(`❌ Failed to create announcement:`, result.error);
      throw new Error(`Failed to create announcement: ${JSON.stringify(result.error)}`);
    }
    
    // Send announcement message
    console.log('📤 Sending announcement message...');
    const messageData = {
      content: 'Dear team, we will be performing system maintenance this Saturday from 2 AM to 6 AM. Please plan your work accordingly. Thank you for your understanding.',
      message_type: 'announcement'
    };
    
    const messageResult = await apiRequest(
      'POST',
      `/messaging/conversations/${conversationIds.announcement}/messages`,
      messageData,
      adminToken
    );
    
    if (messageResult.success) {
      console.log(`✅ Announcement message sent successfully`);
      console.log(`   Message: "${messageResult.data.data.content.substring(0, 50)}..."`);
    } else {
      console.log(`❌ Failed to send announcement message:`, messageResult.error);
      throw new Error(`Failed to send announcement message: ${JSON.stringify(messageResult.error)}`);
    }
    
    // Verify technicians can see the announcement
    console.log('👀 Verifying technicians can see the announcement...');
    for (const [email, token] of Object.entries(userTokens)) {
      const conversationsResult = await apiRequest('GET', '/messaging/conversations', null, token);
      if (conversationsResult.success) {
        const announcementConv = conversationsResult.data.data.find(
          conv => conv._id === conversationIds.announcement
        );
        if (announcementConv) {
          console.log(`   ✅ ${email} can see the announcement`);
        } else {
          console.log(`   ❌ ${email} cannot see the announcement`);
        }
      }
    }
    
    console.log('✅ Admin announcement test completed successfully');
    
  } catch (error) {
    console.log('❌ Admin announcement test failed:', error.message);
    throw error;
  }
}

/**
 * Test Case 2: Group Chat
 */
async function testGroupChat() {
  console.log('\n👥 === TEST CASE 2: GROUP CHAT ===');
  
  try {
    // Get tech user IDs for group
    const tech1Id = userIds[TEST_USERS[0].email];
    const tech2Id = userIds[TEST_USERS[1].email];
    const tech3Id = userIds[TEST_USERS[2].email];
    
    // Create group conversation (using tech1's token)
    console.log('👥 Creating group conversation...');
    const groupData = {
      title: 'PDR Team Discussion',
      description: 'Group chat for PDR technicians to discuss work and coordination',
      participant_ids: [tech2Id, tech3Id] // tech1 will be added automatically as creator
    };
    
    const result = await apiRequest(
      'POST',
      '/messaging/conversations/group',
      groupData,
      userTokens[TEST_USERS[0].email]
    );
    
    if (result.success) {
      conversationIds.group = result.data.data._id;
      console.log(`✅ Group conversation created: ${conversationIds.group}`);
      console.log(`   Title: ${result.data.data.title}`);
      console.log(`   Participants: ${result.data.data.participants.length}`);
    } else {
      throw new Error(`Failed to create group conversation: ${result.error.message}`);
    }
    
    // Send messages from different users
    const groupMessages = [
      {
        sender: TEST_USERS[0].email,
        content: 'Hey team! How are the PDR jobs going today?'
      },
      {
        sender: TEST_USERS[1].email,
        content: 'Going well! Just finished a Honda Civic, small dent on the door. Clean repair.'
      },
      {
        sender: TEST_USERS[2].email,
        content: 'I have a BMW coming in at 2 PM. Large dent on the hood, might take a while.'
      },
      {
        sender: TEST_USERS[0].email,
        content: 'Sounds good. Let me know if you need any help with the BMW!'
      }
    ];
    
    console.log('💬 Sending group messages...');
    for (const msg of groupMessages) {
      const messageResult = await apiRequest(
        'POST',
        `/messaging/conversations/${conversationIds.group}/messages`,
        { content: msg.content },
        userTokens[msg.sender]
      );
      
      if (messageResult.success) {
        console.log(`   ✅ ${msg.sender}: "${msg.content.substring(0, 30)}..."`);
      } else {
        console.log(`   ❌ Failed to send message from ${msg.sender}`);
      }
      
      // Small delay to ensure proper message ordering
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    // Verify all participants can see messages
    console.log('👀 Verifying all participants can see group messages...');
    for (const user of TEST_USERS) {
      const messagesResult = await apiRequest(
        'GET',
        `/messaging/conversations/${conversationIds.group}/messages`,
        null,
        userTokens[user.email]
      );
      
      if (messagesResult.success) {
        console.log(`   ✅ ${user.email} can see ${messagesResult.data.data.length} messages`);
      } else {
        console.log(`   ❌ ${user.email} cannot access group messages`);
      }
    }
    
    console.log('✅ Group chat test completed successfully');
    
  } catch (error) {
    console.log('❌ Group chat test failed:', error.message);
    throw error;
  }
}

/**
 * Test Case 3: One-to-One Private Chat
 */
async function testPrivateChat() {
  console.log('\n💬 === TEST CASE 3: PRIVATE CHAT (1-on-1) ===');
  
  try {
    const tech1Email = TEST_USERS[0].email;
    const tech2Email = TEST_USERS[1].email;
    const tech2Id = userIds[tech2Email];
    
    // Create private conversation
    console.log('💬 Creating private conversation...');
    const privateData = {
      recipient_id: tech2Id
    };
    
    const result = await apiRequest(
      'POST',
      '/messaging/conversations/private',
      privateData,
      userTokens[tech1Email]
    );
    
    if (result.success) {
      conversationIds.private = result.data.data._id;
      console.log(`✅ Private conversation created: ${conversationIds.private}`);
      console.log(`   Type: ${result.data.data.conversation_type}`);
      console.log(`   Participants: ${result.data.data.participants.length}`);
    } else {
      throw new Error(`Failed to create private conversation: ${result.error.message}`);
    }
    
    // Exchange private messages
    const privateMessages = [
      {
        sender: tech1Email,
        content: 'Hey! Do you have the special tools for the aluminum panel repair?'
      },
      {
        sender: tech2Email,
        content: 'Yes, I have the aluminum-specific PDR tools. Do you need to borrow them?'
      },
      {
        sender: tech1Email,
        content: 'That would be great! I have a Tesla Model S coming in tomorrow with aluminum body damage.'
      },
      {
        sender: tech2Email,
        content: 'Perfect! I\'ll bring them over after I finish this current job. Should be about 30 minutes.'
      },
      {
        sender: tech1Email,
        content: 'Thanks a lot! I owe you lunch! 😄'
      }
    ];
    
    console.log('💬 Exchanging private messages...');
    for (const msg of privateMessages) {
      const messageResult = await apiRequest(
        'POST',
        `/messaging/conversations/${conversationIds.private}/messages`,
        { content: msg.content },
        userTokens[msg.sender]
      );
      
      if (messageResult.success) {
        console.log(`   ✅ ${msg.sender.split('@')[0]}: "${msg.content.substring(0, 40)}..."`);
      } else {
        console.log(`   ❌ Failed to send message from ${msg.sender}`);
      }
      
      // Small delay between messages
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    // Verify both users can see the conversation
    console.log('👀 Verifying both users can see private messages...');
    for (const email of [tech1Email, tech2Email]) {
      const messagesResult = await apiRequest(
        'GET',
        `/messaging/conversations/${conversationIds.private}/messages`,
        null,
        userTokens[email]
      );
      
      if (messagesResult.success) {
        console.log(`   ✅ ${email} can see ${messagesResult.data.data.length} messages`);
      } else {
        console.log(`   ❌ ${email} cannot access private messages`);
      }
    }
    
    // Test creating duplicate private conversation (should return existing)
    console.log('🔄 Testing duplicate private conversation creation...');
    const duplicateResult = await apiRequest(
      'POST',
      '/messaging/conversations/private',
      { recipient_id: tech2Id },
      userTokens[tech1Email]
    );
    
    if (duplicateResult.success && duplicateResult.data.data._id === conversationIds.private) {
      console.log('   ✅ Duplicate prevention working - returned existing conversation');
    } else {
      console.log('   ❌ Duplicate prevention failed');
    }
    
    console.log('✅ Private chat test completed successfully');
    
  } catch (error) {
    console.log('❌ Private chat test failed:', error.message);
    throw error;
  }
}

/**
 * Display final test summary
 */
function displayTestSummary() {
  console.log('\n📊 === TEST SUMMARY ===');
  console.log('✅ All messaging tests completed successfully!');
  console.log('\nCreated conversations:');
  console.log(`   📢 Announcement: ${conversationIds.announcement || 'N/A'}`);
  console.log(`   👥 Group Chat: ${conversationIds.group || 'N/A'}`);
  console.log(`   💬 Private Chat: ${conversationIds.private || 'N/A'}`);
  
  console.log('\n🎯 Test scenarios verified:');
  console.log('   ✅ Admin can send announcements to all users');
  console.log('   ✅ Users can create and participate in group chats');
  console.log('   ✅ Users can have private one-on-one conversations');
  console.log('   ✅ Message encryption/decryption working');
  console.log('   ✅ Permission-based access control functioning');
  console.log('   ✅ Duplicate conversation prevention working');
}

/**
 * Main test execution
 */
async function runMessagingTests() {
  console.log('🚀 Starting Messaging System Tests...');
  console.log(`📡 API Base URL: ${API_BASE_URL}`);
  
  try {
    // Step 1: Login as admin
    adminToken = await login(ADMIN_EMAIL, ADMIN_PASSWORD);
    
    // Step 2: Login as test users and get their IDs
    console.log('\n👥 Setting up test users...');
    for (const user of TEST_USERS) {
      try {
        userTokens[user.email] = await login(user.email, user.password);
        const userInfo = await getUserInfo(userTokens[user.email], user.email);
        userIds[user.email] = userInfo.id || userInfo._id;
        console.log(`✅ ${user.email} setup complete (ID: ${userInfo.id || userInfo._id})`);
      } catch (error) {
        console.log(`⚠️  Could not setup ${user.email}: ${error.message}`);
        // Remove failed user from tokens to prevent further issues
        delete userTokens[user.email];
      }
    }
    
    // Check if we have enough users for testing
    const availableUsers = Object.keys(userTokens).length;
    if (availableUsers < 3) {
      console.log(`⚠️  Warning: Only ${availableUsers} test users available. Some tests may be limited.`);
    }
    
    // Step 3: Run test cases
    await testAdminAnnouncement();
    
    if (availableUsers >= 3) {
      await testGroupChat();
    } else {
      console.log('\n👥 Skipping group chat test - need at least 3 users');
    }
    
    if (availableUsers >= 2) {
      await testPrivateChat();
    } else {
      console.log('\n💬 Skipping private chat test - need at least 2 users');
    }
    
    // Step 4: Display summary
    displayTestSummary();
    
  } catch (error) {
    console.log('\n❌ Test execution failed:', error.message);
    console.log('\nPlease check:');
    console.log('   - API server is running');
    console.log('   - Database is connected');
    console.log('   - Admin user exists with correct credentials');
    console.log('   - Test users exist or can be created');
    process.exit(1);
  }
}

// Execute tests
if (require.main === module) {
  runMessagingTests().catch(error => {
    console.error('💥 Unhandled error:', error);
    process.exit(1);
  });
}

module.exports = {
  runMessagingTests,
  testAdminAnnouncement,
  testGroupChat,
  testPrivateChat
};
