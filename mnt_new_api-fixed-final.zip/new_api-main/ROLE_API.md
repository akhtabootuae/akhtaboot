# Role API Documentation

This document provides information about the API endpoints related to roles.

## Base URL

```
/api/roles
```

## Endpoints

### Get all roles

```
GET /api/roles
```

**Description**: Retrieve a list of all available roles.

**Authorization**: Requires valid JWT token.

**Response**:

```json
[
  {
    "_id": "60d21b4667d0d8992e610c85",
    "role_name": "Admin",
    "description": "Full system access with all privileges",
    "created_at": "2023-06-22T12:00:00.000Z",
    "updated_at": "2023-06-22T12:00:00.000Z"
  },
  {
    "_id": "60d21b4667d0d8992e610c86",
    "role_name": "Supervisor",
    "description": "Manages technicians and oversees operations",
    "created_at": "2023-06-22T12:00:00.000Z",
    "updated_at": "2023-06-22T12:00:00.000Z"
  }
]
```

### Get role by ID

```
GET /api/roles/:id
```

**Description**: Retrieve a specific role by its ID.

**Authorization**: Requires valid JWT token.

**Parameters**:
- `id`: The MongoDB ObjectId of the role

**Response**:

```json
{
  "_id": "60d21b4667d0d8992e610c85",
  "role_name": "Admin",
  "description": "Full system access with all privileges",
  "created_at": "2023-06-22T12:00:00.000Z",
  "updated_at": "2023-06-22T12:00:00.000Z"
}
```

### Create a new role

```
POST /api/roles
```

**Description**: Create a new role.

**Authorization**: Requires valid JWT token and Admin privileges.

**Request Body**:

```json
{
  "role_name": "Manager",
  "description": "Department manager with limited administrative privileges"
}
```

**Response**:

```json
{
  "_id": "60d21b4667d0d8992e610c87",
  "role_name": "Manager",
  "description": "Department manager with limited administrative privileges",
  "created_at": "2023-06-22T12:00:00.000Z",
  "updated_at": "2023-06-22T12:00:00.000Z"
}
```

### Update a role

```
PUT /api/roles/:id
```

**Description**: Update an existing role.

**Authorization**: Requires valid JWT token and Admin privileges.

**Parameters**:
- `id`: The MongoDB ObjectId of the role

**Request Body**:

```json
{
  "description": "Updated role description"
}
```

**Response**:

```json
{
  "message": "Role updated successfully",
  "_id": "60d21b4667d0d8992e610c85",
  "description": "Updated role description",
  "updated_at": "2023-06-22T14:00:00.000Z"
}
```

### Delete a role

```
DELETE /api/roles/:id
```

**Description**: Delete a role.

**Authorization**: Requires valid JWT token and Admin privileges.

**Parameters**:
- `id`: The MongoDB ObjectId of the role

**Response**:

```json
{
  "message": "Role deleted successfully"
}
```

## Error Responses

```json
{
  "message": "Role not found"
}
```

```json
{
  "message": "Server error"
}
```

```json
{
  "message": "Please provide role_name and description"
}
```

```json
{
  "message": "Role already exists"
}
```
