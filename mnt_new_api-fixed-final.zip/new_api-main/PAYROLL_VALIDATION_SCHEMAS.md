# Payroll Collections Validation Schemas

This document contains the validation schemas for all payroll-related MongoDB collections. These schemas are used to ensure data integrity and should be referenced when creating seeders or modifying payroll data.

## Table of Contents
1. [pay_periods](#pay_periods)
2. [pay_stubs](#pay_stubs)
3. [payroll_calculations](#payroll_calculations)
4. [payroll_deduction_history](#payroll_deduction_history)
5. [payroll_deduction_types](#payroll_deduction_types)
6. [payroll_employee_deductions](#payroll_employee_deductions)

---

## pay_periods

### Required Fields
- `period_name` (string, maxLength: 100)
- `start_date` (date)
- `end_date` (date)
- `pay_date` (date)
- `frequency` (string, enum)
- `year` (int, 2020-2050)

### Optional Fields
- `period_number` (int, 1-53)
- `status` (string, enum)
- `cutoff_date` (date)
- `total_employees` (int, min: 0)
- `total_hours` (number, min: 0)
- `total_gross_pay` (number, min: 0)
- `total_deductions` (number, min: 0)
- `total_net_pay` (number, min: 0)
- `processed_at` (date)
- `processed_by` (objectId)
- `closed_at` (date)
- `closed_by` (objectId)
- `notes` (string, maxLength: 500)
- `created_at` (date)
- `updated_at` (date)
- `created_by` (objectId)
- `updated_by` (objectId)

### Enum Values
- `frequency`: ["weekly", "bi-weekly", "monthly", "semi-monthly"]
- `status`: ["draft", "open", "processing", "closed", "cancelled"]

### Validation Rules
- `start_date` must be before `end_date`
- `pay_date` must be on or after `end_date`
- Pay periods cannot overlap with existing periods (except cancelled ones)

---

## pay_stubs

### Required Fields
- `employee_id` (objectId)
- `pay_period_id` (objectId)
- `payroll_calculation_id` (objectId)
- `stub_number` (string, maxLength: 50)
- `issue_date` (date)

### Required Nested Objects

#### employee_info (required fields):
- `employee_id` (string)
- `full_name` (string)
- `email` (string)

#### pay_period_info (required fields):
- `start_date` (date)
- `end_date` (date)
- `frequency` (string, enum)

#### earnings (required fields):
- `gross_pay` (number, min: 0)
- `net_pay` (number, min: 0)

### Optional Fields
- `pay_date` (date)
- `pdf_path` (string)
- `status` (string, enum)
- `delivery_method` (string, enum)
- `delivered_at` (date)
- `viewed_at` (date)
- `notes` (string, maxLength: 500)
- `created_at` (date)
- `updated_at` (date)
- `created_by` (objectId)
- `updated_by` (objectId)

### Deductions Array Schema
Each deduction object requires:
- `name` (string)
- `amount` (number, min: 0)

Optional fields:
- `type` (string, enum: ["tax", "insurance", "retirement", "loan", "advance", "other"])
- `calculation_method` (string, enum: ["fixed", "percentage", "formula"])
- `ytd_amount` (number, min: 0)

### Enum Values
- `status`: ["draft", "issued", "delivered", "viewed"]
- `delivery_method`: ["email", "print", "portal", "other"]
- `frequency`: ["weekly", "bi-weekly", "monthly", "semi-monthly"]

---

## payroll_calculations

### Required Fields
- `employee_id` (objectId)
- `pay_period_id` (objectId)
- `gross_pay` (number, min: 0)
- `total_deductions` (number, min: 0)
- `net_pay` (number, min: 0)

### Optional Fields
- `regular_hours` (number, min: 0)
- `overtime_hours` (number, min: 0)
- `total_hours` (number, min: 0)
- `regular_pay` (number, min: 0)
- `overtime_pay` (number, min: 0)
- `daily_rate` (number, min: 0)
- `hourly_rate` (number, min: 0)
- `days_worked` (int, min: 0)
- `status` (string, enum)
- `calculation_date` (date)
- `approved_at` (date)
- `approved_by` (objectId)
- `paid_at` (date)
- `pay_method` (string, enum)
- `notes` (string, maxLength: 500)
- `created_at` (date)
- `updated_at` (date)
- `created_by` (objectId)
- `updated_by` (objectId)

### Deductions Array Schema
Each deduction object requires:
- `deduction_type_id` (objectId)
- `amount` (number, min: 0)

Optional fields:
- `deduction_name` (string)
- `calculation_method` (string, enum: ["fixed", "percentage", "formula"])
- `percentage` (number, 0-100)
- `notes` (string, maxLength: 200)

### Taxes Object Schema (optional)
- `federal_tax` (number, min: 0)
- `state_tax` (number, min: 0)
- `social_security` (number, min: 0)
- `medicare` (number, min: 0)
- `other_taxes` (number, min: 0)

### Enum Values
- `status`: ["draft", "calculated", "reviewed", "approved", "paid"]
- `pay_method`: ["bank_transfer", "check", "cash", "other"]

### Validation Rules
- Cannot have duplicate calculations for same employee and pay period
- Cannot modify calculations with status "paid"

---

## payroll_deduction_history

### Required Fields
- `employee_deduction_id` (objectId)
- `employee_id` (objectId)
- `pay_period_start` (date)
- `pay_period_end` (date)
- `gross_pay_amount` (number, min: 0)
- `amount_deducted` (number, min: 0)
- `processed_at` (date)

### Optional Fields
- `reason_for_variance` (string, maxLength: 500)
- `remaining_balance_after` (number, min: 0, nullable)
- `processed_by` (objectId, nullable)

---

## payroll_deduction_types

### Required Fields
- `name` (string, minLength: 1, maxLength: 100)
- `type` (string, enum)
- `created_at` (date)

### Optional Fields
- `description` (string, maxLength: 500)
- `default_amount` (number, min: 0, nullable)
- `default_percentage` (number, 0-100, nullable)
- `frequency` (string, enum)
- `max_percentage_of_pay` (number, 0-100, nullable)
- `requires_approval` (boolean)
- `is_system_type` (boolean)
- `active` (boolean)
- `updated_at` (date)

### Enum Values
- `type`: ["fixed_amount", "percentage", "conditional"]
- `frequency`: ["daily", "weekly", "monthly", "per_pay_period", "one_time"]

### Validation Rules
- System types (`is_system_type: true`) cannot be deleted
- Cannot delete deduction types with active deductions

---

## payroll_employee_deductions

### Required Fields
- `employee_id` (objectId)
- `deduction_type_id` (objectId)
- `amount` (number, min: 0)
- `frequency` (string, enum)
- `start_date` (date)
- `status` (string, enum)
- `created_by` (objectId)
- `created_at` (date)

### Optional Fields
- `end_date` (date, nullable)
- `priority` (int, 1-10)
- `max_total_amount` (number, min: 0, nullable)
- `total_deducted` (number, min: 0)
- `remaining_balance` (number, min: 0, nullable)
- `notes` (string, maxLength: 1000)
- `reference_number` (string, maxLength: 50)
- `legal_required` (boolean)
- `approved_by` (objectId, nullable)
- `approved_at` (date, nullable)
- `updated_at` (date)

### Enum Values
- `frequency`: ["daily", "weekly", "monthly", "per_pay_period", "one_time"]
- `status`: ["active", "paused", "completed", "cancelled", "pending_approval"]

### Validation Rules
- Employee must exist and be payroll eligible
- Deduction type must exist and be active
- End date must be after start date
- Priority must be between 1 and 10
- Deductions are processed in priority order (1 = highest)

---

## Important Notes for Seeders

1. **ObjectId References**: All `objectId` fields must reference valid documents in their respective collections
2. **Date Fields**: All date fields should be proper JavaScript Date objects or ISO date strings
3. **Number Precision**: Financial amounts should be rounded to 2 decimal places
4. **Status Workflow**: Respect the status workflow for each collection (e.g., pay periods go from draft → open → processing → closed)
5. **Required Relationships**:
   - Pay stubs require existing payroll calculations
   - Payroll calculations require existing pay periods and employees
   - Employee deductions require existing deduction types and employees
   - Deduction history requires existing employee deductions

## Example Seed Data Structure

```javascript
// Pay Period
{
  period_name: "January 2024 - Week 1",
  start_date: new Date("2024-01-01"),
  end_date: new Date("2024-01-07"),
  pay_date: new Date("2024-01-12"),
  frequency: "weekly",
  year: 2024,
  period_number: 1,
  status: "open",
  cutoff_date: new Date("2024-01-08"),
  total_employees: 0,
  total_hours: 0,
  total_gross_pay: 0,
  total_deductions: 0,
  total_net_pay: 0,
  created_at: new Date(),
  updated_at: new Date(),
  created_by: new ObjectId("user_id_here")
}

// Deduction Type
{
  name: "Health Insurance",
  description: "Employee health insurance premium",
  type: "fixed_amount",
  default_amount: 150.00,
  frequency: "monthly",
  max_percentage_of_pay: null,
  requires_approval: false,
  is_system_type: true,
  active: true,
  created_at: new Date(),
  updated_at: new Date()
}

// Employee Deduction
{
  employee_id: new ObjectId("employee_id_here"),
  deduction_type_id: new ObjectId("deduction_type_id_here"),
  amount: 150.00,
  frequency: "monthly",
  start_date: new Date("2024-01-01"),
  end_date: null,
  status: "active",
  priority: 2,
  max_total_amount: null,
  total_deducted: 0,
  remaining_balance: null,
  legal_required: false,
  created_by: new ObjectId("user_id_here"),
  created_at: new Date(),
  updated_at: new Date()
}
```