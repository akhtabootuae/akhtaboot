const { MongoClient, ObjectId } = require('mongodb');
const PayrollAuditLog = require('./models/PayrollAuditLog');

async function debugAuditLog() {
  let client;
  
  try {
    // Connect to MongoDB
    const uri = process.env.MONGODB_URI || 'mongodb://localhost:27017/your_database';
    client = new MongoClient(uri);
    await client.connect();
    
    const db = client.db();
    console.log('Connected to MongoDB');
    
    // Test 1: Create audit entry with minimal required fields
    console.log('\n=== Test 1: Minimal required fields ===');
    try {
      const minimalEntry = {
        user_id: new ObjectId().toString(), // Generate a test ObjectId
        action: 'update_rate',
        entity_type: 'payroll_rate',
      };
      
      console.log('Attempting to insert:', JSON.stringify(minimalEntry, null, 2));
      await PayrollAuditLog.createAuditEntry(db, minimalEntry);
      console.log('✓ Test 1 passed');
    } catch (error) {
      console.error('✗ Test 1 failed:', error.message);
      if (error.errInfo) {
        console.error('Validation details:', JSON.stringify(error.errInfo, null, 2));
      }
    }
    
    // Test 2: Create audit entry like in payrollRoutes.js (line 227)
    console.log('\n=== Test 2: Entry from payrollRoutes.js ===');
    try {
      const routeEntry = {
        user_id: new ObjectId().toString(),
        user_email: 'test@example.com',
        action: 'update_rate',
        entity_type: 'payroll_rate',
        entity_id: new ObjectId().toString(),
        ip_address: '127.0.0.1',
        user_agent: 'Mozilla/5.0',
        details: {
          old_values: { daily_rate: 100 },
          new_values: { daily_rate: 150 },
          request_method: 'PUT',
          endpoint: '/api/payroll/rates/123',
          success: true,
          effective_date: new Date(),
          reason: 'Annual raise',
          operation: 'update'
        },
        severity: 'medium',
        category: 'data_modification'
      };
      
      console.log('Attempting to insert:', JSON.stringify(routeEntry, null, 2));
      await PayrollAuditLog.createAuditEntry(db, routeEntry);
      console.log('✓ Test 2 passed');
    } catch (error) {
      console.error('✗ Test 2 failed:', error.message);
      if (error.errInfo) {
        console.error('Validation details:', JSON.stringify(error.errInfo, null, 2));
      }
    }
    
    // Test 3: Create audit entry like in middleware (payrollAudit.js)
    console.log('\n=== Test 3: Entry from middleware ===');
    try {
      const middlewareEntry = {
        user_id: new ObjectId().toString(),
        user_email: 'Unknown',
        action: 'view_payroll',
        entity_type: 'payroll_system',
        entity_id: null,
        ip_address: '::1',
        user_agent: 'PostmanRuntime/7.26.8',
        details: {
          request_method: 'GET',
          endpoint: '/api/payroll/rates',
          success: true
        },
        severity: 'low',
        category: 'data_access'
      };
      
      console.log('Attempting to insert:', JSON.stringify(middlewareEntry, null, 2));
      await PayrollAuditLog.createAuditEntry(db, middlewareEntry);
      console.log('✓ Test 3 passed');
    } catch (error) {
      console.error('✗ Test 3 failed:', error.message);
      if (error.errInfo) {
        console.error('Validation details:', JSON.stringify(error.errInfo, null, 2));
      }
    }
    
    // Test 4: Direct insertion to test MongoDB validation
    console.log('\n=== Test 4: Direct MongoDB insertion ===');
    try {
      const directEntry = {
        user_id: new ObjectId(),
        user_email: 'test@example.com',
        action: 'update_rate',
        entity_type: 'payroll_rate',
        entity_id: new ObjectId(),
        timestamp: new Date(),
        ip_address: '127.0.0.1',
        user_agent: 'Test Agent',
        details: {},
        session_id: null,
        severity: 'low',
        category: 'data_modification'
      };
      
      console.log('Attempting direct insert:', JSON.stringify(directEntry, null, 2));
      const result = await db.collection('payroll_audit_log').insertOne(directEntry);
      console.log('✓ Test 4 passed, inserted with ID:', result.insertedId);
    } catch (error) {
      console.error('✗ Test 4 failed:', error.message);
      if (error.errInfo) {
        console.error('Validation details:', JSON.stringify(error.errInfo, null, 2));
      }
    }
    
    // Test 5: Check if collection has validation rules
    console.log('\n=== Test 5: Check collection validation ===');
    try {
      const collections = await db.listCollections({ name: 'payroll_audit_log' }).toArray();
      if (collections.length > 0) {
        console.log('Collection exists with options:', JSON.stringify(collections[0].options, null, 2));
      } else {
        console.log('Collection does not exist');
      }
    } catch (error) {
      console.error('Error checking collection:', error.message);
    }
    
  } catch (error) {
    console.error('Fatal error:', error);
  } finally {
    if (client) {
      await client.close();
      console.log('\nDisconnected from MongoDB');
    }
  }
}

// Run the debug script
debugAuditLog().catch(console.error);