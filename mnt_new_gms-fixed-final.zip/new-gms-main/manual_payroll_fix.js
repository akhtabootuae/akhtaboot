// Manual Payroll System Fix - Works around validation issues
// Run: mongosh GMS_DB < manual_payroll_fix.js

print("🔧 Manual Payroll System Fix - Working around schema validation...");

const db = db.getSiblingDB('GMS_DB');

// First, let's bypass validation by temporarily disabling it
print("\n⚠️  Temporarily disabling validation to add payroll_info...");

try {
  // Disable validation temporarily
  db.runCommand({
    collMod: "users",
    validator: {}
  });
  print("✅ Validation temporarily disabled");
  
  // Now add payroll_info to all users
  const updateResult = db.users.updateMany(
    { "payroll_info": { $exists: false } },
    {
      $set: {
        "payroll_info": {
          current_daily_rate: 0,
          employee_number: "",
          hire_date: null,
          payroll_eligible: true,
          last_pay_date: null
        },
        "updated_at": new Date()
      }
    }
  );
  
  print(`✅ Added payroll_info to ${updateResult.modifiedCount} users`);
  
  // Set admins as not payroll eligible
  const adminUpdate = db.users.updateMany(
    { "role_name": "Admin" },
    {
      $set: {
        "payroll_info.payroll_eligible": false,
        "updated_at": new Date()
      }
    }
  );
  
  print(`✅ Set ${adminUpdate.modifiedCount} admin users as not payroll eligible`);
  
} catch (error) {
  print("❌ Error during user updates:", error.message);
}

// Add payroll permissions to users
print("\n🔑 Adding payroll permissions...");

const payrollPermissions = [
  {
    permission_id: "payroll_view",
    permission_name: "View Payroll",
    permission_description: "Can view payroll data and reports",
    category: "PAYROLL_MANAGEMENT",
    granted: true
  },
  {
    permission_id: "payroll_manage_rates",
    permission_name: "Manage Employee Rates",
    permission_description: "Can modify employee daily rates",
    category: "PAYROLL_MANAGEMENT",
    granted: true
  },
  {
    permission_id: "payroll_process",
    permission_name: "Process Payroll",
    permission_description: "Can process payroll runs and generate paystubs",
    category: "PAYROLL_MANAGEMENT",
    granted: true
  }
];

try {
  // Add permissions to admin users
  const adminUsers = db.users.find({ role_name: "Admin" }).toArray();
  
  adminUsers.forEach(admin => {
    payrollPermissions.forEach(permission => {
      // Check if permission exists
      const hasPermission = admin.permissions && admin.permissions.some(p => p.permission_id === permission.permission_id);
      
      if (!hasPermission) {
        db.users.updateOne(
          { _id: admin._id },
          {
            $push: {
              permissions: permission
            },
            $set: { updated_at: new Date() }
          }
        );
      }
    });
  });
  
  print(`✅ Added payroll permissions to ${adminUsers.length} admin users`);
  
} catch (error) {
  print("❌ Error adding permissions:", error.message);
}

// Re-enable validation with payroll_info included
print("\n🔒 Re-enabling validation with payroll_info support...");

try {
  db.runCommand({
    collMod: "users",
    validator: {
      $jsonSchema: {
        bsonType: 'object',
        required: [
          'first_name',
          'last_name',
          'email',
          'password_hash',
          'role_id',
          'role_name',
          'created_at',
          'updated_at'
        ],
        properties: {
          first_name: {
            bsonType: 'string'
          },
          last_name: {
            bsonType: 'string'
          },
          email: {
            bsonType: 'string',
            description: 'must be a string and is required'
          },
          phone: {
            bsonType: 'string'
          },
          password_hash: {
            bsonType: 'string'
          },
          is_active: {
            bsonType: 'bool',
            description: 'active flag'
          },
          staff_code: {
            bsonType: 'string'
          },
          speciality: {
            bsonType: 'string',
            // Removed enum constraint to allow existing data
            description: 'Technician specialty or role description'
          },
          branch: {
            bsonType: 'object',
            required: [
              'branch_id',
              'branch_name'
            ],
            properties: {
              branch_id: {
                bsonType: 'objectId'
              },
              branch_name: {
                bsonType: 'string'
              },
              branch_code: {
                bsonType: 'string'
              },
              location: {
                bsonType: 'string'
              }
            }
          },
          role_id: {
            bsonType: 'objectId'
          },
          role_name: {
            bsonType: 'string'
          },
          role_description: {
            bsonType: 'string'
          },
          permissions: {
            bsonType: 'array',
            items: {
              bsonType: 'object',
              required: [
                'permission_id',
                'permission_name',
                'granted'
              ],
              properties: {
                permission_id: {
                  bsonType: 'string'
                },
                permission_name: {
                  bsonType: 'string'
                },
                permission_description: {
                  bsonType: 'string'
                },
                category: {
                  bsonType: 'string'
                },
                granted: {
                  bsonType: 'bool'
                }
              }
            }
          },
          permission_logs: {
            bsonType: 'array',
            items: {
              bsonType: 'object',
              required: [
                'log_id',
                'target_type',
                'target_id',
                'permission_id',
                'action',
                'created_at'
              ],
              properties: {
                log_id: {
                  bsonType: 'string'
                },
                target_type: {
                  'enum': [
                    'user',
                    'role'
                  ]
                },
                target_id: {
                  bsonType: 'objectId'
                },
                permission_id: {
                  bsonType: 'string'
                },
                action: {
                  'enum': [
                    'grant',
                    'revoke'
                  ]
                },
                created_at: {
                  bsonType: 'date'
                },
                details: {
                  bsonType: 'string'
                }
              }
            }
          },
          // NEW: payroll_info field
          payroll_info: {
            bsonType: 'object',
            properties: {
              current_daily_rate: {
                bsonType: 'number',
                minimum: 0
              },
              employee_number: {
                bsonType: 'string'
              },
              hire_date: {
                bsonType: ['date', 'null']
              },
              payroll_eligible: {
                bsonType: 'bool'
              },
              last_pay_date: {
                bsonType: ['date', 'null']
              }
            }
          },
          created_at: {
            bsonType: 'date'
          },
          updated_at: {
            bsonType: 'date'
          }
        }
      }
    }
  });
  
  print("✅ Validation re-enabled with payroll_info support");
  
} catch (error) {
  print("❌ Error re-enabling validation:", error.message);
}

// Create employee numbers
print("\n🔢 Creating employee numbers...");

try {
  const payrollUsers = db.users.find({ 
    "payroll_info.payroll_eligible": true,
    "payroll_info.employee_number": ""
  }).toArray();
  
  payrollUsers.forEach((user, index) => {
    const empNum = `EMP${String(index + 1).padStart(3, '0')}`;
    db.users.updateOne(
      { _id: user._id },
      {
        $set: {
          "payroll_info.employee_number": empNum,
          "payroll_info.hire_date": new Date(),
          "updated_at": new Date()
        }
      }
    );
    print(`✅ ${user.first_name} ${user.last_name} -> ${empNum}`);
  });
  
} catch (error) {
  print("❌ Error creating employee numbers:", error.message);
}

// Create sample payroll rates
print("\n🧪 Creating sample payroll rates...");

try {
  const employees = db.users.find({ 
    "payroll_info.payroll_eligible": true 
  }).limit(3).toArray();
  
  const admin = db.users.findOne({ role_name: "Admin" });
  
  if (admin && employees.length > 0) {
    employees.forEach((emp, index) => {
      const rate = 150 + (index * 25);
      
      // Insert rate record
      db.payroll_rates.insertOne({
        employee_id: emp._id,
        daily_rate: rate,
        rate_type: "regular",
        effective_date: new Date(),
        end_date: null,
        created_by: admin._id,
        created_at: new Date(),
        notes: "Initial setup rate"
      });
      
      // Update user's current rate
      db.users.updateOne(
        { _id: emp._id },
        {
          $set: {
            "payroll_info.current_daily_rate": rate,
            "updated_at": new Date()
          }
        }
      );
      
      print(`✅ ${emp.first_name} ${emp.last_name}: AED ${rate}/day`);
    });
  }
  
} catch (error) {
  print("❌ Error creating sample rates:", error.message);
}

// Final verification
print("\n🔍 Final Verification...");

try {
  const stats = {
    totalUsers: db.users.countDocuments(),
    usersWithPayrollInfo: db.users.countDocuments({ "payroll_info": { $exists: true } }),
    payrollEligible: db.users.countDocuments({ "payroll_info.payroll_eligible": true }),
    payrollRates: db.payroll_rates.countDocuments(),
    payrollPermissions: db.permissions.countDocuments({ category: "PAYROLL_MANAGEMENT" }),
    usersWithPayrollPerms: db.users.countDocuments({ "permissions.permission_id": "payroll_view" })
  };
  
  print("📊 Setup Statistics:");
  print(`   Total users: ${stats.totalUsers}`);
  print(`   Users with payroll_info: ${stats.usersWithPayrollInfo}`);
  print(`   Payroll eligible users: ${stats.payrollEligible}`);
  print(`   Payroll rate records: ${stats.payrollRates}`);
  print(`   Payroll permissions in system: ${stats.payrollPermissions}`);
  print(`   Users with payroll permissions: ${stats.usersWithPayrollPerms}`);
  
  // Show sample data
  const sampleUser = db.users.findOne({ "payroll_info.payroll_eligible": true });
  if (sampleUser) {
    print("\n📋 Sample Employee:");
    print(`   Name: ${sampleUser.first_name} ${sampleUser.last_name}`);
    print(`   Employee #: ${sampleUser.payroll_info.employee_number}`);
    print(`   Daily Rate: AED ${sampleUser.payroll_info.current_daily_rate}`);
    print(`   Role: ${sampleUser.role_name}`);
  }
  
} catch (error) {
  print("❌ Error in verification:", error.message);
}

print("\n🎉 Manual Payroll Fix Complete!");
print("\n📋 Test Commands:");
print("   db.users.findOne({'payroll_info.payroll_eligible': true})");
print("   db.payroll_rates.find()");
print("   db.users.find({'permissions.permission_id': 'payroll_view'}).count()");