// Browser console debug script for attendance page
// Run this in the browser console while on the attendance page

console.log('=== BROWSER ATTENDANCE DEBUG ===');

// Function to test the API call directly in browser
async function debugTimesheetsAPI() {
  const baseURL = window.location.origin.replace(':3001', ':3000'); // Frontend to backend port
  
  try {
    console.log('Testing API endpoint:', `${baseURL}/api/payroll/timesheets`);
    
    // Get the auth token if available
    const token = localStorage.getItem('authToken');
    console.log('Auth token available:', !!token);
    
    const headers = {
      'Content-Type': 'application/json',
    };
    
    if (token) {
      headers.Authorization = `Bearer ${token}`;
    }
    
    const response = await fetch(`${baseURL}/api/payroll/timesheets`, {
      method: 'GET',
      headers: headers
    });

    console.log('Response status:', response.status);
    console.log('Response headers:', [...response.headers.entries()]);

    const responseText = await response.text();
    console.log('Raw response:', responseText);

    try {
      const jsonData = JSON.parse(responseText);
      console.log('Parsed response:', jsonData);
      
      // Check structure
      if (jsonData.message) {
        console.log('✅ Message:', jsonData.message);
      }
      
      if (jsonData.timesheets) {
        console.log('✅ Timesheets found:', jsonData.timesheets.length, 'items');
        if (jsonData.timesheets.length > 0) {
          console.log('First timesheet sample:', jsonData.timesheets[0]);
        }
      } else {
        console.log('❌ No timesheets property found');
        console.log('Available properties:', Object.keys(jsonData));
      }
      
    } catch (parseError) {
      console.error('❌ JSON parse error:', parseError);
    }

  } catch (error) {
    console.error('❌ Network error:', error);
  }
}

// Function to check current frontend state
function checkFrontendState() {
  console.log('\n=== FRONTEND STATE CHECK ===');
  
  // Check if we're on the right page
  console.log('Current URL:', window.location.href);
  
  // Check for React state (if accessible)
  const reactRoot = document.querySelector('#__next, [data-reactroot]');
  if (reactRoot) {
    console.log('✅ React app detected');
  }
  
  // Check for error messages in DOM
  const errorElements = document.querySelectorAll('[class*="error"], [class*="Error"]');
  if (errorElements.length > 0) {
    console.log('⚠️ Found error elements:', errorElements.length);
    errorElements.forEach((el, index) => {
      console.log(`Error ${index + 1}:`, el.textContent);
    });
  }
  
  // Check for loading indicators
  const loadingElements = document.querySelectorAll('[class*="loading"], [class*="Loading"], [class*="spinner"]');
  console.log('Loading elements found:', loadingElements.length);
  
  // Check for timesheet table
  const timesheetTable = document.querySelector('table');
  if (timesheetTable) {
    const rows = timesheetTable.querySelectorAll('tbody tr');
    console.log('✅ Table found with', rows.length, 'data rows');
  } else {
    console.log('❌ No table found on page');
  }
  
  // Check for empty state
  const emptyState = document.querySelector('[class*="empty"], [class*="Empty"]');
  if (emptyState) {
    console.log('⚠️ Empty state detected:', emptyState.textContent);
  }
}

// Function to monitor API calls
function monitorAPIRequests() {
  console.log('\n=== MONITORING API CALLS ===');
  
  // Override fetch to log all requests
  const originalFetch = window.fetch;
  window.fetch = function(...args) {
    const url = args[0];
    const options = args[1] || {};
    
    if (url.includes('/api/payroll/')) {
      console.log('🌐 API Request:', {
        url: url,
        method: options.method || 'GET',
        headers: options.headers,
        body: options.body
      });
    }
    
    return originalFetch.apply(this, args).then(response => {
      if (url.includes('/api/payroll/')) {
        console.log('📨 API Response:', {
          url: url,
          status: response.status,
          statusText: response.statusText,
          headers: [...response.headers.entries()]
        });
        
        // Clone response to read body without consuming it
        const clonedResponse = response.clone();
        clonedResponse.text().then(text => {
          console.log('📄 Response body:', text);
        }).catch(err => {
          console.log('❌ Could not read response body:', err);
        });
      }
      
      return response;
    });
  };
  
  console.log('✅ API monitoring enabled. Refresh the page to see API calls.');
}

// Run all debug functions
console.log('Run these functions in the console:');
console.log('1. debugTimesheetsAPI() - Test the API directly');
console.log('2. checkFrontendState() - Check current page state');
console.log('3. monitorAPIRequests() - Monitor all API calls (then refresh page)');

// Auto-run some checks
checkFrontendState();