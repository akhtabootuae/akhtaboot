// Fix for WorkOrder.js model to include 'paused' status

// In /Users/bashir/Documents/GitHub/new_api/models/WorkOrder.js
// Line 940, update the validStatuses array to include 'paused':

// FROM:
// const validStatuses = ['pending', 'in_progress', 'completed'];

// TO:
// const validStatuses = ['pending', 'in_progress', 'completed', 'paused'];

// This should be done in the updateStageStatus method around line 940

console.log(`
INSTRUCTIONS TO FIX THE API:

1. Open /Users/bashir/Documents/GitHub/new_api/models/WorkOrder.js

2. Find the updateStageStatus method (around line 936)

3. Change line 940 from:
   const validStatuses = ['pending', 'in_progress', 'completed'];
   
   To:
   const validStatuses = ['pending', 'in_progress', 'completed', 'paused'];

4. Also check the schema definition at the top of the file (around line 101) and ensure 
   the stage status enum includes 'paused'

5. Save the file and restart your API server

This will fix the validation error when trying to pause a stage.
`);