// MongoDB script to create and initialize the notifications collection
// Run this script in MongoDB shell: mongo < initialize_notifications_collection.js

// Switch to your database (update the database name if needed)
// use your_database_name;

print("Creating notifications collection with schema validation...");

// Drop the collection if it exists (comment out if you want to preserve existing data)
// db.notifications.drop();

// Create notifications collection with schema validation
db.createCollection("notifications", {
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["type", "title", "message", "priority", "status", "createdAt"],
      properties: {
        type: {
          enum: ["time_alert", "deadline_warning", "status_change", "assignment", "general"],
          description: "Type of notification"
        },
        title: {
          bsonType: "string",
          description: "Notification title"
        },
        message: {
          bsonType: "string",
          description: "Notification message content"
        },
        workOrderId: {
          bsonType: ["string", "null"],
          description: "Related work order ID"
        },
        stageId: {
          bsonType: ["string", "null"],
          description: "Related stage ID"
        },
        recipientType: {
          enum: ["supervisor", "technician", "owner", "admin", "all", null],
          description: "Type of recipient"
        },
        recipientId: {
          bsonType: ["objectId", "null"],
          description: "Specific recipient user ID"
        },
        priority: {
          enum: ["low", "medium", "high", "urgent"],
          description: "Notification priority level"
        },
        status: {
          enum: ["unread", "read", "archived"],
          description: "Notification status"
        },
        percentComplete: {
          bsonType: ["number", "null"],
          minimum: 0,
          maximum: 100,
          description: "Progress percentage for time alerts"
        },
        metadata: {
          bsonType: ["object", "null"],
          description: "Additional notification metadata"
        },
        createdAt: {
          bsonType: "date",
          description: "When the notification was created"
        },
        readAt: {
          bsonType: ["date", "null"],
          description: "When the notification was read"
        },
        expiresAt: {
          bsonType: ["date", "null"],
          description: "When the notification expires"
        }
      }
    }
  }
});

print("Creating indexes for notifications collection...");

// Create indexes for better query performance
db.notifications.createIndex({ recipientType: 1, recipientId: 1, status: 1 });
db.notifications.createIndex({ workOrderId: 1 });
db.notifications.createIndex({ createdAt: -1 });
db.notifications.createIndex({ status: 1, priority: 1 });
db.notifications.createIndex({ expiresAt: 1 }, { expireAfterSeconds: 0 }); // TTL index for auto-deletion

// Create compound index for filtering
db.notifications.createIndex({ 
  recipientType: 1, 
  status: 1, 
  type: 1, 
  priority: 1, 
  createdAt: -1 
});

print("Notifications collection created successfully!");

// Insert sample notifications for testing (optional - comment out in production)
print("Inserting sample notifications...");

db.notifications.insertMany([
  {
    type: "deadline_warning",
    title: "Work Order Deadline Approaching",
    message: "Work order WO-2024-001 is due in 2 hours",
    workOrderId: "WO-2024-001",
    recipientType: "technician",
    priority: "high",
    status: "unread",
    createdAt: new Date(),
    expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // 30 days
  },
  {
    type: "assignment",
    title: "New Work Order Assigned",
    message: "You have been assigned to work order WO-2024-002",
    workOrderId: "WO-2024-002",
    recipientType: "technician",
    priority: "medium",
    status: "unread",
    createdAt: new Date(),
    expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
  },
  {
    type: "general",
    title: "System Maintenance",
    message: "The system will be under maintenance tonight from 11 PM to 1 AM",
    recipientType: "all",
    priority: "low",
    status: "unread",
    createdAt: new Date(),
    expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 days
  }
]);

print("Sample notifications inserted!");

// Verify the collection was created
var collections = db.getCollectionNames();
if (collections.indexOf("notifications") > -1) {
  print("✓ Notifications collection exists");
  print("✓ Total documents: " + db.notifications.countDocuments());
  print("✓ Indexes created: ");
  db.notifications.getIndexes().forEach(function(index) {
    print("  - " + JSON.stringify(index.key));
  });
} else {
  print("✗ Failed to create notifications collection");
}

print("\nNotifications collection initialization complete!");
print("\nTo run this script:");
print("1. Save this file as initialize_notifications_collection.js");
print("2. Run: mongo your_database_name < initialize_notifications_collection.js");
print("   OR");
print("   mongo your_database_name --eval \"load('initialize_notifications_collection.js')\"");
print("\nRemember to:");
print("1. Update the work order model to include 'paused' status (see fix_workorder_model.js)");
print("2. Create API endpoints for notifications in your backend");
print("3. Initialize the notifications collection in your API's database initialization");