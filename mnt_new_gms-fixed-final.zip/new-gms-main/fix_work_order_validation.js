// MongoDB Script to Fix Work Order Validation Schema

// Connect to your database and run this script

db.runCommand({
  collMod: "work_orders",
  validator: {
    $jsonSchema: {
      bsonType: 'object',
      required: [
        'workOrderNumber',
        'customer_id',
        'vehicle_id',
        'status',
        'createdAt',
        'parts'
      ],
      properties: {
        workOrderNumber: {
          bsonType: 'string',
          description: 'Unique identifier for this work order'
        },
        customer_id: {
          bsonType: 'objectId',
          description: 'Reference to a customer document'
        },
        vehicle_id: {
          bsonType: 'int',
          description: 'ID of the vehicle in customer\'s vehicles array'
        },
        status: {
          'enum': [
            'open',
            'in_progress',
            'on_hold',
            'completed',
            'closed'
          ],
          description: 'Overall status of the work order'
        },
        description: {
          bsonType: 'string',
          description: 'detailed description of the work to be performed'
        },
        createdAt: {
          bsonType: 'date',
          description: 'Work order creation timestamp'
        },
        updatedAt: {
          bsonType: 'date',
          description: 'Last update timestamp'
        },
        parts: {
          bsonType: 'array',
          minItems: 1,
          description: 'Sub-workorders split by vehicle part',
          items: {
            bsonType: 'object',
            required: [
              'partName',
              'variationId',
              'status',
              'stages',
              'createdAt'
            ],
            properties: {
              partName: {
                bsonType: 'string',
                description: 'e.g. \'left door\', \'engine\''
              },
              variationId: {
                bsonType: 'objectId',
                description: 'Refers to a document in `variations`'
              },
              status: {
                'enum': [
                  'pending',
                  'in_progress',
                  'completed',
                  'cancelled'
                ],
                description: 'Status of this part\'s overall work'
              },
              assignedTo: {
                bsonType: 'objectId',
                description: 'Technician _id'
              },
              createdAt: {
                bsonType: 'date',
                description: 'Timestamp when this part was added'
              },
              updatedAt: {
                bsonType: 'date',
                description: 'Timestamp of last change to this part'
              },
              cancellationReason: {
                bsonType: 'string',
                description: 'Reason for cancellation if cancelled'
              },
              approvalImage: {
                bsonType: 'string',
                description: 'Image URL for cancellation approval'
              },
              stages: {
                bsonType: 'array',
                minItems: 1,
                description: 'Workflow stages for this part',
                items: {
                  bsonType: 'object',
                  required: [
                    'stageId',
                    'status',
                    'logs',
                    'createdAt'
                  ],
                  properties: {
                    stageId: {
                      bsonType: 'objectId',
                      description: 'Refers to a document in `stages`'
                    },
                    status: {
                      'enum': [
                        'pending',
                        'in_progress',
                        'completed',
                        'paused'
                      ],
                      description: 'Status of this stage'
                    },
                    assignedTo: {
                      bsonType: 'objectId',
                      description: 'Technician _id for this stage'
                    },
                    createdAt: {
                      bsonType: 'date',
                      description: 'Stage start timestamp'
                    },
                    updatedAt: {
                      bsonType: 'date',
                      description: 'Stage last update timestamp'
                    },
                    // NEW FIELDS FOR ERROR REPORTING
                    hasIssue: {
                      bsonType: 'bool',
                      description: 'Flag indicating if this stage has reported issues'
                    },
                    errorReportIds: {
                      bsonType: 'array',
                      items: {
                        bsonType: 'objectId'
                      },
                      description: 'Array of error report IDs associated with this stage'
                    },
                    needsRedo: {
                      bsonType: 'bool',
                      description: 'Flag indicating if stage needs to be redone'
                    },
                    originalCompletionTime: {
                      bsonType: ['date', 'null'],
                      description: 'Original completion time before revert'
                    },
                    estimatedHours: {
                      bsonType: 'number',
                      description: 'Estimated hours for this stage'
                    },
                    actualHours: {
                      bsonType: 'number',
                      description: 'Actual hours spent on this stage'
                    },
                    logs: {
                      bsonType: 'array',
                      description: 'Time-log entries for this stage',
                      items: {
                        bsonType: 'object',
                        required: [
                          'timestamp',
                          'action'
                        ],
                        properties: {
                          timestamp: {
                            bsonType: 'date',
                            description: 'When the action occurred'
                          },
                          action: {
                            'enum': [
                              'start',
                              'pause',
                              'resume',
                              'complete'
                            ],
                            description: 'Type of time-log event'
                          },
                          note: {
                            bsonType: 'string',
                            description: 'Optional comment'
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        },
        // Add any other top-level fields that might exist
        cancelledParts: {
          bsonType: 'array',
          items: {
            bsonType: 'object',
            properties: {
              partName: {
                bsonType: 'string'
              },
              cancelledAt: {
                bsonType: 'date'
              },
              reason: {
                bsonType: 'string'
              },
              approvalImage: {
                bsonType: 'string'
              }
            }
          }
        }
      }
    }
  }
});

print("Work order validation schema updated successfully!");

// Now update all existing documents to add the new fields with default values
db.work_orders.updateMany(
  { "parts.stages": { $exists: true } },
  {
    $set: {
      "parts.$[].stages.$[stage].hasIssue": false,
      "parts.$[].stages.$[stage].errorReportIds": [],
      "parts.$[].stages.$[stage].needsRedo": false
    }
  },
  {
    arrayFilters: [
      { "stage": { $exists: true } }
    ]
  }
);

print("Added error reporting fields to existing stages");

// Verify the update
var sampleWorkOrder = db.work_orders.findOne();
if (sampleWorkOrder && sampleWorkOrder.parts && sampleWorkOrder.parts[0] && sampleWorkOrder.parts[0].stages) {
  print("Sample stage after update:");
  printjson(sampleWorkOrder.parts[0].stages[0]);
}

print("✅ Work order validation schema has been fixed!");