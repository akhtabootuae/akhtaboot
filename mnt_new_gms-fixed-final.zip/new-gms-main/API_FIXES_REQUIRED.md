# API Fixes Required for Work Order Stage Management

## Issue: MongoDB Document Validation Failures

### Problem 1: Stage Status Validation
**File**: `/Users/bashir/Documents/GitHub/new_api/models/WorkOrder.js`
**Line**: ~940

The `updateStageStatus` method doesn't include "paused" as a valid status, but the MongoDB schema does.

**Fix**:
```javascript
// Line 940 - Change from:
const validStatuses = ['pending', 'in_progress', 'completed'];

// To:
const validStatuses = ['pending', 'in_progress', 'completed', 'paused'];
```

### Problem 2: Timestamp Handling in Logs
The API backend (WorkOrder.js `addLogEntry` method) handles the timestamp correctly by adding it server-side if not provided. Our frontend was sending timestamps as ISO strings which were causing validation errors.

**Already Fixed**: We removed the timestamp from frontend API calls and let the backend handle it.

## Summary of Changes Made

### Frontend Changes:
1. **SubWorkOrderDetail.tsx**:
   - Loads existing stage state from work order on mount
   - Persists all stage changes to database via API
   - Tracks paused duration and excludes it from working time
   - Removed timestamp from log API calls (let backend handle it)

2. **API Service (api.ts)**:
   - Added `updateStage`, `updateStageStatus`, and `addStageLog` functions

3. **Time Components**:
   - Added `pausedDuration` prop to properly track paused time
   - Fixed elapsed time and countdown calculations

4. **Part Selection**:
   - Fixed part matching to use part names instead of IDs

## What You Need to Do:

1. **Update the API Model**:
   ```bash
   cd /Users/bashir/Documents/GitHub/new_api
   # Edit models/WorkOrder.js line 940 to add 'paused' to validStatuses
   ```

2. **Restart the API Server**:
   ```bash
   # After making the change, restart your API server
   npm run dev  # or however you start your API
   ```

3. **Test the System**:
   - Start a stage - should persist to DB
   - Pause the stage - should work now
   - Resume the stage - should work
   - Complete the stage - should calculate actual hours
   - Leave and come back - should restore state

## MongoDB Schema Reference:
The work_orders collection schema already includes "paused" as a valid status:
```javascript
status: {
  'enum': [
    'pending',
    'in_progress',
    'completed',
    'paused'  // This is in the schema
  ],
  description: 'Status of this stage'
}
```

The API model just needs to be updated to match this schema.