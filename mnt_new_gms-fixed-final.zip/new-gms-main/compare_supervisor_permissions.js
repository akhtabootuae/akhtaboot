/**
 * Compare permissions between working and non-working supervisors
 */

const { MongoClient } = require('mongodb');

// Database configuration
const MONGO_URI = 'mongodb+srv://root:sSZba4as0uM25d0x@gmsdb.ilit0p8.mongodb.net/?retryWrites=true&w=majority&appName=gmsDB';
const DATABASE_NAME = 'GMS_DB';

async function comparePermissions() {
  const client = new MongoClient(MONGO_URI);
  
  try {
    await client.connect();
    console.log('Connected to MongoDB');
    
    const db = client.db(DATABASE_NAME);
    
    // Get both supervisors
    const aliUser = await db.collection('users').findOne({
      email: "ali@akhtaboot.com"
    });
    
    const bashirUser = await db.collection('users').findOne({
      email: "bok@rit.edu"
    });
    
    if (!aliUser || !bashirUser) {
      console.log('❌ Could not find both users');
      return;
    }
    
    console.log(`\n👤 Ali Qadri (NOT WORKING): ${aliUser.permissions?.length || 0} permissions`);
    console.log(`👤 Bashir Khadra (WORKING): ${bashirUser.permissions?.length || 0} permissions`);
    
    // Create permission maps for easy comparison
    const aliPerms = {};
    const bashirPerms = {};
    
    aliUser.permissions?.forEach(p => {
      aliPerms[p.permission_name] = p.granted;
    });
    
    bashirUser.permissions?.forEach(p => {
      bashirPerms[p.permission_name] = p.granted;
    });
    
    // Find permissions that Bashir has but Ali doesn't
    console.log('\n🔍 PERMISSIONS BASHIR HAS BUT ALI DOESN\'T:');
    let foundDifferences = false;
    
    for (const perm in bashirPerms) {
      if (!(perm in aliPerms)) {
        console.log(`✅ ${perm}: ${bashirPerms[perm]}`);
        foundDifferences = true;
      }
    }
    
    // Find permissions that Ali has but Bashir doesn't
    console.log('\n🔍 PERMISSIONS ALI HAS BUT BASHIR DOESN\'T:');
    for (const perm in aliPerms) {
      if (!(perm in bashirPerms)) {
        console.log(`❌ ${perm}: ${aliPerms[perm]}`);
        foundDifferences = true;
      }
    }
    
    // Find permissions with different granted status
    console.log('\n🔍 PERMISSIONS WITH DIFFERENT STATUS:');
    for (const perm in aliPerms) {
      if (perm in bashirPerms && aliPerms[perm] !== bashirPerms[perm]) {
        console.log(`🔄 ${perm}:`);
        console.log(`   Ali: ${aliPerms[perm]}`);
        console.log(`   Bashir: ${bashirPerms[perm]}`);
        foundDifferences = true;
      }
    }
    
    if (!foundDifferences) {
      console.log('❗ NO PERMISSION DIFFERENCES FOUND!');
      console.log('The issue might be something else entirely...');
    }
    
    // Check specific registration permissions
    console.log('\n🎯 SPECIFIC REGISTRATION PERMISSION CHECK:');
    const regPerms = ['create_customer', 'create_work_order', 'create_invoice', 'manage_vehicles', 'manage_invoice_images'];
    
    regPerms.forEach(perm => {
      const aliHas = aliPerms[perm];
      const bashirHas = bashirPerms[perm];
      
      console.log(`${perm}:`);
      console.log(`  Ali: ${aliHas === true ? '✅' : aliHas === false ? '❌' : '❓'} ${aliHas}`);
      console.log(`  Bashir: ${bashirHas === true ? '✅' : bashirHas === false ? '❌' : '❓'} ${bashirHas}`);
    });
    
    // Check user creation dates
    console.log('\n📅 USER CREATION DATES:');
    console.log(`Ali created: ${aliUser.created_at}`);
    console.log(`Bashir created: ${bashirUser.created_at}`);
    console.log(`Ali updated: ${aliUser.updated_at}`);
    console.log(`Bashir updated: ${bashirUser.updated_at}`);
    
  } catch (error) {
    console.error('❌ Error comparing permissions:', error);
    throw error;
  } finally {
    await client.close();
    console.log('\nDatabase connection closed');
  }
}

// Run the script
if (require.main === module) {
  comparePermissions()
    .then(() => {
      console.log('\n🎯 Comparison completed!');
      process.exit(0);
    })
    .catch((error) => {
      console.error('Comparison failed:', error);
      process.exit(1);
    });
}

module.exports = { comparePermissions };