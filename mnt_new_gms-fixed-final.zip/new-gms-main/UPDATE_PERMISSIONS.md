# Backend Updates Required for Payroll System

Your backend team needs to make the following updates to support the payroll system:

## 1. Update Permissions File

Add the following to `/Users/bashir/Documents/GitHub/new_api/config/permissions.js`:

### Add to PERMISSIONS object (after SYSTEM_ADMINISTRATION):
```javascript
// Payroll Management  
PAYROLL_MANAGEMENT: [
  { id: "payroll_view", name: "payroll_view", description: "Can view payroll data and reports" },
  { id: "payroll_manage_rates", name: "payroll_manage_rates", description: "Can modify employee daily rates" },
  { id: "payroll_manage_deductions", name: "payroll_manage_deductions", description: "Can create and modify payroll deductions" },
  { id: "payroll_process", name: "payroll_process", description: "Can process payroll runs and generate paystubs" },
  { id: "payroll_attendance", name: "payroll_attendance", description: "Can mark and modify employee attendance" }
]
```

### Update role permissions in getDefaultPermissionsForRole function:

**For Admin role** - add to the existing permissions (they get all):
```javascript
// Already gets all permissions automatically
```

**For Supervisor role** - add to supervisorPermissions array:
```javascript
// Payroll Management (partial - no processing)
'payroll_view', 'payroll_manage_rates', 'payroll_manage_deductions', 'payroll_attendance'
```

**For Technician role** - no payroll permissions needed

## 2. Update Database Seeder

Add the following to `/Users/bashir/Documents/GitHub/new_api/config/dbSeeder.js`:

### Add new function after updateWorkOrdersValidation:
```javascript
/**
 * Seeds payroll system collections and updates user schema
 * @param {Object} db MongoDB database connection
 */
async function seedPayrollSystem(db) {
  try {
    console.log('Setting up payroll system...');
    
    // 1. Create payroll_rates collection
    const ratesExists = await db.listCollections({ name: 'payroll_rates' }).toArray();
    if (ratesExists.length === 0) {
      console.log('Creating payroll_rates collection...');
      await db.createCollection("payroll_rates", {
        validator: {
          $jsonSchema: {
            bsonType: "object",
            required: ["employee_id", "daily_rate", "rate_type", "effective_date", "created_by", "created_at"],
            properties: {
              employee_id: {
                bsonType: "objectId",
                description: "Reference to users collection - required"
              },
              daily_rate: {
                bsonType: "number",
                minimum: 0,
                description: "Daily rate amount - required and must be positive"
              },
              rate_type: {
                bsonType: "string",
                enum: ["regular", "holiday", "premium"],
                description: "Type of rate - required"
              },
              effective_date: {
                bsonType: "date",
                description: "When this rate becomes active - required"
              },
              end_date: {
                bsonType: ["date", "null"],
                description: "When rate ends (null for current rate)"
              },
              created_by: {
                bsonType: "objectId",
                description: "Admin who set the rate - required"
              },
              created_at: {
                bsonType: "date",
                description: "When record was created - required"
              },
              notes: {
                bsonType: "string",
                description: "Reason for rate change"
              }
            }
          }
        }
      });
      
      // Create indexes
      await db.collection('payroll_rates').createIndex({ "employee_id": 1 });
      await db.collection('payroll_rates').createIndex({ "employee_id": 1, "effective_date": -1 });
      await db.collection('payroll_rates').createIndex({ "end_date": 1 });
      
      console.log('Payroll rates collection created successfully');
    }
    
    // 2. Create payroll_audit_log collection
    const auditExists = await db.listCollections({ name: 'payroll_audit_log' }).toArray();
    if (auditExists.length === 0) {
      console.log('Creating payroll_audit_log collection...');
      await db.createCollection("payroll_audit_log", {
        validator: {
          $jsonSchema: {
            bsonType: "object",
            required: ["log_id", "action", "entity_type", "entity_id", "user_id", "timestamp"],
            properties: {
              log_id: {
                bsonType: "string",
                description: "Unique log identifier - required"
              },
              action: {
                bsonType: "string",
                enum: ["rate_change", "deduction_add", "deduction_modify", "attendance_mark", "payroll_run"],
                description: "Type of action - required"
              },
              entity_type: {
                bsonType: "string",
                enum: ["employee", "deduction", "payroll_run"],
                description: "Type of entity affected - required"
              },
              entity_id: {
                bsonType: "objectId",
                description: "ID of affected entity - required"
              },
              user_id: {
                bsonType: "objectId",
                description: "User who made the change - required"
              },
              old_data: {
                bsonType: "object",
                description: "Previous state of data"
              },
              new_data: {
                bsonType: "object",
                description: "New state of data"
              },
              timestamp: {
                bsonType: "date",
                description: "When change occurred - required"
              },
              ip_address: {
                bsonType: "string",
                description: "IP address of user making change"
              },
              notes: {
                bsonType: "string",
                description: "Additional notes about the change"
              }
            }
          }
        }
      });
      
      // Create indexes
      await db.collection('payroll_audit_log').createIndex({ "entity_id": 1 });
      await db.collection('payroll_audit_log').createIndex({ "user_id": 1 });
      await db.collection('payroll_audit_log').createIndex({ "timestamp": -1 });
      
      console.log('Payroll audit log collection created successfully');
    }
    
    // 3. Add payroll permissions to permissions collection
    console.log('Adding payroll permissions...');
    const payrollPermissions = [
      {
        permission_id: "payroll_view",
        permission_name: "View Payroll",
        permission_description: "Can view payroll data and reports",
        category: "PAYROLL_MANAGEMENT"
      },
      {
        permission_id: "payroll_manage_rates",
        permission_name: "Manage Employee Rates",
        permission_description: "Can modify employee daily rates",
        category: "PAYROLL_MANAGEMENT"
      },
      {
        permission_id: "payroll_manage_deductions",
        permission_name: "Manage Deductions",
        permission_description: "Can create and modify payroll deductions",
        category: "PAYROLL_MANAGEMENT"
      },
      {
        permission_id: "payroll_process",
        permission_name: "Process Payroll",
        permission_description: "Can process payroll runs and generate paystubs",
        category: "PAYROLL_MANAGEMENT"
      },
      {
        permission_id: "payroll_attendance",
        permission_name: "Manage Attendance",
        permission_description: "Can mark and modify employee attendance",
        category: "PAYROLL_MANAGEMENT"
      }
    ];
    
    for (const permission of payrollPermissions) {
      const existing = await db.collection('permissions').findOne({ permission_id: permission.permission_id });
      if (!existing) {
        await db.collection('permissions').insertOne({
          ...permission,
          created_at: new Date(),
          updated_at: new Date()
        });
        console.log(`Added permission: ${permission.permission_name}`);
      }
    }
    
    // 4. Update users schema to support payroll_info (temporarily disable validation)
    console.log('Updating users schema for payroll_info...');
    
    // Temporarily disable validation
    await db.runCommand({ collMod: "users", validator: {} });
    
    // Add payroll_info to users who don't have it
    const usersUpdateResult = await db.collection('users').updateMany(
      { "payroll_info": { $exists: false } },
      {
        $set: {
          "payroll_info": {
            current_daily_rate: 0,
            employee_number: "",
            hire_date: null,
            payroll_eligible: true,
            last_pay_date: null
          },
          "updated_at": new Date()
        }
      }
    );
    
    console.log(`Added payroll_info to ${usersUpdateResult.modifiedCount} users`);
    
    // Set admins as not payroll eligible
    await db.collection('users').updateMany(
      { "role_name": "Admin" },
      { $set: { "payroll_info.payroll_eligible": false } }
    );
    
    // Re-enable validation with payroll_info support
    await db.runCommand({
      collMod: "users",
      validator: {
        $jsonSchema: {
          bsonType: 'object',
          required: [
            'first_name', 'last_name', 'email', 'password_hash',
            'role_id', 'role_name', 'created_at', 'updated_at'
          ],
          properties: {
            first_name: { bsonType: 'string' },
            last_name: { bsonType: 'string' },
            email: { bsonType: 'string' },
            phone: { bsonType: 'string' },
            password_hash: { bsonType: 'string' },
            is_active: { bsonType: 'bool' },
            staff_code: { bsonType: 'string' },
            speciality: { bsonType: 'string' },
            branch: {
              bsonType: 'object',
              required: ['branch_id', 'branch_name'],
              properties: {
                branch_id: { bsonType: 'objectId' },
                branch_name: { bsonType: 'string' },
                branch_code: { bsonType: 'string' },
                location: { bsonType: 'string' }
              }
            },
            role_id: { bsonType: 'objectId' },
            role_name: { bsonType: 'string' },
            role_description: { bsonType: 'string' },
            permissions: {
              bsonType: 'array',
              items: {
                bsonType: 'object',
                required: ['permission_id', 'permission_name', 'granted'],
                properties: {
                  permission_id: { bsonType: 'string' },
                  permission_name: { bsonType: 'string' },
                  permission_description: { bsonType: 'string' },
                  category: { bsonType: 'string' },
                  granted: { bsonType: 'bool' }
                }
              }
            },
            permission_logs: { bsonType: 'array' },
            // ADD PAYROLL_INFO FIELD
            payroll_info: {
              bsonType: 'object',
              properties: {
                current_daily_rate: { bsonType: 'number', minimum: 0 },
                employee_number: { bsonType: 'string' },
                hire_date: { bsonType: ['date', 'null'] },
                payroll_eligible: { bsonType: 'bool' },
                last_pay_date: { bsonType: ['date', 'null'] }
              }
            },
            created_at: { bsonType: 'date' },
            updated_at: { bsonType: 'date' }
          }
        }
      }
    });
    
    // 5. Add payroll permissions to existing admin and supervisor users
    console.log('Granting payroll permissions to existing users...');
    
    // Add to admins (all permissions)
    const adminUsers = await db.collection('users').find({ role_name: "Admin" }).toArray();
    for (const admin of adminUsers) {
      for (const permission of payrollPermissions) {
        const hasPermission = admin.permissions?.some(p => p.permission_id === permission.permission_id);
        if (!hasPermission) {
          await db.collection('users').updateOne(
            { _id: admin._id },
            {
              $push: {
                permissions: {
                  permission_id: permission.permission_id,
                  permission_name: permission.permission_name,
                  permission_description: permission.permission_description,
                  category: permission.category,
                  granted: true
                }
              }
            }
          );
        }
      }
    }
    
    // Add to supervisors (excluding payroll_process)
    const supervisorUsers = await db.collection('users').find({ role_name: "Supervisor" }).toArray();
    const supervisorPermissions = payrollPermissions.filter(p => p.permission_id !== "payroll_process");
    
    for (const supervisor of supervisorUsers) {
      for (const permission of supervisorPermissions) {
        const hasPermission = supervisor.permissions?.some(p => p.permission_id === permission.permission_id);
        if (!hasPermission) {
          await db.collection('users').updateOne(
            { _id: supervisor._id },
            {
              $push: {
                permissions: {
                  permission_id: permission.permission_id,
                  permission_name: permission.permission_name,
                  permission_description: permission.permission_description,
                  category: permission.category,
                  granted: true
                }
              }
            }
          );
        }
      }
    }
    
    // 6. Create employee numbers and sample rates
    console.log('Creating employee numbers and sample rates...');
    
    const payrollEligibleUsers = await db.collection('users').find({ 
      "payroll_info.payroll_eligible": true,
      "payroll_info.employee_number": ""
    }).toArray();
    
    const adminUser = await db.collection('users').findOne({ role_name: "Admin" });
    
    for (let i = 0; i < payrollEligibleUsers.length; i++) {
      const user = payrollEligibleUsers[i];
      const employeeNumber = `EMP${String(i + 1).padStart(3, '0')}`;
      const dailyRate = 150 + (i * 25); // AED 150, 175, 200, etc.
      
      // Update employee number
      await db.collection('users').updateOne(
        { _id: user._id },
        {
          $set: {
            "payroll_info.employee_number": employeeNumber,
            "payroll_info.hire_date": new Date(),
            "payroll_info.current_daily_rate": dailyRate
          }
        }
      );
      
      // Create initial rate record
      if (adminUser) {
        await db.collection('payroll_rates').insertOne({
          employee_id: user._id,
          daily_rate: dailyRate,
          rate_type: "regular",
          effective_date: new Date(),
          end_date: null,
          created_by: adminUser._id,
          created_at: new Date(),
          notes: "Initial rate setup during payroll system seeding"
        });
      }
      
      console.log(`Set up payroll for ${user.first_name} ${user.last_name}: ${employeeNumber} - AED ${dailyRate}/day`);
    }
    
    console.log('Payroll system setup completed successfully!');
    
  } catch (error) {
    console.error('Error setting up payroll system:', error);
    // Don't fail the entire seeding process
  }
}
```

### Add the function call to seedDatabase:
```javascript
async function seedDatabase(db) {
  try {
    // ... existing seed calls ...
    await seedNotifications(db);
    await updateWorkOrdersValidation(db);
    await seedPayrollSystem(db); // ADD THIS LINE
  } catch (error) {
    console.error('Error seeding database:', error);
    throw error;
  }
}
```

## 3. Run the Updated Seeder

After making these changes, run the seeder to set up payroll for new installations:

```bash
# In your backend directory
npm run seed
# or
node scripts/seedDatabase.js
```

## Summary

These updates will ensure that:
- ✅ New installations automatically include the complete payroll system
- ✅ Proper permissions are set up for all user roles
- ✅ Database schema supports payroll data
- ✅ Sample payroll data is created for testing
- ✅ Existing users are properly migrated to support payroll

The payroll system will be included in all future database setups!