'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/app/context/AuthContext';

export default function ProtectedRoute({ 
  children,
  adminOnly = false, 
}: { 
  children: React.ReactNode,
  adminOnly?: boolean,
}) {
  const { isAuthenticated, user, isLoading } = useAuth();
  const router = useRouter();

  // Helper function for case-insensitive admin check
  const isAdmin = user?.role_name?.toLowerCase() === 'admin';
  
  // Add debugging logs
  console.log('ProtectedRoute: adminOnly =', adminOnly);
  console.log('ProtectedRoute: isAuthenticated =', isAuthenticated);
  console.log('ProtectedRoute: isLoading =', isLoading);
  console.log('ProtectedRoute: user =', user);
  console.log('ProtectedRoute: isAdmin =', isAdmin);

  useEffect(() => {
    // Only run this check after the auth state is loaded
    if (!isLoading) {
      console.log('ProtectedRoute effect: Auth loaded');
      
      // If not authenticated, redirect to login
      if (!isAuthenticated) {
        console.log('ProtectedRoute effect: Redirecting to login - not authenticated');
        router.push('/login');
        return;
      }
      
      // If admin-only route but user is not admin
      if (adminOnly && !isAdmin) {
        console.log('ProtectedRoute effect: Redirecting to unauthorized - not admin');
        // Redirect to unauthorized page or dashboard
        router.push('/unauthorized');
      }
    }
  }, [isAuthenticated, user, isLoading, adminOnly, router]);

  // Show loading state
  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  // Re-enable proper admin checking now that case sensitivity is fixed
  if (adminOnly && !isAdmin) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-red-600">Unauthorized Access</h2>
          <p className="text-gray-600 mt-2">You don't have permission to view this page.</p>
        </div>
      </div>
    );
  }

  // If not authenticated, don't render children
  if (!isAuthenticated) {
    return null;
  }

  return <>{children}</>;
}
