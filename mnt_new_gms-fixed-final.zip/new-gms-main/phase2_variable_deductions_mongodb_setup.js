/*
 * Phase 2: Variable Deductions System - MongoDB Setup Script
 * 
 * This script sets up the MongoDB collections and data required for the variable deductions system.
 * Run this script in mongosh connected to your GMS_DB database.
 * 
 * Usage: mongosh mongodb://localhost:27017/GMS_DB phase2_variable_deductions_mongodb_setup.js
 */

// Use the GMS_DB database
use('GMS_DB');

console.log("🚀 Starting Phase 2: Variable Deductions System setup...");

// 1. Create payroll_deduction_types collection
console.log("📋 Creating payroll_deduction_types collection...");

// Drop existing collection if it exists (for clean setup)
try {
  db.payroll_deduction_types.drop();
  console.log("   ✅ Dropped existing payroll_deduction_types collection");
} catch (e) {
  console.log("   ℹ️  No existing payroll_deduction_types collection to drop");
}

// Create the collection with schema validation
db.createCollection("payroll_deduction_types", {
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["name", "type", "created_at"],
      properties: {
        name: {
          bsonType: "string",
          minLength: 1,
          maxLength: 100,
          description: "Name of the deduction type - must be a string between 1-100 characters and is required"
        },
        description: {
          bsonType: "string",
          maxLength: 500,
          description: "Description of the deduction type - optional string up to 500 characters"
        },
        type: {
          bsonType: "string",
          enum: ["fixed_amount", "percentage", "conditional"],
          description: "Type of deduction calculation - must be one of: fixed_amount, percentage, conditional"
        },
        default_amount: {
          bsonType: ["number", "null"],
          minimum: 0,
          description: "Default amount for fixed deductions - must be positive number or null"
        },
        default_percentage: {
          bsonType: ["number", "null"],
          minimum: 0,
          maximum: 100,
          description: "Default percentage for percentage-based deductions - must be 0-100 or null"
        },
        frequency: {
          bsonType: "string",
          enum: ["daily", "weekly", "monthly", "per_pay_period", "one_time"],
          description: "How often this deduction is applied"
        },
        max_percentage_of_pay: {
          bsonType: ["number", "null"],
          minimum: 0,
          maximum: 100,
          description: "Maximum percentage of pay this deduction can take - legal compliance"
        },
        requires_approval: {
          bsonType: "bool",
          description: "Whether this deduction type requires manager approval"
        },
        is_system_type: {
          bsonType: "bool",
          description: "Whether this is a system-defined type (cannot be deleted)"
        },
        active: {
          bsonType: "bool",
          description: "Whether this deduction type is currently active"
        },
        created_at: {
          bsonType: "date",
          description: "When this deduction type was created - required"
        },
        updated_at: {
          bsonType: "date",
          description: "When this deduction type was last updated"
        }
      }
    }
  }
});

console.log("   ✅ Created payroll_deduction_types collection with validation");

// Create indexes for deduction types
db.payroll_deduction_types.createIndex({ "name": 1 }, { unique: true });
db.payroll_deduction_types.createIndex({ "type": 1 });
db.payroll_deduction_types.createIndex({ "active": 1 });
console.log("   ✅ Created indexes for payroll_deduction_types");

// 2. Create payroll_employee_deductions collection
console.log("📋 Creating payroll_employee_deductions collection...");

// Drop existing collection if it exists
try {
  db.payroll_employee_deductions.drop();
  console.log("   ✅ Dropped existing payroll_employee_deductions collection");
} catch (e) {
  console.log("   ℹ️  No existing payroll_employee_deductions collection to drop");
}

// Create the collection with schema validation
db.createCollection("payroll_employee_deductions", {
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["employee_id", "deduction_type_id", "amount", "frequency", "start_date", "status", "created_by", "created_at"],
      properties: {
        employee_id: {
          bsonType: "objectId",
          description: "Reference to the employee (user) - must be valid ObjectId and is required"
        },
        deduction_type_id: {
          bsonType: "objectId",
          description: "Reference to the deduction type - must be valid ObjectId and is required"
        },
        amount: {
          bsonType: "number",
          minimum: 0,
          description: "Deduction amount (fixed amount or percentage) - must be positive and is required"
        },
        frequency: {
          bsonType: "string",
          enum: ["daily", "weekly", "monthly", "per_pay_period", "one_time"],
          description: "How often this deduction is applied - required"
        },
        start_date: {
          bsonType: "date",
          description: "When this deduction starts - required"
        },
        end_date: {
          bsonType: ["date", "null"],
          description: "When this deduction ends - null for ongoing deductions"
        },
        status: {
          bsonType: "string",
          enum: ["active", "paused", "completed", "cancelled"],
          description: "Current status of the deduction - required"
        },
        priority: {
          bsonType: "int",
          minimum: 1,
          maximum: 10,
          description: "Priority order for processing deductions (1 = highest priority)"
        },
        max_total_amount: {
          bsonType: ["number", "null"],
          minimum: 0,
          description: "Maximum total amount to deduct (for loans/advances) - null for ongoing deductions"
        },
        total_deducted: {
          bsonType: "number",
          minimum: 0,
          description: "Total amount deducted so far"
        },
        remaining_balance: {
          bsonType: ["number", "null"],
          minimum: 0,
          description: "Remaining balance for loans/advances - null for ongoing deductions"
        },
        notes: {
          bsonType: "string",
          maxLength: 1000,
          description: "Additional notes about this deduction"
        },
        reference_number: {
          bsonType: "string",
          maxLength: 50,
          description: "External reference number (court order, loan number, etc.)"
        },
        legal_required: {
          bsonType: "bool",
          description: "Whether this is a legally required deduction (garnishment, etc.)"
        },
        created_by: {
          bsonType: "objectId",
          description: "User who created this deduction - required"
        },
        approved_by: {
          bsonType: ["objectId", "null"],
          description: "User who approved this deduction - null if no approval required"
        },
        approved_at: {
          bsonType: ["date", "null"],
          description: "When this deduction was approved"
        },
        created_at: {
          bsonType: "date",
          description: "When this deduction was created - required"
        },
        updated_at: {
          bsonType: "date",
          description: "When this deduction was last updated"
        }
      }
    }
  }
});

console.log("   ✅ Created payroll_employee_deductions collection with validation");

// Create indexes for employee deductions
db.payroll_employee_deductions.createIndex({ "employee_id": 1 });
db.payroll_employee_deductions.createIndex({ "deduction_type_id": 1 });
db.payroll_employee_deductions.createIndex({ "status": 1 });
db.payroll_employee_deductions.createIndex({ "start_date": 1 });
db.payroll_employee_deductions.createIndex({ "end_date": 1 });
db.payroll_employee_deductions.createIndex({ "priority": 1 });
db.payroll_employee_deductions.createIndex({ "employee_id": 1, "status": 1 });
db.payroll_employee_deductions.createIndex({ "employee_id": 1, "priority": 1 });
console.log("   ✅ Created indexes for payroll_employee_deductions");

// 3. Create payroll_deduction_history collection
console.log("📋 Creating payroll_deduction_history collection...");

// Drop existing collection if it exists
try {
  db.payroll_deduction_history.drop();
  console.log("   ✅ Dropped existing payroll_deduction_history collection");
} catch (e) {
  console.log("   ℹ️  No existing payroll_deduction_history collection to drop");
}

// Create the collection with schema validation
db.createCollection("payroll_deduction_history", {
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["employee_deduction_id", "employee_id", "pay_period_start", "pay_period_end", "amount_deducted", "processed_at"],
      properties: {
        employee_deduction_id: {
          bsonType: "objectId",
          description: "Reference to the employee deduction - required"
        },
        employee_id: {
          bsonType: "objectId",
          description: "Reference to the employee - required"
        },
        pay_period_start: {
          bsonType: "date",
          description: "Start date of the pay period - required"
        },
        pay_period_end: {
          bsonType: "date",
          description: "End date of the pay period - required"
        },
        gross_pay_amount: {
          bsonType: "number",
          minimum: 0,
          description: "Employee's gross pay for this period"
        },
        amount_deducted: {
          bsonType: "number",
          minimum: 0,
          description: "Amount actually deducted in this period - required"
        },
        reason_for_variance: {
          bsonType: "string",
          maxLength: 500,
          description: "Explanation if deducted amount differs from configured amount"
        },
        remaining_balance_after: {
          bsonType: ["number", "null"],
          minimum: 0,
          description: "Remaining balance after this deduction - null for ongoing deductions"
        },
        processed_by: {
          bsonType: "objectId",
          description: "User who processed this payroll"
        },
        processed_at: {
          bsonType: "date",
          description: "When this deduction was processed - required"
        }
      }
    }
  }
});

console.log("   ✅ Created payroll_deduction_history collection with validation");

// Create indexes for deduction history
db.payroll_deduction_history.createIndex({ "employee_deduction_id": 1 });
db.payroll_deduction_history.createIndex({ "employee_id": 1 });
db.payroll_deduction_history.createIndex({ "pay_period_start": 1, "pay_period_end": 1 });
db.payroll_deduction_history.createIndex({ "processed_at": 1 });
db.payroll_deduction_history.createIndex({ "employee_id": 1, "pay_period_start": 1 });
console.log("   ✅ Created indexes for payroll_deduction_history");

// 4. Insert default deduction types
console.log("📋 Inserting default deduction types...");

const defaultDeductionTypes = [
  {
    name: "Employee Advance",
    description: "Salary advance that needs to be repaid through payroll deductions",
    type: "fixed_amount",
    default_amount: null,
    default_percentage: null,
    frequency: "weekly",
    max_percentage_of_pay: 25,
    requires_approval: true,
    is_system_type: true,
    active: true,
    created_at: new Date(),
    updated_at: new Date()
  },
  {
    name: "Personal Loan",
    description: "Personal loan from company that needs to be repaid",
    type: "fixed_amount",
    default_amount: null,
    default_percentage: null,
    frequency: "weekly",
    max_percentage_of_pay: 25,
    requires_approval: true,
    is_system_type: true,
    active: true,
    created_at: new Date(),
    updated_at: new Date()
  },
  {
    name: "Court-Ordered Garnishment",
    description: "Legal wage garnishment ordered by court",
    type: "percentage",
    default_amount: null,
    default_percentage: null,
    frequency: "per_pay_period",
    max_percentage_of_pay: 25,
    requires_approval: false,
    is_system_type: true,
    active: true,
    created_at: new Date(),
    updated_at: new Date()
  },
  {
    name: "Equipment Purchase",
    description: "Purchase of tools or equipment through payroll deduction",
    type: "fixed_amount",
    default_amount: null,
    default_percentage: null,
    frequency: "weekly",
    max_percentage_of_pay: 15,
    requires_approval: true,
    is_system_type: true,
    active: true,
    created_at: new Date(),
    updated_at: new Date()
  },
  {
    name: "Uniform & Safety Gear",
    description: "Cost of uniforms and safety equipment",
    type: "fixed_amount",
    default_amount: 10,
    default_percentage: null,
    frequency: "weekly",
    max_percentage_of_pay: 10,
    requires_approval: false,
    is_system_type: true,
    active: true,
    created_at: new Date(),
    updated_at: new Date()
  },
  {
    name: "Training Cost Recovery",
    description: "Recovery of training course costs",
    type: "fixed_amount",
    default_amount: null,
    default_percentage: null,
    frequency: "monthly",
    max_percentage_of_pay: 20,
    requires_approval: true,
    is_system_type: true,
    active: true,
    created_at: new Date(),
    updated_at: new Date()
  },
  {
    name: "Parking Fee",
    description: "Monthly parking fee deduction",
    type: "fixed_amount",
    default_amount: 50,
    default_percentage: null,
    frequency: "monthly",
    max_percentage_of_pay: 5,
    requires_approval: false,
    is_system_type: true,
    active: true,
    created_at: new Date(),
    updated_at: new Date()
  },
  {
    name: "Custom Deduction",
    description: "Custom deduction type for special circumstances",
    type: "fixed_amount",
    default_amount: null,
    default_percentage: null,
    frequency: "per_pay_period",
    max_percentage_of_pay: 30,
    requires_approval: true,
    is_system_type: false,
    active: true,
    created_at: new Date(),
    updated_at: new Date()
  }
];

const insertResult = db.payroll_deduction_types.insertMany(defaultDeductionTypes);
console.log(`   ✅ Inserted ${insertResult.insertedIds.length} default deduction types`);

// 5. Update permissions in permission_definitions collection
console.log("📋 Adding deduction management permissions...");

const deductionPermissions = [
  {
    permission_id: "payroll_manage_deductions",
    permission_name: "Manage Payroll Deductions",
    description: "Create, edit, and delete employee payroll deductions",
    module: "payroll",
    is_system_permission: true,
    created_at: new Date(),
    updated_at: new Date()
  },
  {
    permission_id: "payroll_approve_deductions",
    permission_name: "Approve Payroll Deductions",
    description: "Approve payroll deductions that require approval",
    module: "payroll",
    is_system_permission: true,
    created_at: new Date(),
    updated_at: new Date()
  },
  {
    permission_id: "payroll_view_deduction_history",
    permission_name: "View Deduction History",
    description: "View historical deduction records and reports",
    module: "payroll",
    is_system_permission: true,
    created_at: new Date(),
    updated_at: new Date()
  },
  {
    permission_id: "payroll_manage_deduction_types",
    permission_name: "Manage Deduction Types",
    description: "Create and edit deduction type definitions",
    module: "payroll",
    is_system_permission: true,
    created_at: new Date(),
    updated_at: new Date()
  }
];

// Insert permissions (ignore duplicates)
for (const permission of deductionPermissions) {
  try {
    db.permission_definitions.insertOne(permission);
    console.log(`   ✅ Added permission: ${permission.permission_name}`);
  } catch (e) {
    if (e.code === 11000) {
      console.log(`   ℹ️  Permission already exists: ${permission.permission_name}`);
    } else {
      console.log(`   ❌ Error adding permission ${permission.permission_name}:`, e.message);
    }
  }
}

// 6. Grant deduction permissions to Admin role
console.log("📋 Granting deduction permissions to Admin role...");

// Find Admin role
const adminRole = db.roles.findOne({ role_name: "Admin" });
if (adminRole) {
  const deductionPermissionIds = deductionPermissions.map(p => p.permission_id);
  
  // Grant all deduction permissions to admin
  for (const permissionId of deductionPermissionIds) {
    try {
      db.user_permissions.updateOne(
        { 
          role_id: adminRole._id,
          permission_id: permissionId
        },
        {
          $set: {
            granted: true,
            updated_at: new Date()
          },
          $setOnInsert: {
            created_at: new Date()
          }
        },
        { upsert: true }
      );
      console.log(`   ✅ Granted ${permissionId} to Admin role`);
    } catch (e) {
      console.log(`   ❌ Error granting ${permissionId} to Admin:`, e.message);
    }
  }
} else {
  console.log("   ⚠️  Admin role not found - permissions not granted");
}

// 7. Verification and summary
console.log("\n🔍 Verification and Summary:");

// Count documents
const deductionTypesCount = db.payroll_deduction_types.countDocuments();
const employeeDeductionsCount = db.payroll_employee_deductions.countDocuments();
const deductionHistoryCount = db.payroll_deduction_history.countDocuments();

console.log(`📊 Collections created successfully:`);
console.log(`   • payroll_deduction_types: ${deductionTypesCount} documents`);
console.log(`   • payroll_employee_deductions: ${deductionHistoryCount} documents`);
console.log(`   • payroll_deduction_history: ${deductionHistoryCount} documents`);

// List deduction types
console.log("\n📋 Available deduction types:");
const deductionTypes = db.payroll_deduction_types.find({}, { name: 1, type: 1, frequency: 1 }).toArray();
deductionTypes.forEach(type => {
  console.log(`   • ${type.name} (${type.type}, ${type.frequency})`);
});

// Check permissions
const permissionCount = db.permission_definitions.countDocuments({ module: "payroll" });
console.log(`\n🔑 Payroll permissions available: ${permissionCount}`);

console.log("\n✅ Phase 2: Variable Deductions System setup completed successfully!");
console.log("\n📝 Next steps:");
console.log("1. Implement backend API endpoints as documented in PHASE2_VARIABLE_DEDUCTIONS_BACKEND_DOC.md");
console.log("2. Test API endpoints");
console.log("3. Implement frontend deduction management UI");
console.log("4. Test full integration");

console.log("\n🚀 Ready for backend implementation!");