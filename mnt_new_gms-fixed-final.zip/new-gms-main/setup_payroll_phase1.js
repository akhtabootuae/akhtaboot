// MongoDB Setup Script for Payroll System - Phase 1
// Run this script in MongoDB shell: mongosh your_database_name < setup_payroll_phase1.js

print("🚀 Starting Payroll System Phase 1 Database Setup...");

// Get current database
const db = db.getSiblingDB('GMS_DB'); // Replace with your actual database name

print("📋 Current database:", db.getName());

// 1. Create payroll_rates collection with schema validation
print("\n📊 Creating payroll_rates collection...");
try {
  db.createCollection("payroll_rates", {
    validator: {
      $jsonSchema: {
        bsonType: "object",
        required: ["employee_id", "daily_rate", "rate_type", "effective_date", "created_by", "created_at"],
        properties: {
          employee_id: {
            bsonType: "objectId",
            description: "Reference to users collection - required"
          },
          daily_rate: {
            bsonType: "number",
            minimum: 0,
            description: "Daily rate amount - required and must be positive"
          },
          rate_type: {
            bsonType: "string",
            enum: ["regular", "holiday", "premium"],
            description: "Type of rate - required"
          },
          effective_date: {
            bsonType: "date",
            description: "When this rate becomes active - required"
          },
          end_date: {
            bsonType: ["date", "null"],
            description: "When rate ends (null for current rate)"
          },
          created_by: {
            bsonType: "objectId",
            description: "Admin who set the rate - required"
          },
          created_at: {
            bsonType: "date",
            description: "When record was created - required"
          },
          notes: {
            bsonType: "string",
            description: "Reason for rate change"
          }
        }
      }
    }
  });
  print("✅ payroll_rates collection created successfully");
} catch (error) {
  print("❌ Error creating payroll_rates collection:", error.message);
}

// 2. Create payroll_audit_log collection
print("\n📝 Creating payroll_audit_log collection...");
try {
  db.createCollection("payroll_audit_log", {
    validator: {
      $jsonSchema: {
        bsonType: "object",
        required: ["log_id", "action", "entity_type", "entity_id", "user_id", "timestamp"],
        properties: {
          log_id: {
            bsonType: "string",
            description: "Unique log identifier - required"
          },
          action: {
            bsonType: "string",
            enum: ["rate_change", "deduction_add", "deduction_modify", "attendance_mark", "payroll_run"],
            description: "Type of action - required"
          },
          entity_type: {
            bsonType: "string",
            enum: ["employee", "deduction", "payroll_run"],
            description: "Type of entity affected - required"
          },
          entity_id: {
            bsonType: "objectId",
            description: "ID of affected entity - required"
          },
          user_id: {
            bsonType: "objectId",
            description: "User who made the change - required"
          },
          old_data: {
            bsonType: "object",
            description: "Previous state of data"
          },
          new_data: {
            bsonType: "object",
            description: "New state of data"
          },
          timestamp: {
            bsonType: "date",
            description: "When change occurred - required"
          },
          ip_address: {
            bsonType: "string",
            description: "IP address of user making change"
          },
          notes: {
            bsonType: "string",
            description: "Additional notes about the change"
          }
        }
      }
    }
  });
  print("✅ payroll_audit_log collection created successfully");
} catch (error) {
  print("❌ Error creating payroll_audit_log collection:", error.message);
}

// 3. Create indexes for performance
print("\n🔍 Creating database indexes...");

// Indexes for payroll_rates
try {
  db.payroll_rates.createIndex({ "employee_id": 1 });
  print("✅ Index on payroll_rates.employee_id created");
} catch (error) {
  print("❌ Error creating payroll_rates.employee_id index:", error.message);
}

try {
  db.payroll_rates.createIndex({ "employee_id": 1, "effective_date": -1 });
  print("✅ Compound index on payroll_rates (employee_id + effective_date) created");
} catch (error) {
  print("❌ Error creating payroll_rates compound index:", error.message);
}

try {
  db.payroll_rates.createIndex({ "end_date": 1 });
  print("✅ Index on payroll_rates.end_date created");
} catch (error) {
  print("❌ Error creating payroll_rates.end_date index:", error.message);
}

// Indexes for audit log
try {
  db.payroll_audit_log.createIndex({ "entity_id": 1 });
  print("✅ Index on payroll_audit_log.entity_id created");
} catch (error) {
  print("❌ Error creating payroll_audit_log.entity_id index:", error.message);
}

try {
  db.payroll_audit_log.createIndex({ "user_id": 1 });
  print("✅ Index on payroll_audit_log.user_id created");
} catch (error) {
  print("❌ Error creating payroll_audit_log.user_id index:", error.message);
}

try {
  db.payroll_audit_log.createIndex({ "timestamp": -1 });
  print("✅ Index on payroll_audit_log.timestamp created");
} catch (error) {
  print("❌ Error creating payroll_audit_log.timestamp index:", error.message);
}

// 4. Add new payroll permissions to existing permissions collection
print("\n🔐 Adding payroll permissions...");

const payrollPermissions = [
  {
    permission_id: "payroll_view",
    permission_name: "View Payroll",
    permission_description: "Can view payroll data and reports",
    category: "PAYROLL_MANAGEMENT"
  },
  {
    permission_id: "payroll_manage_rates",
    permission_name: "Manage Employee Rates",
    permission_description: "Can modify employee daily rates",
    category: "PAYROLL_MANAGEMENT"
  },
  {
    permission_id: "payroll_manage_deductions",
    permission_name: "Manage Deductions",
    permission_description: "Can create and modify payroll deductions",
    category: "PAYROLL_MANAGEMENT"
  },
  {
    permission_id: "payroll_process",
    permission_name: "Process Payroll",
    permission_description: "Can process payroll runs and generate paystubs",
    category: "PAYROLL_MANAGEMENT"
  },
  {
    permission_id: "payroll_attendance",
    permission_name: "Manage Attendance",
    permission_description: "Can mark and modify employee attendance",
    category: "PAYROLL_MANAGEMENT"
  }
];

// Check if permissions collection exists and add permissions
try {
  const permissionsCollection = db.getCollection("permissions");
  if (permissionsCollection) {
    payrollPermissions.forEach(permission => {
      const existing = permissionsCollection.findOne({ permission_id: permission.permission_id });
      if (!existing) {
        permissionsCollection.insertOne({
          ...permission,
          created_at: new Date(),
          updated_at: new Date()
        });
        print(`✅ Added permission: ${permission.permission_name}`);
      } else {
        print(`⚠️  Permission already exists: ${permission.permission_name}`);
      }
    });
  } else {
    print("⚠️  Permissions collection not found - will need to be added manually");
  }
} catch (error) {
  print("❌ Error adding permissions:", error.message);
}

// 5. Update existing users with payroll_info field
print("\n👥 Adding payroll_info field to existing users...");

try {
  // First, let's check how many users we have
  const userCount = db.users.countDocuments();
  print(`📊 Found ${userCount} users in the system`);

  // Update all users to add payroll_info field if it doesn't exist
  const updateResult = db.users.updateMany(
    { "payroll_info": { $exists: false } }, // Only update users without payroll_info
    {
      $set: {
        "payroll_info": {
          current_daily_rate: 0,
          employee_number: "",
          hire_date: null,
          payroll_eligible: true, // Default to true, admins can be set to false manually
          last_pay_date: null
        },
        "updated_at": new Date()
      }
    }
  );
  
  print(`✅ Updated ${updateResult.modifiedCount} users with payroll_info field`);
  
  // Set admins to not be payroll eligible
  const adminUpdateResult = db.users.updateMany(
    { "role_name": "Admin" },
    {
      $set: {
        "payroll_info.payroll_eligible": false,
        "updated_at": new Date()
      }
    }
  );
  
  print(`✅ Set ${adminUpdateResult.modifiedCount} admin users as not payroll eligible`);
  
} catch (error) {
  print("❌ Error updating users with payroll_info:", error.message);
}

// 6. Grant payroll permissions to Admin and Supervisor roles
print("\n🔑 Granting payroll permissions to Admin and Supervisor roles...");

try {
  // Get Admin and Supervisor role IDs
  const adminRole = db.roles.findOne({ role_name: "Admin" });
  const supervisorRole = db.roles.findOne({ role_name: "Supervisor" });
  
  if (adminRole) {
    // Grant all payroll permissions to admins
    const adminUsers = db.users.find({ role_name: "Admin" }).toArray();
    
    adminUsers.forEach(admin => {
      payrollPermissions.forEach(permission => {
        const existingPermission = admin.permissions?.find(p => p.permission_id === permission.permission_id);
        if (!existingPermission) {
          db.users.updateOne(
            { _id: admin._id },
            {
              $push: {
                permissions: {
                  permission_id: permission.permission_id,
                  permission_name: permission.permission_name,
                  permission_description: permission.permission_description,
                  category: permission.category,
                  granted: true
                }
              },
              $set: { updated_at: new Date() }
            }
          );
        }
      });
    });
    
    print(`✅ Granted payroll permissions to ${adminUsers.length} admin users`);
  }
  
  if (supervisorRole) {
    // Grant view and manage permissions to supervisors (not processing)
    const supervisorPermissions = payrollPermissions.filter(p => 
      p.permission_id !== "payroll_process" // Supervisors can't process payroll
    );
    
    const supervisorUsers = db.users.find({ role_name: "Supervisor" }).toArray();
    
    supervisorUsers.forEach(supervisor => {
      supervisorPermissions.forEach(permission => {
        const existingPermission = supervisor.permissions?.find(p => p.permission_id === permission.permission_id);
        if (!existingPermission) {
          db.users.updateOne(
            { _id: supervisor._id },
            {
              $push: {
                permissions: {
                  permission_id: permission.permission_id,
                  permission_name: permission.permission_name,
                  permission_description: permission.permission_description,
                  category: permission.category,
                  granted: true
                }
              },
              $set: { updated_at: new Date() }
            }
          );
        }
      });
    });
    
    print(`✅ Granted payroll permissions to ${supervisorUsers.length} supervisor users`);
  }
  
} catch (error) {
  print("❌ Error granting permissions:", error.message);
}

// 7. Insert some sample data for testing
print("\n🧪 Inserting sample data for testing...");

try {
  // Get some employees for sample data
  const employees = db.users.find({ 
    "role_name": { $in: ["Technician", "Manager"] },
    "payroll_info.payroll_eligible": true 
  }).limit(3).toArray();
  
  if (employees.length > 0) {
    const adminUser = db.users.findOne({ role_name: "Admin" });
    
    employees.forEach((employee, index) => {
      // Insert sample daily rate
      const sampleRate = {
        employee_id: employee._id,
        daily_rate: 150 + (index * 25), // $150, $175, $200
        rate_type: "regular",
        effective_date: new Date(),
        end_date: null,
        created_by: adminUser ? adminUser._id : new ObjectId(),
        created_at: new Date(),
        notes: "Initial rate setup for payroll system testing"
      };
      
      db.payroll_rates.insertOne(sampleRate);
      
      // Update user's current_daily_rate
      db.users.updateOne(
        { _id: employee._id },
        {
          $set: {
            "payroll_info.current_daily_rate": sampleRate.daily_rate,
            "payroll_info.employee_number": `EMP${String(index + 1).padStart(3, '0')}`,
            "payroll_info.hire_date": new Date(),
            "updated_at": new Date()
          }
        }
      );
      
      print(`✅ Created sample rate for ${employee.first_name} ${employee.last_name}: $${sampleRate.daily_rate}/day`);
    });
    
    print(`✅ Inserted sample data for ${employees.length} employees`);
  } else {
    print("⚠️  No eligible employees found for sample data");
  }
  
} catch (error) {
  print("❌ Error inserting sample data:", error.message);
}

// 8. Verification - Check what we created
print("\n🔍 Verification - Checking created collections and data...");

try {
  // Check collections
  const collections = db.listCollectionNames();
  const payrollCollections = collections.filter(name => name.includes('payroll'));
  print(`📋 Payroll collections created: ${payrollCollections.join(', ')}`);
  
  // Check document counts
  const ratesCount = db.payroll_rates.countDocuments();
  const auditCount = db.payroll_audit_log.countDocuments();
  const usersWithPayrollInfo = db.users.countDocuments({ "payroll_info": { $exists: true } });
  
  print(`📊 Document counts:`);
  print(`   - Payroll rates: ${ratesCount}`);
  print(`   - Audit log entries: ${auditCount}`);
  print(`   - Users with payroll info: ${usersWithPayrollInfo}`);
  
  // Check indexes
  const ratesIndexes = db.payroll_rates.getIndexes();
  const auditIndexes = db.payroll_audit_log.getIndexes();
  
  print(`🔍 Indexes created:`);
  print(`   - payroll_rates: ${ratesIndexes.length} indexes`);
  print(`   - payroll_audit_log: ${auditIndexes.length} indexes`);
  
} catch (error) {
  print("❌ Error during verification:", error.message);
}

print("\n🎉 Payroll System Phase 1 Database Setup Complete!");
print("💡 Next steps:");
print("   1. Update your backend API with the new payroll endpoints");
print("   2. Test the new collections with sample data");
print("   3. Implement the frontend payroll management interface");
print("\n📋 Manual verification commands:");
print("   db.payroll_rates.find().pretty()");
print("   db.users.findOne({'payroll_info': {$exists: true}})");
print("   db.payroll_audit_log.getIndexes()");