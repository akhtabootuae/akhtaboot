'use client';

import { useEffect, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';

// Type to define which routes require authentication
export type RouteAuthConfig = {
  adminOnly?: boolean;
  staffOnly?: boolean;
  supervisorOnly?: boolean;
  adminAndAccountantOnly?: boolean; // New option for admin and accountant access only
  adminAndSupervisorOnly?: boolean; // New option for admin and supervisor access only
};

/**
 * Utility function to handle authentication requirements for routes
 *
 * @param isAuthenticated - Whether the user is authenticated
 * @param user - The authenticated user object (if any)
 * @param authConfig - Authentication configuration
 * @param router - Next.js router
 */
export const handleRouteProtection = (
  isAuthenticated: boolean,
  user: any | null,
  authConfig: RouteAuthConfig = {},
  router: ReturnType<typeof useRouter>
): boolean => {
  const { adminOnly, staffOnly, supervisorOnly, adminAndAccountantOnly, adminAndSupervisorOnly } = authConfig;

  // Normalize role name to lowercase for case-insensitive comparison
  const roleName = user?.role_name?.toLowerCase() ?? '';

  // If not authenticated, redirect to login
  if (!isAuthenticated) {
    router.push('/login');
    return false;
  }

  // Check role-based access (all comparisons are case-insensitive)
  if (adminOnly && roleName !== 'admin') {
    router.push('/unauthorized');
    return false;
  }

  if (staffOnly && !['admin', 'staff', 'manager', 'supervisor'].includes(roleName)) {
    router.push('/unauthorized');
    return false;
  }

  if (supervisorOnly && !['admin', 'supervisor', 'manager'].includes(roleName)) {
    router.push('/unauthorized');
    return false;
  }

  // Check for admin and accountant only (excludes supervisor)
  if (adminAndAccountantOnly && !['admin', 'accountant'].includes(roleName)) {
    router.push('/unauthorized');
    return false;
  }

  // Check for admin and supervisor only (excludes accountant)
  if (adminAndSupervisorOnly && !['admin', 'supervisor'].includes(roleName)) {
    router.push('/unauthorized');
    return false;
  }

  // All checks passed
  return true;
};

/**
 * React hook to check authentication and enforce route protection
 *
 * @param isAuthenticated - Whether the user is authenticated
 * @param user - The authenticated user object (if any)
 * @param authConfig - Authentication configuration
 * @returns Whether access is granted
 */
export const useRouteProtection = (
  isAuthenticated: boolean,
  user: any | null,
  authConfig: RouteAuthConfig = {}
): boolean => {
  const router = useRouter();
  const [accessGranted, setAccessGranted] = useState(false);

  // Use JSON.stringify to create a stable reference for authConfig
  const authConfigKey = JSON.stringify(authConfig);
  const prevAuthConfigKey = useRef(authConfigKey);

  useEffect(() => {
    prevAuthConfigKey.current = authConfigKey;
    const result = handleRouteProtection(isAuthenticated, user, authConfig, router);
    setAccessGranted(result);
  }, [isAuthenticated, user, authConfigKey, router]);

  return accessGranted;
};
