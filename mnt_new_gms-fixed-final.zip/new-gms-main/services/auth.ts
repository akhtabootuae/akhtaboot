'use client';

import api from './api';

export type LoginCredentials = {
  email: string;
  password: string;
};

export type UserRegistration = {
  first_name: string;
  last_name: string;
  email: string;
  password: string;
  phone?: string; // Added phone number field
  role: {
    role_name?: string;
    role_id?: string;
  };
  branch?: {
    branch_name?: string;
    branch_code?: string;
    branch_id?: string;
  };
  speciality?: string; // Added for technician specialty
};

export const authService = {
  // Login user
  login: async (credentials: LoginCredentials) => {
    try {
      return await api.post('/api/users/login', credentials);
    } catch (error) {
      throw error;
    }
  },
  
  // Create new user (admin only)
  createUser: async (userData: UserRegistration) => {
    try {
      return await api.post('/api/users', userData);
    } catch (error) {
      throw error;
    }
  },
  
  // Logout user (cleans up local storage)
  logout: () => {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('authToken');
      localStorage.removeItem('user');
    }
  },
  
  // Get current authenticated user
  getCurrentUser: () => {
    if (typeof window !== 'undefined') {
      const userStr = localStorage.getItem('user');
      if (userStr) {
        try {
          return JSON.parse(userStr);
        } catch (e) {
          authService.logout();
          return null;
        }
      }
    }
    return null;
  },
  
  // Check if user is authenticated
  isAuthenticated: () => {
    if (typeof window !== 'undefined') {
      return !!localStorage.getItem('authToken');
    }
    return false;
  },
};

export default authService;
