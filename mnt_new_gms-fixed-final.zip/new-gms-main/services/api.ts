'use client';

import axios, { AxiosError } from 'axios';
import { ApiResponse, PaginatedApiResponse } from '@/app/types/api';

// Create axios instance with base configuration
const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000', // Your backend API server
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Function to get the auth token - this works on both client and server side
const getAuthToken = () => {
  if (typeof window !== 'undefined') {
    return localStorage.getItem('authToken');
  }
  return null;
};

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    const token = getAuthToken();
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor to handle errors
api.interceptors.response.use(
  (response) => {
    // Return the data from the response directly
    return response.data;
  },
  (error) => {
    // Log detailed error information for debugging
    if (error.response?.status === 401 || error.response?.status === 403) {
      console.error(`[API Error] ${error.config?.method?.toUpperCase()} ${error.config?.url} - Status: ${error.response.status}`, {
        message: error.response.data?.message,
        headers: error.response.headers,
        requestHeaders: error.config?.headers
      });
    }
    
    // Only handle 401 (authentication errors), not 403 (authorization errors)
    // 403 means user is authenticated but doesn't have permission - don't log them out
    if (error.response?.status === 401) {
      // Handle unauthorized access
      if (typeof window !== 'undefined') {
        localStorage.removeItem('authToken');
        localStorage.removeItem('user');
        
        // Only redirect if we're in a browser context and not during SSR
        if (window.location.pathname !== '/login') {
          window.location.href = `/login?callbackUrl=${encodeURIComponent(window.location.pathname)}`;
        }
      }
    }
    
    return Promise.reject(error);
  }
);

// Error Reports API
export const errorReportsApi = {
  // Get pending verifications for a technician
  getPendingVerifications: async (technicianId?: string) => {
    try {
      const params = technicianId ? { technicianId } : {};
      return await api.get('/api/error-reports/pending-verifications', { params });
    } catch (error) {
      console.error('Error fetching pending verifications:', error);
      throw error;
    }
  },
};

// Case Management API
export const caseApi = {

  // Get all cases with filtering and pagination
  getCases: async (filters: {
    page?: number;
    limit?: number;
    status?: string;
    priority?: string;
    createdBy?: string;
    assignedTo?: string;
    linkedType?: string;
    linkedId?: string;
    tags?: string[];
    search?: string;
    dateFrom?: string;
    dateTo?: string;
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
    overdue?: boolean;
    dueToday?: boolean;
  } = {}) => {
    try {
      const params: any = { ...filters };
      
      // Convert sortOrder to MongoDB format
      if (params.sortOrder === 'asc') {
        params.sortOrder = 1;
      } else if (params.sortOrder === 'desc') {
        params.sortOrder = -1;
      }
      
      return await api.get('/api/cases', { params });
    } catch (error) {
      console.error('Error fetching cases:', error);
      throw error;
    }
  },

  // Get case by ID
  getCaseById: async (id: string) => {
    try {
      return await api.get(`/api/cases/${id}`);
    } catch (error) {
      console.error(`Error fetching case ${id}:`, error);
      throw error;
    }
  },

  // Create new case
  createCase: async (caseData: {
    title: string;
    description: string;
    priority?: 'low' | 'medium' | 'high' | 'urgent';
    status?: 'open' | 'in-progress' | 'pending' | 'resolved' | 'closed';
    linkedTo?: {
      type: string;
      id?: string;
      reference?: string;
    };
    assignedTo?: string;
    tags?: string[];
    dueDate?: string;
  }) => {
    try {
      return await api.post('/api/cases', caseData);
    } catch (error) {
      console.error('Error creating case:', error);
      throw error;
    }
  },

  // Update case
  updateCase: async (id: string, updates: {
    title?: string;
    description?: string;
    priority?: 'low' | 'medium' | 'high' | 'urgent';
    status?: 'open' | 'in-progress' | 'pending' | 'resolved' | 'closed';
    assignedTo?: string;
    tags?: string[];
    dueDate?: string;
  }) => {
    try {
      return await api.put(`/api/cases/${id}`, updates);
    } catch (error) {
      console.error(`Error updating case ${id}:`, error);
      throw error;
    }
  },

  // Add note to case
  addNote: async (id: string, content: string) => {
    try {
      return await api.post(`/api/cases/${id}/notes`, { content });
    } catch (error) {
      console.error(`Error adding note to case ${id}:`, error);
      throw error;
    }
  },

  // Upload attachment to case
  uploadAttachment: async (id: string, file: File) => {
    try {
      const formData = new FormData();
      formData.append('attachment', file);
      
      return await api.post(`/api/cases/${id}/attachments`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
    } catch (error) {
      console.error(`Error uploading attachment to case ${id}:`, error);
      throw error;
    }
  },

  // Download attachment from case
  downloadAttachment: async (id: string, filename: string) => {
    try {
      // Use the backend as a proxy to avoid CORS issues
      const backendUrl = `${api.defaults.baseURL}/api/cases/${id}/attachments/${encodeURIComponent(filename)}?download=true`;
      
      // Create a temporary link and trigger download
      const link = document.createElement('a');
      link.href = backendUrl;
      link.download = filename;
      link.target = '_blank'; // Fallback for some browsers
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      return { success: true, message: 'File download started' };
    } catch (error) {
      console.error(`Error downloading attachment ${filename} from case ${id}:`, error);
      throw error;
    }
  },

  // View attachment from case (opens in new tab/window)
  viewAttachment: async (id: string, filename: string) => {
    try {
      // Instead of fetching the file directly, create a URL that goes through your backend
      const backendUrl = `${api.defaults.baseURL}/api/cases/${id}/attachments/${encodeURIComponent(filename)}?view=true`;
      
      // Open the backend URL directly in a new tab
      // This way the browser handles the file display and your backend can proxy from S3
      window.open(backendUrl, '_blank');
      
      return { success: true, message: 'File opened successfully' };
    } catch (error) {
      console.error(`Error viewing attachment ${filename} from case ${id}:`, error);
      throw error;
    }
  },

  // Delete attachment from case
  deleteAttachment: async (id: string, filename: string) => {
    try {
      return await api.delete(`/api/cases/${id}/attachments/${encodeURIComponent(filename)}`);
    } catch (error) {
      console.error(`Error deleting attachment ${filename} from case ${id}:`, error);
      throw error;
    }
  },

  // Get case statistics
  getStats: async (filters: {
    dateFrom?: string;
    dateTo?: string;
    assignedTo?: string;
  } = {}) => {
    try {
      return await api.get('/api/cases/stats', { params: filters });
    } catch (error) {
      console.error('Error fetching case stats:', error);
      throw error;
    }
  },

  // Delete case
  deleteCase: async (id: string) => {
    try {
      return await api.delete(`/api/cases/${id}`);
    } catch (error) {
      console.error(`Error deleting case ${id}:`, error);
      throw error;
    }
  },

  // Case Logs API functions
  getCaseLogs: async (params = {}) => {
    try {
      return await api.get('/api/cases/logs', { params });
    } catch (error: any) {
      console.error('Error fetching case logs:', error);
      throw error;
    }
  },

  getCaseLogsDisplay: async (params = {}) => {
    try {
      return await api.get('/api/cases/logs/display', { params });
    } catch (error: any) {
      console.error('Error fetching formatted case logs:', error);
      throw error;
    }
  },

  getCaseLogsList: async (params = {}) => {
    try {
      return await api.get('/api/cases/logs/list', { params });
    } catch (error: any) {
      console.error('Error fetching case logs list:', error);
      throw error;
    }
  },

  getCaseLogsDashboard: async (params = {}) => {
    try {
      return await api.get('/api/cases/logs/dashboard', { params });
    } catch (error: any) {
      console.error('Error fetching case logs dashboard:', error);
      throw error;
    }
  },

  exportCaseLogs: async (params = {}) => {
    try {
      const response = await api.get('/api/cases/logs/export', { 
        params,
        responseType: 'text' // Ensure we get the raw CSV text
      });
      return response;
    } catch (error: any) {
      console.error('Error exporting case logs:', error);
      throw error;
    }
  },

  getSpecificCaseLogs: async (caseId: string, params = {}) => {
    try {
      return await api.get(`/api/cases/${caseId}/logs`, { params });
    } catch (error: any) {
      console.error('Error fetching specific case logs:', error);
      throw error;
    }
  },

  getCaseLogDetails: async (logId: string) => {
    try {
      return await api.get(`/api/cases/logs/${logId}`);
    } catch (error: any) {
      console.error('Error fetching case log details:', error);
      throw error;
    }
  },

  getCaseLogsStatistics: async (params = {}) => {
    try {
      return await api.get('/api/cases/logs/statistics', { params });
    } catch (error: any) {
      console.error('Error fetching case logs statistics:', error);
      throw error;
    }
  },

  getRecentCaseActivity: async (params = {}) => {
    try {
      return await api.get('/api/cases/logs/recent', { params });
    } catch (error: any) {
      console.error('Error fetching recent case activity:', error);
      throw error;
    }
  },
};

export default api;

// Authentication-related API functions
export const authApi = {
  login: async (email: string, password: string) => {
    try {
      return await api.post('/api/users/login', { email, password });
    } catch (error) {
      throw error;
    }
  },
  
  // Change password for authenticated user
  changePassword: async (currentPassword: string, newPassword: string) => {
    try {
      return await api.post('/api/users/change-password', {
        currentPassword,
        newPassword
      });
    } catch (error) {
      throw error;
    }
  },
  
  // Function to check if token is valid (you can implement this if your backend has an endpoint)
  validateToken: async () => {
    const token = getAuthToken();
    if (!token) return false;
    
    try {
      // You can implement a lightweight endpoint to validate tokens
      // await api.get('/api/auth/validate');
      return true;
    } catch (error) {
      return false;
    }
  },
};

// Data fetching API functions
export const dataApi = {
  // Fetch all user roles
  getRoles: async () => {
    try {
      return await api.get('/api/roles');
    } catch (error) {
      console.error('Error fetching roles:', error);
      throw error;
    }
  },

  // Fetch technician specialties
  getTechnicianSpecialties: async () => {
    try {
      // Return the hardcoded specialties from the User model enum
      return ["PDR", "Fix/Remove", "Paint", "Body Work", "Mechanical", "Electrical", "General"];
    } catch (error) {
      console.error('Error fetching technician specialties:', error);
      throw error;
    }
  },

  // Fetch technicians by specialty (excluding a specific technician)
  getTechniciansBySpecialty: async (specialty: string, excludeTechnicianId?: string) => {
    try {
      const params: any = { specialty };
      if (excludeTechnicianId) {
        params.excludeId = excludeTechnicianId;
      }
      return await api.get('/api/users/technicians/by-specialty', { params });
    } catch (error: AxiosError | Error | unknown) {
      console.error('Error fetching technicians by specialty:', error);
      
      // If endpoint doesn't exist or other 404, return empty array
      if ((error as AxiosError)?.response?.status === 404) {
        // Technicians by specialty endpoint not found, returning empty array
        return [];
      }
      
      // For other errors, still throw to trigger fallback behavior
      throw error;
    }
  },

  // Fetch users by role ID
  getUsersByRole: async (roleId: string) => {
    try {
      return await api.get(`/api/users?role_id=${roleId}`);
    } catch (error) {
      console.error('Error fetching users by role:', error);
      throw error;
    }
  },

  // Fetch all branches
  getBranches: async () => {
    try {
      return await api.get('/api/branches');
    } catch (error) {
      console.error('Error fetching branches:', error);
      throw error;
    }
  },
  
  // Invoice related API functions
  getInvoices: async (filters = {}) => {
    try {
      return await api.get('/api/invoices', { params: filters });
    } catch (error) {
      console.error('Error fetching invoices:', error);
      throw error;
    }
  },
  
  getInvoiceById: async (id: string) => {
    try {
      return await api.get(`/api/invoices/${id}`);
    } catch (error) {
      console.error(`Error fetching invoice ${id}:`, error);
      throw error;
    }
  },

  getInvoiceByNumber: async (invoiceNumber: string) => {
    try {
      return await api.get(`/api/invoices/number/${invoiceNumber}`);
    } catch (error) {
      console.error(`Error fetching invoice by number ${invoiceNumber}:`, error);
      throw error;
    }
  },
  
  getCustomers: async () => {
    try {
      return await api.get('/api/customers');
    } catch (error) {
      console.error('Error fetching customers:', error);
      throw error;
    }
  },
  
  getCustomerById: async (customerId: string) => {
    try {
      return await api.get(`/api/customers/${customerId}`);
    } catch (error) {
      console.error(`Error fetching customer ${customerId}:`, error);
      throw error;
    }
  },
  
  createInvoice: async (invoiceData: any) => {
    try {
      return await api.post('/api/invoices', invoiceData);
    } catch (error) {
      console.error('Error creating invoice:', error);
      throw error;
    }
  },
  
  updateInvoice: async (id: string, invoiceData: any) => {
    try {
      return await api.put(`/api/invoices/${id}`, invoiceData);
    } catch (error) {
      console.error(`Error updating invoice ${id}:`, error);
      throw error;
    }
  },
  
  updateInvoiceInformation: async (id: string, invoiceData: any) => {
    try {
      return await api.put(`/api/invoices/${id}/update-information`, invoiceData);
    } catch (error) {
      console.error(`Error updating invoice information ${id}:`, error);
      throw error;
    }
  },
  
  deleteInvoice: async (id: string) => {
    try {
      return await api.delete(`/api/invoices/${id}`);
    } catch (error) {
      console.error(`Error deleting invoice ${id}:`, error);
      throw error;
    }
  },
  
  addPaymentRecord: async (id: string, paymentData: any) => {
    try {
      return await api.post(`/api/invoices/${id}/payments`, paymentData);
    } catch (error) {
      console.error(`Error adding payment to invoice ${id}:`, error);
      throw error;
    }
  },
  
  // Fetch all users/staff
  getUsers: async () => {
    try {
      return await api.get('/api/users');
    } catch (error) {
      console.error('Error fetching users:', error);
      throw error;
    }
  },

  // Fetch a single user by ID
  getUserById: async (userId: string) => {
    try {
      return await api.get(`/api/users/${userId}`);
    } catch (error: AxiosError | Error | unknown) {
      console.error('Error fetching user by ID:', error);
      
      // If user not found (404), return a structured error response instead of throwing
      if ((error as AxiosError)?.response?.status === 404) {
        return {
          success: false,
          error: 'User not found',
          status: 404,
          data: null
        };
      }
      
      throw error;
    }
  },

  // Export users as CSV
  exportUsers: async () => {
    try {
      const response = await api.get('/api/users/export', {
        responseType: 'text', // Important: tell axios to expect text response for CSV
        transformResponse: [(data) => data] // Prevent any transformation of the response
      });
      return response;
    } catch (error) {
      console.error('Error exporting users:', error);
      throw error;
    }
  },

  // Get work orders for a specific user
  getUserWorkOrders: async (userId: string, page = 1, limit = 10, status = 'in_progress') => {
    try {
      const params: any = { page, limit };
      // Only add status if it's not 'all'
      if (status && status !== 'all') {
        params.status = status;
      }
      
      return await api.get(`/api/users/${userId}/workorders`, {
        params
      });
    } catch (error) {
      console.error('Error fetching user work orders:', error);
      throw error;
    }
  },

  // Work Order related API functions
  getWorkOrders: async () => {
    try {
      return await api.get('/api/work-orders');
    } catch (error) {
      console.error('Error fetching work orders:', error);
      throw error;
    }
  },

  getWorkOrderById: async (id: string) => {
    try {
      return await api.get(`/api/work-orders/${id}`);
    } catch (error) {
      console.error(`Error fetching work order ${id}:`, error);
      throw error;
    }
  },

  getTechnicians: async () => {
    try {
      return await api.get('/api/users/technicians');
    } catch (error) {
      console.error('Error fetching technicians:', error);
      throw error;
    }
  },

  // Enrich work orders with customer and vehicle names
  //
  // NOTE: This function has an N+1 API problem. Each unique customer ID results in
  // a separate API call to getCustomerById. While Promise.all parallelizes the requests,
  // this still creates N HTTP requests for N unique customers. This could be improved
  // with a batch API endpoint (e.g., POST /api/customers/batch) that accepts an array
  // of customer IDs and returns all matching customers in a single request.
  enrichWorkOrdersWithNames: async (workOrders: any[]) => {
    try {
      if (!Array.isArray(workOrders) || workOrders.length === 0) {
        return workOrders;
      }

      // Get unique customer IDs
      const customerIds = [...new Set(workOrders.map(wo => wo.customer_id).filter(Boolean))];

      // Fetch all customers in parallel (N+1 problem - see comment above)
      const customerPromises = customerIds.map(async (customerId) => {
        try {
          const customerResponse = await dataApi.getCustomerById(customerId);
          return customerResponse;
        } catch (error) {
          console.error(`Error fetching customer ${customerId}:`, error);
          return null;
        }
      });

      const customerResults = await Promise.all(customerPromises);
      const customersMap = new Map();
      
      customerResults.forEach((result, index) => {
        if (result) {
          customersMap.set(customerIds[index], result);
        }
      });

      // Enrich work orders
      return workOrders.map(workOrder => {
        const enrichedOrder = { ...workOrder };
        
        // Enrich customer data
        const customerData = customersMap.get(workOrder.customer_id);
        if (customerData) {
          enrichedOrder.customer = {
            name: customerData.name || `${customerData.first_name || ''} ${customerData.last_name || ''}`.trim(),
            phone: customerData.phone,
            email: customerData.email
          };

          // Enrich vehicle data
          if (workOrder.vehicle_id && customerData.vehicles && Array.isArray(customerData.vehicles)) {
            const vehicle = customerData.vehicles.find((v: any) => 
              v.vehicle_id === workOrder.vehicle_id || v.id === workOrder.vehicle_id || v._id === workOrder.vehicle_id
            );
            if (vehicle) {
              enrichedOrder.vehicle = {
                make: vehicle.make || '',
                model: vehicle.model || '',
                year: vehicle.year || '',
                license_plate: vehicle.license_plate || '',
                color: vehicle.color || '',
                display: function() {
                  const parts = [];
                  if (this.year) parts.push(this.year);
                  if (this.make) parts.push(this.make);
                  if (this.model) parts.push(this.model);
                  
                  let result = parts.join(' ');
                  if (this.license_plate) {
                    result += ` (${this.license_plate})`;
                  }
                  
                  return result || 'Unknown Vehicle';
                }
              };
            } else {
              // Vehicle not found in customer's vehicles array
              enrichedOrder.vehicle = {
                make: '',
                model: '',
                year: '',
                license_plate: '',
                color: '',
                display: () => `Vehicle ID: ${workOrder.vehicle_id}`
              };
            }
          } else {
            // No vehicle_id or no vehicles array
            enrichedOrder.vehicle = {
              make: '',
              model: '',
              year: '',
              license_plate: '',
              color: '',
              display: () => 'Unknown Vehicle'
            };
          }
        } else {
          // Customer not found - fallback
          enrichedOrder.customer = {
            name: `Customer ID: ${workOrder.customer_id}`,
            phone: '',
            email: ''
          };
          enrichedOrder.vehicle = {
            make: '',
            model: '',
            year: '',
            license_plate: '',
            color: '',
            display: () => `Vehicle ID: ${workOrder.vehicle_id || 'Unknown'}`
          };
        }

        return enrichedOrder;
      });
    } catch (error) {
      console.error('Error enriching work orders with names:', error);
      // Return original work orders if enrichment fails
      return workOrders;
    }
  },

  // Update stage in work order
  updateStage: async (workOrderId: string, partIndex: number, stageIndex: number, stageData: any) => {
    try {
      return await api.put(`/api/work-orders/${workOrderId}/parts/${partIndex}/stages/${stageIndex}`, stageData);
    } catch (error) {
      console.error('Error updating stage:', error);
      throw error;
    }
  },

  // Update stage status
  updateStageStatus: async (workOrderId: string, partIndex: number, stageIndex: number, status: string) => {
    try {
      return await api.put(`/api/work-orders/${workOrderId}/parts/${partIndex}/stages/${stageIndex}/status`, { status });
    } catch (error) {
      console.error('Error updating stage status:', error);
      throw error;
    }
  },

  // Add log entry to stage
  addStageLog: async (workOrderId: string, partIndex: number, stageIndex: number, logData: any) => {
    try {
      return await api.post(`/api/work-orders/${workOrderId}/parts/${partIndex}/stages/${stageIndex}/logs`, logData);
    } catch (error) {
      console.error('Error adding stage log:', error);
      throw error;
    }
  },

  // Update work order status
  updateWorkOrderStatus: async (workOrderId: string, status: string) => {
    try {
      return await api.put(`/api/work-orders/${workOrderId}/status`, { status });
    } catch (error) {
      console.error('Error updating work order status:', error);
      throw error;
    }
  },

  // Update work order priority
  updateWorkOrderPriority: async (workOrderId: string, priority: string) => {
    try {
      return await api.put(`/api/work-orders/${workOrderId}`, { priority });
    } catch (error) {
      console.error('Error updating work order priority:', error);
      throw error;
    }
  },

  // Cancel a part in work order with approval image
  cancelPart: async (workOrderId: string, partName: string, reason: string, approvalImage: File) => {
    try {
      const formData = new FormData();
      formData.append('partName', partName);
      formData.append('reason', reason);
      formData.append('approvalImage', approvalImage);

      return await api.post(`/api/work-orders/${workOrderId}/parts/cancel`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
    } catch (error) {
      console.error('Error cancelling part:', error);
      throw error;
    }
  },

  // Get all stages for mapping
  getStages: async () => {
    try {
      return await api.get('/api/stages');
    } catch (error) {
      console.error('Error fetching stages:', error);
      throw error;
    }
  },

  // Search users by name, email, or role
  searchUsers: async (searchTerm: string) => {
    try {
      // Since we don't have a specific search endpoint, get all users and filter
      const allUsers = await api.get('/api/users');
      const users = Array.isArray(allUsers) ? allUsers : [];
      
      const searchLower = searchTerm.toLowerCase();
      return users.filter((user: any) => {
        const name = user.name || `${user.first_name || ''} ${user.last_name || ''}`.trim();
        const email = user.email || '';
        const role = user.role || '';
        
        return (
          name.toLowerCase().includes(searchLower) ||
          email.toLowerCase().includes(searchLower) ||
          role.toLowerCase().includes(searchLower)
        );
      }).map((user: any) => ({
        id: user._id,
        label: user.name || `${user.first_name || ''} ${user.last_name || ''}`.trim(),
        subtitle: `${user.email} • ${user.role}`
      }));
    } catch (error) {
      console.error('Error searching users:', error);
      throw error;
    }
  },

  // Search customers by name, email, or phone
  searchCustomers: async (searchTerm: string) => {
    try {
      const allCustomers = await api.get('/api/customers');
      const customers = Array.isArray(allCustomers) ? allCustomers : [];
      
      const searchLower = searchTerm.toLowerCase();
      return customers.filter((customer: any) => {
        const name = `${customer.first_name || ''} ${customer.last_name || ''}`.trim();
        const email = customer.email || '';
        const phone = customer.phone || '';
        
        return (
          name.toLowerCase().includes(searchLower) ||
          email.toLowerCase().includes(searchLower) ||
          phone.includes(searchTerm)
        );
      }).map((customer: any) => ({
        id: customer._id,
        label: `${customer.first_name || ''} ${customer.last_name || ''}`.trim(),
        subtitle: `${customer.email} • ${customer.phone || 'No phone'}`
      }));
    } catch (error) {
      console.error('Error searching customers:', error);
      throw error;
    }
  },

  // Search work orders by number or customer
  searchWorkOrders: async (searchTerm: string) => {
    try {
      // This would need to be implemented when work orders search API is available
      // For now, return empty array
      return [];
    } catch (error) {
      console.error('Error searching work orders:', error);
      throw error;
    }
  },

  // Search invoices by number or customer
  searchInvoices: async (searchTerm: string) => {
    try {
      // Fetch all invoices and customers in parallel
      const [allInvoicesResponse, allCustomersResponse] = await Promise.all([
        api.get('/api/invoices'),
        api.get('/api/customers')
      ]);
      
      const invoices = Array.isArray(allInvoicesResponse) ? allInvoicesResponse : [];
      const customers = Array.isArray(allCustomersResponse) ? allCustomersResponse : [];
      
      // Create a map of customer_id to customer data for quick lookup
      const customerMap = new Map();
      customers.forEach((customer: any) => {
        customerMap.set(customer._id, customer);
      });
      
      const searchLower = searchTerm.toLowerCase();
      return invoices.filter((invoice: any) => {
        // Primary search field is invoice_number
        const invoiceNumber = invoice.invoice_number || '';
        
        // Get customer data using customer_id reference
        const customer = customerMap.get(invoice.customer_id);
        const customerName = customer 
          ? `${customer.first_name || ''} ${customer.last_name || ''}`.trim()
          : '';
        
        // Get license plate from vehicle info
        const licensePlate = invoice.vehicle_info?.license_plate || '';
        
        return (
          invoiceNumber.toLowerCase().includes(searchLower) ||
          customerName.toLowerCase().includes(searchLower) ||
          licensePlate.toLowerCase().includes(searchLower)
        );
      }).map((invoice: any) => {
        // Get customer data for display
        const customer = customerMap.get(invoice.customer_id);
        const customerName = customer 
          ? `${customer.first_name || ''} ${customer.last_name || ''}`.trim()
          : 'Unknown Customer';
        
        return {
          id: invoice._id,
          label: invoice.invoice_number || 'No Invoice Number',
          subtitle: customerName
        };
      });
    } catch (error: AxiosError | Error | unknown) {
      console.error('Error searching invoices:', error);
      throw error;
    }
  },

  // Manner Evaluations API functions
  getMannerEvaluations: async (userId: string) => {
    try {
      const response = await api.get(`/api/users/${userId}/manner-evaluations`);
      return response;
    } catch (error) {
      console.error('Error fetching manner evaluations:', error);
      throw error;
    }
  },

  createMannerEvaluation: async (userId: string, evaluationData: any) => {
    try {
      const response = await api.post(`/api/users/${userId}/manner-evaluations`, evaluationData);
      return response;
    } catch (error) {
      console.error('Error creating manner evaluation:', error);
      throw error;
    }
  },

  updateMannerEvaluation: async (userId: string, evaluationId: string, evaluationData: any) => {
    try {
      const response = await api.put(`/api/users/${userId}/manner-evaluations/${evaluationId}`, evaluationData);
      return response;
    } catch (error) {
      console.error('Error updating manner evaluation:', error);
      throw error;
    }
  },

  deleteMannerEvaluation: async (userId: string, evaluationId: string) => {
    try {
      const response = await api.delete(`/api/users/${userId}/manner-evaluations/${evaluationId}`);
      return response;
    } catch (error) {
      console.error('Error deleting manner evaluation:', error);
      throw error;
    }
  },

  getMannerEvaluationLogs: async (userId: string) => {
    try {
      const response = await api.get(`/api/users/${userId}/manner-evaluation-logs`);
      return response;
    } catch (error) {
      console.error('Error fetching manner evaluation logs:', error);
      throw error;
    }
  },
};

// Notifications API functions
export const notificationsApi = {
  // Get all notifications for the current user
  getNotifications: async (filters?: {
    type?: string;
    priority?: string;
    status?: string;
    recipientType?: string;
  }) => {
    try {
      return await api.get('/api/notifications', { params: filters });
    } catch (error) {
      console.error('Error fetching notifications:', error);
      throw error;
    }
  },

  // Get notification by ID
  getNotificationById: async (id: string) => {
    try {
      return await api.get(`/api/notifications/${id}`);
    } catch (error) {
      console.error(`Error fetching notification ${id}:`, error);
      throw error;
    }
  },

  // Mark notification as done
  markAsDone: async (id: string) => {
    try {
      return await api.put(`/api/notifications/${id}/done`);
    } catch (error) {
      console.error(`Error marking notification ${id} as done:`, error);
      throw error;
    }
  },

  // Mark multiple notifications as done
  markMultipleAsDone: async (ids: string[]) => {
    try {
      return await api.put('/api/notifications/done', { notificationIds: ids });
    } catch (error) {
      console.error('Error marking notifications as done:', error);
      throw error;
    }
  },

  // Archive notification
  archiveNotification: async (id: string) => {
    try {
      return await api.put(`/api/notifications/${id}/archive`);
    } catch (error) {
      console.error(`Error archiving notification ${id}:`, error);
      throw error;
    }
  },

  // Get notification statistics
  getNotificationStats: async () => {
    try {
      return await api.get('/api/notifications/stats');
    } catch (error) {
      console.error('Error fetching notification stats:', error);
      throw error;
    }
  },

  // Delete expired notifications
  deleteExpired: async () => {
    try {
      return await api.delete('/api/notifications/expired');
    } catch (error) {
      console.error('Error deleting expired notifications:', error);
      throw error;
    }
  },

  // Create notification for case note added
  createCaseNoteNotification: async (caseId: string, noteContent: string) => {
    try {
      return await api.post('/api/notifications/case-note', {
        case_id: caseId,
        note_content: noteContent
      });
    } catch (error) {
      console.error('Error creating case note notification:', error);
      throw error;
    }
  },
};

export const errorReportingApi = {
  // Create a new error report
  createErrorReport: async (formData: FormData) => {
    try {
      return await api.post('/api/error-reports', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
    } catch (error) {
      console.error('Error creating error report:', error);
      throw error;
    }
  },

  // Create error report for specific work order stage
  createStageErrorReport: async (workOrderId: string, partIndex: number, stageIndex: number, formData: FormData) => {
    try {
      return await api.post(`/api/work-orders/${workOrderId}/parts/${partIndex}/stages/${stageIndex}/error-report`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
    } catch (error) {
      console.error('Error creating stage error report:', error);
      throw error;
    }
  },
  
  // Upload QC approval photo when work is accepted
  uploadQCApprovalPhoto: async (workOrderId: string, partIndex: number, stageIndex: number, formData: FormData) => {
    try {
      return await api.post(`/api/work-orders/${workOrderId}/parts/${partIndex}/stages/${stageIndex}/qc-approval`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
    } catch (error) {
      console.error('Error uploading QC approval photo:', error);
      throw error;
    }
  },

  // Get error report by ID
  getErrorReport: async (id: string) => {
    try {
      return await api.get(`/api/error-reports/${id}`);
    } catch (error) {
      console.error(`Error fetching error report ${id}:`, error);
      throw error;
    }
  },

  // Get error report for specific stage
  getStageErrorReport: async (workOrderId: string, partIndex: number, stageIndex: number) => {
    try {
      return await api.get(`/api/work-orders/${workOrderId}/parts/${partIndex}/stages/${stageIndex}/error-report`);
    } catch (error) {
      console.error(`Error fetching error report for stage ${stageIndex}:`, error);
      throw error;
    }
  },

  // Get all error reports for a work order
  getWorkOrderErrorReports: async (workOrderId: string) => {
    try {
      return await api.get(`/api/error-reports/work-order/${workOrderId}`);
    } catch (error) {
      console.error(`Error fetching error reports for work order ${workOrderId}:`, error);
      throw error;
    }
  },

  // Get error reports by technician
  getTechnicianErrorReports: async (technicianId: string, type: 'reported' | 'problematic' = 'reported') => {
    try {
      return await api.get(`/api/error-reports/technician/${technicianId}?type=${type}`);
    } catch (error) {
      console.error(`Error fetching error reports for technician ${technicianId}:`, error);
      throw error;
    }
  },

  // Acknowledge an error report
  acknowledgeErrorReport: async (id: string) => {
    try {
      return await api.put(`/api/error-reports/${id}/acknowledge`);
    } catch (error) {
      console.error(`Error acknowledging error report ${id}:`, error);
      throw error;
    }
  },

  // Resolve an error report
  resolveErrorReport: async (id: string, resolution: string) => {
    try {
      return await api.put(`/api/error-reports/${id}/resolve`, { resolution });
    } catch (error) {
      console.error(`Error resolving error report ${id}:`, error);
      throw error;
    }
  },

  // Mark stage for redo
  markStageForRedo: async (workOrderId: string, partIndex: number, stageIndex: number) => {
    try {
      return await api.put(`/api/work-orders/${workOrderId}/parts/${partIndex}/stages/${stageIndex}/redo`);
    } catch (error) {
      console.error('Error marking stage for redo:', error);
      throw error;
    }
  },

  // Get error summary for work order
  getWorkOrderErrorSummary: async (workOrderId: string) => {
    try {
      return await api.get(`/api/work-orders/${workOrderId}/error-summary`);
    } catch (error) {
      console.error(`Error fetching error summary for work order ${workOrderId}:`, error);
      throw error;
    }
  },

  // Mark multiple stages for redo
  markStagesForRedo: async (workOrderId: string, partIndex: number, stageIndices: number[]) => {
    try {
      return await api.post('/api/error-reports/mark-redo', {
        workOrderId,
        partIndex,
        stageIndices
      });
    } catch (error) {
      console.error('Error marking stages for redo:', error);
      throw error;
    }
  },

  // Start verification process
  startVerification: async (errorReportId: string, verifyingTechnicianId: string) => {
    try {
      return await api.post(`/api/error-reports/${errorReportId}/start-verification`, {
        verifyingTechnicianId
      });
    } catch (error) {
      console.error('Error starting verification:', error);
      throw error;
    }
  },

  // Complete verification process
  completeVerification: async (errorReportId: string, verdict: 'good_standard' | 'not_good_standard', notes: string) => {
    try {
      return await api.post(`/api/error-reports/${errorReportId}/complete-verification`, {
        verdict,
        notes
      });
    } catch (error) {
      console.error('Error completing verification:', error);
      throw error;
    }
  },

  // Get pending verifications for a technician
  getPendingVerifications: async (technicianId?: string) => {
    try {
      const params = technicianId ? { technicianId } : {};
      return await api.get('/api/error-reports/pending-verifications', { params });
    } catch (error) {
      console.error('Error fetching pending verifications:', error);
      throw error;
    }
  },
};

// Expense Management API Functions
export const fetchExpenses = async (filters: any = {}) => {
  try {
    const queryParams = new URLSearchParams();
    
    if (filters.search) queryParams.append('search', filters.search);
    if (filters.expense_type) queryParams.append('expense_type', filters.expense_type);
    if (filters.status) queryParams.append('status', filters.status);
    if (filters.approval_status) queryParams.append('approval_status', filters.approval_status);
    if (filters.date_from) queryParams.append('date_from', filters.date_from);
    if (filters.date_to) queryParams.append('date_to', filters.date_to);
    if (filters.vendor) queryParams.append('vendor', filters.vendor);
    if (filters.branch_id) queryParams.append('branch_id', filters.branch_id);
    if (filters.page) queryParams.append('page', filters.page);
    if (filters.limit) queryParams.append('limit', filters.limit);

    const url = `/api/expenses${queryParams.toString() ? `?${queryParams.toString()}` : ''}`;
    return await api.get(url);
  } catch (error) {
    console.error('Error fetching expenses:', error);
    throw error;
  }
};

export const fetchUserExpenses = async (filters: any = {}) => {
  try {
    const queryParams = new URLSearchParams();
    
    if (filters.expense_type) queryParams.append('expense_type', filters.expense_type);
    if (filters.status) queryParams.append('status', filters.status);
    if (filters.date_from) queryParams.append('date_from', filters.date_from);
    if (filters.date_to) queryParams.append('date_to', filters.date_to);

    const url = `/api/expenses/my${queryParams.toString() ? `?${queryParams.toString()}` : ''}`;
    return await api.get(url);
  } catch (error) {
    console.error('Error fetching user expenses:', error);
    throw error;
  }
};

export const fetchExpenseById = async (expenseId: string) => {
  try {
    return await api.get(`/api/expenses/${expenseId}`);
  } catch (error) {
    console.error('Error fetching expense by ID:', error);
    throw error;
  }
};

export const createExpense = async (expenseData: any) => {
  try {
    // Create FormData for file upload
    const formData = new FormData();
    
    // Add the invoice image file (required for creation)
    if (expenseData.invoice_image) {
      formData.append('invoice_image', expenseData.invoice_image);
    }
    
    // Add all other expense data fields
    Object.keys(expenseData).forEach(key => {
      if (key !== 'invoice_image' && expenseData[key] !== undefined && expenseData[key] !== null) {
        if (Array.isArray(expenseData[key])) {
          formData.append(key, JSON.stringify(expenseData[key]));
        } else {
          formData.append(key, expenseData[key].toString());
        }
      }
    });
    
    const response = await api.post('/api/expenses', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response;
  } catch (error) {
    throw error;
  }
};

export const updateExpense = async (expenseId: string, expenseData: any) => {
  try {
    return await api.put(`/api/expenses/${expenseId}`, expenseData);
  } catch (error) {
    console.error('Error updating expense:', error);
    throw error;
  }
};

export const deleteExpense = async (expenseId: string) => {
  try {
    return await api.delete(`/api/expenses/${expenseId}`);
  } catch (error) {
    console.error('Error deleting expense:', error);
    throw error;
  }
};

export const fetchExpenseStatistics = async (filters: any = {}) => {
  try {
    const queryParams = new URLSearchParams();
    
    if (filters.branch_id) queryParams.append('branch_id', filters.branch_id);
    if (filters.date_from) queryParams.append('date_from', filters.date_from);
    if (filters.date_to) queryParams.append('date_to', filters.date_to);

    const url = `/api/expenses/statistics${queryParams.toString() ? `?${queryParams.toString()}` : ''}`;
    return await api.get(url);
  } catch (error) {
    console.error('Error fetching expense statistics:', error);
    throw error;
  }
};

export const fetchExpensesByType = async (filters: any = {}) => {
  try {
    const queryParams = new URLSearchParams();
    
    if (filters.branch_id) queryParams.append('branch_id', filters.branch_id);
    if (filters.date_from) queryParams.append('date_from', filters.date_from);
    if (filters.date_to) queryParams.append('date_to', filters.date_to);

    const url = `/api/expenses/by-type${queryParams.toString() ? `?${queryParams.toString()}` : ''}`;
    return await api.get(url);
  } catch (error) {
    console.error('Error fetching expenses by type:', error);
    throw error;
  }
};

export const fetchPendingApprovals = async () => {
  try {
    return await api.get('/api/expenses/pending-approval');
  } catch (error) {
    console.error('Error fetching pending approvals:', error);
    throw error;
  }
};

export const approveExpense = async (expenseId: string, approvalData: any) => {
  try {
    return await api.put(`/api/expenses/${expenseId}/approval`, approvalData);
  } catch (error) {
    console.error('Error approving expense:', error);
    throw error;
  }
};

export const rejectExpense = async (expenseId: string, rejectionData: any) => {
  try {
    return await api.put(`/api/expenses/${expenseId}/approval`, rejectionData);
  } catch (error) {
    console.error('Error rejecting expense:', error);
    throw error;
  }
};

export const addReceiptImage = async (expenseId: string, receiptData: any) => {
  try {
    return await api.post(`/api/expenses/${expenseId}/receipt-images`, receiptData);
  } catch (error) {
    console.error('Error adding receipt image:', error);
    throw error;
  }
};

export const removeReceiptImage = async (expenseId: string, receiptData: any) => {
  try {
    return await api.delete(`/api/expenses/${expenseId}/receipt-images`, { data: receiptData });
  } catch (error) {
    console.error('Error removing receipt image:', error);
    throw error;
  }
};

export const fetchExpenseTypes = async () => {
  try {
    return await api.get('/api/expenses/types');
  } catch (error) {
    console.error('Error fetching expense types:', error);
    throw error;
  }
};

export const generateExpenseInvoicePDF = async (expenseData: any): Promise<Blob> => {
  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000'}/api/expenses/generate-signature-pdf`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${getAuthToken()}`,
      },
      body: JSON.stringify(expenseData),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ message: 'Failed to generate invoice PDF' }));
      throw new Error(errorData.message || 'Failed to generate invoice PDF');
    }

    return response.blob();
  } catch (error) {
    console.error('Error generating expense invoice PDF:', error);
    throw error;
  }
};

// Payroll API functions
export const payrollApi = {
  // Get employee count and summary data (for dashboard)
  getEmployees: async () => {
    try {
      return await api.get('/api/payroll/employees/list');
    } catch (error) {
      console.error('Error fetching payroll employees:', error);
      throw error;
    }
  },

  // Get full list of payroll-eligible employees (for employee management page)
  getEmployeesList: async (filters?: { 
    page?: number; 
    limit?: number; 
    branch_id?: string; 
    role_name?: string; 
    payroll_eligible_only?: boolean;
    search?: string;
    include_rates?: boolean;
  }) => {
    try {
      // Default to including rates for the employee rates page
      const params = { include_rates: true, ...filters };
      return await api.get('/api/payroll/employees/list', { params });
    } catch (error) {
      console.error('Error fetching payroll employees list:', error);
      throw error;
    }
  },

  // Get rate history for specific employee
  getEmployeeRates: async (employeeId: string) => {
    try {
      return await api.get(`/api/payroll/employees/${employeeId}/rates`);
    } catch (error) {
      console.error(`Error fetching rates for employee ${employeeId}:`, error);
      throw error;
    }
  },

  // Update employee daily rate
  updateEmployeeRate: async (employeeId: string, rateData: {
    daily_rate: number;
    effective_date?: string;
    reason?: string;
    rate_type?: string;
  }) => {
    try {
      const requestPayload = {
        daily_rate: rateData.daily_rate,
        effective_date: rateData.effective_date || new Date().toISOString(),
        reason: rateData.reason || "Rate update",
        rate_type: rateData.rate_type || "regular"
      };
      return await api.put(`/api/payroll/employees/${employeeId}/rate`, requestPayload);
    } catch (error) {
      console.error(`Error updating rate for employee ${employeeId}:`, error);
      throw error;
    }
  },

  // Get current rate for employee
  getCurrentRate: async (employeeId: string) => {
    try {
      return await api.get(`/api/payroll/employees/${employeeId}/current-rate`);
    } catch (error) {
      console.error(`Error fetching current rate for employee ${employeeId}:`, error);
      throw error;
    }
  },

  // Get audit log (admin only)
  getAuditLog: async (filters?: {
    page?: number;
    limit?: number;
    user_id?: string;
    action?: string;
    start_date?: string;
    end_date?: string;
  }) => {
    try {
      return await api.get('/api/payroll/audit-log', { params: filters });
    } catch (error) {
      console.error('Error fetching payroll audit log:', error);
      throw error;
    }
  },

  // Phase 2: Variable Deductions System API Functions

  // Deduction Types
  getDeductionTypes: async (filters?: { active?: boolean }) => {
    try {
      return await api.get('/api/payroll/deduction-types', { params: filters });
    } catch (error) {
      console.error('Error fetching deduction types:', error);
      throw error;
    }
  },

  getDeductionTypeById: async (id: string) => {
    try {
      return await api.get(`/api/payroll/deduction-types/${id}`);
    } catch (error) {
      console.error(`Error fetching deduction type ${id}:`, error);
      throw error;
    }
  },

  createDeductionType: async (typeData: any) => {
    try {
      return await api.post('/api/payroll/deduction-types', typeData);
    } catch (error) {
      console.error('Error creating deduction type:', error);
      throw error;
    }
  },

  updateDeductionType: async (id: string, typeData: any) => {
    try {
      return await api.put(`/api/payroll/deduction-types/${id}`, typeData);
    } catch (error) {
      console.error(`Error updating deduction type ${id}:`, error);
      throw error;
    }
  },

  deleteDeductionType: async (id: string) => {
    try {
      return await api.delete(`/api/payroll/deduction-types/${id}`);
    } catch (error) {
      console.error(`Error deleting deduction type ${id}:`, error);
      throw error;
    }
  },

  // Employee Deductions
  getEmployeeDeductions: async (employeeId: string, filters?: { status?: string; active_only?: boolean }) => {
    try {
      return await api.get(`/api/payroll/employees/${employeeId}/deductions`, { params: filters });
    } catch (error) {
      console.error(`Error fetching deductions for employee ${employeeId}:`, error);
      throw error;
    }
  },

  getDeductionById: async (id: string) => {
    try {
      return await api.get(`/api/payroll/deductions/${id}`);
    } catch (error) {
      console.error(`Error fetching deduction ${id}:`, error);
      throw error;
    }
  },

  createEmployeeDeduction: async (employeeId: string, deductionData: any) => {
    try {
      return await api.post(`/api/payroll/employees/${employeeId}/deductions`, deductionData);
    } catch (error) {
      console.error(`Error creating deduction for employee ${employeeId}:`, error);
      throw error;
    }
  },

  updateDeduction: async (id: string, deductionData: any) => {
    try {
      return await api.put(`/api/payroll/deductions/${id}`, deductionData);
    } catch (error) {
      console.error(`Error updating deduction ${id}:`, error);
      throw error;
    }
  },

  approveDeduction: async (id: string, notes?: string) => {
    try {
      return await api.post(`/api/payroll/deductions/${id}/approve`, { notes });
    } catch (error) {
      console.error(`Error approving deduction ${id}:`, error);
      throw error;
    }
  },

  updateDeductionStatus: async (id: string, status: string, reason?: string) => {
    try {
      return await api.put(`/api/payroll/deductions/${id}/status`, { status, reason });
    } catch (error) {
      console.error(`Error updating deduction status ${id}:`, error);
      throw error;
    }
  },

  // Deduction History
  getEmployeeDeductionHistory: async (employeeId: string, options?: {
    page?: number;
    limit?: number;
    start_date?: string;
    end_date?: string;
  }) => {
    try {
      return await api.get(`/api/payroll/employees/${employeeId}/deduction-history`, { params: options });
    } catch (error) {
      console.error(`Error fetching deduction history for employee ${employeeId}:`, error);
      throw error;
    }
  },

  getDeductionHistory: async (deductionId: string) => {
    try {
      return await api.get(`/api/payroll/deductions/${deductionId}/history`);
    } catch (error) {
      console.error(`Error fetching history for deduction ${deductionId}:`, error);
    }
  },

  // Get all deduction history with filtering and pagination
  getAllDeductionHistory: async (filters?: {
    page?: number;
    limit?: number;
    start_date?: string;
    end_date?: string;
    employee_id?: string;
    deduction_type_id?: string;
  }) => {
    try {
      return await api.get('/api/payroll/deduction-history', { params: filters });
    } catch (error) {
      console.error('Error fetching all deduction history:', error);
      throw error;
    }
  },

  getDeductionSummary: async (employeeId: string, options?: {
    start_date?: string;
    end_date?: string;
  }) => {
    try {
      return await api.get(`/api/payroll/employees/${employeeId}/deduction-summary`, { params: options });
    } catch (error) {
      console.error(`Error fetching deduction summary for employee ${employeeId}:`, error);
      throw error;
    }
  },

  // Phase 3: Time Sheets (Attendance) endpoints
  getTimeSheets: async (filters?: { 
    employee_id?: string; 
    start_date?: string; 
    end_date?: string; 
    status?: string; 
    page?: number; 
    limit?: number; 
  }) => {
    try {
      return await api.get('/api/payroll/timesheets', { params: filters });
    } catch (error) {
      console.error('Error fetching time sheets:', error);
      throw error;
    }
  },

  getTimeSheet: async (id: string) => {
    try {
      return await api.get(`/api/payroll/timesheets/${id}`);
    } catch (error) {
      console.error('Error fetching time sheet:', error);
      throw error;
    }
  },

  createTimeSheet: async (data: any) => {
    try {
      return await api.post('/api/payroll/timesheets', data);
    } catch (error) {
      console.error('Error creating time sheet:', error);
      throw error;
    }
  },

  updateTimeSheet: async (id: string, data: any) => {
    try {
      const response = await api.put(`/api/payroll/timesheets/${id}`, data);
      return response;
    } catch (error) {
      console.error('Error updating time sheet:', error);
      throw error;
    }
  },

  submitTimeSheet: async (id: string) => {
    try {
      return await api.post(`/api/payroll/timesheets/${id}/submit`);
    } catch (error) {
      console.error('Error submitting time sheet:', error);
      throw error;
    }
  },

  approveTimeSheet: async (id: string) => {
    try {
      return await api.post(`/api/payroll/timesheets/${id}/approve`);
    } catch (error) {
      console.error('Error approving time sheet:', error);
      throw error;
    }
  },

  rejectTimeSheet: async (id: string, rejection_reason: string) => {
    try {
      return await api.post(`/api/payroll/timesheets/${id}/reject`, { rejection_reason });
    } catch (error) {
      console.error('Error rejecting time sheet:', error);
      throw error;
    }
  },

  deleteTimeSheet: async (id: string) => {
    try {
      return await api.delete(`/api/payroll/timesheets/${id}`);
    } catch (error) {
      console.error('Error deleting time sheet:', error);
      throw error;
    }
  },

  getEmployeeTimeSheets: async (employeeId: string, filters?: any) => {
    try {
      return await api.get(`/api/payroll/employees/${employeeId}/timesheets`, { params: filters });
    } catch (error) {
      console.error('Error fetching employee time sheets:', error);
      throw error;
    }
  },

  createBulkTimeSheets: async (data: { entries: any[] }) => {
    try {
      return await api.post('/api/payroll/timesheets/bulk', data);
    } catch (error) {
      console.error('Error creating bulk time sheets:', error);
      throw error;
    }
  },

  // Pay Periods endpoints
  getPayPeriods: async (filters?: { status?: string; page?: number; limit?: number }) => {
    try {
      return await api.get('/api/payroll/pay-periods', { params: filters });
    } catch (error) {
      console.error('Error fetching pay periods:', error);
      throw error;
    }
  },

  getPayPeriod: async (id: string) => {
    try {
      return await api.get(`/api/payroll/pay-periods/${id}`);
    } catch (error) {
      console.error('Error fetching pay period:', error);
      throw error;
    }
  },

  createPayPeriod: async (data: any) => {
    try {
      return await api.post('/api/payroll/pay-periods', data);
    } catch (error) {
      console.error('Error creating pay period:', error);
      throw error;
    }
  },

  updatePayPeriod: async (id: string, data: any) => {
    try {
      return await api.put(`/api/payroll/pay-periods/${id}`, data);
    } catch (error) {
      console.error('Error updating pay period:', error);
      throw error;
    }
  },

  calculatePayPeriod: async (id: string) => {
    try {
      return await api.post(`/api/payroll/pay-periods/${id}/calculate`);
    } catch (error) {
      console.error('Error calculating pay period:', error);
      throw error;
    }
  },

  approvePayPeriod: async (id: string) => {
    try {
      return await api.post(`/api/payroll/pay-periods/${id}/approve`);
    } catch (error) {
      console.error('Error approving pay period:', error);
      throw error;
    }
  },

  getPayPeriodCalculations: async (payPeriodId: string) => {
    try {
      return await api.get(`/api/payroll/pay-periods/${payPeriodId}/calculations`);
    } catch (error) {
      console.error('Error fetching pay period calculations:', error);
      throw error;
    }
  },

  // Payroll Calculations endpoints
  getPayrollCalculations: async (filters?: { 
    pay_period_id?: string; 
    employee_id?: string; 
    status?: string 
  }) => {
    try {
      return await api.get('/api/payroll/calculations', { params: filters });
    } catch (error) {
      console.error('Error fetching payroll calculations:', error);
      throw error;
    }
  },

  getPayrollCalculation: async (id: string) => {
    try {
      return await api.get(`/api/payroll/calculations/${id}`);
    } catch (error) {
      console.error('Error fetching payroll calculation:', error);
      throw error;
    }
  },

  recalculatePayroll: async (id: string) => {
    try {
      return await api.post(`/api/payroll/calculations/${id}/recalculate`);
    } catch (error) {
      console.error('Error recalculating payroll:', error);
      throw error;
    }
  },

  approvePayrollCalculation: async (id: string) => {
    try {
      return await api.post(`/api/payroll/calculations/${id}/approve`);
    } catch (error) {
      console.error('Error approving payroll calculation:', error);
      throw error;
    }
  },

  // Attendance Analytics endpoints
  getAttendanceSummary: async (params: { 
    start_date: string; 
    end_date: string; 
    employee_id?: string 
  }) => {
    try {
      return await api.get('/api/payroll/attendance/summary', { params });
    } catch (error) {
      console.error('Error fetching attendance summary:', error);
      throw error;
    }
  },

  // Phase 4: Reports & Paystubs endpoints
  getPayStubs: async (filters?: { 
    employee_id?: string; 
    pay_period_id?: string; 
    status?: string 
  }) => {
    try {
      return await api.get('/api/payroll/paystubs', { params: filters });
    } catch (error) {
      console.error('Error fetching paystubs:', error);
      throw error;
    }
  },

  getPayStub: async (id: string) => {
    try {
      return await api.get(`/api/payroll/paystubs/${id}`);
    } catch (error) {
      console.error('Error fetching paystub:', error);
      throw error;
    }
  },

  generatePayStub: async (calculationId: string) => {
    try {
      return await api.post(`/api/payroll/paystubs/generate/${calculationId}`);
    } catch (error) {
      console.error('Error generating paystub:', error);
      throw error;
    }
  },

  downloadPayStub: async (id: string) => {
    try {
      return await api.get(`/api/payroll/paystubs/${id}/download`, { responseType: 'blob' });
    } catch (error) {
      console.error('Error downloading paystub:', error);
      throw error;
    }
  },

  sendPayStub: async (id: string, email?: string) => {
    try {
      return await api.post(`/api/payroll/paystubs/${id}/send`, { email });
    } catch (error) {
      console.error('Error sending paystub:', error);
      throw error;
    }
  },

  // Reports endpoints
  getReports: async (filters?: { type?: string; status?: string }) => {
    try {
      return await api.get('/api/payroll/reports', { params: filters });
    } catch (error) {
      console.error('Error fetching reports:', error);
      throw error;
    }
  },

  generateReport: async (data: any) => {
    try {
      return await api.post('/api/payroll/reports/generate', data);
    } catch (error) {
      console.error('Error generating report:', error);
      throw error;
    }
  },

  downloadReport: async (id: string) => {
    try {
      return await api.get(`/api/payroll/reports/${id}/download`, { responseType: 'blob' });
    } catch (error) {
      console.error('Error downloading report:', error);
      throw error;
    }
  },

  // Phase 5: Advanced Features endpoints
  getPayrollAlerts: async (filters?: { type?: string; severity?: string; resolved?: boolean }) => {
    try {
      return await api.get('/api/payroll/alerts', { params: filters });
    } catch (error) {
      console.error('Error fetching payroll alerts:', error);
      throw error;
    }
  },

  acknowledgeAlert: async (id: string) => {
    try {
      return await api.post(`/api/payroll/alerts/${id}/acknowledge`);
    } catch (error) {
      console.error('Error acknowledging alert:', error);
      throw error;
    }
  },

  resolveAlert: async (id: string, notes?: string) => {
    try {
      return await api.post(`/api/payroll/alerts/${id}/resolve`, { notes });
    } catch (error) {
      console.error('Error resolving alert:', error);
      throw error;
    }
  },

  // Budget Management endpoints
  getBudgets: async () => {
    try {
      return await api.get('/api/payroll/budgets');
    } catch (error) {
      console.error('Error fetching budgets:', error);
      throw error;
    }
  },

  createBudget: async (data: any) => {
    try {
      return await api.post('/api/payroll/budgets', data);
    } catch (error) {
      console.error('Error creating budget:', error);
      throw error;
    }
  },

  updateBudget: async (id: string, data: any) => {
    try {
      return await api.put(`/api/payroll/budgets/${id}`, data);
    } catch (error) {
      console.error('Error updating budget:', error);
      throw error;
    }
  },

  // Integration Management endpoints
  getIntegrations: async () => {
    try {
      return await api.get('/api/payroll/integrations');
    } catch (error) {
      console.error('Error fetching integrations:', error);
      throw error;
    }
  },

  createIntegration: async (data: any) => {
    try {
      return await api.post('/api/payroll/integrations', data);
    } catch (error) {
      console.error('Error creating integration:', error);
      throw error;
    }
  },

  updateIntegration: async (id: string, data: any) => {
    try {
      return await api.put(`/api/payroll/integrations/${id}`, data);
    } catch (error) {
      console.error('Error updating integration:', error);
      throw error;
    }
  },

  testIntegration: async (id: string) => {
    try {
      return await api.post(`/api/payroll/integrations/${id}/test`);
    } catch (error) {
      console.error('Error testing integration:', error);
      throw error;
    }
  },

  syncIntegration: async (id: string) => {
    try {
      return await api.post(`/api/payroll/integrations/${id}/sync`);
    } catch (error) {
      console.error('Error syncing integration:', error);
      throw error;
    }
  },

  // Pay Period Details & Analytics endpoints
  getPayPeriodAnalytics: async (id: string) => {
    try {
      return await api.get(`/api/payroll/pay-periods/${id}/analytics`);
    } catch (error) {
      console.error(`Error fetching analytics for pay period ${id}:`, error);
      throw error;
    }
  },

  getMissingTimesheets: async (id: string) => {
    try {
      return await api.get(`/api/payroll/pay-periods/${id}/missing-timesheets`);
    } catch (error) {
      console.error(`Error fetching missing timesheets for pay period ${id}:`, error);
      throw error;
    }
  },

  bulkApproveCalculations: async (id: string, calculationIds?: string[]) => {
    try {
      const requestData = calculationIds ? { calculation_ids: calculationIds } : {};
      return await api.post(`/api/payroll/pay-periods/${id}/bulk-approve-calculations`, requestData);
    } catch (error) {
      console.error(`Error bulk approving calculations for pay period ${id}:`, error);
      throw error;
    }
  },

  bulkRecalculatePayPeriod: async (id: string, options?: { calculation_ids?: string[], reason?: string }) => {
    try {
      return await api.post(`/api/payroll/pay-periods/${id}/bulk-recalculate`, options || {});
    } catch (error) {
      console.error(`Error bulk recalculating pay period ${id}:`, error);
      throw error;
    }
  },

  // Update employee monthly salary (new system)
  updateEmployeeSalary: async (employeeId: string, salaryData: {
    monthly_salary: number;
    reason?: string;
  }) => {
    try {
      const requestPayload = {
        monthly_salary: salaryData.monthly_salary,
        reason: salaryData.reason || "Salary update",
        effective_date: new Date().toISOString()
      };
      return await api.put(`/api/payroll/employees/${employeeId}/salary`, requestPayload);
    } catch (error) {
      console.error(`Error updating salary for employee ${employeeId}:`, error);
      throw error;
    }
  }
};

// Finance API
export const financeApi = {
  // Revenue Analytics
  getRevenue: async (filters: { start_date?: string; end_date?: string; branch_id?: string } = {}) => {
    try {
      const params = new URLSearchParams();
      Object.entries(filters).forEach(([key, value]) => {
        if (value) params.append(key, value);
      });
      return await api.get(`/api/finance/revenue?${params}`);
    } catch (error) {
      console.error('Error fetching revenue analytics:', error);
      throw error;
    }
  },

  // Expense Analytics
  getExpenses: async (filters: { start_date?: string; end_date?: string; branch_id?: string; expense_type?: string } = {}) => {
    try {
      const params = new URLSearchParams();
      Object.entries(filters).forEach(([key, value]) => {
        if (value) params.append(key, value);
      });
      return await api.get(`/api/finance/expenses?${params}`);
    } catch (error) {
      console.error('Error fetching expense analytics:', error);
      throw error;
    }
  },

  // Payroll Cost Analytics
  getPayroll: async (filters: { start_date?: string; end_date?: string; branch_id?: string } = {}) => {
    try {
      const params = new URLSearchParams();
      Object.entries(filters).forEach(([key, value]) => {
        if (value) params.append(key, value);
      });
      return await api.get(`/api/finance/payroll?${params}`);
    } catch (error) {
      console.error('Error fetching payroll analytics:', error);
      throw error;
    }
  },

  // Profit & Loss Analysis
  getProfitLoss: async (filters: { start_date?: string; end_date?: string; branch_id?: string } = {}) => {
    try {
      const params = new URLSearchParams();
      Object.entries(filters).forEach(([key, value]) => {
        if (value) params.append(key, value);
      });
      return await api.get(`/api/finance/profit-loss?${params}`);
    } catch (error) {
      console.error('Error fetching profit & loss analytics:', error);
      throw error;
    }
  },

  // Financial Dashboard
  getDashboard: async (filters: { start_date?: string; end_date?: string; branch_id?: string } = {}) => {
    try {
      const params = new URLSearchParams();
      Object.entries(filters).forEach(([key, value]) => {
        if (value) params.append(key, value);
      });
      return await api.get(`/api/finance/dashboard?${params}`);
    } catch (error) {
      console.error('Error fetching financial dashboard:', error);
      throw error;
    }
  },

  // Cash Flow Analysis
  getCashFlow: async (filters: { start_date?: string; end_date?: string; branch_id?: string } = {}) => {
    try {
      const params = new URLSearchParams();
      Object.entries(filters).forEach(([key, value]) => {
        if (value) params.append(key, value);
      });
      return await api.get(`/api/finance/cash-flow?${params}`);
    } catch (error) {
      console.error('Error fetching cash flow analytics:', error);
      throw error;
    }
  },

  // Financial Summary
  getSummary: async (filters: { start_date?: string; end_date?: string; branch_id?: string } = {}) => {
    try {
      const params = new URLSearchParams();
      Object.entries(filters).forEach(([key, value]) => {
        if (value) params.append(key, value);
      });
      return await api.get(`/api/finance/summary?${params}`);
    } catch (error) {
      console.error('Error fetching financial summary:', error);
      throw error;
    }
  },

  // Branch Performance Comparison
  getBranchComparison: async (filters: { start_date?: string; end_date?: string } = {}) => {
    try {
      const params = new URLSearchParams();
      Object.entries(filters).forEach(([key, value]) => {
        if (value) params.append(key, value);
      });
      return await api.get(`/api/finance/branches/comparison?${params}`);
    } catch (error) {
      console.error('Error fetching branch comparison:', error);
      throw error;
    }
  },

  // Export Functions
  exportCSV: async (filters: { start_date?: string; end_date?: string; branch_id?: string; type?: string } = {}) => {
    try {
      const params = new URLSearchParams();
      Object.entries(filters).forEach(([key, value]) => {
        if (value) params.append(key, value);
      });
      
      const response = await axios.get(`${api.defaults.baseURL}/api/finance/export/csv?${params}`, {
        headers: {
          Authorization: `Bearer ${getAuthToken()}`,
        },
        responseType: 'blob'
      });
      
      return response;
    } catch (error) {
      console.error('Error exporting CSV:', error);
      throw error;
    }
  },

  exportDetailedCSV: async (filters: { start_date?: string; end_date?: string; branch_id?: string; type: string }) => {
    try {
      const params = new URLSearchParams();
      Object.entries(filters).forEach(([key, value]) => {
        if (value) params.append(key, value);
      });
      
      const response = await axios.get(`${api.defaults.baseURL}/api/finance/export/csv/detailed?${params}`, {
        headers: {
          Authorization: `Bearer ${getAuthToken()}`,
        },
        responseType: 'blob'
      });
      
      return response;
    } catch (error) {
      console.error('Error exporting detailed CSV:', error);
      throw error;
    }
  }
};

// Customer Review API functions
export const customerReviewApi = {
  // Create a new customer review (public endpoint)
  createReview: async (reviewData: {
    rating: number;
    phone_number?: string;
    comment?: string;
    referral?: string;
  }) => {
    try {
      return await api.post('/api/customer-reviews', reviewData);
    } catch (error) {
      console.error('Error creating customer review:', error);
      throw error;
    }
  },

  // Get all customer reviews with filters (admin)
  getReviews: async (filters: {
    page?: number;
    limit?: number;
    rating?: number;
    phone_number?: string;
    sort_by?: string;
    sort_order?: 'asc' | 'desc';
  } = {}) => {
    try {
      return await api.get('/api/customer-reviews', { params: filters });
    } catch (error) {
      console.error('Error fetching customer reviews:', error);
      throw error;
    }
  },

  // Get review statistics (admin)
  getStatistics: async () => {
    try {
      return await api.get('/api/customer-reviews/statistics');
    } catch (error) {
      console.error('Error fetching customer review statistics:', error);
      throw error;
    }
  },

  // Get review by ID (admin)
  getReviewById: async (id: string) => {
    try {
      return await api.get(`/api/customer-reviews/${id}`);
    } catch (error) {
      console.error(`Error fetching customer review ${id}:`, error);
      throw error;
    }
  },

  // Get reviews by phone number (admin)
  getReviewsByPhone: async (phoneNumber: string) => {
    try {
      return await api.get(`/api/customer-reviews/phone/${phoneNumber}`);
    } catch (error) {
      console.error(`Error fetching reviews for phone ${phoneNumber}:`, error);
      throw error;
    }
  },

  // Get reviews by rating (admin)
  getReviewsByRating: async (rating: number) => {
    try {
      return await api.get(`/api/customer-reviews/rating/${rating}`);
    } catch (error) {
      console.error(`Error fetching reviews with rating ${rating}:`, error);
      throw error;
    }
  },

  // Update review (admin)
  updateReview: async (id: string, reviewData: {
    rating?: number;
    phone_number?: string;
    comment?: string;
  }) => {
    try {
      return await api.put(`/api/customer-reviews/${id}`, reviewData);
    } catch (error) {
      console.error(`Error updating customer review ${id}:`, error);
      throw error;
    }
  },

  // Delete review (admin)
  deleteReview: async (id: string) => {
    try {
      return await api.delete(`/api/customer-reviews/${id}`);
    } catch (error) {
      console.error(`Error deleting customer review ${id}:`, error);
      throw error;
    }
  },

  // Bulk delete reviews (admin)
  bulkDeleteReviews: async (reviewIds: string[]) => {
    try {
      return await api.post('/api/customer-reviews/bulk-delete', { review_ids: reviewIds });
    } catch (error) {
      console.error('Error bulk deleting customer reviews:', error);
      throw error;
    }
  },

  // Export reviews (admin)
  exportReviews: async (exportData: {
    format: 'json' | 'csv';
    filters?: {
      rating?: number;
      phone_number?: string;
      date_from?: string;
      date_to?: string;
    };
    include_statistics?: boolean;
  }) => {
    try {
      const response = await api.post('/api/customer-reviews/export', exportData, {
        responseType: exportData.format === 'csv' ? 'blob' : 'json'
      });
      return response;
    } catch (error) {
      console.error('Error exporting customer reviews:', error);
      throw error;
    }
  },
};

// Messaging API functions
export const messagingApi = {
  // Get all conversations for the authenticated user
  getConversations: async () => {
    try {
      return await api.get('/api/messaging/conversations');
    } catch (error) {
      console.error('Error fetching conversations:', error);
      throw error;
    }
  },

  // Create private conversation
  createPrivateConversation: async (recipientId: string) => {
    try {
      return await api.post('/api/messaging/conversations/private', {
        recipient_id: recipientId
      });
    } catch (error) {
      console.error('Error creating private conversation:', error);
      throw error;
    }
  },

  // Create group conversation
  createGroupConversation: async (data: {
    title: string;
    participant_ids: string[];
  }) => {
    try {
      return await api.post('/api/messaging/conversations/group', data);
    } catch (error) {
      console.error('Error creating group conversation:', error);
      throw error;
    }
  },

  // Create announcement (Admin only)
  createAnnouncement: async (data: {
    title: string;
    description?: string;
    recipient_ids: string[];
    time_span?: string;
  }) => {
    try {
      return await api.post('/api/messaging/conversations/announcement', data);
    } catch (error) {
      console.error('Error creating announcement:', error);
      throw error;
    }
  },

  // Delete announcement
  deleteAnnouncement: async (conversationId: string) => {
    try {
      return await api.delete(`/api/messaging/conversations/announcement/${conversationId}`);
    } catch (error) {
      console.error('Error deleting announcement:', error);
      throw error;
    }
  },

  // Get messages for a conversation
  getConversationMessages: async (conversationId: string, params?: {
    page?: number;
    limit?: number;
  }) => {
    try {
      return await api.get(`/api/messaging/conversations/${conversationId}/messages`, {
        params
      });
    } catch (error) {
      console.error('Error fetching conversation messages:', error);
      throw error;
    }
  },

  // Send message
  sendMessage: async (conversationId: string, data: {
    content: string;
    message_type?: 'text' | 'announcement';
  }) => {
    try {
      return await api.post(`/api/messaging/conversations/${conversationId}/messages`, data);
    } catch (error) {
      console.error('Error sending message:', error);
      throw error;
    }
  },

  // Search users for messaging (using general users endpoint)
  searchUsers: async (params?: {
    q?: string;
    limit?: number;
  }) => {
    try {
      // Use the existing getUsers endpoint and filter locally
      const allUsers = await api.get('/api/users') as any;
      const users = Array.isArray(allUsers) ? allUsers : [];
      
      let filteredUsers = users;
      
      // Apply search filter if query provided
      if (params?.q?.trim()) {
        const searchLower = params.q.toLowerCase();
        filteredUsers = users.filter((user: any) => {
          const name = user.name || `${user.first_name || ''} ${user.last_name || ''}`.trim();
          const email = user.email || '';
          const role = user.role || '';
          
          return (
            name.toLowerCase().includes(searchLower) ||
            email.toLowerCase().includes(searchLower) ||
            role.toLowerCase().includes(searchLower)
          );
        });
      }
      
      // Apply limit if provided
      if (params?.limit) {
        filteredUsers = filteredUsers.slice(0, params.limit);
      }
      
      // Format response to match expected structure
      return {
        success: true,
        users: filteredUsers.map((user: any) => ({
          _id: user._id,
          name: user.name || `${user.first_name || ''} ${user.last_name || ''}`.trim(),
          email: user.email,
          role: user.role,
          branch: user.branch
        }))
      };
    } catch (error) {
      console.error('Error searching users:', error);
      throw error;
    }
  },

  // Add user to group conversation
  addUserToGroup: async (conversationId: string, data: {
    user_id: string;
    show_previous_messages?: boolean;
  }) => {
    try {
      return await api.post(`/api/messaging/conversations/${conversationId}/add-user`, data);
    } catch (error) {
      console.error('Error adding user to group:', error);
      throw error;
    }
  },

  // Remove user from group conversation
  removeUserFromGroup: async (conversationId: string, data: {
    user_id: string;
  }) => {
    try {
      return await api.post(`/api/messaging/conversations/${conversationId}/remove-user`, data);
    } catch (error) {
      console.error('Error removing user from group:', error);
      throw error;
    }
  },

  // Send image message
  sendImage: async (conversationId: string, imageFile: File, caption?: string) => {
    try {
      const formData = new FormData();
      formData.append('image', imageFile);
      if (caption) formData.append('caption', caption);

      // Use axios for file uploads with proper headers
      return await api.post(`/api/messaging/conversations/${conversationId}/send-image`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });
    } catch (error) {
      console.error('Error sending image:', error);
      throw error;
    }
  },

  // Send voice note message  
  sendVoice: async (conversationId: string, audioFile: File, duration: number) => {
    try {
      const formData = new FormData();
      formData.append('voiceNote', audioFile);
      formData.append('duration', duration.toString());

      // Use axios for file uploads with proper headers
      return await api.post(`/api/messaging/conversations/${conversationId}/send-voice`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });
    } catch (error) {
      console.error('Error sending voice note:', error);
      throw error;
    }
  },

  // Refresh expired file URL
  refreshFileUrl: async (fileKey: string) => {
    try {
      const response = await api.get(`/api/messaging/file/${encodeURIComponent(fileKey)}`);
      
      // Backend returns: { success: true, data: { signed_url: "...", expires_in: 86400 } }
      // The axios interceptor returns response.data, so we access data.signed_url
      const signedUrl = (response as any).data?.signed_url;
      
      if (!signedUrl) {
        console.error('Invalid response structure:', response);
        throw new Error('No signed URL in response');
      }
      
      return signedUrl;
    } catch (error) {
      console.error('Error refreshing file URL:', error);
      throw error;
    }
  },
};

