// MongoDB Fix Script for Payroll System - Phase 1
// This script fixes the issues from the initial setup
// Run this script in MongoDB shell: mongosh GMS_DB < fix_payroll_setup.js

print("🔧 Starting Payroll System Phase 1 Fix Script...");

// Get current database
const db = db.getSiblingDB('GMS_DB');

print("📋 Current database:", db.getName());

// 1. Update users collection schema to include payroll_info
print("\n📝 Updating users collection schema validation...");

try {
  // Get current validation rules
  const currentValidation = db.runCommand({ collMod: "users", validator: {} });
  
  // Update the schema to include payroll_info
  db.runCommand({
    collMod: "users",
    validator: {
      $jsonSchema: {
        bsonType: 'object',
        required: [
          'first_name',
          'last_name',
          'email',
          'password_hash',
          'role_id',
          'role_name',
          'created_at',
          'updated_at'
        ],
        properties: {
          first_name: {
            bsonType: 'string'
          },
          last_name: {
            bsonType: 'string'
          },
          email: {
            bsonType: 'string',
            description: 'must be a string and is required'
          },
          phone: {
            bsonType: 'string'
          },
          password_hash: {
            bsonType: 'string'
          },
          is_active: {
            bsonType: 'bool',
            description: 'active flag'
          },
          staff_code: {
            bsonType: 'string'
          },
          speciality: {
            bsonType: 'string',
            'enum': [
              'PDR',
              'Fix/Remove',
              'Paint',
              'Body Work',
              'Mechanical',
              'Electrical',
              'General'
            ],
            description: 'Technician specialty - only applicable for technician roles'
          },
          branch: {
            bsonType: 'object',
            required: [
              'branch_id',
              'branch_name'
            ],
            properties: {
              branch_id: {
                bsonType: 'objectId'
              },
              branch_name: {
                bsonType: 'string'
              },
              branch_code: {
                bsonType: 'string'
              },
              location: {
                bsonType: 'string'
              }
            }
          },
          role_id: {
            bsonType: 'objectId'
          },
          role_name: {
            bsonType: 'string'
          },
          role_description: {
            bsonType: 'string'
          },
          permissions: {
            bsonType: 'array',
            items: {
              bsonType: 'object',
              required: [
                'permission_id',
                'permission_name',
                'granted'
              ],
              properties: {
                permission_id: {
                  bsonType: 'string'
                },
                permission_name: {
                  bsonType: 'string'
                },
                permission_description: {
                  bsonType: 'string'
                },
                category: {
                  bsonType: 'string'
                },
                granted: {
                  bsonType: 'bool'
                }
              }
            }
          },
          permission_logs: {
            bsonType: 'array',
            items: {
              bsonType: 'object',
              required: [
                'log_id',
                'target_type',
                'target_id',
                'permission_id',
                'action',
                'created_at'
              ],
              properties: {
                log_id: {
                  bsonType: 'string'
                },
                target_type: {
                  'enum': [
                    'user',
                    'role'
                  ]
                },
                target_id: {
                  bsonType: 'objectId'
                },
                permission_id: {
                  bsonType: 'string'
                },
                action: {
                  'enum': [
                    'grant',
                    'revoke'
                  ]
                },
                created_at: {
                  bsonType: 'date'
                },
                details: {
                  bsonType: 'string'
                }
              }
            }
          },
          // ADD NEW PAYROLL_INFO FIELD
          payroll_info: {
            bsonType: 'object',
            properties: {
              current_daily_rate: {
                bsonType: 'number',
                minimum: 0,
                description: 'Current daily rate for the employee'
              },
              employee_number: {
                bsonType: 'string',
                description: 'Unique employee identifier for payroll'
              },
              hire_date: {
                bsonType: ['date', 'null'],
                description: 'Date when employee was hired'
              },
              payroll_eligible: {
                bsonType: 'bool',
                description: 'Whether employee is eligible for payroll processing'
              },
              last_pay_date: {
                bsonType: ['date', 'null'],
                description: 'Date of last payroll payment'
              }
            }
          },
          created_at: {
            bsonType: 'date'
          },
          updated_at: {
            bsonType: 'date'
          }
        }
      }
    }
  });
  
  print("✅ Users collection schema updated to include payroll_info");
} catch (error) {
  print("❌ Error updating users schema:", error.message);
}

// 2. Add payroll_info field to existing users
print("\n👥 Adding payroll_info field to existing users...");

try {
  // First, let's check how many users we have
  const userCount = db.users.countDocuments();
  print(`📊 Found ${userCount} users in the system`);

  // Update all users to add payroll_info field if it doesn't exist
  const updateResult = db.users.updateMany(
    { "payroll_info": { $exists: false } }, // Only update users without payroll_info
    {
      $set: {
        "payroll_info": {
          current_daily_rate: 0,
          employee_number: "",
          hire_date: null,
          payroll_eligible: true, // Default to true, admins can be set to false manually
          last_pay_date: null
        },
        "updated_at": new Date()
      }
    }
  );
  
  print(`✅ Updated ${updateResult.modifiedCount} users with payroll_info field`);
  
  // Set admins to not be payroll eligible
  const adminUpdateResult = db.users.updateMany(
    { "role_name": "Admin" },
    {
      $set: {
        "payroll_info.payroll_eligible": false,
        "updated_at": new Date()
      }
    }
  );
  
  print(`✅ Set ${adminUpdateResult.modifiedCount} admin users as not payroll eligible`);
  
} catch (error) {
  print("❌ Error updating users with payroll_info:", error.message);
}

// 3. Grant payroll permissions to Admin and Supervisor roles
print("\n🔑 Granting payroll permissions to Admin and Supervisor roles...");

const payrollPermissions = [
  {
    permission_id: "payroll_view",
    permission_name: "View Payroll",
    permission_description: "Can view payroll data and reports",
    category: "PAYROLL_MANAGEMENT",
    granted: true
  },
  {
    permission_id: "payroll_manage_rates",
    permission_name: "Manage Employee Rates",
    permission_description: "Can modify employee daily rates",
    category: "PAYROLL_MANAGEMENT",
    granted: true
  },
  {
    permission_id: "payroll_manage_deductions",
    permission_name: "Manage Deductions",
    permission_description: "Can create and modify payroll deductions",
    category: "PAYROLL_MANAGEMENT",
    granted: true
  },
  {
    permission_id: "payroll_process",
    permission_name: "Process Payroll",
    permission_description: "Can process payroll runs and generate paystubs",
    category: "PAYROLL_MANAGEMENT",
    granted: true
  },
  {
    permission_id: "payroll_attendance",
    permission_name: "Manage Attendance",
    permission_description: "Can mark and modify employee attendance",
    category: "PAYROLL_MANAGEMENT",
    granted: true
  }
];

try {
  // Grant all payroll permissions to admins
  const adminUsers = db.users.find({ role_name: "Admin" }).toArray();
  
  let adminPermissionsAdded = 0;
  adminUsers.forEach(admin => {
    payrollPermissions.forEach(permission => {
      // Check if permission already exists
      const existingPermission = admin.permissions && admin.permissions.find(p => p.permission_id === permission.permission_id);
      if (!existingPermission) {
        db.users.updateOne(
          { _id: admin._id },
          {
            $push: {
              permissions: permission
            },
            $set: { updated_at: new Date() }
          }
        );
        adminPermissionsAdded++;
      }
    });
  });
  
  print(`✅ Granted ${adminPermissionsAdded} payroll permissions to ${adminUsers.length} admin users`);
  
  // Grant view and manage permissions to supervisors (not processing)
  const supervisorPermissions = payrollPermissions.filter(p => 
    p.permission_id !== "payroll_process" // Supervisors can't process payroll
  );
  
  const supervisorUsers = db.users.find({ role_name: "Supervisor" }).toArray();
  
  let supervisorPermissionsAdded = 0;
  supervisorUsers.forEach(supervisor => {
    supervisorPermissions.forEach(permission => {
      // Check if permission already exists
      const existingPermission = supervisor.permissions && supervisor.permissions.find(p => p.permission_id === permission.permission_id);
      if (!existingPermission) {
        db.users.updateOne(
          { _id: supervisor._id },
          {
            $push: {
              permissions: permission
            },
            $set: { updated_at: new Date() }
          }
        );
        supervisorPermissionsAdded++;
      }
    });
  });
  
  print(`✅ Granted ${supervisorPermissionsAdded} payroll permissions to ${supervisorUsers.length} supervisor users`);
  
} catch (error) {
  print("❌ Error granting permissions:", error.message);
}

// 4. Create sample employee numbers for existing payroll-eligible users
print("\n🔢 Creating employee numbers for payroll-eligible users...");

try {
  const payrollEligibleUsers = db.users.find({ 
    "payroll_info.payroll_eligible": true,
    "payroll_info.employee_number": ""
  }).toArray();
  
  payrollEligibleUsers.forEach((user, index) => {
    const employeeNumber = `EMP${String(index + 1).padStart(3, '0')}`;
    db.users.updateOne(
      { _id: user._id },
      {
        $set: {
          "payroll_info.employee_number": employeeNumber,
          "payroll_info.hire_date": new Date(), // Set to today as placeholder
          "updated_at": new Date()
        }
      }
    );
    print(`✅ Assigned employee number ${employeeNumber} to ${user.first_name} ${user.last_name}`);
  });
  
  print(`✅ Created employee numbers for ${payrollEligibleUsers.length} users`);
  
} catch (error) {
  print("❌ Error creating employee numbers:", error.message);
}

// 5. Insert sample payroll rates for testing
print("\n🧪 Creating sample payroll rates for testing...");

try {
  // Get some employees for sample data
  const employees = db.users.find({ 
    "role_name": { $in: ["Technician", "Manager", "Supervisor"] },
    "payroll_info.payroll_eligible": true 
  }).limit(3).toArray();
  
  if (employees.length > 0) {
    const adminUser = db.users.findOne({ role_name: "Admin" });
    
    if (adminUser) {
      employees.forEach((employee, index) => {
        // Check if rate already exists
        const existingRate = db.payroll_rates.findOne({ 
          employee_id: employee._id,
          end_date: null 
        });
        
        if (!existingRate) {
          const dailyRate = 150 + (index * 25); // $150, $175, $200
          
          // Insert sample daily rate
          const sampleRate = {
            employee_id: employee._id,
            daily_rate: dailyRate,
            rate_type: "regular",
            effective_date: new Date(),
            end_date: null,
            created_by: adminUser._id,
            created_at: new Date(),
            notes: "Initial rate setup for payroll system testing"
          };
          
          db.payroll_rates.insertOne(sampleRate);
          
          // Update user's current_daily_rate
          db.users.updateOne(
            { _id: employee._id },
            {
              $set: {
                "payroll_info.current_daily_rate": dailyRate,
                "updated_at": new Date()
              }
            }
          );
          
          print(`✅ Created sample rate for ${employee.first_name} ${employee.last_name}: AED ${dailyRate}/day`);
        } else {
          print(`⚠️  Rate already exists for ${employee.first_name} ${employee.last_name}`);
        }
      });
      
      print(`✅ Processed sample data for ${employees.length} employees`);
    } else {
      print("⚠️  No admin user found to create sample rates");
    }
  } else {
    print("⚠️  No eligible employees found for sample data");
  }
  
} catch (error) {
  print("❌ Error inserting sample data:", error.message);
}

// 6. Verification - Check what we created
print("\n🔍 Verification - Checking setup completion...");

try {
  // Check collections exist
  const hasPayrollRates = db.getCollection("payroll_rates").findOne() !== null;
  const hasPayrollAudit = db.getCollection("payroll_audit_log").findOne() !== null;
  
  print(`📋 Collections status:`);
  print(`   - payroll_rates collection: ${hasPayrollRates ? 'Exists' : 'Not found'}`);
  print(`   - payroll_audit_log collection: ${hasPayrollAudit ? 'Exists' : 'Not found'}`);
  
  // Check document counts
  const ratesCount = db.payroll_rates.countDocuments();
  const auditCount = db.payroll_audit_log.countDocuments();
  const usersWithPayrollInfo = db.users.countDocuments({ "payroll_info": { $exists: true } });
  const payrollEligibleCount = db.users.countDocuments({ "payroll_info.payroll_eligible": true });
  const usersWithPayrollPermissions = db.users.countDocuments({ 
    "permissions.permission_id": "payroll_view" 
  });
  
  print(`📊 Document counts:`);
  print(`   - Payroll rates: ${ratesCount}`);
  print(`   - Audit log entries: ${auditCount}`);
  print(`   - Users with payroll info: ${usersWithPayrollInfo}`);
  print(`   - Payroll eligible users: ${payrollEligibleCount}`);
  print(`   - Users with payroll permissions: ${usersWithPayrollPermissions}`);
  
  // Check permissions in permissions collection
  const payrollPermissionsCount = db.permissions.countDocuments({ 
    category: "PAYROLL_MANAGEMENT" 
  });
  print(`   - Payroll permissions in collection: ${payrollPermissionsCount}`);
  
  // Sample data check
  print(`\n📋 Sample Data:`);
  const sampleUser = db.users.findOne({ "payroll_info.payroll_eligible": true });
  if (sampleUser) {
    print(`   - Sample user: ${sampleUser.first_name} ${sampleUser.last_name}`);
    print(`   - Employee number: ${sampleUser.payroll_info.employee_number}`);
    print(`   - Daily rate: AED ${sampleUser.payroll_info.current_daily_rate}`);
    print(`   - Payroll eligible: ${sampleUser.payroll_info.payroll_eligible}`);
  }
  
  const sampleRate = db.payroll_rates.findOne();
  if (sampleRate) {
    print(`   - Sample rate record exists: AED ${sampleRate.daily_rate}/day`);
  }
  
} catch (error) {
  print("❌ Error during verification:", error.message);
}

print("\n🎉 Payroll System Phase 1 Setup Fix Complete!");
print("💡 Status Summary:");
print("   ✅ Database collections created");
print("   ✅ User schema updated");
print("   ✅ Payroll permissions added");
print("   ✅ Employee numbers assigned");
print("   ✅ Sample data created");
print("   ✅ Ready for backend API implementation");

print("\n📋 Quick test commands:");
print("   db.users.findOne({'payroll_info.payroll_eligible': true})");
print("   db.payroll_rates.find().pretty()");
print("   db.permissions.find({category: 'PAYROLL_MANAGEMENT'})");
print("   db.users.find({'permissions.permission_id': 'payroll_view'}).count()");