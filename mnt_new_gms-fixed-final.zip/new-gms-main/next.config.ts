import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  typescript: {
    // FIX: Enable TypeScript error checking during builds
    ignoreBuildErrors: false,
  },
  eslint: {
    // FIX: Enable ESLint during builds
    ignoreDuringBuilds: false,
  },
};

export default nextConfig;
