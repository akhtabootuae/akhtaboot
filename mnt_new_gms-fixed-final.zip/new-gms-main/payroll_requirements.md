# Garage Management System - Payroll System Requirements

## Overview
This document outlines the requirements for a payroll system within a Garage Management System (GMS). The payroll system is designed for automotive service businesses where employees are paid daily rates rather than hourly wages.

## Core Payment Model
- **Daily Rate System**: Employees are paid a fixed daily rate (not hourly or per-job)
- **Attendance-Based**: Pay is calculated based on days worked, tracked through an attendance system
- **Individual Rates**: Each employee has their own daily rate that can differ based on experience, skills, role, etc.

## Employee Daily Rate Management

### Rate Storage
- Store individual daily rates for each employee
- Allow different rates for different employees (e.g., Lead Mechanic: $200/day, Apprentice: $120/day)
- Track rate history for auditing and record-keeping purposes
- Easy rate updates for raises, promotions, or role changes

### Rate Types
- **Regular Daily Rate**: Standard workday compensation
- **Holiday/Premium Rate**: Different rates for holidays or special circumstances
- **Partial Day Handling**: Ability to handle half-days or partial attendance

## Attendance System Integration

### Data Requirements
- Pull attendance data to determine which employees worked on which days (attendence system does not exist right now, add a basic modal to allow me to force an employee to be considered as present)
- Track work status: Full Day, Half Day, Absent, Holiday, etc.
- Handle different attendance scenarios:
  - Regular workdays
  - Partial days (early departure, late arrival)
  - Holiday work
  - Overtime days (if different rate applies)

### Integration Points
- Real-time or batch sync with attendance system
- Data validation to ensure payroll accuracy

## Variable Deductions System

### Deduction Framework
- **Zero to Many**: Each employee can have no deductions or multiple deductions
- **Per-Employee Configuration**: Deductions are assigned individually, not globally
- **Active/Inactive States**: Deductions can be temporarily disabled without deletion

### Deduction Types

#### Fixed Amount Deductions
- Flat daily, weekly, or monthly amounts
- Examples: Uniform rental ($5/day), Tool loan payment ($25/week), Parking fee ($10/week)

#### Percentage-Based Deductions
- Calculated as percentage of gross pay
- Examples: Union dues (2%), Retirement contribution (5%), Insurance premium (3%)

#### Conditional Deductions
- Applied only under specific conditions
- Examples: Safety violation penalties, Equipment damage costs, Overtime meal deductions

### Common Garage Industry Deductions
- Tool purchases and loans
- Uniform and safety equipment costs
- Employee advances and loan repayments
- Insurance premiums
- Parking fees
- Training course fees
- Equipment damage/breakage costs
- Union dues

### Deduction Management Features
- Easy setup and assignment of deductions to employees
- Temporary vs. recurring deductions
- Start and end dates for time-limited deductions
- Deduction priority/order of application
- Maximum deduction limits (cannot exceed certain percentage of pay)

## Pay Calculation Process

### Calculation Flow
1. **Gross Pay Calculation**: Daily Rate × Days Worked = Gross Pay
2. **Apply Deductions**: Subtract all active employee-specific deductions
3. **Net Pay**: Final amount after all deductions
4. **Generate Documentation**: Paystub with detailed breakdown

### Pay Period Management
- Support different pay periods: Weekly, Bi-weekly, Monthly
- Calculate totals across the pay period
- Handle pay periods that span multiple months

### Paystub Generation
- Clear breakdown showing:
  - Days worked in period
  - Daily rate
  - Gross pay calculation
  - Itemized list of all deductions
  - Net pay amount
  - Year-to-date totals

## Reporting Requirements

### Labor Cost Reports
- Daily, weekly, monthly labor cost summaries
- Labor costs per employee
- Average daily labor costs across team
- Labor cost trends over time

### Employee Reports
- Individual employee pay history
- Attendance and pay correlation
- Deduction summaries per employee
- Rate change history

### Business Intelligence
- Most consistent workers (attendance tracking)
- Labor cost as percentage of revenue
- Seasonal labor cost variations
- Employee productivity metrics (if integrated with job management)

## System Features

### Flexibility Requirements
- Handle employees with no deductions
- Manage complex deduction scenarios (multiple loans, various fees)
- One-time vs. recurring deduction management
- Easy modification of employee rates and deductions

### Data Integrity
- Audit trails for all pay calculations
- Rate change approvals and logging
- Deduction modification tracking
- Payroll run history and reversibility

### User Interface Requirements
- Simple employee setup and rate configuration
- Easy deduction assignment and management
- Clear payroll review before processing
- Intuitive paystub viewing and printing

## Technical Considerations

### Data Models
- **Employee**: ID, Name, Daily Rate, Hire Date, Status
- **Rate History**: Employee, Rate, Effective Date, End Date
- **Deductions**: Type, Amount/Percentage, Frequency, Employee Assignment
- **Attendance**: Employee, Date, Status (Full/Partial/Absent)
- **Payroll Runs**: Pay Period, Employees, Calculations, Status

### Integration Points
- Attendance system API or database connection
- Potentially integrate with accounting systems
- Employee management system connection
- Tax calculation services (future consideration)

### Security Requirements
- Secure storage of payroll data (we will create a new mongodb collection/table to store this data there)
- Access controls for payroll modifications
- Audit logging for compliance (all changes must be logged. We can also create a new table)

### Key notes and instructions: 
- Analyze the above instructions and with your knowledge of our frontend and backend + db. Create a solid implemntation plan that fulfills the requirments. Explain it to me as a software developer and once I approve it you can start.
- Any DB updates will need to be done manually by via the mongoDB shell. You will also need to edit/add the models files (in the backend). Furthermore we will need update the DB seeder script to seed the new tables and apply any nesscary changes to the old ones so that they match the scehama. Keep in mind that employee info is stored in the users table (admins are not employees and do not get paid in the same way nor via the same system so ignore them for now). 

## Implementation Priority
1. **Phase 1**: Basic daily rate management and simple pay calculation
2. **Phase 2**: Variable deductions system implementation
3. **Phase 3**: Attendance system integration
4. **Phase 4**: Reporting and analytics features
5. **Phase 5**: Advanced features and optimizations
