// Complete MongoDB Fix for Error Reporting System
// This script fixes BOTH the work_orders and error_reports collections

// Step 1: Drop and recreate error_reports collection with correct schema
db.error_reports.drop();
print("Dropped existing error_reports collection");

db.createCollection("error_reports", {
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: [
        "workOrderId", 
        "partIndex", 
        "stageIndex", 
        "reportedStageId",
        "problematicStageIndex", 
        "reportingTechnicianId", 
        "problematicTechnicianId", 
        "reportType",
        "issueDescription", 
        "imageUrl", 
        "timestamp", 
        "status"
      ],
      properties: {
        workOrderId: {
          bsonType: "objectId",
          description: "Reference to main work order"
        },
        partIndex: {
          bsonType: "int",
          description: "Index of part in work order parts array"
        },
        stageIndex: {
          bsonType: "int",
          description: "Index of stage where error was reported"
        },
        reportedStageId: {
          bsonType: "objectId",
          description: "Stage ID where error was reported"
        },
        problematicStageIndex: {
          bsonType: "int",
          description: "Index of stage that has the issue"
        },
        reportingTechnicianId: {
          bsonType: "objectId",
          description: "Technician who reported the issue"
        },
        problematicTechnicianId: {
          bsonType: "objectId",
          description: "Technician who worked on problematic stage"
        },
        reportType: {
          bsonType: "string",
          enum: ["forward", "revert"],
          description: "Type of error report"
        },
        issueDescription: {
          bsonType: "string",
          minLength: 10,
          description: "Detailed description of the issue"
        },
        imageUrl: {
          bsonType: "string",
          description: "URL of uploaded evidence image"
        },
        timestamp: {
          bsonType: "date",
          description: "When error was reported"
        },
        status: {
          bsonType: "string",
          enum: ["pending", "acknowledged", "resolved"],
          description: "Current status of error report"
        },
        stagesToRedo: {
          bsonType: "array",
          items: {
            bsonType: "int"
          },
          description: "Array of stage indices that need to be redone"
        },
        created_at: {
          bsonType: "date",
          description: "Document creation timestamp"
        },
        updated_at: {
          bsonType: "date",
          description: "Document last update timestamp"
        }
      }
    }
  }
});

// Create indexes for error_reports
db.error_reports.createIndex({ workOrderId: 1 });
db.error_reports.createIndex({ partIndex: 1 });
db.error_reports.createIndex({ reportingTechnicianId: 1 });
db.error_reports.createIndex({ problematicTechnicianId: 1 });
db.error_reports.createIndex({ timestamp: -1 });
db.error_reports.createIndex({ status: 1 });
print("Created error_reports collection with indexes");

// Step 2: Update work_orders collection validator
db.runCommand({
  collMod: "work_orders",
  validator: {
    $jsonSchema: {
      bsonType: 'object',
      required: [
        'workOrderNumber',
        'customer_id',
        'vehicle_id',
        'status',
        'createdAt',
        'parts'
      ],
      properties: {
        workOrderNumber: {
          bsonType: 'string',
          description: 'Unique identifier for this work order'
        },
        customer_id: {
          bsonType: 'objectId',
          description: 'Reference to a customer document'
        },
        vehicle_id: {
          bsonType: 'int',
          description: 'ID of the vehicle in customer\'s vehicles array'
        },
        status: {
          'enum': [
            'open',
            'in_progress',
            'on_hold',
            'completed',
            'closed'
          ],
          description: 'Overall status of the work order'
        },
        description: {
          bsonType: 'string',
          description: 'detailed description of the work to be performed'
        },
        createdAt: {
          bsonType: 'date',
          description: 'Work order creation timestamp'
        },
        updatedAt: {
          bsonType: 'date',
          description: 'Last update timestamp'
        },
        parts: {
          bsonType: 'array',
          minItems: 1,
          description: 'Sub-workorders split by vehicle part',
          items: {
            bsonType: 'object',
            required: [
              'partName',
              'variationId',
              'status',
              'stages',
              'createdAt'
            ],
            properties: {
              partName: {
                bsonType: 'string',
                description: 'e.g. \'left door\', \'engine\''
              },
              variationId: {
                bsonType: 'objectId',
                description: 'Refers to a document in `variations`'
              },
              status: {
                'enum': [
                  'pending',
                  'in_progress',
                  'completed',
                  'cancelled'
                ],
                description: 'Status of this part\'s overall work'
              },
              assignedTo: {
                bsonType: 'objectId',
                description: 'Technician _id'
              },
              createdAt: {
                bsonType: 'date',
                description: 'Timestamp when this part was added'
              },
              updatedAt: {
                bsonType: 'date',
                description: 'Timestamp of last change to this part'
              },
              cancellationReason: {
                bsonType: 'string',
                description: 'Reason for cancellation if cancelled'
              },
              approvalImage: {
                bsonType: 'string',
                description: 'Image URL for cancellation approval'
              },
              stages: {
                bsonType: 'array',
                minItems: 1,
                description: 'Workflow stages for this part',
                items: {
                  bsonType: 'object',
                  required: [
                    'stageId',
                    'status',
                    'logs',
                    'createdAt'
                  ],
                  properties: {
                    stageId: {
                      bsonType: 'objectId',
                      description: 'Refers to a document in `stages`'
                    },
                    status: {
                      'enum': [
                        'pending',
                        'in_progress',
                        'completed',
                        'paused'
                      ],
                      description: 'Status of this stage'
                    },
                    assignedTo: {
                      bsonType: 'objectId',
                      description: 'Technician _id for this stage'
                    },
                    createdAt: {
                      bsonType: 'date',
                      description: 'Stage start timestamp'
                    },
                    updatedAt: {
                      bsonType: 'date',
                      description: 'Stage last update timestamp'
                    },
                    // ERROR REPORTING FIELDS
                    hasIssue: {
                      bsonType: 'bool',
                      description: 'Flag indicating if this stage has reported issues'
                    },
                    errorReportIds: {
                      bsonType: 'array',
                      items: {
                        bsonType: 'objectId'
                      },
                      description: 'Array of error report IDs associated with this stage'
                    },
                    needsRedo: {
                      bsonType: 'bool',
                      description: 'Flag indicating if stage needs to be redone'
                    },
                    originalCompletionTime: {
                      bsonType: ['date', 'null'],
                      description: 'Original completion time before revert'
                    },
                    estimatedHours: {
                      bsonType: 'number',
                      description: 'Estimated hours for this stage'
                    },
                    actualHours: {
                      bsonType: 'number',
                      description: 'Actual hours spent on this stage'
                    },
                    logs: {
                      bsonType: 'array',
                      description: 'Time-log entries for this stage',
                      items: {
                        bsonType: 'object',
                        required: [
                          'timestamp',
                          'action'
                        ],
                        properties: {
                          timestamp: {
                            bsonType: 'date',
                            description: 'When the action occurred'
                          },
                          action: {
                            'enum': [
                              'start',
                              'pause',
                              'resume',
                              'complete'
                            ],
                            description: 'Type of time-log event'
                          },
                          note: {
                            bsonType: 'string',
                            description: 'Optional comment'
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        },
        cancelledParts: {
          bsonType: 'array',
          items: {
            bsonType: 'object',
            properties: {
              partName: {
                bsonType: 'string'
              },
              cancelledAt: {
                bsonType: 'date'
              },
              reason: {
                bsonType: 'string'
              },
              approvalImage: {
                bsonType: 'string'
              }
            }
          }
        }
      }
    }
  }
});
print("Updated work_orders validation schema");

// Step 3: Add error reporting fields to existing work order stages
db.work_orders.updateMany(
  { "parts.stages": { $exists: true } },
  {
    $set: {
      "parts.$[].stages.$[stage].hasIssue": false,
      "parts.$[].stages.$[stage].errorReportIds": [],
      "parts.$[].stages.$[stage].needsRedo": false
    }
  },
  {
    arrayFilters: [
      { "stage": { $exists: true } }
    ]
  }
);
print("Added error reporting fields to existing stages");

// Step 4: Also update the API models to ensure they're in sync
print("\n⚠️  IMPORTANT: You also need to update the API model validation!");
print("Update /Users/bashir/Documents/GitHub/new_api/models/ErrorReport.js");
print("Update /Users/bashir/Documents/GitHub/new_api/models/WorkOrder.js");
print("to match these schemas");

// Step 5: Verify everything
print("\n=== VERIFICATION ===");
var errorReportsCount = db.error_reports.countDocuments({});
print(`Error reports collection exists with ${errorReportsCount} documents`);

var workOrdersCount = db.work_orders.countDocuments({});
print(`Work orders collection has ${workOrdersCount} documents`);

// Show sample
var sample = db.work_orders.findOne({}, { parts: { $slice: 1 } });
if (sample && sample.parts && sample.parts[0] && sample.parts[0].stages && sample.parts[0].stages[0]) {
  print("\nSample stage with error reporting fields:");
  printjson({
    stageId: sample.parts[0].stages[0].stageId,
    hasIssue: sample.parts[0].stages[0].hasIssue,
    errorReportIds: sample.parts[0].stages[0].errorReportIds,
    needsRedo: sample.parts[0].stages[0].needsRedo
  });
}

print("\n✅ Error reporting system database setup completed!");
print("Now restart your API server for changes to take effect.");