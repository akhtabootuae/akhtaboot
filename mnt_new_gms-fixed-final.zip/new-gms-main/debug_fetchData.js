// Temporary debug version of fetchData function
// Add this to the attendance page temporarily to see what's happening

const fetchDataDebug = async () => {
  try {
    setLoading(true);
    setError(null);

    console.log('🔍 Starting fetchData debug...');

    // Fetch employees
    console.log('📋 Fetching employees...');
    const employeesResponse = await payrollApi.getEmployees();
    console.log('👥 Employees response:', employeesResponse);
    setEmployees(employeesResponse.employees || []);

    // Fetch time sheets with filters
    const timeSheetsFilters = {
      ...filters,
      page: 1,
      limit: 50
    };

    // Remove empty filters
    Object.keys(timeSheetsFilters).forEach(key => {
      if (!timeSheetsFilters[key as keyof typeof timeSheetsFilters]) {
        delete timeSheetsFilters[key as keyof typeof timeSheetsFilters];
      }
    });

    console.log('🔍 Timesheet filters:', timeSheetsFilters);
    console.log('⏰ Fetching timesheets...');
    
    const timeSheetsResponse = await payrollApi.getTimeSheets(timeSheetsFilters);
    console.log('📊 Raw timesheets response:', timeSheetsResponse);
    console.log('📊 Response type:', typeof timeSheetsResponse);
    console.log('📊 Response keys:', Object.keys(timeSheetsResponse || {}));
    
    if (timeSheetsResponse) {
      if (timeSheetsResponse.timesheets) {
        console.log('✅ Found timesheets array:', timeSheetsResponse.timesheets.length, 'items');
        setTimeSheets(timeSheetsResponse.timesheets);
      } else if (Array.isArray(timeSheetsResponse)) {
        console.log('⚠️ Response is array directly:', timeSheetsResponse.length, 'items');
        setTimeSheets(timeSheetsResponse);
      } else {
        console.log('❌ Unexpected response structure');
        console.log('Available properties:', Object.keys(timeSheetsResponse));
        setTimeSheets([]);
      }
    } else {
      console.log('❌ No response received');
      setTimeSheets([]);
    }

  } catch (err: any) {
    console.error('❌ Error in fetchData:', err);
    console.error('Error details:', {
      message: err.message,
      response: err.response,
      status: err.response?.status,
      data: err.response?.data
    });
    setError(err.response?.data?.message || 'Failed to fetch attendance data');
  } finally {
    setLoading(false);
  }
};

// Instructions:
// 1. Replace the current fetchData function in attendance page with fetchDataDebug
// 2. Check the console output when the page loads
// 3. This will show you exactly what response structure you're getting