// Helper functions to handle different work order data structures from the API

interface PartialCustomer {
  name?: string;
  fullName?: string;
  customerName?: string;
  phone?: string;
  phoneNumber?: string;
  mobile?: string;
  email?: string;
  emailAddress?: string;
}

interface PartialVehicle {
  make?: string;
  manufacturer?: string;
  model?: string;
  year?: string | number;
  modelYear?: string | number;
  color?: string;
  colour?: string;
  licensePlate?: string;
  license_plate?: string;
  plateNumber?: string;
  vin?: string;
  VIN?: string;
}

interface PartialUser {
  name?: string;
  fullName?: string;
  userName?: string;
}

interface WorkOrderPart {
  assignedTo?: string | PartialUser;
  stages?: Array<{
    assignedTo?: string | PartialUser;
  }>;
}

export interface FlexibleWorkOrder {
  _id: string;
  workOrderNumber: string;
  status: string;
  priority: string;
  createdAt: string;
  totalEstimatedHours: number;
  totalActualHours: number;
  expected_days?: number;
  expected_hours?: number;
  expected_completion_date?: string;
  // Support multiple possible field names
  customerDetails?: PartialCustomer;
  customer?: PartialCustomer;
  customer_details?: PartialCustomer;
  customer_id?: string;
  customerId?: string;
  vehicleDetails?: PartialVehicle;
  vehicle?: PartialVehicle;
  vehicle_details?: PartialVehicle;
  vehicleInfo?: PartialVehicle;
  vehicle_id?: string;
  vehicleId?: string;
  supervisor?: string | PartialUser;
  supervisorId?: string;
  supervisor_id?: string;
  assignedTo?: string | PartialUser;
  assigned_to?: string | PartialUser;
  assignedToId?: string;
  assigned_technician?: string | PartialUser;
  supervisorDetails?: PartialUser;
  supervisorName?: string;
  supervisor_name?: string;
  technicianName?: string;
  technician_name?: string;
  parts?: WorkOrderPart[];
  [key: string]: unknown;
}

// Extract customer information from various possible structures
export const getCustomerInfo = (order: FlexibleWorkOrder) => {
  // Try different field names
  const customer = order.customerDetails || order.customer || order.customer_details || order.customer_id;
  
  if (customer && typeof customer === 'object' && customer.name) {
    return {
      name: customer.name || customer.fullName || customer.customerName || 'Unknown Customer',
      phone: customer.phone || customer.phoneNumber || customer.mobile || '',
      email: customer.email || customer.emailAddress || ''
    };
  }
  
  // If we only have an ID, return placeholder
  if (order.customerId || order.customer_id) {
    return {
      name: 'Customer data not loaded',
      phone: 'Populate required',
      email: ''
    };
  }
  
  return {
    name: 'Unknown Customer',
    phone: '',
    email: ''
  };
};

// Extract vehicle information from various possible structures
export const getVehicleInfo = (order: FlexibleWorkOrder) => {
  // Try different field names
  const vehicle = order.vehicleDetails || order.vehicle || order.vehicle_details || order.vehicleInfo || order.vehicle_id;
  
  if (vehicle && typeof vehicle === 'object' && (vehicle.make || vehicle.model)) {
    return {
      make: vehicle.make || vehicle.manufacturer || '',
      model: vehicle.model || '',
      year: vehicle.year || vehicle.modelYear || '',
      color: vehicle.color || vehicle.colour || '',
      licensePlate: vehicle.licensePlate || vehicle.license_plate || vehicle.plateNumber || '',
      vin: vehicle.vin || vehicle.VIN || '',
      display: function() {
        if (this.year && this.make && this.model) {
          return `${this.year} ${this.make} ${this.model}`;
        }
        if (this.make && this.model) {
          return `${this.make} ${this.model}`;
        }
        return 'Unknown Vehicle';
      }
    };
  }
  
  // If we only have an ID, return placeholder
  if (order.vehicleId || order.vehicle_id) {
    return {
      make: '',
      model: '',
      year: '',
      color: '',
      licensePlate: 'Vehicle data not loaded',
      vin: '',
      display: () => 'Vehicle data not loaded'
    };
  }
  
  return {
    make: '',
    model: '',
    year: '',
    color: '',
    licensePlate: '',
    vin: '',
    display: () => 'Unknown Vehicle'
  };
};

// Extract supervisor information from various possible structures
export const getSupervisorInfo = (order: FlexibleWorkOrder) => {
  // Check if supervisor is a string (name directly or ID)
  if (typeof order.supervisor === 'string' && order.supervisor) {
    // If it looks like an ObjectId, return it for resolution
    if (/^[a-fA-F0-9]{24}$/.test(order.supervisor)) {
      return order.supervisor;
    }
    return order.supervisor;
  }
  
  // Check if supervisor is an object, or if assignedTo/assigned_to are IDs
  const supervisor = order.supervisor || order.assignedTo || order.assigned_to || order.supervisorDetails;
  
  if (supervisor) {
    if (typeof supervisor === 'object') {
      return supervisor.name || supervisor.fullName || supervisor.userName || 'Unassigned';
    } else if (typeof supervisor === 'string') {
      // If it looks like an ObjectId, return it for resolution
      if (/^[a-fA-F0-9]{24}$/.test(supervisor)) {
        return supervisor;
      }
      return supervisor;
    }
  }
  
  // Check parts array for assignedTo technicians (supervisor role)
  if (order.parts && Array.isArray(order.parts) && order.parts.length > 0) {
    // Find the first assigned technician in parts
    for (const part of order.parts) {
      if (part.assignedTo) {
        if (typeof part.assignedTo === 'string') {
          // If it's just an ID, try to get the name from assigned_technician field
          if (order.assigned_technician && typeof order.assigned_technician === 'object' && order.assigned_technician.name) {
            return order.assigned_technician.name;
          }
          // If it looks like an ObjectId, return it for resolution
          if (/^[a-fA-F0-9]{24}$/.test(part.assignedTo)) {
            return part.assignedTo;
          }
          // Return the string value if it's a name
          return part.assignedTo;
        } else if (typeof part.assignedTo === 'object' && part.assignedTo.name) {
          return part.assignedTo.name;
        }
      }
      
      // Check stages within parts for assignedTo
      if (part.stages && Array.isArray(part.stages)) {
        for (const stage of part.stages) {
          if (stage.assignedTo) {
            if (typeof stage.assignedTo === 'string' && /^[a-fA-F0-9]{24}$/.test(stage.assignedTo)) {
              return stage.assignedTo;
            } else if (typeof stage.assignedTo === 'object' && stage.assignedTo.name) {
              return stage.assignedTo.name;
            }
          }
        }
      }
    }
  }
  
  // Check for assigned_technician field directly
  if (order.assigned_technician) {
    if (typeof order.assigned_technician === 'string') {
      // If it looks like an ObjectId, return it for resolution
      if (/^[a-fA-F0-9]{24}$/.test(order.assigned_technician)) {
        return order.assigned_technician;
      }
      return order.assigned_technician;
    } else if (typeof order.assigned_technician === 'object' && order.assigned_technician.name) {
      return order.assigned_technician.name;
    }
  }
  
  // Check alternative supervisor field names
  const alternativeSupervisor = order.supervisorName || order.supervisor_name || order.technicianName || order.technician_name;
  if (alternativeSupervisor && typeof alternativeSupervisor === 'string') {
    return alternativeSupervisor;
  }
  
  // If we only have an ID, return the ID so it can be resolved
  if (order.supervisorId || order.supervisor_id || order.assignedToId) {
    return order.supervisorId || order.supervisor_id || order.assignedToId;
  }
  
  return 'Unassigned';
};

// Format status for display
export const formatStatus = (status: string) => {
  if (!status) return 'Unknown';
  
  // Treat 'open' as 'pending'
  if (status.toLowerCase() === 'open') {
    return 'Pending';
  }
  
  // Special formatting for QA Review
  if (status.toLowerCase().replace(/[\s-_]/g, '') === 'qareview') {
    return 'QA Review';
  }
  
  return status
    .replace(/_/g, ' ')
    .replace(/-/g, ' ')
    .split(' ')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(' ');
};

// Get status badge CSS classes
export const getStatusBadgeClasses = (status: string) => {
  const normalizedStatus = status?.toLowerCase().replace(/[\s-_]/g, '');
  
  switch (normalizedStatus) {
    case 'completed':
    case 'complete':
    case 'done':
      return "bg-green-100 text-green-800";
    case 'inprogress':
    case 'active':
    case 'ongoing':
      return "bg-blue-100 text-blue-800";
    case 'qareview':
    case 'review':
    case 'qacheck':
      return "bg-purple-100 text-purple-800";
    case 'paused':
    case 'onhold':
    case 'hold':
      return "bg-yellow-100 text-yellow-800";
    case 'pending':
    case 'new':
    case 'open':
      return "bg-white text-gray-800 border border-gray-300";
    case 'inneedofqa':
    case 'needqa':
    case 'needsqa':
      return "bg-orange-100 text-orange-800";
    case 'cancelled':
    case 'canceled':
    case 'closed':
      return "bg-red-100 text-red-800";
    default:
      return "bg-gray-100 text-gray-800";
  }
};

// Get status summary card color
export const getStatusSummaryColor = (status: string) => {
  const normalizedStatus = status?.toLowerCase().replace(/[\s-_]/g, '');
  
  switch (normalizedStatus) {
    case 'completed':
    case 'complete':
    case 'done':
      return "text-green-600";
    case 'inprogress':
    case 'active':
    case 'ongoing':
      return "text-blue-600";
    case 'qareview':
    case 'review':
    case 'qacheck':
      return "text-purple-600";
    case 'paused':
    case 'onhold':
    case 'hold':
      return "text-yellow-600";
    case 'pending':
    case 'new':
    case 'open':
      return "text-gray-600";
    case 'inneedofqa':
    case 'needqa':
    case 'needsqa':
      return "text-orange-600";
    case 'cancelled':
    case 'canceled':
    case 'closed':
      return "text-red-600";
    default:
      return "text-gray-600";
  }
};

// Get priority badge CSS classes
export const getPriorityBadgeClasses = (priority: string) => {
  const normalizedPriority = priority?.toLowerCase();
  
  switch (normalizedPriority) {
    case 'urgent':
    case 'critical':
    case 'emergency':
      return "bg-red-100 text-red-800";
    case 'high':
    case 'important':
      return "bg-orange-100 text-orange-800";
    case 'medium':
    case 'normal':
    case 'standard':
      return "bg-yellow-100 text-yellow-800";
    case 'low':
    case 'minor':
      return "bg-green-100 text-green-800";
    default:
      return "bg-gray-100 text-gray-800";
  }
};