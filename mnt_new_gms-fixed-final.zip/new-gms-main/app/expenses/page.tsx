'use client';

import React from 'react';
import ProtectedRoute from '../../components/ProtectedRoute';
import { useAuth } from '../context/AuthContext';
import {
  ExpenseFilters,
  ExpenseTable,
  ExpenseStats,
  LoadingSpinner,
  ErrorMessage,
  ExpenseFormModal,
  useExpenseFilters
} from '../components/Expenses';

export default function ExpensesPage() {
  const { user } = useAuth();
  const {
    expenses,
    statistics,
    loading,
    error,
    search,
    setSearch,
    category,
    setCategory,
    startDate,
    setStartDate,
    endDate,
    setEndDate,
    vendor,
    setVendor,
    clearFilters,
    fetchExpenses,
    fetchStatistics,
    createExpense,
    updateExpense,
  } = useExpenseFilters();


  const [showCreateModal, setShowCreateModal] = React.useState(false);
  const [selectedExpense, setSelectedExpense] = React.useState<any>(null);

  const handleCreateExpense = async (expenseData: any) => {
    try {
      await createExpense(expenseData);
      setShowCreateModal(false);
      fetchExpenses();
      fetchStatistics();
    } catch (error: any) {
      // Error is already handled by the hook and displayed to user
      console.error('Error creating expense:', error);
    }
  };

  const handleEditExpense = async (expenseData: any) => {
    try {
      if (selectedExpense) {
        await updateExpense(selectedExpense._id, expenseData);
        setSelectedExpense(null);
        fetchExpenses();
        fetchStatistics();
      }
    } catch (error: any) {
      // Error is already handled by the hook and displayed to user
      console.error('Error updating expense:', error);
    }
  };

  return (
    <ProtectedRoute>
      <div className="p-6 bg-gray-50 min-h-screen">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900">Expense Management</h1>
            <button
              onClick={() => setShowCreateModal(true)}
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium transition-colors"
            >
              Add New Expense
            </button>
          </div>

          {/* Statistics Cards */}
          {statistics && (
            <ExpenseStats statistics={statistics} />
          )}

          {/* Filters */}
          <ExpenseFilters
            search={search}
            setSearch={setSearch}
            category={category}
            setCategory={setCategory}
            startDate={startDate}
            setStartDate={setStartDate}
            endDate={endDate}
            setEndDate={setEndDate}
            vendor={vendor}
            setVendor={setVendor}
            onClearFilters={clearFilters}
          />

          {/* Content */}
          {loading ? (
            <LoadingSpinner />
          ) : error ? (
            <ErrorMessage message={error} />
          ) : (
            <ExpenseTable
              expenses={expenses}
              onEdit={setSelectedExpense}
            />
          )}

          {/* Modals */}
          {showCreateModal && (
            <ExpenseFormModal
              isOpen={showCreateModal}
              onClose={() => setShowCreateModal(false)}
              onSubmit={handleCreateExpense}
              title="Create New Expense"
            />
          )}

          {selectedExpense && (
            <ExpenseFormModal
              isOpen={true}
              onClose={() => setSelectedExpense(null)}
              onSubmit={handleEditExpense}
              expense={selectedExpense}
              title="Edit Expense"
            />
          )}
        </div>
      </div>
    </ProtectedRoute>
  );
}
