'use client';

import React, { useState } from 'react';
import ProtectedRoute from '../../../components/ProtectedRoute';
import { LoadingSpinner, ErrorMessage } from '../../components/Expenses';
import type { ExpenseLog } from '../../types/expense-logs';
import { 
  ExpenseLogsFilters,
  ExpenseLogsTable,
  ExpenseLogDetailsModal,
  Pagination,
  useExpenseLogs
} from '../../components/Expenses/Logs';

export default function ExpenseLogsPage() {
  const [selectedLog, setSelectedLog] = useState<ExpenseLog | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const {
    // Data
    logs,
    pagination,
    loading,
    error,

    // Filters
    search: searchTerm,
    setSearch: setSearchTerm,
    selectedUserId,
    setSelectedUserId,
    selectedAction,
    setSelectedAction,
    selectedSeverity,
    setSelectedSeverity,
    selectedCategory,
    setSelectedCategory,
    startDate,
    setStartDate,
    endDate,
    setEndDate,

    // Actions
    fetchLogs,
    searchLogs,
    exportLogs,
    clearFilters,
    setPage,
    setPageSize,
  } = useExpenseLogs();

  // Create filters object from individual filter states
  const filters = {
    user_id: selectedUserId,
    action: selectedAction,
    severity: selectedSeverity,
    category: selectedCategory,
    start_date: startDate,
    end_date: endDate
  };

  const setFilters = (newFilters: any) => {
    setSelectedUserId(newFilters.user_id || '');
    setSelectedAction(newFilters.action || '');
    setSelectedSeverity(newFilters.severity || '');
    setSelectedCategory(newFilters.category || '');
    setStartDate(newFilters.start_date || '');
    setEndDate(newFilters.end_date || '');
  };

  const handleViewDetails = (log: ExpenseLog) => {
    setSelectedLog(log);
    setIsModalOpen(true);
  };

  const handleCloseDetails = () => {
    setSelectedLog(null);
    setIsModalOpen(false);
  };

  const handleSearch = async () => {
    await searchLogs(searchTerm);
  };

  const handleExport = async (format: 'csv' | 'json') => {
    try {
      await exportLogs(format);
    } catch (error) {
      console.error('Export failed:', error);
      // You could show a toast notification here
    }
  };

  const handleRefresh = async () => {
    await fetchLogs();
  };

  return (
    <ProtectedRoute>
      <div className="min-h-full bg-gray-50">
        <div className="w-full px-3 sm:px-4 md:px-6 lg:px-8 py-4 md:py-6">
          {/* Header */}
          <div className="mb-4 md:mb-6 lg:mb-8">
            <h1 className="text-lg sm:text-xl md:text-2xl lg:text-3xl font-bold text-gray-900">Expense Logs</h1>
            <p className="text-sm md:text-base text-gray-600 mt-1 max-w-4xl">
              View and analyze all expense-related activity and audit trails
            </p>
          </div>

          {/* Filters */}
          <ExpenseLogsFilters
            searchTerm={searchTerm}
            onSearchChange={setSearchTerm}
            onSearch={handleSearch}
            filters={filters}
            onFiltersChange={setFilters}
            onClearFilters={clearFilters}
            onExport={handleExport}
            onRefresh={handleRefresh}
            searchLoading={loading}
            exportLoading={loading}
          />

          {/* Error Message */}
          {error && (
            <div className="mb-6">
              <ErrorMessage message={error} />
            </div>
          )}

          {/* Loading State */}
          {loading && logs.length === 0 ? (
            <LoadingSpinner />
          ) : (
            <>
              {/* Results Summary */}
              {logs.length > 0 && (
                <div className="bg-white rounded-lg shadow-sm border border-gray-200 px-3 sm:px-4 lg:px-6 py-3 md:py-4 mb-4 md:mb-6">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 sm:gap-4">
                    <div className="text-xs sm:text-sm text-gray-700">
                      Showing <span className="font-medium">{logs.length}</span> of{' '}
                      <span className="font-medium">{pagination.totalLogs.toLocaleString()}</span> log entries
                    </div>
                    <div className="text-xs sm:text-sm text-gray-500">
                      Page {pagination.currentPage} of {pagination.totalPages}
                    </div>
                  </div>
                </div>
              )}

              {/* Logs Table */}
              <ExpenseLogsTable
                logs={logs}
                loading={loading}
                error={error}
                onViewDetails={handleViewDetails}
              />

              {/* Pagination */}
              {logs.length > 0 && pagination.totalPages > 1 && (
                <div className="mt-4 md:mt-6 lg:mt-8">
                  <Pagination
                    currentPage={pagination.currentPage}
                    totalPages={pagination.totalPages}
                    totalItems={pagination.totalLogs}
                    itemsPerPage={50}
                    onPageChange={setPage}
                    onItemsPerPageChange={setPageSize}
                    loading={loading}
                  />
                </div>
              )}

              {/* No Data State */}
              {!loading && logs.length === 0 && (
                <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 sm:p-8 lg:p-12 text-center mx-auto max-w-2xl">
                  <svg className="mx-auto h-10 w-10 sm:h-12 sm:w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                  <h3 className="mt-2 text-sm md:text-base font-medium text-gray-900">No expense logs found</h3>
                  <p className="mt-1 text-xs sm:text-sm text-gray-500 max-w-md mx-auto leading-relaxed">
                    {searchTerm || Object.values(filters).some(v => v) 
                      ? 'No logs match your current search criteria. Try adjusting your filters.'
                      : 'No expense activity has been logged yet.'
                    }
                  </p>
                  <div className="mt-4 md:mt-6">
                    <button
                      onClick={handleRefresh}
                      disabled={loading}
                      className="inline-flex items-center px-3 sm:px-4 py-2 border border-transparent shadow-sm text-xs sm:text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                    >
                      <svg className={`-ml-1 mr-2 h-4 w-4 sm:h-5 sm:w-5 ${loading ? 'animate-spin' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                      </svg>
                      Refresh Logs
                    </button>
                  </div>
                </div>
              )}
            </>
          )}

          {/* Log Details Modal */}
          <ExpenseLogDetailsModal
            log={selectedLog}
            isOpen={isModalOpen}
            onClose={handleCloseDetails}
          />
        </div>
      </div>
    </ProtectedRoute>
  );
}
