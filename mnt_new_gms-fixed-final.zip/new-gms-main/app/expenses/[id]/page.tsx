'use client';

import React, { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import ProtectedRoute from '../../../components/ProtectedRoute';
import { ExpenseResponse, getPaymentMethodDisplay } from '../../types/expense';
import { fetchExpenseById, updateExpense } from '../../../services/api';
import DocumentViewer from '@/app/components/ui/DocumentViewer';
import {
  LoadingSpinner,
  ErrorMessage,
  ExpenseFormModal,
  Breadcrumb
} from '../../components/Expenses';

export default function ExpenseDetailsPage() {
  const params = useParams();
  const router = useRouter();
  const expenseId = params.id as string;

  const [expense, setExpense] = useState<ExpenseResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [documentViewer, setDocumentViewer] = useState({
    isOpen: false,
    url: '',
    filename: ''
  });

  useEffect(() => {
    fetchExpenseDetails();
  }, [expenseId]);

  const fetchExpenseDetails = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await fetchExpenseById(expenseId);
      setExpense(response.data || response);
    } catch (err: any) {
      console.error('Error fetching expense details:', err);
      setError(err.message || 'Failed to fetch expense details');
    } finally {
      setLoading(false);
    }
  };

  const handleEditExpense = async (expenseData: any) => {
    try {
      await updateExpense(expenseId, expenseData);
      setShowEditModal(false);
      fetchExpenseDetails();
    } catch (error: any) {
      console.error('Error updating expense:', error);
      setError('Failed to update expense');
    }
  };

  const handleViewInvoiceImage = () => {
    if (expense?.invoice_image) {
      setDocumentViewer({
        isOpen: true,
        url: expense.invoice_image.signedUrl || expense.invoice_image.url,
        filename: expense.invoice_image.filename
      });
    }
  };

  const handleViewReceiptImage = (image: any, index: number) => {
    setDocumentViewer({
      isOpen: true,
      url: image.url,
      filename: image.title || `Receipt ${index + 1}`
    });
  };



  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-AE', {
      style: 'currency',
      currency: 'AED'
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  if (loading) {
    return (
      <ProtectedRoute>
        <div className="p-6 bg-gray-50 min-h-screen">
          <LoadingSpinner />
        </div>
      </ProtectedRoute>
    );
  }

  if (error) {
    return (
      <ProtectedRoute>
        <div className="p-6 bg-gray-50 min-h-screen">
          <ErrorMessage message={error} />
        </div>
      </ProtectedRoute>
    );
  }

  if (!expense) {
    return (
      <ProtectedRoute>
        <div className="p-6 bg-gray-50 min-h-screen">
          <ErrorMessage message="Expense not found" />
        </div>
      </ProtectedRoute>
    );
  }

  return (
    <ProtectedRoute>
      <div className="p-6 bg-gray-50 min-h-screen">
        <div className="max-w-4xl mx-auto">
          {/* Breadcrumb */}
          <Breadcrumb
            items={[
              { label: 'Home', href: '/' },
              { label: 'Expenses', href: '/expenses' },
              { label: expense.expense_number }
            ]}
          />

          {/* Header */}
          <div className="flex justify-between items-center mb-8">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => router.back()}
                className="text-gray-600 hover:text-gray-800 p-2 rounded-lg hover:bg-gray-200 transition-colors"
              >
                ← Back
              </button>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Expense Details</h1>
                <p className="text-gray-600">{expense.expense_number}</p>
              </div>
            </div>
            <div className="flex space-x-3">
              <button
                onClick={() => setShowEditModal(true)}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium transition-colors"
              >
                Edit Expense
              </button>
            </div>
          </div>

          {/* Main Content */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column - Main Details */}
            <div className="lg:col-span-2 space-y-6">
              {/* Basic Information Card */}
              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Basic Information</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Description
                    </label>
                    <p className="text-gray-900 font-medium">
                      {expense.description || expense.title}
                    </p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Amount
                    </label>
                    <p className="text-2xl font-bold text-gray-900">
                      {formatCurrency(expense.amount)}
                    </p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Category
                    </label>
                    <p className="text-gray-900 capitalize">
                      {expense.expense_type?.replace(/_/g, ' ')}
                    </p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Date
                    </label>
                    <p className="text-gray-900">
                      {formatDate(expense.date)}
                    </p>
                  </div>
                  {expense.vendor && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Vendor
                      </label>
                      <p className="text-gray-900">{expense.vendor}</p>
                    </div>
                  )}
                  {expense.invoice_number && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Invoice Number
                      </label>
                      <p className="text-gray-900">{expense.invoice_number}</p>
                    </div>
                  )}
                  {expense.payment_method && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Payment Method
                      </label>
                      <p className="text-gray-900">
                        {getPaymentMethodDisplay(expense.payment_method)}
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* Notes Card */}
              {expense.notes && (
                <div className="bg-white rounded-lg shadow-md p-6">
                  <h2 className="text-xl font-semibold text-gray-900 mb-4">Notes</h2>
                  <p className="text-gray-700 whitespace-pre-wrap">{expense.notes}</p>
                </div>
              )}

              {/* Tags Card */}
              {expense.tags && expense.tags.length > 0 && (
                <div className="bg-white rounded-lg shadow-md p-6">
                  <h2 className="text-xl font-semibold text-gray-900 mb-4">Tags</h2>
                  <div className="flex flex-wrap gap-2">
                    {expense.tags.map((tag, index) => (
                      <span
                        key={index}
                        className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-blue-100 text-blue-800"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Receipt Images */}
              {expense.receipt_images && expense.receipt_images.length > 0 && (
                <div className="bg-white rounded-lg shadow-md p-6">
                  <h2 className="text-xl font-semibold text-gray-900 mb-4">Receipt Images</h2>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {expense.receipt_images.map((image, index) => (
                      <div key={index} className="relative">
                        <img
                          src={image.url}
                          alt={image.title || `Receipt ${index + 1}`}
                          className="w-full h-32 object-cover rounded-lg border border-gray-200 cursor-pointer hover:shadow-md transition-shadow"
                          onClick={() => handleViewReceiptImage(image, index)}
                        />
                        <button
                          onClick={() => handleViewReceiptImage(image, index)}
                          className="absolute inset-0 bg-black bg-opacity-0 hover:bg-opacity-30 transition-all duration-200 flex items-center justify-center rounded-lg"
                        >
                          <span className="text-white opacity-0 hover:opacity-100 transition-opacity">
                            🔍 View Full Size
                          </span>
                        </button>
                        {image.title && (
                          <p className="text-xs text-gray-600 mt-1 text-center">{image.title}</p>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Invoice Image */}
              {expense.invoice_image && (
                <div className="bg-white rounded-lg shadow-md p-6">
                  <h2 className="text-xl font-semibold text-gray-900 mb-4">Invoice Image</h2>
                  <div className="space-y-4">
                    {/* Invoice File Info */}
                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg border">
                      <div className="flex items-center space-x-3">
                        <div className="flex-shrink-0">
                          <span className="text-2xl">📄</span>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-900">
                            {expense.invoice_image.filename}
                          </p>
                          <p className="text-xs text-gray-500">
                            {(expense.invoice_image.size / 1024 / 1024).toFixed(2)} MB • Uploaded {formatDate(expense.invoice_image.uploadedAt)}
                          </p>
                        </div>
                      </div>
                    </div>
                    
                    {/* Invoice Image Actions */}
                    <div className="flex space-x-3">
                      <button
                        onClick={handleViewInvoiceImage}
                        className="inline-flex items-center px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors"
                      >
                        <span className="mr-2">🔍</span>
                        View Invoice
                      </button>
                      <a
                        href={expense.invoice_image.signedUrl || expense.invoice_image.url}
                        download={expense.invoice_image.filename}
                        className="inline-flex items-center px-4 py-2 bg-gray-600 text-white text-sm font-medium rounded-lg hover:bg-gray-700 transition-colors"
                      >
                        <span className="mr-2">📥</span>
                        Download
                      </a>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Right Column - Metadata */}
            <div className="space-y-6">
              {/* Metadata Card */}
              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Metadata</h2>
                <div className="space-y-3">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Created
                    </label>
                    <p className="text-sm text-gray-600">
                      {formatDate(expense.created_at)}
                    </p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Last Updated
                    </label>
                    <p className="text-sm text-gray-600">
                      {formatDate(expense.updated_at)}
                    </p>
                  </div>
                </div>
              </div>

              {/* Activity Timeline Card */}
              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Activity Timeline</h2>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <div className="flex-shrink-0">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                        <span className="text-blue-600 text-sm">📝</span>
                      </div>
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-gray-900 font-medium">Expense Created</p>
                      <p className="text-sm text-gray-600">{formatDate(expense.created_at)}</p>
                    </div>
                  </div>
                  
                  {expense.updated_at !== expense.created_at && (
                    <div className="flex items-start space-x-3">
                      <div className="flex-shrink-0">
                        <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center">
                          <span className="text-yellow-600 text-sm">✏️</span>
                        </div>
                      </div>
                      <div className="flex-1">
                        <p className="text-sm text-gray-900 font-medium">Expense Updated</p>
                        <p className="text-sm text-gray-600">{formatDate(expense.updated_at)}</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>


            </div>
          </div>

          {/* Modals */}
          {showEditModal && (
            <ExpenseFormModal
              isOpen={showEditModal}
              onClose={() => setShowEditModal(false)}
              onSubmit={handleEditExpense}
              expense={expense}
              title="Edit Expense"
            />
          )}

          {/* Document Viewer */}
          <DocumentViewer
            isOpen={documentViewer.isOpen}
            onClose={() => setDocumentViewer({ ...documentViewer, isOpen: false })}
            documentUrl={documentViewer.url}
            filename={documentViewer.filename}
          />
        </div>
      </div>
    </ProtectedRoute>
  );
}
