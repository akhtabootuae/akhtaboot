'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/app/context/AuthContext';
import { UserRegistration } from '@/services/auth';
import authService from '@/services/auth';
import { dataApi } from '@/services/api';
export default function RegisterUser() {
  const [formData, setFormData] = useState<Partial<UserRegistration>>({
    first_name: '',
    last_name: '',
    email: '',
    password: '',
    phone: '+971 50 ', // Added phone number field with default UAE format
    role: {
      role_name: 'user', // default role
    },
    branch: {
      branch_code: '', // Empty by default
    },
    speciality: '' // Added for technician specialty
  });
  
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  
  // Dynamic data states
  const [roles, setRoles] = useState<{ role_name: string; _id?: string }[]>([]);
  const [branches, setBranches] = useState<{ branch_name: string; branch_code: string; _id: string }[]>([]);
  const [specialties, setSpecialties] = useState<string[]>([]);
  const [isLoadingRoles, setIsLoadingRoles] = useState(true);
  const [isLoadingBranches, setIsLoadingBranches] = useState(true);
  const [isLoadingSpecialties, setIsLoadingSpecialties] = useState(false);
  const [rolesError, setRolesError] = useState<string | null>(null);
  const [branchesError, setBranchesError] = useState<string | null>(null);
  const [specialtiesError, setSpecialtiesError] = useState<string | null>(null);
  
  const router = useRouter();
  const { user, isAuthenticated } = useAuth();

  // Helper function for case-insensitive admin check
  const isAdmin = user?.role_name?.toLowerCase() === 'admin';

  // Redirect non-admin users
  useEffect(() => {
    if (isAuthenticated && !isAdmin) {
      router.push('/unauthorized');
    }
  }, [isAuthenticated, isAdmin, router]);

  // Fetch roles on component mount
  useEffect(() => {
    const fetchRoles = async () => {
      try {
        setIsLoadingRoles(true);
        setRolesError(null);
        const response = await dataApi.getRoles();
        
        // Extract unique roles from users data
        if (response && Array.isArray(response)) {
          const uniqueRoles = [...new Set(response.map((role: { role_name: string }) => role.role_name).filter(Boolean))];
          setRoles(uniqueRoles.map(roleName => ({ role_name: roleName })));
        } else {
          // Fallback to default roles if API response is unexpected
          setRoles([
            { role_name: 'admin' },
            { role_name: 'user' },
            { role_name: 'technician' },
            { role_name: 'supervisor' }
          ]);
        }
      } catch (error) {
        console.error('Error fetching roles:', error);
        setRolesError('Failed to load roles');
        // Fallback to default roles on error
        setRoles([
          { role_name: 'admin' },
          { role_name: 'user' },
          { role_name: 'technician' },
          { role_name: 'supervisor' }
        ]);
      } finally {
        setIsLoadingRoles(false);
      }
    };

    fetchRoles();
  }, []);

  // Fetch branches on component mount
  useEffect(() => {
    const fetchBranches = async () => {
      try {
        setIsLoadingBranches(true);
        setBranchesError(null);
        const response = await dataApi.getBranches();
        
        if (response && Array.isArray(response)) {
          setBranches(response);
        } else {
          setBranches([]);
        }
      } catch (error) {
        console.error('Error fetching branches:', error);
        setBranchesError('Failed to load branches');
        setBranches([]);
      } finally {
        setIsLoadingBranches(false);
      }
    };

    fetchBranches();
  }, []);

  // Fetch specialties when role changes to technician
  useEffect(() => {
    const fetchSpecialties = async () => {
      if (formData.role?.role_name?.toLowerCase() === 'technician') {
        try {
          setIsLoadingSpecialties(true);
          setSpecialtiesError(null);
          const response = await dataApi.getTechnicianSpecialties();
          setSpecialties(response);
        } catch (error) {
          console.error('Error fetching specialties:', error);
          setSpecialtiesError('Failed to load specialties');
          // Fallback specialties
          setSpecialties(["PDR", "Fix/Remove", "Paint", "Body Work", "Mechanical", "Electrical", "General"]);
        } finally {
          setIsLoadingSpecialties(false);
        }
      }
    };

    fetchSpecialties();
  }, [formData.role?.role_name]);

  // Show loading or unauthorized for non-admin users
  if (!isAuthenticated || !isAdmin) {
    return (
      <div className="p-6 bg-gray-50 min-h-screen flex items-center justify-center">
        <div className="bg-white rounded-lg shadow-md p-8 text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Access Denied</h1>
          <p className="text-gray-600 mb-4">You need administrator privileges to access this page.</p>
          <button
            onClick={() => router.push('/')}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
          >
            Go to Dashboard
          </button>
        </div>
      </div>
    );
  }

  // Fetch roles on component mount
  useEffect(() => {
    const fetchRoles = async () => {
      try {
        setIsLoadingRoles(true);
        setRolesError(null);
        const response = await dataApi.getRoles();
        
        // Extract unique roles from users data
        if (response && Array.isArray(response)) {
          const uniqueRoles = [...new Set(response.map((role: { role_name: string }) => role.role_name).filter(Boolean))];
          setRoles(uniqueRoles.map(roleName => ({ role_name: roleName })));
        } else {
          // Fallback to default roles if API response is unexpected
          setRoles([
            { role_name: 'admin' },
            { role_name: 'user' },
            { role_name: 'technician' },
            { role_name: 'supervisor' }
          ]);
        }
      } catch (error) {
        setRolesError('Failed to load roles');
        // Fallback to default roles on error
        setRoles([
          { role_name: 'admin' },
          { role_name: 'user' },
          { role_name: 'technician' },
          { role_name: 'supervisor' }
        ]);
      } finally {
        setIsLoadingRoles(false);
      }
    };

    fetchRoles();
  }, []);

  // Fetch branches on component mount
  useEffect(() => {
    const fetchBranches = async () => {
      try {
        setIsLoadingBranches(true);
        setBranchesError(null);
        const response = await dataApi.getBranches();
        
        if (response && Array.isArray(response)) {
          setBranches(response);
        } else {
          // Fallback to default branches if API response is unexpected
          setBranches([
            { branch_code: 'HQ', branch_name: 'Headquarters' },
            { branch_code: 'BR1', branch_name: 'Branch 1' },
            { branch_code: 'BR2', branch_name: 'Branch 2' }
          ]);
        }
      } catch (error) {
        setBranchesError('Failed to load branches');
        // Fallback to default branches on error
        setBranches([
          { branch_code: 'HQ', branch_name: 'Headquarters' },
          { branch_code: 'BR1', branch_name: 'Branch 1' },
          { branch_code: 'BR2', branch_name: 'Branch 2' }
        ]);
      } finally {
        setIsLoadingBranches(false);
      }
    };

    fetchBranches();
  }, []);

  // Fetch specialties when role changes to technician
  useEffect(() => {
    const fetchSpecialties = async () => {
      if (formData.role?.role_name?.toLowerCase() === 'technician') {
        try {
          setIsLoadingSpecialties(true);
          setSpecialtiesError(null);
          const response = await dataApi.getTechnicianSpecialties();
          setSpecialties(response);
        } catch (error) {
          setSpecialtiesError('Failed to load specialties');
          // Fallback specialties
          setSpecialties(["PDR", "Fix/Remove", "Paint", "Body Work", "Mechanical", "Electrical", "General"]);
        } finally {
          setIsLoadingSpecialties(false);
        }
      }
    };

    fetchSpecialties();
  }, [formData.role?.role_name]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    
    if (name === 'role_name') {
      let newSpeciality = '';
      
      // Set specialty based on role
      if (value.toLowerCase() === 'technician') {
        newSpeciality = formData.speciality || '';
      } else if (value.toLowerCase() === 'supervisor' || value.toLowerCase() === 'admin' || value.toLowerCase() === 'accountant') {
        newSpeciality = 'Other';
      } else {
        newSpeciality = '';
      }
      
      setFormData({
        ...formData,
        role: {
          ...formData.role,
          role_name: value
        },
        speciality: newSpeciality
      });
    } else if (name === 'branch_code') {
      setFormData({
        ...formData,
        branch: {
          ...formData.branch,
          branch_code: value
        }
      });
    } else if (name === 'speciality') {
      setFormData({
        ...formData,
        speciality: value
      });
    } else {
      setFormData({
        ...formData,
        [name]: value
      });
    }
  };

  const validateForm = () => {
    if (!formData.first_name || !formData.last_name || !formData.email || !formData.password || !confirmPassword) {
      setError('All fields are required');
      return false;
    }
    
    if (formData.password !== confirmPassword) {
      setError('Passwords do not match');
      return false;
    }
    
    if (!formData.role?.role_name) {
      setError('Role is required');
      return false;
    }
    
    if (!formData.branch?.branch_code) {
      setError('Branch is required');
      return false;
    }
    
    // Validate specialty for technicians
    if (formData.role?.role_name?.toLowerCase() === 'technician' && !formData.speciality) {
      setError('Specialty is required for technicians');
      return false;
    }
    
    // Auto-set specialty for supervisors and admins
    if ((formData.role?.role_name?.toLowerCase() === 'supervisor' || formData.role?.role_name?.toLowerCase() === 'admin' || formData.role?.role_name?.toLowerCase() === 'accountant') && !formData.speciality) {
      // This should not happen due to auto-setting, but as a fallback
      setFormData(prev => ({ ...prev, speciality: 'Other' }));
    }
    
    // Check if data is still loading
    if (isLoadingRoles || isLoadingBranches) {
      setError('Please wait for roles and branches to load');
      return false;
    }
    
    // Validate role exists in fetched roles
    if (!roles.some(role => role.role_name === formData.role?.role_name)) {
      setError('Selected role is not valid');
      return false;
    }
    
    // Validate branch exists in fetched branches
    if (!branches.some(branch => branch.branch_code === formData.branch?.branch_code)) {
      setError('Selected branch is not valid');
      return false;
    }
    
    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email!)) {
      setError('Please enter a valid email address');
      return false;
    }
    
    // Phone number validation
    if (formData.phone) {
      const phoneParts = formData.phone.split(' ');
      if (phoneParts.length !== 3 || phoneParts[0] !== '+971' || !['50', '52', '54', '55', '56', '58'].includes(phoneParts[1]) || phoneParts[2].length !== 7) {
        setError('Please enter a valid UAE phone number (7 digits after prefix)');
        return false;
      }
    }
    
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    try {
      setIsLoading(true);
      setError(null);
      
      // Use the authService instead of direct API call
      await authService.createUser(formData as UserRegistration);
      
      setSuccess('User created successfully! You will be redirected shortly...');
      setFormData({
        first_name: '',
        last_name: '',
        email: '',
        password: '',
        phone: '+971 50 ', // Reset to default UAE format
        role: {
          role_name: 'user',
        },
        branch: {
          branch_code: '',
        },
        speciality: ''
      });
      setConfirmPassword('');
      
      // Redirect to user list after a delay - only if successful
      setTimeout(() => {
        try {
          router.push('/staff');
        } catch (redirectError) {
          // If redirect fails, just log it but don't show error to user
        }
      }, 2000);
      
    } catch (err: any) {
      setError(err.response?.data?.message || err.message || 'Failed to create user');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Create New User</h1>
        <p className="text-gray-600">Add a new team member to your organization</p>
      </div>
      
      {/* Alert Messages */}
      {/* Loading Info */}
      {(isLoadingRoles || isLoadingBranches) && (
        <div className="mb-6">
          <div className="bg-blue-50 border border-blue-200 text-blue-700 px-4 py-3 rounded-lg" role="alert">
            <div className="flex items-center">
              <svg className="animate-spin w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 110 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clipRule="evenodd" />
              </svg>
              <span className="font-medium">
                Loading {isLoadingRoles && isLoadingBranches ? 'roles and branches' : isLoadingRoles ? 'roles' : 'branches'}...
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Data Loading Errors */}
      {(rolesError || branchesError) && (
        <div className="mb-6">
          <div className="bg-yellow-50 border border-yellow-200 text-yellow-700 px-4 py-3 rounded-lg" role="alert">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                </svg>
                <span className="font-medium">
                  {rolesError && branchesError ? 'Failed to load roles and branches' : rolesError || branchesError}
                </span>
              </div>
              <button 
                onClick={() => window.location.reload()}
                className="text-yellow-700 hover:text-yellow-800 font-medium text-sm underline"
              >
                Retry
              </button>
            </div>
          </div>
        </div>
      )}
      
      {error && (
        <div className="mb-6">
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg" role="alert">
            <div className="flex items-center">
              <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
              </svg>
              <span className="font-medium">{error}</span>
            </div>
          </div>
        </div>
      )}
      
      {success && (
        <div className="mb-6">
          <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg" role="alert">
            <div className="flex items-center">
              <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
              </svg>
              <span className="font-medium">{success}</span>
            </div>
          </div>
        </div>
      )}
      
      {/* Form Card */}
      <div className="bg-white rounded-lg shadow-md">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl font-bold text-gray-900">User Information</h2>
          <p className="text-gray-600 text-sm mt-1">Fill in the details below to create a new user account</p>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label htmlFor="first_name" className="block text-sm font-medium text-gray-700 mb-2">
                First Name
              </label>
              <input
                type="text"
                id="first_name"
                name="first_name"
                value={formData.first_name}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                placeholder="Enter first name"
                required
              />
            </div>
            
            <div>
              <label htmlFor="last_name" className="block text-sm font-medium text-gray-700 mb-2">
                Last Name
              </label>
              <input
                type="text"
                id="last_name"
                name="last_name"
                value={formData.last_name}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                placeholder="Enter last name"
                required
              />
            </div>
            
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                Email Address
              </label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                placeholder="Enter email address"
                required
              />
            </div>
            
            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">
                Phone Number
              </label>
              <div className="flex border border-gray-300 rounded-lg overflow-hidden focus-within:ring-2 focus-within:ring-blue-500 focus-within:border-blue-500 transition-colors">
                <div className="flex items-center px-4 py-3 bg-gray-100 text-gray-700 font-medium border-r border-gray-300">
                  +971
                </div>
                <div className="relative">
                  <select
                    name="phonePrefix"
                    value={formData.phone?.split(' ')[1] || '50'}
                    onChange={(e) => {
                      const prefix = e.target.value;
                      const currentNumber = formData.phone?.split(' ')[2] || '';
                      setFormData({
                        ...formData,
                        phone: `+971 ${prefix} ${currentNumber}`
                      });
                    }}
                    className="px-4 py-3 pr-8 bg-white border-r border-gray-300 focus:outline-none appearance-none min-w-[70px]"
                  >
                    <option value="50">50</option>
                    <option value="52">52</option>
                    <option value="54">54</option>
                    <option value="55">55</option>
                    <option value="56">56</option>
                    <option value="58">58</option>
                  </select>
                  <div className="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
                    <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </div>
                </div>
                <input
                  type="tel"
                  id="phone"
                  name="phoneNumber"
                  value={formData.phone?.split(' ')[2] || ''}
                  onChange={(e) => {
                    const value = e.target.value.replace(/\D/g, ''); // Only allow digits
                    if (value.length <= 7) { // Max 7 digits after prefix
                      const prefix = formData.phone?.split(' ')[1] || '50';
                      setFormData({
                        ...formData,
                        phone: value ? `+971 ${prefix} ${value}` : `+971 ${prefix} `
                      });
                    }
                  }}
                  className="flex-1 px-4 py-3 focus:outline-none min-w-0"
                  placeholder="1234567"
                  maxLength={7}
                />
              </div>
              <p className="text-xs text-gray-500 mt-1">
                Enter 7 digits after the prefix (e.g., 1234567)
              </p>
            </div>
            
            <div>
              <label htmlFor="role_name" className="block text-sm font-medium text-gray-700 mb-2">
                Role {isLoadingRoles && <span className="text-sm text-gray-500">(Loading...)</span>}
                {rolesError && <span className="text-sm text-red-500">({rolesError})</span>}
              </label>
              <div className="relative">
                <select
                  id="role_name"
                  name="role_name"
                  value={formData.role?.role_name || ''}
                  onChange={handleChange}
                  className="w-full px-4 py-3 pr-10 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors disabled:bg-gray-100 disabled:cursor-not-allowed appearance-none bg-white cursor-pointer"
                  required
                  disabled={isLoadingRoles}
                >
                  <option value="">
                    {isLoadingRoles ? 'Loading roles...' : 'Select a role'}
                  </option>
                  {roles.map((role) => (
                    <option key={role.role_name} value={role.role_name}>
                      {role.role_name.charAt(0).toUpperCase() + role.role_name.slice(1)}
                    </option>
                  ))}
                </select>
                <div className="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
                  <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </div>
              </div>
            </div>
            
            {/* Specialty dropdown for technicians */}
            {formData.role?.role_name?.toLowerCase() === 'technician' && (
              <div>
                <label htmlFor="speciality" className="block text-sm font-medium text-gray-700 mb-2">
                  Specialty {isLoadingSpecialties && <span className="text-sm text-gray-500">(Loading...)</span>}
                  {specialtiesError && <span className="text-sm text-red-500">({specialtiesError})</span>}
                </label>
                <div className="relative">
                  <select
                    id="speciality"
                    name="speciality"
                    value={formData.speciality || ''}
                    onChange={handleChange}
                    className="w-full px-4 py-3 pr-10 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors disabled:bg-gray-100 disabled:cursor-not-allowed appearance-none bg-white cursor-pointer"
                    required
                    disabled={isLoadingSpecialties}
                  >
                    <option value="">
                      {isLoadingSpecialties ? 'Loading specialties...' : 'Select a specialty'}
                    </option>
                    {specialties.map((specialty) => (
                      <option key={specialty} value={specialty}>
                        {specialty}
                      </option>
                    ))}
                  </select>
                  <div className="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
                    <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </div>
                </div>
              </div>
            )}

            {/* Read-only specialty display for supervisors and admins */}
            {(formData.role?.role_name?.toLowerCase() === 'supervisor' || formData.role?.role_name?.toLowerCase() === 'admin' || formData.role?.role_name?.toLowerCase() === 'accountant') && (
              <div>
                <label htmlFor="speciality_readonly" className="block text-sm font-medium text-gray-700 mb-2">
                  Specialty
                </label>
                <input
                  type="text"
                  id="speciality_readonly"
                  value="Other"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg bg-gray-100 text-gray-600 cursor-not-allowed"
                  disabled
                  readOnly
                />
                <p className="text-xs text-gray-500 mt-1">
                  Specialty is automatically set to "Other" for {formData.role?.role_name?.toLowerCase()}s
                </p>
              </div>
            )}
            
            <div>
              <label htmlFor="branch_code" className="block text-sm font-medium text-gray-700 mb-2">
                Branch {isLoadingBranches && <span className="text-sm text-gray-500">(Loading...)</span>}
                {branchesError && <span className="text-sm text-red-500">({branchesError})</span>}
              </label>
              <div className="relative">
                <select
                  id="branch_code"
                  name="branch_code"
                  value={formData.branch?.branch_code || ''}
                  onChange={handleChange}
                  className="w-full px-4 py-3 pr-10 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors disabled:bg-gray-100 disabled:cursor-not-allowed appearance-none bg-white cursor-pointer"
                  required
                  disabled={isLoadingBranches}
                >
                  <option value="">
                    {isLoadingBranches ? 'Loading branches...' : 'Select a branch'}
                  </option>
                  {branches.map((branch) => (
                    <option key={branch.branch_code} value={branch.branch_code}>
                      {branch.branch_name || branch.branch_code} ({branch.branch_code})
                    </option>
                  ))}
                </select>
                <div className="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
                  <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </div>
              </div>
            </div>
            
            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-2">
                Password
              </label>
              <input
                type="password"
                id="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                placeholder="Enter password"
                required
              />
            </div>
            
            <div>
              <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-2">
                Confirm Password
              </label>
              <input
                type="password"
                id="confirmPassword"
                name="confirmPassword"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                placeholder="Confirm password"
                required
              />
            </div>
          </div>
          
          <div className="mt-8 flex justify-end space-x-3">
            <button
              type="button"
              onClick={() => router.push('/staff/management')}
              className="px-6 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isLoading || isLoadingRoles || isLoadingBranches}
              className={`px-6 py-2 bg-blue-600 text-white rounded-lg font-medium transition-colors ${
                isLoading || isLoadingRoles || isLoadingBranches ? 'opacity-70 cursor-not-allowed' : 'hover:bg-blue-700'
              }`}
            >
              {isLoading ? (
                <div className="flex items-center">
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Creating...
                </div>
              ) : isLoadingRoles || isLoadingBranches ? (
                'Loading data...'
              ) : (
                'Create User'
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
