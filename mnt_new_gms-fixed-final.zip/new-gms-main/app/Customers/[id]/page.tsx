'use client';

import { useEffect, useState } from 'react';
import api from '@/services/api';
import { use } from 'react';
import { useAuth } from '@/app/context/AuthContext';
import { useRouter } from 'next/navigation';
import PersonalInfoCard from '@/app/components/Customer/PersonalInfoCard';
import VehiclesCard from '@/app/components/Customer/VehiclesCard';
import WorkOrdersCard from '@/app/components/Customer/WorkOrdersCard';
import CustomerEditModal from '@/app/components/Customer/Modals/CustomerEditModal';
import VehicleEditModal from '@/app/components/Customer/Modals/VehicleEditModal';


interface Vehicle {
  vehicle_id: number;
  make: string;
  model: string;
  license_plate: string;
  vin: string;
  year: number;
  color: string;
  vehicle_type: string;
  created_at: string;
  updated_at: string;
}

interface Branch {
  branch_id: string;
  branch_name: string;
  branch_code: string;
  location: string;
}

interface Customer {
  _id: string;
  first_name: string;
  last_name: string;
  email: string;
  phone?: string;
  city?: string;
  country?: string;
  branch: Branch;
  vehicles: Vehicle[];
  created_at: string;
  updated_at: string;
}

interface WorkOrderPart {
  partName: string;
  status: 'pending' | 'in_progress' | 'completed';
  createdAt: string;
  updatedAt?: string;
}

interface WorkOrder {
  _id: string;
  workOrderNumber: string;
  customer_id: string;
  vehicle_id: number;
  status: 'open' | 'in_progress' | 'on_hold' | 'completed' | 'closed';
  description?: string;
  createdAt: string;
  updatedAt?: string;
  parts: WorkOrderPart[];
}

interface FormData {
  first_name: string;
  last_name: string;
  email: string;
  phone: string | null;
}

interface VehicleFormData {
  make: string;
  model: string;
  license_plate: string;
  color: string;}

export default function CustomerDetailsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { user, isAuthenticated, isLoading } = useAuth();
  const router = useRouter();
  const isTechnician = user?.role_name?.toLowerCase() === 'technician';
  const canEdit = !isTechnician;

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.push('/login');
    }
  }, [isAuthenticated, isLoading, router]);

  const [customer, setCustomer] = useState<Customer | null>(null);
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [editError, setEditError] = useState<string | null>(null);
  const [isVehicleEditModalOpen, setIsVehicleEditModalOpen] = useState(false);
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null);
  const [isVehicleSaving, setIsVehicleSaving] = useState(false);
  const [vehicleEditError, setVehicleEditError] = useState<string | null>(null);

  // Form handling moved to modal components

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [customerResponse, workOrdersResponse] = await Promise.all([
          api.get<Customer>(`/api/customers/${id}`),
          api.get<{ success: boolean; data: WorkOrder[] }>(`/api/work-orders/customer/${id}`)
        ]);
        
        setCustomer(customerResponse as unknown as Customer);
        setWorkOrders((workOrdersResponse as any).data || []);
        setError(null);
      } catch (err: any) {
        if (err.response?.status === 403) {
          setError('You don\'t have permission to view this customer');
        } else {
          setError('Failed to load data');
        }
        console.error('Error fetching data:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [id]);

  // Form initialization moved to modal components

  const onSubmit = async (data: FormData) => {
    setIsSaving(true);
    setEditError(null);
    try {
      const response = await api.put(`/api/customers/${id}`, data);
      setCustomer(response as unknown as Customer);
      setIsEditModalOpen(false);
    } catch (err: any) {
      setEditError(err.response?.data?.message || 'Failed to update customer');
    } finally {
      setIsSaving(false);
    }
  };

  const handleEditVehicle = (vehicle: Vehicle) => {
    setSelectedVehicle(vehicle);
    setIsVehicleEditModalOpen(true);
  };

  const onVehicleSubmit = async (data: VehicleFormData) => {
    if (!selectedVehicle) return;
    
    setIsVehicleSaving(true);
    setVehicleEditError(null);
    try {
      const response = await api.put(`/api/customers/${id}/vehicles/${selectedVehicle.vehicle_id}`, data);
      setCustomer(response as unknown as Customer);
      setIsVehicleEditModalOpen(false);
      setSelectedVehicle(null);
    } catch (err: any) {
      setVehicleEditError(err.response?.data?.message || 'Failed to update vehicle');
    } finally {
      setIsVehicleSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="p-6 bg-gray-50 min-h-screen flex items-center justify-center">
        <div className="bg-white p-8 rounded-lg shadow-sm flex flex-col items-center">
          <div className="w-12 h-12 border-4 border-t-blue-600 border-gray-200 rounded-full animate-spin mb-4"></div>
          <div className="text-lg font-medium text-gray-700">Loading customer details...</div>
        </div>
      </div>
    );
  }

  if (error || !customer) {
    return (
      <div className="p-6 bg-gray-50 min-h-screen flex items-center justify-center">
        <div className="bg-white p-8 rounded-lg shadow-sm flex flex-col items-center">
          <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mb-4">
            {error?.includes('permission') ? (
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-red-600">
                <path d="M9 12l2 2 4-4"/>
                <path d="M21 12c0 4.97-4.03 9-9 9s-9-4.03-9-9 4.03-9 9-9 9 4.03 9 9z"/>
                <path d="m9 12 2 2 4-4"/>
                <path d="M12 1v6"/>
                <path d="M12 17v6"/>
                <path d="M1 12h6"/>
                <path d="M17 12h6"/>
              </svg>
            ) : (
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-red-600">
                <circle cx="12" cy="12" r="10"></circle>
                <line x1="12" y1="8" x2="12" y2="12"></line>
                <line x1="12" y1="16" x2="12.01" y2="16"></line>
              </svg>
            )}
          </div>
          <div className="text-lg font-medium text-red-600 text-center">
            {error || 'Customer not found'}
          </div>
          {error?.includes('permission') && (
            <p className="text-sm text-gray-600 text-center mt-2 max-w-md">
              You don't have the necessary permissions to access this customer's information. Please contact your administrator if you believe this is an error.
            </p>
          )}
          <button 
            onClick={() => router.push('/Customers')}
            className="mt-4 px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 text-sm font-medium"
          >
            Back to Customer List
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      <div className="max-w-6xl mx-auto">
        {/* Header with back button and customer info */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <button 
              onClick={() => router.push('/Customers')}
              className="p-2 mr-3 bg-white rounded-md hover:bg-gray-100 transition-colors border border-gray-200"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-gray-600">
                <path d="M19 12H5M12 19l-7-7 7-7"/>
              </svg>
            </button>
            <div className="flex items-center">
              <div className="bg-blue-100 p-1 rounded-full mr-3">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-600">
                  <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path>
                  <circle cx="9.5" cy="7" r="4"></circle>
                </svg>
              </div>
              <div>
                <h1 className="text-2xl font-semibold text-gray-800">
                  {customer.first_name} {customer.last_name}
                </h1>
                <p className="text-sm text-gray-500">
                  Customer since {new Date(customer.created_at).toLocaleDateString()}
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-6">
          {canEdit && (
            <CustomerEditModal 
              customer={customer}
              isOpen={isEditModalOpen}
              isSaving={isSaving}
              error={editError}
              onClose={() => setIsEditModalOpen(false)}
              onSubmit={onSubmit}
            />
          )}

          {/* Personal Info Card */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden w-full">
            <PersonalInfoCard customer={customer} onEdit={canEdit ? () => setIsEditModalOpen(true) : undefined} />
          </div>

          {/* Vehicles Card */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden w-full">
            <VehiclesCard vehicles={customer.vehicles} onEditVehicle={canEdit ? handleEditVehicle : undefined} />

            {canEdit && selectedVehicle && (
              <VehicleEditModal
                vehicle={selectedVehicle}
                isOpen={isVehicleEditModalOpen}
                isSaving={isVehicleSaving}
                error={vehicleEditError}
                onClose={() => setIsVehicleEditModalOpen(false)}
                onSubmit={onVehicleSubmit}
              />
            )}
          </div>

          {/* Work Orders Card */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden w-full">
            <WorkOrdersCard workOrders={workOrders} vehicles={customer.vehicles} />
          </div>
        </div>
      </div>
    </div>
  );
}