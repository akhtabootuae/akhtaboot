'use client';

import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useRouteProtection } from '@/services/route-protection';
import useDebounce from '../hooks/useDebounce';
import CustomerSearchBar from '../components/Customer/CustomerSearchBar';
import CustomerRow from '../components/Customer/CustomerRow';
import api from '@/services/api';
import Link from 'next/link';

interface Vehicle {
  make: string;
  model: string;
  license_plate: string;
  vin: string;
}

interface Customer {
  _id: string;
  first_name: string;
  last_name: string;
  email: string;
  phone?: string;
  vehicles?: Vehicle[];
  created_at?: string;
}

const PAGE_SIZE = 8;

export default function CustomersPage() {
  const { user, isAuthenticated, isLoading } = useAuth();
  
  // Route protection for authenticated users (everyone who is logged in)
  const hasAccess = useRouteProtection(isAuthenticated, user, {});
  
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [search, setSearch] = useState('');
  const [currentPage, setCurrentPage] = useState(1);

  // debouncedSearch will only update 300ms after the last keystroke
  const debouncedSearch = useDebounce(search, 300);

  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        const response = await api.get<Customer[]>('/api/customers');
        if (Array.isArray(response)) {
          setCustomers(response);
        } else {
          console.error('Invalid response format:', response);
          setCustomers([]);
        }
      } catch (error) {
        console.error('Error fetching customers:', error);
        setCustomers([]);
      }
    };
    fetchCustomers();
  }, []);

  // whenever you type, search changes immediately, but debouncedSearch lags by 300ms
  useEffect(() => {
    setCurrentPage(1);
  }, [debouncedSearch]);

  // Show loading state while checking auth
  if (isLoading || !hasAccess) {
    return (
      <div className="p-6 bg-gray-50 min-h-screen flex items-center justify-center">
        <div className="text-xl text-gray-600">Loading...</div>
      </div>
    );
  }

  // filter by the **debounced** term
  const filtered = customers.filter(c => {
    const term = debouncedSearch.toLowerCase();
    return (
      (`${c.first_name} ${c.last_name}`.toLowerCase().includes(term)) ||
      c.email.toLowerCase().includes(term) ||
      c.phone?.includes(term) ||
      c.vehicles?.some(v =>
        [v.make, v.model, v.license_plate, v.vin]
          .filter(Boolean)
          .some(val => val.toLowerCase().includes(term))
      )
    );
  });

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const startIdx = (currentPage - 1) * PAGE_SIZE;
  const visible = filtered.slice(startIdx, startIdx + PAGE_SIZE);

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      <div className="w-full">          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center">
              <div className="bg-blue-100 p-3 rounded-full mr-4">
                <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-600"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M22 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
              </div>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">
                  Customer Management
                </h1>
                <div className="flex items-center mt-2">
                  <div className="text-sm bg-blue-100 text-blue-800 py-1 px-3 rounded-full font-medium">
                    {filtered.length} customers
                  </div>
                </div>
              </div>
            </div>            <Link 
              href="/new_reg" 
              className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 text-sm font-medium flex items-center gap-2 transition-colors"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 5v14M5 12h14"/></svg>
              Register New Customer
            </Link>
        </div>

        {/* Search Card - Using CustomerSearchBar component */}
        <div className="bg-white rounded-lg shadow-md mb-8 overflow-hidden">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-800">Search Customers</h2>
            <p className="text-sm text-gray-600">Find customers by name, email, phone or vehicle information</p>
          </div>
          <div className="p-6">
            <CustomerSearchBar 
              search={search} 
              onSearchChange={setSearch} 
            />
          </div>
        </div>

        {/* Customers Table Card */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-800">Customer List</h2>
            <p className="text-sm text-gray-600">Manage and view customer details</p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full table-auto">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                  <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                  <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Phone</th>
                  <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Vehicles</th>
                  <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer Since</th>
                  <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {visible.length > 0 ? (
                  visible.map(c => <CustomerRow key={c._id} customer={c} />)
                ) : (
                  <tr>
                    <td colSpan={6} className="px-6 py-12 text-center text-gray-500">
                      <div className="flex flex-col items-center justify-center">
                        <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" className="text-gray-300 mb-3"><circle cx="9" cy="7" r="4"></circle><path d="M3 21v-2a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v2"></path><path d="M16 11h6"></path><circle cx="16" cy="11" r="5" strokeDasharray="10"></circle></svg>
                        <p className="text-base font-medium">No customers found</p>
                        <p className="text-sm text-gray-400">Try adjusting your search criteria</p>
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination footer */}
          <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex items-center justify-between">
            <div className="text-sm text-gray-600 font-medium">
              Showing {startIdx + 1}–{Math.min(startIdx + PAGE_SIZE, filtered.length)} of {filtered.length} customers
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="px-4 py-2 bg-white border border-gray-300 rounded-lg text-gray-700 text-sm font-medium hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                Previous
              </button>
              <span className="text-sm text-gray-700 font-medium px-3">
                Page {currentPage} of {totalPages}
              </span>
              <button
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="px-4 py-2 bg-white border border-gray-300 rounded-lg text-gray-700 text-sm font-medium hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                Next
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}