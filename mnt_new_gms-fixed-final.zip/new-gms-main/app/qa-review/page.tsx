'use client';

import React, { useState, useEffect } from 'react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import api from '../../services/api';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

// Interface for QA Record
interface QARecord {
  _id: string;
  WO_ID: string;
  work_order_object_id?: string; // Optional ObjectId for direct navigation
  person_name: string;
  passed: boolean;
  images: Array<{
    s3_key: string;
    original_name: string;
    size: number;
    mime_type: string;
    upload_date: string;
  }>;
  description: string;
  created_at: string;
  updated_at: string;
}

// Interface for API Response
interface QAResponse {
  success: boolean;
  data: QARecord[];
  pagination?: {
    page: number;
    limit: number;
    total: number;
    pages: number;
  };
}

// Interface for QA Stats
interface QAStats {
  total: number;
  passed: number;
  failed: number;
  pass_rate: string;
}

/**
 * QA Review Page
 * 
 * Comprehensive audit log for all QA submissions
 * Includes filtering, sorting, and detailed views
 */
export default function QAReviewPage() {
  const router = useRouter();
  
  // State
  const [qaRecords, setQARecords] = useState<QARecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [stats, setStats] = useState<QAStats | null>(null);
  
  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalRecords, setTotalRecords] = useState(0);
  
  // Filters
  const [filters, setFilters] = useState({
    wo_id: '',
    person_name: '',
    passed: '',
    date_from: '',
    date_to: ''
  });
  
  // Sorting
  const [sortBy, setSortBy] = useState('created_at');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  
  // Expanded row state
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());
  const [showImagesForRecord, setShowImagesForRecord] = useState<Set<string>>(new Set());

  // Fetch QA records
  const fetchQARecords = async (page = 1) => {
    try {
      setLoading(true);
      setError('');
      
      const params: any = {
        page: page.toString(),
        limit: '10'
      };
      
      // Add filters
      if (filters.wo_id) params.wo_id = filters.wo_id;
      if (filters.person_name) params.person_name = filters.person_name;
      if (filters.passed !== '') params.passed = filters.passed;
      if (filters.date_from) params.date_from = filters.date_from;
      if (filters.date_to) params.date_to = filters.date_to;
      
      console.log('Fetching QA records with params:', params);
      const response = await api.get('/api/workorder-qa', { params }) as QAResponse;
      
      if (response.success) {
        setQARecords(response.data);
        if (response.pagination) {
          setCurrentPage(response.pagination.page);
          setTotalPages(response.pagination.pages);
          setTotalRecords(response.pagination.total);
        }
      } else {
        setError('Failed to fetch QA records');
      }
    } catch (err) {
      console.error('Error fetching QA records:', err);
      setError('Failed to load QA records');
    } finally {
      setLoading(false);
    }
  };

  // Fetch QA statistics
  const fetchQAStats = async () => {
    try {
      const response = await api.get('/api/workorder-qa/stats/overview');
      if (response.success) {
        setStats(response.data);
      }
    } catch (err) {
      console.error('Error fetching QA stats:', err);
    }
  };

  // Load data on mount
  useEffect(() => {
    fetchQARecords();
    fetchQAStats();
  }, []);

  // Handle filter changes
  const handleFilterChange = (key: string, value: string) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  // Apply filters
  const applyFilters = () => {
    setCurrentPage(1);
    fetchQARecords(1);
  };

  // Reset filters
  const resetFilters = () => {
    setFilters({
      wo_id: '',
      person_name: '',
      passed: '',
      date_from: '',
      date_to: ''
    });
    setCurrentPage(1);
    fetchQARecords(1);
  };

  // Handle page change
  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    fetchQARecords(page);
  };

  // Toggle row expansion
  const toggleRowExpansion = (recordId: string) => {
    const newExpandedRows = new Set(expandedRows);
    if (newExpandedRows.has(recordId)) {
      newExpandedRows.delete(recordId);
    } else {
      newExpandedRows.add(recordId);
    }
    setExpandedRows(newExpandedRows);
  };

  // Toggle image display for a record
  const toggleImageDisplay = (recordId: string) => {
    const newShowImages = new Set(showImagesForRecord);
    if (newShowImages.has(recordId)) {
      newShowImages.delete(recordId);
    } else {
      newShowImages.add(recordId);
    }
    setShowImagesForRecord(newShowImages);
  };

  // Handle image download/view
  const handleImageDownload = async (recordId: string, imageIndex: number) => {
    try {
      const response = await api.get(`/api/workorder-qa/${recordId}/images/${imageIndex}/download`);
      if (response.success && response.data.download_url) {
        window.open(response.data.download_url, '_blank');
      } else {
        console.error('Failed to get image download URL');
        console.error('Failed to load image. Please try again.');
      }
    } catch (error) {
      console.error('Error downloading image:', error);
      console.error('Failed to load image. Please try again.');
    }
  };

  // Handle work order click - navigate directly to work order detail page
  const handleWorkOrderClick = async (qaRecord: QARecord) => {
    try {
      // If we have the work order ObjectId, use it directly
      if (qaRecord.work_order_object_id) {
        router.push(`/workOrders/${qaRecord.work_order_object_id}`);
        return;
      }
      
      // Search for the work order by its number with a larger limit to overcome pagination issues
      // The API has a bug where search happens after pagination, so we need more records
      const response = await api.get('/api/work-orders', { 
        params: { 
          search: qaRecord.WO_ID,
          limit: '100' // Increased limit to find older work orders
        } 
      });
      
      if (response.success && response.data && response.data.length > 0) {
        const workOrder = response.data[0];
        router.push(`/workOrders/${workOrder._id}`);
      } else {
        // If still not found, try without search and filter manually
        console.log(`Work order ${qaRecord.WO_ID} not found in search, trying broader fetch...`);
        
        const broadResponse = await api.get('/api/work-orders', { 
          params: { 
            limit: '100' // Get more records without search filter
          } 
        });
        
        if (broadResponse.success && broadResponse.data) {
          // Manually search in the results
          const foundWorkOrder = broadResponse.data.find((wo: any) => 
            wo.workOrderNumber === qaRecord.WO_ID || 
            wo.work_order_number === qaRecord.WO_ID ||
            wo.workOrderId === qaRecord.WO_ID
          );
          
          if (foundWorkOrder) {
            router.push(`/workOrders/${foundWorkOrder._id}`);
            return;
          }
        }
        
        console.error(`Work order not found for number: ${qaRecord.WO_ID}`);
        console.error(`Work order ${qaRecord.WO_ID} not found. It may be in an older batch of records.`);
      }
    } catch (error) {
      console.error('Error navigating to work order:', error);
      console.error(`Failed to open work order ${qaRecord.WO_ID}. Please try again.`);
    }
  };

  // Format date
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Render loading state
  if (loading && qaRecords.length === 0) {
    return (
      <div className="p-6 bg-gray-50 min-h-screen">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          <span className="ml-2 text-gray-600">Loading QA records...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">QA Review & Audit</h1>
        <p className="text-gray-600">Comprehensive audit log of all quality assurance submissions</p>
      </div>

      {/* Statistics Cards */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-sm font-medium text-gray-500 mb-2">Total QA Records</h3>
            <p className="text-2xl font-bold text-gray-900">{stats.total}</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-sm font-medium text-gray-500 mb-2">Passed</h3>
            <p className="text-2xl font-bold text-green-600">{stats.passed}</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-sm font-medium text-gray-500 mb-2">Failed</h3>
            <p className="text-2xl font-bold text-red-600">{stats.failed}</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-sm font-medium text-gray-500 mb-2">Pass Rate</h3>
            <p className="text-2xl font-bold text-blue-600">{stats.pass_rate}%</p>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="bg-white p-6 rounded-lg shadow-md mb-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Filters</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Work Order ID</label>
            <Input
              type="text"
              placeholder="WO-2024-001"
              value={filters.wo_id}
              onChange={(e) => handleFilterChange('wo_id', e.target.value)}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Inspector Name</label>
            <Input
              type="text"
              placeholder="Inspector name"
              value={filters.person_name}
              onChange={(e) => handleFilterChange('person_name', e.target.value)}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
            <select
              className="w-full p-2 border border-gray-300 rounded-md"
              value={filters.passed}
              onChange={(e) => handleFilterChange('passed', e.target.value)}
            >
              <option value="">All</option>
              <option value="true">Passed</option>
              <option value="false">Failed</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Date From</label>
            <Input
              type="date"
              value={filters.date_from}
              onChange={(e) => handleFilterChange('date_from', e.target.value)}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Date To</label>
            <Input
              type="date"
              value={filters.date_to}
              onChange={(e) => handleFilterChange('date_to', e.target.value)}
            />
          </div>
        </div>
        <div className="flex space-x-3 mt-4">
          <Button onClick={applyFilters} className="bg-blue-600 hover:bg-blue-700">
            Apply Filters
          </Button>
          <Button onClick={resetFilters} variant="outline">
            Reset
          </Button>
        </div>
      </div>

      {/* Error state */}
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
          {error}
        </div>
      )}

      {/* QA Records Table */}
      <div className="bg-white rounded-lg shadow-md">
        <div className="p-6 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold text-gray-900">QA Records</h2>
            <div className="text-sm text-gray-600">
              Showing {qaRecords.length} of {totalRecords} records
            </div>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Work Order
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Inspector
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Images
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Date
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {qaRecords.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-4 text-center text-gray-500">
                    No QA records found
                  </td>
                </tr>
              ) : (
                qaRecords.map((record) => (
                  <React.Fragment key={record._id}>
                    <tr className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <button
                          onClick={() => handleWorkOrderClick(record)}
                          className="text-sm font-medium text-blue-600 hover:text-blue-800 hover:underline cursor-pointer"
                        >
                          {record.WO_ID}
                        </button>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{record.person_name}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                          record.passed 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {record.passed ? 'PASSED' : 'FAILED'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{record.images.length} images</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{formatDate(record.created_at)}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => toggleRowExpansion(record._id)}
                        >
                          {expandedRows.has(record._id) ? 'Hide Details' : 'Show Details'}
                        </Button>
                      </td>
                    </tr>
                    {expandedRows.has(record._id) && (
                      <tr>
                        <td colSpan={6} className="px-6 py-4 bg-gray-50">
                          <div className="space-y-4">
                            <div>
                              <h4 className="font-medium text-gray-900 mb-2">Description</h4>
                              <p className="text-sm text-gray-700">{record.description}</p>
                            </div>
                            <div>
                              <div className="flex justify-between items-center mb-2">
                                <h4 className="font-medium text-gray-900">Images ({record.images.length})</h4>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => toggleImageDisplay(record._id)}
                                  className="text-xs"
                                >
                                  {showImagesForRecord.has(record._id) ? 'Hide Images' : 'Display Images'}
                                </Button>
                              </div>
                              
                              {showImagesForRecord.has(record._id) && (
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                  {record.images.map((image, index) => (
                                    <div key={index} className="bg-white p-2 rounded border">
                                      <div className="text-xs text-gray-600 mb-1">
                                        {image.original_name}
                                      </div>
                                      <div className="text-xs text-gray-500">
                                        {(image.size / 1024 / 1024).toFixed(2)} MB
                                      </div>
                                      <div className="text-xs text-gray-500">
                                        {formatDate(image.upload_date)}
                                      </div>
                                      <Button
                                        size="sm"
                                        variant="outline"
                                        className="mt-2 text-xs"
                                        onClick={() => handleImageDownload(record._id, index)}
                                      >
                                        View Full Size
                                      </Button>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex justify-between items-center mt-6">
          <Button
            onClick={() => handlePageChange(currentPage - 1)}
            disabled={currentPage === 1}
            variant="outline"
          >
            Previous
          </Button>
          <span className="text-sm text-gray-700">
            Page {currentPage} of {totalPages}
          </span>
          <Button
            onClick={() => handlePageChange(currentPage + 1)}
            disabled={currentPage === totalPages}
            variant="outline"
          >
            Next
          </Button>
        </div>
      )}
    </div>
  );
}