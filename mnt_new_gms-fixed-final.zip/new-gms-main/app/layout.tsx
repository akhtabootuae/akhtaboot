
import DashboardWrapper from "./dashBoardWrapper"
import type { Metadata } from "next"
import "./globals.css"
import { CollapsedProvider } from "./context/CollapsedContext"
import { AuthProvider } from "./context/AuthContext"
import { AutoPlayProvider } from "./context/AutoPlayContext"
import { NotificationProvider } from "./context/NotificationContext"

export const metadata: Metadata = {
  title: "GMS Dashboard",
  description: "Garage Management System dashboard",
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <AuthProvider>
          <CollapsedProvider>
            <NotificationProvider>
              <AutoPlayProvider>
                <DashboardWrapper>{children}</DashboardWrapper>
              </AutoPlayProvider>
            </NotificationProvider>
          </CollapsedProvider>
        </AuthProvider>
      </body>
    </html>
  )
}
