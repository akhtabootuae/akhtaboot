'use client';

import React, { useState, useEffect } from 'react';
import { customerReviewApi } from '@/services/api';

interface ReviewFormData {
  rating: number;
  phone_number: string;
  comment: string;
  referral: string;
  other_referral?: string;
}

const CustomerReviewPage = () => {
  const [formData, setFormData] = useState<ReviewFormData>({
    rating: 0,
    phone_number: '',
    comment: '',
    referral: '',
    other_referral: ''
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hoveredRating, setHoveredRating] = useState(0);
  const [countdown, setCountdown] = useState(0);

  // Function to reset the form completely
  const resetForm = () => {
    setFormData({
      rating: 0,
      phone_number: '',
      comment: '',
      referral: '',
      other_referral: ''
    });
    setIsSubmitted(false);
    setIsSubmitting(false);
    setError(null);
    setHoveredRating(0);
    setCountdown(0);
  };

  // Auto-refresh countdown effect
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isSubmitted && countdown > 0) {
      interval = setInterval(() => {
        setCountdown(prev => prev - 1);
      }, 1000);
    } else if (isSubmitted && countdown === 0) {
      // Reset form after countdown
      resetForm();
    }

    return () => {
      if (interval) {
        clearInterval(interval);
      }
    };
  }, [isSubmitted, countdown]);

  // Start countdown when review is submitted
  useEffect(() => {
    if (isSubmitted && countdown === 0) {
      setCountdown(5);
    }
  }, [isSubmitted]);

  const handleRatingClick = (rating: number) => {
    setFormData(prev => ({ ...prev, rating }));
  };

  const handleRatingHover = (rating: number) => {
    setHoveredRating(rating);
  };

  const handleRatingLeave = () => {
    setHoveredRating(0);
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value;
    
    // Remove any non-numeric characters except +
    value = value.replace(/[^\d+]/g, '');
    
    // Ensure it starts with + if there are digits
    if (value && !value.startsWith('+')) {
      value = '+' + value;
    }
    
    setFormData(prev => ({ ...prev, phone_number: value }));
  };

  const handleCommentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const value = e.target.value;
    if (value.length <= 1000) {
      setFormData(prev => ({ ...prev, comment: value }));
    }
  };
  
  const handleReferralChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value;
    setFormData(prev => ({ ...prev, referral: value }));
  };
  
  const handleOtherReferralChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setFormData(prev => ({ ...prev, other_referral: value }));
  };

  const validateForm = () => {
    // Clear any previous errors
    setError(null);
    
    // Require rating
    if (formData.rating === 0) {
      setError('Please select a rating');
      return false;
    }
    
    // Require phone number
    if (!formData.phone_number || formData.phone_number === '+' || !formData.phone_number.trim()) {
      setError('Please enter your phone number');
      return false;
    }
    
    // Phone number validation
    const phoneRegex = /^\+?[1-9]\d{1,14}$/;
    if (!phoneRegex.test(formData.phone_number)) {
      setError('Please enter a valid phone number (e.g., +971501234567)');
      return false;
    }
    
    // No validation for referral - it's completely optional
    // Users can select "other" without providing additional details if they want
    
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    
    if (!validateForm() || isSubmitting) {
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const reviewData: any = {
        rating: formData.rating,
        phone_number: formData.phone_number
      };
      
      // Only include comment if it's provided
      if (formData.comment.trim()) {
        reviewData.comment = formData.comment.trim();
      }
      
      // Include referral information
      if (formData.referral) {
        // If referral is "other", format it as "other:" followed by the text (if provided)
        if (formData.referral === "other") {
          if (formData.other_referral && formData.other_referral.trim()) {
            reviewData.referral = `other:${formData.other_referral.trim()}`;
          } else {
            reviewData.referral = "other";
          }
        } else {
          reviewData.referral = formData.referral;
        }
      }
      
      await customerReviewApi.createReview(reviewData);
      
      // Set submitted state first
      setIsSubmitted(true);
      setCountdown(5);
      
      // Then reset form data
      setFormData({
        rating: 0,
        phone_number: '',
        comment: '',
        referral: '',
        other_referral: ''
      });
      
    } catch (err: any) {
      let errorMessage = 'Failed to submit review. Please try again.';
      
      if (err.response?.data?.message) {
        errorMessage = err.response.data.message;
      } else if (err.message) {
        errorMessage = err.message;
      }
      
      setError(errorMessage);
    } finally {
      setIsSubmitting(false);
    }
  };

  const getRatingLabel = (rating: number) => {
    switch (rating) {
      case 1: return 'Very Poor';
      case 2: return 'Poor';
      case 3: return 'Average';
      case 4: return 'Good';
      case 5: return 'Excellent';
      default: return '';
    }
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-blue-50 to-indigo-100">
        <div className="container mx-auto px-4 py-16">
          <div className="text-center max-w-4xl mx-auto">
            {/* Logo */}
            <div className="flex justify-center mb-6">
              <img src="/Final-logo.webp" alt="Company Logo" className="h-20 md:h-24" />
            </div>
            <div className="w-32 h-32 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-12">
              <svg className="w-16 h-16 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <h1 className="text-6xl font-bold text-gray-900 mb-8">Thank You!</h1>
            <p className="text-2xl text-gray-600 mb-12 leading-relaxed max-w-2xl mx-auto">
              Your review has been submitted successfully. We truly appreciate your feedback and will use it to improve our service quality!
            </p>
            <div className="space-y-6">
              <button
                onClick={resetForm}
                className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-12 py-4 rounded-xl hover:from-blue-700 hover:to-indigo-700 transition-all duration-300 text-xl font-semibold shadow-lg hover:shadow-xl transform hover:-translate-y-1"
              >
                Submit Another Review
              </button>
              
              {/* Countdown display */}
              {countdown > 0 && (
                <div className="bg-blue-50 border-2 border-blue-200 rounded-xl p-4 max-w-md mx-auto">
                  <div className="flex items-center justify-center">
                    <svg className="w-5 h-5 text-blue-500 mr-3 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" fill="none" strokeDasharray="62.83" strokeDashoffset="62.83" className="animate-pulse"/>
                    </svg>
                    <p className="text-blue-700 font-medium">
                      Auto-refreshing in {countdown} second{countdown !== 1 ? 's' : ''}...
                    </p>
                  </div>
                </div>
              )}
              
              <div className="text-gray-500 text-lg">
                🎉 Your feedback matters to us
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-100 flex flex-col">
      {/* Header - Full Width */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-6 py-8">
        <div className="text-center">
          {/* Logo */}
          <div className="flex justify-center mb-4">
            <img src="/Final-logo.webp" alt="Company Logo" className="h-16 md:h-20" />
          </div>
          <h1 className="text-4xl font-bold mb-3">Customer Review</h1>
          <p className="text-lg text-blue-100 max-w-3xl mx-auto">
            Share your experience with our service - Your feedback helps us deliver exceptional quality
          </p>
        </div>
      </div>

      {/* Main Content - Full Width */}
      <div className="flex-1 px-6 py-8">
        <form onSubmit={handleSubmit} className="space-y-8">
          
          {/* Rating Section - Full Width */}
          <div className="text-center">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">
              How would you rate our service?
            </h2>
            <div className="flex items-center justify-center space-x-4 mb-4">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => handleRatingClick(star)}
                  onMouseEnter={() => handleRatingHover(star)}
                  onMouseLeave={handleRatingLeave}
                  className="focus:outline-none focus:ring-2 focus:ring-blue-300 focus:ring-opacity-50 rounded-full p-2 transition-all duration-200 hover:scale-110"
                >
                  <svg
                    className={`w-10 h-10 transition-colors duration-200 ${
                      star <= (hoveredRating || formData.rating) ? 'text-yellow-400' : 'text-gray-300'
                    }`}
                    fill="currentColor"
                    viewBox="0 0 20 20"
                  >
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                </button>
              ))}
            </div>
            {(formData.rating > 0 || hoveredRating > 0) && (
              <div className="text-center mb-4">
                <span className="inline-block bg-blue-100 text-blue-800 px-4 py-2 rounded-full text-lg font-medium">
                  {getRatingLabel(hoveredRating || formData.rating)}
                </span>
              </div>
            )}
            {formData.rating === 0 && (
              <p className="text-red-500 text-sm mt-2">* Please select a rating</p>
            )}
          </div>

          {/* Phone Number and Comment Section - Side by Side on Large Screens */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {/* Phone Number Section */}
            <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-200">
              <label htmlFor="phone_number" className="block text-xl font-bold text-gray-800 mb-4">
                Phone Number 
                <span className="text-red-500 font-normal text-sm ml-2">*</span>
              </label>
              <input
                type="tel"
                id="phone_number"
                value={formData.phone_number}
                onChange={handlePhoneChange}
                placeholder="+971501234567"
                required
                className="w-full px-4 py-3 text-lg border-2 border-gray-200 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-300 focus:ring-opacity-50 focus:border-blue-500 transition-all duration-200"
              />
              <p className="mt-3 text-gray-500 text-sm">
                💡 Include country code (e.g., +971 for UAE). Required field.
              </p>
            </div>

            {/* Comment Section */}
            <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-200">
              <label htmlFor="comment" className="block text-xl font-bold text-gray-800 mb-4">
                Your Experience 
                <span className="text-gray-400 font-normal text-sm ml-2">(Optional)</span>
              </label>
              <textarea
                id="comment"
                rows={6}
                value={formData.comment}
                onChange={handleCommentChange}
                placeholder="What did you like about our service? What could we improve? Any suggestions or feedback would be greatly appreciated..."
                className="w-full px-4 py-3 text-base border-2 border-gray-200 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-300 focus:ring-opacity-50 focus:border-blue-500 transition-all duration-200 resize-none"
              />
              <div className="flex justify-between items-center mt-3">
                <p className="text-gray-500 text-sm">
                  💬 Your detailed feedback helps us serve you better
                </p>
                <p className="text-sm text-gray-500 font-medium">
                  {formData.comment.length}/1000
                </p>
              </div>
            </div>
          </div>
          
          {/* Referral Section - Full Width */}
          <div className="max-w-6xl mx-auto w-full">
            <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-200">
              <label htmlFor="referral" className="block text-xl font-bold text-gray-800 mb-4">
                How did you hear about us?
                <span className="text-gray-400 font-normal text-sm ml-2">(Optional)</span>
              </label>
              <div className="relative group">
                <select
                  id="referral"
                  value={formData.referral}
                  onChange={handleReferralChange}
                  className="w-full px-4 py-3 text-lg border-2 border-gray-200 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-300 focus:ring-opacity-50 focus:border-blue-500 hover:border-gray-400 hover:bg-gray-50 transition-all duration-200 bg-white appearance-none cursor-pointer pr-10"
                >
                  <option value="">Please select an option</option>
                  <option value="Tiktok">TikTok</option>
                  <option value="Instagram">Instagram</option>
                  <option value="Youtube">YouTube</option>
                  <option value="Recommended by a friend">Recommended by a friend</option>
                  <option value="other">Other</option>
                </select>
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-4">
                  <div className="bg-blue-100 rounded-full p-1 text-blue-600 transform transition-transform duration-200 group-hover:translate-y-0.5">
                    <svg className="h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                      <path fillRule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 11.168l3.71-3.938a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z" clipRule="evenodd" />
                    </svg>
                  </div>
                </div>
              </div>
              
              {/* Conditional input field for "Other" option */}
              {formData.referral === 'other' && (
                <div className="mt-4">
                  <label htmlFor="other_referral" className="block text-md font-medium text-gray-700 mb-2">
                    Please specify:
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      id="other_referral"
                      value={formData.other_referral || ''}
                      onChange={handleOtherReferralChange}
                      placeholder="Please tell us how you heard about us"
                      className="w-full px-4 py-3 text-base border-2 border-gray-200 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-300 focus:ring-opacity-50 focus:border-blue-500 transition-all duration-200"
                    />
                    <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                      <span className="text-blue-500 bg-blue-50 p-1 rounded-full">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2h-1V9a1 1 0 00-1-1z" clipRule="evenodd" />
                        </svg>
                      </span>
                    </div>
                  </div>
                </div>
              )}
              
              <p className="mt-3 text-gray-500 text-sm">
                📱 Your answer helps us understand which channels are most effective
              </p>
            </div>
          </div>

          {/* Error Message - Full Width */}
          {error && (
            <div className="bg-red-50 border-2 border-red-200 rounded-xl p-4 max-w-3xl mx-auto">
              <div className="flex items-center justify-center">
                <svg className="w-5 h-5 text-red-500 mr-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <p className="text-red-700 font-medium text-lg">{error}</p>
              </div>
            </div>
          )}

          {/* Submit Button - Full Width */}
          <div className="text-center">
            <button
              type="submit"
              disabled={isSubmitting || formData.rating === 0}
              className={`px-8 py-4 rounded-xl text-white font-semibold text-xl transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1 ${
                isSubmitting || formData.rating === 0
                  ? 'bg-gray-400 cursor-not-allowed'
                  : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 focus:outline-none focus:ring-2 focus:ring-blue-300 focus:ring-opacity-50'
              }`}
            >
              {isSubmitting ? (
                <div className="flex items-center justify-center">
                  <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Submitting Your Review...
                </div>
              ) : (
                'Submit Review'
              )}
            </button>
          </div>
        </form>
      </div>

      {/* Footer Section - Full Width */}
      <div className="bg-gradient-to-r from-gray-50 to-gray-100 px-6 py-6 border-t border-gray-200">
        <div className="text-center">
          <p className="text-gray-700 mb-2 text-lg font-semibold">
            🔒 Your feedback is secure and confidential
          </p>
          <p className="text-base text-gray-600 max-w-4xl mx-auto">
            We use your feedback to continuously improve our service quality and customer experience. 
            Your privacy is important to us, and all reviews are handled with complete confidentiality.
          </p>
        </div>
      </div>
    </div>
  );
};

export default CustomerReviewPage;
