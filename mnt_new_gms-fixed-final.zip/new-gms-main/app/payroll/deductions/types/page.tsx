"use client";

import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../../../components/ui/card";
import { Button } from "../../../components/ui/button";
import { Input } from "../../../components/ui/input";
import { Search, Plus, Edit2, Trash2, AlertCircle, CheckCircle, Settings, ToggleLeft, ToggleRight } from "lucide-react";
import { payrollApi } from "../../../../services/api";
import { PayrollDeductionType } from "../../../types/payroll";
import { useAuth } from "../../../context/AuthContext";
import { useRouteProtection } from "../../../../services/route-protection";
import Link from "next/link";

interface CreateDeductionTypeData {
  name: string;
  description: string;
  type: 'fixed_amount' | 'percentage' | 'conditional';
  default_amount: number | null;
  default_percentage: number | null;
  frequency: 'daily' | 'weekly' | 'monthly' | 'per_pay_period' | 'one_time';
  max_percentage_of_pay: number | null;
  requires_approval: boolean;
  active: boolean;
}

export default function DeductionTypesPage() {
  const { user, isAuthenticated } = useAuth();
  
  // Admin and accountant only - prevent supervisor access
  const hasAccess = useRouteProtection(isAuthenticated, user, { adminAndAccountantOnly: true });
  
  const [deductionTypes, setDeductionTypes] = useState<PayrollDeductionType[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filteredTypes, setFilteredTypes] = useState<PayrollDeductionType[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingType, setEditingType] = useState<PayrollDeductionType | null>(null);
  const [deleteConfirmType, setDeleteConfirmType] = useState<PayrollDeductionType | null>(null);

  // Form state for add/edit modal
  const [formData, setFormData] = useState<CreateDeductionTypeData>({
    name: "",
    description: "",
    type: "fixed_amount",
    default_amount: null,
    default_percentage: null,
    frequency: "per_pay_period",
    max_percentage_of_pay: null,
    requires_approval: false,
    active: true
  });

  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);

  const canManageDeductionTypes = user?.permissions?.some(p => 
    p.permission_id === 'payroll_manage_deduction_types' && p.granted
  ) || user?.role_name?.toLowerCase() === 'admin';

  const fetchDeductionTypes = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await payrollApi.getDeductionTypes();
      const types = response.deduction_types || [];
      setDeductionTypes(types);
      setFilteredTypes(types);
    } catch (err: any) {
      console.error('Error fetching deduction types:', err);
      setError(err.response?.data?.message || 'Failed to fetch deduction types');
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setFormData({
      name: "",
      description: "",
      type: "fixed_amount",
      default_amount: null,
      default_percentage: null,
      frequency: "per_pay_period",
      max_percentage_of_pay: null,
      requires_approval: false,
      active: true
    });
    setFormErrors({});
  };

  const validateForm = (): boolean => {
    const errors: Record<string, string> = {};

    if (!formData.name.trim()) {
      errors.name = "Name is required";
    }

    if (formData.type === 'fixed_amount' && !formData.default_amount) {
      errors.default_amount = "Default amount is required for fixed amount type";
    }

    if (formData.type === 'percentage' && !formData.default_percentage) {
      errors.default_percentage = "Default percentage is required for percentage type";
    }

    if (formData.type === 'percentage' && formData.default_percentage && (formData.default_percentage < 0 || formData.default_percentage > 100)) {
      errors.default_percentage = "Percentage must be between 0 and 100";
    }

    if (formData.max_percentage_of_pay && (formData.max_percentage_of_pay < 0 || formData.max_percentage_of_pay > 100)) {
      errors.max_percentage_of_pay = "Max percentage must be between 0 and 100";
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    try {
      setSubmitting(true);
      
      const submitData = {
        ...formData,
        default_amount: formData.type === 'fixed_amount' ? formData.default_amount : null,
        default_percentage: formData.type === 'percentage' ? formData.default_percentage : null,
      };

      if (editingType) {
        await payrollApi.updateDeductionType(editingType._id, submitData);
      } else {
        await payrollApi.createDeductionType(submitData);
      }

      await fetchDeductionTypes();
      setShowAddModal(false);
      setEditingType(null);
      resetForm();
    } catch (err: any) {
      console.error('Error saving deduction type:', err);
      setError(err.response?.data?.message || 'Failed to save deduction type');
    } finally {
      setSubmitting(false);
    }
  };

  const handleEdit = (type: PayrollDeductionType) => {
    setEditingType(type);
    setFormData({
      name: type.name,
      description: type.description || "",
      type: type.type,
      default_amount: type.default_amount,
      default_percentage: type.default_percentage,
      frequency: type.frequency,
      max_percentage_of_pay: type.max_percentage_of_pay,
      requires_approval: type.requires_approval,
      active: type.active
    });
    setShowAddModal(true);
  };

  const handleDelete = async (type: PayrollDeductionType) => {
    if (type.is_system_type) {
      setError("Cannot delete system deduction types");
      return;
    }

    try {
      await payrollApi.deleteDeductionType(type._id);
      await fetchDeductionTypes();
      setDeleteConfirmType(null);
    } catch (err: any) {
      console.error('Error deleting deduction type:', err);
      setError(err.response?.data?.message || 'Failed to delete deduction type');
    }
  };

  const handleToggleActive = async (type: PayrollDeductionType) => {
    try {
      await payrollApi.updateDeductionType(type._id, {
        ...type,
        active: !type.active
      });
      await fetchDeductionTypes();
    } catch (err: any) {
      console.error('Error toggling deduction type status:', err);
      setError(err.response?.data?.message || 'Failed to update deduction type status');
    }
  };

  useEffect(() => {
    fetchDeductionTypes();
  }, []);

  useEffect(() => {
    if (!searchTerm) {
      setFilteredTypes(deductionTypes);
    } else {
      const filtered = deductionTypes.filter(type =>
        type.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (type.description || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        type.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
        type.frequency.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredTypes(filtered);
    }
  }, [searchTerm, deductionTypes]);

  const getTypeDisplayName = (type: string) => {
    switch (type) {
      case 'fixed_amount': return 'Fixed Amount';
      case 'percentage': return 'Percentage';
      case 'conditional': return 'Conditional';
      default: return type;
    }
  };

  const getFrequencyDisplayName = (frequency: string) => {
    switch (frequency) {
      case 'daily': return 'Daily';
      case 'weekly': return 'Weekly';
      case 'monthly': return 'Monthly';
      case 'per_pay_period': return 'Per Pay Period';
      case 'one_time': return 'One Time';
      default: return frequency;
    }
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          <span className="ml-3 text-gray-600">Loading deduction types...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Deduction Types</h1>
          <p className="text-gray-600 mt-2">
            Manage payroll deduction types and configure their settings
          </p>
        </div>
        <div className="flex items-center gap-4">
          <Link href="/payroll/deductions">
            <Button variant="outline">
              Back to Deductions
            </Button>
          </Link>
          {canManageDeductionTypes && (
            <Button 
              onClick={() => {
                resetForm();
                setEditingType(null);
                setShowAddModal(true);
              }}
              className="flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              Add Deduction Type
            </Button>
          )}
        </div>
      </div>

      {/* Error Display */}
      {error && (
        <Card className="border-red-200">
          <CardContent className="p-4">
            <div className="flex items-center gap-3 text-red-600">
              <AlertCircle className="w-5 h-5" />
              <span className="font-medium">Error</span>
            </div>
            <p className="text-red-600 mt-2">{error}</p>
            <Button 
              onClick={() => setError(null)} 
              className="mt-3"
              variant="outline"
              size="sm"
            >
              Dismiss
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Types</CardTitle>
            <Settings className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{deductionTypes.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Types</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{deductionTypes.filter(t => t.active).length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">System Types</CardTitle>
            <AlertCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{deductionTypes.filter(t => t.is_system_type).length}</div>
          </CardContent>
        </Card>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              type="text"
              placeholder="Search deduction types by name, description, type, or frequency..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Deduction Types List */}
      <Card>
        <CardHeader>
          <CardTitle>Deduction Types</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredTypes.length === 0 ? (
            <div className="text-center py-8">
              <Settings className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">
                {searchTerm ? 'No deduction types match your search criteria' : 'No deduction types found'}
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredTypes.map((type) => (
                <div key={type._id} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-4">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-gray-900">{type.name}</span>
                            {type.is_system_type && (
                              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                System
                              </span>
                            )}
                            <button
                              onClick={() => handleToggleActive(type)}
                              className="flex items-center gap-1"
                              disabled={type.is_system_type}
                            >
                              {type.active ? (
                                <ToggleRight className="w-5 h-5 text-green-600" />
                              ) : (
                                <ToggleLeft className="w-5 h-5 text-gray-400" />
                              )}
                              <span className={`text-xs ${type.active ? 'text-green-600' : 'text-gray-400'}`}>
                                {type.active ? 'Active' : 'Inactive'}
                              </span>
                            </button>
                          </div>
                          {type.description && (
                            <div className="text-sm text-gray-500 mt-1">{type.description}</div>
                          )}
                          <div className="flex items-center gap-4 mt-2 text-xs text-gray-500">
                            <span>Type: {getTypeDisplayName(type.type)}</span>
                            <span>Frequency: {getFrequencyDisplayName(type.frequency)}</span>
                            {type.default_amount && (
                              <span>Default: ${type.default_amount}</span>
                            )}
                            {type.default_percentage && (
                              <span>Default: {type.default_percentage}%</span>
                            )}
                            {type.requires_approval && (
                              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                                Requires Approval
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                    {canManageDeductionTypes && (
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEdit(type)}
                          className="flex items-center gap-1"
                        >
                          <Edit2 className="w-3 h-3" />
                          Edit
                        </Button>
                        {!type.is_system_type && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setDeleteConfirmType(type)}
                            className="flex items-center gap-1 text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="w-3 h-3" />
                            Delete
                          </Button>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add/Edit Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <h2 className="text-xl font-bold mb-4">
                {editingType ? 'Edit Deduction Type' : 'Add New Deduction Type'}
              </h2>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Name *</label>
                  <Input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    className={formErrors.name ? 'border-red-500' : ''}
                  />
                  {formErrors.name && <p className="text-red-500 text-xs mt-1">{formErrors.name}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                  <Input
                    type="text"
                    value={formData.description}
                    onChange={(e) => setFormData({...formData, description: e.target.value})}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Type *</label>
                    <select
                      value={formData.type}
                      onChange={(e) => setFormData({...formData, type: e.target.value as any})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    >
                      <option value="fixed_amount">Fixed Amount</option>
                      <option value="percentage">Percentage</option>
                      <option value="conditional">Conditional</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Frequency *</label>
                    <select
                      value={formData.frequency}
                      onChange={(e) => setFormData({...formData, frequency: e.target.value as any})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    >
                      <option value="daily">Daily</option>
                      <option value="weekly">Weekly</option>
                      <option value="monthly">Monthly</option>
                      <option value="per_pay_period">Per Pay Period</option>
                      <option value="one_time">One Time</option>
                    </select>
                  </div>
                </div>

                {formData.type === 'fixed_amount' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Default Amount *</label>
                    <Input
                      type="number"
                      step="0.01"
                      value={formData.default_amount || ''}
                      onChange={(e) => setFormData({...formData, default_amount: e.target.value ? parseFloat(e.target.value) : null})}
                      className={formErrors.default_amount ? 'border-red-500' : ''}
                    />
                    {formErrors.default_amount && <p className="text-red-500 text-xs mt-1">{formErrors.default_amount}</p>}
                  </div>
                )}

                {formData.type === 'percentage' && (
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Default Percentage *</label>
                      <Input
                        type="number"
                        step="0.01"
                        value={formData.default_percentage || ''}
                        onChange={(e) => setFormData({...formData, default_percentage: e.target.value ? parseFloat(e.target.value) : null})}
                        className={formErrors.default_percentage ? 'border-red-500' : ''}
                      />
                      {formErrors.default_percentage && <p className="text-red-500 text-xs mt-1">{formErrors.default_percentage}</p>}
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Max % of Pay</label>
                      <Input
                        type="number"
                        step="0.01"
                        value={formData.max_percentage_of_pay || ''}
                        onChange={(e) => setFormData({...formData, max_percentage_of_pay: e.target.value ? parseFloat(e.target.value) : null})}
                        className={formErrors.max_percentage_of_pay ? 'border-red-500' : ''}
                      />
                      {formErrors.max_percentage_of_pay && <p className="text-red-500 text-xs mt-1">{formErrors.max_percentage_of_pay}</p>}
                    </div>
                  </div>
                )}

                <div className="flex items-center gap-4">
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={formData.requires_approval}
                      onChange={(e) => setFormData({...formData, requires_approval: e.target.checked})}
                    />
                    <span className="text-sm text-gray-700">Requires Approval</span>
                  </label>

                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={formData.active}
                      onChange={(e) => setFormData({...formData, active: e.target.checked})}
                    />
                    <span className="text-sm text-gray-700">Active</span>
                  </label>
                </div>

                <div className="flex justify-end gap-3 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setShowAddModal(false);
                      setEditingType(null);
                      resetForm();
                    }}
                  >
                    Cancel
                  </Button>
                  <Button type="submit" disabled={submitting}>
                    {submitting ? 'Saving...' : (editingType ? 'Update' : 'Create')}
                  </Button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmType && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
            <div className="p-6">
              <div className="flex items-center gap-3 text-red-600 mb-4">
                <AlertCircle className="w-6 h-6" />
                <h2 className="text-lg font-bold">Delete Deduction Type</h2>
              </div>
              
              <p className="text-gray-600 mb-6">
                Are you sure you want to delete "{deleteConfirmType.name}"? This action cannot be undone.
              </p>

              <div className="flex justify-end gap-3">
                <Button
                  variant="outline"
                  onClick={() => setDeleteConfirmType(null)}
                >
                  Cancel
                </Button>
                <Button
                  onClick={() => handleDelete(deleteConfirmType)}
                  className="bg-red-600 hover:bg-red-700"
                >
                  Delete
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}