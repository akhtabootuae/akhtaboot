"use client";

import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import Link from "next/link";
import { Calendar, Clock, Users, Plus, Search, Filter, Download, ArrowLeft } from "lucide-react";
import { payrollApi } from "../../../services/api";
import { PayrollTimeSheet, PayrollEmployee } from "../../types/payroll";
import { useAuth } from "../../context/AuthContext";
import { useRouteProtection } from "../../../services/route-protection";
import useDebounce from "../../hooks/useDebounce";

export default function AttendancePage() {
  const { user, isAuthenticated } = useAuth();
  
  // Admin and accountant only - prevent supervisor access
  const hasAccess = useRouteProtection(isAuthenticated, user, { adminAndAccountantOnly: true });
  
  const [timeSheets, setTimeSheets] = useState<PayrollTimeSheet[]>([]);
  const [employees, setEmployees] = useState<PayrollEmployee[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filters, setFilters] = useState({
    employee_id: '',
    start_date: '',
    end_date: '',
    status: '',
    search: ''
  });

  // Debounce the search term to avoid excessive API calls
  const debouncedSearch = useDebounce(filters.search, 300);

  const canManageAttendance = user?.permissions?.some(p => 
    p.permission_id === 'payroll_manage_attendance' && p.granted
  ) || user?.role_name?.toLowerCase() === 'admin';

  const canViewAllAttendance = user?.permissions?.some(p => 
    p.permission_id === 'payroll_view_all_attendance' && p.granted
  ) || user?.role_name?.toLowerCase() === 'admin';

  // Effect for non-search filters only (immediate API calls)
  useEffect(() => {
    fetchData();
  }, [filters.employee_id, filters.start_date, filters.end_date, filters.status]);

  const fetchData = async () => {
    try {
      setLoading(true);
      setError(null);

      // Fetch employees
      const employeesResponse = await payrollApi.getEmployees();
      setEmployees(employeesResponse.employees || []);

      // Fetch time sheets with filters (excluding search - search is handled locally)
      const timeSheetsFilters = {
        employee_id: filters.employee_id,
        start_date: filters.start_date,
        end_date: filters.end_date,
        status: filters.status,
        page: 1,
        limit: 50
      };

      // Remove empty filters
      Object.keys(timeSheetsFilters).forEach(key => {
        if (!timeSheetsFilters[key as keyof typeof timeSheetsFilters]) {
          delete timeSheetsFilters[key as keyof typeof timeSheetsFilters];
        }
      });

      const timeSheetsResponse = await payrollApi.getTimeSheets(timeSheetsFilters);
      setTimeSheets(timeSheetsResponse.timesheets || []);

    } catch (err: any) {
      console.error('Error fetching attendance data:', err);
      setError(err.response?.data?.message || 'Failed to fetch attendance data');
    } finally {
      setLoading(false);
    }
  };

  const handleFilterChange = (field: string, value: string) => {
    setFilters(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const formatTime = (dateString: string | undefined) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      draft: { color: 'bg-gray-100 text-gray-800', label: 'Draft' },
      submitted: { color: 'bg-blue-100 text-blue-800', label: 'Submitted' },
      approved: { color: 'bg-green-100 text-green-800', label: 'Approved' },
      rejected: { color: 'bg-red-100 text-red-800', label: 'Rejected' }
    };

    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.draft;

    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${config.color}`}>
        {config.label}
      </span>
    );
  };

  const filteredTimeSheets = timeSheets.filter(timeSheet => {
    if (debouncedSearch) {
      const searchLower = debouncedSearch.toLowerCase();
      const employeeName = `${timeSheet.employee?.first_name} ${timeSheet.employee?.last_name}`.toLowerCase();
      return employeeName.includes(searchLower);
    }
    return true;
  });

  if (loading) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          <span className="ml-3 text-gray-600">Loading attendance data...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <Card className="border-red-200">
          <CardContent className="p-6">
            <div className="flex items-center gap-3 text-red-600">
              <Calendar className="w-5 h-5" />
              <span className="font-medium">Error loading attendance data</span>
            </div>
            <p className="text-red-600 mt-2">{error}</p>
            <Button onClick={fetchData} variant="outline" className="mt-4">
              Try Again
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/payroll">
            <Button variant="outline" size="sm" className="flex items-center gap-2">
              <ArrowLeft className="w-4 h-4" />
              Back
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Attendance Management</h1>
            <p className="text-gray-600 mt-2">
              Track and manage employee attendance and time sheets
            </p>
          </div>
        </div>
        {canManageAttendance && (
          <Link href="/payroll/attendance/new">
            <Button className="flex items-center gap-2">
              <Plus className="w-4 h-4" />
              Add Time Sheet
            </Button>
          </Link>
        )}
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="w-5 h-5" />
            Filters
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Search Employee
              </label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search by name..."
                  value={filters.search}
                  onChange={(e) => handleFilterChange('search', e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Employee
              </label>
              <select
                value={filters.employee_id}
                onChange={(e) => handleFilterChange('employee_id', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">All Employees</option>
                {employees.map((employee) => (
                  <option key={employee._id} value={employee._id}>
                    {employee.first_name} {employee.last_name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Status
              </label>
              <select
                value={filters.status}
                onChange={(e) => handleFilterChange('status', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">All Statuses</option>
                <option value="draft">Draft</option>
                <option value="submitted">Submitted</option>
                <option value="approved">Approved</option>
                <option value="rejected">Rejected</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Start Date
              </label>
              <Input
                type="date"
                value={filters.start_date}
                onChange={(e) => handleFilterChange('start_date', e.target.value)}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                End Date
              </label>
              <Input
                type="date"
                value={filters.end_date}
                onChange={(e) => handleFilterChange('end_date', e.target.value)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Users className="w-8 h-8 text-blue-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-500">Total Records</p>
                <p className="text-2xl font-semibold text-gray-900">{filteredTimeSheets.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Calendar className="w-8 h-8 text-green-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-500">Approved</p>
                <p className="text-2xl font-semibold text-gray-900">
                  {filteredTimeSheets.filter(ts => ts.status === 'approved').length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Clock className="w-8 h-8 text-orange-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-500">Avg Hours/Day</p>
                <p className="text-2xl font-semibold text-gray-900">
                  {filteredTimeSheets.length > 0 ? 
                    (filteredTimeSheets.reduce((sum, ts) => sum + (ts.total_hours || 0), 0) / filteredTimeSheets.length).toFixed(1) : 
                    '0'
                  }
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Download className="w-8 h-8 text-purple-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-500">Export Data</p>
                <Button variant="outline" size="sm" className="mt-1">
                  Download Report
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Time Sheets Table */}
      <Card>
        <CardHeader>
          <CardTitle>Time Sheets</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredTimeSheets.length === 0 ? (
            <div className="text-center py-8">
              <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 mb-4">No time sheets found matching your criteria.</p>
              {canManageAttendance && (
                <Link href="/payroll/attendance/new">
                  <Button>
                    <Plus className="w-4 h-4 mr-2" />
                    Add First Time Sheet
                  </Button>
                </Link>
              )}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Employee
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Date
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Hours Worked
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredTimeSheets.map((timeSheet) => (
                    <tr key={timeSheet._id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div>
                            <div className="text-sm font-medium text-gray-900">
                              {timeSheet.employee?.first_name} {timeSheet.employee?.last_name}
                            </div>
                            <div className="text-sm text-gray-500">
                              {timeSheet.employee?.speciality}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {formatDate(timeSheet.work_date)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {getStatusBadge(timeSheet.status)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        <div>
                          <div>Total: {timeSheet.total_hours?.toFixed(1) || '0'} hours</div>
                          {timeSheet.total_hours && timeSheet.total_hours > 8 && (
                            <div className="text-orange-600 text-xs mt-1">
                              ⚠️ Overtime: {(timeSheet.total_hours - 8).toFixed(1)} hours
                              <div className="text-gray-500">Pending approval</div>
                            </div>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <div className="flex items-center gap-2">
                          <Link href={`/payroll/attendance/${timeSheet._id}`}>
                            <Button
                              size="sm"
                              variant="outline"
                            >
                              View
                            </Button>
                          </Link>
                          {canManageAttendance && (
                            <Link href={`/payroll/attendance/${timeSheet._id}/edit`}>
                              <Button
                                size="sm"
                                variant="outline"
                              >
                                Edit
                              </Button>
                            </Link>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}