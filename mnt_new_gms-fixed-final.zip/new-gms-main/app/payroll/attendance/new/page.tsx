"use client";

import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../../../components/ui/card";
import { Button } from "../../../components/ui/button";
import { Input } from "../../../components/ui/input";
import { useRouter } from "next/navigation";
import { ArrowLeft, Save, Calendar, User, AlertCircle, Plus, X } from "lucide-react";
import { payrollApi } from "../../../../services/api";
import { PayrollEmployee, PayrollPayPeriod } from "../../../types/payroll";
import { useAuth } from "../../../context/AuthContext";
import { useRouteProtection } from "../../../../services/route-protection";

interface WorkOrder {
  _id: string;
  order_number: string;
  customer_name: string;
  parts: Array<{
    part_name: string;
    variation_name: string;
  }>;
}

export default function NewTimesheetPage() {
  const router = useRouter();
  const { user, isAuthenticated } = useAuth();
  
  // Admin and accountant only - prevent supervisor access
  const hasAccess = useRouteProtection(isAuthenticated, user, { adminAndAccountantOnly: true });

  const [employees, setEmployees] = useState<PayrollEmployee[]>([]);
  const [payPeriods, setPayPeriods] = useState<PayrollPayPeriod[]>([]);
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  
  const [formData, setFormData] = useState({
    employee_id: '',
    work_date: new Date().toISOString().split('T')[0],
    work_order_ids: [] as string[],
    notes: '',
    status: 'draft' as 'draft' | 'submitted'
  });
  
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});
  const [workOrderSearch, setWorkOrderSearch] = useState('');
  const [showWorkOrderDropdown, setShowWorkOrderDropdown] = useState(false);

  const canManageTimesheets = user?.permissions?.some(p => 
    p.permission_id === 'payroll_manage_attendance' && p.granted
  ) || user?.role_name?.toLowerCase() === 'admin';

  useEffect(() => {
    if (!canManageTimesheets) {
      router.push('/unauthorized');
      return;
    }
    fetchInitialData();
  }, [canManageTimesheets, router]);

  const fetchInitialData = async () => {
    try {
      setLoading(true);
      setError(null);

      // Fetch employees
      const [employeesResponse, payPeriodsResponse] = await Promise.all([
        payrollApi.getEmployees({ active: true }),
        payrollApi.getPayPeriods({ status: 'open' })
      ]);

      setEmployees(employeesResponse.employees || []);
      setPayPeriods(payPeriodsResponse.pay_periods || []);

      // Fetch work orders separately
      try {
        const workOrdersResponse = await fetch('/api/work-orders?status=approved,quality_passed');
        if (workOrdersResponse.ok) {
          const data = await workOrdersResponse.json();
          setWorkOrders(data.data || []);
        }
      } catch (err) {
        console.warn('Could not fetch work orders:', err);
      }

    } catch (err: any) {
      console.error('Error fetching initial data:', err);
      setError(err.response?.data?.message || 'Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  const validateForm = () => {
    const errors: Record<string, string> = {};

    if (!formData.employee_id) {
      errors.employee_id = 'Please select an employee';
    }

    if (!formData.work_date) {
      errors.work_date = 'Work date is required';
    }

    // Check if date is not in the future
    if (formData.work_date && new Date(formData.work_date) > new Date()) {
      errors.work_date = 'Work date cannot be in the future';
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    
    // Clear validation error for this field
    if (validationErrors[field]) {
      setValidationErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[field];
        return newErrors;
      });
    }
  };

  const handleAddWorkOrder = (workOrderId: string) => {
    if (!formData.work_order_ids.includes(workOrderId)) {
      handleInputChange('work_order_ids', [...formData.work_order_ids, workOrderId]);
    }
    setWorkOrderSearch('');
    setShowWorkOrderDropdown(false);
  };

  const handleRemoveWorkOrder = (workOrderId: string) => {
    handleInputChange('work_order_ids', formData.work_order_ids.filter(id => id !== workOrderId));
  };

  const handleSubmit = async (submitAfterSave = false) => {
    if (!validateForm()) {
      return;
    }

    try {
      setSaving(true);
      setError(null);
      setSuccessMessage(null);

      // Create the timesheet
      console.log('Creating timesheet with data:', formData);
      const createResponse = await payrollApi.createTimeSheet({
        ...formData,
        status: submitAfterSave ? 'submitted' : 'draft'
      });

      console.log('Create response:', createResponse);

      // Extract the ID from the response
      const timesheetId = createResponse.timesheet?._id;
      if (!timesheetId) {
        throw new Error('Failed to get timesheet ID from response');
      }

      // Fetch the complete timesheet details
      console.log('Fetching created timesheet:', timesheetId);
      const fetchResponse = await payrollApi.getTimeSheet(timesheetId);
      console.log('Fetch response:', fetchResponse);

      setSuccessMessage('Timesheet created successfully!');
      
      // Redirect to the timesheet detail page after a short delay
      setTimeout(() => {
        router.push(`/payroll/attendance/${timesheetId}`);
      }, 1500);

    } catch (err: any) {
      console.error('Error creating timesheet:', err);
      setError(err.response?.data?.message || 'Failed to create timesheet');
    } finally {
      setSaving(false);
    }
  };

  const filteredWorkOrders = workOrders.filter(wo => {
    const searchLower = workOrderSearch.toLowerCase();
    return wo.order_number.toLowerCase().includes(searchLower) ||
           wo.customer_name.toLowerCase().includes(searchLower) ||
           wo.parts.some(p => 
             p.part_name.toLowerCase().includes(searchLower) ||
             p.variation_name.toLowerCase().includes(searchLower)
           );
  });

  const selectedWorkOrders = workOrders.filter(wo => 
    formData.work_order_ids.includes(wo._id)
  );

  if (loading) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          <span className="ml-3 text-gray-600">Loading...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="mb-6">
        <Button 
          variant="outline" 
          size="sm" 
          onClick={() => router.back()}
          className="mb-4 flex items-center gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          Back
        </Button>
        <h1 className="text-3xl font-bold text-gray-900">Create New Timesheet</h1>
        <p className="text-gray-600 mt-2">Record employee attendance and work hours</p>
      </div>

      {/* Success Message */}
      {successMessage && (
        <Card className="mb-6 border-green-200 bg-green-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-green-700">
              <Calendar className="w-5 h-5" />
              <span className="font-medium">{successMessage}</span>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Error Message */}
      {error && (
        <Card className="mb-6 border-red-200 bg-red-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-red-700">
              <AlertCircle className="w-5 h-5" />
              <span className="font-medium">{error}</span>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Form */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            Timesheet Information
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={(e) => { e.preventDefault(); handleSubmit(false); }} className="space-y-6">
            {/* Employee Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Employee *
              </label>
              <select
                value={formData.employee_id}
                onChange={(e) => handleInputChange('employee_id', e.target.value)}
                className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
                  validationErrors.employee_id ? 'border-red-500' : 'border-gray-300'
                }`}
                disabled={saving}
              >
                <option value="">Select an employee</option>
                {employees.map((employee) => (
                  <option key={employee._id} value={employee._id}>
                    {employee.first_name} {employee.last_name} - {employee.speciality} ({employee.branch.branch_name})
                  </option>
                ))}
              </select>
              {validationErrors.employee_id && (
                <p className="mt-1 text-sm text-red-600">{validationErrors.employee_id}</p>
              )}
            </div>

            {/* Work Date */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Work Date *
              </label>
              <Input
                type="date"
                value={formData.work_date}
                onChange={(e) => handleInputChange('work_date', e.target.value)}
                max={new Date().toISOString().split('T')[0]}
                className={validationErrors.work_date ? 'border-red-500' : ''}
                disabled={saving}
              />
              {validationErrors.work_date && (
                <p className="mt-1 text-sm text-red-600">{validationErrors.work_date}</p>
              )}
            </div>

            {/* Work Orders */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Work Orders (Optional)
              </label>
              <div className="relative">
                <Input
                  type="text"
                  value={workOrderSearch}
                  onChange={(e) => {
                    setWorkOrderSearch(e.target.value);
                    setShowWorkOrderDropdown(true);
                  }}
                  onFocus={() => setShowWorkOrderDropdown(true)}
                  placeholder="Search work orders by number, customer, or part..."
                  disabled={saving}
                />
                
                {/* Work Order Dropdown */}
                {showWorkOrderDropdown && workOrderSearch && filteredWorkOrders.length > 0 && (
                  <div className="absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-md shadow-lg max-h-60 overflow-auto">
                    {filteredWorkOrders.slice(0, 10).map((wo) => (
                      <button
                        key={wo._id}
                        type="button"
                        onClick={() => handleAddWorkOrder(wo._id)}
                        className="w-full px-4 py-2 text-left hover:bg-gray-100 focus:bg-gray-100 focus:outline-none"
                      >
                        <div className="font-medium">{wo.order_number} - {wo.customer_name}</div>
                        <div className="text-sm text-gray-600">
                          {wo.parts.map(p => `${p.part_name} (${p.variation_name})`).join(', ')}
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Selected Work Orders */}
              {selectedWorkOrders.length > 0 && (
                <div className="mt-3 space-y-2">
                  {selectedWorkOrders.map((wo) => (
                    <div key={wo._id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                      <div>
                        <span className="font-medium">{wo.order_number}</span>
                        <span className="text-gray-600 ml-2">- {wo.customer_name}</span>
                      </div>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => handleRemoveWorkOrder(wo._id)}
                        className="h-6 w-6 p-0"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Notes */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Notes (Optional)
              </label>
              <textarea
                value={formData.notes}
                onChange={(e) => handleInputChange('notes', e.target.value)}
                placeholder="Any additional notes about this timesheet..."
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none"
                rows={3}
                disabled={saving}
              />
            </div>

            {/* Active Pay Period Info */}
            {payPeriods.length > 0 && (
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <div className="text-sm font-medium text-blue-900 mb-1">Active Pay Period</div>
                <div className="text-sm text-blue-700">
                  {payPeriods[0].period_name} ({new Date(payPeriods[0].start_date).toLocaleDateString()} - {new Date(payPeriods[0].end_date).toLocaleDateString()})
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex gap-3 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => router.back()}
                disabled={saving}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={saving || !formData.employee_id || !formData.work_date}
                className="flex-1 flex items-center gap-2"
              >
                {saving ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    Creating...
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    Save as Draft
                  </>
                )}
              </Button>
              <Button
                type="button"
                onClick={() => handleSubmit(true)}
                disabled={saving || !formData.employee_id || !formData.work_date}
                className="flex-1 flex items-center gap-2"
              >
                {saving ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    Creating...
                  </>
                ) : (
                  <>
                    <Plus className="w-4 h-4" />
                    Create & Submit
                  </>
                )}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}