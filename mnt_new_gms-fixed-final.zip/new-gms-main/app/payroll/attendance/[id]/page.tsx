"use client";

import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../../../components/ui/card";
import { Button } from "../../../components/ui/button";
import { useParams, useRouter } from "next/navigation";
import { ArrowLeft, Clock, Calendar, User, FileText, CheckCircle, AlertCircle, Send, X } from "lucide-react";
import { payrollApi } from "../../../../services/api";
import api from "../../../../services/api";
import { PayrollTimeSheet } from "../../../types/payroll";
import { useAuth } from "../../../context/AuthContext";
import { useRouteProtection } from "../../../../services/route-protection";

export default function TimesheetDetailPage() {
  const params = useParams();
  const router = useRouter();
  const { user, isAuthenticated } = useAuth();
  
  // Admin and accountant only - prevent supervisor access
  const hasAccess = useRouteProtection(isAuthenticated, user, { adminAndAccountantOnly: true });
  
  const timesheetId = params.id as string;

  const [timesheet, setTimesheet] = useState<PayrollTimeSheet | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const canManageAttendance = user?.permissions?.some(p => 
    p.permission_id === 'payroll_manage_attendance' && p.granted
  ) || user?.role_name?.toLowerCase() === 'admin';

  const canApproveTimesheets = user?.permissions?.some(p => 
    p.permission_id === 'payroll_approve_timesheets' && p.granted
  ) || user?.role_name?.toLowerCase() === 'admin';

  useEffect(() => {
    fetchTimesheet();
  }, [timesheetId]);

  const fetchTimesheet = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await payrollApi.getTimeSheet(timesheetId);
      const timesheetData = response.timesheet;
      
      // If employee information is missing, fetch it separately
      if (timesheetData && timesheetData.employee_id && !timesheetData.employee) {
        try {
          const employeeResponse = await api.get(`/api/users/${timesheetData.employee_id}`);
          if (employeeResponse && !employeeResponse.error) {
            timesheetData.employee = {
              first_name: employeeResponse.first_name,
              last_name: employeeResponse.last_name,
              email: employeeResponse.email,
              speciality: employeeResponse.speciality,
              branch: employeeResponse.branch
            };
          }
        } catch (employeeErr) {
          console.warn('Could not fetch employee information:', employeeErr);
        }
      }
      
      setTimesheet(timesheetData);
    } catch (err: any) {
      console.error('Error fetching timesheet:', err);
      setError(err.response?.data?.message || 'Failed to fetch timesheet');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitTimesheet = async () => {
    if (!timesheet) return;
    
    try {
      setActionLoading('submit');
      setError(null);
      await payrollApi.submitTimeSheet(timesheetId);
      
      // Check if this is an absence (total hours is 0 or very low) and send notification to supervisors
      if (timesheet.total_hours === 0 || timesheet.total_hours < 0.5) {
        try {
          const notificationData = {
            type: "general",
            title: "Employee Absence Alert",
            message: `${timesheet.employee?.first_name || 'Unknown'} ${timesheet.employee?.last_name || 'Employee'} has submitted a timesheet showing absence for ${new Date(timesheet.work_date).toLocaleDateString()}. Total hours worked: ${timesheet.total_hours || 0} hours. ${timesheet.notes ? 'Notes: ' + timesheet.notes : ''}`,
            recipientType: "supervisor",
            priority: "medium",
            employeeId: timesheet.employee_id,
            timesheetId: timesheetId
          };
          
          await api.post('/api/notifications', notificationData);
        } catch (notifError) {
          console.error('Error sending absence notification:', notifError);
          // Don't fail the main operation if notification fails
        }
      }
      
      setSuccessMessage('Timesheet submitted successfully!');
      await fetchTimesheet(); // Refresh to get updated status
    } catch (err: any) {
      console.error('Error submitting timesheet:', err);
      setError(err.response?.data?.message || 'Failed to submit timesheet');
    } finally {
      setActionLoading(null);
    }
  };

  const handleApproveTimesheet = async () => {
    if (!timesheet) return;
    
    if (!confirm('Are you sure you want to approve this timesheet?')) {
      return;
    }
    
    try {
      setActionLoading('approve');
      setError(null);
      await payrollApi.approveTimeSheet(timesheetId);
      setSuccessMessage('Timesheet approved successfully!');
      await fetchTimesheet(); // Refresh to get updated status
    } catch (err: any) {
      console.error('Error approving timesheet:', err);
      setError(err.response?.data?.message || 'Failed to approve timesheet');
    } finally {
      setActionLoading(null);
    }
  };

  const handleRejectTimesheet = async () => {
    if (!timesheet) return;
    
    const reason = prompt('Please provide a reason for rejection:');
    if (!reason) return;
    
    try {
      setActionLoading('reject');
      setError(null);
      await payrollApi.rejectTimeSheet(timesheetId, reason);
      setSuccessMessage('Timesheet rejected successfully!');
      await fetchTimesheet(); // Refresh to get updated status
    } catch (err: any) {
      console.error('Error rejecting timesheet:', err);
      setError(err.response?.data?.message || 'Failed to reject timesheet');
    } finally {
      setActionLoading(null);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const formatTime = (dateString: string | undefined) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-AE', {
      style: 'currency',
      currency: 'AED',
      minimumFractionDigits: 0,
      maximumFractionDigits: 2,
    }).format(amount);
  };

  const formatDuration = (minutes: number | undefined) => {
    if (!minutes) return 'N/A';
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return hours > 0 ? `${hours}h ${mins}m` : `${mins}m`;
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      draft: { color: 'bg-gray-100 text-gray-800', icon: FileText, label: 'Draft' },
      submitted: { color: 'bg-blue-100 text-blue-800', icon: Clock, label: 'Submitted' },
      approved: { color: 'bg-green-100 text-green-800', icon: CheckCircle, label: 'Approved' },
      rejected: { color: 'bg-red-100 text-red-800', icon: AlertCircle, label: 'Rejected' }
    };

    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.draft;
    const IconComponent = config.icon;

    return (
      <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${config.color}`}>
        <IconComponent className="w-4 h-4 mr-2" />
        {config.label}
      </span>
    );
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          <span className="ml-3 text-gray-600">Loading timesheet...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <Card className="border-red-200">
          <CardContent className="p-6">
            <div className="flex items-center gap-3 text-red-600">
              <AlertCircle className="w-5 h-5" />
              <span className="font-medium">Error loading timesheet</span>
            </div>
            <p className="text-red-600 mt-2">{error}</p>
            <div className="flex gap-3 mt-4">
              <Button onClick={fetchTimesheet} variant="outline">
                Try Again
              </Button>
              <Button onClick={() => router.back()} variant="outline">
                Go Back
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!timesheet) {
    return null;
  }

  return (
    <div className="p-6 space-y-6">
      {/* Success Message */}
      {successMessage && (
        <Card className="border-green-200 bg-green-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-green-700">
              <CheckCircle className="w-5 h-5" />
              <span className="font-medium">{successMessage}</span>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Error Message */}
      {error && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-red-700">
              <AlertCircle className="w-5 h-5" />
              <span className="font-medium">{error}</span>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => router.back()}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Timesheet Details</h1>
            <p className="text-gray-600 mt-1">
              {formatDate(timesheet.work_date)}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {getStatusBadge(timesheet.status)}
          
          {/* Action Buttons */}
          {timesheet.status === 'draft' && canManageAttendance && (
            <>
              <Button 
                onClick={() => router.push(`/payroll/attendance/${timesheetId}/edit`)}
                variant="outline"
                className="flex items-center gap-2"
              >
                <FileText className="w-4 h-4" />
                Edit
              </Button>
              <Button 
                onClick={handleSubmitTimesheet}
                disabled={actionLoading === 'submit'}
                className="flex items-center gap-2"
              >
                {actionLoading === 'submit' ? (
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
                {actionLoading === 'submit' ? 'Submitting...' : 'Submit'}
              </Button>
            </>
          )}
          
          {timesheet.status === 'submitted' && canApproveTimesheets && (
            <>
              <Button 
                onClick={handleRejectTimesheet}
                disabled={actionLoading === 'reject'}
                variant="outline"
                className="flex items-center gap-2 text-red-600 border-red-300 hover:bg-red-50"
              >
                {actionLoading === 'reject' ? (
                  <div className="w-4 h-4 border-2 border-red-600 border-t-transparent rounded-full animate-spin" />
                ) : (
                  <X className="w-4 h-4" />
                )}
                {actionLoading === 'reject' ? 'Rejecting...' : 'Reject'}
              </Button>
              <Button 
                onClick={handleApproveTimesheet}
                disabled={actionLoading === 'approve'}
                className="flex items-center gap-2"
              >
                {actionLoading === 'approve' ? (
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <CheckCircle className="w-4 h-4" />
                )}
                {actionLoading === 'approve' ? 'Approving...' : 'Approve'}
              </Button>
            </>
          )}
          
          {timesheet.status === 'approved' && canManageAttendance && (
            <span className="text-sm text-green-600 font-medium">Timesheet Approved</span>
          )}
          
          {timesheet.status === 'rejected' && canManageAttendance && (
            <Button 
              onClick={() => router.push(`/payroll/attendance/${timesheetId}/edit`)}
              variant="outline"
              className="flex items-center gap-2"
            >
              <FileText className="w-4 h-4" />
              Edit & Resubmit
            </Button>
          )}
        </div>
      </div>

      {/* Employee Information */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="w-5 h-5" />
            Employee Information
          </CardTitle>
        </CardHeader>
        <CardContent>
          {timesheet.employee ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <div className="text-sm text-gray-500">Employee Name</div>
                <div className="text-lg font-medium">
                  {timesheet.employee.first_name && timesheet.employee.last_name 
                    ? `${timesheet.employee.first_name} ${timesheet.employee.last_name}`
                    : 'N/A'}
                </div>
              </div>
              <div>
                <div className="text-sm text-gray-500">Email</div>
                <div className="text-lg">{timesheet.employee.email || 'N/A'}</div>
              </div>
              <div>
                <div className="text-sm text-gray-500">Specialty</div>
                <div className="text-lg">{timesheet.employee.speciality || 'N/A'}</div>
              </div>
              <div>
                <div className="text-sm text-gray-500">Branch</div>
                <div className="text-lg">{timesheet.employee.branch?.branch_name || 'N/A'}</div>
              </div>
            </div>
          ) : (
            <div className="text-center py-8">
              <User className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">Employee information not available</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Time Tracking */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Time Tracking
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div>
              <div className="text-sm text-gray-500">Time In</div>
              <div className="text-2xl font-bold text-green-600">
                {timesheet.time_in ? formatTime(timesheet.time_in) : 'Not Recorded'}
              </div>
            </div>
            <div>
              <div className="text-sm text-gray-500">Time Out</div>
              <div className="text-2xl font-bold text-red-600">
                {timesheet.time_out ? formatTime(timesheet.time_out) : 'Not Recorded'}
              </div>
            </div>
            <div>
              <div className="text-sm text-gray-500">Break Duration</div>
              <div className="text-2xl font-bold text-orange-600">
                {timesheet.break_duration != null && timesheet.break_duration > 0 
                  ? formatDuration(timesheet.break_duration) 
                  : 'No Break'}
              </div>
            </div>
            <div>
              <div className="text-sm text-gray-500">Work Date</div>
              <div className="text-lg font-medium">
                {timesheet.work_date ? formatDate(timesheet.work_date) : 'N/A'}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Hours Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            Hours Summary
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <div className="text-sm text-gray-500">Regular Hours</div>
              <div className="text-3xl font-bold text-blue-600">
                {timesheet.regular_hours != null ? timesheet.regular_hours.toFixed(1) : '0.0'} hrs
              </div>
            </div>
            <div>
              <div className="text-sm text-gray-500">Overtime Hours</div>
              <div className="text-3xl font-bold text-orange-600">
                {timesheet.overtime_hours != null ? timesheet.overtime_hours.toFixed(1) : '0.0'} hrs
              </div>
            </div>
            <div>
              <div className="text-sm text-gray-500">Total Hours</div>
              <div className="text-3xl font-bold text-purple-600">
                {timesheet.total_hours != null ? timesheet.total_hours.toFixed(1) : '0.0'} hrs
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Overtime Notice */}
      {timesheet.total_hours != null && timesheet.total_hours > 8 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-orange-600">
              <AlertCircle className="w-5 h-5" />
              Overtime Detected
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="p-4 bg-orange-50 rounded-lg">
              <div className="text-sm text-orange-700 font-medium">
                {(timesheet.total_hours - 8).toFixed(1)} overtime hours will be processed automatically
              </div>
              <div className="text-sm text-orange-600 mt-1">
                Overtime compensation will be created as an expense record upon timesheet approval
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Additional Information */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Work Orders */}
        {timesheet.work_order_ids && timesheet.work_order_ids.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Associated Work Orders</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {timesheet.work_order_ids.map((workOrderId, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="font-mono text-sm">{workOrderId}</span>
                    <Button size="sm" variant="outline">
                      View
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Notes & Status */}
        <Card>
          <CardHeader>
            <CardTitle>Notes & Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {timesheet.notes && (
                <div>
                  <div className="text-sm text-gray-500 font-medium">Notes</div>
                  <div className="mt-1 p-3 bg-gray-50 rounded-lg">
                    {timesheet.notes}
                  </div>
                </div>
              )}
              
              <div>
                <div className="text-sm text-gray-500 font-medium">Status</div>
                <div className="mt-2">
                  {getStatusBadge(timesheet.status)}
                </div>
              </div>

              {timesheet.approved_at && (
                <div>
                  <div className="text-sm text-gray-500 font-medium">Approved At</div>
                  <div className="text-sm">
                    {new Date(timesheet.approved_at).toLocaleString()}
                  </div>
                </div>
              )}
              
              {timesheet.rejection_reason && (
                <div>
                  <div className="text-sm text-red-500 font-medium">Rejection Reason</div>
                  <div className="text-sm text-red-600 mt-1 p-2 bg-red-50 rounded">
                    {timesheet.rejection_reason}
                  </div>
                </div>
              )}

              <div className="pt-2 border-t">
                <div className="text-xs text-gray-400">
                  Created: {new Date(timesheet.created_at || '').toLocaleString()}
                </div>
                {timesheet.updated_at && (
                  <div className="text-xs text-gray-400">
                    Updated: {new Date(timesheet.updated_at).toLocaleString()}
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}