"use client";

import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../../../../components/ui/card";
import { Button } from "../../../../components/ui/button";
import { Input } from "../../../../components/ui/input";
import { useParams, useRouter } from "next/navigation";
import { ArrowLeft, Clock, Save, X, User, AlertCircle, CheckCircle } from "lucide-react";
import { payrollApi } from "../../../../../services/api";
import api from "../../../../../services/api";
import { PayrollTimeSheet } from "../../../../types/payroll";
import { useAuth } from "../../../../context/AuthContext";
import { useRouteProtection } from "../../../../../services/route-protection";

export default function TimesheetEditPage() {
  const params = useParams();
  const router = useRouter();
  const { user, isAuthenticated } = useAuth();
  
  // Admin and accountant only - prevent supervisor access
  const hasAccess = useRouteProtection(isAuthenticated, user, { adminAndAccountantOnly: true });
  
  const timesheetId = params.id as string;

  const [timesheet, setTimesheet] = useState<PayrollTimeSheet | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    time_in: '',
    time_out: '',
    break_duration: 0,
    notes: '',
    status: 'draft' as 'draft' | 'submitted' | 'approved' | 'rejected',
    work_order_ids: [] as string[]
  });
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});

  const canManageTimesheets = user?.permissions?.some(p => 
    p.permission_id === 'payroll_manage_timesheets' && p.granted
  ) || user?.role_name?.toLowerCase() === 'admin';

  useEffect(() => {
    if (!canManageTimesheets) {
      setError('You do not have permission to edit timesheets');
      return;
    }
    fetchTimesheet();
  }, [timesheetId, canManageTimesheets]);

  const fetchTimesheet = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await payrollApi.getTimeSheet(timesheetId);
      const timesheetData = response.timesheet;
      setTimesheet(timesheetData);
      
      // Populate form with existing data
      setFormData({
        time_in: formatDateTimeForInput(timesheetData.time_in),
        time_out: formatDateTimeForInput(timesheetData.time_out),
        break_duration: timesheetData.break_duration || 0,
        notes: timesheetData.notes || '',
        status: timesheetData.status,
        work_order_ids: timesheetData.work_order_ids || []
      });
    } catch (err: any) {
      console.error('Error fetching timesheet:', err);
      setError(err.response?.data?.message || 'Failed to fetch timesheet');
    } finally {
      setLoading(false);
    }
  };

  const formatDateTimeForInput = (dateString: string | undefined) => {
    if (!dateString) return '';
    // Convert to local datetime-local format (YYYY-MM-DDTHH:MM)
    const date = new Date(dateString);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    return `${year}-${month}-${day}T${hours}:${minutes}`;
  };

  const formatDateTimeForAPI = (dateTimeLocal: string) => {
    if (!dateTimeLocal) return '';
    // Convert from datetime-local to ISO string
    const isoString = new Date(dateTimeLocal).toISOString();
    console.log(`Date conversion: ${dateTimeLocal} -> ${isoString}`);
    return isoString;
  };

  const calculateHours = () => {
    if (!formData.time_in || !formData.time_out) return { total: 0, regular: 0, overtime: 0 };
    
    const timeIn = new Date(formData.time_in);
    const timeOut = new Date(formData.time_out);
    const breakMinutes = formData.break_duration || 0;
    
    if (timeOut <= timeIn) return { total: 0, regular: 0, overtime: 0 };
    
    const totalMinutes = (timeOut.getTime() - timeIn.getTime()) / (1000 * 60) - breakMinutes;
    const totalHours = Math.max(0, totalMinutes / 60);
    const regularHours = Math.min(totalHours, 8);
    const overtimeHours = Math.max(0, totalHours - 8);
    
    return {
      total: totalHours,
      regular: regularHours,
      overtime: overtimeHours
    };
  };

  const validateForm = () => {
    const errors: Record<string, string> = {};
    
    if (!formData.time_in) {
      errors.time_in = 'Time in is required';
    }
    
    if (!formData.time_out) {
      errors.time_out = 'Time out is required';
    }
    
    if (formData.time_in && formData.time_out) {
      const timeIn = new Date(formData.time_in);
      const timeOut = new Date(formData.time_out);
      
      if (timeOut <= timeIn) {
        errors.time_out = 'Time out must be after time in';
      }
    }
    
    if (formData.break_duration < 0 || formData.break_duration > 480) {
      errors.break_duration = 'Break duration must be between 0 and 480 minutes';
    }
    
    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    
    // Clear validation error for this field
    if (validationErrors[field]) {
      setValidationErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[field];
        return newErrors;
      });
    }
  };

  const handleWorkOrderIdsChange = (value: string) => {
    // Convert comma-separated string to array
    const ids = value.split(',').map(id => id.trim()).filter(id => id.length > 0);
    handleInputChange('work_order_ids', ids);
  };

  const handleSave = async () => {
    if (!validateForm()) {
      return;
    }
    
    try {
      setSaving(true);
      setError(null);
      
      const updateData = {
        time_in: formatDateTimeForAPI(formData.time_in),
        time_out: formatDateTimeForAPI(formData.time_out),
        break_duration: formData.break_duration,
        notes: formData.notes,
        status: formData.status,
        work_order_ids: formData.work_order_ids
      };
      
      // Detailed logging for debugging
      console.log('=== TIMESHEET UPDATE DEBUG ===');
      console.log('Timesheet ID:', timesheetId);
      console.log('Form Data:', formData);
      console.log('Update Payload:', updateData);
      console.log('API URL:', `/api/payroll/timesheets/${timesheetId}`);
      
      const response = await payrollApi.updateTimeSheet(timesheetId, updateData);
      console.log('Update Response:', response);
      
      // Check if timesheet is being submitted and has absence (0 or very low hours)
      if (formData.status === 'submitted') {
        const calculatedHours = calculateHours();
        if (calculatedHours.total === 0 || calculatedHours.total < 0.5) {
          try {
            const notificationData = {
              type: "general",
              title: "Employee Absence Alert",
              message: `${timesheet?.employee?.first_name || 'Unknown'} ${timesheet?.employee?.last_name || 'Employee'} has submitted a timesheet showing absence for ${timesheet ? new Date(timesheet.work_date).toLocaleDateString() : 'unknown date'}. Total hours worked: ${calculatedHours.total.toFixed(1)} hours. ${formData.notes ? 'Notes: ' + formData.notes : ''}`,
              recipientType: "supervisor",
              priority: "medium",
              employeeId: timesheet?.employee_id,
              timesheetId: timesheetId
            };
            
            await api.post('/api/notifications', notificationData);
          } catch (notifError) {
            console.error('Error sending absence notification:', notifError);
            // Don't fail the main operation if notification fails
          }
        }
      }
      
      // Redirect back to detail view
      router.push(`/payroll/attendance/${timesheetId}`);
    } catch (err: any) {
      console.error('=== ERROR DETAILS ===');
      console.error('Full Error Object:', err);
      console.error('Error Message:', err.message);
      console.error('Response Status:', err.response?.status);
      console.error('Response Data:', err.response?.data);
      console.error('Response Headers:', err.response?.headers);
      console.error('Request Config:', err.config);
      
      // Try to extract more specific error information
      let errorMessage = 'Failed to update timesheet';
      
      if (err.response?.data) {
        if (typeof err.response.data === 'string') {
          errorMessage = err.response.data;
        } else if (err.response.data.message) {
          errorMessage = err.response.data.message;
        } else if (err.response.data.error) {
          errorMessage = err.response.data.error;
        } else if (err.response.data.errors) {
          // Handle validation errors
          const errors = err.response.data.errors;
          if (Array.isArray(errors)) {
            errorMessage = errors.map(e => e.message || e).join(', ');
          } else if (typeof errors === 'object') {
            errorMessage = Object.values(errors).join(', ');
          }
        } else {
          errorMessage = `Server error (${err.response.status}): ${JSON.stringify(err.response.data)}`;
        }
      }
      
      setError(errorMessage);
    } finally {
      setSaving(false);
    }
  };

  const handleCancel = () => {
    router.push(`/payroll/attendance/${timesheetId}`);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-AE', {
      style: 'currency',
      currency: 'AED',
      minimumFractionDigits: 0,
      maximumFractionDigits: 2,
    }).format(amount);
  };

  const hours = calculateHours();
  const estimatedPay = timesheet ? (hours.regular * (timesheet.daily_rate || 0) / 8) + (hours.overtime * (timesheet.daily_rate || 0) / 8 * 1.5) : 0;

  if (loading) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          <span className="ml-3 text-gray-600">Loading timesheet...</span>
        </div>
      </div>
    );
  }

  if (error && !timesheet) {
    return (
      <div className="p-6">
        <Card className="border-red-200">
          <CardContent className="p-6">
            <div className="flex items-center gap-3 text-red-600">
              <AlertCircle className="w-5 h-5" />
              <span className="font-medium">Error loading timesheet</span>
            </div>
            <p className="text-red-600 mt-2">{error}</p>
            <div className="flex gap-3 mt-4">
              <Button onClick={fetchTimesheet} variant="outline">
                Try Again
              </Button>
              <Button onClick={() => router.back()} variant="outline">
                Go Back
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!timesheet) {
    return null;
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => router.push(`/payroll/attendance/${timesheetId}`)}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Details
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Edit Timesheet</h1>
            <p className="text-gray-600 mt-1">
              {new Date(timesheet.work_date).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
              })}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Button 
            variant="outline"
            onClick={handleCancel}
            disabled={saving}
            className="flex items-center gap-2"
          >
            <X className="w-4 h-4" />
            Cancel
          </Button>
          <Button 
            onClick={handleSave}
            disabled={saving}
            className="flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            {saving ? 'Saving...' : 'Save Changes'}
          </Button>
        </div>
      </div>

      {/* Error Message */}
      {error && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-4">
            <div className="flex items-start gap-3 text-red-600">
              <AlertCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
              <div className="flex-1">
                <div className="font-medium mb-2">Update Error</div>
                <div className="text-sm whitespace-pre-wrap">{error}</div>
                <div className="text-xs mt-2 text-red-500">
                  Check the browser console for detailed debugging information.
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Employee Information (Read-only) */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="w-5 h-5" />
            Employee Information
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <span className="font-medium">Name:</span> {timesheet.employee?.first_name} {timesheet.employee?.last_name}
            </div>
            <div>
              <span className="font-medium">Email:</span> {timesheet.employee?.email}
            </div>
            <div>
              <span className="font-medium">Specialty:</span> {timesheet.employee?.speciality || 'N/A'}
            </div>
            <div>
              <span className="font-medium">Daily Rate:</span> {formatCurrency(timesheet.daily_rate || 0)}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Time Tracking Form */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Time Tracking
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Time In *
              </label>
              <Input
                type="datetime-local"
                value={formData.time_in}
                onChange={(e) => handleInputChange('time_in', e.target.value)}
                className={validationErrors.time_in ? 'border-red-500' : ''}
              />
              {validationErrors.time_in && (
                <p className="text-red-500 text-sm mt-1">{validationErrors.time_in}</p>
              )}
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Time Out *
              </label>
              <Input
                type="datetime-local"
                value={formData.time_out}
                onChange={(e) => handleInputChange('time_out', e.target.value)}
                className={validationErrors.time_out ? 'border-red-500' : ''}
              />
              {validationErrors.time_out && (
                <p className="text-red-500 text-sm mt-1">{validationErrors.time_out}</p>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Break Duration (minutes)
              </label>
              <Input
                type="number"
                min="0"
                max="480"
                value={formData.break_duration}
                onChange={(e) => handleInputChange('break_duration', parseInt(e.target.value) || 0)}
                className={validationErrors.break_duration ? 'border-red-500' : ''}
              />
              {validationErrors.break_duration && (
                <p className="text-red-500 text-sm mt-1">{validationErrors.break_duration}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Status
              </label>
              <select
                value={formData.status}
                onChange={(e) => handleInputChange('status', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="draft">Draft</option>
                <option value="submitted">Submitted</option>
                <option value="approved">Approved</option>
                <option value="rejected">Rejected</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Work Order IDs (comma-separated)
            </label>
            <Input
              type="text"
              value={formData.work_order_ids.join(', ')}
              onChange={(e) => handleWorkOrderIdsChange(e.target.value)}
              placeholder="e.g., 6846b63e72f41a235c21db5f, 6846b63e72f41a235c21db60"
            />
            <p className="text-gray-500 text-sm mt-1">
              Enter work order IDs separated by commas (optional)
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Notes
            </label>
            <textarea
              rows={4}
              value={formData.notes}
              onChange={(e) => handleInputChange('notes', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Add any notes about this timesheet..."
            />
          </div>
        </CardContent>
      </Card>

      {/* Hours Calculation Preview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5" />
            Hours & Pay Preview
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div>
              <div className="text-sm text-gray-500">Regular Hours</div>
              <div className="text-2xl font-bold text-blue-600">
                {hours.regular.toFixed(1)} hrs
              </div>
            </div>
            <div>
              <div className="text-sm text-gray-500">Overtime Hours</div>
              <div className="text-2xl font-bold text-orange-600">
                {hours.overtime.toFixed(1)} hrs
              </div>
            </div>
            <div>
              <div className="text-sm text-gray-500">Total Hours</div>
              <div className="text-2xl font-bold text-purple-600">
                {hours.total.toFixed(1)} hrs
              </div>
            </div>
            <div>
              <div className="text-sm text-gray-500">Estimated Pay</div>
              <div className="text-2xl font-bold text-green-600">
                {formatCurrency(estimatedPay)}
              </div>
            </div>
          </div>
          
          {hours.overtime > 0 && (
            <div className="mt-4 p-4 bg-orange-50 rounded-lg">
              <div className="text-sm text-orange-700 font-medium">Overtime Detected</div>
              <div className="text-sm text-orange-600 mt-1">
                {hours.overtime.toFixed(1)} hours at 1.5x rate = {formatCurrency(hours.overtime * (timesheet.daily_rate || 0) / 8 * 1.5)}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}