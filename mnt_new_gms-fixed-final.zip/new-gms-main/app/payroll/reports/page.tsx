"use client";

import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import Link from "next/link";
import { FileText, Download, Calendar, Users, DollarSign, TrendingUp, BarChart3, PieChart } from "lucide-react";
import { useAuth } from "../../context/AuthContext";
import { useRouteProtection } from "../../../services/route-protection";

export default function ReportsPage() {
  const { user, isAuthenticated } = useAuth();
  
  // Admin and accountant only - prevent supervisor access
  const hasAccess = useRouteProtection(isAuthenticated, user, { adminAndAccountantOnly: true });
  
  const canGenerateReports = user?.permissions?.some(p => 
    p.permission_id === 'payroll_generate_reports' && p.granted
  ) || user?.role_name?.toLowerCase() === 'admin';

  const reportTypes = [
    {
      id: 'payroll_summary',
      name: 'Payroll Summary',
      description: 'Overview of payroll costs by period',
      icon: DollarSign,
      color: 'text-green-600',
      bgColor: 'bg-green-100'
    },
    {
      id: 'employee_earnings',
      name: 'Employee Earnings',
      description: 'Detailed earnings breakdown by employee',
      icon: Users,
      color: 'text-blue-600',
      bgColor: 'bg-blue-100'
    },
    {
      id: 'deductions_summary',
      name: 'Deductions Summary',
      description: 'Analysis of all employee deductions',
      icon: BarChart3,
      color: 'text-orange-600',
      bgColor: 'bg-orange-100'
    },
    {
      id: 'attendance_report',
      name: 'Attendance Report',
      description: 'Employee attendance patterns and statistics',
      icon: Calendar,
      color: 'text-purple-600',
      bgColor: 'bg-purple-100'
    },
    {
      id: 'tax_report',
      name: 'Tax Report',
      description: 'Tax calculations and compliance reporting',
      icon: FileText,
      color: 'text-red-600',
      bgColor: 'bg-red-100'
    },
    {
      id: 'cost_analysis',
      name: 'Cost Analysis',
      description: 'Labor cost trends and budget analysis',
      icon: TrendingUp,
      color: 'text-indigo-600',
      bgColor: 'bg-indigo-100'
    }
  ];

  const quickReports = [
    {
      name: 'Current Month Payroll',
      description: 'Payroll summary for the current month',
      type: 'payroll_summary',
      period: 'current_month'
    },
    {
      name: 'Last Pay Period',
      description: 'Detailed report for the last completed pay period',
      type: 'employee_earnings',
      period: 'last_period'
    },
    {
      name: 'YTD Employee Earnings',
      description: 'Year-to-date earnings for all employees',
      type: 'employee_earnings',
      period: 'year_to_date'
    },
    {
      name: 'Monthly Attendance',
      description: 'Attendance summary for the current month',
      type: 'attendance_report',
      period: 'current_month'
    }
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Payroll Reports</h1>
          <p className="text-gray-600 mt-2">
            Generate comprehensive payroll and attendance reports
          </p>
        </div>
        {canGenerateReports && (
          <Button asChild className="flex items-center gap-2">
            <Link href="/payroll/reports/new">
              <FileText className="w-4 h-4" />
              Create Custom Report
            </Link>
          </Button>
        )}
      </div>

      {/* Quick Reports */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Download className="w-5 h-5" />
            Quick Reports
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {quickReports.map((report, index) => (
              <div key={index} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="font-medium text-gray-900 mb-1">{report.name}</h3>
                    <p className="text-sm text-gray-600 mb-3">{report.description}</p>
                  </div>
                  <Button size="sm" variant="outline">
                    Generate
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Report Types */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5" />
            Report Types
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {reportTypes.map((reportType) => (
              <div key={reportType.id} className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                <div className="flex items-center gap-3 mb-4">
                  <div className={`p-3 rounded-lg ${reportType.bgColor}`}>
                    <reportType.icon className={`w-6 h-6 ${reportType.color}`} />
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-900">{reportType.name}</h3>
                  </div>
                </div>
                <p className="text-sm text-gray-600 mb-4">{reportType.description}</p>
                {canGenerateReports && (
                  <Button 
                    size="sm" 
                    variant="outline" 
                    className="w-full"
                    asChild
                  >
                    <Link href={`/payroll/reports/new?type=${reportType.id}`}>
                      Create Report
                    </Link>
                  </Button>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recent Reports */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Recent Reports
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 mb-4">No reports generated yet.</p>
            <p className="text-sm text-gray-500">
              Create your first report to see it listed here.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Analytics Preview */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <PieChart className="w-5 h-5" />
              Payroll Distribution
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center py-8">
              <PieChart className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 text-sm">
                Chart will appear when payroll data is available
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5" />
              Cost Trends
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center py-8">
              <TrendingUp className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 text-sm">
                Trend analysis will appear with historical data
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}