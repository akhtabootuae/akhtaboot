"use client";

import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { FileText, Search, Filter, ChevronLeft, ChevronRight, AlertCircle, Calendar, User, ArrowLeft } from "lucide-react";
import { payrollApi } from "../../../services/api";
import { PayrollAuditLog } from "../../types/payroll";
import { useAuth } from "../../context/AuthContext";
import { useRouteProtection } from "../../../services/route-protection";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function PayrollAuditPage() {
  const { user, isAuthenticated } = useAuth();
  const router = useRouter();
  
  // Admin and accountant only - prevent supervisor access
  const hasAccess = useRouteProtection(isAuthenticated, user, { adminAndAccountantOnly: true });
  
  const [auditLogs, setAuditLogs] = useState<PayrollAuditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalCount, setTotalCount] = useState(0);
  const [filters, setFilters] = useState({
    entity_type: '',
    action: '',
    user_id: '',
    start_date: '',
    end_date: ''
  });

  const isAdmin = user?.role_name?.toLowerCase() === 'admin';

  // Redirect if not admin
  useEffect(() => {
    if (!loading && !isAdmin) {
      router.push('/payroll');
    }
  }, [isAdmin, loading, router]);

  const fetchAuditLogs = async (page = 1) => {
    try {
      setLoading(true);
      setError(null);
      
      const params = {
        page,
        limit: 20,
        ...Object.fromEntries(
          Object.entries(filters).filter(([_, value]) => value !== '')
        )
      };
      
      const response = await payrollApi.getAuditLog(params);
      setAuditLogs(response.audit_entries || []);
      
      if (response.pagination) {
        setCurrentPage(response.pagination.current_page);
        setTotalPages(response.pagination.total_pages);
        setTotalCount(response.pagination.total_entries);
      }
    } catch (err: any) {
      console.error('Error fetching audit logs:', err);
      setError(err.response?.data?.message || 'Failed to fetch audit logs');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isAdmin) {
      fetchAuditLogs(currentPage);
    }
  }, [currentPage, isAdmin]);

  const handleFilterChange = (key: string, value: string) => {
    setFilters(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const applyFilters = () => {
    setCurrentPage(1);
    fetchAuditLogs(1);
  };

  const clearFilters = () => {
    setFilters({
      entity_type: '',
      action: '',
      user_id: '',
      start_date: '',
      end_date: ''
    });
    setCurrentPage(1);
    setTimeout(() => fetchAuditLogs(1), 0);
  };

  const formatDateTime = (dateString: string) => {
    return new Date(dateString).toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  const getActionColor = (action: string) => {
    switch (action) {
      case 'view_payroll':
        return 'bg-blue-100 text-blue-800';
      case 'update_payroll':
        return 'bg-orange-100 text-orange-800';
      case 'create_timesheet':
        return 'bg-green-100 text-green-800';
      case 'update_timesheet':
        return 'bg-yellow-100 text-yellow-800';
      case 'rate_change':
        return 'bg-purple-100 text-purple-800';
      case 'deduction_add':
        return 'bg-emerald-100 text-emerald-800';
      case 'deduction_modify':
        return 'bg-amber-100 text-amber-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatActionName = (action: string) => {
    return action.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
  };

  const formatDataChange = (oldData: any, newData: any) => {
    if (!oldData && !newData) return null;
    
    const changes = [];
    
    if (oldData?.daily_rate !== undefined && newData?.daily_rate !== undefined) {
      changes.push(`Rate: AED ${oldData.daily_rate} → AED ${newData.daily_rate}`);
    }
    
    if (newData?.daily_rate && !oldData?.daily_rate) {
      changes.push(`Set rate: AED ${newData.daily_rate}`);
    }
    
    return changes.length > 0 ? changes.join(', ') : 'Data modified';
  };

  if (!isAdmin) {
    return (
      <div className="p-6">
        <Card className="border-red-200">
          <CardContent className="p-6">
            <div className="flex items-center gap-3 text-red-600">
              <AlertCircle className="w-5 h-5" />
              <span className="font-medium">Access Denied</span>
            </div>
            <p className="text-red-600 mt-2">Only administrators can access the audit log.</p>
            <Button onClick={() => router.push('/payroll')} className="mt-4" variant="outline">
              Back to Payroll
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (loading && auditLogs.length === 0) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          <span className="ml-3 text-gray-600">Loading audit logs...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/payroll">
            <Button variant="outline" size="sm" className="flex items-center gap-2">
              <ArrowLeft className="w-4 h-4" />
              Back
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Payroll Audit Log</h1>
            <p className="text-gray-600 mt-2">
              Track all payroll-related changes and modifications
            </p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <FileText className="w-4 h-4" />
            <span>{totalCount} total records</span>
          </div>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="w-5 h-5" />
            Filters
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Entity Type
              </label>
              <select
                value={filters.entity_type}
                onChange={(e) => handleFilterChange('entity_type', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">All Types</option>
                <option value="payroll_rate">Payroll Rate</option>
                <option value="payroll_system">Payroll System</option>
                <option value="timesheet">Timesheet</option>
                <option value="attendance">Attendance</option>
                <option value="employee">Employee</option>
                <option value="deduction">Deduction</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Action
              </label>
              <select
                value={filters.action}
                onChange={(e) => handleFilterChange('action', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">All Actions</option>
                <option value="view_payroll">View Payroll</option>
                <option value="update_payroll">Update Payroll</option>
                <option value="create_timesheet">Create Timesheet</option>
                <option value="update_timesheet">Update Timesheet</option>
                <option value="rate_change">Rate Change</option>
                <option value="deduction_add">Deduction Add</option>
                <option value="deduction_modify">Deduction Modify</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                User Email
              </label>
              <Input
                type="text"
                value={filters.user_id}
                onChange={(e) => handleFilterChange('user_id', e.target.value)}
                placeholder="Filter by user email..."
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Start Date
              </label>
              <Input
                type="date"
                value={filters.start_date}
                onChange={(e) => handleFilterChange('start_date', e.target.value)}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                End Date
              </label>
              <Input
                type="date"
                value={filters.end_date}
                onChange={(e) => handleFilterChange('end_date', e.target.value)}
              />
            </div>
          </div>

          <div className="flex gap-3">
            <Button onClick={applyFilters} className="flex items-center gap-2">
              <Search className="w-4 h-4" />
              Apply Filters
            </Button>
            <Button onClick={clearFilters} variant="outline">
              Clear Filters
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Error Display */}
      {error && (
        <Card className="border-red-200">
          <CardContent className="p-6">
            <div className="flex items-center gap-3 text-red-600">
              <AlertCircle className="w-5 h-5" />
              <span className="font-medium">Error loading audit logs</span>
            </div>
            <p className="text-red-600 mt-2">{error}</p>
            <Button onClick={() => fetchAuditLogs(currentPage)} className="mt-4" variant="outline">
              Try Again
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Audit Logs */}
      <Card>
        <CardHeader>
          <CardTitle>Audit Entries</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
              <span className="ml-3 text-gray-600">Loading...</span>
            </div>
          ) : auditLogs.length === 0 ? (
            <div className="text-center py-8">
              <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">No audit logs found matching your criteria.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {auditLogs.map((log) => (
                <div key={log._id} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getActionColor(log.action)}`}>
                          {formatActionName(log.action)}
                        </span>
                        <span className="text-sm text-gray-500">
                          {log.entity_type.charAt(0).toUpperCase() + log.entity_type.slice(1)}
                        </span>
                        {log.category && (
                          <>
                            <span className="text-gray-400">•</span>
                            <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs ${
                              log.category === 'data_access' ? 'bg-gray-100 text-gray-700' :
                              log.category === 'data_modification' ? 'bg-orange-100 text-orange-700' :
                              'bg-blue-100 text-blue-700'
                            }`}>
                              {log.category.replace('_', ' ').toUpperCase()}
                            </span>
                          </>
                        )}
                      </div>

                      <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
                        <User className="w-4 h-4" />
                        <span>
                          {log.user_email}
                        </span>
                        <span className="text-gray-400">•</span>
                        <Calendar className="w-4 h-4" />
                        <span>{formatDateTime(log.timestamp)}</span>
                        {log.ip_address && (
                          <>
                            <span className="text-gray-400">•</span>
                            <span className="text-xs font-mono">{log.ip_address}</span>
                          </>
                        )}
                      </div>

                      {/* Entity ID if available */}
                      {log.entity_id && (
                        <div className="text-sm text-gray-600 mb-2">
                          <span className="font-medium">Entity ID: </span>
                          <span className="font-mono text-xs bg-gray-100 px-2 py-1 rounded">
                            {log.entity_id}
                          </span>
                        </div>
                      )}

                      {/* Request Details */}
                      {log.details && (
                        <div className="bg-gray-50 rounded p-3 mb-2">
                          <div className="grid grid-cols-1 lg:grid-cols-3 gap-2 text-sm">
                            {log.details.request_method && (
                              <div>
                                <span className="font-medium text-gray-700">Method: </span>
                                <span className={`px-2 py-1 rounded text-xs font-mono ${
                                  log.details.request_method === 'GET' ? 'bg-blue-100 text-blue-800' :
                                  log.details.request_method === 'POST' ? 'bg-green-100 text-green-800' :
                                  log.details.request_method === 'PUT' ? 'bg-yellow-100 text-yellow-800' :
                                  log.details.request_method === 'DELETE' ? 'bg-red-100 text-red-800' :
                                  'bg-gray-100 text-gray-800'
                                }`}>
                                  {log.details.request_method}
                                </span>
                              </div>
                            )}
                            {log.details.success !== undefined && (
                              <div>
                                <span className="font-medium text-gray-700">Status: </span>
                                <span className={`px-2 py-1 rounded text-xs font-medium ${
                                  log.details.success ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                                }`}>
                                  {log.details.success ? 'Success' : 'Failed'}
                                </span>
                              </div>
                            )}
                            {log.severity && (
                              <div>
                                <span className="font-medium text-gray-700">Severity: </span>
                                <span className={`px-2 py-1 rounded text-xs font-medium ${
                                  log.severity === 'high' ? 'bg-red-100 text-red-800' :
                                  log.severity === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                                  'bg-blue-100 text-blue-800'
                                }`}>
                                  {log.severity.charAt(0).toUpperCase() + log.severity.slice(1)}
                                </span>
                              </div>
                            )}
                          </div>
                          {log.details.endpoint && (
                            <div className="mt-2">
                              <span className="font-medium text-gray-700">Endpoint: </span>
                              <span className="font-mono text-xs bg-gray-100 px-2 py-1 rounded">
                                {log.details.endpoint}
                              </span>
                            </div>
                          )}
                          {log.user_agent && (
                            <div className="mt-2">
                              <span className="font-medium text-gray-700">User Agent: </span>
                              <span className="text-xs text-gray-600">
                                {log.user_agent.length > 100 ? 
                                  `${log.user_agent.substring(0, 100)}...` : 
                                  log.user_agent
                                }
                              </span>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between mt-6 pt-4 border-t">
              <div className="text-sm text-gray-600">
                Page {currentPage} of {totalPages} ({totalCount} total records)
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                  disabled={currentPage === 1 || loading}
                  className="flex items-center gap-1"
                >
                  <ChevronLeft className="w-4 h-4" />
                  Previous
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                  disabled={currentPage === totalPages || loading}
                  className="flex items-center gap-1"
                >
                  Next
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}