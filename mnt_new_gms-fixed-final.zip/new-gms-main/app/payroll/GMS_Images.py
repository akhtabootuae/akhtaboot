import hashlib

# Hash the string "GMS_Images"
text = "GMS_Images"
hash_md5 = hashlib.md5(text.encode()).hexdigest()

text2 = "GMS_DB"
hash_md5_2 = hashlib.md5(text2.encode()).hexdigest()
print(f"MD5 hash of '{text2}': {hash_md5_2}")

print(f"MD5 hash of '{text}': {hash_md5}")


# access key: AKIA46ALPOONAAWKYKEC
# secret access key: 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