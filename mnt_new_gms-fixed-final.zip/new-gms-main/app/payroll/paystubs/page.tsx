"use client";

import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import Link from "next/link";
import { FileText, Download, Send, Eye, Search, Filter, Calendar, Users } from "lucide-react";
import { useAuth } from "../../context/AuthContext";
import { useRouteProtection } from "../../../services/route-protection";

export default function PaystubsPage() {
  const { user, isAuthenticated } = useAuth();
  
  // Admin and accountant only - prevent supervisor access
  const hasAccess = useRouteProtection(isAuthenticated, user, { adminAndAccountantOnly: true });
  
  const [filters, setFilters] = useState({
    employee_search: '',
    pay_period: '',
    status: '',
    date_range: ''
  });

  const canGeneratePaystubs = user?.permissions?.some(p => 
    p.permission_id === 'payroll_generate_paystubs' && p.granted
  ) || user?.role_name?.toLowerCase() === 'admin';

  const mockPaystubs = [
    {
      id: '1',
      employee_name: 'John Doe',
      employee_email: 'john.doe@garage.com',
      pay_period: 'January 2024 - Week 1',
      pay_date: '2024-01-15',
      gross_pay: 2800,
      total_deductions: 420,
      net_pay: 2380,
      status: 'sent',
      generated_at: '2024-01-10',
      sent_at: '2024-01-10'
    },
    {
      id: '2',
      employee_name: 'Jane Smith',
      employee_email: 'jane.smith@garage.com',
      pay_period: 'January 2024 - Week 1',
      pay_date: '2024-01-15',
      gross_pay: 3200,
      total_deductions: 480,
      net_pay: 2720,
      status: 'generated',
      generated_at: '2024-01-10'
    },
    {
      id: '3',
      employee_name: 'Mike Johnson',
      employee_email: 'mike.johnson@garage.com',
      pay_period: 'December 2023 - Week 4',
      pay_date: '2024-01-05',
      gross_pay: 2600,
      total_deductions: 390,
      net_pay: 2210,
      status: 'downloaded',
      generated_at: '2023-12-28',
      sent_at: '2023-12-28',
      downloaded_at: '2023-12-29'
    }
  ];

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-AE', {
      style: 'currency',
      currency: 'AED',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      generated: { color: 'bg-blue-100 text-blue-800', label: 'Generated' },
      sent: { color: 'bg-green-100 text-green-800', label: 'Sent' },
      viewed: { color: 'bg-purple-100 text-purple-800', label: 'Viewed' },
      downloaded: { color: 'bg-gray-100 text-gray-800', label: 'Downloaded' }
    };

    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.generated;

    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${config.color}`}>
        {config.label}
      </span>
    );
  };

  const filteredPaystubs = mockPaystubs.filter(paystub => {
    if (filters.employee_search) {
      const searchLower = filters.employee_search.toLowerCase();
      return paystub.employee_name.toLowerCase().includes(searchLower) ||
             paystub.employee_email.toLowerCase().includes(searchLower);
    }
    return true;
  });

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Employee Paystubs</h1>
          <p className="text-gray-600 mt-2">
            Generate, manage, and distribute employee paystubs
          </p>
        </div>
        {canGeneratePaystubs && (
          <Button asChild className="flex items-center gap-2">
            <Link href="/payroll/paystubs/generate">
              <FileText className="w-4 h-4" />
              Generate Paystubs
            </Link>
          </Button>
        )}
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <FileText className="w-8 h-8 text-blue-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-500">Total Paystubs</p>
                <p className="text-2xl font-semibold text-gray-900">{filteredPaystubs.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Send className="w-8 h-8 text-green-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-500">Sent</p>
                <p className="text-2xl font-semibold text-gray-900">
                  {filteredPaystubs.filter(p => p.status === 'sent' || p.status === 'viewed' || p.status === 'downloaded').length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Eye className="w-8 h-8 text-purple-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-500">Viewed</p>
                <p className="text-2xl font-semibold text-gray-900">
                  {filteredPaystubs.filter(p => p.status === 'viewed' || p.status === 'downloaded').length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Download className="w-8 h-8 text-orange-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-500">Downloaded</p>
                <p className="text-2xl font-semibold text-gray-900">
                  {filteredPaystubs.filter(p => p.status === 'downloaded').length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="w-5 h-5" />
            Filters
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Search Employee
              </label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search by name or email..."
                  value={filters.employee_search}
                  onChange={(e) => setFilters(prev => ({ ...prev, employee_search: e.target.value }))}
                  className="pl-10"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Pay Period
              </label>
              <select
                value={filters.pay_period}
                onChange={(e) => setFilters(prev => ({ ...prev, pay_period: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">All Periods</option>
                <option value="january_2024_week_1">January 2024 - Week 1</option>
                <option value="december_2023_week_4">December 2023 - Week 4</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Status
              </label>
              <select
                value={filters.status}
                onChange={(e) => setFilters(prev => ({ ...prev, status: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">All Statuses</option>
                <option value="generated">Generated</option>
                <option value="sent">Sent</option>
                <option value="viewed">Viewed</option>
                <option value="downloaded">Downloaded</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Actions
              </label>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="flex-1">
                  <Download className="w-4 h-4 mr-1" />
                  Export
                </Button>
                <Button variant="outline" size="sm" className="flex-1">
                  Reset
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Paystubs Table */}
      <Card>
        <CardHeader>
          <CardTitle>Paystubs</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredPaystubs.length === 0 ? (
            <div className="text-center py-8">
              <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 mb-4">No paystubs found matching your criteria.</p>
              {canGeneratePaystubs && (
                <Button asChild>
                  <Link href="/payroll/paystubs/generate">
                    <FileText className="w-4 h-4 mr-2" />
                    Generate Paystubs
                  </Link>
                </Button>
              )}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Employee
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Pay Period
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Gross Pay
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Net Pay
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredPaystubs.map((paystub) => (
                    <tr key={paystub.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div>
                          <div className="text-sm font-medium text-gray-900">{paystub.employee_name}</div>
                          <div className="text-sm text-gray-500">{paystub.employee_email}</div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div>
                          <div className="text-sm text-gray-900">{paystub.pay_period}</div>
                          <div className="text-sm text-gray-500">Pay Date: {formatDate(paystub.pay_date)}</div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        <div>
                          <div className="font-medium">{formatCurrency(paystub.gross_pay)}</div>
                          <div className="text-red-600 text-xs">-{formatCurrency(paystub.total_deductions)} deductions</div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-green-600">
                        {formatCurrency(paystub.net_pay)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {getStatusBadge(paystub.status)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <div className="flex items-center gap-2">
                          <Button size="sm" variant="outline">
                            <Eye className="w-3 h-3 mr-1" />
                            View
                          </Button>
                          <Button size="sm" variant="outline">
                            <Download className="w-3 h-3 mr-1" />
                            Download
                          </Button>
                          {paystub.status === 'generated' && (
                            <Button size="sm" variant="outline">
                              <Send className="w-3 h-3 mr-1" />
                              Send
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}