/*
 * Pay Periods Management Page
 * 
 * Fixed Issues:
 * - Updated data structure to match backend API (period_name vs name)
 * - Fixed permission checks to use correct permission IDs from backend
 * - Added proper status handling (draft, processing, etc.)
 * - Replaced broken navigation links with placeholder alerts
 * - Added loading states for calculate/approve actions
 * - Added confirmation dialog for approve action
 * - Updated status badges and filtering logic
 * 
 * TODO:
 * - Implement create pay period modal/page
 * - Implement pay period details page
 * - Implement calculations view page
 */

"use client";

import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import Link from "next/link";
import { Calendar, Calculator, DollarSign, Plus, CheckCircle, Clock, AlertCircle, ArrowLeft } from "lucide-react";
import { payrollApi } from "../../../services/api";
import { PayrollPayPeriod } from "../../types/payroll";
import { useAuth } from "../../context/AuthContext";
import { useRouteProtection } from "../../../services/route-protection";

export default function PayPeriodsPage() {
  const { user, isAuthenticated } = useAuth();
  
  // Admin and accountant only - prevent supervisor access
  const hasAccess = useRouteProtection(isAuthenticated, user, { adminAndAccountantOnly: true });
  
  const [payPeriods, setPayPeriods] = useState<PayrollPayPeriod[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [processingPayPeriod, setProcessingPayPeriod] = useState<string | null>(null);

  const canCreatePayPeriods = user?.permissions?.some(p => 
    p.permission_id === 'payroll_manage_pay_periods' && p.granted
  ) || user?.role_name?.toLowerCase() === 'admin';

  const canProcessPayroll = user?.permissions?.some(p => 
    p.permission_id === 'payroll_process' && p.granted
  ) || user?.role_name?.toLowerCase() === 'admin';

  useEffect(() => {
    fetchPayPeriods();
  }, []);

  const fetchPayPeriods = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await payrollApi.getPayPeriods();
      setPayPeriods(response.pay_periods || []);
    } catch (err: any) {
      console.error('Error fetching pay periods:', err);
      setError(err.response?.data?.message || 'Failed to fetch pay periods');
    } finally {
      setLoading(false);
    }
  };

  const handleCalculatePayroll = async (payPeriodId: string) => {
    try {
      setProcessingPayPeriod(payPeriodId);
      const response = await payrollApi.calculatePayPeriod(payPeriodId);
      console.log('Calculate payroll response:', response.data);
      await fetchPayPeriods(); // Refresh data
      
      // Show success message with calculation summary if available
      const summary = response.data?.calculation_summary;
      if (summary) {
        console.error(`Payroll calculation completed successfully! Employees processed: ${summary.employees_processed} Errors: ${summary.calculation_errors?.length || 0}`);
      } else {
        console.error('Payroll calculation completed successfully!');
      }
    } catch (error: any) {
      console.error('Error calculating payroll:', error);
      console.error(error.response?.data?.message || 'Failed to calculate payroll');
    } finally {
      setProcessingPayPeriod(null);
    }
  };

  const handleApprovePayPeriod = async (payPeriodId: string) => {
    if (!confirm('Are you sure you want to approve this pay period? This action cannot be undone.')) {
      return;
    }
    
    try {
      setProcessingPayPeriod(payPeriodId);
      const response = await payrollApi.approvePayPeriod(payPeriodId);
      console.log('Approve payroll response:', response.data);
      await fetchPayPeriods(); // Refresh data
      console.error('Pay period approved successfully!');
    } catch (error: any) {
      console.error('Error approving pay period:', error);
      console.error(error.response?.data?.message || 'Failed to approve pay period');
    } finally {
      setProcessingPayPeriod(null);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const formatCurrency = (amount: number | undefined) => {
    if (amount === undefined) return 'N/A';
    return new Intl.NumberFormat('en-AE', {
      style: 'currency',
      currency: 'AED',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      draft: { color: 'bg-gray-100 text-gray-800', icon: Clock, label: 'Draft' },
      open: { color: 'bg-blue-100 text-blue-800', icon: Clock, label: 'Open' },
      processing: { color: 'bg-yellow-100 text-yellow-800', icon: Calculator, label: 'Processing' },
      calculating: { color: 'bg-yellow-100 text-yellow-800', icon: Calculator, label: 'Calculating' },
      calculated: { color: 'bg-green-100 text-green-800', icon: CheckCircle, label: 'Calculated' },
      approved: { color: 'bg-purple-100 text-purple-800', icon: CheckCircle, label: 'Approved' },
      paid: { color: 'bg-gray-100 text-gray-800', icon: DollarSign, label: 'Paid' },
      closed: { color: 'bg-gray-100 text-gray-800', icon: CheckCircle, label: 'Closed' }
    };

    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.open;
    const IconComponent = config.icon;

    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${config.color}`}>
        <IconComponent className="w-3 h-3 mr-1" />
        {config.label}
      </span>
    );
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          <span className="ml-3 text-gray-600">Loading pay periods...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <Card className="border-red-200">
          <CardContent className="p-6">
            <div className="flex items-center gap-3 text-red-600">
              <AlertCircle className="w-5 h-5" />
              <span className="font-medium">Error loading pay periods</span>
            </div>
            <p className="text-red-600 mt-2">{error}</p>
            <Button onClick={fetchPayPeriods} variant="outline" className="mt-4">
              Try Again
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/payroll">
            <Button variant="outline" size="sm" className="flex items-center gap-2">
              <ArrowLeft className="w-4 h-4" />
              Back
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Pay Periods</h1>
            <p className="text-gray-600 mt-2">
              Manage payroll periods and calculate employee pay
            </p>
          </div>
        </div>
        {canCreatePayPeriods && (
          <Button
            onClick={() => {
              // TODO: Implement create pay period modal or navigate to create page
              console.error('Create Pay Period functionality will be implemented in a future update');
            }}
            className="flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Create Pay Period
          </Button>
        )}
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Calendar className="w-8 h-8 text-blue-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-500">Total Periods</p>
                <p className="text-2xl font-semibold text-gray-900">{payPeriods.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Clock className="w-8 h-8 text-yellow-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-500">Open Periods</p>
                <p className="text-2xl font-semibold text-gray-900">
                  {payPeriods.filter(p => ['open', 'draft'].includes(p.status)).length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Calculator className="w-8 h-8 text-green-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-500">Calculated</p>
                <p className="text-2xl font-semibold text-gray-900">
                  {payPeriods.filter(p => ['calculated', 'approved', 'processing'].includes(p.status)).length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <DollarSign className="w-8 h-8 text-purple-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-500">Total Payroll</p>
                <p className="text-2xl font-semibold text-gray-900">
                  {formatCurrency(payPeriods.reduce((sum, p) => sum + (p.total_net_pay || 0), 0))}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Pay Periods List */}
      <Card>
        <CardHeader>
          <CardTitle>Pay Periods</CardTitle>
        </CardHeader>
        <CardContent>
          {payPeriods.length === 0 ? (
            <div className="text-center py-8">
              <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 mb-4">No pay periods created yet.</p>
              {canCreatePayPeriods && (
                <Button
                  onClick={() => {
                    // TODO: Implement create pay period modal or navigate to create page
                    console.error('Create Pay Period functionality will be implemented in a future update');
                  }}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Create First Pay Period
                </Button>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              {payPeriods.map((payPeriod) => (
                <div key={payPeriod._id} className="border border-gray-200 rounded-lg p-6 hover:bg-gray-50">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-lg font-medium text-gray-900">
                          {payPeriod.period_name || payPeriod.name}
                        </h3>
                        {getStatusBadge(payPeriod.status)}
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-600 mb-4">
                        <div>
                          <span className="font-medium">Period:</span> {formatDate(payPeriod.start_date)} - {formatDate(payPeriod.end_date)}
                        </div>
                        {payPeriod.pay_date && (
                          <div>
                            <span className="font-medium">Pay Date:</span> {formatDate(payPeriod.pay_date)}
                          </div>
                        )}
                        {payPeriod.total_employees && (
                          <div>
                            <span className="font-medium">Employees:</span> {payPeriod.total_employees}
                          </div>
                        )}
                      </div>

                      {!['open', 'draft'].includes(payPeriod.status) && (
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                          <div>
                            <span className="font-medium text-gray-700">Gross Pay:</span>
                            <div className="text-lg font-semibold text-green-600">
                              {formatCurrency(payPeriod.total_gross_pay)}
                            </div>
                          </div>
                          <div>
                            <span className="font-medium text-gray-700">Deductions:</span>
                            <div className="text-lg font-semibold text-red-600">
                              {formatCurrency(payPeriod.total_deductions)}
                            </div>
                          </div>
                          <div>
                            <span className="font-medium text-gray-700">Net Pay:</span>
                            <div className="text-lg font-semibold text-blue-600">
                              {formatCurrency(payPeriod.total_net_pay)}
                            </div>
                          </div>
                        </div>
                      )}

                      {payPeriod.description && (
                        <div className="mt-2 text-sm text-gray-600">
                          <span className="font-medium">Description:</span> {payPeriod.description}
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-2 ml-4">
                      <Link href={`/payroll/pay-periods/${payPeriod._id}`}>
                        <Button
                          size="sm"
                          variant="outline"
                        >
                          View Details
                        </Button>
                      </Link>

                      {canProcessPayroll && ['open', 'draft'].includes(payPeriod.status) && (
                        <Button
                          size="sm"
                          onClick={() => handleCalculatePayroll(payPeriod._id)}
                          disabled={processingPayPeriod === payPeriod._id}
                          className="flex items-center gap-1"
                        >
                          {processingPayPeriod === payPeriod._id ? (
                            <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
                          ) : (
                            <Calculator className="w-3 h-3" />
                          )}
                          {processingPayPeriod === payPeriod._id ? 'Calculating...' : 'Calculate'}
                        </Button>
                      )}

                      {canProcessPayroll && payPeriod.status === 'calculated' && (
                        <Button
                          size="sm"
                          onClick={() => handleApprovePayPeriod(payPeriod._id)}
                          disabled={processingPayPeriod === payPeriod._id}
                          className="flex items-center gap-1"
                        >
                          {processingPayPeriod === payPeriod._id ? (
                            <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
                          ) : (
                            <CheckCircle className="w-3 h-3" />
                          )}
                          {processingPayPeriod === payPeriod._id ? 'Approving...' : 'Approve'}
                        </Button>
                      )}

                      {['calculated', 'approved', 'paid', 'closed'].includes(payPeriod.status) ? (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            // TODO: Navigate to calculations page
                            console.error('Calculations view will be implemented in a future update');
                          }}
                        >
                          View Calculations
                        </Button>
                      ) : null}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}