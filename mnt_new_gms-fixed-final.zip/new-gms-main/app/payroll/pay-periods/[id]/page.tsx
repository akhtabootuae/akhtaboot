/*
 * Pay Period Details Page
 * 
 * Comprehensive view for managing individual pay periods with:
 * - Period overview and status
 * - Employee calculations management
 * - Analytics and insights
 * - Bulk operations
 * - Missing timesheet alerts
 * 
 * Updated: Backend fix applied for proper total calculations
 */

"use client";

import React, { useState, useEffect } from "react";
import { useParams, useRouter } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "../../../components/ui/card";
import { Button } from "../../../components/ui/button";
import { ArrowLeft, Calculator, CheckCircle, AlertCircle, DollarSign, Users, Clock, TrendingUp } from "lucide-react";
import { payrollApi } from "../../../../services/api";
import { PayrollPayPeriod, PayrollCalculation } from "../../../types/payroll";
import { useAuth } from "../../../context/AuthContext";
import { useRouteProtection } from "../../../../services/route-protection";

interface PayPeriodAnalytics {
  pay_period: {
    _id: string;
    period_name: string;
    status: string;
    start_date: string;
    end_date: string;
  };
  department_breakdown: Record<string, {
    employees: number;
    total_gross: number;
    total_net: number;
  }>;
  branch_breakdown: Record<string, {
    employees: number;
    total_gross: number;
    total_net: number;
  }>;
  overtime_statistics: {
    total_overtime_hours: number;
    employees_with_overtime: number;
    average_overtime_per_employee: number;
    total_overtime_pay: number;
  };
  deduction_analysis: Record<string, {
    total_amount: number;
    employee_count: number;
  }>;
  comparison_with_previous: {
    previous_period_id: string;
    previous_period_name: string;
    gross_pay_change: number;
    employee_count_change: number;
    net_pay_change: number;
  } | null;
  summary: {
    total_employees: number;
    total_timesheets: number;
    average_gross_pay: number;
    average_net_pay: number;
  };
}

interface MissingTimesheetData {
  pay_period: {
    _id: string;
    period_name: string;
    start_date: string;
    end_date: string;
    status: string;
  };
  statistics: {
    total_eligible_employees: number;
    employees_with_timesheets: number;
    employees_missing_timesheets: number;
    completion_percentage: number;
  };
  missing_employees: Array<{
    employee_id: string;
    name: string;
    email: string;
    department: string;
    branch: string;
    phone: string | null;
    last_timesheet_date: string | null;
  }>;
}

export default function PayPeriodDetailsPage() {
  const params = useParams();
  const router = useRouter();
  const { user } = useAuth();
  const payPeriodId = params.id as string;

  // State management
  const [payPeriod, setPayPeriod] = useState<PayrollPayPeriod | null>(null);
  const [analytics, setAnalytics] = useState<PayPeriodAnalytics | null>(null);
  const [calculations, setCalculations] = useState<PayrollCalculation[]>([]);
  const [missingTimesheets, setMissingTimesheets] = useState<MissingTimesheetData | null>(null);
  const [loading, setLoading] = useState(true);
  const [analyticsLoading, setAnalyticsLoading] = useState(false);
  const [calculationsLoading, setCalculationsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [processingAction, setProcessingAction] = useState<string | null>(null);

  // Permissions
  const canViewPayPeriods = user?.permissions?.some(p => 
    ['payroll_view_pay_periods', 'payroll_manage_pay_periods'].includes(p.permission_id) && p.granted
  ) || user?.role_name?.toLowerCase() === 'admin';

  const canProcessPayroll = user?.permissions?.some(p => 
    p.permission_id === 'payroll_process' && p.granted
  ) || user?.role_name?.toLowerCase() === 'admin';

  // Check permissions
  useEffect(() => {
    if (!canViewPayPeriods) {
      router.push('/unauthorized');
      return;
    }
  }, [canViewPayPeriods, router]);

  // Initial data fetch
  useEffect(() => {
    if (payPeriodId && canViewPayPeriods) {
      fetchPayPeriodData();
    }
  }, [payPeriodId, canViewPayPeriods]);

  const fetchPayPeriodData = async () => {
    try {
      setLoading(true);
      setError(null);

      // Fetch basic pay period info
      const payPeriodResponse = await payrollApi.getPayPeriod(payPeriodId);
      console.log('=== PAY PERIOD RESPONSE ===', payPeriodResponse);
      console.log('Pay Period Data:', payPeriodResponse.pay_period);
      console.log('Total Employees:', payPeriodResponse.pay_period?.total_employees);
      console.log('Total Gross Pay:', payPeriodResponse.pay_period?.total_gross_pay);
      console.log('Total Net Pay:', payPeriodResponse.pay_period?.total_net_pay);
      setPayPeriod(payPeriodResponse.pay_period);

      // Only fetch analytics and missing timesheets if the pay period has been calculated
      if (['calculated', 'approved', 'paid', 'closed'].includes(payPeriodResponse.pay_period.status)) {
        // Fetch analytics in parallel
        setAnalyticsLoading(true);
        try {
          const analyticsResponse = await payrollApi.getPayPeriodAnalytics(payPeriodId);
          setAnalytics(analyticsResponse.analytics);
        } catch (analyticsError) {
          console.warn('Analytics data not available:', analyticsError);
        } finally {
          setAnalyticsLoading(false);
        }

        // Fetch missing timesheets
        try {
          const missingResponse = await payrollApi.getMissingTimesheets(payPeriodId);
          setMissingTimesheets(missingResponse);
        } catch (missingError) {
          console.warn('Missing timesheets data not available:', missingError);
        }
      } else {
        // For non-calculated periods, try to get missing timesheets only
        try {
          const missingResponse = await payrollApi.getMissingTimesheets(payPeriodId);
          setMissingTimesheets(missingResponse);
        } catch (missingError) {
          console.warn('Missing timesheets data not available:', missingError);
        }
      }

    } catch (err: any) {
      console.error('Error fetching pay period data:', err);
      setError(err.response?.data?.message || 'Failed to fetch pay period data');
    } finally {
      setLoading(false);
    }
  };

  const fetchCalculations = async () => {
    try {
      setCalculationsLoading(true);
      const calculationsResponse = await payrollApi.getPayrollCalculations({
        pay_period_id: payPeriodId
      });
      setCalculations(calculationsResponse.calculations || []);
    } catch (err: any) {
      console.error('Error fetching calculations:', err);
    } finally {
      setCalculationsLoading(false);
    }
  };

  // Fetch calculations after initial load
  useEffect(() => {
    if (payPeriod) {
      fetchCalculations();
    }
  }, [payPeriod]);

  const handleCalculatePayroll = async () => {
    if (!payPeriod) return;
    
    try {
      setProcessingAction('calculating');
      await payrollApi.calculatePayPeriod(payPeriodId);
      await fetchPayPeriodData(); // Refresh all data
      await fetchCalculations();
    } catch (error: any) {
      console.error('Error calculating payroll:', error);
      console.error(error.response?.data?.message || 'Failed to calculate payroll');
    } finally {
      setProcessingAction(null);
    }
  };

  const handleApprovePayPeriod = async () => {
    if (!payPeriod) return;
    
    if (!confirm('Are you sure you want to approve this pay period? This action cannot be undone.')) {
      return;
    }

    try {
      setProcessingAction('approving');
      await payrollApi.approvePayPeriod(payPeriodId);
      await fetchPayPeriodData(); // Refresh data
    } catch (error: any) {
      console.error('Error approving pay period:', error);
      console.error(error.response?.data?.message || 'Failed to approve pay period');
    } finally {
      setProcessingAction(null);
    }
  };

  const handleBulkApprove = async () => {
    if (!confirm('Are you sure you want to approve all calculated employee payroll? This action cannot be undone.')) {
      return;
    }

    try {
      setProcessingAction('bulk-approving');
      const response = await payrollApi.bulkApproveCalculations(payPeriodId);
      console.error(response.message || 'Bulk approval completed successfully');
      await fetchCalculations(); // Refresh calculations
      await fetchPayPeriodData(); // Refresh period data
    } catch (error: any) {
      console.error('Error bulk approving calculations:', error);
      console.error(error.response?.data?.message || 'Failed to bulk approve calculations');
    } finally {
      setProcessingAction(null);
    }
  };

  const handleBulkRecalculate = async () => {
    const reason = prompt('Please provide a reason for recalculation (optional):');
    if (reason === null) return; // User cancelled

    try {
      setProcessingAction('bulk-recalculating');
      const response = await payrollApi.bulkRecalculatePayPeriod(payPeriodId, { reason });
      console.error(response.message || 'Bulk recalculation completed successfully');
      await fetchCalculations(); // Refresh calculations
      await fetchPayPeriodData(); // Refresh period data
    } catch (error: any) {
      console.error('Error bulk recalculating:', error);
      console.error(error.response?.data?.message || 'Failed to bulk recalculate');
    } finally {
      setProcessingAction(null);
    }
  };

  const formatCurrency = (amount: number | undefined) => {
    if (amount === undefined) return 'N/A';
    return new Intl.NumberFormat('en-AE', {
      style: 'currency',
      currency: 'AED',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      draft: { color: 'bg-gray-100 text-gray-800', icon: Clock, label: 'Draft' },
      open: { color: 'bg-blue-100 text-blue-800', icon: Clock, label: 'Open' },
      processing: { color: 'bg-yellow-100 text-yellow-800', icon: Calculator, label: 'Processing' },
      calculated: { color: 'bg-green-100 text-green-800', icon: CheckCircle, label: 'Calculated' },
      approved: { color: 'bg-purple-100 text-purple-800', icon: CheckCircle, label: 'Approved' },
      paid: { color: 'bg-gray-100 text-gray-800', icon: DollarSign, label: 'Paid' },
      closed: { color: 'bg-gray-100 text-gray-800', icon: CheckCircle, label: 'Closed' }
    };

    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.open;
    const IconComponent = config.icon;

    return (
      <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${config.color}`}>
        <IconComponent className="w-4 h-4 mr-2" />
        {config.label}
      </span>
    );
  };

  if (!canViewPayPeriods) {
    return null; // Will redirect in useEffect
  }

  if (loading) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          <span className="ml-3 text-gray-600">Loading pay period details...</span>
        </div>
      </div>
    );
  }

  if (error || !payPeriod) {
    return (
      <div className="p-6">
        <Card className="border-red-200">
          <CardContent className="p-6">
            <div className="flex items-center gap-3 text-red-600">
              <AlertCircle className="w-5 h-5" />
              <span className="font-medium">Error loading pay period</span>
            </div>
            <p className="text-red-600 mt-2">{error || 'Pay period not found'}</p>
            <div className="flex gap-3 mt-4">
              <Button onClick={() => router.back()} variant="outline">
                Go Back
              </Button>
              <Button onClick={fetchPayPeriodData} variant="outline">
                Try Again
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => router.back()}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              {payPeriod.period_name || payPeriod.name}
            </h1>
            <p className="text-gray-600 mt-1">
              {formatDate(payPeriod.start_date)} - {formatDate(payPeriod.end_date)}
            </p>
          </div>
          {getStatusBadge(payPeriod.status)}
        </div>

        <div className="flex items-center gap-3">
          {canProcessPayroll && ['open', 'draft'].includes(payPeriod.status) && (
            <Button
              onClick={handleCalculatePayroll}
              disabled={processingAction === 'calculating'}
              className="flex items-center gap-2"
            >
              {processingAction === 'calculating' ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
              ) : (
                <Calculator className="w-4 h-4" />
              )}
              {processingAction === 'calculating' ? 'Calculating...' : 'Calculate Payroll'}
            </Button>
          )}

          {canProcessPayroll && payPeriod.status === 'calculated' && (
            <Button
              onClick={handleApprovePayPeriod}
              disabled={processingAction === 'approving'}
              className="flex items-center gap-2"
            >
              {processingAction === 'approving' ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
              ) : (
                <CheckCircle className="w-4 h-4" />
              )}
              {processingAction === 'approving' ? 'Approving...' : 'Approve Pay Period'}
            </Button>
          )}
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Users className="w-8 h-8 text-blue-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-500">Total Employees</p>
                <p className="text-2xl font-semibold text-gray-900">
                  {payPeriod.total_employees || analytics?.summary?.total_employees || missingTimesheets?.statistics?.total_eligible_employees || '-'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <DollarSign className="w-8 h-8 text-green-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-500">Gross Pay</p>
                <p className="text-2xl font-semibold text-gray-900">
                  {payPeriod.total_gross_pay ? formatCurrency(payPeriod.total_gross_pay) : 
                   ['draft', 'open'].includes(payPeriod.status) ? 'Pending' : 'AED 0'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <TrendingUp className="w-8 h-8 text-purple-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-500">Net Pay</p>
                <p className="text-2xl font-semibold text-gray-900">
                  {payPeriod.total_net_pay ? formatCurrency(payPeriod.total_net_pay) : 
                   ['draft', 'open'].includes(payPeriod.status) ? 'Pending' : 'AED 0'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Clock className="w-8 h-8 text-orange-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-500">
                  {['draft', 'open'].includes(payPeriod.status) ? 'Timesheet Status' : 'Completion'}
                </p>
                <p className="text-2xl font-semibold text-gray-900">
                  {missingTimesheets ? 
                    `${missingTimesheets.statistics.completion_percentage.toFixed(0)}%` : 
                    ['draft', 'open'].includes(payPeriod.status) ? 'Pending' : 'N/A'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Missing Timesheets Alert */}
      {missingTimesheets && missingTimesheets.missing_employees.length > 0 && (
        <Card className="border-orange-200 bg-orange-50">
          <CardHeader>
            <CardTitle className="text-orange-800 flex items-center gap-2">
              <AlertCircle className="w-5 h-5" />
              Missing Timesheets Alert
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-orange-700 mb-3">
              {missingTimesheets.missing_employees.length} employees have not submitted timesheets for this period.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {missingTimesheets.missing_employees.slice(0, 6).map((employee) => (
                <div key={employee.employee_id} className="bg-white p-3 rounded border">
                  <p className="font-medium text-gray-900">{employee.name}</p>
                  <p className="text-sm text-gray-600">{employee.department}</p>
                  <p className="text-sm text-gray-500">{employee.email}</p>
                </div>
              ))}
            </div>
            {missingTimesheets.missing_employees.length > 6 && (
              <p className="text-sm text-orange-600 mt-3">
                +{missingTimesheets.missing_employees.length - 6} more employees missing timesheets
              </p>
            )}
          </CardContent>
        </Card>
      )}

      {/* Quick Analytics Overview */}
      {analytics ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Department Breakdown</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {Object.entries(analytics.department_breakdown).map(([department, data]) => (
                  <div key={department} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                    <div>
                      <p className="font-medium text-gray-900">{department}</p>
                      <p className="text-sm text-gray-600">{data.employees} employees</p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-gray-900">{formatCurrency(data.total_net)}</p>
                      <p className="text-sm text-gray-600">Net Pay</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Overtime Statistics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-gray-600">Total Overtime Hours:</span>
                  <span className="font-semibold">{analytics.overtime_statistics.total_overtime_hours.toFixed(1)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Employees with Overtime:</span>
                  <span className="font-semibold">{analytics.overtime_statistics.employees_with_overtime}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Average per Employee:</span>
                  <span className="font-semibold">{analytics.overtime_statistics.average_overtime_per_employee.toFixed(1)} hrs</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Total Overtime Pay:</span>
                  <span className="font-semibold">{formatCurrency(analytics.overtime_statistics.total_overtime_pay)}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      ) : ['draft', 'open'].includes(payPeriod.status) ? (
        <Card className="border-blue-200 bg-blue-50">
          <CardHeader>
            <CardTitle className="text-blue-800 flex items-center gap-2">
              <Calculator className="w-5 h-5" />
              Analytics Pending
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-blue-700">
              Analytics and detailed breakdowns will be available after calculating payroll for this period.
            </p>
          </CardContent>
        </Card>
      ) : null}

      {/* Bulk Operations */}
      {canProcessPayroll && payPeriod.status === 'calculated' && (
        <Card>
          <CardHeader>
            <CardTitle>Bulk Operations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4">
              <Button
                onClick={handleBulkApprove}
                disabled={processingAction === 'bulk-approving'}
                className="flex items-center gap-2"
              >
                {processingAction === 'bulk-approving' ? (
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                ) : (
                  <CheckCircle className="w-4 h-4" />
                )}
                {processingAction === 'bulk-approving' ? 'Approving...' : 'Approve All Calculations'}
              </Button>

              <Button
                onClick={handleBulkRecalculate}
                disabled={processingAction === 'bulk-recalculating'}
                variant="outline"
                className="flex items-center gap-2"
              >
                {processingAction === 'bulk-recalculating' ? (
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-600"></div>
                ) : (
                  <Calculator className="w-4 h-4" />
                )}
                {processingAction === 'bulk-recalculating' ? 'Recalculating...' : 'Recalculate All'}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Employee Calculations Table */}
      <Card>
        <CardHeader>
          <CardTitle>Employee Calculations</CardTitle>
        </CardHeader>
        <CardContent>
          {calculationsLoading ? (
            <div className="flex items-center justify-center h-32">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
              <span className="ml-3 text-gray-600">Loading calculations...</span>
            </div>
          ) : calculations.length === 0 ? (
            <div className="text-center py-8">
              <Calculator className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">No calculations available yet.</p>
              {canProcessPayroll && ['open', 'draft'].includes(payPeriod.status) && (
                <p className="text-sm text-gray-500 mt-2">
                  Click "Calculate Payroll" to generate employee calculations.
                </p>
              )}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Employee
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Hours
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Gross Pay
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Deductions
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Net Pay
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {calculations.map((calculation) => (
                    <tr key={calculation._id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div>
                          <p className="text-sm font-medium text-gray-900">
                            {calculation.employee?.first_name} {calculation.employee?.last_name}
                          </p>
                          <p className="text-sm text-gray-500">{calculation.employee?.email}</p>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {calculation.total_hours?.toFixed(1) || 0} hrs
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {formatCurrency(calculation.gross_pay)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {formatCurrency(calculation.total_deductions)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {formatCurrency(calculation.net_pay)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {getStatusBadge(calculation.status)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}