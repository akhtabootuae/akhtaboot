"use client";

import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../../../../components/ui/card";
import { Button } from "../../../../components/ui/button";
import { useParams, useRouter } from "next/navigation";
import { ArrowLeft, Plus, DollarSign, Calendar, AlertCircle, CheckCircle, Pause, X, Edit, History } from "lucide-react";
import { payrollApi } from "../../../../../services/api";
import { PayrollEmployee, PayrollEmployeeDeduction } from "../../../../types/payroll";
import { useAuth } from "../../../../context/AuthContext";
import { useRouteProtection } from "../../../../../services/route-protection";
import AddDeductionModal from "../../../../components/Payroll/Modals/AddDeductionModal";
import EditDeductionModal from "../../../../components/Payroll/Modals/EditDeductionModal";
import DeductionHistoryModal from "../../../../components/Payroll/Modals/DeductionHistoryModal";

export default function EmployeeDeductionsPage() {
  const params = useParams();
  const router = useRouter();
  const { user, isAuthenticated } = useAuth();
  
  // Admin and accountant only - prevent supervisor access
  const hasAccess = useRouteProtection(isAuthenticated, user, { adminAndAccountantOnly: true });
  
  const employeeId = params.id as string;

  const [employee, setEmployee] = useState<PayrollEmployee | null>(null);
  const [deductions, setDeductions] = useState<PayrollEmployeeDeduction[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showHistoryModal, setShowHistoryModal] = useState(false);
  const [selectedDeduction, setSelectedDeduction] = useState<PayrollEmployeeDeduction | null>(null);

  const canManageDeductions = user?.permissions?.some(p => 
    p.permission_id === 'payroll_manage_deductions' && p.granted
  ) || user?.role_name?.toLowerCase() === 'admin';

  const canApproveDeductions = user?.permissions?.some(p => 
    p.permission_id === 'payroll_approve_deductions' && p.granted
  ) || user?.role_name?.toLowerCase() === 'admin';

  const fetchEmployeeData = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Fetch employee data with rates included
      const employeesResponse = await payrollApi.getEmployeesList({ include_rates: true });
      const employeeData = employeesResponse.employees?.find((emp: PayrollEmployee) => emp._id === employeeId);
      
      if (!employeeData) {
        setError('Employee not found');
        return;
      }
      
      setEmployee(employeeData);
      
      // Fetch employee deductions
      const deductionsResponse = await payrollApi.getEmployeeDeductions(employeeId);
      setDeductions(deductionsResponse.deductions || []);
    } catch (err: any) {
      console.error('Error fetching employee data:', err);
      setError(err.response?.data?.message || 'Failed to fetch employee data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEmployeeData();
  }, [employeeId]);

  const handleAddDeduction = () => {
    setShowAddModal(true);
  };

  const handleEditDeduction = (deduction: PayrollEmployeeDeduction) => {
    setSelectedDeduction(deduction);
    setShowEditModal(true);
  };

  const handleViewHistory = (deduction: PayrollEmployeeDeduction) => {
    setSelectedDeduction(deduction);
    setShowHistoryModal(true);
  };

  const handleApproveDeduction = async (deductionId: string) => {
    if (!canApproveDeductions) return;
    
    try {
      await payrollApi.approveDeduction(deductionId);
      await fetchEmployeeData(); // Refresh data
    } catch (error: any) {
      console.error('Error approving deduction:', error);
      console.error(error.response?.data?.message || 'Failed to approve deduction');
    }
  };

  const handleUpdateStatus = async (deductionId: string, status: string, reason?: string) => {
    if (!canManageDeductions) return;
    
    try {
      await payrollApi.updateDeductionStatus(deductionId, status, reason);
      await fetchEmployeeData(); // Refresh data
    } catch (error: any) {
      console.error('Error updating deduction status:', error);
      console.error(error.response?.data?.message || 'Failed to update deduction status');
    }
  };

  const handleSuccess = () => {
    fetchEmployeeData();
    setShowAddModal(false);
    setShowEditModal(false);
    setSelectedDeduction(null);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-AE', {
      style: 'currency',
      currency: 'AED',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      active: { color: 'bg-green-100 text-green-800', icon: CheckCircle, label: 'Active' },
      paused: { color: 'bg-yellow-100 text-yellow-800', icon: Pause, label: 'Paused' },
      completed: { color: 'bg-blue-100 text-blue-800', icon: CheckCircle, label: 'Completed' },
      cancelled: { color: 'bg-red-100 text-red-800', icon: X, label: 'Cancelled' },
      pending_approval: { color: 'bg-orange-100 text-orange-800', icon: AlertCircle, label: 'Pending Approval' }
    };

    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.active;
    const IconComponent = config.icon;

    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${config.color}`}>
        <IconComponent className="w-3 h-3 mr-1" />
        {config.label}
      </span>
    );
  };

  const getFrequencyLabel = (frequency: string) => {
    const labels = {
      daily: 'Daily',
      weekly: 'Weekly', 
      monthly: 'Monthly',
      per_pay_period: 'Per Pay Period',
      one_time: 'One Time'
    };
    return labels[frequency as keyof typeof labels] || frequency;
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          <span className="ml-3 text-gray-600">Loading employee deductions...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <Card className="border-red-200">
          <CardContent className="p-6">
            <div className="flex items-center gap-3 text-red-600">
              <AlertCircle className="w-5 h-5" />
              <span className="font-medium">Error loading employee deductions</span>
            </div>
            <p className="text-red-600 mt-2">{error}</p>
            <div className="flex gap-3 mt-4">
              <Button 
                onClick={fetchEmployeeData} 
                variant="outline"
              >
                Try Again
              </Button>
              <Button 
                onClick={() => router.back()}
                variant="outline"
              >
                Go Back
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!employee) {
    return null;
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => router.back()}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              {employee.first_name} {employee.last_name} - Deductions
            </h1>
            <p className="text-gray-600 mt-1">
              {employee.speciality} • {employee.branch.branch_name} • {employee.email}
            </p>
          </div>
        </div>
        {canManageDeductions && (
          <Button onClick={handleAddDeduction} className="flex items-center gap-2">
            <Plus className="w-4 h-4" />
            Add Deduction
          </Button>
        )}
      </div>

      {/* Employee Summary Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="w-5 h-5" />
            Employee Summary
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div>
              <div className="text-sm text-gray-500">Monthly Salary</div>
              <div className="text-2xl font-bold text-green-600">
                {employee.payroll_info?.monthly_salary ? formatCurrency(employee.payroll_info.monthly_salary) : 'Not set'}
              </div>
            </div>
            <div>
              <div className="text-sm text-gray-500">Active Deductions</div>
              <div className="text-2xl font-bold text-blue-600">
                {deductions.filter(d => d.status === 'active').length}
              </div>
            </div>
            <div>
              <div className="text-sm text-gray-500">Total Monthly Deductions</div>
              <div className="text-2xl font-bold text-orange-600">
                {formatCurrency(
                  deductions
                    .filter(d => d.status === 'active')
                    .reduce((total, d) => {
                      // Convert to monthly estimate based on frequency
                      const multiplier = {
                        daily: 30,
                        weekly: 4.33,
                        monthly: 1,
                        per_pay_period: 2, // Assuming bi-weekly
                        one_time: 0
                      };
                      return total + (d.amount * (multiplier[d.frequency as keyof typeof multiplier] || 1));
                    }, 0)
                )}
              </div>
            </div>
            <div>
              <div className="text-sm text-gray-500">Pending Approvals</div>
              <div className="text-2xl font-bold text-red-600">
                {deductions.filter(d => d.status === 'pending_approval').length}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Deductions List */}
      <Card>
        <CardHeader>
          <CardTitle>Deductions</CardTitle>
        </CardHeader>
        <CardContent>
          {deductions.length === 0 ? (
            <div className="text-center py-8">
              <DollarSign className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 mb-4">No deductions found for this employee.</p>
              {canManageDeductions && (
                <Button onClick={handleAddDeduction} className="flex items-center gap-2">
                  <Plus className="w-4 h-4" />
                  Add First Deduction
                </Button>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              {deductions.map((deduction) => (
                <div key={deduction._id} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="font-medium text-gray-900">
                          {deduction.deduction_type?.name || 'Unknown Type'}
                        </h3>
                        {getStatusBadge(deduction.status)}
                        {deduction.legal_required && (
                          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800">
                            Legal Required
                          </span>
                        )}
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                        <div>
                          <span className="font-medium">Amount:</span> {formatCurrency(deduction.amount)} ({getFrequencyLabel(deduction.frequency)})
                        </div>
                        <div>
                          <span className="font-medium">Period:</span> {formatDate(deduction.start_date)} 
                          {deduction.end_date && ` - ${formatDate(deduction.end_date)}`}
                        </div>
                        <div>
                          <span className="font-medium">Priority:</span> {deduction.priority || 'N/A'}
                        </div>
                      </div>

                      {deduction.max_total_amount && (
                        <div className="mt-2 text-sm">
                          <span className="font-medium">Progress:</span> 
                          {formatCurrency(deduction.total_deducted)} / {formatCurrency(deduction.max_total_amount)}
                          {deduction.remaining_balance && (
                            <span className="text-gray-500"> (Remaining: {formatCurrency(deduction.remaining_balance)})</span>
                          )}
                        </div>
                      )}

                      {deduction.reference_number && (
                        <div className="mt-2 text-sm">
                          <span className="font-medium">Reference:</span> {deduction.reference_number}
                        </div>
                      )}

                      {deduction.notes && (
                        <div className="mt-2 text-sm text-gray-600">
                          <span className="font-medium">Notes:</span> {deduction.notes}
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-2 ml-4">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleViewHistory(deduction)}
                        className="flex items-center gap-1"
                      >
                        <History className="w-3 h-3" />
                        History
                      </Button>

                      {canManageDeductions && deduction.status !== 'completed' && deduction.status !== 'cancelled' && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleEditDeduction(deduction)}
                          className="flex items-center gap-1"
                        >
                          <Edit className="w-3 h-3" />
                          Edit
                        </Button>
                      )}

                      {canApproveDeductions && deduction.status === 'pending_approval' && (
                        <Button
                          size="sm"
                          onClick={() => handleApproveDeduction(deduction._id)}
                          className="flex items-center gap-1"
                        >
                          <CheckCircle className="w-3 h-3" />
                          Approve
                        </Button>
                      )}

                      {canManageDeductions && deduction.status === 'active' && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleUpdateStatus(deduction._id, 'paused')}
                          className="flex items-center gap-1"
                        >
                          <Pause className="w-3 h-3" />
                          Pause
                        </Button>
                      )}

                      {canManageDeductions && deduction.status === 'paused' && (
                        <Button
                          size="sm"
                          onClick={() => handleUpdateStatus(deduction._id, 'active')}
                          className="flex items-center gap-1"
                        >
                          <CheckCircle className="w-3 h-3" />
                          Resume
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Modals */}
      {showAddModal && (
        <AddDeductionModal
          employee={employee}
          onClose={() => setShowAddModal(false)}
          onSuccess={handleSuccess}
        />
      )}

      {showEditModal && selectedDeduction && (
        <EditDeductionModal
          deduction={selectedDeduction}
          onClose={() => {
            setShowEditModal(false);
            setSelectedDeduction(null);
          }}
          onSuccess={handleSuccess}
        />
      )}

      {showHistoryModal && selectedDeduction && (
        <DeductionHistoryModal
          deduction={selectedDeduction}
          onClose={() => {
            setShowHistoryModal(false);
            setSelectedDeduction(null);
          }}
        />
      )}
    </div>
  );
}