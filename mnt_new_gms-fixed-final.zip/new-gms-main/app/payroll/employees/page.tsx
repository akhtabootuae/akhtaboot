"use client";

import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Search, Edit, DollarSign, Users, AlertCircle, ArrowLeft } from "lucide-react";
import Link from "next/link";
import { payrollApi } from "../../../services/api";
import { PayrollEmployee } from "../../types/payroll";
import { useAuth } from "../../context/AuthContext";
import { useRouteProtection } from "../../../services/route-protection";
import EditSalaryModal from "../../components/Payroll/Modals/EditSalaryModal";

export default function EmployeeSalariesPage() {
  const { user, isAuthenticated } = useAuth();
  
  // Admin and accountant only - prevent supervisor access
  const hasAccess = useRouteProtection(isAuthenticated, user, { adminAndAccountantOnly: true });
  
  const [employees, setEmployees] = useState<PayrollEmployee[]>([]);
  const [filteredEmployees, setFilteredEmployees] = useState<PayrollEmployee[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedEmployee, setSelectedEmployee] = useState<PayrollEmployee | null>(null);
  const [showEditModal, setShowEditModal] = useState(false);

  const canManageSalaries = user?.permissions?.some(p => 
    p.permission_id === 'payroll_manage_rates' && p.granted
  ) || user?.role_name?.toLowerCase() === 'admin';

  const fetchEmployees = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await payrollApi.getEmployeesList();
      
      // The response is the data object directly due to axios interceptor
      const apiResponse = response as {
        employees: Array<{
          _id: string;
          first_name: string;
          last_name: string;
          email: string;
          speciality?: string;
          staff_code?: string;
          branch?: {
            branch_name: string;
          };
          payroll_info?: {
            hire_date?: string;
            eligible?: boolean;
          };
          daily_rate?: {
            rate_id: string;
            daily_rate: number;
            rate_type: string;
            effective_date: string;
            end_date?: string | null;
            created_at: string;
            notes?: string;
          } | null;
        }>;
      };
      
      // Map the API response to match PayrollEmployee interface
      const mappedEmployees = (apiResponse.employees || []).map((employee) => ({
        employee_id: employee._id,
        _id: employee._id,
        first_name: employee.first_name,
        last_name: employee.last_name,
        email: employee.email,
        speciality: employee.speciality,
        employee_number: employee.staff_code,
        branch: {
          branch_name: employee.branch?.branch_name || 'Unknown Branch',
          location: employee.branch?.branch_name || 'Unknown Location'
        },
        payroll_info: {
          current_daily_rate: employee.daily_rate?.daily_rate || 0,
          employee_number: employee.staff_code || '',
          hire_date: employee.payroll_info?.hire_date || null,
          payroll_eligible: employee.payroll_info?.eligible || false,
          last_pay_date: null // Not in API response yet
        },
        current_rate: employee.daily_rate?.daily_rate || 0,
        rate_effective_date: employee.daily_rate?.effective_date || undefined
      }));
      
      setEmployees(mappedEmployees);
      setFilteredEmployees(mappedEmployees);
    } catch (err: unknown) {
      console.error('Error fetching employees:', err);
      const error = err as { response?: { data?: { message?: string } } };
      setError(error.response?.data?.message || 'Failed to fetch employees');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEmployees();
  }, []);

  useEffect(() => {
    if (!searchTerm) {
      setFilteredEmployees(employees);
    } else {
      const filtered = employees.filter(employee =>
        `${employee.first_name} ${employee.last_name}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
        employee.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (employee.employee_number || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (employee.speciality || '').toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredEmployees(filtered);
    }
  }, [searchTerm, employees]);

  const handleEditSalary = (employee: PayrollEmployee) => {
    setSelectedEmployee(employee);
    setShowEditModal(true);
  };


  const handleSalaryUpdated = () => {
    fetchEmployees(); // Refresh the list
    setShowEditModal(false);
    setSelectedEmployee(null);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-AE', {
      style: 'currency',
      currency: 'AED',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          <span className="ml-3 text-gray-600">Loading employees...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <Card className="border-red-200">
          <CardContent className="p-6">
            <div className="flex items-center gap-3 text-red-600">
              <AlertCircle className="w-5 h-5" />
              <span className="font-medium">Error loading employees</span>
            </div>
            <p className="text-red-600 mt-2">{error}</p>
            <Button 
              onClick={fetchEmployees} 
              className="mt-4"
              variant="outline"
            >
              Try Again
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/payroll">
            <Button variant="outline" size="sm" className="flex items-center gap-2">
              <ArrowLeft className="w-4 h-4" />
              Back
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Employee Salaries</h1>
            <p className="text-gray-600 mt-2">
              Manage monthly salaries for payroll-eligible employees
            </p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Users className="w-4 h-4" />
            <span>{employees.length} employees</span>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                type="text"
                placeholder="Search by name, email, employee number, or specialty..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Employees Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="w-5 h-5" />
            Employee Monthly Salaries
          </CardTitle>
        </CardHeader>
        <CardContent>
          {filteredEmployees.length === 0 ? (
            <div className="text-center py-8">
              <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">
                {searchTerm ? 'No employees match your search criteria' : 'No payroll-eligible employees found'}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Employee</th>
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Specialty</th>
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Branch</th>
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Monthly Salary</th>
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Hire Date</th>
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Last Pay</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-gray-700">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {filteredEmployees.map((employee) => (
                    <tr key={employee.employee_id || employee._id} className="hover:bg-gray-50">
                      <td className="px-4 py-4">
                        <div>
                          <div className="font-medium text-gray-900">
                            {employee.first_name} {employee.last_name}
                          </div>
                          <div className="text-sm text-gray-500">{employee.email}</div>
                          {employee.employee_number && (
                            <div className="text-xs text-gray-400">ID: {employee.employee_number}</div>
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                          {employee.speciality || 'General'}
                        </span>
                      </td>
                      <td className="px-4 py-4">
                        <div className="text-sm text-gray-900">{employee.branch.branch_name}</div>
                        <div className="text-xs text-gray-500">{employee.branch.branch_name}</div>
                      </td>
                      <td className="px-4 py-4">
                        {/* Check for monthly salary first (new system), then fall back to daily rate (old system) */}
                        {employee.payroll_info?.monthly_salary ? (
                          <>
                            <div className="font-medium text-lg text-green-600">
                              {formatCurrency(employee.payroll_info.monthly_salary)}
                            </div>
                            <div className="text-xs text-gray-500">per month</div>
                          </>
                        ) : (employee.current_rate || employee.payroll_info?.current_daily_rate) ? (
                          <>
                            <div className="font-medium text-lg text-blue-600">
                              {formatCurrency((employee.current_rate || employee.payroll_info?.current_daily_rate || 0) * 22)}
                            </div>
                            <div className="text-xs text-gray-500">per month (estimated from daily rate)</div>
                          </>
                        ) : (
                          <div className="font-medium text-sm text-gray-500">
                            No salary information available
                          </div>
                        )}
                      </td>
                      <td className="px-4 py-4 text-sm text-gray-600">
                        {formatDate(employee.payroll_info?.hire_date)}
                      </td>
                      <td className="px-4 py-4 text-sm text-gray-600">
                        {formatDate(employee.payroll_info?.last_pay_date)}
                      </td>
                      <td className="px-4 py-4">
                        <div className="flex items-center justify-center gap-2">
                          {canManageSalaries && (
                            <Button
                              size="sm"
                              onClick={() => handleEditSalary(employee)}
                              className="flex items-center gap-1"
                            >
                              <Edit className="w-3 h-3" />
                              Edit Salary
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Modals */}
      {showEditModal && selectedEmployee && (
        <EditSalaryModal
          employee={selectedEmployee}
          onClose={() => {
            setShowEditModal(false);
            setSelectedEmployee(null);
          }}
          onSuccess={handleSalaryUpdated}
        />
      )}
    </div>
  );
}