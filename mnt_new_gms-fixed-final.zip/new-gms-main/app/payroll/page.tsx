"use client";

import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import Link from "next/link";
import { Users, FileText, DollarSign, MinusCircle, Calendar, Clock, BarChart3, AlertTriangle } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { useRouteProtection } from "../../services/route-protection";
import { payrollApi } from "../../services/api";

export default function PayrollDashboard() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  
  // Admin and accountant only - prevent supervisor access
  const hasAccess = useRouteProtection(isAuthenticated, user, { adminAndAccountantOnly: true });
  
  const isAdmin = user?.role_name?.toLowerCase() === 'admin';
  const [employeeCount, setEmployeeCount] = useState<number | null>(null);
  
  useEffect(() => {
    const fetchEmployeeCount = async () => {
      try {
        const response = await payrollApi.getEmployees();
        setEmployeeCount((response as { total_employees?: number }).total_employees || 0);
      } catch (error) {
        console.error('Error fetching employee count:', error);
        setEmployeeCount(0);
      }
    };
    
    if (hasAccess && isAuthenticated && !authLoading) {
      fetchEmployeeCount();
    }
  }, [hasAccess, isAuthenticated, authLoading]);

  // Show loading state during auth check
  if (authLoading || !hasAccess) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const dashboardCards = [
    {
      title: "Employee Rates",
      description: "Manage daily rates for all employees",
      icon: <DollarSign className="w-8 h-8 text-blue-600" />,
      href: "/payroll/employees",
      color: "border-blue-200 hover:border-blue-300"
    },
    {
      title: "Deductions",
      description: "Manage employee deductions and loans",
      icon: <MinusCircle className="w-8 h-8 text-orange-600" />,
      href: "/payroll/deductions",
      color: "border-orange-200 hover:border-orange-300"
    },
    {
      title: "Attendance",
      description: "Track employee time and attendance",
      icon: <Calendar className="w-8 h-8 text-indigo-600" />,
      href: "/payroll/attendance",
      color: "border-indigo-200 hover:border-indigo-300"
    },
    {
      title: "Pay Periods",
      description: "Manage payroll periods and calculations",
      icon: <Clock className="w-8 h-8 text-purple-600" />,
      href: "/payroll/pay-periods",
      color: "border-purple-200 hover:border-purple-300"
    },
    // {
    //   title: "Reports",
    //   description: "Generate payroll and attendance reports",
    //   icon: <BarChart3 className="w-8 h-8 text-blue-600" />,
    //   href: "/payroll/reports",
    //   color: "border-blue-200 hover:border-blue-300"
    // },
    // {
    //   title: "Paystubs",
    //   description: "Generate and manage employee paystubs",
    //   icon: <FileText className="w-8 h-8 text-teal-600" />,
    //   href: "/payroll/paystubs",
    //   color: "border-teal-200 hover:border-teal-300"
    // },
    {
      title: "Alerts",
      description: "Monitor payroll alerts and notifications",
      icon: <AlertTriangle className="w-8 h-8 text-yellow-600" />,
      href: "/notifications",
      color: "border-yellow-200 hover:border-yellow-300"
    },
    // {
    //   title: "Total Employees",
    //   description: "Payroll-eligible staff members",
    //   icon: <Users className="w-8 h-8 text-green-600" />,
    //   href: "/payroll/employees",
    //   color: "border-green-200 hover:border-green-300",
    //   metric: employeeCount !== null ? employeeCount.toString() : "Loading..."
    // },
    ...(isAdmin ? [{
      title: "Audit Log",
      description: "View all payroll changes and modifications",
      icon: <FileText className="w-8 h-8 text-purple-600" />,
      href: "/payroll/audit",
      color: "border-purple-200 hover:border-purple-300"
    }] : [])
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Payroll Management</h1>
          <p className="text-gray-600 mt-2">
            Manage employee daily rates and payroll information
          </p>
        </div>
      </div>

      {/* Quick Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {dashboardCards.map((card, index) => (
          <Link key={index} href={card.href}>
            <Card className={`cursor-pointer transition-all duration-200 ${card.color} hover:shadow-lg`}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-lg font-medium">{card.title}</CardTitle>
                {card.icon}
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-3">{card.description}</p>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="mt-2 p-0 h-auto text-blue-600 hover:text-blue-800"
                >
                  View Details →
                </Button>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <Link href="/payroll/employees">
              <Button className="w-full justify-start" variant="outline">
                <Users className="w-4 h-4 mr-2" />
                Manage Employee Rates
              </Button>
            </Link>

            <Link href="/payroll/deductions">
              <Button className="w-full justify-start" variant="outline">
                <MinusCircle className="w-4 h-4 mr-2" />
                Manage Deductions
              </Button>
            </Link>

            <Link href="/payroll/attendance">
              <Button className="w-full justify-start" variant="outline">
                <Calendar className="w-4 h-4 mr-2" />
                Track Attendance
              </Button>
            </Link>

            <Link href="/payroll/pay-periods">
              <Button className="w-full justify-start" variant="outline">
                <Clock className="w-4 h-4 mr-2" />
                Calculate Payroll
              </Button>
            </Link>

            <Link href="/payroll/reports">
              <Button className="w-full justify-start" variant="outline">
                <BarChart3 className="w-4 h-4 mr-2" />
                Generate Reports
              </Button>
            </Link>
            
            {isAdmin && (
              <Link href="/payroll/audit">
                <Button className="w-full justify-start" variant="outline">
                  <FileText className="w-4 h-4 mr-2" />
                  View Audit Log
                </Button>
              </Link>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Feature Status */}
      
    </div>
  );
}