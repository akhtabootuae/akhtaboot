"use client";

import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { AlertTriangle, CheckCircle, Clock, XCircle, Bell, Filter } from "lucide-react";
import { useAuth } from "../../context/AuthContext";
import { useRouteProtection } from "../../../services/route-protection";

export default function AlertsPage() {
  const { user, isAuthenticated } = useAuth();
  
  // Admin and accountant only - prevent supervisor access
  const hasAccess = useRouteProtection(isAuthenticated, user, { adminAndAccountantOnly: true });
  const [alerts] = useState([]);
  const [filters, setFilters] = useState({
    type: '',
    severity: '',
    resolved: ''
  });

  const mockAlerts = [
    {
      id: '1',
      type: 'missing_timesheet',
      severity: 'high',
      title: 'Missing Time Sheet',
      message: 'John Doe has not submitted time sheet for January 15, 2024',
      related_entity_type: 'employee',
      related_entity_id: 'emp_001',
      acknowledged: false,
      resolved: false,
      created_at: '2024-01-16T09:00:00Z',
      expires_at: '2024-01-20T23:59:59Z'
    },
    {
      id: '2',
      type: 'calculation_error',
      severity: 'critical',
      title: 'Payroll Calculation Error',
      message: 'Error calculating overtime for pay period January 2024 - Week 1',
      related_entity_type: 'pay_period',
      related_entity_id: 'pp_001',
      acknowledged: true,
      resolved: false,
      created_at: '2024-01-10T14:30:00Z',
      acknowledged_at: '2024-01-10T15:00:00Z'
    },
    {
      id: '3',
      type: 'approval_required',
      severity: 'medium',
      title: 'Deduction Approval Required',
      message: 'New employee advance deduction requires approval for Jane Smith',
      related_entity_type: 'deduction',
      related_entity_id: 'ded_003',
      acknowledged: true,
      resolved: true,
      created_at: '2024-01-08T11:20:00Z',
      acknowledged_at: '2024-01-08T11:25:00Z',
      resolved_at: '2024-01-08T16:45:00Z'
    },
    {
      id: '4',
      type: 'payment_due',
      severity: 'low',
      title: 'Upcoming Payment Due',
      message: 'Payroll payment due in 2 days for January 2024 - Week 1',
      related_entity_type: 'pay_period',
      related_entity_id: 'pp_001',
      acknowledged: false,
      resolved: false,
      created_at: '2024-01-13T08:00:00Z',
      expires_at: '2024-01-15T23:59:59Z'
    }
  ];

  const getSeverityConfig = (severity: string) => {
    const configs = {
      critical: { 
        color: 'text-red-600', 
        bgColor: 'bg-red-100', 
        borderColor: 'border-red-200',
        icon: XCircle,
        label: 'Critical'
      },
      high: { 
        color: 'text-orange-600', 
        bgColor: 'bg-orange-100', 
        borderColor: 'border-orange-200',
        icon: AlertTriangle,
        label: 'High'
      },
      medium: { 
        color: 'text-yellow-600', 
        bgColor: 'bg-yellow-100', 
        borderColor: 'border-yellow-200',
        icon: Clock,
        label: 'Medium'
      },
      low: { 
        color: 'text-blue-600', 
        bgColor: 'bg-blue-100', 
        borderColor: 'border-blue-200',
        icon: Bell,
        label: 'Low'
      }
    };
    return configs[severity as keyof typeof configs] || configs.medium;
  };

  const getTypeLabel = (type: string) => {
    const labels = {
      missing_timesheet: 'Missing Time Sheet',
      calculation_error: 'Calculation Error',
      approval_required: 'Approval Required',
      payment_due: 'Payment Due',
      compliance_issue: 'Compliance Issue'
    };
    return labels[type as keyof typeof labels] || type;
  };

  const formatDateTime = (dateString: string) => {
    return new Date(dateString).toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const handleAcknowledge = (alertId: string) => {
    console.log('Acknowledging alert:', alertId);
    // API call would go here
  };

  const handleResolve = (alertId: string) => {
    console.log('Resolving alert:', alertId);
    // API call would go here
  };

  const filteredAlerts = mockAlerts.filter(alert => {
    if (filters.type && alert.type !== filters.type) return false;
    if (filters.severity && alert.severity !== filters.severity) return false;
    if (filters.resolved && alert.resolved.toString() !== filters.resolved) return false;
    return true;
  });

  const alertStats = {
    total: filteredAlerts.length,
    unresolved: filteredAlerts.filter(a => !a.resolved).length,
    critical: filteredAlerts.filter(a => a.severity === 'critical').length,
    unacknowledged: filteredAlerts.filter(a => !a.acknowledged).length
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Payroll Alerts</h1>
          <p className="text-gray-600 mt-2">
            Monitor and manage payroll system alerts and notifications
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Bell className="w-6 h-6 text-blue-600" />
          <span className="text-sm font-medium text-gray-700">
            {alertStats.unresolved} unresolved alerts
          </span>
        </div>
      </div>

      {/* Alert Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Bell className="w-8 h-8 text-blue-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-500">Total Alerts</p>
                <p className="text-2xl font-semibold text-gray-900">{alertStats.total}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <AlertTriangle className="w-8 h-8 text-orange-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-500">Unresolved</p>
                <p className="text-2xl font-semibold text-gray-900">{alertStats.unresolved}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <XCircle className="w-8 h-8 text-red-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-500">Critical</p>
                <p className="text-2xl font-semibold text-gray-900">{alertStats.critical}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Clock className="w-8 h-8 text-yellow-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-500">Unacknowledged</p>
                <p className="text-2xl font-semibold text-gray-900">{alertStats.unacknowledged}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="w-5 h-5" />
            Filters
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Alert Type
              </label>
              <select
                value={filters.type}
                onChange={(e) => setFilters(prev => ({ ...prev, type: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">All Types</option>
                <option value="missing_timesheet">Missing Time Sheet</option>
                <option value="calculation_error">Calculation Error</option>
                <option value="approval_required">Approval Required</option>
                <option value="payment_due">Payment Due</option>
                <option value="compliance_issue">Compliance Issue</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Severity
              </label>
              <select
                value={filters.severity}
                onChange={(e) => setFilters(prev => ({ ...prev, severity: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">All Severities</option>
                <option value="critical">Critical</option>
                <option value="high">High</option>
                <option value="medium">Medium</option>
                <option value="low">Low</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Status
              </label>
              <select
                value={filters.resolved}
                onChange={(e) => setFilters(prev => ({ ...prev, resolved: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">All Statuses</option>
                <option value="false">Unresolved</option>
                <option value="true">Resolved</option>
              </select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Alerts List */}
      <Card>
        <CardHeader>
          <CardTitle>Alerts</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredAlerts.length === 0 ? (
            <div className="text-center py-8">
              <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
              <p className="text-gray-600 mb-2">No alerts match your criteria.</p>
              <p className="text-sm text-gray-500">All systems are running smoothly!</p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredAlerts.map((alert) => {
                const severityConfig = getSeverityConfig(alert.severity);
                const IconComponent = severityConfig.icon;
                
                return (
                  <div
                    key={alert.id}
                    className={`border rounded-lg p-4 ${severityConfig.borderColor} ${
                      alert.resolved ? 'opacity-60' : ''
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-3 flex-1">
                        <div className={`p-2 rounded-lg ${severityConfig.bgColor}`}>
                          <IconComponent className={`w-5 h-5 ${severityConfig.color}`} />
                        </div>
                        
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="font-medium text-gray-900">{alert.title}</h3>
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${severityConfig.bgColor} ${severityConfig.color}`}>
                              {severityConfig.label}
                            </span>
                            <span className="px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-600">
                              {getTypeLabel(alert.type)}
                            </span>
                          </div>
                          
                          <p className="text-gray-700 mb-3">{alert.message}</p>
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm text-gray-500">
                            <div>Created: {formatDateTime(alert.created_at)}</div>
                            {alert.expires_at && (
                              <div>Expires: {formatDateTime(alert.expires_at)}</div>
                            )}
                            {alert.acknowledged_at && (
                              <div>Acknowledged: {formatDateTime(alert.acknowledged_at)}</div>
                            )}
                            {alert.resolved_at && (
                              <div>Resolved: {formatDateTime(alert.resolved_at)}</div>
                            )}
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2 ml-4">
                        {alert.resolved ? (
                          <span className="flex items-center gap-1 text-green-600 text-sm">
                            <CheckCircle className="w-4 h-4" />
                            Resolved
                          </span>
                        ) : (
                          <>
                            {!alert.acknowledged && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleAcknowledge(alert.id)}
                              >
                                Acknowledge
                              </Button>
                            )}
                            <Button
                              size="sm"
                              onClick={() => handleResolve(alert.id)}
                              className="bg-green-600 hover:bg-green-700"
                            >
                              Resolve
                            </Button>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}