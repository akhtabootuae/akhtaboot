import React, { useState } from 'react';

// Mock data for demonstration
const mockWorkOrder = {
  _id: "demo-work-order",
  workOrderNumber: "WO-2025-001",
  status: "in_progress",
  priority: "high",
  customer: {
    name: "John Smith",
    phone: "+962-77-123-4567",
    email: "john.smith@email.com"
  },
  vehicle: {
    year: "2020",
    make: "Toyota",
    model: "Yaris",
    color: "Silver",
    licensePlate: "AD 13 123456"
  },
  timeline: {
    startDate: "5/17/2025",
    estimatedEndDate: "5/22/2025",
    supervisor: "Charlie Technician"
  },
  hours: {
    estimated: 24,
    actual: 18.5,
    progress: 100
  },
  createdAt: new Date().toISOString(),
  description: "Regular maintenance and inspection"
};

export default function WorkOrderPage() {
  const [workOrder] = useState(mockWorkOrder);
  const [isVehicleOverviewCollapsed, setIsVehicleOverviewCollapsed] = useState(false);

  const getStatusBadgeClass = (status) => {
    switch (status) {
      case 'in_progress':
        return 'bg-blue-600 text-white';
      case 'completed':
        return 'bg-green-600 text-white';
      case 'open':
        return 'bg-yellow-600 text-white';
      default:
        return 'bg-gray-600 text-white';
    }
  };

  const formatStatus = (status) => {
    return status.replace('_', ' ').toUpperCase();
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                Work Order #{workOrder.workOrderNumber}
              </h1>
              <p className="text-gray-600">ID: {workOrder._id}</p>
            </div>
            <div className="flex items-center gap-3">
              <span className={`px-4 py-2 rounded-full text-sm font-medium ${getStatusBadgeClass(workOrder.status)}`}>
                {formatStatus(workOrder.status)}
              </span>
              <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                Performance Review
              </button>
            </div>
          </div>
        </div>

        {/* Main Info Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Customer Information */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Customer Information</h2>
            <div className="space-y-3">
              <div className="text-gray-900 font-medium">{workOrder.customer.name}</div>
              <div className="text-gray-600">{workOrder.customer.phone}</div>
              <div className="text-gray-900 font-medium">
                {workOrder.vehicle.year} {workOrder.vehicle.make} {workOrder.vehicle.model}
              </div>
              <div className="text-gray-600">{workOrder.vehicle.color}</div>
              <div className="text-gray-600">Plate: {workOrder.vehicle.licensePlate}</div>
            </div>
          </div>

          {/* Timeline */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Timeline</h2>
            <div className="space-y-3">
              <div>
                <span className="text-gray-600">Started: </span>
                <span className="text-gray-900">{workOrder.timeline.startDate}</span>
              </div>
              <div>
                <span className="text-gray-600">Est. End: </span>
                <span className="text-gray-900">{workOrder.timeline.estimatedEndDate}</span>
              </div>
              <div>
                <span className="text-gray-600">Supervisor: </span>
                <span className="text-gray-900">{workOrder.timeline.supervisor}</span>
              </div>
              <div className="mt-4">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-gray-600">Overall Progress</span>
                  <span className="text-gray-900 font-semibold">{workOrder.hours.progress}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-3">
                  <div 
                    className="bg-orange-500 h-3 rounded-full transition-all duration-300" 
                    style={{ width: `${workOrder.hours.progress}%` }}
                  />
                </div>
                <div className="flex items-center mt-2 text-sm text-orange-600">
                  <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                  </svg>
                  Approaching deadline
                </div>
              </div>
            </div>
          </div>

          {/* Hours Summary */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Hours Summary</h2>
            <div className="space-y-3">
              <div>
                <span className="text-gray-600">Estimated: </span>
                <span className="text-gray-900 font-semibold">{workOrder.hours.estimated}h</span>
              </div>
              <div>
                <span className="text-gray-600">Actual: </span>
                <span className="text-gray-900 font-semibold">{workOrder.hours.actual}h</span>
              </div>
            </div>
          </div>
        </div>

        {/* Vehicle Overview */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold text-gray-900">Vehicle Overview</h2>
            <button
              onClick={() => setIsVehicleOverviewCollapsed(!isVehicleOverviewCollapsed)}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              aria-label={isVehicleOverviewCollapsed ? "Expand vehicle overview" : "Collapse vehicle overview"}
            >
              <svg 
                className={`w-5 h-5 transform transition-transform ${isVehicleOverviewCollapsed ? 'rotate-180' : ''}`}
                fill="none" 
                stroke="currentColor" 
                viewBox="0 0 24 24"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </button>
          </div>
          {!isVehicleOverviewCollapsed && (
            <div className="flex justify-center">
              <div className="relative">
                {/* Car diagram SVG */}
                <svg width="400" height="250" viewBox="0 0 400 250" className="border border-gray-200 rounded-lg">
                {/* Car body outline */}
                <path
                  d="M 80 80 
                     Q 80 60 100 60 
                     L 300 60 
                     Q 320 60 320 80 
                     L 320 170 
                     Q 320 190 300 190 
                     L 100 190 
                     Q 80 190 80 170 
                     Z"
                  fill="#f0f9ff"
                  stroke="#1e40af"
                  strokeWidth="2"
                />
                
                {/* Windshield */}
                <rect x="120" y="80" width="160" height="40" fill="#d1fae5" stroke="#10b981" strokeWidth="1" rx="5"/>
                
                {/* Side windows */}
                <rect x="140" y="130" width="50" height="40" fill="#d1fae5" stroke="#10b981" strokeWidth="1" rx="3"/>
                <rect x="210" y="130" width="50" height="40" fill="#d1fae5" stroke="#10b981" strokeWidth="1" rx="3"/>
                
                {/* Wheels */}
                <circle cx="120" cy="200" r="20" fill="#374151" stroke="#1f2937" strokeWidth="2"/>
                <circle cx="120" cy="200" r="12" fill="#6b7280"/>
                <circle cx="280" cy="200" r="20" fill="#374151" stroke="#1f2937" strokeWidth="2"/>
                <circle cx="280" cy="200" r="12" fill="#6b7280"/>
                
                {/* Headlights */}
                <circle cx="315" cy="100" r="8" fill="#fef3c7" stroke="#f59e0b" strokeWidth="1"/>
                <circle cx="315" cy="150" r="8" fill="#fef3c7" stroke="#f59e0b" strokeWidth="1"/>
                
                {/* Door handles */}
                <rect x="75" y="120" width="8" height="15" fill="#9ca3af" rx="2"/>
                <rect x="75" y="150" width="8" height="15" fill="#9ca3af" rx="2"/>
                
                {/* Center console/dashboard */}
                <rect x="180" y="140" width="40" height="20" fill="white" stroke="#d1d5db" strokeWidth="1" rx="3"/>
              </svg>
            </div>
          </div>
          )}
        </div>
      </div>
    </div>
  );
}