"use client";

import React, { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import api, { dataApi } from '../../../services/api';
import { 
  getCustomerInfo, 
  getVehicleInfo, 
  getSupervisorInfo, 
  type FlexibleWorkOrder 
} from '../../../lib/workOrderHelpers';

// Import all components
import { 
  WorkOrderHeader, 
  CustomerInfoCard, 
  TimelineCard, 
  HoursSummaryCard, 
  PartsStatusGrid 
} from './components/MainWorkOrder';
import { VehicleVisualization } from './components/Visualizations';
import SubWorkOrderDetail from './components/SubWorkOrder/SubWorkOrderDetail';
import { QARecordsList } from '../../components/qa/QARecordsList';
import { QAForm } from '../../components/qa/QAForm';
import WorkOrderCaseModal from './components/WorkOrderCaseModal';

/**
 * WorkOrderPage Component
 * 
 * Main page for viewing work order details.
 * - Shows work order overview when no part selected
 * - Shows sub work order detail when part is selected
 * - Handles loading and error states
 */
export default function WorkOrderPage() {
  console.log("=== WorkOrderPage CLIENT COMPONENT ===");
  
  const router = useRouter();
  const params = useParams();
  const id = params.id as string;
  
  console.log("Params:", params);
  console.log("ID from params:", id);
  
  // State management
  const [workOrder, setWorkOrder] = useState<FlexibleWorkOrder | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedPart, setSelectedPart] = useState<string | null>(null);
  const [technicians, setTechnicians] = useState<Map<string, string>>(new Map());
  const [supervisorName, setSupervisorName] = useState<string>('');
  
  // QA Modal state
  const [showQAModal, setShowQAModal] = useState(false);
  
  // Case Modal state
  const [showCaseModal, setShowCaseModal] = useState(false);

  // Fetch technicians data
  useEffect(() => {
    const fetchTechnicians = async () => {
      try {
        const result = await api.get('/api/users/technicians');
        if (result && result.success && result.data) {
          const techMap = new Map();
          result.data.forEach((tech: any) => {
            techMap.set(tech._id, tech.name);
          });
          setTechnicians(techMap);
        }
      } catch (error) {
        console.error('Error fetching technicians:', error);
      }
    };

    fetchTechnicians();
  }, []);

  // Function to fetch work order data
  const fetchWorkOrder = async () => {
    if (!id) {
      setError('No work order ID provided');
      setLoading(false);
      return;
    }

      try {
        console.log('Attempting to fetch work order with ID:', id);
        console.log('Full URL:', `/api/work-orders/${id}`);
        
        // Fetch work order from API
        const result = await api.get(`/api/work-orders/${id}`);
        
        console.log('Work order fetched:', result);
        console.log('Work order data structure:', result);
        
        if (result && result.success && result.data) {
          const workOrderData = result.data;
          
          console.log("=== WORK ORDER DETAIL DATA STRUCTURE ===");
          console.log("Full result object:", JSON.stringify(result, null, 2));
          console.log("Work order data:", workOrderData);
          console.log("Customer data:", workOrderData.customer_id || workOrderData.customerDetails || workOrderData.customer);
          console.log("Vehicle data:", workOrderData.vehicle_id || workOrderData.vehicleDetails || workOrderData.vehicle);
          console.log("=== END DATA STRUCTURE ===");
          
          setWorkOrder(workOrderData);
        } else if (result && !result.success) {
          setError(result.message || 'Failed to load work order');
        } else {
          setError('Failed to load work order - invalid response format');
        }
      } catch (err: any) {
        console.error('Error fetching work order:', err);
        console.error('Error response:', err.response);
        console.error('Error status:', err.response?.status);
        console.error('Error data:', err.response?.data);
        
        // Handle different error types
        if (err.response?.status === 404) {
          setError('Work order not found. It may have been deleted.');
        } else if (err.response?.status === 403) {
          setError('You do not have permission to view this work order.');
        } else if (err.response?.status === 401) {
          setError('Please log in to view this work order.');
        } else {
          setError(`Error loading work order: ${err.response?.data?.message || err.message}`);
        }
      } finally {
        setLoading(false);
      }
    };

  // Fetch work order data on mount
  useEffect(() => {
    console.log('WorkOrderPage - Fetching work order with ID:', id);
    fetchWorkOrder();
  }, [id]);

  // Fetch supervisor name when work order changes
  useEffect(() => {
    const fetchSupervisorName = async () => {
      if (!workOrder) return;
      
      const initialSupervisorInfo = getSupervisorInfo(workOrder);
      console.log('=== SUPERVISOR DEBUG ===');
      console.log('Work order supervisor field:', workOrder.supervisor);
      console.log('Work order assignedTo field:', workOrder.assignedTo);
      console.log('Work order assigned_to field:', workOrder.assigned_to);
      console.log('Work order supervisorDetails field:', workOrder.supervisorDetails);
      console.log('Work order assigned_technician field:', workOrder.assigned_technician);
      console.log('Work order supervisorId field:', workOrder.supervisorId);
      console.log('Work order supervisor_id field:', workOrder.supervisor_id);
      console.log('Initial supervisor info from getSupervisorInfo:', initialSupervisorInfo);
      console.log('=== END SUPERVISOR DEBUG ===');
      
      // Check if we got an ID pattern or "Unassigned"
      const isId = /^[a-fA-F0-9]{24}$/.test(initialSupervisorInfo) || 
                   initialSupervisorInfo.startsWith('Supervisor ID:');
      
      console.log('Is ID check:', isId, 'for value:', initialSupervisorInfo);
      
      if (isId) {
        try {
          // Extract the ID
          let supervisorId = initialSupervisorInfo;
          if (initialSupervisorInfo.startsWith('Supervisor ID:')) {
            supervisorId = initialSupervisorInfo.replace('Supervisor ID:', '').trim();
          }
          
          // Fetch the user details
          console.log('Fetching user details for supervisor ID:', supervisorId);
          const result = await dataApi.getUserById(supervisorId);
          console.log('API result:', result);
          console.log('API result type:', typeof result);
          console.log('API result.success:', result?.success);
          console.log('API result.data:', result?.data);
          console.log('Full API response structure:', JSON.stringify(result, null, 2));
          
          if (result && result._id) {
            console.log('User data from API:', result);
            const firstName = result.first_name || '';
            const lastName = result.last_name || '';
            const fullName = `${firstName} ${lastName}`.trim();
            console.log('Constructed full name:', fullName);
            const finalName = fullName || result.name || result.fullName || result.userName || initialSupervisorInfo;
            console.log('Final name to set:', finalName);
            setSupervisorName(finalName);
          } else {
            console.log('No data from API, using initial info:', initialSupervisorInfo);
            setSupervisorName(initialSupervisorInfo);
          }
        } catch (error) {
          console.error('Error fetching supervisor details:', error);
          setSupervisorName(initialSupervisorInfo);
        }
      } else {
        console.log('Not an ID, using initial info as final name:', initialSupervisorInfo);
        setSupervisorName(initialSupervisorInfo);
      }
    };

    fetchSupervisorName();
  }, [workOrder]);

  // Show loading spinner
  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading work order...</p>
        </div>
      </div>
    );
  }

  // Show error message
  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600 font-medium">{error}</p>
          <button 
            onClick={() => router.push('/workOrders')}
            className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            Back to Work Orders
          </button>
        </div>
      </div>
    );
  }

  // Show no data message
  if (!workOrder) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <p className="text-gray-600">No work order found</p>
      </div>
    );
  }

  // Extract customer and vehicle details using helper functions
  const customerInfo = getCustomerInfo(workOrder);
  const vehicleInfo = getVehicleInfo(workOrder);

  // Calculate progress percentage based on sub-work order progress
  const calculateProgressPercentage = (workOrder: FlexibleWorkOrder) => {
    if (!workOrder.parts || workOrder.parts.length === 0) {
      return 0;
    }

    // Get list of cancelled parts
    const cancelledParts = workOrder.cancelledParts || [];
    const cancelledPartNames = cancelledParts.map((cp: any) => cp.partName);
    
    let totalProgress = 0;
    const totalParts = workOrder.parts.length;
    
    // Calculate progress for each part
    workOrder.parts.forEach((part: any) => {
      const partName = part.partName || part.name || `Part ${workOrder.parts?.indexOf(part)}`;
      
      // If part is cancelled, count it as 100% complete
      if (cancelledPartNames.includes(partName)) {
        totalProgress += 100;
      } else if (part.stages && part.stages.length > 0) {
        // Calculate progress based on completed stages
        const totalStages = part.stages.length;
        const completedStages = part.stages.filter((stage: any) => stage.status === 'completed').length;
        const partProgress = (completedStages / totalStages) * 100;
        totalProgress += partProgress;
      }
      // If no stages, progress is 0 (already handled by default totalProgress)
    });
    
    // Calculate average progress across all parts
    return Math.round(totalProgress / totalParts);
  };
  
  const progressPercentage = calculateProgressPercentage(workOrder);

  // Get cancelled parts list
  const cancelledParts = workOrder.cancelledParts || [];
  const cancelledPartNames = cancelledParts.map((cp: any) => cp.partName);
  
  // Helper function to calculate part progress and get current technician
  const getPartDetails = (part: any) => {
    if (!part.stages || part.stages.length === 0) {
      return { progress: 0, technician: 'Unassigned', currentStage: null };
    }

    // Calculate progress based on completed stages
    const totalStages = part.stages.length;
    const completedStages = part.stages.filter((stage: any) => stage.status === 'completed').length;
    const progress = Math.round((completedStages / totalStages) * 100);

    // Find current stage (first non-completed stage)
    const currentStage = part.stages.find((stage: any) => 
      stage.status === 'in_progress' || stage.status === 'paused'
    ) || part.stages.find((stage: any) => stage.status === 'pending');

    // Get technician from current stage or last worked stage
    let technician = 'Unassigned';
    let technicianId = null;

    if (currentStage && currentStage.assignedTo) {
      technicianId = currentStage.assignedTo;
    } else {
      // Look for the last stage with an assigned technician
      for (let i = part.stages.length - 1; i >= 0; i--) {
        if (part.stages[i].assignedTo) {
          technicianId = part.stages[i].assignedTo;
          break;
        }
      }
    }

    // Resolve technician name from the technicians map
    if (technicianId) {
      if (typeof technicianId === 'object' && technicianId.name) {
        // Already populated with name
        technician = technicianId.name;
      } else if (typeof technicianId === 'string') {
        // ObjectId string - look it up in our technicians map
        const resolvedName = technicians.get(technicianId);
        technician = resolvedName || 'Unknown Technician';
      }
    }

    return { progress, technician, currentStage };
  };

  // QA helper functions
  const isQAEnabled = (): boolean => {
    if (!workOrder) return false;
    
    // QA is enabled if at least one part/stage is completed
    if (workOrder.parts && workOrder.parts.length > 0) {
      return workOrder.parts.some((part: any) => {
        if (part.stages && part.stages.length > 0) {
          return part.stages.some((stage: any) => stage.status === 'completed');
        }
        // If no stages, check if the part itself is completed
        return part.status === 'completed';
      });
    }
    
    // Fallback: check if work order status indicates completion
    return workOrder.status === 'completed' || workOrder.status === 'closed';
  };

  // Handle QA submission success
  const handleQASuccess = (qaRecord: any) => {
    console.log('QA submission successful:', qaRecord);
    setShowQAModal(false);
    // Could refresh QA records here if needed
  };

  // Handle QA form cancellation
  const handleQACancel = () => {
    setShowQAModal(false);
  };

  // Handle case creation
  const handleCreateCase = () => {
    setShowCaseModal(true);
  };

  const handleCaseCreated = (newCase: any) => {
    console.log('Case created successfully:', newCase);
    // The modal will show a success toast, so we don't need to do anything else here
  };

  // Create parts data for display
  const carParts = workOrder.parts?.map((part: any, index: number) => {
    const partName = part.partName || part.name || `Part ${index + 1}`;
    const isCancelled = cancelledPartNames.includes(partName);
    const partDetails = getPartDetails(part);
    
    // Determine part status based on stages
    let status = part.status || 'pending';
    if (isCancelled) {
      status = 'cancelled';
    } else if (partDetails.progress === 100) {
      status = 'completed';
    } else if (partDetails.progress > 0) {
      status = 'in_progress';
    }
    
    return {
      id: `part-${index}`,
      name: partName,
      status: status,
      progress: isCancelled ? 100 : partDetails.progress,
      technician: isCancelled ? 'Cancelled' : partDetails.technician,
      isCancelled: isCancelled
    };
  }) || [
    // Default parts if none in work order
    { id: 'front-bumper', name: 'Front Bumper', status: 'in_progress', progress: 60, technician: 'Mike Johnson', isCancelled: false },
    { id: 'windshield', name: 'Windshield', status: 'completed', progress: 100, technician: 'Sarah Davis', isCancelled: false },
    { id: 'left-door', name: 'Left Door', status: 'not_started', progress: 0, technician: 'Unassigned', isCancelled: false },
    { id: 'right-door', name: 'Right Door', status: 'not_started', progress: 0, technician: 'Unassigned', isCancelled: false },
    { id: 'rear-bumper', name: 'Rear Bumper', status: 'requires_attention', progress: 30, technician: 'Tom Wilson', isCancelled: false },
    { id: 'engine', name: 'Engine', status: 'not_started', progress: 0, technician: 'Unassigned', isCancelled: false }
  ];

  return (
    <div className="min-h-screen bg-gray-50 p-3 md:p-6">
      {selectedPart ? (
        // Show sub work order detail when part is selected
        <SubWorkOrderDetail 
          partName={selectedPart}
          workOrder={workOrder}
          onBack={() => setSelectedPart(null)}
          onUpdateWorkOrder={fetchWorkOrder}
        />
      ) : (
        // Show main work order overview
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <WorkOrderHeader
            workOrderNumber={workOrder.workOrderNumber}
            workOrderId={workOrder._id}
            status={workOrder.status}
            onPerformanceReview={() => console.log('Performance review clicked')}
            invoiceId={workOrder.invoice_id}
            onQAClick={() => setShowQAModal(true)}
            isQAEnabled={isQAEnabled()}
            onCreateCase={handleCreateCase}
          />

          {/* Main Info Grid - Optimized for tablets */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
            {/* Customer Information */}
            <CustomerInfoCard
              customerName={customerInfo.name}
              customerPhone={customerInfo.phone}
              vehicleDisplay={vehicleInfo.display ? vehicleInfo.display() : 'N/A Vehicle'}
              vehicleColor={vehicleInfo.color}
              licensePlate={vehicleInfo.licensePlate}
            />

            {/* Timeline */}
            {console.log('=== TIMELINE CARD PROPS ===', {
              supervisorName,
              finalValue: supervisorName || 'Loading...'
            })}
            <TimelineCard
              createdAt={workOrder.createdAt || workOrder.created_at}
              expectedCompletionDate={workOrder.expected_completion_date}
              expectedDays={workOrder.expected_days}
              supervisorName={supervisorName || 'Loading...'}
              progressPercentage={progressPercentage}
              parts={workOrder.parts}
            />

            {/* Hours Summary */}
            <HoursSummaryCard
              totalEstimatedHours={workOrder.totalEstimatedHours}
              totalActualHours={workOrder.totalActualHours || workOrder.actual_hours}
              expectedDays={workOrder.expected_days}
              expectedCompletionDate={workOrder.expected_completion_date}
              createdAt={workOrder.createdAt || workOrder.created_at}
            />
          </div>

          {/* Vehicle Overview */}
          {/* <VehicleVisualization onPartClick={(partId) => {
            // Map the part IDs to proper part names
            const partMapping: Record<string, string> = {
              'windshield': 'Windshield',
              'left-window': 'Left Window',
              'right-window': 'Right Window',
              'left-door': 'Left Door',
              'right-door': 'Right Door',
              'front-bumper': 'Front Bumper',
              'rear-bumper': 'Rear Bumper',
              'front-left-wheel': 'Front Left Wheel',
              'front-right-wheel': 'Front Right Wheel',
              'headlight': 'Headlight',
              'engine': 'Engine',
              'left-mirror': 'Left Mirror',
              'right-mirror': 'Right Mirror'
            };
            
            const partName = partMapping[partId] || partId;
            setSelectedPart(partName);
          }} /> */}

          {/* Parts Status Cards */}
          <PartsStatusGrid
            parts={carParts}
            onPartClick={(partId) => {
              // Find the part by ID and pass the name instead
              const part = carParts.find(p => p.id === partId);
              if (part) {
                setSelectedPart(part.name);
              }
            }}
          />

          {/* QA Records Section */}
          <div className="mt-6">
            <div className="bg-white rounded-lg shadow-md p-4 md:p-6">
              <div className="flex justify-between items-center mb-4">
                <div>
                  <h2 className="text-lg md:text-xl font-bold text-gray-900">Quality Assurance Records</h2>
                  <p className="text-xs md:text-sm text-gray-600">QA submissions and inspections for this work order</p>
                </div>
              </div>
              
              <QARecordsList 
                workOrderId={workOrder.workOrderNumber}
                limit={5}
                showWorkOrderColumn={false}
              />
            </div>
          </div>
        </div>
      )}

      {/* QA Modal */}
      {showQAModal && workOrder && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50 p-4">
          <div className="bg-white p-4 md:p-8 rounded-lg shadow-2xl w-full max-w-full md:max-w-4xl max-h-[85vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h2 className="text-lg md:text-xl font-bold text-gray-900">
                  QA - {workOrder.workOrderNumber}
                </h2>
                <div className="mt-1 text-xs md:text-sm text-gray-600">
                  <p>Customer: {getCustomerInfo(workOrder).name}</p>
                  <p>Vehicle: {getVehicleInfo(workOrder).display()}</p>
                </div>
              </div>
              <button
                onClick={handleQACancel}
                className="text-gray-500 hover:text-gray-700 text-2xl"
              >
                ✕
              </button>
            </div>

            <QAForm
              workOrderId={workOrder._id}
              workOrderNumber={workOrder.workOrderNumber}
              onSuccess={handleQASuccess}
              onCancel={handleQACancel}
            />
          </div>
        </div>
      )}

      {/* Case Modal */}
      {workOrder && (
        <WorkOrderCaseModal
          isOpen={showCaseModal}
          onClose={() => setShowCaseModal(false)}
          onCaseCreated={handleCaseCreated}
          workOrderId={workOrder._id}
          workOrderNumber={workOrder.workOrderNumber || workOrder.number || workOrder._id}
        />
      )}
    </div>
  );
}