import React from 'react';

// Workflow step structure
interface WorkflowStep {
  id: number;
  name: string;
  completed: boolean;
  inProgress: boolean;
}

// Props for workflow progress
interface WorkflowProgressProps {
  steps: WorkflowStep[];     // Array of workflow steps
}

/**
 * WorkflowProgress Component
 * 
 * Shows visual progress through workflow steps.
 * - Displays numbered circles for each step
 * - Green = completed, Blue = in progress, Gray = not started
 * - Connected by progress lines
 */
const WorkflowProgress: React.FC<WorkflowProgressProps> = ({ steps }) => {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
      <h2 className="text-xl font-semibold text-gray-900 mb-6">Workflow Progress</h2>
      
      {/* Steps display */}
      <div className="flex items-center justify-center space-x-8">
        {steps.map((step, index) => (
          <div key={step.id} className="flex items-center">
            <div className="flex flex-col items-center">
              {/* Step circle with number */}
              <div className={`w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-lg ${
                step.completed ? 'bg-green-500' : 
                step.inProgress ? 'bg-blue-500' : 'bg-gray-300'
              }`}>
                {step.id}
              </div>
              
              {/* Step name */}
              <span className="mt-2 text-sm font-medium text-gray-700">{step.name}</span>
            </div>
            
            {/* Connecting line (not after last step) */}
            {index < steps.length - 1 && (
              <div className={`w-16 h-1 mx-4 ${step.completed ? 'bg-green-500' : 'bg-gray-300'}`} />
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default WorkflowProgress;