import React from 'react';

// Props for current stage info
interface CurrentStageInfoProps {
  currentStage: string;          // Current stage name
  stageStatus: string;           // Stage status
  technicianName: string;        // Assigned technician name
  estimatedHours: number;        // Estimated hours
  actualHours: number;           // Actual hours spent
  startTime: string | null;      // When stage started
  isPartCancelled: boolean;      // Whether part is cancelled
}

/**
 * CurrentStageInfo Component
 * 
 * Shows detailed information about the current stage.
 * - Stage name and status
 * - Technician assignment
 * - Time tracking (estimated vs actual)
 * - Special display for cancelled parts
 */
const CurrentStageInfo: React.FC<CurrentStageInfoProps> = ({
  currentStage,
  stageStatus,
  technicianName,
  estimatedHours,
  actualHours,
  startTime,
  isPartCancelled
}) => {
  // Format hours to readable string (e.g., "2h 30m")
  const formatActualHours = (hours: number): string => {
    if (hours < 1) {
      const minutes = Math.round(hours * 60);
      return `${minutes}m`;
    } else {
      const wholeHours = Math.floor(hours);
      const minutes = Math.round((hours - wholeHours) * 60);
      if (minutes === 0) {
        return `${wholeHours}h`;
      }
      return `${wholeHours}h ${minutes}m`;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      {isPartCancelled ? (
        // Cancelled part display
        <div className="text-center py-8">
          <div className="text-red-600 mb-4">
            <svg className="w-16 h-16 mx-auto" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
            </svg>
          </div>
          <h2 className="text-xl font-semibold text-red-600 mb-2">Part Cancelled</h2>
          <p className="text-gray-600">This part has been cancelled and will not be completed.</p>
        </div>
      ) : (
        // Normal stage info display
        <>
          <h2 className="text-xl font-semibold text-gray-900 mb-4">
            Current Stage: {currentStage}
          </h2>
          <div className="space-y-4">
            {/* Status */}
            <div className="flex justify-between">
              <span className="text-gray-600">Status:</span>
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                stageStatus === 'completed' ? 'bg-green-100 text-green-800' :
                stageStatus === 'in_progress' ? 'bg-blue-100 text-blue-800' :
                stageStatus === 'paused' ? 'bg-yellow-100 text-yellow-800' :
                'bg-gray-100 text-gray-800'
              }`}>
                {stageStatus.replace('_', ' ').toUpperCase()}
              </span>
            </div>
            
            {/* Technician */}
            <div className="flex justify-between">
              <span className="text-gray-600">Technician:</span>
              <span className="text-gray-900 font-medium">{technicianName}</span>
            </div>
            
            {/* Estimated hours */}
            <div className="flex justify-between">
              <span className="text-gray-600">Estimated Hours:</span>
              <span className="text-gray-900 font-medium">{estimatedHours}h</span>
            </div>
            
            {/* Actual hours */}
            <div className="flex justify-between">
              <span className="text-gray-600">Actual Hours:</span>
              <span className="text-gray-900 font-medium">{formatActualHours(actualHours)}</span>
            </div>
            
            {/* Start time */}
            {startTime && (
              <div className="flex justify-between">
                <span className="text-gray-600">Started:</span>
                <span className="text-gray-900 font-medium">
                  {new Date(startTime).toLocaleString()}
                </span>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
};

export default CurrentStageInfo;