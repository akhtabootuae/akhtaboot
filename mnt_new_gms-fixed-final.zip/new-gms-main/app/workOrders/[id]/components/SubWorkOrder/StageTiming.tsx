import React, { useState } from 'react';
import { ElapsedTime, CountdownTimer } from '../Common';
import api from '@/services/api';

// Props for stage timing
interface StageTimingProps {
  startTime: string | null;      // When stage started
  pauseTime: string | null;      // When stage was paused (if applicable)
  estimatedHours: number;        // Estimated hours for the stage
  status: string;                // Current stage status
  workOrderId: string;           // Work order ID
  partIndex: number;             // Part index
  stageIndex: number;            // Stage index
  pausedDuration?: number;       // Total paused duration in seconds
  supervisorId?: string;         // Supervisor ID for notifications
  onTimeUpdated?: (newEstimatedHours: number) => void; // Callback when time is updated
}

/**
 * StageTiming Component
 * 
 * Shows timing information for current stage.
 * - Elapsed time since start
 * - Remaining time countdown
 * - Plus button to add more time
 * - Side by side display
 */
const StageTiming: React.FC<StageTimingProps> = ({
  startTime,
  pauseTime,
  estimatedHours,
  status,
  workOrderId,
  partIndex,
  stageIndex,
  pausedDuration = 0,
  supervisorId,
  onTimeUpdated
}) => {
  const [showAddTimeModal, setShowAddTimeModal] = useState(false);
  const [additionalHours, setAdditionalHours] = useState(1);
  const [additionalMinutes, setAdditionalMinutes] = useState(0);
  const [isUpdating, setIsUpdating] = useState(false);

  // Handle adding additional time
  const handleAddTime = async () => {
    try {
      setIsUpdating(true);
      
      // Calculate additional time in hours (decimal)
      const additionalTimeInHours = additionalHours + (additionalMinutes / 60);
      const newEstimatedHours = estimatedHours + additionalTimeInHours;
      
      // Update the estimated time via API using the correct endpoint
      await api.put(`/api/work-orders/${workOrderId}/parts/${partIndex}/stages/${stageIndex}`, {
        estimatedHours: newEstimatedHours
      });
      
      // Notify parent component
      if (onTimeUpdated) {
        onTimeUpdated(newEstimatedHours);
      }
      
      // Close modal and reset form
      setShowAddTimeModal(false);
      setAdditionalHours(1);
      setAdditionalMinutes(0);
      
    } catch (error) {
      console.error('Error adding time:', error);
      console.error('Failed to add time. Please try again.');
    } finally {
      setIsUpdating(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold text-gray-900">Stage Timing</h2>
        
        {/* Plus button to add more time */}
        {status === 'in_progress' && (
          <button
            onClick={() => setShowAddTimeModal(true)}
            className="flex items-center justify-center w-8 h-8 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition-colors"
            title="Add more time to this stage"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
          </button>
        )}
      </div>
      
      {/* Two column grid for timers */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Elapsed time */}
        <div className="text-center">
          <p className="text-sm text-blue-600 font-medium mb-2">Elapsed Time:</p>
          <div className="text-3xl font-bold text-blue-600">
            <ElapsedTime 
              startTime={startTime} 
              endTime={null}
              pausedDuration={pausedDuration}
            />
          </div>
        </div>
        
        {/* Remaining time */}
        <div className="text-center">
          <p className="text-sm text-green-600 font-medium mb-2">Remaining Time:</p>
          <div className="text-3xl font-bold text-green-600">
            <CountdownTimer 
              startTime={startTime} 
              estimatedHours={estimatedHours} 
              status={status}
              workOrderId={workOrderId}
              pausedDuration={pausedDuration}
              supervisorId={supervisorId}
            />
          </div>
        </div>
      </div>

      {/* Add Time Modal */}
      {showAddTimeModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold mb-4">Add More Time</h3>
            
            <p className="text-sm text-gray-600 mb-4">
              Add additional time to extend the estimated duration for this stage.
            </p>
            
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Additional Time
              </label>
              
              <div className="flex gap-2">
                {/* Hours input */}
                <div className="flex-1">
                  <div className="relative">
                    <input
                      type="number"
                      min="0"
                      max="12"
                      value={additionalHours}
                      onChange={(e) => setAdditionalHours(parseInt(e.target.value) || 0)}
                      className="block w-full rounded-md border border-gray-300 p-2 pr-12 focus:border-blue-500 focus:ring-blue-500"
                      placeholder="0"
                    />
                    <span className="absolute right-2 top-2 text-sm text-gray-500">hrs</span>
                  </div>
                </div>
                
                {/* Minutes input */}
                <div className="flex-1">
                  <div className="relative">
                    <input
                      type="number"
                      min="0"
                      max="59"
                      value={additionalMinutes}
                      onChange={(e) => setAdditionalMinutes(parseInt(e.target.value) || 0)}
                      className="block w-full rounded-md border border-gray-300 p-2 pr-12 focus:border-blue-500 focus:ring-blue-500"
                      placeholder="0"
                    />
                    <span className="absolute right-2 top-2 text-sm text-gray-500">min</span>
                  </div>
                </div>
              </div>
              
              <p className="mt-2 text-xs text-gray-500">
                Current estimate: {Math.floor(estimatedHours)}h {Math.round((estimatedHours % 1) * 60)}m
                {additionalHours > 0 || additionalMinutes > 0 ? (
                  <span className="text-blue-600">
                    {' → '}New estimate: {Math.floor(estimatedHours + additionalHours + (additionalMinutes / 60))}h {Math.round(((estimatedHours + additionalHours + (additionalMinutes / 60)) % 1) * 60)}m
                  </span>
                ) : null}
              </p>
            </div>
            
            {/* Action buttons */}
            <div className="flex space-x-3">
              <button
                onClick={() => setShowAddTimeModal(false)}
                disabled={isUpdating}
                className="flex-1 px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300 disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                onClick={handleAddTime}
                disabled={isUpdating || (additionalHours === 0 && additionalMinutes === 0)}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed"
              >
                {isUpdating ? 'Adding...' : 'Add Time'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default StageTiming;