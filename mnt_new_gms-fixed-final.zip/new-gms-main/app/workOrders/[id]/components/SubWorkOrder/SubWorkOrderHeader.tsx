import React from 'react';
import { Plus } from 'lucide-react';

// Props for sub work order header
interface SubWorkOrderHeaderProps {
  partName: string;          // Display name of the part
  onBack: () => void;        // Callback to go back to main view
  onCreateCase: () => void;  // Callback to create a case
}

/**
 * SubWorkOrderHeader Component
 * 
 * Header for sub work order detail page.
 * - Shows part name
 * - Back button to return to main work order
 */
const SubWorkOrderHeader: React.FC<SubWorkOrderHeaderProps> = ({
  partName,
  onBack,
  onCreateCase
}) => {
  return (
    <div className="mb-4 md:mb-8">
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-3">
        {/* Title */}
        <div className="flex-1">
          <h1 className="text-xl md:text-3xl font-bold text-gray-900 mb-1 md:mb-2">
            Sub Work Order: {partName}
          </h1>
        </div>
        
        {/* Action buttons */}
        <div className="flex items-center gap-2 self-start">
          <button 
            onClick={onCreateCase}
            className="px-3 py-2 md:px-4 md:py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm md:text-base flex items-center gap-1 md:gap-2"
            title="Create a case linked to this work order"
          >
            <Plus className="w-3 h-3 md:w-4 md:h-4" />
            <span className="hidden sm:inline">Create</span> Case
          </button>
          
          <button 
            onClick={onBack}
            className="px-3 py-2 md:px-4 md:py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors text-sm md:text-base"
          >
            ← Back to Overview
          </button>
        </div>
      </div>
    </div>
  );
};

export default SubWorkOrderHeader;