import React from 'react';

// Props for part summary
interface PartSummaryProps {
  overallProgress: number;       // Overall progress percentage
  totalEstimatedHours: number;   // Total estimated hours
  totalActualHours: number;      // Total actual hours
  assignedTechnician: string;    // Assigned technician name
  qaStatus: 'Passed' | 'Pending'; // QA status
}

/**
 * PartSummary Component
 * 
 * Shows overall summary for the entire part.
 * - Overall progress across all stages
 * - Total time estimates vs actuals
 * - Current technician assignment
 * - QA status
 */
const PartSummary: React.FC<PartSummaryProps> = ({
  overallProgress,
  totalEstimatedHours,
  totalActualHours,
  assignedTechnician,
  qaStatus
}) => {
  // Format hours to readable string
  const formatActualHours = (hours: number): string => {
    if (hours < 1) {
      const minutes = Math.round(hours * 60);
      return `${minutes}m`;
    } else {
      const wholeHours = Math.floor(hours);
      const minutes = Math.round((hours - wholeHours) * 60);
      if (minutes === 0) {
        return `${wholeHours}h`;
      }
      return `${wholeHours}h ${minutes}m`;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-xl font-semibold text-gray-900 mb-4">Part Summary</h2>
      <div className="space-y-4">
        {/* Overall progress */}
        <div className="flex justify-between">
          <span className="text-gray-600">Overall Progress:</span>
          <span className="text-gray-900 font-medium">{overallProgress}%</span>
        </div>
        
        {/* Total estimated hours */}
        <div className="flex justify-between">
          <span className="text-gray-600">Total Estimated:</span>
          <span className="text-gray-900 font-medium">{totalEstimatedHours}h</span>
        </div>
        
        {/* Total actual hours */}
        <div className="flex justify-between">
          <span className="text-gray-600">Total Actual:</span>
          <span className="text-gray-900 font-medium">{formatActualHours(totalActualHours)}</span>
        </div>
        
        {/* Assigned technician */}
        <div className="flex justify-between">
          <span className="text-gray-600">Assigned Technician:</span>
          <span className="text-gray-900 font-medium">{assignedTechnician}</span>
        </div>
        
        {/* QA status with color coding */}
        <div className="flex justify-between">
          <span className="text-gray-600">QA Status:</span>
          <span className={`px-2 py-1 rounded text-sm ${
            qaStatus === 'Passed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
          }`}>
            {qaStatus}
          </span>
        </div>
      </div>
    </div>
  );
};

export default PartSummary;