import React from 'react';
import { TechnicianSelector } from '../Common';

// Technician interface
interface Technician {
  _id: string;
  name: string;
  email: string;
  phone: string;
  role: string;
  speciality?: string;
}

// Props for stage controls
interface StageControlsProps {
  isStarted: boolean;                    // Whether stage has started
  showStartForm: boolean;                // Whether to show start form
  stageStatus: string;                   // Current stage status
  currentStage: string;                  // Current stage name
  selectedTechnician: string;            // Selected technician ID
  isPartCancelled: boolean;              // Whether part is cancelled
  technicians: Technician[];             // Available technicians
  workOrderId: string;                   // Work order ID
  hasIssue?: boolean;                    // Whether stage has reported issues
  needsRedo?: boolean;                   // Whether stage needs to be redone
  estimatedHours?: number;               // Estimated hours for the stage
  errorReportsCount?: number;            // Number of error reports for this work order
  allStagesCompleted?: boolean;          // Whether all stages in the work order are completed
  onShowStartForm: (show: boolean) => void;      // Show/hide start form
  onStartStage: () => void;              // Start stage handler
  onPauseStage: () => void;              // Pause stage handler
  onResumeStage: () => void;             // Resume stage handler
  onCompleteStage: () => void;           // Complete stage handler
  onShowChangeTechForm: (show: boolean) => void; // Show change tech form
  onShowCancelModal: (show: boolean) => void;    // Show cancel modal
  onShowErrorReportModal: (show: boolean) => void; // Show error report modal
  onShowErrorReportsModal: (show: boolean) => void; // Show error reports list modal
  onTechnicianChange: (techId: string, hours?: number) => void;  // Technician change handler with hours
}

/**
 * StageControls Component
 * 
 * Main control panel for stage operations.
 * - Start/pause/resume/complete buttons
 * - Technician assignment form
 * - Quality check and cancel options
 * - Dynamic button display based on stage status
 */
const StageControls: React.FC<StageControlsProps> = ({
  isStarted,
  showStartForm,
  stageStatus,
  currentStage,
  selectedTechnician,
  isPartCancelled,
  technicians,
  workOrderId,
  hasIssue = false,
  needsRedo = false,
  estimatedHours = 1,
  errorReportsCount = 0,
  allStagesCompleted = false,
  onShowStartForm,
  onStartStage,
  onPauseStage,
  onResumeStage,
  onCompleteStage,
  onShowChangeTechForm,
  onShowCancelModal,
  onShowErrorReportModal,
  onShowErrorReportsModal,
  onTechnicianChange
}) => {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold text-gray-900">Stage Controls</h2>
        
        {/* Error indicators and View Issues button */}
        <div className="flex gap-2 items-center">
          {hasIssue && (
            <span className="px-3 py-1 bg-red-100 text-red-800 text-sm font-medium rounded-full">
              ⚠️ Has Issues
            </span>
          )}
          {needsRedo && (
            <span className="px-3 py-1 bg-orange-100 text-orange-800 text-sm font-medium rounded-full">
              🔄 Needs Redo
            </span>
          )}
          
          {/* View Issues Button */}
          <button 
            onClick={() => onShowErrorReportsModal(true)}
            className="relative px-3 py-1 bg-indigo-600 text-white text-sm font-medium rounded-full hover:bg-indigo-700 flex items-center gap-1"
          >
            <span>🔍</span>
            <span>View Issues</span>
            {errorReportsCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                {errorReportsCount}
              </span>
            )}
          </button>
        </div>
      </div>
      
      {/* Not started - show start button */}
      {!isStarted && !showStartForm && (
        <div className="flex gap-3">
          <button 
            onClick={() => onShowStartForm(true)}
            className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 font-medium"
          >
            Start Stage
          </button>
          {!isPartCancelled && (
            <button 
              onClick={() => onShowCancelModal(true)}
              className="px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 font-medium"
            >
              Cancel Part
            </button>
          )}
        </div>
      )}

      {/* Start form */}
      {showStartForm && (
        <div className="bg-gray-50 p-4 rounded-lg">
          <h3 className="font-medium mb-4">
            Start {currentStage.charAt(0).toUpperCase() + currentStage.slice(1)} Stage
          </h3>
          
          {/* Technician selector */}
          <TechnicianSelector
            value={selectedTechnician}
            onChange={(value, hours) => onTechnicianChange(value, hours)}
            workOrderId={parseInt(workOrderId) || 1}
            stageId={1}
            stageName={currentStage}
            onAssignmentComplete={() => {}}
          />
          
          {/* Form buttons */}
          <div className="flex space-x-3 mt-4">
            <button 
              onClick={onStartStage}
              className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
            >
              Start
            </button>
            <button 
              onClick={() => onShowStartForm(false)}
              className="px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* In progress controls */}
      {isStarted && stageStatus === 'in_progress' && (
        <div className="flex flex-wrap gap-3">
          <button 
            onClick={onPauseStage}
            className="px-6 py-3 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700 font-medium"
          >
            Pause Stage
          </button>
          <button 
            onClick={onCompleteStage}
            className="px-6 py-3 rounded-lg font-medium bg-green-600 text-white hover:bg-green-700"
          >
            Complete Stage
          </button>
          <button 
            onClick={() => onShowChangeTechForm(true)}
            className="px-6 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 font-medium"
          >
            Change Technician
          </button>
          <button 
            onClick={() => onShowErrorReportModal(true)}
            className="px-6 py-3 bg-orange-600 text-white rounded-lg hover:bg-orange-700 font-medium"
          >
            Report Issue
          </button>
          {!isPartCancelled && (
            <button 
              onClick={() => onShowCancelModal(true)}
              className="px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 font-medium"
            >
              Cancel Part
            </button>
          )}
        </div>
      )}

      {/* Paused controls */}
      {stageStatus === 'paused' && (
        <div className="flex flex-wrap gap-3">
          <button 
            onClick={onResumeStage}
            className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium"
          >
            Resume Stage
          </button>
          <button 
            onClick={onCompleteStage}
            className="px-6 py-3 rounded-lg font-medium bg-green-600 text-white hover:bg-green-700"
          >
            Complete Stage
          </button>
          <button 
            onClick={() => onShowChangeTechForm(true)}
            className="px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 font-medium"
          >
            Change Technician
          </button>
          <button 
            onClick={() => onShowErrorReportModal(true)}
            className="px-6 py-3 bg-orange-600 text-white rounded-lg hover:bg-orange-700 font-medium"
          >
            Report Issue
          </button>
          {!isPartCancelled && (
            <button 
              onClick={() => onShowCancelModal(true)}
              className="px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 font-medium"
            >
              Cancel Part
            </button>
          )}
        </div>
      )}

      {/* Quality Check - Only show when all stages are completed */}
      {allStagesCompleted && !isPartCancelled && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <h3 className="text-lg font-semibold text-green-800 mb-3">Work Order Part Complete</h3>
          <p className="text-green-700 mb-2">All stages for this part have been completed.</p>
          <p className="text-sm text-green-600">Quality Assurance is now available from the main Work Orders page.</p>
        </div>
      )}
    </div>
  );
};

export default StageControls;