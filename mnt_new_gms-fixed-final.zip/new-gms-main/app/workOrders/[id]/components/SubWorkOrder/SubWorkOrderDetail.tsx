import React, { useState, useEffect } from 'react';
import api, { errorReportingApi, dataApi } from '../../../../../services/api';
import { FlexibleWorkOrder, getSupervisorInfo } from '../../../../../lib/workOrderHelpers';
import { useAuth } from '../../../../context/AuthContext';

// Import all sub-components
import SubWorkOrderHeader from './SubWorkOrderHeader';
import WorkflowProgress from './WorkflowProgress';
import StageTiming from './StageTiming';
import StageControls from './StageControls';
import CurrentStageInfo from './CurrentStageInfo';
import PartSummary from './PartSummary';

// Import modals
import { CancelPartModal, ChangeTechnicianModal, ErrorReportModal, ErrorReportsModal, ErrorReportDetailModal } from '../Modals';
import { ErrorReportData } from '../Modals/ErrorReportModal';
import WorkOrderCaseModal from '../WorkOrderCaseModal';

// Props for sub work order detail
interface SubWorkOrderDetailProps {
  partName: string;                // Part being worked on
  workOrder: FlexibleWorkOrder;   // Main work order data
  onBack: () => void;             // Go back handler
  onUpdateWorkOrder?: () => void; // Refresh work order data
}

// Technician interface
interface Technician {
  _id: string;
  name: string;
  email: string;
  phone: string;
  role: string;
  speciality?: string;
}

/**
 * SubWorkOrderDetail Component
 * 
 * Main component for sub work order detail view.
 * Manages all state and coordinates between sub-components.
 * - Workflow management
 * - Stage timing and controls
 * - Technician assignment
 * - Quality assurance
 * - Part cancellation
 */
const SubWorkOrderDetail: React.FC<SubWorkOrderDetailProps> = ({ 
  partName, 
  workOrder, 
  onBack,
  onUpdateWorkOrder 
}) => {
  // Get current user for error reporting
  const { user } = useAuth();
  
  // Helper function to extract supervisor ID from work order
  const getSupervisorId = (workOrder: FlexibleWorkOrder): string | undefined => {
    // Check if the current part has an assigned technician (supervisor)
    if (workOrder.parts && workOrder.parts[partIndex]) {
      const part = workOrder.parts[partIndex];
      if (part.assignedTo) {
        return typeof part.assignedTo === 'string' ? part.assignedTo : part.assignedTo._id;
      }
    }
    
    // Check work order level supervisor/assignedTo fields
    const supervisorInfo = getSupervisorInfo(workOrder);
    
    // If it's an ObjectId string, return it
    if (supervisorInfo && /^[a-fA-F0-9]{24}$/.test(supervisorInfo)) {
      return supervisorInfo;
    }
    
    // Check other fields
    if (workOrder.supervisor && typeof workOrder.supervisor === 'object' && workOrder.supervisor._id) {
      return workOrder.supervisor._id;
    }
    
    if (workOrder.assignedTo && typeof workOrder.assignedTo === 'object' && workOrder.assignedTo._id) {
      return workOrder.assignedTo._id;
    }
    
    if (workOrder.assigned_technician) {
      return typeof workOrder.assigned_technician === 'string' 
        ? workOrder.assigned_technician 
        : workOrder.assigned_technician._id;
    }
    
    return undefined;
  };
  
  // Stage and workflow state
  const [currentStage, setCurrentStage] = useState('remove');
  const [stageStatus, setStageStatus] = useState('not_started');
  const [isStarted, setIsStarted] = useState(false);
  const [startTime, setStartTime] = useState<string | null>(null);
  const [pauseTime, setPauseTime] = useState<string | null>(null);
  const [pausedDuration, setPausedDuration] = useState(0); // Track total paused time in seconds
  const [estimatedHours, setEstimatedHours] = useState(1); // Store estimated hours
  const [partIndex, setPartIndex] = useState(0); // Store the actual part index
  const [stageIds, setStageIds] = useState<string[]>([]); // Store actual stage IDs from DB
  
  // Technician state
  const [selectedTechnician, setSelectedTechnician] = useState('');
  const [selectedTechnicianName, setSelectedTechnicianName] = useState('');
  const [technicians, setTechnicians] = useState<Technician[]>([]);
  const [allStaffMembers, setAllStaffMembers] = useState<Technician[]>([]);
  
  // Stage mapping from database
  const [stageMapping, setStageMapping] = useState<Map<string, {name: string, order: number}>>(new Map());
  const [allStages, setAllStages] = useState<any[]>([]);
  
  // Form visibility state
  const [showStartForm, setShowStartForm] = useState(false);
  const [showChangeTechForm, setShowChangeTechForm] = useState(false);
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [showErrorReportModal, setShowErrorReportModal] = useState(false);
  const [showErrorReportsModal, setShowErrorReportsModal] = useState(false);
  const [showErrorReportDetailModal, setShowErrorReportDetailModal] = useState(false);
  const [showCaseModal, setShowCaseModal] = useState(false);

  // Error reporting state
  const [stageHasIssues, setStageHasIssues] = useState(false);
  const [stageNeedsRedo, setStageNeedsRedo] = useState(false);
  const [errorReportType, setErrorReportType] = useState<'forward' | 'revert'>('revert');
  const [previousStages, setPreviousStages] = useState([
    { stageId: 'remove', status: 'completed', assignedTo: '', name: 'Remove' },
    { stageId: 'repair', status: 'not_started', assignedTo: '', name: 'Repair' },
    { stageId: 'paint', status: 'not_started', assignedTo: '', name: 'Paint' }
  ]);
  
  
  // Cancellation state
  const [cancelReason, setCancelReason] = useState('');
  const [cancelImage, setCancelImage] = useState<File | null>(null);
  const [isPartCancelled, setIsPartCancelled] = useState(false);

  // Error reports state
  const [errorReports, setErrorReports] = useState<any[]>([]);
  const [selectedErrorReport, setSelectedErrorReport] = useState<any | null>(null);
  const [errorReportsLoading, setErrorReportsLoading] = useState(false);

  // Helper function to get part display name
  const getPartDisplayName = (part: string) => {
    const partNames: Record<string, string> = {
      'front-bumper': 'Front Bumper',
      'windshield': 'Windshield',
      'left-window': 'Left Window', 
      'right-window': 'Right Window',
      'left-door': 'Left Door',
      'right-door': 'Right Door',
      'front-left-wheel': 'Front Left Wheel',
      'front-right-wheel': 'Front Right Wheel',
      'rear-bumper': 'Rear Bumper',
      'headlight': 'Headlight',
      'engine': 'Engine',
      'left-mirror': 'Left Mirror',
      'right-mirror': 'Right Mirror'
    };
    return partNames[part] || part;
  };

  // Helper function to determine work order status based on stage progress
  const determineWorkOrderStatus = (workOrder: FlexibleWorkOrder): string => {
    if (!workOrder.parts || workOrder.parts.length === 0) {
      return 'open'; // No parts means work hasn't started
    }

    let hasAnyStartedStage = false;
    let allStagesCompleted = true;

    // Check all parts and their stages
    for (const part of workOrder.parts) {
      if (!part.stages || part.stages.length === 0) {
        // Part has no stages - consider it not started
        allStagesCompleted = false;
        continue;
      }

      for (const stage of part.stages) {
        if (stage.status === 'in_progress' || stage.status === 'paused' || stage.status === 'completed') {
          hasAnyStartedStage = true;
        }
        
        if (stage.status !== 'completed') {
          allStagesCompleted = false;
        }
      }
    }

    // Determine status based on stage progress
    if (allStagesCompleted && hasAnyStartedStage) {
      return 'qa_review'; // All stages completed - ready for QA
    } else if (hasAnyStartedStage) {
      return 'in_progress'; // At least one stage started
    } else {
      return 'open'; // No stages started
    }
  };

  // Helper function to check if all stages across all parts are completed
  const areAllStagesCompleted = (workOrder: FlexibleWorkOrder): boolean => {
    if (!workOrder.parts || workOrder.parts.length === 0) {
      return false; // No parts means work hasn't started
    }

    // Check all parts and their stages
    for (const part of workOrder.parts) {
      if (!part.stages || part.stages.length === 0) {
        return false; // Part has no stages
      }

      for (const stage of part.stages) {
        if (stage.status !== 'completed') {
          return false; // Found a non-completed stage
        }
      }
    }

    return true; // All stages are completed
  };

  // Fetch all stages data to build mapping
  useEffect(() => {
    const fetchStages = async () => {
      try {
        console.log('Fetching stages from API...');
        // Get all stages from the database
        const response = await dataApi.getStages();
        console.log('Stages API response:', response);
        
        if (response && response.data) {
          console.log('Stage data found:', response.data);
          setAllStages(response.data);
          
          // Build mapping from stageId to stage details
          const mapping = new Map();
          response.data.forEach((stage: any) => {
            mapping.set(stage._id, {
              name: stage.name,
              order: stage.order
            });
          });
          console.log('Built stage mapping:', mapping);
          setStageMapping(mapping);
        } else {
          console.error('No stage data in response:', response);
          console.error('Failed to load stage information. Please refresh the page.');
        }
      } catch (error) {
        console.error('Error fetching stages:', error);
        console.error('Failed to load stage information. Please check your connection and try again.');
      }
    };
    
    fetchStages();
  }, []);

  // Initialize component state from work order data
  useEffect(() => {
    console.log('=== SubWorkOrderDetail Initialization ===');
    console.log('Received partName:', partName);
    console.log('Stage mapping size:', stageMapping.size);
    
    if (!workOrder.parts || workOrder.parts.length === 0) {
      console.error('No parts in work order');
      return;
    }

    // Wait for stage mapping to be loaded before processing
    if (stageMapping.size === 0) {
      console.log('Stage mapping not ready yet, skipping initialization');
      return;
    }

    // Find the part index that matches our part name
    // Try both the display name and the raw part name
    const foundPartIndex = workOrder.parts.findIndex((part: any) => {
      const matches = part.partName === partName || 
                     part.partName === getPartDisplayName(partName) ||
                     part.name === partName;
      console.log(`Checking part: ${part.partName || part.name}, matches: ${matches}`);
      return matches;
    });
    
    if (foundPartIndex === -1) {
      console.error('Part not found in work order:', partName);
      console.error('Available parts:', workOrder.parts.map((p: any) => p.partName || p.name));
      return;
    }

    console.log('Setting partIndex to:', foundPartIndex);
    setPartIndex(foundPartIndex);
    const part = workOrder.parts[foundPartIndex];
    
    if (part.stages && part.stages.length > 0) {
      // Extract stage IDs
      const ids = part.stages.map((stage: any) => stage.stageId);
      setStageIds(ids);

      // Find current stage (first non-completed stage or last stage)
      let currentStageIdx = part.stages.findIndex((stage: any) => 
        stage.status !== 'completed'
      );
      
      if (currentStageIdx === -1) {
        // All stages completed, show last stage
        currentStageIdx = part.stages.length - 1;
      }

      const currentStageData = part.stages[currentStageIdx];
      
      // Map stage index to actual stage name from database
      let currentStageName = 'Unknown Stage';
      
      if (currentStageData && currentStageData.stageId && stageMapping.has(currentStageData.stageId)) {
        const stageInfo = stageMapping.get(currentStageData.stageId);
        currentStageName = stageInfo?.name || 'Unknown Stage';
      }
      
      // Set current stage name (keep original case for display)
      setCurrentStage(currentStageName);
      
      // Set stage status
      setStageStatus(currentStageData.status || 'pending');
      
      // If stage is in progress or paused, load timing data
      if (currentStageData.status === 'in_progress' || currentStageData.status === 'paused') {
        setIsStarted(true);
        
        // Find the start log entry
        const startLog = currentStageData.logs?.find((log: any) => log.action === 'start');
        if (startLog) {
          setStartTime(startLog.timestamp);
        }
        
        // If paused, find the last pause log
        if (currentStageData.status === 'paused') {
          const pauseLogs = currentStageData.logs?.filter((log: any) => log.action === 'pause') || [];
          if (pauseLogs.length > 0) {
            setPauseTime(pauseLogs[pauseLogs.length - 1].timestamp);
          }
        }
        
        // Calculate total paused duration
        calculatePausedDuration(currentStageData.logs || []);
      }
      
      // Set technician if assigned
      if (currentStageData.assignedTo) {
        setSelectedTechnician(currentStageData.assignedTo);
      }
      
      // Set estimated hours for current stage
      if (currentStageData.estimatedHours) {
        setEstimatedHours(currentStageData.estimatedHours);
      } else {
        // Default to 1 hour if not set
        setEstimatedHours(1);
      }
      
      // Set error reporting flags
      setStageHasIssues(currentStageData.hasIssue || false);
      setStageNeedsRedo(currentStageData.needsRedo || false);
      
      // Update previous stages data with actual stage names
      const updatedPreviousStages = part.stages.map((stage: any, idx: number) => {
        let stageDisplayName = 'Unknown Stage';
        
        if (stage.stageId && stageMapping.has(stage.stageId)) {
          const stageInfo = stageMapping.get(stage.stageId);
          stageDisplayName = stageInfo?.name || 'Unknown Stage';
        }
        
        return {
          stageId: stage.stageId, // Keep the actual stageId for reference
          status: stage.status || 'pending',
          assignedTo: stage.assignedTo || '',
          name: stageDisplayName,
          order: stageMapping.get(stage.stageId)?.order || idx + 1
        };
      });
      setPreviousStages(updatedPreviousStages);
    }
  }, [workOrder, partName, stageMapping]);

  // Calculate total paused duration from logs
  const calculatePausedDuration = (logs: any[]) => {
    let totalPaused = 0;
    let lastPauseTime: Date | null = null;

    logs.forEach(log => {
      if (log.action === 'pause') {
        lastPauseTime = new Date(log.timestamp);
      } else if (log.action === 'resume' && lastPauseTime) {
        const resumeTime = new Date(log.timestamp);
        totalPaused += (resumeTime.getTime() - lastPauseTime.getTime()) / 1000;
        lastPauseTime = null;
      }
    });

    // If still paused, add time from last pause to now
    if (lastPauseTime && pauseTime) {
      const now = new Date();
      totalPaused += (now.getTime() - lastPauseTime.getTime()) / 1000;
    }

    setPausedDuration(totalPaused);
  };
  
  // Check if part is cancelled on mount
  useEffect(() => {
    const cancelledParts = workOrder.cancelledParts || [];
    const cancelledPartNames = cancelledParts.map((cp: any) => cp.partName);
    const currentPartName = getPartDisplayName(partName);
    setIsPartCancelled(cancelledPartNames.includes(currentPartName));
  }, [workOrder, partName]);

  // Fetch technicians and all staff on mount
  useEffect(() => {
    const fetchTechnicians = async () => {
      try {
        const response = await api.get('/api/users/technicians');
        setTechnicians(response || []);
      } catch (error) {
        console.error("Error fetching technicians:", error);
      }
    };
    
    const fetchAllStaff = async () => {
      try {
        // Fetch all users (not just technicians) for the "Reported by" field
        const response = await api.get('/api/users');
        setAllStaffMembers(response || []);
      } catch (error) {
        console.error("Error fetching all staff:", error);
      }
    };
    
    fetchTechnicians();
    fetchAllStaff();
  }, []);

  // Get technician name by ID
  const getTechnicianNameById = (techId: string): string => {
    if (!techId) return 'Unassigned';
    const tech = technicians.find(t => t._id === techId);
    return tech ? tech.name : techId;
  };

  // Get current stage index with stage order enforcement
  const getCurrentStageIndex = () => {
    // Use the actual current stage index from the part data
    if (!workOrder.parts || !workOrder.parts[partIndex]) return 0;
    const part = workOrder.parts[partIndex];
    
    // Find the index of the current stage based on status
    const currentIdx = part.stages?.findIndex((stage: any) => 
      stage.status === 'in_progress' || stage.status === 'paused'
    );
    
    if (currentIdx !== -1) return currentIdx;
    
    // Enforce stage order: find the first pending stage that has all previous stages completed
    if (part.stages) {
      for (let i = 0; i < part.stages.length; i++) {
        const stage = part.stages[i];
        
        // If this stage is pending, check if all previous stages are completed
        if (stage.status === 'pending') {
          // Check if all previous stages (0 to i-1) are completed
          let canStart = true;
          for (let j = 0; j < i; j++) {
            if (part.stages[j].status !== 'completed') {
              canStart = false;
              break;
            }
          }
          
          if (canStart) {
            return i;
          }
        }
      }
    }
    
    return 0; // Default to first stage if nothing else matches
  };

  // Workflow steps data - dynamically generated from actual stages
  const workflowSteps = previousStages.map((stage, index) => ({
    id: index + 1,
    name: stage.name || `Stage ${index + 1}`,
    completed: stage.status === 'completed',
    inProgress: getCurrentStageIndex() === index && (stageStatus === 'in_progress' || stageStatus === 'paused')
  }));

  // Stage control handlers
  const handleStartStage = async () => {
    if (!selectedTechnician) {
      console.error('Please select a technician');
      return;
    }

    // Check if we need to show error reporting modal for forward checking
    const currentStageIndex = getCurrentStageIndex();
    
    // Only check for previous work if we're NOT on the first stage (remove)
    if (currentStageIndex > 0) {
      // Check if previous stage is completed and show error report modal
      const previousStageCompleted = previousStages[currentStageIndex - 1]?.status === 'completed';
      if (previousStageCompleted) {
        setErrorReportType('forward');
        setShowErrorReportModal(true);
        return; // Don't start stage yet, wait for error report result
      }
    }

    // If this is the first stage or error check passed, start the stage
    startStageProcess();
  };

  const startStageProcess = async () => {
    try {
      const tech = technicians.find(t => t._id === selectedTechnician);
      setSelectedTechnicianName(tech ? tech.name : 'Unknown');
      
      const currentStageIndex = getCurrentStageIndex();
      const timestamp = new Date().toISOString();
      
      console.log('Starting stage with params:', {
        workOrderId: workOrder._id,
        partIndex,
        currentStageIndex,
        currentStage,
        selectedTechnician,
        estimatedHours,
        part: workOrder.parts[partIndex],
        targetStage: workOrder.parts[partIndex]?.stages?.[currentStageIndex]
      });
      
      // Update stage in database
      const updateResult = await dataApi.updateStage(workOrder._id, partIndex, currentStageIndex, {
        status: 'in_progress',
        assignedTo: selectedTechnician,
        estimatedHours: estimatedHours
      });
      
      console.log('Stage update result:', updateResult);
      
      // Add start log
      const logResult = await dataApi.addStageLog(workOrder._id, partIndex, currentStageIndex, {
        action: 'start',
        note: `Stage started by ${tech ? tech.name : 'Unknown'}`
      });
      
      console.log('Stage log result:', logResult);
      
      // Only update local state if API calls were successful
      if (updateResult && logResult) {
        console.log('Stage started successfully, updating local state');
        setIsStarted(true);
        setStageStatus('in_progress');
        setStartTime(timestamp);
        setPauseTime(null);
        setPausedDuration(0);
        setShowStartForm(false);
        
        // Check if this is the first stage being started in the entire work order
        const currentWorkOrderStatus = workOrder.status;
        const newWorkOrderStatus = determineWorkOrderStatus({
          ...workOrder,
          parts: workOrder.parts.map((part: any, idx: number) => {
            if (idx === partIndex) {
              // Update the current part's stage status to in_progress
              return {
                ...part,
                stages: part.stages?.map((stage: any, stageIdx: number) => 
                  stageIdx === currentStageIndex 
                    ? { ...stage, status: 'in_progress' }
                    : stage
                ) || []
              };
            }
            return part;
          })
        });
        
        // Update work order status if it needs to change
        if (currentWorkOrderStatus !== newWorkOrderStatus) {
          console.log(`Updating work order status from ${currentWorkOrderStatus} to ${newWorkOrderStatus}`);
          try {
            await dataApi.updateWorkOrderStatus(workOrder._id, newWorkOrderStatus);
            console.log('Work order status updated successfully');
          } catch (statusError) {
            console.error('Failed to update work order status:', statusError);
            // Don't fail the stage start if status update fails
          }
        }
        
        // Force refresh work order data
        if (onUpdateWorkOrder) {
          console.log('Refreshing work order data after stage start');
          onUpdateWorkOrder();
        }
      } else {
        throw new Error('API calls returned invalid response');
      }
    } catch (error: any) {
      console.error('Error starting stage:', error);
      console.error('Error details:', {
        message: error.message,
        response: error.response?.data,
        status: error.response?.status
      });
      
      let errorMessage = 'Failed to start stage';
      if (error.response?.status === 403) {
        errorMessage = 'Permission denied: You do not have permission to manage work order stages';
      } else if (error.response?.data?.message) {
        errorMessage = `Failed to start stage: ${error.response.data.message}`;
      } else if (error.message) {
        errorMessage = `Failed to start stage: ${error.message}`;
      }
      
      console.error(errorMessage);
    }
  };

  const handlePauseStage = async () => {
    try {
      const currentStageIndex = getCurrentStageIndex();
      const timestamp = new Date().toISOString();
      
      console.log('Pausing stage:', { workOrderId: workOrder._id, partIndex, currentStageIndex });
      
      // Update stage status in database
      const statusResult = await dataApi.updateStageStatus(workOrder._id, partIndex, currentStageIndex, 'paused');
      console.log('Stage status update result:', statusResult);
      
      // Add pause log
      const logResult = await dataApi.addStageLog(workOrder._id, partIndex, currentStageIndex, {
        action: 'pause'
      });
      console.log('Stage log result:', logResult);
      
      // Update local state
      setStageStatus('paused');
      setPauseTime(timestamp);
      
      console.log('Stage paused successfully');
    } catch (error) {
      console.error('Error pausing stage:', error);
      console.error(`Failed to pause stage: ${error.message || 'Unknown error'}`);
    }
  };

  const handleResumeStage = async () => {
    try {
      const currentStageIndex = getCurrentStageIndex();
      const timestamp = new Date().toISOString();
      
      // Calculate pause duration and add to total
      if (pauseTime) {
        const pauseDuration = (new Date().getTime() - new Date(pauseTime).getTime()) / 1000;
        setPausedDuration(prev => prev + pauseDuration);
      }
      
      // Update stage status in database
      await dataApi.updateStageStatus(workOrder._id, partIndex, currentStageIndex, 'in_progress');
      
      // Add resume log
      await dataApi.addStageLog(workOrder._id, partIndex, currentStageIndex, {
        action: 'resume'
      });
      
      // Update local state
      setStageStatus('in_progress');
      setPauseTime(null);
    } catch (error) {
      console.error('Error resuming stage:', error);
      console.error('Failed to resume stage');
    }
  };

  const handleCompleteStage = async () => {
    try {
      const currentStageIndex = getCurrentStageIndex();
      const timestamp = new Date().toISOString();
      
      console.log('Completing stage:', { 
        workOrderId: workOrder._id, 
        partIndex, 
        currentStageIndex, 
        currentStage 
      });
      
      // Calculate actual hours (excluding paused time)
      let actualHours = 0;
      if (startTime) {
        const totalElapsed = (new Date().getTime() - new Date(startTime).getTime()) / 1000;
        const workingTime = totalElapsed - pausedDuration;
        actualHours = workingTime / 3600; // Convert to hours
        console.log('Calculated actual hours:', actualHours);
      }
      
      // Update stage in database
      const updateResult = await dataApi.updateStage(workOrder._id, partIndex, currentStageIndex, {
        status: 'completed',
        actualHours: actualHours
      });
      console.log('Stage update result:', updateResult);
      
      // Add complete log
      const logResult = await dataApi.addStageLog(workOrder._id, partIndex, currentStageIndex, {
        action: 'complete',
        note: `Completed in ${actualHours.toFixed(2)} hours`
      });
      console.log('Stage log result:', logResult);
      
      // Update the previous stages data before completing
      setPreviousStages(prev => {
        const updated = [...prev];
        updated[currentStageIndex] = {
          ...updated[currentStageIndex],
          status: 'completed',
          assignedTo: selectedTechnician
        };
        return updated;
      });

      setStageStatus('completed');
      setPauseTime(null);
      setPausedDuration(0);
      
      console.log('Stage marked as completed locally, refreshing work order data...');
      
      // Check if all stages across all parts are now completed
      const currentWorkOrderStatus = workOrder.status;
      const newWorkOrderStatus = determineWorkOrderStatus({
        ...workOrder,
        parts: workOrder.parts.map((part: any, idx: number) => {
          if (idx === partIndex) {
            // Update the current part's stage status to completed
            return {
              ...part,
              stages: part.stages?.map((stage: any, stageIdx: number) => 
                stageIdx === currentStageIndex 
                  ? { ...stage, status: 'completed' }
                  : stage
              ) || []
            };
          }
          return part;
        })
      });
      
      // Update work order status if it needs to change
      if (currentWorkOrderStatus !== newWorkOrderStatus) {
        console.log(`Updating work order status from ${currentWorkOrderStatus} to ${newWorkOrderStatus}`);
        try {
          await dataApi.updateWorkOrderStatus(workOrder._id, newWorkOrderStatus);
          console.log('Work order status updated successfully');
        } catch (statusError) {
          console.error('Failed to update work order status:', statusError);
          // Don't fail the stage completion if status update fails
        }
      }
      
      // Force refresh work order data and wait for it to complete
      if (onUpdateWorkOrder) {
        await new Promise<void>((resolve) => {
          onUpdateWorkOrder();
          // Give time for the parent component to update
          setTimeout(resolve, 500);
        });
      }
      
      // Move to next stage if available (based on stages array length)
      const part = workOrder.parts[partIndex];
      if (part && part.stages && currentStageIndex < part.stages.length - 1) {
        console.log('Moving to next stage...');
        // Next stage will be determined by getCurrentStageIndex after refresh
        setStageStatus('pending');
        setIsStarted(false);
        setStartTime(null);
        setSelectedTechnician('');
        setSelectedTechnicianName('');
        setEstimatedHours(1);
      } else {
        console.log('All stages completed for this part');
      }
    } catch (error) {
      console.error('Error completing stage:', error);
      console.error(`Failed to complete stage: ${error.message || 'Unknown error'}`);
    }
  };

  const handleChangeTechnician = async (newTechId: string) => {
    try {
      const currentStageIndex = getCurrentStageIndex();
      
      // Update technician in database
      await dataApi.updateStage(workOrder._id, partIndex, currentStageIndex, {
        assignedTo: newTechId
      });
      
      const tech = technicians.find(t => t._id === newTechId);
      setSelectedTechnician(newTechId);
      setSelectedTechnicianName(tech ? tech.name : 'Unknown');
      setShowChangeTechForm(false);
    } catch (error) {
      console.error('Error changing technician:', error);
      console.error('Failed to change technician');
    }
  };




  // Cancel part functions
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    setCancelImage(file);
  };

  const handleCancelPart = async () => {
    try {
      if (!cancelImage) {
        console.error('Please upload an approval image');
        return;
      }

      if (!cancelReason.trim()) {
        console.error('Please provide a reason for cancellation');
        return;
      }

      // Check if current stage is in progress or paused
      if (stageStatus === 'in_progress' || stageStatus === 'paused') {
        // Need to stop/complete the current stage before cancelling
        const currentStageIndex = getCurrentStageIndex();
        
        try {
          // Calculate actual hours if stage was started
          let actualHours = 0;
          if (startTime) {
            const totalElapsed = (new Date().getTime() - new Date(startTime).getTime()) / 1000;
            const workingTime = totalElapsed - pausedDuration;
            actualHours = workingTime / 3600; // Convert to hours
          }
          
          // Mark current stage as cancelled/stopped
          await dataApi.updateStage(workOrder._id, partIndex, currentStageIndex, {
            status: 'completed',
            actualHours: actualHours,
            notes: `Stage stopped due to part cancellation: ${cancelReason}`
          });
          
          // Add a log entry for the stage being stopped
          await dataApi.addStageLog(workOrder._id, partIndex, currentStageIndex, {
            action: 'complete',
            note: `Stage stopped due to part cancellation. Worked ${actualHours.toFixed(2)} hours`
          });
          
          console.log('Current stage marked as stopped before part cancellation');
        } catch (stageError) {
          console.error('Error stopping current stage:', stageError);
          // Continue with part cancellation even if stage update fails
        }
      }

      // Call API to cancel the part
      const result = await dataApi.cancelPart(
        workOrder._id,
        getPartDisplayName(partName),
        cancelReason,
        cancelImage
      );

      if (result && result.success) {
        console.error(`Part "${getPartDisplayName(partName)}" has been cancelled successfully.`);
        
        // Update local state
        setIsPartCancelled(true);
        setShowCancelModal(false);
        setCancelReason('');
        setCancelImage(null);
        
        // Refresh the work order data to reflect the cancellation
        if (onUpdateWorkOrder) {
          onUpdateWorkOrder();
        }
      } else {
        throw new Error(result?.message || 'Failed to cancel part');
      }
      
    } catch (error: any) {
      console.error('Error cancelling part:', error);
      console.error(`Failed to cancel part: ${error.response?.data?.message || error.message || 'Please try again.'}`);
    }
  };

  // Error reporting handlers
  const handleShowErrorReportModal = (show: boolean) => {
    if (show) {
      setErrorReportType('revert'); // Default to revert when manually triggered
    }
    setShowErrorReportModal(show);
  };

  const handleErrorReportSubmit = async (errorData: ErrorReportData) => {
    try {
      // Check if work was acceptable (no error to report)
      if (errorData.reportType === 'forward' && errorData.issueDescription === 'Work accepted') {
        // Upload employee photo for QC approval
        if (errorData.image) {
          const formData = new FormData();
          formData.append('employeePhoto', errorData.image);
          formData.append('workOrderId', workOrder._id);
          formData.append('partIndex', partIndex.toString());
          formData.append('stageIndex', getCurrentStageIndex().toString());
          formData.append('approvalType', 'qc_acceptance');
          
          try {
            // Upload QC approval photo to S3
            await errorReportingApi.uploadQCApprovalPhoto(
              workOrder._id,
              partIndex,
              getCurrentStageIndex(),
              formData
            );
            console.log('QC approval photo uploaded successfully');
          } catch (uploadError) {
            console.error('Error uploading QC approval photo:', uploadError);
            // Continue anyway - photo upload failure shouldn't block work
          }
        }
        
        setShowErrorReportModal(false);
        startStageProcess();
        return;
      }

      // Validate that we have all required fields before making API call
      if (!errorData.problematicTechnicianId || !errorData.reportingTechnicianId || !errorData.image) {
        console.error('Missing required fields for error report');
        console.error('Please fill in all required fields including who is reporting the issue');
        return;
      }

      // Validate issue description length (backend requires minimum 10 characters)
      if (!errorData.issueDescription || errorData.issueDescription.trim().length < 10) {
        console.error('Issue description too short:', errorData.issueDescription?.length || 0);
        console.error('Issue description must be at least 10 characters long');
        return;
      }

      // Get current stage index and stage ID for API call
      const currentStageIndex = getCurrentStageIndex();
      
      // Get the current stage ID (reportedStageId) from the work order data
      let reportedStageId = '';
      if (workOrder.parts && workOrder.parts[partIndex] && workOrder.parts[partIndex].stages) {
        const currentStageData = workOrder.parts[partIndex].stages[currentStageIndex];
        reportedStageId = currentStageData?.stageId || '';
      }

      // Validate we have the required stage ID
      if (!reportedStageId) {
        console.error('Could not determine current stage ID for error report');
        console.error('Unable to determine current stage information. Please try again.');
        return;
      }

      // Create FormData for the API call
      const formData = new FormData();
      // Note: reportedStageId, timestamp, and status are handled by backend
      
      console.log('Submitting error report with data:', {
        problematicStageIndex: errorData.problematicStageIndex,
        problematicTechnicianId: errorData.problematicTechnicianId,
        reportingTechnicianId: errorData.reportingTechnicianId,
        reportType: errorData.reportType,
        workOrderId: workOrder._id,
        partIndex: partIndex,
        currentStageIndex: getCurrentStageIndex()
      });
      
      // Additional debug - check if reportingTechnicianId is being overridden somewhere
      console.log('Available technicians:', technicians.map(t => ({id: t._id, name: t.name})));
      console.log('Current user:', user);
      
      formData.append('problematicStageIndex', errorData.problematicStageIndex.toString());
      formData.append('problematicTechnicianId', errorData.problematicTechnicianId);
      formData.append('reportingTechnicianId', errorData.reportingTechnicianId);
      formData.append('reportType', errorData.reportType);
      formData.append('issueDescription', errorData.issueDescription);
      formData.append('stagesToRedo', JSON.stringify(errorData.stagesToRedo));
      
      // Add verification fields if present
      if (errorData.requiresVerification) {
        formData.append('requiresVerification', 'true');
        if (errorData.verifyingTechnicianId) {
          formData.append('verifyingTechnicianId', errorData.verifyingTechnicianId);
        }
        if (errorData.verificationVerdict) {
          formData.append('verificationVerdict', errorData.verificationVerdict);
        }
        if (errorData.verificationNotes) {
          formData.append('verificationNotes', errorData.verificationNotes);
        }
        if (errorData.revertToStageIndex !== undefined) {
          formData.append('revertToStageIndex', errorData.revertToStageIndex.toString());
        }
      }
      
      if (errorData.image) {
        formData.append('image', errorData.image);
      }

      // Submit error report
      await errorReportingApi.createStageErrorReport(
        workOrder._id,
        partIndex,
        currentStageIndex,
        formData
      );

      // Update UI state
      setStageHasIssues(true);
      if (errorData.stagesToRedo.length > 0) {
        setStageNeedsRedo(true);
      }

      setShowErrorReportModal(false);
      
      // If this was a forward check and work was not acceptable, don't start the stage
      // The technician will need to address the issue first

      console.error('Error report submitted successfully');
    } catch (error) {
      console.error('Error submitting error report:', error);
      console.error('Failed to submit error report');
    }
  };

  // Handle technician and hours change from StageControls
  const handleTechnicianChange = (techId: string, hours?: number) => {
    setSelectedTechnician(techId);
    if (hours !== undefined) {
      setEstimatedHours(hours);
    }
  };

  // Fetch error reports for the work order
  const fetchErrorReports = async () => {
    try {
      setErrorReportsLoading(true);
      const response = await errorReportingApi.getWorkOrderErrorReports(workOrder._id);
      console.log('Error reports response for work order', workOrder._id, ':', response);
      
      // Backend now returns array directly
      let errorReportsData = [];
      if (Array.isArray(response)) {
        errorReportsData = response;
      } else if (response && response.data) {
        errorReportsData = response.data;
      }
      
      // Filter to ensure we only show reports for THIS work order
      const filteredReports = errorReportsData.filter(report => 
        report.workOrderId === workOrder._id
      );
      
      // Debug: log each error report's details including technician IDs
      console.log(`Total reports from API: ${errorReportsData.length}, Filtered for work order: ${filteredReports.length}`);
      filteredReports.forEach((report, index) => {
        console.log(`Report ${index + 1}:`, {
          workOrderId: report.workOrderId,
          reportingTechnicianId: report.reportingTechnicianId,
          problematicTechnicianId: report.problematicTechnicianId,
          imageSignedUrl: report.imageSignedUrl
        });
      });
      
      setErrorReports(filteredReports);
    } catch (error) {
      console.error('Error fetching error reports:', error);
      setErrorReports([]);
    } finally {
      setErrorReportsLoading(false);
    }
  };

  // Handle showing error reports modal
  const handleShowErrorReportsModal = (show: boolean) => {
    setShowErrorReportsModal(show);
    if (show) {
      fetchErrorReports();
    }
  };

  // Handle selecting an error report for detail view
  const handleSelectErrorReport = (errorReport: any) => {
    setSelectedErrorReport(errorReport);
    setShowErrorReportsModal(false);
    setShowErrorReportDetailModal(true);
  };

  // Handle going back from detail to list
  const handleBackToErrorReportsList = () => {
    setShowErrorReportDetailModal(false);
    setShowErrorReportsModal(true);
    setSelectedErrorReport(null);
  };

  // Handle case creation
  const handleCreateCase = () => {
    setShowCaseModal(true);
  };

  const handleCaseCreated = (newCase: any) => {
    console.log('Case created successfully:', newCase);
    // The modal will show a success toast, so we don't need to do anything else here
  };

  return (
    <div className="max-w-6xl mx-auto px-3 md:px-0">
      {/* Header */}
      <SubWorkOrderHeader 
        partName={getPartDisplayName(partName)}
        onBack={onBack}
        onCreateCase={handleCreateCase}
      />

      {/* Workflow Progress */}
      <WorkflowProgress steps={workflowSteps} />

      {/* Stage Timing */}
      <StageTiming
        startTime={startTime}
        pauseTime={pauseTime}
        estimatedHours={estimatedHours}
        status={stageStatus}
        workOrderId={workOrder._id}
        partIndex={partIndex}
        stageIndex={getCurrentStageIndex()}
        pausedDuration={pausedDuration}
        supervisorId={getSupervisorId(workOrder)}
        onTimeUpdated={setEstimatedHours}
      />

      {/* Stage Controls */}
      <StageControls
        isStarted={isStarted}
        showStartForm={showStartForm}
        stageStatus={stageStatus}
        currentStage={currentStage}
        selectedTechnician={selectedTechnician}
        isPartCancelled={isPartCancelled}
        technicians={technicians}
        workOrderId={workOrder._id}
        hasIssue={stageHasIssues}
        needsRedo={stageNeedsRedo}
        estimatedHours={estimatedHours}
        errorReportsCount={errorReports.length}
        allStagesCompleted={areAllStagesCompleted(workOrder)}
        onShowStartForm={setShowStartForm}
        onStartStage={handleStartStage}
        onPauseStage={handlePauseStage}
        onResumeStage={handleResumeStage}
        onCompleteStage={handleCompleteStage}
        onShowChangeTechForm={setShowChangeTechForm}
        onShowCancelModal={setShowCancelModal}
        onShowErrorReportModal={handleShowErrorReportModal}
        onShowErrorReportsModal={handleShowErrorReportsModal}
        onTechnicianChange={handleTechnicianChange}
      />

      {/* Current Stage and Part Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
        <CurrentStageInfo
          currentStage={currentStage}
          stageStatus={stageStatus}
          technicianName={getTechnicianNameById(selectedTechnician)}
          estimatedHours={estimatedHours}
          actualHours={0.8}
          startTime={startTime}
          isPartCancelled={isPartCancelled}
        />

        <PartSummary
          overallProgress={33}
          totalEstimatedHours={4}
          totalActualHours={3.5}
          assignedTechnician={getTechnicianNameById(selectedTechnician)}
          qaStatus="Available on main page"
        />
      </div>

      {/* Modals */}

      <CancelPartModal
        isOpen={showCancelModal}
        partName={getPartDisplayName(partName)}
        cancelReason={cancelReason}
        cancelImage={cancelImage}
        onClose={() => {
          setShowCancelModal(false);
          setCancelReason('');
          setCancelImage(null);
        }}
        onReasonChange={setCancelReason}
        onImageChange={handleImageUpload}
        onConfirm={handleCancelPart}
      />

      <ChangeTechnicianModal
        isOpen={showChangeTechForm}
        workOrderId={workOrder._id}
        stageName={currentStage}
        onClose={() => setShowChangeTechForm(false)}
        onConfirm={handleChangeTechnician}
      />

      <ErrorReportModal
        isOpen={showErrorReportModal}
        reportType={errorReportType}
        currentStage={currentStage}
        previousStages={previousStages}
        technicians={technicians}
        allStaffMembers={allStaffMembers}
        workOrderId={workOrder._id}
        partIndex={partIndex}
        stageIndex={getCurrentStageIndex()}
        onClose={() => setShowErrorReportModal(false)}
        onSubmit={handleErrorReportSubmit}
      />

      <ErrorReportsModal
        isOpen={showErrorReportsModal}
        workOrderId={workOrder._id}
        errorReports={errorReports}
        onClose={() => setShowErrorReportsModal(false)}
        onSelectErrorReport={handleSelectErrorReport}
        onRefresh={fetchErrorReports}
      />

      <ErrorReportDetailModal
        isOpen={showErrorReportDetailModal}
        errorReport={selectedErrorReport}
        onClose={() => {
          setShowErrorReportDetailModal(false);
          setSelectedErrorReport(null);
        }}
        onBack={handleBackToErrorReportsList}
      />

      <WorkOrderCaseModal
        isOpen={showCaseModal}
        onClose={() => setShowCaseModal(false)}
        onCaseCreated={handleCaseCreated}
        workOrderId={workOrder._id}
        workOrderNumber={workOrder.workOrderNumber || workOrder.number || workOrder._id}
      />
    </div>
  );
};

export default SubWorkOrderDetail;