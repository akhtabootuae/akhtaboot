import React, { useState, useEffect } from 'react';
import { dataApi, errorReportingApi } from '@/services/api';
import { useAuth } from '@/app/context/AuthContext';

// Technician interface
interface Technician {
  _id: string;
  name: string;
  email: string;
  phone: string;
  role: string;
  speciality?: string;
}

// Stage interface
interface Stage {
  stageId: string;
  status: string;
  assignedTo?: string;
  name?: string;
}

// Props for error report modal
interface ErrorReportModalProps {
  isOpen: boolean;                          // Whether modal is open
  reportType: 'forward' | 'revert';         // Type of error report
  currentStage: string;                     // Current stage name
  previousStages: Stage[];                  // Available previous stages
  technicians: Technician[];               // Available technicians
  allStaffMembers?: Technician[];          // All staff members for "Reported by" field
  workOrderId: string;                      // Work order ID
  partIndex: number;                        // Part index
  stageIndex: number;                       // Current stage index
  onClose: () => void;                      // Close modal handler
  onSubmit: (data: ErrorReportData) => void; // Submit handler
}

// Error report data structure
export interface ErrorReportData {
  problematicStageIndex: number;
  problematicTechnicianId: string;
  reportingTechnicianId: string;
  reportType: 'forward' | 'revert';
  issueDescription: string;
  image: File | null;
  stagesToRedo: number[];
  requiresVerification?: boolean;
  verifyingTechnicianId?: string;
  revertToStageIndex?: number;
  verificationVerdict?: 'good_standard' | 'not_good_standard';
  verificationNotes?: string;
}

/**
 * ErrorReportModal Component
 * 
 * Modal for reporting errors in work order stages.
 * - Forward reporting: when starting next stage, report issues with previous work
 * - Revert reporting: report issues with current or past stages
 * - Image upload for evidence
 * - Stage selection for redo functionality
 */
const ErrorReportModal: React.FC<ErrorReportModalProps> = ({
  isOpen,
  reportType,
  currentStage,
  previousStages,
  technicians,
  allStaffMembers,
  workOrderId,
  partIndex,
  stageIndex,
  onClose,
  onSubmit
}) => {
  // Get current user (supervisor)
  const { user } = useAuth();
  
  // Form state - Default to general issue (-1) for easier access
  const [selectedStage, setSelectedStage] = useState<number>(-1);
  const [selectedTechnician, setSelectedTechnician] = useState<string>('');
  const [reportingTechnician, setReportingTechnician] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [stagesToRedo, setStagesToRedo] = useState<number[]>([]);
  const [isAcceptable, setIsAcceptable] = useState<boolean | null>(null);
  
  // Employee photo state for QC approval
  const [employeePhoto, setEmployeePhoto] = useState<File | null>(null);
  const [employeePhotoPreview, setEmployeePhotoPreview] = useState<string | null>(null);
  
  // Verification state
  const [requiresVerification, setRequiresVerification] = useState<boolean>(false);
  const [verifyingTechnicianId, setVerifyingTechnicianId] = useState<string>('');
  const [revertToStageIndex, setRevertToStageIndex] = useState<number>(0);
  const [availableVerifiers, setAvailableVerifiers] = useState<Technician[]>([]);
  const [loadingVerifiers, setLoadingVerifiers] = useState<boolean>(false);
  const [verifiersError, setVerifiersError] = useState<string>('');
  
  // Verification verdict state
  const [verificationVerdict, setVerificationVerdict] = useState<'good_standard' | 'not_good_standard' | ''>('');
  const [verificationNotes, setVerificationNotes] = useState<string>('');

  // Reset form when modal opens/closes
  React.useEffect(() => {
    if (isOpen) {
      // Default to general issue for easier access
      setSelectedStage(-1);
      setSelectedTechnician('');
      setReportingTechnician('');
      setDescription('');
      setSelectedImage(null);
      setStagesToRedo([]);
      setIsAcceptable(null);
      setRequiresVerification(false);
      setVerifyingTechnicianId('');
      setRevertToStageIndex(0);
      setAvailableVerifiers([]);
      setVerifiersError('');
      setVerificationVerdict('');
      setVerificationNotes('');
      setEmployeePhoto(null);
      setEmployeePhotoPreview(null);
    }
  }, [isOpen, reportType, stageIndex, previousStages]);

  // Get technician who worked on selected stage
  const getStageAssignedTechnician = React.useCallback((stageIdx: number) => {
    const stage = previousStages[stageIdx];
    return stage?.assignedTo || '';
  }, [previousStages]);

  // Auto-select technician when stage changes (but not for general issues)
  React.useEffect(() => {
    if (selectedStage !== -1) {
      const assignedTech = getStageAssignedTechnician(selectedStage);
      if (assignedTech) {
        setSelectedTechnician(assignedTech);
      }
    } else {
      // Clear technician selection for general issues
      setSelectedTechnician('');
    }
  }, [selectedStage, getStageAssignedTechnician]);

  // Fetch available verifiers when verification is required
  useEffect(() => {
    const fetchVerifiers = async () => {
      if (requiresVerification && selectedTechnician) {
        setLoadingVerifiers(true);
        setVerifiersError('');
        
        try {
          // Find the problematic technician to get their specialty
          const problematicTech = technicians.find(t => t._id === selectedTechnician);
          
          let verifiersList: Technician[] = [];
          
          if (problematicTech && problematicTech.speciality) {
            // Fetch technicians with same specialty
            verifiersList = await dataApi.getTechniciansBySpecialty(
              problematicTech.speciality,
              selectedTechnician
            );
          }
          
          // Always add admin as the last option
          if (user) {
            verifiersList.push({
              _id: user._id,
              name: user.first_name + ' ' + user.last_name + ' (Admin)',
              email: user.email,
              phone: user.phone || '',
              role: 'Admin',
              speciality: 'All'
            });
          }
          
          setAvailableVerifiers(verifiersList);
          
        } catch (error) {
          console.error('Error fetching verifiers:', error);
          setVerifiersError('Failed to load verifying technicians');
          
          // Fallback to just admin
          if (user) {
            setAvailableVerifiers([{
              _id: user._id,
              name: user.first_name + ' ' + user.last_name + ' (Admin)',
              email: user.email,
              phone: user.phone || '',
              role: 'Admin',
              speciality: 'All'
            }]);
          }
        } finally {
          setLoadingVerifiers(false);
        }
      }
    };

    fetchVerifiers();
  }, [requiresVerification, selectedTechnician, technicians, user]);

  // Handle file selection
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedImage(e.target.files[0]);
    }
  };
  
  // Handle employee photo change for QC approval
  const handleEmployeePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setEmployeePhoto(file);
      
      // Create preview URL
      const reader = new FileReader();
      reader.onloadend = () => {
        setEmployeePhotoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle stage redo selection
  const handleStageRedoChange = (stageIdx: number, checked: boolean) => {
    if (checked) {
      setStagesToRedo(prev => [...prev, stageIdx]);
    } else {
      setStagesToRedo(prev => prev.filter(idx => idx !== stageIdx));
    }
  };

  // Handle form submission
  const handleSubmit = () => {
    // For forward reporting, check if work is acceptable
    if (reportType === 'forward') {
      if (isAcceptable === null) {
        console.error('Please indicate if the previous work is acceptable');
        return;
      }
      
      if (isAcceptable) {
        // Work is acceptable, but we need an employee photo
        if (!employeePhoto) {
          console.error('Please take a photo of the employee to confirm QC approval');
          return;
        }
        
        // Work is acceptable, no error to report
        onClose();
        // Need to trigger stage start in parent component
        const acceptableData: ErrorReportData = {
          problematicStageIndex: -1, // No problematic stage
          problematicTechnicianId: '',
          reportingTechnicianId: reportingTechnician || '',
          reportType: 'forward',
          issueDescription: 'Work accepted',
          image: employeePhoto, // Include employee photo for QC approval
          stagesToRedo: []
        };
        onSubmit(acceptableData);
        return;
      }
    }

    // For revert reporting or when work is not acceptable
    // Handle general issues (selectedStage === -1) differently
    if (selectedStage !== -1) {
      // For specific stage reporting, check if there are any completed stages
      const completedStages = previousStages.filter(stage => stage.status === 'completed');
      if (completedStages.length === 0) {
        console.error('No completed stages available for error reporting');
        return;
      }
      
      // Check if the selected stage is actually completed
      const selectedStageData = previousStages[selectedStage];
      if (!selectedStageData || selectedStageData.status !== 'completed') {
        console.error('You can only report errors on completed stages');
        return;
      }
      
      if (!selectedTechnician) {
        console.error('System error: No technician assigned to this stage');
        return;
      }
    }
    
    if (!reportingTechnician) {
      console.error('Please select who is reporting this issue');
      return;
    }
    
    if (!description.trim()) {
      console.error('Please provide a description of the issue');
      return;
    }
    
    if (!selectedImage) {
      console.error('Please upload an evidence image');
      return;
    }

    // Validate verification fields if required
    if (requiresVerification) {
      if (!verifyingTechnicianId) {
        console.error('Please select a verifying technician');
        return;
      }
      
      if (!verificationVerdict) {
        console.error('The verifying technician must provide their verdict on the work quality');
        return;
      }
      
      if (verificationVerdict === 'not_good_standard' && (revertToStageIndex === undefined || revertToStageIndex === null)) {
        console.error('Please select which stage to revert to since work was deemed not good standard');
        return;
      }
    }

    // Submit error report
    const errorData: ErrorReportData = {
      problematicStageIndex: selectedStage,
      problematicTechnicianId: selectedTechnician || '', // Can be empty for general issues
      reportingTechnicianId: reportingTechnician,
      reportType,
      issueDescription: description.trim(),
      image: selectedImage,
      stagesToRedo: selectedStage === -1 ? [] : stagesToRedo, // No stage redo for general issues
      requiresVerification,
      verifyingTechnicianId: requiresVerification ? verifyingTechnicianId : undefined,
      revertToStageIndex: requiresVerification && verificationVerdict === 'not_good_standard' ? revertToStageIndex : undefined,
      verificationVerdict: requiresVerification ? verificationVerdict as 'good_standard' | 'not_good_standard' : undefined,
      verificationNotes: requiresVerification ? verificationNotes : undefined
    };

    onSubmit(errorData);
  };

  // Don't render if not open
  if (!isOpen) return null;

  return (
    // Modal overlay
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      {/* Modal content */}
      <div className="bg-white rounded-lg p-4 md:p-6 w-full max-w-full md:max-w-2xl max-h-[85vh] overflow-y-auto">
        <h3 className="text-lg md:text-xl font-bold mb-3 md:mb-4">
          {reportType === 'forward' ? 'Quality Check - Previous Work' : 'Report Stage Issue'}
        </h3>
        
        {/* Quality check question for forward reporting */}
        {reportType === 'forward' && (
          <div className="mb-6 p-4 bg-gray-50 rounded-lg">
            <h4 className="font-medium mb-3">Was the previous work acceptable?</h4>
            <div className="flex gap-4">
              <label className="flex items-center">
                <input
                  type="radio"
                  name="workAcceptable"
                  checked={isAcceptable === true}
                  onChange={() => setIsAcceptable(true)}
                  className="mr-2"
                />
                <span className="text-green-600 font-medium">Yes - Work is acceptable</span>
              </label>
              <label className="flex items-center">
                <input
                  type="radio"
                  name="workAcceptable"
                  checked={isAcceptable === false}
                  onChange={() => setIsAcceptable(false)}
                  className="mr-2"
                />
                <span className="text-red-600 font-medium">No - Report issue</span>
              </label>
            </div>
            
            {/* Show employee photo capture when work is acceptable */}
            {isAcceptable === true && (
            <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
              <h4 className="font-medium mb-3 text-green-800">QC Approval - Employee Photo Required</h4>
              <p className="text-sm text-gray-600 mb-4">
                Please take a photo of the employee who completed this work to confirm QC approval.
              </p>
              
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Employee Photo *
                </label>
                <input
                  type="file"
                  accept="image/*"
                  capture="environment"
                  onChange={handleEmployeePhotoChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                  required
                />
                {employeePhoto && (
                  <p className="text-sm text-green-600 mt-1">
                    ✓ Photo selected: {employeePhoto.name}
                  </p>
                )}
              </div>
              
              {/* Preview employee photo */}
              {employeePhotoPreview && (
                <div className="mt-4">
                  <p className="text-sm font-medium text-gray-700 mb-2">Photo Preview:</p>
                  <img 
                    src={employeePhotoPreview} 
                    alt="Employee" 
                    className="max-w-full h-48 object-cover rounded-lg border border-gray-300"
                  />
                </div>
              )}
            </div>
            )}
          </div>
        )}

        {/* Show error reporting form only if work is not acceptable or it's a revert report */}
        {(isAcceptable === false || reportType === 'revert') && (
          <>
            {/* Stage selection - Only show completed stages */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {reportType === 'forward' ? 'Problematic Stage' : 'Select Stage with Issue'}
              </label>
              <select
                value={selectedStage}
                onChange={(e) => setSelectedStage(parseInt(e.target.value))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {/* General issue option */}
                <option key="general-issue" value={-1}>
                  General Issue - Stage Unknown
                </option>
                {previousStages
                  .map((stage, index) => ({ ...stage, originalIndex: index }))
                  .filter(stage => stage.status === 'completed')
                  .map((stage) => (
                    <option key={`problematic-stage-${stage.originalIndex}`} value={stage.originalIndex}>
                      Stage {stage.originalIndex + 1}: {stage.name || `Stage ${stage.originalIndex + 1}`} (Completed)
                    </option>
                  ))}
              </select>
              {previousStages.filter(stage => stage.status === 'completed').length === 0 && (
                <p className="text-sm text-gray-500 mt-1">No completed stages available for specific error reporting - you can still report general issues</p>
              )}
            </div>

            {/* Reported by selection */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Reported by *
              </label>
              <select
                value={reportingTechnician}
                onChange={(e) => setReportingTechnician(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              >
                <option key="empty-reporter" value="">Select who is reporting this issue</option>
                {(allStaffMembers || technicians).map((staff, index) => (
                  <option key={`reporter-${staff._id}-${index}`} value={staff._id}>
                    {staff.name} - {staff.role}
                  </option>
                ))}
              </select>
            </div>

            {/* Technician selection - Handle both specific stage and general issue */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {selectedStage === -1 ? 'Select Technician (if applicable)' : 'Technician who worked on this stage (System Set)'}
              </label>
              {selectedStage === -1 ? (
                // For general issues, allow manual technician selection
                <select
                  value={selectedTechnician}
                  onChange={(e) => setSelectedTechnician(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Select Technician (Optional for general issues)</option>
                  {technicians.map((tech) => (
                    <option key={tech._id} value={tech._id}>
                      {tech.name} - {tech.role}
                    </option>
                  ))}
                </select>
              ) : (
                // For specific stages, show assigned technician (read-only)
                <div className="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-50 text-gray-700">
                  {(() => {
                    const assignedTechId = getStageAssignedTechnician(selectedStage);
                    const assignedTech = technicians.find(t => t._id === assignedTechId);
                    return assignedTech ? `${assignedTech.name} - ${assignedTech.role}` : 'No technician assigned';
                  })()}
                </div>
              )}
              <p className="text-xs text-gray-500 mt-1">
                {selectedStage === -1 
                  ? 'For general issues, you can optionally select a technician or leave blank if not applicable.'
                  : 'This field is automatically set based on who worked on the selected stage and cannot be edited.'
                }
              </p>
            </div>

            {/* Issue description */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Issue Description *
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe the issue in detail..."
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                rows={4}
                required
              />
            </div>

            {/* Image upload */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Evidence Image *
              </label>
              <input
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
              {selectedImage && (
                <p className="text-sm text-gray-600 mt-1">
                  Selected: {selectedImage.name}
                </p>
              )}
            </div>

            {/* Stages to redo - Only show completed stages */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Which completed stages need to be redone?
              </label>
              <div className="space-y-2">
                {previousStages
                  .map((stage, index) => ({ ...stage, originalIndex: index }))
                  .filter(stage => stage.status === 'completed')
                  .map((stage) => (
                    <label key={stage.originalIndex} className="flex items-center">
                      <input
                        type="checkbox"
                        checked={stagesToRedo.includes(stage.originalIndex)}
                        onChange={(e) => handleStageRedoChange(stage.originalIndex, e.target.checked)}
                        className="mr-3"
                      />
                      <span className="text-sm">
                        Stage {stage.originalIndex + 1}: {stage.name || `Stage ${stage.originalIndex + 1}`} (Completed)
                      </span>
                    </label>
                  ))}
              </div>
              {previousStages.filter(stage => stage.status === 'completed').length === 0 && (
                <p className="text-sm text-gray-500">No completed stages available for redo</p>
              )}
            </div>

            {/* Verification Section */}
            <div className="mb-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
              <label className="flex items-center mb-4">
                <input
                  type="checkbox"
                  checked={requiresVerification}
                  onChange={(e) => setRequiresVerification(e.target.checked)}
                  className="mr-3 h-4 w-4 text-blue-600"
                />
                <span className="font-medium text-gray-800">
                  Requires Peer Verification
                </span>
              </label>

              {/* Show verification options when enabled */}
              {requiresVerification && (
                <div className="space-y-4">
                  {/* Verifying Technician Selection */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Verifying Technician *
                    </label>
                    {loadingVerifiers ? (
                      <p className="text-sm text-gray-600">Loading available technicians...</p>
                    ) : (
                      <select
                        value={verifyingTechnicianId}
                        onChange={(e) => setVerifyingTechnicianId(e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required={requiresVerification}
                      >
                        <option key="empty" value="">Select Verifying Technician</option>
                        {availableVerifiers.map((tech, index) => (
                          <option key={`${tech._id}-${index}`} value={tech._id}>
                            {tech.name} - {tech.speciality || 'General'}
                          </option>
                        ))}
                      </select>
                    )}
                    {verifiersError && (
                      <p className="text-sm text-gray-600 mt-1">{verifiersError}</p>
                    )}
                  </div>

                  {/* Verification Verdict - only show if verifying technician is selected */}
                  {verifyingTechnicianId && (
                    <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                      <h4 className="font-medium mb-3 text-gray-800">
                        {availableVerifiers.find(t => t._id === verifyingTechnicianId)?.name || 'Verifying Technician'}: 
                        Is this work acceptable?
                      </h4>
                      
                      <div className="mb-3">
                        <div className="space-y-2">
                          <label className="flex items-center">
                            <input
                              type="radio"
                              name="verificationVerdict"
                              value="good_standard"
                              checked={verificationVerdict === 'good_standard'}
                              onChange={(e) => setVerificationVerdict(e.target.value as 'good_standard')}
                              className="mr-3"
                            />
                            <span className="text-green-600 font-medium">
                              ✓ Good Standard - Work is acceptable, continue
                            </span>
                          </label>
                          <label className="flex items-center">
                            <input
                              type="radio"
                              name="verificationVerdict"
                              value="not_good_standard"
                              checked={verificationVerdict === 'not_good_standard'}
                              onChange={(e) => setVerificationVerdict(e.target.value as 'not_good_standard')}
                              className="mr-3"
                            />
                            <span className="text-red-600 font-medium">
                              ✗ Not Good Standard - Work needs to be redone
                            </span>
                          </label>
                        </div>
                      </div>

                      {/* Optional verification notes */}
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Additional Notes (Optional)
                        </label>
                        <textarea
                          value={verificationNotes}
                          onChange={(e) => setVerificationNotes(e.target.value)}
                          placeholder="Any additional observations..."
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                          rows={2}
                        />
                      </div>
                    </div>
                  )}

                  {/* Stage to revert to if verification fails - only show if verdict is bad */}
                  {verificationVerdict === 'not_good_standard' && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Revert to stage: *
                      </label>
                      <select
                        value={revertToStageIndex}
                        onChange={(e) => setRevertToStageIndex(parseInt(e.target.value))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required={requiresVerification}
                      >
                        <option key="empty-stage" value="">Select Stage</option>
                        {previousStages.map((stage, index) => (
                          <option key={`stage-${index}`} value={index}>
                            Stage {index + 1}: {stage.name || `Stage ${index + 1}`}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}

                  {/* Verification info */}
                  <div className="text-sm text-gray-600 bg-gray-50 p-3 rounded">
                    <p>• Select the verifying technician who will physically inspect the work</p>
                    <p>• They will provide their verdict on work quality in this same session</p>
                    <p>• If approved, work continues. If not, it reverts to the selected stage</p>
                  </div>
                </div>
              )}
            </div>
          </>
        )}
        
        {/* Action buttons */}
        <div className="flex justify-end space-x-3">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            {isAcceptable === true ? 'Continue' : (isAcceptable === false || reportType === 'revert') ? 'Report Issue' : 'Submit'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ErrorReportModal;