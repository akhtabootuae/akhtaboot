import React, { useState } from 'react';
import { errorReportingApi } from '@/services/api';

// Props interface for the verification modal
interface VerificationModalProps {
  isOpen: boolean;
  errorReportId: string;
  workOrderNumber: string;
  stageName: string;
  issueDescription: string;
  imageUrl?: string;
  onClose: () => void;
  onComplete: () => void;
}

/**
 * VerificationModal Component
 * 
 * Modal for verifying technicians to review and submit their verdict
 * on reported work quality issues.
 */
const VerificationModal: React.FC<VerificationModalProps> = ({
  isOpen,
  errorReportId,
  workOrderNumber,
  stageName,
  issueDescription,
  imageUrl,
  onClose,
  onComplete
}) => {
  // State for verdict and notes
  const [verdict, setVerdict] = useState<'good_standard' | 'not_good_standard' | ''>('');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Reset form when modal opens
  React.useEffect(() => {
    if (isOpen) {
      setVerdict('');
      setNotes('');
    }
  }, [isOpen]);

  // Handle form submission
  const handleSubmit = async () => {
    // Validate verdict is selected
    if (!verdict) {
      console.error('Please select a verdict');
      return;
    }

    setIsSubmitting(true);

    try {
      // Submit verification result
      await errorReportingApi.completeVerification(
        errorReportId,
        verdict,
        notes
      );

      // Notify parent component
      onComplete();
      
      // Close modal
      onClose();
    } catch (error) {
      console.error('Error submitting verification:', error);
      console.error('Failed to submit verification. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Don't render if not open
  if (!isOpen) return null;

  return (
    // Modal overlay
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      {/* Modal content */}
      <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <h3 className="text-xl font-bold mb-4">Work Quality Verification</h3>
        
        {/* Work order info */}
        <div className="mb-6 p-4 bg-gray-50 rounded-lg">
          <h4 className="font-medium mb-2">Work Order: {workOrderNumber}</h4>
          <p className="text-sm text-gray-600">Stage: {stageName}</p>
        </div>

        {/* Issue description */}
        <div className="mb-6">
          <h4 className="font-medium mb-2">Reported Issue:</h4>
          <p className="text-gray-700 bg-gray-50 p-3 rounded">{issueDescription}</p>
        </div>

        {/* Evidence image if available */}
        {imageUrl && (
          <div className="mb-6">
            <h4 className="font-medium mb-2">Evidence Image:</h4>
            <img 
              src={imageUrl} 
              alt="Evidence" 
              className="max-w-full h-auto rounded-lg border border-gray-300"
            />
          </div>
        )}

        {/* Verification section */}
        <div className="mb-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
          <h4 className="font-medium mb-4">Physical Inspection Required</h4>
          <p className="text-sm text-gray-700 mb-4">
            Please physically inspect the work before submitting your verdict.
          </p>
          
          {/* Verdict selection */}
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Your Verdict *
            </label>
            <div className="space-y-2">
              <label className="flex items-center">
                <input
                  type="radio"
                  name="verdict"
                  value="good_standard"
                  checked={verdict === 'good_standard'}
                  onChange={(e) => setVerdict(e.target.value as 'good_standard')}
                  className="mr-3"
                />
                <span className="text-green-600 font-medium">
                  ✓ Good Standard - Work is acceptable
                </span>
              </label>
              <label className="flex items-center">
                <input
                  type="radio"
                  name="verdict"
                  value="not_good_standard"
                  checked={verdict === 'not_good_standard'}
                  onChange={(e) => setVerdict(e.target.value as 'not_good_standard')}
                  className="mr-3"
                />
                <span className="text-red-600 font-medium">
                  ✗ Not Good Standard - Work needs to be redone
                </span>
              </label>
            </div>
          </div>

          {/* Additional notes */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Additional Notes (Optional)
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Add any additional observations..."
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              rows={3}
            />
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex justify-end space-x-3">
          <button
            onClick={onClose}
            disabled={isSubmitting}
            className="px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300 disabled:opacity-50"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={isSubmitting || !verdict}
            className={`px-4 py-2 rounded text-white font-medium transition-colors ${
              isSubmitting || !verdict
                ? 'bg-gray-400 cursor-not-allowed'
                : 'bg-blue-600 hover:bg-blue-700'
            }`}
          >
            {isSubmitting ? 'Submitting...' : 'Submit Verification'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default VerificationModal;