import React, { useState, useEffect } from 'react';
import { dataApi } from '../../../../../services/api';

// Error report interface based on API response
interface ErrorReport {
  _id: string;
  workOrderId: string;
  partIndex: number;
  stageIndex: number;
  reportedStageId: string;
  problematicStageIndex: number;
  reportingTechnicianId: string;
  problematicTechnicianId: string;
  reportType: 'forward' | 'revert';
  issueDescription: string;
  imageS3Key: string;
  imageUrl: string;
  imageSignedUrl: string;
  imageName: string;
  imageSize: number;
  timestamp: string;
  status: 'pending' | 'acknowledged' | 'resolved';
  stagesToRedo: number[];
  reportingTechnician: {
    _id: string;
    name: string;
    email: string;
  };
  problematicTechnician: {
    _id: string;
    name: string;
    email: string;
  };
}

// Props for the error report detail modal
interface ErrorReportDetailModalProps {
  isOpen: boolean;
  errorReport: ErrorReport | null;
  onClose: () => void;
  onBack: () => void;
}

/**
 * ErrorReportDetailModal Component
 * 
 * Modal that displays detailed view of a specific error report.
 * Shows all information including the AWS S3 image.
 */
const ErrorReportDetailModal: React.FC<ErrorReportDetailModalProps> = ({
  isOpen,
  errorReport,
  onClose,
  onBack
}) => {
  const [imageLoading, setImageLoading] = useState(true);
  const [imageError, setImageError] = useState(false);
  const [technicians, setTechnicians] = useState<{[id: string]: {name: string, email: string}}>({});
  const [loadingTechnicians, setLoadingTechnicians] = useState(false);

  // Fetch technician details when modal opens
  useEffect(() => {
    if (!isOpen || !errorReport) return;

    const fetchTechnicians = async () => {
      setLoadingTechnicians(true);
      const techData: {[id: string]: {name: string, email: string}} = {};
      
      // Fetch reporting technician
      if (errorReport.reportingTechnicianId) {
        try {
          const response = await dataApi.getUserById(errorReport.reportingTechnicianId);
          if (response) {
            techData[errorReport.reportingTechnicianId] = {
              name: response.name || `${response.first_name || ''} ${response.last_name || ''}`.trim() || 'Unknown',
              email: response.email || 'N/A'
            };
          }
        } catch (error) {
          console.error(`Error fetching reporting technician:`, error);
          techData[errorReport.reportingTechnicianId] = { name: 'Unknown', email: 'N/A' };
        }
      }

      // Fetch problematic technician
      if (errorReport.problematicTechnicianId) {
        try {
          const response = await dataApi.getUserById(errorReport.problematicTechnicianId);
          if (response) {
            techData[errorReport.problematicTechnicianId] = {
              name: response.name || `${response.first_name || ''} ${response.last_name || ''}`.trim() || 'Unknown',
              email: response.email || 'N/A'
            };
          }
        } catch (error) {
          console.error(`Error fetching problematic technician:`, error);
          techData[errorReport.problematicTechnicianId] = { name: 'Unknown', email: 'N/A' };
        }
      }
      
      setTechnicians(techData);
      setLoadingTechnicians(false);
    };

    fetchTechnicians();
  }, [isOpen, errorReport]);


  if (!isOpen || !errorReport) return null;

  // Helper function to format timestamp
  const formatDate = (timestamp: string) => {
    return new Date(timestamp).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  // Helper function to format file size
  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  // Helper function to get status color
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'acknowledged':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'resolved':
        return 'bg-green-100 text-green-800 border-green-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  // Handle image load
  const handleImageLoad = () => {
    setImageLoading(false);
    setImageError(false);
  };

  // Handle image error
  const handleImageError = () => {
    setImageLoading(false);
    setImageError(true);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-5xl max-h-[95vh] overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="text-gray-400 hover:text-gray-600 text-xl"
            >
              ←
            </button>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Error Report Details</h2>
              <p className="text-sm text-gray-600">Report ID: {errorReport._id}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 text-2xl"
          >
            ×
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(95vh-120px)]">
          <div className="max-w-4xl mx-auto space-y-6">
            
            {/* Stage + Time - Large and prominent */}
            <div className="text-3xl font-bold text-gray-900 bg-blue-50 p-6 rounded-lg text-center">
              Stage {errorReport.stageIndex + 1} + {formatDate(errorReport.timestamp)}
            </div>
            
            {/* Technician Details - Large and clear */}
            <div className="bg-gray-50 p-6 rounded-lg">
              <div className="space-y-4">
                <div className="text-2xl font-semibold text-gray-800">
                  <span className="text-green-700">Reported by:</span> {
                    loadingTechnicians ? 'Loading...' : 
                    (technicians[errorReport.reportingTechnicianId]?.name || 
                     errorReport.reportingTechnician?.name || 
                     `Unknown (ID: ${errorReport.reportingTechnicianId?.substring(0, 8) || 'N/A'}...)`)
                  }
                </div>
                
                <div className="text-2xl font-semibold text-gray-800">
                  <span className="text-red-700">Mistake done by:</span> {
                    loadingTechnicians ? 'Loading...' : 
                    (technicians[errorReport.problematicTechnicianId]?.name || 
                     errorReport.problematicTechnician?.name || 
                     `Technician ID: ${errorReport.problematicTechnicianId?.substring(0, 8)}...`)
                  }
                </div>
              </div>
            </div>
            
            {/* Issue Description */}
            <div className="bg-yellow-50 p-6 rounded-lg">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Description:</h3>
              <p className="text-lg text-gray-700 whitespace-pre-wrap">{errorReport.issueDescription}</p>
            </div>
            
            {/* Evidence Image */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Evidence Image</h3>
              
              {errorReport.imageSignedUrl ? (
                <div className="space-y-4">
                  {/* Modern Image Display with Hover Effects */}
                  <div className="relative">
                    {imageLoading && (
                      <div className="absolute inset-0 flex items-center justify-center bg-gray-100 rounded-lg">
                        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
                      </div>
                    )}
                    
                    {imageError ? (
                      <div className="flex flex-col items-center justify-center py-20 text-gray-500 bg-gray-50 rounded-lg border border-gray-200">
                        <div className="text-6xl mb-4">🖼️</div>
                        <p className="text-lg">Failed to load image</p>
                        <p className="text-sm mt-2">Image may be expired or unavailable</p>
                      </div>
                    ) : (
                      <div className="relative group">
                        <img
                          src={errorReport.imageSignedUrl}
                          alt="Error evidence"
                          className="w-full h-auto max-h-[600px] object-contain rounded-lg border border-gray-200"
                          onLoad={handleImageLoad}
                          onError={handleImageError}
                        />
                        
                        {/* Hover overlay with view full size button */}
                        <button
                          onClick={() => window.open(errorReport.imageSignedUrl, '_blank')}
                          className="absolute inset-0 bg-black bg-opacity-0 hover:bg-opacity-30 transition-all duration-200 flex items-center justify-center rounded-lg"
                        >
                          <span className="text-white opacity-0 group-hover:opacity-100 transition-opacity text-lg font-medium bg-black bg-opacity-50 px-4 py-2 rounded-lg">
                            View Full Size
                          </span>
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Image metadata */}
                  {errorReport.imageName && (
                    <div className="text-center">
                      <p className="text-sm text-gray-600">
                        {errorReport.imageName} • {errorReport.imageSize ? formatFileSize(errorReport.imageSize) : 'Unknown size'}
                      </p>
                    </div>
                  )}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-20 text-gray-500 bg-gray-50 rounded-lg border border-gray-200">
                  <div className="text-6xl mb-4">📷</div>
                  <p className="text-lg">No image attached</p>
                </div>
              )}
            </div>

            {/* Status badges */}
            <div className="flex justify-center gap-4">
              <span className={`px-6 py-3 text-lg font-medium rounded-full border ${getStatusColor(errorReport.status)}`}>
                Status: {errorReport.status.charAt(0).toUpperCase() + errorReport.status.slice(1)}
              </span>
              <span className="px-6 py-3 text-lg font-medium rounded-full bg-gray-100 text-gray-800 border border-gray-200">
                Type: {errorReport.reportType === 'forward' ? 'Forward Check' : 'Issue Report'}
              </span>
            </div>
            
          </div>
        </div>
      </div>
    </div>
  );
};

export default ErrorReportDetailModal;