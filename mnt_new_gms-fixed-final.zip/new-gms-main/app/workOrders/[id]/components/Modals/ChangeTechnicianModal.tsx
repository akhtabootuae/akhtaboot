import React, { useState, useEffect } from 'react';
import api from '@/services/api';

// Props for change technician modal
interface ChangeTechnicianModalProps {
  isOpen: boolean;                      // Whether modal is open
  workOrderId: string;                  // Work order ID
  onClose: () => void;                  // Close modal handler
  onConfirm: (techId: string) => void;  // Confirm technician change
  stageName?: string;                   // Current stage name for filtering technicians
}

// Technician data structure
interface Technician {
  _id: string;
  name: string;
  email: string;
  phone: string;
  role: string;
  user_id?: string;
  technician_name?: string;
  staff_code?: string;
  speciality?: string;
  branch?: any;
}

/**
 * ChangeTechnicianModal Component
 * 
 * Modal for changing assigned technician mid-stage.
 * - Shows technician selector without estimated time (since work is already in progress)
 * - Allows changing assignment without restarting stage
 * - Used when current technician unavailable
 */
const ChangeTechnicianModal: React.FC<ChangeTechnicianModalProps> = ({
  isOpen,
  workOrderId,
  onClose,
  onConfirm,
  stageName
}) => {
  const [technicians, setTechnicians] = useState<Technician[]>([]);
  const [filteredTechnicians, setFilteredTechnicians] = useState<Technician[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTechnician, setSelectedTechnician] = useState<string>('');

  // Map stage names to required specialties
  const getRequiredSpecialty = (stage: string | undefined): string[] => {
    if (!stage) return ['General']; // If no stage specified, show general technicians
    
    const stageMap: { [key: string]: string[] } = {
      // Map stage names to specialties (case-insensitive)
      'fix': ['Fix/Remove'],
      'remove': ['Fix/Remove'],
      'pdr': ['PDR'],
      'paint': ['Paint'],
      'primer': ['Paint'],
      'polish': ['Paint', 'Body Work'],
      'denter': ['Body Work'],
      'magoon': ['Body Work'],
      'repair': ['Body Work', 'Mechanical'],
      // Additional mappings for database stage names
      'Fix': ['Fix/Remove'],
      'Remove': ['Fix/Remove'],
      'PDR': ['PDR'],
      'Paint': ['Paint'],
      'Primer': ['Paint'],
      'Polish': ['Paint', 'Body Work'],
      'Denter': ['Body Work'],
      'Magoon': ['Body Work'],
      'Repair': ['Body Work', 'Mechanical']
    };
    
    // Check map with lowercase first for consistency
    const lowerStage = stage.toLowerCase();
    return stageMap[lowerStage] || stageMap[stage] || ['General'];
  };

  // Fetch technicians when component mounts
  useEffect(() => {
    if (!isOpen) return;

    const fetchTechnicians = async () => {
      try {
        setLoading(true);
        // Get list of technicians from API
        const response = await api.get('/api/users/technicians');
        console.log("Technicians data:", response);
        setTechnicians(response || []);
      } catch (error) {
        console.error("Error fetching technicians:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchTechnicians();
  }, [isOpen]);

  // Filter technicians based on stage specialty
  useEffect(() => {
    if (technicians.length === 0) {
      setFilteredTechnicians([]);
      return;
    }

    const requiredSpecialties = getRequiredSpecialty(stageName);
    console.log(`Filtering technicians for stage: ${stageName}, required specialties:`, requiredSpecialties);
    
    const filtered = technicians.filter(tech => {
      // If technician has 'General' specialty, they can work on any stage
      if (tech.speciality === 'General') return true;
      
      // If no specialty is set, don't include them
      if (!tech.speciality) return false;
      
      // Check if technician's specialty matches required specialties
      return requiredSpecialties.includes(tech.speciality);
    });
    
    console.log(`Filtered ${filtered.length} technicians from ${technicians.length} total`);
    setFilteredTechnicians(filtered);
  }, [technicians, stageName]);

  // Reset state when modal closes
  useEffect(() => {
    if (!isOpen) {
      setSelectedTechnician('');
      setTechnicians([]);
      setFilteredTechnicians([]);
    }
  }, [isOpen]);

  // Handle form submission
  const handleConfirm = () => {
    if (selectedTechnician) {
      onConfirm(selectedTechnician);
      onClose();
    }
  };

  // Don't render if not open
  if (!isOpen) return null;

  return (
    // Modal overlay
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      {/* Modal content */}
      <div className="bg-white rounded-lg p-6 w-full max-w-md">
        <h3 className="font-medium mb-4">Change Assigned Technician</h3>
        
        <p className="text-sm text-gray-600 mb-4">
          Select a new technician to continue this stage. The estimated time remains unchanged.
        </p>
        
        {/* Technician selector - simplified without estimated time */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Select New Technician
          </label>
          
          {loading ? (
            <div className="animate-pulse bg-gray-200 h-10 w-full rounded"></div>
          ) : (
            <select
              value={selectedTechnician}
              onChange={(e) => setSelectedTechnician(e.target.value)}
              className="block w-full rounded-md border border-gray-300 p-2 focus:border-blue-500 focus:ring-blue-500"
            >
              <option value="">Select Technician</option>
              {filteredTechnicians.map((tech) => (
                <option key={tech._id} value={tech._id}>
                  {tech.name} {tech.speciality ? `(${tech.speciality})` : ''}
                </option>
              ))}
            </select>
          )}
          
          {filteredTechnicians.length === 0 && technicians.length > 0 && !loading && (
            <p className="text-sm text-orange-600 mt-1">
              No technicians available with the required specialty for this stage.
            </p>
          )}
        </div>
        
        {/* Action buttons */}
        <div className="flex space-x-3">
          <button 
            onClick={onClose}
            className="flex-1 px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300"
          >
            Cancel
          </button>
          <button 
            onClick={handleConfirm}
            disabled={!selectedTechnician}
            className="flex-1 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed"
          >
            Assign Technician
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChangeTechnicianModal;