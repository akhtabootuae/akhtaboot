import React from 'react';

// Props for cancel part modal
interface CancelPartModalProps {
  isOpen: boolean;                              // Whether modal is open
  partName: string;                             // Name of part being cancelled
  cancelReason: string;                         // Reason for cancellation
  cancelImage: File | null;                     // Approval image file
  onClose: () => void;                          // Close modal handler
  onReasonChange: (reason: string) => void;     // Reason text change handler
  onImageChange: (e: React.ChangeEvent<HTMLInputElement>) => void; // Image change handler
  onConfirm: () => void;                        // Confirm cancellation handler
}

/**
 * CancelPartModal Component
 * 
 * Modal for cancelling a part with approval.
 * - Requires reason text
 * - Requires approval image upload
 * - Confirm button disabled until image uploaded
 */
const CancelPartModal: React.FC<CancelPartModalProps> = ({
  isOpen,
  partName,
  cancelReason,
  cancelImage,
  onClose,
  onReasonChange,
  onImageChange,
  onConfirm
}) => {
  // Don't render if not open
  if (!isOpen) return null;

  return (
    // Modal overlay
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      {/* Modal content */}
      <div className="bg-white rounded-lg p-4 md:p-6 w-full max-w-full md:max-w-md">
        <h3 className="text-lg md:text-xl font-bold mb-3 md:mb-4 text-red-600">Cancel Part: {partName}</h3>
        
        <div className="space-y-4">
          {/* Cancellation reason */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Reason for Cancellation
            </label>
            <textarea
              value={cancelReason}
              onChange={(e) => onReasonChange(e.target.value)}
              className="w-full p-3 border border-gray-300 rounded-md focus:ring-red-500 focus:border-red-500"
              rows={3}
              placeholder="Please provide a reason for cancelling this part..."
            />
          </div>
          
          {/* Approval image upload */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Approval Image *
            </label>
            <input
              type="file"
              accept="image/*"
              onChange={onImageChange}
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-red-500 focus:border-red-500"
              required
            />
            {/* Show selected file name */}
            {cancelImage && (
              <p className="text-sm text-green-600 mt-1">✓ Image selected: {cancelImage.name}</p>
            )}
            <p className="text-xs text-gray-500 mt-1">
              Required: Upload approval image from WhatsApp or other source
            </p>
          </div>
        </div>
        
        {/* Action buttons */}
        <div className="flex justify-end space-x-3 mt-6">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            disabled={!cancelImage}
            className={`px-4 py-2 rounded font-medium ${
              cancelImage 
                ? 'bg-red-600 text-white hover:bg-red-700' 
                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }`}
          >
            Confirm Cancellation
          </button>
        </div>
      </div>
    </div>
  );
};

export default CancelPartModal;