import React, { useState } from 'react';

// QA checkpoint structure
interface QACheckpoint {
  id: number;
  requirement: string;
  checked: boolean;
}

// QA data structure for submission
export interface QAData {
  qaPerformerName: string;
  checkpoints: QACheckpoint[];
  photos: File[];
}

// Props for QA modal
interface QualityAssuranceModalProps {
  isOpen: boolean;                          // Whether modal is open
  checkpoints: QACheckpoint[];              // List of QA checkpoints
  onClose: () => void;                      // Close modal handler
  onCheckpointChange: (checkpointId: number) => void;  // Checkbox change handler
  onSubmit?: (qaData: QAData) => void;      // Submit handler with QA data
}

/**
 * QualityAssuranceModal Component
 * 
 * Enhanced modal for performing quality assurance checks.
 * - QA performer name input
 * - Quality checkpoints with checkboxes
 * - Mandatory photo uploads (3-5 photos required)
 * - Form validation before submission
 */
const QualityAssuranceModal: React.FC<QualityAssuranceModalProps> = ({
  isOpen,
  checkpoints,
  onClose,
  onCheckpointChange,
  onSubmit
}) => {
  // Form state
  const [qaPerformerName, setQaPerformerName] = useState('');
  const [uploadedPhotos, setUploadedPhotos] = useState<File[]>([]);
  const [dragActive, setDragActive] = useState(false);

  // Constants
  const MIN_PHOTOS = 3;
  const MAX_PHOTOS = 5;

  // Reset form when modal opens/closes
  React.useEffect(() => {
    if (isOpen) {
      setQaPerformerName('');
      setUploadedPhotos([]);
    }
  }, [isOpen]);

  // Handle file selection
  const handleFileSelect = (files: FileList | null) => {
    if (!files) return;

    const newFiles = Array.from(files).filter(file => {
      // Only accept image files
      return file.type.startsWith('image/');
    });

    setUploadedPhotos(prev => {
      const combined = [...prev, ...newFiles];
      // Limit to maximum photos
      return combined.slice(0, MAX_PHOTOS);
    });
  };

  // Handle drag and drop
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files) {
      handleFileSelect(e.dataTransfer.files);
    }
  };

  // Remove photo
  const removePhoto = (index: number) => {
    setUploadedPhotos(prev => prev.filter((_, i) => i !== index));
  };

  // Validation
  const isFormValid = () => {
    const allCheckboxesChecked = checkpoints.every(checkpoint => checkpoint.checked);
    const nameProvided = qaPerformerName.trim().length > 0;
    const sufficientPhotos = uploadedPhotos.length >= MIN_PHOTOS;
    
    return allCheckboxesChecked && nameProvided && sufficientPhotos;
  };

  // Handle form submission
  const handleSubmit = () => {
    if (!isFormValid()) {
      let errorMessage = 'Please complete all requirements:\n';
      
      if (qaPerformerName.trim().length === 0) {
        errorMessage += '• Enter your name\n';
      }
      
      if (!checkpoints.every(checkpoint => checkpoint.checked)) {
        errorMessage += '• Check all quality requirements\n';
      }
      
      if (uploadedPhotos.length < MIN_PHOTOS) {
        errorMessage += `• Upload at least ${MIN_PHOTOS} photos\n`;
      }
      
      console.error(errorMessage);
      return;
    }

    // Submit QA data
    if (onSubmit) {
      const qaData: QAData = {
        qaPerformerName: qaPerformerName.trim(),
        checkpoints,
        photos: uploadedPhotos
      };
      onSubmit(qaData);
    }
    
    // Close modal
    onClose();
  };

  // Don't render if not open
  if (!isOpen) return null;

  return (
    // Modal overlay
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      {/* Modal content */}
      <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <h3 className="text-2xl font-bold mb-6 text-gray-900">Quality Assurance Check</h3>
        
        {/* QA Performer Name */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            QA Performed By *
          </label>
          <input
            type="text"
            value={qaPerformerName}
            onChange={(e) => setQaPerformerName(e.target.value)}
            placeholder="Enter your full name"
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            required
          />
        </div>

        {/* Quality Checkpoints */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-3">
            Quality Requirements *
          </label>
          <div className="space-y-3 bg-gray-50 p-4 rounded-lg">
            {checkpoints.map(checkpoint => (
              <label key={checkpoint.id} className="flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={checkpoint.checked}
                  onChange={() => onCheckpointChange(checkpoint.id)}
                  className="mr-3 h-4 w-4 text-blue-600 rounded focus:ring-blue-500"
                />
                <span className="text-sm text-gray-700">{checkpoint.requirement}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Photo Upload Section */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Quality Documentation Photos * ({MIN_PHOTOS}-{MAX_PHOTOS} photos required)
          </label>
          
          {/* Upload Area */}
          <div
            className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${
              dragActive 
                ? 'border-blue-500 bg-blue-50' 
                : uploadedPhotos.length >= MIN_PHOTOS 
                  ? 'border-green-500 bg-green-50' 
                  : 'border-gray-300 bg-gray-50'
            }`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            <div className="space-y-2">
              <svg className="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48">
                <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              <div className="text-sm text-gray-600">
                <label className="cursor-pointer">
                  <span className="text-blue-600 hover:text-blue-500 font-medium">Upload photos</span>
                  <span> or drag and drop</span>
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    onChange={(e) => handleFileSelect(e.target.files)}
                    className="hidden"
                  />
                </label>
              </div>
              <p className="text-xs text-gray-500">PNG, JPG, JPEG up to 10MB each</p>
              <p className="text-sm font-medium text-gray-700">
                {uploadedPhotos.length}/{MAX_PHOTOS} photos uploaded
                {uploadedPhotos.length < MIN_PHOTOS && (
                  <span className="text-red-600"> (Need {MIN_PHOTOS - uploadedPhotos.length} more)</span>
                )}
              </p>
            </div>
          </div>

          {/* Photo Preview Grid */}
          {uploadedPhotos.length > 0 && (
            <div className="mt-4 grid grid-cols-2 md:grid-cols-3 gap-3">
              {uploadedPhotos.map((file, index) => (
                <div key={index} className="relative group">
                  <img
                    src={URL.createObjectURL(file)}
                    alt={`QA Photo ${index + 1}`}
                    className="w-full h-24 object-cover rounded-lg border border-gray-200"
                  />
                  <button
                    onClick={() => removePhoto(index)}
                    className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-500"
                  >
                    ×
                  </button>
                  <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-50 text-white text-xs p-1 rounded-b-lg truncate">
                    {file.name}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Form Actions */}
        <div className="flex justify-between items-center pt-4 border-t border-gray-200">
          <div className="text-sm text-gray-600">
            {isFormValid() ? (
              <span className="text-green-600 font-medium">✓ All requirements completed</span>
            ) : (
              <span className="text-gray-500">Complete all requirements to submit</span>
            )}
          </div>
          
          <div className="flex space-x-3">
            <button
              onClick={onClose}
              className="px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-500"
            >
              Cancel
            </button>
            <button
              onClick={handleSubmit}
              disabled={!isFormValid()}
              className={`px-6 py-2 rounded-md font-medium focus:outline-none focus:ring-2 ${
                isFormValid()
                  ? 'bg-blue-600 text-white hover:bg-blue-700 focus:ring-blue-500'
                  : 'bg-gray-300 text-gray-500 cursor-not-allowed'
              }`}
            >
              Submit QA Report
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QualityAssuranceModal;