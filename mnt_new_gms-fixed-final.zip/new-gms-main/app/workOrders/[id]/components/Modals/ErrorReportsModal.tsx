import React, { useState, useEffect } from 'react';
import { dataApi } from '../../../../../services/api';

// Error report interface based on API response
interface ErrorReport {
  _id: string;
  workOrderId: string;
  partIndex: number;
  stageIndex: number;
  reportedStageId: string;
  problematicStageIndex: number;
  reportingTechnicianId: string;
  problematicTechnicianId: string;
  reportType: 'forward' | 'revert';
  issueDescription: string;
  imageS3Key: string;
  imageUrl: string;
  imageSignedUrl: string;
  imageName: string;
  imageSize: number;
  timestamp: string;
  status: 'pending' | 'acknowledged' | 'resolved';
  stagesToRedo: number[];
  reportingTechnician: {
    _id: string;
    name: string;
    email: string;
  };
  problematicTechnician: {
    _id: string;
    name: string;
    email: string;
  };
}

// Props for the error reports modal
interface ErrorReportsModalProps {
  isOpen: boolean;
  workOrderId: string;
  errorReports: ErrorReport[];
  onClose: () => void;
  onSelectErrorReport: (errorReport: ErrorReport) => void;
  onRefresh: () => void;
}

/**
 * ErrorReportsModal Component
 * 
 * Modal that displays all error reports for a work order.
 * Shows a list view with basic info and allows clicking for details.
 */
const ErrorReportsModal: React.FC<ErrorReportsModalProps> = ({
  isOpen,
  workOrderId,
  errorReports,
  onClose,
  onSelectErrorReport,
  onRefresh
}) => {
  const [technicians, setTechnicians] = useState<{[id: string]: {name: string, email: string}}>({});
  const [loadingTechnicians, setLoadingTechnicians] = useState(false);

  
  // Fetch technician details
  useEffect(() => {
    if (!isOpen || !errorReports || errorReports.length === 0) return;

    const fetchTechnicians = async () => {
      setLoadingTechnicians(true);
      const technicianIds = new Set<string>();
      
      // Collect all unique technician IDs
      errorReports.forEach(report => {
        if (report.reportingTechnicianId) technicianIds.add(report.reportingTechnicianId);
        if (report.problematicTechnicianId) technicianIds.add(report.problematicTechnicianId);
      });

      const techData: {[id: string]: {name: string, email: string}} = {};
      
      // Fetch each technician's details
      for (const techId of technicianIds) {
        try {
          console.log(`Fetching technician data for ID: ${techId}`);
          const response = await dataApi.getUserById(techId);
          console.log(`API response for ${techId}:`, response);
          
          if (response) {
            const techName = response.name || `${response.first_name || ''} ${response.last_name || ''}`.trim() || 'Unknown';
            techData[techId] = {
              name: techName,
              email: response.email || 'N/A'
            };
            console.log(`Stored technician data for ${techId}:`, techData[techId]);
          }
        } catch (error) {
          console.error(`Error fetching technician ${techId}:`, error);
          techData[techId] = {
            name: 'API Error',
            email: 'N/A'
          };
        }
      }
      
      console.log('Final technicians data:', techData);
      setTechnicians(techData);
      setLoadingTechnicians(false);
    };

    fetchTechnicians();
  }, [isOpen, errorReports]);
  
  if (!isOpen) return null;

  // Helper function to format timestamp
  const formatDate = (timestamp: string) => {
    return new Date(timestamp).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Helper function to get status color
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'acknowledged':
        return 'bg-blue-100 text-blue-800';
      case 'resolved':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  // Helper function to get report type color
  const getReportTypeColor = (type: string) => {
    switch (type) {
      case 'forward':
        return 'bg-orange-100 text-orange-800';
      case 'revert':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
          <div>
            <h2 className="text-xl font-semibold text-gray-900">Error Reports</h2>
            <p className="text-sm text-gray-600">Work Order: {workOrderId}</p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={onRefresh}
              className="px-3 py-1 text-sm bg-blue-600 text-white rounded hover:bg-blue-700"
            >
              Refresh
            </button>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 text-2xl"
            >
              ×
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(90vh-120px)]">
          {errorReports.length === 0 ? (
            <div className="text-center py-8">
              <div className="text-gray-400 text-6xl mb-4">📋</div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">No Error Reports</h3>
              <p className="text-gray-600">No issues have been reported for any stages in this work order.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {errorReports.map((report) => (
                <div
                  key={report._id}
                  onClick={() => onSelectErrorReport(report)}
                  className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 cursor-pointer transition-colors"
                >
                  <div className="flex gap-2 mb-3">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(report.status || 'pending')}`}>
                      {(report.status || 'pending').charAt(0).toUpperCase() + (report.status || 'pending').slice(1)}
                    </span>
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${getReportTypeColor(report.reportType || 'revert')}`}>
                      {(report.reportType || 'revert') === 'forward' ? 'Forward Check' : 'Issue Report'}
                    </span>
                  </div>

                  <div className="space-y-4">
                    {/* Stage + Time - Large and prominent */}
                    <div className="text-xl font-bold text-gray-900 bg-blue-50 p-3 rounded-lg">
                      Stage {(report.stageIndex ?? 0) + 1} + {report.timestamp ? formatDate(report.timestamp) : 'Unknown date'}
                    </div>
                    
                    {/* Technician Details - Large and clear */}
                    <div className="space-y-3 bg-gray-50 p-4 rounded-lg">
                      <div className="text-lg font-semibold text-gray-800">
                        <span className="text-green-700">Reported by:</span> {
                          loadingTechnicians ? 'Loading...' : 
                          (technicians[report.reportingTechnicianId]?.name || 
                           report.reportingTechnician?.name || 
                           `Unknown (ID: ${report.reportingTechnicianId?.substring(0, 8) || 'N/A'}...)`)
                        }
                      </div>
                      
                      <div className="text-lg font-semibold text-gray-800">
                        <span className="text-red-700">Mistake done by:</span> {
                          loadingTechnicians ? 'Loading...' : 
                          (technicians[report.problematicTechnicianId]?.name || 
                           report.problematicTechnician?.name || 
                           `Technician ID: ${report.problematicTechnicianId?.substring(0, 8)}...`)
                        }
                      </div>
                    </div>
                    
                    {/* Issue description */}
                    <div className="text-base text-gray-700 bg-yellow-50 p-3 rounded-lg">
                      <strong>Description:</strong> {report.issueDescription || 'No description available'}
                    </div>
                  </div>

                  <div className="mt-3 flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      {report.imageSignedUrl && (
                        <span className="text-xs text-gray-500 flex items-center gap-1">
                          📷 Image attached
                        </span>
                      )}
                    </div>
                    <span className="text-xs text-blue-600 font-medium">
                      Click to view details →
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ErrorReportsModal;