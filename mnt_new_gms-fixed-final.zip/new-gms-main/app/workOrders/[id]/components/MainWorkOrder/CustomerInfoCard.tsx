import React from 'react';

// Props for customer info card
interface CustomerInfoCardProps {
  customerName: string;          // Customer's full name
  customerPhone?: string;        // Customer's phone number
  vehicleDisplay: string;        // Vehicle make/model/year
  vehicleColor?: string;         // Vehicle color
  licensePlate?: string;         // License plate number
}

/**
 * CustomerInfoCard Component
 * 
 * Displays customer and vehicle information in a card format.
 * - Shows customer name and phone
 * - Shows vehicle details (make, model, color, plate)
 * - Part of the main work order info grid
 */
const CustomerInfoCard: React.FC<CustomerInfoCardProps> = ({
  customerName,
  customerPhone,
  vehicleDisplay,
  vehicleColor,
  licensePlate
}) => {
  return (
    <div className="bg-white rounded-lg shadow-sm p-4 md:p-6">
      <h2 className="text-base md:text-lg font-semibold text-gray-900 mb-3 md:mb-4">Customer Information</h2>
      <div className="space-y-2 md:space-y-3">
        {/* Customer name */}
        <div className="text-sm md:text-base text-gray-900 font-medium">{customerName}</div>
        
        {/* Customer phone */}
        <div className="text-sm md:text-base text-gray-600">{customerPhone || 'N/A'}</div>
        
        {/* Vehicle info */}
        <div className="text-sm md:text-base text-gray-900 font-medium">
          {vehicleDisplay}
        </div>
        
        {/* Vehicle color and plate in one line on tablets */}
        <div className="text-sm md:text-base text-gray-600">
          <span>{vehicleColor || 'N/A'}</span>
          {vehicleColor && licensePlate && <span className="mx-2">•</span>}
          {licensePlate && <span>Plate: {licensePlate}</span>}
        </div>
      </div>
    </div>
  );
};

export default CustomerInfoCard;