import React from 'react';

// Part data structure
interface Part {
  id: string;
  name: string;
  status: string;
  progress: number;
  technician: string;
  isCancelled: boolean;
}

// Props for parts status grid
interface PartsStatusGridProps {
  parts: Part[];                    // Array of parts
  onPartClick: (partId: string) => void;  // Callback when part is clicked
}

/**
 * PartsStatusGrid Component
 * 
 * Displays a grid of all parts with their current status.
 * - Shows part name, status, technician, and progress
 * - Color-coded status badges
 * - Click on part to see details
 * - Shows cancelled parts with special styling
 */
const PartsStatusGrid: React.FC<PartsStatusGridProps> = ({
  parts,
  onPartClick
}) => {
  // Get color classes based on part status
  const getPartStatusColor = (status: string, isCancelled = false) => {
    if (isCancelled || status === 'cancelled') {
      return 'bg-red-50 text-red-900 border border-red-200';
    }
    
    switch (status) {
      case 'completed': 
        return 'bg-green-100 text-green-800';
      case 'in_progress': 
        return 'bg-blue-100 text-blue-800';
      case 'requires_attention': 
        return 'bg-red-100 text-red-800';
      default: 
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-4 md:p-6">
      <h2 className="text-lg md:text-xl font-semibold text-gray-900 mb-4 md:mb-6">Parts Status</h2>
      
      {/* Grid of parts - optimized for tablets */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
        {parts.map((part) => (
          <div 
            key={part.id} 
            className={`border rounded-lg p-3 md:p-4 transition-shadow ${
              part.isCancelled ? 'opacity-60 cursor-not-allowed' : 'hover:shadow-md cursor-pointer'
            }`}
            onClick={() => !part.isCancelled && onPartClick(part.id)}
          >
            {/* Part header with name and status */}
            <div className="flex justify-between items-start mb-2">
              <h3 className={`text-sm md:text-base font-medium ${part.isCancelled ? 'text-red-900 line-through' : 'text-gray-900'}`}>
                {part.name}
                {part.isCancelled && <span className="text-xs text-red-600 ml-1">(Cancelled)</span>}
              </h3>
              <span className={`px-1.5 md:px-2 py-0.5 md:py-1 rounded-full text-xs font-medium ${getPartStatusColor(part.status, part.isCancelled)}`}>
                {part.status.replace('_', ' ').toUpperCase()}
              </span>
            </div>
            
            {/* Technician assignment */}
            <div className="text-xs md:text-sm text-gray-600 mb-2">
              Technician: {part.technician}
            </div>
            
            {/* Progress bar (not shown for cancelled parts) */}
            {!part.isCancelled && (
              <div className="flex items-center">
                <div className="flex-1 bg-gray-200 rounded-full h-1.5 md:h-2 mr-2">
                  <div 
                    className="bg-blue-600 h-1.5 md:h-2 rounded-full transition-all duration-300" 
                    style={{ width: `${part.progress}%` }}
                  />
                </div>
                <span className="text-xs md:text-sm text-gray-600">{part.progress}%</span>
              </div>
            )}
            
            {/* Cancelled message */}
            {part.isCancelled && (
              <div className="text-xs text-red-600">
                This part has been cancelled.
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default PartsStatusGrid;