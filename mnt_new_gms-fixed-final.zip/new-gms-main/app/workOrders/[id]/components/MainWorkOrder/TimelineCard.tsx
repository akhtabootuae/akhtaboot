import React from 'react';

// Props for timeline card
interface TimelineCardProps {
  createdAt: string;              // When work order was created
  expectedCompletionDate?: string; // Expected completion date
  expectedDays?: number;          // Expected days to complete
  supervisorName: string;         // Supervisor name
  progressPercentage: number;     // Overall progress percentage
  parts?: any[];                  // Parts array to calculate longest stage
}

/**
 * TimelineCard Component
 * 
 * Shows timeline information and overall progress for a work order.
 * - Start and expected end dates
 * - Supervisor assignment
 * - Progress bar with percentage
 * - Warning if approaching deadline (>75% progress)
 */
const TimelineCard: React.FC<TimelineCardProps> = ({
  createdAt,
  expectedCompletionDate,
  expectedDays,
  supervisorName,
  progressPercentage,
  parts
}) => {
  // Format date to readable string
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  // Calculate expected end date if not provided
  const getExpectedEndDate = () => {
    if (expectedCompletionDate) {
      return formatDate(expectedCompletionDate);
    }
    
    // Calculate based on longest stage duration
    if (parts && parts.length > 0) {
      let maxEstimatedHours = 0;
      
      // Find the longest stage across all parts
      parts.forEach(part => {
        if (part.stages && Array.isArray(part.stages)) {
          part.stages.forEach((stage: any) => {
            const estimatedHours = stage.estimatedHours || stage.estimated_hours || 0;
            if (estimatedHours > maxEstimatedHours) {
              maxEstimatedHours = estimatedHours;
            }
          });
        }
      });
      
      // If we found stage hours, calculate expected end date
      if (maxEstimatedHours > 0) {
        const endDate = new Date(createdAt);
        // Convert hours to days (assuming 8-hour workday)
        const workDays = Math.ceil(maxEstimatedHours / 8);
        endDate.setDate(endDate.getDate() + workDays);
        return formatDate(endDate.toISOString());
      }
    }
    
    // Fall back to expected days if provided
    if (expectedDays && createdAt) {
      const endDate = new Date(createdAt);
      endDate.setDate(endDate.getDate() + expectedDays);
      return formatDate(endDate.toISOString());
    }
    
    return 'TBD';
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-4 md:p-6">
      <h2 className="text-base md:text-lg font-semibold text-gray-900 mb-3 md:mb-4">Timeline</h2>
      <div className="space-y-2 md:space-y-3">
        {/* Start date */}
        <div className="text-sm md:text-base">
          <span className="text-gray-600">Started: </span>
          <span className="text-gray-900">{formatDate(createdAt)}</span>
        </div>
        
        {/* Expected end date */}
        <div className="text-sm md:text-base">
          <span className="text-gray-600">Est. End: </span>
          <span className="text-gray-900">{getExpectedEndDate()}</span>
        </div>
        
        {/* Supervisor */}
        <div className="text-sm md:text-base">
          <span className="text-gray-600">Supervisor: </span>
          <span className="text-gray-900">{supervisorName}</span>
        </div>
        
        {/* Progress bar */}
        <div className="mt-3 md:mt-4">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm md:text-base text-gray-600">Overall Progress</span>
            <span className="text-sm md:text-base text-gray-900 font-semibold">{progressPercentage}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2 md:h-3">
            <div 
              className="bg-orange-500 h-2 md:h-3 rounded-full transition-all duration-300" 
              style={{ width: `${progressPercentage}%` }}
            />
          </div>
          
          {/* Warning if approaching deadline */}
          {progressPercentage >= 75 && (
            <div className="flex items-center mt-2 text-xs md:text-sm text-orange-600">
              <svg className="w-3 h-3 md:w-4 md:h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
              Approaching deadline
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TimelineCard;