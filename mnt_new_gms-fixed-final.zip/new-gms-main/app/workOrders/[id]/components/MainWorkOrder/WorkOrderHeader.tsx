import React from 'react';
import { useRouter } from 'next/navigation';
import { FileText, Plus } from 'lucide-react';
import { formatStatus, getStatusBadgeClasses } from '../../../../../lib/workOrderHelpers';

// Props for the work order header component
interface WorkOrderHeaderProps {
  workOrderNumber: string;     // Work order number (e.g., "WO-001")
  workOrderId: string;         // Database ID
  status: string;              // Current status
  onPerformanceReview: () => void;  // Callback for performance review button
  invoiceId?: string;          // Invoice ID for navigation
  onQAClick?: () => void;      // Callback for QA button
  isQAEnabled?: boolean;       // Whether QA is available
  onCreateCase?: () => void;   // Callback for Create Case button
}

/**
 * WorkOrderHeader Component
 * 
 * Displays the main header for a work order page.
 * - Shows work order number and ID
 * - Displays current status with colored badge
 * - Includes performance review button
 */
const WorkOrderHeader: React.FC<WorkOrderHeaderProps> = ({
  workOrderNumber,
  workOrderId,
  status,
  onPerformanceReview,
  invoiceId,
  onQAClick,
  isQAEnabled = false,
  onCreateCase
}) => {
  const router = useRouter();
  
  const handleViewInvoice = () => {
    if (invoiceId) {
      router.push(`/Invoices/${invoiceId}`);
    }
  };
  
  return (
    <div className="mb-4 md:mb-8">
      <div className="flex flex-col md:flex-row md:justify-between md:items-start gap-3">
        {/* Left side - Title and ID */}
        <div>
          <h1 className="text-xl md:text-3xl font-bold text-gray-900 mb-1 md:mb-2">
            Work Order #{workOrderNumber}
          </h1>
          <p className="text-sm md:text-base text-gray-600">ID: {workOrderId}</p>
        </div>
        
        {/* Right side - Status and actions */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Status badge with dynamic colors */}
          <span className={`px-3 py-1 md:px-4 md:py-2 rounded-full text-xs md:text-sm font-medium ${getStatusBadgeClasses(status)}`}>
            {formatStatus(status)}
          </span>
          
          {/* View Invoice button */}
          {invoiceId ? (
            <button 
              onClick={handleViewInvoice}
              className="px-3 py-1 md:px-4 md:py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors flex items-center gap-1 md:gap-2 text-xs md:text-sm"
              title="View the invoice for this work order"
            >
              <FileText className="w-3 h-3 md:w-4 md:h-4" />
              <span className="hidden sm:inline">View</span> Invoice
            </button>
          ) : (
            <button 
              disabled
              className="px-3 py-1 md:px-4 md:py-2 bg-gray-300 text-gray-500 rounded-lg cursor-not-allowed flex items-center gap-1 md:gap-2 text-xs md:text-sm"
              title="No invoice associated with this work order"
            >
              <FileText className="w-3 h-3 md:w-4 md:h-4" />
              No Invoice
            </button>
          )}
          
          {/* QA button */}
          {onQAClick && (
            <button 
              onClick={onQAClick}
              disabled={!isQAEnabled}
              className={`px-3 py-1 md:px-4 md:py-2 rounded-lg transition-colors flex items-center gap-1 md:gap-2 text-xs md:text-sm ${
                isQAEnabled 
                  ? 'bg-purple-600 text-white hover:bg-purple-700' 
                  : 'bg-gray-300 text-gray-500 cursor-not-allowed'
              }`}
              title={isQAEnabled ? "Perform Quality Assurance" : "Complete at least one work order part to enable QA"}
            >
              <FileText className="w-3 h-3 md:w-4 md:h-4" />
              <span className="hidden sm:inline">Quality</span> QA
            </button>
          )}
          
          {/* Create Case button */}
          {onCreateCase && (
            <button 
              onClick={onCreateCase}
              className="px-3 py-1 md:px-4 md:py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-xs md:text-sm flex items-center gap-1 md:gap-2"
              title="Create a case linked to this work order"
            >
              <Plus className="w-3 h-3 md:w-4 md:h-4" />
              <span className="hidden sm:inline">Create</span> Case
            </button>
          )}
          
          {/* Performance review button */}
          <button 
            onClick={onPerformanceReview}
            className="px-3 py-1 md:px-4 md:py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors text-xs md:text-sm"
          >
            <span className="hidden sm:inline">Performance</span> Review
          </button>
        </div>
      </div>
    </div>
  );
};

export default WorkOrderHeader;