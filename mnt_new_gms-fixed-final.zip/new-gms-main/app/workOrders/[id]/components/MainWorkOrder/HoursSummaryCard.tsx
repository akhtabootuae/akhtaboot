import React from 'react';

// Props for hours summary card
interface HoursSummaryCardProps {
  totalEstimatedHours?: number;        // Total estimated hours
  totalActualHours?: number;           // Total actual hours used
  expectedDays?: number;               // Expected days (if no hours provided)
  expectedCompletionDate?: string;     // Expected completion date
  createdAt?: string;                  // Creation date (for calculating end date)
}

/**
 * HoursSummaryCard Component
 * 
 * Displays summary of estimated vs actual hours for the work order.
 * - Shows estimated hours (or converts from days)
 * - Shows actual hours used
 * - Shows expected completion date
 * - Calculates estimated end date if not provided
 */
const HoursSummaryCard: React.FC<HoursSummaryCardProps> = ({
  totalEstimatedHours,
  totalActualHours,
  expectedDays,
  expectedCompletionDate,
  createdAt
}) => {
  // Format date to readable string
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  // Get estimated hours display
  const getEstimatedHoursDisplay = () => {
    if (totalEstimatedHours) {
      return `${totalEstimatedHours}h`;
    }
    if (expectedDays) {
      // Convert days to hours (8 hours per day)
      return `${expectedDays * 8}h (${expectedDays} days × 8h)`;
    }
    return '0h';
  };

  // Calculate estimated end date if not provided
  const getEstimatedEndDate = () => {
    if (expectedCompletionDate) {
      return formatDate(expectedCompletionDate);
    }
    if (expectedDays && createdAt) {
      const endDate = new Date(createdAt);
      endDate.setDate(endDate.getDate() + expectedDays);
      return formatDate(endDate.toISOString());
    }
    return null;
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-4 md:p-6">
      <h2 className="text-base md:text-lg font-semibold text-gray-900 mb-3 md:mb-4">Hours Summary</h2>
      <div className="space-y-2 md:space-y-3">
        {/* Estimated hours */}
        <div className="text-sm md:text-base">
          <span className="text-gray-600">Estimated: </span>
          <span className="text-gray-900 font-semibold">
            {getEstimatedHoursDisplay()}
          </span>
        </div>
        
        {/* Actual hours */}
        <div className="text-sm md:text-base">
          <span className="text-gray-600">Actual: </span>
          <span className="text-gray-900 font-semibold">
            {totalActualHours || 0}h
          </span>
        </div>
        
        {/* Expected days (if provided) */}
        {expectedDays && (
          <div className="text-sm md:text-base">
            <span className="text-gray-600">Expected Days: </span>
            <span className="text-gray-900 font-semibold">{expectedDays} days</span>
          </div>
        )}
        
        {/* Expected completion date */}
        {expectedCompletionDate && (
          <div className="text-sm md:text-base">
            <span className="text-gray-600">Expected By: </span>
            <span className="text-gray-900 font-semibold">
              {formatDate(expectedCompletionDate)}
            </span>
          </div>
        )}
        
        {/* Calculated end date (if no explicit completion date) */}
        {!expectedCompletionDate && getEstimatedEndDate() && (
          <div className="text-sm md:text-base">
            <span className="text-gray-600">Estimated End: </span>
            <span className="text-gray-900 font-semibold">
              {getEstimatedEndDate()}
            </span>
          </div>
        )}
      </div>
    </div>
  );
};

export default HoursSummaryCard;