import React, { useState, useEffect } from 'react';
import api from '../../../../../services/api';

// Props for the countdown timer component
interface CountdownTimerProps {
  startTime: string | null;      // When the timer started
  estimatedHours: number;        // How many hours were estimated
  status: string;                // Current status (in_progress, paused, etc)
  workOrderId?: string;          // Work order ID for notifications
  stageId?: string;              // Stage ID for notifications
  pausedDuration?: number;       // Total paused duration in seconds
  supervisorId?: string;         // Supervisor ID for notifications
}

/**
 * CountdownTimer Component
 * 
 * Shows how much time is left for a task based on estimated hours.
 * - Counts down from estimated time when task is in progress
 * - Shows negative time if task exceeds estimate
 * - Sends alert when 70% of time is used
 * - Pauses when status is 'paused'
 */
const CountdownTimer: React.FC<CountdownTimerProps> = ({ 
  startTime, 
  estimatedHours,
  status,
  workOrderId,
  stageId,
  pausedDuration = 0,
  supervisorId
}) => {
  const [timeDisplay, setTimeDisplay] = useState<string>("00:00:00");
  const [isExpired, setIsExpired] = useState<boolean>(false);
  const [has75PercentAlertSent, setHas75PercentAlertSent] = useState<boolean>(false);

  // Helper function to format numbers with leading zeros (e.g., 5 -> "05")
  const formatTimeUnit = (unit: number): string => {
    return unit.toString().padStart(2, '0');
  };
  
  // Convert seconds to HH:MM:SS format
  const formatTime = (totalSeconds: number): string => {
    if (totalSeconds < 0) {
      // If time is negative (overdue), show with minus sign
      const absSeconds = Math.abs(totalSeconds);
      const hours = Math.floor(absSeconds / 3600);
      const minutes = Math.floor((absSeconds % 3600) / 60);
      const seconds = Math.floor(absSeconds % 60);
      return `-${formatTimeUnit(hours)}:${formatTimeUnit(minutes)}:${formatTimeUnit(seconds)}`;
    } else {
      // Normal countdown display
      const hours = Math.floor(totalSeconds / 3600);
      const minutes = Math.floor((totalSeconds % 3600) / 60);
      const seconds = Math.floor(totalSeconds % 60);
      return `${formatTimeUnit(hours)}:${formatTimeUnit(minutes)}:${formatTimeUnit(seconds)}`;
    }
  };

  // Send notification when 75% of estimated time is used
  const sendTimeAlert = async (percentComplete: number, workOrderId?: string, stageId?: string) => {
    try {
      console.log(`Alert: ${percentComplete}% of estimated time has been used`);
      
      // Create notification data
      const notificationData = {
        type: 'time_alert',
        title: 'Time Alert: 75% Time Used',
        message: `Work order stage has used ${percentComplete}% of estimated time`,
        workOrderId: workOrderId,
        stageId: stageId,
        percentComplete,
        priority: 'high',
        status: 'unread',
        createdAt: new Date().toISOString(),
        recipientType: 'supervisor',
        recipientId: supervisorId, // Add supervisor ID to target specific supervisor
        metadata: {
          alertType: 'time_usage',
          threshold: percentComplete
        }
      };
      
      // Try to send notification to API
      try {
        await api.post('/api/notifications', notificationData);
        console.log('Time alert notification created successfully');
      } catch (apiError) {
        console.warn('Notifications API not available, using fallback logging:', apiError);
        console.log('TIME ALERT NOTIFICATION:', JSON.stringify(notificationData, null, 2));
      }
    } catch (error) {
      console.error("Failed to send time alert:", error);
    }
  };

  useEffect(() => {
    // If no start time or status is not active, just show estimated time
    if (!startTime || (status?.toLowerCase() !== "in_progress" && status?.toLowerCase() !== "paused")) {
      const estSeconds = Math.floor((estimatedHours || 1) * 3600);
      setTimeDisplay(formatTime(estSeconds));
      setIsExpired(false);
      return;
    }
    
    // Function to update the timer display
    const updateTimer = () => {
      try {
        const start = new Date(startTime).getTime();
        const now = new Date().getTime();
        const totalElapsed = Math.floor((now - start) / 1000); // Total time elapsed in seconds
        const workingElapsed = totalElapsed - pausedDuration; // Actual working time (excluding pauses)
        const estSeconds = Math.floor((estimatedHours || 1) * 3600); // Estimated time in seconds
        const remaining = estSeconds - workingElapsed; // Time remaining
        
        // Calculate percentage of time used (based on working time)
        const percentUsed = Math.floor((workingElapsed / estSeconds) * 100);
        
        // Send alert when 75% of time is used (only once)
        if (percentUsed >= 75 && !has75PercentAlertSent && status?.toLowerCase() === "in_progress") {
          setHas75PercentAlertSent(true);
          sendTimeAlert(75, workOrderId, stageId);
        }
        
        // Check if time has expired
        setIsExpired(remaining <= 0);
        setTimeDisplay(formatTime(remaining));
      } catch (error) {
        console.error("Timer calculation error:", error);
        setTimeDisplay(formatTime(Math.floor((estimatedHours || 1) * 3600)));
      }
    };
    
    // Update timer immediately
    updateTimer();
    
    // Only update every second if status is "in_progress" (not when paused)
    let intervalId: NodeJS.Timeout;
    if (status?.toLowerCase() === "in_progress") {
      intervalId = setInterval(updateTimer, 1000);
    }
    
    // Cleanup interval on unmount
    return () => {
      if (intervalId) clearInterval(intervalId);
    };
  }, [startTime, estimatedHours, status, has75PercentAlertSent, workOrderId, stageId, pausedDuration, supervisorId]);

  const isInProgress = status?.toLowerCase() === "in_progress";
  const isPaused = status?.toLowerCase() === "paused";
  
  return (
    <div className="font-mono">
      {/* Time display with color based on status */}
      <span 
        className={`font-bold ${
          timeDisplay.startsWith('-') ? "text-orange-600" :  // Overdue
          isExpired ? "text-red-600" :                       // Time expired
          isInProgress ? "text-green-700" :                  // Active countdown
          isPaused ? "text-yellow-600" :                     // Paused
          "text-gray-500"                                    // Not started
        }`}
      >
        {timeDisplay}
      </span>
      
      {/* Status messages */}
      {!isInProgress && !isPaused && (
        <span className="text-xs text-gray-500 block">
          Estimated time
        </span>
      )}
      
      {isPaused && (
        <span className="text-xs text-yellow-600 block">
          Paused
        </span>
      )}
      
      {isInProgress && timeDisplay.startsWith('-') && (
        <span className="text-xs text-orange-600 block">
          Exceeded estimated time
        </span>
      )}
    </div>
  );
};

export default CountdownTimer;