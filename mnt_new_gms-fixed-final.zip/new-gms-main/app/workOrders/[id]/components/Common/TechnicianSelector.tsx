import React, { useState, useEffect } from 'react';
import api from '../../../../../services/api';

// Props for the technician selector component
interface TechnicianSelectorProps {
  value: string;                                           // Currently selected technician ID
  onChange: (value: string, estimatedHours?: number) => void;  // Callback when selection changes
  workOrderId: number;                                     // Work order ID
  stageId: number;                                        // Stage ID
  onAssignmentComplete: () => void;                       // Callback after assignment
  stageName?: string;                                      // Stage name for filtering technicians
}

// Technician data structure
interface Technician {
  _id: string;
  name: string;
  email: string;
  phone: string;
  role: string;
  user_id?: string;
  technician_name?: string;
  staff_code?: string;
  speciality?: string;
  branch?: any;
}

/**
 * TechnicianSelector Component
 * 
 * Allows selection of a technician and setting estimated hours for a task.
 * - Fetches available technicians from API
 * - Shows technician speciality if available
 * - Includes estimated hours input
 * - Shows loading state while fetching data
 */
const TechnicianSelector: React.FC<TechnicianSelectorProps> = ({
  value,
  onChange,
  workOrderId,
  stageId,
  onAssignmentComplete,
  stageName
}) => {
  const [technicians, setTechnicians] = useState<Technician[]>([]);
  const [filteredTechnicians, setFilteredTechnicians] = useState<Technician[]>([]);
  const [loading, setLoading] = useState(true);
  const [estimatedHours, setEstimatedHours] = useState<number>(1); // Default 1 hour
  const [hours, setHours] = useState<number>(1); // Separate hours input
  const [minutes, setMinutes] = useState<number>(0); // Separate minutes input

  // Map stage names to required specialties
  const getRequiredSpecialty = (stage: string | undefined): string[] => {
    if (!stage) return ['General']; // If no stage specified, show general technicians
    
    const stageMap: { [key: string]: string[] } = {
      // Map stage names to specialties (case-insensitive)
      'fix': ['Fix/Remove'],
      'remove': ['Fix/Remove'],
      'pdr': ['PDR'],
      'paint': ['Paint'],
      'primer': ['Paint'],
      'polish': ['Paint', 'Body Work'],
      'denter': ['Body Work'],
      'magoon': ['Body Work'],
      'repair': ['Body Work', 'Mechanical'],
      // Additional mappings for database stage names
      'Fix': ['Fix/Remove'],
      'Remove': ['Fix/Remove'],
      'PDR': ['PDR'],
      'Paint': ['Paint'],
      'Primer': ['Paint'],
      'Polish': ['Paint', 'Body Work'],
      'Denter': ['Body Work'],
      'Magoon': ['Body Work'],
      'Repair': ['Body Work', 'Mechanical']
    };
    
    // Check map with lowercase first for consistency
    const lowerStage = stage.toLowerCase();
    return stageMap[lowerStage] || stageMap[stage] || ['General'];
  };

  // Fetch technicians when component mounts
  useEffect(() => {
    const fetchTechnicians = async () => {
      try {
        setLoading(true);
        // Get list of technicians from API
        const response = await api.get('/api/users/technicians');
        console.log("Technicians data:", response);
        setTechnicians(response || []);
      } catch (error) {
        console.error("Error fetching technicians:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchTechnicians();
  }, []);

  // Filter technicians based on stage specialty
  useEffect(() => {
    if (technicians.length === 0) {
      setFilteredTechnicians([]);
      return;
    }

    const requiredSpecialties = getRequiredSpecialty(stageName);
    console.log(`Filtering technicians for stage: ${stageName}, required specialties:`, requiredSpecialties);
    
    const filtered = technicians.filter(tech => {
      // If technician has 'General' specialty, they can work on any stage
      if (tech.speciality === 'General') return true;
      
      // If no specialty is set, don't include them
      if (!tech.speciality) return false;
      
      // Check if technician's specialty matches required specialties
      return requiredSpecialties.includes(tech.speciality);
    });
    
    console.log(`Filtered ${filtered.length} technicians from ${technicians.length} total`);
    setFilteredTechnicians(filtered);
  }, [technicians, stageName]);

  // Handle technician selection change
  const handleTechnicianChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const techId = e.target.value;
    onChange(techId, estimatedHours);
  };

  // Handle hours change
  const handleHoursChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newHours = parseInt(e.target.value) || 0;
    // Enforce max 12 hours
    const validHours = Math.min(Math.max(0, newHours), 12);
    setHours(validHours);
    
    // Calculate total hours as decimal
    const totalHours = validHours + (minutes / 60);
    setEstimatedHours(totalHours);
    onChange(value, totalHours);
  };

  // Handle minutes change
  const handleMinutesChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newMinutes = parseInt(e.target.value) || 0;
    // Enforce max 59 minutes
    const validMinutes = Math.min(Math.max(0, newMinutes), 59);
    setMinutes(validMinutes);
    
    // Calculate total hours as decimal
    const totalHours = hours + (validMinutes / 60);
    setEstimatedHours(totalHours);
    onChange(value, totalHours);
  };

  // Show loading spinner while fetching data
  if (loading) {
    return <div className="animate-pulse bg-gray-200 h-10 w-full rounded"></div>;
  }

  return (
    <div className="space-y-3">
      {/* Technician dropdown */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Assign Technician
        </label>
        <select
          value={value}
          onChange={handleTechnicianChange}
          className="block w-full rounded-md border border-gray-300 p-2 focus:border-blue-500 focus:ring-blue-500"
        >
          <option value="">Select Technician</option>
          {filteredTechnicians.map((tech) => (
            <option key={tech._id} value={tech._id}>
              {tech.name} {tech.speciality ? `(${tech.speciality})` : ''}
            </option>
          ))}
        </select>
        {filteredTechnicians.length === 0 && technicians.length > 0 && (
          <p className="text-sm text-orange-600 mt-1">
            No technicians available with the required specialty for this stage.
          </p>
        )}
      </div>

      {/* Estimated time inputs */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Estimated Time
        </label>
        <div className="flex gap-2">
          {/* Hours input */}
          <div className="flex-1">
            <div className="relative">
              <input
                type="number"
                min="0"
                max="12"
                value={hours}
                onChange={handleHoursChange}
                className="block w-full rounded-md border border-gray-300 p-2 pr-12 focus:border-blue-500 focus:ring-blue-500"
                placeholder="0"
              />
              <span className="absolute right-2 top-2 text-sm text-gray-500">hrs</span>
            </div>
          </div>
          
          {/* Minutes input */}
          <div className="flex-1">
            <div className="relative">
              <input
                type="number"
                min="0"
                max="59"
                value={minutes}
                onChange={handleMinutesChange}
                className="block w-full rounded-md border border-gray-300 p-2 pr-12 focus:border-blue-500 focus:ring-blue-500"
                placeholder="0"
              />
              <span className="absolute right-2 top-2 text-sm text-gray-500">min</span>
            </div>
          </div>
        </div>
        <p className="mt-1 text-xs text-gray-500">
          Max: 12 hours 59 minutes
        </p>
      </div>
    </div>
  );
};

export default TechnicianSelector;