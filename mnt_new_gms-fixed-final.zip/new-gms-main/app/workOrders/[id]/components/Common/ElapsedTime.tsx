import React, { useState, useEffect } from 'react';

// Props for the elapsed time component
interface ElapsedTimeProps {
  startTime: string | null;    // When the timer started
  endTime?: string | null;     // When the timer ended (optional)
  pausedDuration?: number;     // Total paused duration in seconds
}

/**
 * ElapsedTime Component
 * 
 * Shows how much time has passed since a task started.
 * - Shows "Not started" if no start time
 * - Counts up continuously if task is ongoing
 * - Shows fixed time if task has ended
 * - Formats as days/hours/minutes for long durations
 */
const ElapsedTime: React.FC<ElapsedTimeProps> = ({ startTime, endTime, pausedDuration = 0 }) => {
  const [timeDisplay, setTimeDisplay] = useState<string>("Not started");
  
  // Helper function to format numbers with leading zeros
  const formatTimeUnit = (unit: number): string => {
    return unit.toString().padStart(2, '0');
  };
  
  // Convert seconds to readable format
  const formatTime = (totalSeconds: number): string => {
    // For very long durations (over 24 hours), show days
    if (totalSeconds >= 86400) {
      const days = Math.floor(totalSeconds / 86400);
      const remainingHours = Math.floor((totalSeconds % 86400) / 3600);
      const remainingMinutes = Math.floor((totalSeconds % 3600) / 60);
      
      let timeString = `${days} day${days !== 1 ? 's' : ''}`;
      
      if (remainingHours > 0) {
        timeString += ` ${remainingHours} hour${remainingHours !== 1 ? 's' : ''}`;
      }
      
      if (remainingMinutes > 0) {
        timeString += ` ${remainingMinutes} minute${remainingMinutes !== 1 ? 's' : ''}`;
      }
      
      return timeString;
    }
    
    // For shorter durations, show HH:MM:SS
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = Math.floor(totalSeconds % 60);
    return `${formatTimeUnit(hours)}:${formatTimeUnit(minutes)}:${formatTimeUnit(seconds)}`;
  };

  useEffect(() => {
    // If no start time, show "Not started"
    if (!startTime) {
      setTimeDisplay("Not started");
      return;
    }

    // Function to calculate and update elapsed time
    const updateTimer = () => {
      try {
        if (endTime) {
          // If task has ended, calculate time between start and end
          const start = new Date(startTime).getTime();
          const end = new Date(endTime).getTime();
          const elapsed = Math.max(0, Math.floor((end - start) / 1000));
          setTimeDisplay(formatTime(elapsed));
          return;
        }
        
        // If task is ongoing, calculate time from start to now
        const start = new Date(startTime).getTime();
        const now = new Date().getTime();
        const elapsed = Math.max(0, Math.floor((now - start) / 1000));
        setTimeDisplay(formatTime(elapsed));
      } catch (error) {
        console.error("Elapsed time calculation error:", error);
        setTimeDisplay("Error");
      }
    };
    
    // Update immediately
    updateTimer();
    
    // Only set interval if task is ongoing (no end time)
    let intervalId: NodeJS.Timeout | null = null;
    if (!endTime) {
      intervalId = setInterval(updateTimer, 1000);
    }
    
    // Cleanup interval on unmount
    return () => {
      if (intervalId) clearInterval(intervalId);
    };
  }, [startTime, endTime, pausedDuration]);

  const isRunning = startTime && !endTime;

  return (
    <div className="flex flex-col">
      {/* Time display with color based on status */}
      <span className={`font-bold ${
        timeDisplay === "Not started" ? "text-gray-500" :
        timeDisplay === "Error" ? "text-red-600" :
        endTime ? "text-blue-600" : "text-blue-700"
      }`}>
        {timeDisplay}
      </span>
      
      {/* Show "Running" indicator if timer is active */}
      {isRunning && (
        <span className="text-xs text-blue-600">
          Running
        </span>
      )}
    </div>
  );
};

export default ElapsedTime;