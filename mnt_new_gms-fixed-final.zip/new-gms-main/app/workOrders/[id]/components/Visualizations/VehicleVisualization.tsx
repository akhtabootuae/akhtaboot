import React, { useState } from 'react';

// Props for vehicle visualization
interface VehicleVisualizationProps {
  onPartClick: (partId: string) => void;  // Handler when part is clicked
}

/**
 * VehicleVisualization Component
 * 
 * Interactive SVG drawing of a vehicle showing all parts.
 * - Side view and top view of car
 * - Clickable parts that highlight on hover
 * - Different colors for different part types
 * - Used to navigate to specific part work orders
 */
const VehicleVisualization: React.FC<VehicleVisualizationProps> = ({ onPartClick }) => {
  const [isCollapsed, setIsCollapsed] = useState(false);

  return (
    <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold text-gray-900">Vehicle Overview</h2>
        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          aria-label={isCollapsed ? "Expand vehicle overview" : "Collapse vehicle overview"}
        >
          <svg 
            className={`w-5 h-5 transform transition-transform ${isCollapsed ? 'rotate-180' : ''}`}
            fill="none" 
            stroke="currentColor" 
            viewBox="0 0 24 24"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </button>
      </div>
      {!isCollapsed && (
        <>
          <div className="flex justify-center">
            <div className="relative">
              {/* SVG drawing of the car */}
              <svg width="800" height="600" viewBox="0 0 800 600" className="border border-gray-200 rounded-lg">
                {/* Side view of car */}
                <g transform="translate(50, 350)">
                  {/* Car body outline */}
                  <path 
                    d="M50 0 L150 -30 L550 -30 L650 0 L650 80 L600 80 L600 100 L550 100 L550 80 L150 80 L150 100 L100 100 L100 80 L50 80 Z" 
                    fill="#f0f9ff" 
                    stroke="#1e40af" 
                    strokeWidth="2"
                  />
                  
                  {/* Windshield - clickable */}
                  <path 
                    d="M150 -30 L200 -60 L450 -60 L500 -30" 
                    fill="#d1fae5" 
                    stroke="#10b981" 
                    strokeWidth="2" 
                    className="cursor-pointer hover:fill-green-200 transition-colors"
                    onClick={() => onPartClick('windshield')}
                  />
                  
                  {/* Left window - clickable */}
                  <rect 
                    x="220" y="-60" width="80" height="30" 
                    fill="#d1fae5" 
                    stroke="#10b981" 
                    strokeWidth="1" 
                    className="cursor-pointer hover:fill-green-200 transition-colors"
                    onClick={() => onPartClick('left-window')}
                  />
                  
                  {/* Right window - clickable */}
                  <rect 
                    x="320" y="-60" width="80" height="30" 
                    fill="#d1fae5" 
                    stroke="#10b981" 
                    strokeWidth="1" 
                    className="cursor-pointer hover:fill-green-200 transition-colors"
                    onClick={() => onPartClick('right-window')}
                  />
                  
                  {/* Left door - clickable */}
                  <rect 
                    x="200" y="-30" width="120" height="80" 
                    fill="#e5e7eb" 
                    stroke="#6b7280" 
                    strokeWidth="2" 
                    className="cursor-pointer hover:fill-gray-300 transition-colors"
                    onClick={() => onPartClick('left-door')}
                  />
                  
                  {/* Right door - clickable */}
                  <rect 
                    x="380" y="-30" width="120" height="80" 
                    fill="#e5e7eb" 
                    stroke="#6b7280" 
                    strokeWidth="2" 
                    className="cursor-pointer hover:fill-gray-300 transition-colors"
                    onClick={() => onPartClick('right-door')}
                  />
                  
                  {/* Front bumper - clickable */}
                  <rect 
                    x="0" y="20" width="50" height="40" 
                    fill="#fbbf24" 
                    stroke="#f59e0b" 
                    strokeWidth="2" 
                    rx="5"
                    className="cursor-pointer hover:fill-yellow-300 transition-colors"
                    onClick={() => onPartClick('front-bumper')}
                  />
                  
                  {/* Rear bumper - clickable */}
                  <rect 
                    x="650" y="20" width="50" height="40" 
                    fill="#fbbf24" 
                    stroke="#f59e0b" 
                    strokeWidth="2" 
                    rx="5"
                    className="cursor-pointer hover:fill-yellow-300 transition-colors"
                    onClick={() => onPartClick('rear-bumper')}
                  />
                  
                  {/* Front left wheel - clickable */}
                  <circle 
                    cx="150" cy="100" r="25" 
                    fill="#374151" 
                    stroke="#1f2937" 
                    strokeWidth="3"
                    className="cursor-pointer hover:fill-gray-500 transition-colors"
                    onClick={() => onPartClick('front-left-wheel')}
                  />
                  <circle cx="150" cy="100" r="15" fill="#6b7280"/>
                  
                  {/* Front right wheel - clickable */}
                  <circle 
                    cx="550" cy="100" r="25" 
                    fill="#374151" 
                    stroke="#1f2937" 
                    strokeWidth="3"
                    className="cursor-pointer hover:fill-gray-500 transition-colors"
                    onClick={() => onPartClick('front-right-wheel')}
                  />
                  <circle cx="550" cy="100" r="15" fill="#6b7280"/>
                  
                  {/* Headlight - clickable */}
                  <circle 
                    cx="25" cy="30" r="12" 
                    fill="#fef3c7" 
                    stroke="#f59e0b" 
                    strokeWidth="2"
                    className="cursor-pointer hover:fill-yellow-200 transition-colors"
                    onClick={() => onPartClick('headlight')}
                  />
                  
                  {/* Engine compartment - clickable */}
                  <rect 
                    x="50" y="10" width="100" height="60" 
                    fill="#f3f4f6" 
                    stroke="#9ca3af" 
                    strokeWidth="2" 
                    className="cursor-pointer hover:fill-gray-200 transition-colors"
                    onClick={() => onPartClick('engine')}
                  />
                </g>
                
                {/* Top view of car */}
                <g transform="translate(50, 50)">
                  <text x="300" y="20" textAnchor="middle" className="text-sm font-medium fill-gray-700">
                    Top View
                  </text>
                  
                  {/* Car body from top */}
                  <rect 
                    x="250" y="50" width="300" height="150" 
                    fill="#f0f9ff" 
                    stroke="#1e40af" 
                    strokeWidth="2" 
                    rx="20"
                  />
                  
                  {/* Roof */}
                  <rect 
                    x="280" y="80" width="240" height="90" 
                    fill="#e5e7eb" 
                    stroke="#6b7280" 
                    strokeWidth="1" 
                    rx="10"
                  />
                  
                  {/* Left mirror - clickable */}
                  <rect 
                    x="240" y="90" width="8" height="15" 
                    fill="#9ca3af" 
                    rx="2"
                    className="cursor-pointer hover:fill-gray-500 transition-colors"
                    onClick={() => onPartClick('left-mirror')}
                  />
                  
                  {/* Right mirror - clickable */}
                  <rect 
                    x="552" y="90" width="8" height="15" 
                    fill="#9ca3af" 
                    rx="2"
                    className="cursor-pointer hover:fill-gray-500 transition-colors"
                    onClick={() => onPartClick('right-mirror')}
                  />
                  
                  {/* Left window from top - clickable */}
                  <rect 
                    x="300" y="100" width="60" height="70" 
                    fill="#d1fae5" 
                    stroke="#10b981" 
                    strokeWidth="1" 
                    rx="5"
                    className="cursor-pointer hover:fill-green-200 transition-colors"
                    onClick={() => onPartClick('left-window')}
                  />
                  
                  {/* Right window from top - clickable */}
                  <rect 
                    x="440" y="100" width="60" height="70" 
                    fill="#d1fae5" 
                    stroke="#10b981" 
                    strokeWidth="1" 
                    rx="5"
                    className="cursor-pointer hover:fill-green-200 transition-colors"
                    onClick={() => onPartClick('right-window')}
                  />
                </g>
              </svg>
            </div>
          </div>
          
          {/* Instructions */}
          <p className="text-center text-sm text-gray-500 mt-4">
            Click on any car part to view detailed work progress
          </p>
        </>
      )}
    </div>
  );
};

export default VehicleVisualization;