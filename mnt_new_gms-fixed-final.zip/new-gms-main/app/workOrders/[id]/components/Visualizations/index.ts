// Export all visualization components from one place
export { default as VehicleVisualization } from './VehicleVisualization';