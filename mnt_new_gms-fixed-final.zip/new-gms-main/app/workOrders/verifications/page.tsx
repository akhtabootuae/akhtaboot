'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/app/context/AuthContext';
import { errorReportingApi } from '@/services/api';
import { VerificationModal } from '@/app/workOrders/[id]/components/Modals';

// Interface for pending verification
interface PendingVerification {
  _id: string;
  workOrderId: string;
  workOrderNumber: string;
  partName: string;
  stageName: string;
  issueDescription: string;
  imageUrl: string;
  reportedAt: string;
  problematicTechnician: {
    name: string;
    email: string;
  };
}

/**
 * Verifications Page
 * 
 * Shows all pending verifications for the logged-in technician
 * Allows them to complete verifications
 */
export default function VerificationsPage() {
  const router = useRouter();
  const { user } = useAuth();
  
  // State
  const [verifications, setVerifications] = useState<PendingVerification[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selectedVerification, setSelectedVerification] = useState<PendingVerification | null>(null);
  const [showVerificationModal, setShowVerificationModal] = useState(false);

  // Fetch pending verifications
  const fetchVerifications = async () => {
    try {
      setLoading(true);
      setError('');
      
      // Fetch verifications for current user
      const data = await errorReportingApi.getPendingVerifications(user?._id);
      setVerifications(data);
    } catch (err) {
      console.error('Error fetching verifications:', err);
      setError('Failed to load pending verifications');
    } finally {
      setLoading(false);
    }
  };

  // Load verifications on mount
  useEffect(() => {
    if (user?._id) {
      fetchVerifications();
    }
  }, [user]);

  // Handle opening verification modal
  const handleOpenVerification = (verification: PendingVerification) => {
    setSelectedVerification(verification);
    setShowVerificationModal(true);
  };

  // Handle verification completion
  const handleVerificationComplete = () => {
    // Refresh the list
    fetchVerifications();
    setShowVerificationModal(false);
    setSelectedVerification(null);
  };

  // Render loading state
  if (loading) {
    return (
      <div className="p-6 bg-gray-50 min-h-screen">
        <div className="flex justify-center items-center h-64">
          <div className="text-gray-600">Loading pending verifications...</div>
        </div>
      </div>
    );
  }

  // Render error state
  if (error) {
    return (
      <div className="p-6 bg-gray-50 min-h-screen">
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
          {error}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Pending Verifications</h1>
        <p className="text-gray-600">Review and verify reported work quality issues</p>
      </div>

      {/* Verifications list */}
      {verifications.length === 0 ? (
        <div className="bg-white rounded-lg shadow-md p-8 text-center">
          <p className="text-gray-600">No pending verifications at this time</p>
        </div>
      ) : (
        <div className="grid gap-4">
          {verifications.map((verification) => (
            <div key={verification._id} className="bg-white rounded-lg shadow-md p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">
                    Work Order: {verification.workOrderNumber}
                  </h3>
                  <p className="text-sm text-gray-600">
                    Part: {verification.partName} - Stage: {verification.stageName}
                  </p>
                </div>
                <span className="text-sm text-gray-500">
                  {new Date(verification.reportedAt).toLocaleDateString()}
                </span>
              </div>

              <div className="mb-4">
                <p className="text-sm text-gray-700">
                  <span className="font-medium">Issue:</span> {verification.issueDescription}
                </p>
                <p className="text-sm text-gray-600 mt-1">
                  <span className="font-medium">Reported about:</span> {verification.problematicTechnician.name}
                </p>
              </div>

              <button
                onClick={() => handleOpenVerification(verification)}
                className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
              >
                Review & Verify
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Verification Modal */}
      {selectedVerification && (
        <VerificationModal
          isOpen={showVerificationModal}
          errorReportId={selectedVerification._id}
          workOrderNumber={selectedVerification.workOrderNumber}
          stageName={selectedVerification.stageName}
          issueDescription={selectedVerification.issueDescription}
          imageUrl={selectedVerification.imageUrl}
          onClose={() => setShowVerificationModal(false)}
          onComplete={handleVerificationComplete}
        />
      )}
    </div>
  );
}