"use client";

import React, { useState, useEffect } from "react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import api, { dataApi } from '../../services/api';
import { QAForm } from '../components/qa/QAForm';
import toast from 'react-hot-toast';
import { 
  getCustomerInfo, 
  getVehicleInfo, 
  // getSupervisorInfo, 
  formatStatus, 
  getStatusBadgeClasses, 
  getPriorityBadgeClasses,
  getStatusSummaryColor,
  type FlexibleWorkOrder 
} from '../../lib/workOrderHelpers';


// Use flexible work order type that can handle different API structures
type WorkOrder = FlexibleWorkOrder;

interface StatusSummary {
  status: string;
  count: number;
}

interface APIResponse {
  success: boolean;
  data: WorkOrder[];
  pagination?: {
    currentPage: number;
    totalPages: number;
    totalItems: number;
    itemsPerPage: number;
    hasNext: boolean;
    hasPrev: boolean;
  };
}

interface StatusSummaryAPIResponse {
  success: boolean;
  data: StatusSummary[];
}

// Type for API parameters
interface APIParams {
  page: string;
  limit: string;
  sortBy: string;
  sortOrder: string;
  populate?: string;
  search?: string;
  status?: string;
}

// Helper function to check if QA is enabled for a work order
const isQAEnabled = (workOrder: WorkOrder): boolean => {
  // QA is enabled if at least one part/stage is completed
  if (workOrder.parts && workOrder.parts.length > 0) {
    return workOrder.parts.some(part => {
      if (part.stages && part.stages.length > 0) {
        return part.stages.some(stage => stage.status === 'completed');
      }
      // If no stages, check if the part itself is completed
      return part.status === 'completed';
    });
  }
  
  // Fallback: check if work order status indicates completion
  return workOrder.status === 'completed' || workOrder.status === 'qa_review';
};

const WorkOrdersListPage: React.FC = () => {
  const router = useRouter();
  const searchParams = useSearchParams();
  const initialSearch = searchParams.get('search') || '';
  
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>([]);
  const [filteredWorkOrders, setFilteredWorkOrders] = useState<WorkOrder[]>([]);
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [search, setSearch] = useState(initialSearch);
  const [statuses, setStatuses] = useState<string[]>([]);
  // const [supervisors, setSupervisors] = useState<string[]>([]);
  const [selectedStatus, setSelectedStatus] = useState("");
  // const [selectedSupervisor, setSelectedSupervisor] = useState("");
  const [statusSummary, setStatusSummary] = useState<StatusSummary[]>([]);
  // const [supervisorCache, setSupervisorCache] = useState<Record<string, string>>({});

  // Modal states for status details
  const [showStatusModal, setShowStatusModal] = useState(false);
  const [statusWorkOrders, setStatusWorkOrders] = useState<WorkOrder[]>([]);
  const [selectedStatusFilter, setSelectedStatusFilter] = useState("");
  
  // QA Modal states
  const [showQAModal, setShowQAModal] = useState(false);
  const [selectedWorkOrderForQA, setSelectedWorkOrderForQA] = useState<WorkOrder | null>(null);
  
  // Pause all state
  const [isPausingAll, setIsPausingAll] = useState(false);
  const [showPauseConfirmation, setShowPauseConfirmation] = useState(false);

  // Function to fetch supervisor name from API
  // const fetchSupervisorName = async (supervisorId: string): Promise<string> => {
  //   // Check cache first
  //   if (supervisorCache[supervisorId]) {
  //     return supervisorCache[supervisorId];
  //   }

  //   try {
  //     const response = await api.get(`/api/users/${supervisorId}`);
  //     const userData = response.data || response;
  //     const name = userData.name || `${userData.first_name || ''} ${userData.last_name || ''}`.trim() || 'Unknown';
      
  //     // Update cache
  //     setSupervisorCache(prev => ({
  //       ...prev,
  //       [supervisorId]: name
  //     }));
      
  //     return name;
  //   } catch (error) {
  //     console.error(`Error fetching supervisor ${supervisorId}:`, error);
  //     return 'Unknown';
  //   }
  // };

  // Function to get supervisor display name (with API fetch if needed)
  // const getSupervisorDisplayName = (order: WorkOrder): string => {
  //   // First check all possible supervisor fields
  //   console.log("Getting supervisor for order:", order.workOrderNumber);
  //   console.log("Order supervisor fields:", {
  //     supervisor: order.supervisor,
  //     supervisorId: order.supervisorId,
  //     assignedTo: order.assignedTo,
  //     assigned_technician: order.assigned_technician,
  //     parts_assignedTo: order.parts?.[0]?.assignedTo
  //   });
    
  //   // Extract supervisor ID from various fields
  //   let supervisorId = null;
    
  //   // Check direct fields first - handle both string IDs and object IDs
  //   if (order.supervisor) {
  //     supervisorId = typeof order.supervisor === 'string' ? order.supervisor : order.supervisor._id || order.supervisor.id;
  //   } else if (order.supervisorId) {
  //     supervisorId = typeof order.supervisorId === 'string' ? order.supervisorId : order.supervisorId._id || order.supervisorId.id;
  //   } else if (order.assignedTo) {
  //     supervisorId = typeof order.assignedTo === 'string' ? order.assignedTo : order.assignedTo._id || order.assignedTo.id;
  //   } else if (order.assigned_technician) {
  //     supervisorId = typeof order.assigned_technician === 'string' ? order.assigned_technician : order.assigned_technician._id || order.assigned_technician.id;
  //   } else if (order.parts?.[0]?.assignedTo) {
  //     const assignedTo = order.parts[0].assignedTo;
  //     supervisorId = typeof assignedTo === 'string' ? assignedTo : assignedTo._id || assignedTo.id;
  //   }
    
  //   console.log("Extracted supervisor ID:", supervisorId);
  //   console.log("Current cache:", supervisorCache);
    
  //   // If we have an ID that looks like a MongoDB ObjectId
  //   if (supervisorId && supervisorId.match(/^[a-fA-F0-9]{24}$/)) {
  //     // Return from cache if available
  //     if (supervisorCache[supervisorId]) {
  //       return supervisorCache[supervisorId];
  //     }
  //     // Otherwise return Loading...
  //     return 'Loading...';
  //   }
    
  //   // Fall back to the helper function
  //   const supervisorInfo = getSupervisorInfo(order);
  //   return supervisorInfo;
  // };

  // Fetch work orders from the backend
  const fetchWorkOrders = async (page: number, searchQuery = "") => {
  setLoading(true);
  try {
    const params: APIParams = {
      page: page.toString(),
      limit: '10',
      sortBy: 'createdAt',
      sortOrder: 'desc',
      // Add populate to get related customer, vehicle, and supervisor data
      // Including all possible supervisor field names
      populate: 'customer_id vehicle_id assignedTo supervisor supervisorId assigned_technician'
    };

    if (searchQuery) {
      params.search = searchQuery;
    }

    if (selectedStatus) {
      params.status = selectedStatus;
    }

    const result = await api.get('/api/work-orders', { params }) as APIResponse;

    if (result.success && Array.isArray(result.data)) {
      setWorkOrders(result.data);
      setFilteredWorkOrders(result.data);
      
      if (result.pagination) {
        setTotalPages(result.pagination.totalPages);
      }

      const uniqueStatuses = Array.from(new Set(result.data.map(wo => wo.status)));
      
      setStatuses(uniqueStatuses);
      
      // Fetch supervisor names for all work orders
      // const supervisorIds = new Set<string>();
      // result.data.forEach(wo => {
      //   let supervisorId = null;
        
      //   // Check all possible fields - handle both string IDs and object IDs
      //   if (wo.supervisor) {
      //     supervisorId = typeof wo.supervisor === 'string' ? wo.supervisor : wo.supervisor._id || wo.supervisor.id;
      //   } else if (wo.supervisorId) {
      //     supervisorId = typeof wo.supervisorId === 'string' ? wo.supervisorId : wo.supervisorId._id || wo.supervisorId.id;
      //   } else if (wo.assignedTo) {
      //     supervisorId = typeof wo.assignedTo === 'string' ? wo.assignedTo : wo.assignedTo._id || wo.assignedTo.id;
      //   } else if (wo.assigned_technician) {
      //     supervisorId = typeof wo.assigned_technician === 'string' ? wo.assigned_technician : wo.assigned_technician._id || wo.assigned_technician.id;
      //   } else if (wo.parts?.[0]?.assignedTo) {
      //     const assignedTo = wo.parts[0].assignedTo;
      //     supervisorId = typeof assignedTo === 'string' ? assignedTo : assignedTo._id || assignedTo.id;
      //   }
        
      //   if (supervisorId && supervisorId.match(/^[a-fA-F0-9]{24}$/)) {
      //     console.log(`Found supervisor ID ${supervisorId} for work order ${wo.workOrderNumber}`);
      //     supervisorIds.add(supervisorId);
      //   }
      // });
      
      // console.log("Total unique supervisor IDs to fetch:", supervisorIds.size);
      // console.log("Supervisor IDs:", Array.from(supervisorIds));
      
      // // Fetch all supervisor names
      // supervisorIds.forEach(id => {
      //   console.log(`Fetching supervisor name for ID: ${id}`);
      //   fetchSupervisorName(id);
      // });
    } else {
      console.error("Invalid work orders data format:", result);
      // Show empty state if API fails
      setWorkOrders([]);
      setFilteredWorkOrders([]);
    }
  } catch (error) {
    console.error("Error fetching work orders:", error);
    setWorkOrders([]);
    setFilteredWorkOrders([]);
  } finally {
    setLoading(false);
  }
};

  // Fetch status summary from the backend
  const fetchStatusSummary = async () => {
  try {
    const result = await api.get('/api/work-orders/status-summary') as StatusSummaryAPIResponse;
    
    if (result.success && Array.isArray(result.data)) {
      // Create a map of existing data
      const dataMap = new Map(result.data.map(item => [item.status, item.count]));
      
      // Ensure all expected statuses are included
      const completeStatusSummary = [
        { status: 'pending', count: dataMap.get('pending') || 0 },
        { status: 'in_progress', count: dataMap.get('in_progress') || 0 },
        { status: 'qa_review', count: dataMap.get('qa_review') || 0 },
        { status: 'paused', count: dataMap.get('paused') || 0 },
        { status: 'completed', count: dataMap.get('completed') || 0 }
      ];
      
      // Add any additional statuses from API that we didn't expect
      result.data.forEach(item => {
        if (!completeStatusSummary.find(s => s.status === item.status)) {
          completeStatusSummary.push(item);
        }
      });
      
      setStatusSummary(completeStatusSummary);
    } else {
      console.error("Invalid status summary data format:", result);
      // Fallback data if API fails
      setStatusSummary([
        { status: 'pending', count: 0 },
        { status: 'in_progress', count: 0 },
        { status: 'qa_review', count: 0 },
        { status: 'paused', count: 0 },
        { status: 'completed', count: 0 }
      ]);
    }
  } catch (error) {
    console.error("Error fetching status summary:", error);
    // Fallback data if API fails
    setStatusSummary([
      { status: 'pending', count: 0 },
      { status: 'in_progress', count: 0 },
      { status: 'qa_review', count: 0 },
      { status: 'in_need_of_qa', count: 0 },
      { status: 'completed', count: 0 }
    ]);
  }
  };

  // Handle filtering
  const handleFilter = () => {
    let filtered = [...workOrders];
    
    if (selectedStatus) {
      filtered = filtered.filter((order) => order.status === selectedStatus);
    }
    
    // if (selectedSupervisor) {
    //   filtered = filtered.filter((order) => getSupervisorDisplayName(order) === selectedSupervisor);
    // }
    
    setFilteredWorkOrders(filtered);
  };

  // Handle search
  const handleSearch = () => {
    fetchWorkOrders(1, search);
    setPage(1);
  };

  // Handle priority toggle
  const handlePriorityToggle = async (workOrderId: string, newPriority: string) => {
    try {
      await dataApi.updateWorkOrderPriority(workOrderId, newPriority);
      toast.success(`Work order priority updated to ${newPriority.toUpperCase()}`);
      
      // Refresh the work orders list
      await fetchWorkOrders(page, search);
    } catch (error) {
      console.error('Error updating work order priority:', error);
      toast.error('Failed to update work order priority');
    }
  };

  // Handle QA button click
  const handleQAClick = (workOrder: WorkOrder) => {
    setSelectedWorkOrderForQA(workOrder);
    setShowQAModal(true);
  };

  // Handle QA submission success
  const handleQASuccess = (qaRecord: any) => {
    // Refresh the work orders list to show updated QA status
    fetchWorkOrders(page);
    setShowQAModal(false);
    setSelectedWorkOrderForQA(null);
  };

  // Handle QA form cancellation
  const handleQACancel = () => {
    setShowQAModal(false);
    setSelectedWorkOrderForQA(null);
  };
  
  // Handle pause all in-progress work orders
  const handlePauseAll = async () => {
    setIsPausingAll(true);
    try {
      // First, fetch all in-progress work orders with populated parts data
      const params = {
        status: 'in_progress',
        limit: '1000', // Get all in-progress work orders
        populate: 'parts' // Ensure we get parts data
      };
      
      const workOrdersResponse = await api.get('/api/work-orders', { params });
      const inProgressWorkOrders = workOrdersResponse.data || workOrdersResponse || [];
      
      if (inProgressWorkOrders.length === 0) {
        console.error('No work orders are currently in progress.');
        return;
      }
      
      // Count total stages to pause
      let totalStagesToPause = 0;
      let pausedStagesCount = 0;
      let failedStagesCount = 0;
      
      // Iterate through work orders to pause all in-progress stages
      for (const workOrder of inProgressWorkOrders) {
        if (!workOrder.parts || workOrder.parts.length === 0) continue;
        
        // Iterate through parts
        for (let partIndex = 0; partIndex < workOrder.parts.length; partIndex++) {
          const part = workOrder.parts[partIndex];
          if (!part.stages || part.stages.length === 0) continue;
          
          // Iterate through stages
          for (let stageIndex = 0; stageIndex < part.stages.length; stageIndex++) {
            const stage = part.stages[stageIndex];
            
            // Only pause stages that are in_progress
            if (stage.status === 'in_progress') {
              totalStagesToPause++;
              
              try {
                // Use the dataApi to update stage status
                await dataApi.updateStageStatus(workOrder._id, partIndex, stageIndex, 'paused');
                
                // Add pause log
                await dataApi.addStageLog(workOrder._id, partIndex, stageIndex, {
                  action: 'pause',
                  notes: 'Bulk pause - all work halted'
                });
                
                pausedStagesCount++;
              } catch (error) {
                console.error(`Failed to pause stage ${stageIndex} in part ${partIndex} of work order ${workOrder.workOrderNumber}:`, error);
                failedStagesCount++;
              }
            }
          }
        }
      }
      
      // Show result message
      if (totalStagesToPause === 0) {
        console.error('No stages are currently in progress.');
      } else if (failedStagesCount === 0) {
        console.error(`Successfully paused ${pausedStagesCount} stage${pausedStagesCount !== 1 ? 's' : ''} across ${inProgressWorkOrders.length} work order${inProgressWorkOrders.length !== 1 ? 's' : ''}.`);
      } else {
        console.error(`Paused ${pausedStagesCount} stage${pausedStagesCount !== 1 ? 's' : ''}. Failed to pause ${failedStagesCount} stage${failedStagesCount !== 1 ? 's' : ''}.`);
      }
      
      // Refresh the work orders list and status summary
      await fetchWorkOrders(page);
      await fetchStatusSummary();
    } catch (error) {
      console.error('Error pausing all work orders:', error);
      console.error('An error occurred while pausing work orders. Please try again.');
    } finally {
      setIsPausingAll(false);
      setShowPauseConfirmation(false);
    }
  };

  // Handle status card click
  const handleStatusClick = async (status: string) => {
  try {
    setSelectedStatusFilter(status);
    
    const params = {
      page: '1',
      limit: '100',
      status: status,
      // Add populate to get related data including all supervisor fields
      populate: 'customer_id vehicle_id assignedTo supervisor supervisorId assigned_technician'
    };

    const result = await api.get('/api/work-orders', { params }) as APIResponse;

    if (result.success) {
      setStatusWorkOrders(result.data);
      setShowStatusModal(true);
      
      // Fetch supervisor names for status work orders
      // const supervisorIds = new Set<string>();
      // result.data.forEach(wo => {
      //   let supervisorId = null;
        
      //   // Check all possible fields - handle both string IDs and object IDs
      //   if (wo.supervisor) {
      //     supervisorId = typeof wo.supervisor === 'string' ? wo.supervisor : wo.supervisor._id || wo.supervisor.id;
      //   } else if (wo.supervisorId) {
      //     supervisorId = typeof wo.supervisorId === 'string' ? wo.supervisorId : wo.supervisorId._id || wo.supervisorId.id;
      //   } else if (wo.assignedTo) {
      //     supervisorId = typeof wo.assignedTo === 'string' ? wo.assignedTo : wo.assignedTo._id || wo.assignedTo.id;
      //   } else if (wo.assigned_technician) {
      //     supervisorId = typeof wo.assigned_technician === 'string' ? wo.assigned_technician : wo.assigned_technician._id || wo.assigned_technician.id;
      //   } else if (wo.parts?.[0]?.assignedTo) {
      //     const assignedTo = wo.parts[0].assignedTo;
      //     supervisorId = typeof assignedTo === 'string' ? assignedTo : assignedTo._id || assignedTo.id;
      //   }
        
      //   if (supervisorId && supervisorId.match(/^[a-fA-F0-9]{24}$/)) {
      //     supervisorIds.add(supervisorId);
      //   }
      // });
      
      // // Fetch all supervisor names
      // supervisorIds.forEach(id => {
      //   fetchSupervisorName(id);
      // });
    }
    } catch (error) {
      console.error("Error fetching work orders for status:", error);
    }
  };

  // Status and priority styling functions are now imported from helpers

  useEffect(() => {
    fetchWorkOrders(page, initialSearch);
    fetchStatusSummary();
  }, [page]);

  // Fetch work orders when initial search changes
  useEffect(() => {
    if (initialSearch) {
      fetchWorkOrders(1, initialSearch);
      setPage(1);
    }
  }, [initialSearch]);

  // Update supervisors list when cache changes
  // useEffect(() => {
  //   if (workOrders.length > 0 && Object.keys(supervisorCache).length > 0) {
  //     const uniqueSupervisors = Array.from(new Set(
  //       workOrders
  //         .map(wo => {
  //           const supervisorId = wo.supervisor || wo.supervisorId || wo.assignedTo || 
  //                               (wo.parts?.[0]?.assignedTo) || null;
  //           if (supervisorId && typeof supervisorId === 'string' && supervisorId.match(/^[a-fA-F0-9]{24}$/)) {
  //             return supervisorCache[supervisorId] || null;
  //           }
  //           return getSupervisorInfo(wo);
  //         })
  //         .filter(supervisor => supervisor && supervisor !== 'Unassigned' && supervisor !== 'Loading...')
  //     ));
  //     setSupervisors(uniqueSupervisors);
  //   }
  // }, [supervisorCache, workOrders, fetchWorkOrders]);

  // Add a useEffect to handle initial data loading issues
  // useEffect(() => {
  //   // If we have no data after initial load, try fetching again
  //   if (workOrders.length === 0 && !loading) {
  //     const timer = setTimeout(() => {
  //       console.log("No work orders found, retrying fetch...");
  //       fetchWorkOrders(page);
  //       fetchStatusSummary();
  //     }, 1000);
      
  //     return () => clearTimeout(timer);
  //   }
  // }, [workOrders, loading, page]);

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      {/* Status Summary Section */}
      <div className="mb-6">
        <h2 className="text-xl md:text-2xl font-bold mb-3 text-gray-900">Work Orders Status Summary</h2>
        {statusSummary.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
            {statusSummary.map((summary) => (
              // Don't show cancelled work orders in summary
              summary.status === "cancelled" ? null : (
                <button
                  key={summary.status}
                  className="p-4 bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-200 flex flex-col items-center hover:bg-gray-50"
                  onClick={() => handleStatusClick(summary.status)}
                >
                  <h3 className="text-sm md:text-base font-semibold mb-1 text-gray-900 text-center">
                    {formatStatus(summary.status)}
                  </h3>
                  <p className={`text-2xl md:text-3xl font-bold ${getStatusSummaryColor(summary.status)}`}>{summary.count}</p>
                  <p className="text-xs md:text-sm text-gray-500">work orders</p>
                </button>
              )
            ))}
          </div>
        ) : (
          <div className="bg-white p-8 rounded-lg shadow-md">
            <p className="text-gray-500">Loading status summary...</p>
          </div>
        )}
      </div>

      {/* Pause All Button */}
      <div className="mb-4 flex justify-end">
        <Button
          onClick={() => setShowPauseConfirmation(true)}
          variant="outline"
          className="bg-red-50 hover:bg-red-100 text-red-600 border-red-300"
          disabled={isPausingAll}
        >
          {isPausingAll ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-red-600 mr-2"></div>
              Pausing...
            </>
          ) : (
            'Pause All In-Progress'
          )}
        </Button>
      </div>

      {/* Search + Filters Section */}
      <div className="bg-white p-4 md:p-6 rounded-lg shadow-md mb-4">
        <div className="flex flex-col gap-3">
          {/* Search Input and Button */}
          <div className="flex items-center space-x-2 flex-1">
            <Input
              type="text"
              placeholder="Search work orders..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="flex-1 text-sm"
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  handleSearch();
                }
              }}
            />
            <Button onClick={handleSearch} className="bg-blue-600 hover:bg-blue-700 text-sm px-3 py-2">
              Search
            </Button>
          </div>

          {/* Filters */}
          <div className="flex items-center space-x-2 flex-wrap gap-2">
            <select
              className="p-2 border border-gray-300 rounded-lg bg-white text-gray-900 text-sm flex-1 min-w-[120px]"
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
            >
              <option value="">All Statuses</option>
              {statuses.map((status) => (
                <option key={status} value={status}>
                  {formatStatus(status)}
                </option>
              ))}
            </select>

            {/* <select
              className="p-2 border border-gray-300 rounded-lg bg-white text-gray-900"
              value={selectedSupervisor}
              onChange={(e) => setSelectedSupervisor(e.target.value)}
            >
              <option value="">All Supervisors</option>
              {supervisors.map((supervisor) => (
                <option key={supervisor} value={supervisor}>
                  {supervisor}
                </option>
              ))}
            </select> */}

            <Button onClick={handleFilter} variant="outline" className="text-sm px-3 py-2">
              Filter
            </Button>
            <Button
              onClick={() => {
                setSelectedStatus("");
                // setSelectedSupervisor("");
                setFilteredWorkOrders(workOrders);
              }}
              variant="outline"
              className="text-sm px-3 py-2"
            >
              Reset
            </Button>
          </div>
        </div>
      </div>

      {/* Work Orders Table */}
      <div className="bg-white rounded-lg shadow-md">
        <div className="p-4 md:p-6 border-b border-gray-200">
          <h2 className="text-lg md:text-xl font-bold text-gray-900">Work Orders</h2>
        </div>
        
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-3 md:px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Work Order
                </th>
                <th className="px-3 md:px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider hidden sm:table-cell">
                  Customer
                </th>
                <th className="px-3 md:px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider hidden md:table-cell">
                  Vehicle
                </th>
                <th className="px-3 md:px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-3 md:px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider hidden lg:table-cell">
                  Priority
                </th>
                <th className="px-3 md:px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {loading ? (
                <tr>
                  <td colSpan={6} className="text-center py-6">
                    <div className="flex items-center justify-center">
                      <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
                      <span className="ml-2 text-sm text-gray-600">Loading...</span>
                    </div>
                  </td>
                </tr>
              ) : filteredWorkOrders.length > 0 ? (
                filteredWorkOrders.map((order, idx) => (
                  <tr
                    key={order._id}
                    data-order-id={order._id}
                    className={`group ${
                      idx % 2 === 0 ? "bg-white" : "bg-gray-50"
                    }`}
                  >
                    <td className="px-3 md:px-6 py-3 whitespace-nowrap">
                      <Link 
                        href={`/workOrders/${order._id}`}
                        className="block group-hover:bg-blue-50 -mx-3 md:-mx-6 -my-3 px-3 md:px-6 py-3"
                      >
                        <div className="text-sm font-medium text-gray-900">
                          {order.workOrderNumber}
                        </div>
                        <div className="text-xs text-gray-500">
                          {new Date(order.createdAt).toLocaleDateString()}
                        </div>
                        <div className="text-xs text-gray-600 sm:hidden mt-1">
                          {getCustomerInfo(order).name}
                        </div>
                      </Link>
                    </td>
                    <td className="px-3 md:px-6 py-3 whitespace-nowrap hidden sm:table-cell">
                      <Link 
                        href={`/workOrders/${order._id}`}
                        className="block group-hover:bg-blue-50 -mx-3 md:-mx-6 -my-3 px-3 md:px-6 py-3"
                      >
                        <div className="text-sm font-medium text-gray-900">
                          {getCustomerInfo(order).name}
                        </div>
                        <div className="text-xs text-gray-500">
                          {getCustomerInfo(order).phone}
                        </div>
                      </Link>
                    </td>
                    <td className="px-3 md:px-6 py-3 whitespace-nowrap hidden md:table-cell">
                      <Link 
                        href={`/workOrders/${order._id}`}
                        className="block group-hover:bg-blue-50 -mx-3 md:-mx-6 -my-3 px-3 md:px-6 py-3"
                      >
                        <div className="text-base font-medium text-gray-900 text-center">
                          {getVehicleInfo(order).display()}
                        </div>
                        <div className="border-t border-gray-200 mt-1 pt-1">
                          <div className="text-sm text-gray-900 font-mono bg-gray-100 px-2 py-1 rounded text-center">
                            {getVehicleInfo(order).licensePlate}
                          </div>
                        </div>
                      </Link>
                    </td>
                    {/* <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      <Link 
                        href={`/workOrders/${order._id}`}
                        className="block group-hover:bg-blue-50 -mx-6 -my-4 px-6 py-4"
                      >
                        {getSupervisorDisplayName(order)}
                      </Link>
                    </td> */}
                    <td className="px-3 md:px-6 py-3 whitespace-nowrap">
                      <Link 
                        href={`/workOrders/${order._id}`}
                        className="block group-hover:bg-blue-50 -mx-3 md:-mx-6 -my-3 px-3 md:px-6 py-3"
                      >
                        <span
                          className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${getStatusBadgeClasses(order.status)}`}
                        >
                          {formatStatus(order.status)}
                        </span>
                      </Link>
                    </td>
                    <td className="px-3 md:px-6 py-3 whitespace-nowrap hidden lg:table-cell">
                      <div className="flex items-center gap-2">
                        <span
                          className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${getPriorityBadgeClasses(order.priority || 'normal')}`}
                        >
                          {order.priority?.toUpperCase() || 'NORMAL'}
                        </span>
                        <Button
                          size="sm"
                          variant={order.priority === 'high' ? "destructive" : "outline"}
                          onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            handlePriorityToggle(order._id, order.priority === 'high' ? 'normal' : 'high');
                          }}
                          className="text-xs px-2 py-1"
                        >
                          {order.priority === 'high' ? 'Set Normal' : 'Set High'}
                        </Button>
                      </div>
                    </td>
                    <td className="px-3 md:px-6 py-3 whitespace-nowrap text-sm text-gray-900">
                      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-1 sm:gap-2">
                        {/* View Invoice Button */}
                        {(order.invoiceId || order.invoice_id) ? (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              router.push(`/Invoices/${order.invoiceId || order.invoice_id}`);
                            }}
                            className="text-xs px-2 py-1"
                          >
                            Invoice
                          </Button>
                        ) : (
                          <Button
                            size="sm"
                            variant="outline"
                            disabled
                            className="text-xs opacity-50 px-2 py-1"
                          >
                            No Invoice
                          </Button>
                        )}
                        
                        {/* QA Button */}
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            handleQAClick(order);
                          }}
                          disabled={!isQAEnabled(order)}
                          className={`text-xs px-2 py-1 ${!isQAEnabled(order) ? 'opacity-50 cursor-not-allowed' : ''}`}
                        >
                          QA
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="text-center py-8">
                    <div className="text-gray-500">
                      <div className="text-4xl mb-4">📋</div>
                      <p className="text-lg font-medium">No work orders found</p>
                      <p className="text-sm">Try adjusting your search or filter criteria</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pagination */}
      <div className="flex justify-between items-center mt-4">
        <Button
          onClick={() => setPage((prev) => Math.max(prev - 1, 1))}
          disabled={page === 1}
          variant="outline"
          className="text-sm px-3 py-2"
        >
          Previous
        </Button>
        <span className="text-xs md:text-sm text-gray-700">
          Page {page} of {totalPages}
        </span>
        <Button
          onClick={() => setPage((prev) => Math.min(prev + 1, totalPages))}
          disabled={page === totalPages}
          variant="outline"
          className="text-sm px-3 py-2"
        >
          Next
        </Button>
      </div>

      {/* Status Detail Modal */}
      {showStatusModal && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50 p-4">
          <div className="bg-white p-4 md:p-8 rounded-lg shadow-2xl w-full max-w-full md:max-w-6xl max-h-[85vh] overflow-hidden">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg md:text-2xl font-bold text-gray-900">
                Work Orders - <span className="text-blue-600">{formatStatus(selectedStatusFilter)}</span>
              </h2>
              <Button
                variant="ghost"
                onClick={() => setShowStatusModal(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                ✕
              </Button>
            </div>

            {statusWorkOrders.length > 0 ? (
              <div className="overflow-y-auto max-h-[65vh]">
                <div className="overflow-x-auto">
                  <table className="min-w-full">
                    <thead className="bg-gray-50 sticky top-0">
                      <tr>
                        <th className="px-3 md:px-6 py-2 md:py-3 text-left text-xs font-semibold text-gray-600 uppercase">
                          Work Order
                        </th>
                        <th className="px-3 md:px-6 py-2 md:py-3 text-left text-xs font-semibold text-gray-600 uppercase hidden sm:table-cell">
                          Customer
                        </th>
                        <th className="px-3 md:px-6 py-2 md:py-3 text-left text-xs font-semibold text-gray-600 uppercase hidden md:table-cell">
                          Vehicle
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {statusWorkOrders.map((wo, idx) => (
                        <tr
                          key={wo._id}
                          onClick={() => {
                            setShowStatusModal(false);
                            router.push(`/workOrders/${wo._id}`);
                          }}
                          className={`cursor-pointer transition-colors ${
                            idx % 2 === 0 ? "bg-white" : "bg-gray-50"
                          } hover:bg-blue-50`}
                        >
                          <td className="px-3 md:px-6 py-3 whitespace-nowrap">
                            <div className="text-sm font-medium text-gray-900">
                              {wo.workOrderNumber}
                            </div>
                            <div className="text-xs text-gray-500">
                              {new Date(wo.createdAt).toLocaleDateString()}
                            </div>
                            <div className="text-xs text-gray-600 sm:hidden mt-1">
                              {getCustomerInfo(wo).name}
                            </div>
                          </td>
                          <td className="px-3 md:px-6 py-3 whitespace-nowrap hidden sm:table-cell">
                            <div className="text-sm font-medium text-gray-900">
                              {getCustomerInfo(wo).name}
                            </div>
                            <div className="text-xs text-gray-500">
                              {getCustomerInfo(wo).phone}
                            </div>
                          </td>
                          <td className="px-3 md:px-6 py-3 whitespace-nowrap hidden md:table-cell">
                            <div className="text-base font-medium text-gray-900 text-center">
                              {getVehicleInfo(wo).display()}
                            </div>
                            <div className="border-t border-gray-200 mt-1 pt-1">
                              <div className="text-sm text-gray-900 font-mono bg-gray-100 px-2 py-1 rounded text-center">
                                {getVehicleInfo(wo).licensePlate}
                              </div>
                            </div>
                          </td>
                          {/* <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {getSupervisorDisplayName(wo)}
                          </td> */}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-500">No work orders found for this status.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* QA Modal */}
      {showQAModal && selectedWorkOrderForQA && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50 p-4">
          <div className="bg-white p-4 md:p-8 rounded-lg shadow-2xl w-full max-w-full md:max-w-4xl max-h-[85vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h2 className="text-lg md:text-xl font-bold text-gray-900">
                  QA - {selectedWorkOrderForQA.workOrderNumber}
                </h2>
                <div className="mt-1 text-xs md:text-sm text-gray-600">
                  <p>Customer: {getCustomerInfo(selectedWorkOrderForQA).name}</p>
                  <p>Vehicle: {getVehicleInfo(selectedWorkOrderForQA).display()}</p>
                </div>
              </div>
              <Button
                variant="ghost"
                onClick={handleQACancel}
                className="text-gray-500 hover:text-gray-700"
              >
                ✕
              </Button>
            </div>

            <QAForm
              workOrderId={selectedWorkOrderForQA._id}
              workOrderNumber={selectedWorkOrderForQA.workOrderNumber}
              onSuccess={handleQASuccess}
              onCancel={handleQACancel}
            />
          </div>
        </div>
      )}

      {/* Pause Confirmation Modal */}
      {showPauseConfirmation && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50 p-4">
          <div className="bg-white p-6 rounded-lg shadow-2xl max-w-md w-full">
            <div className="flex items-start mb-4">
              <div className="flex-shrink-0">
                <svg className="h-6 w-6 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
              </div>
              <div className="ml-3">
                <h3 className="text-lg font-medium text-gray-900">
                  Pause All In-Progress Work Orders
                </h3>
                <div className="mt-2 text-sm text-gray-500">
                  <p className="mb-2">
                    <strong>Warning:</strong> This action will pause ALL ongoing stages across all work orders that are currently in progress.
                  </p>
                  <p>
                    This should only be used if all work needs to be halted/stopped immediately (e.g., emergency situations, end of workday, etc.).
                  </p>
                </div>
              </div>
            </div>
            
            <div className="mt-6 flex justify-end space-x-3">
              <Button
                variant="outline"
                onClick={() => setShowPauseConfirmation(false)}
                disabled={isPausingAll}
              >
                Cancel
              </Button>
              <Button
                onClick={handlePauseAll}
                className="bg-red-600 hover:bg-red-700 text-white"
                disabled={isPausingAll}
              >
                {isPausingAll ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Pausing...
                  </>
                ) : (
                  'Confirm Pause All'
                )}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default WorkOrdersListPage;