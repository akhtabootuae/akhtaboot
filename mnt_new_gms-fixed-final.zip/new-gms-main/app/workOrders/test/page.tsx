"use client";
import Link from 'next/link';

export default function TestPage() {
  console.log("TEST PAGE LOADED - /workOrders/test/page.tsx");
  
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold">Test Page - Static Route</h1>
      <p>If you can see this, static routes are working!</p>
      <Link href="/workOrders" className="text-blue-600 underline">Back to Work Orders</Link>
    </div>
  );
}