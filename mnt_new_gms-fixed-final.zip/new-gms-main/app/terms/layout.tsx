import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Terms and Conditions - Al Akhtaboot Althabi",
  description: "Terms and Conditions for Al Akhtaboot Althabi Auto.maint & Repair LLC",
}

export default function TermsLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}