'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { ChevronUp } from 'lucide-react';

export default function TermsContent() {
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [language, setLanguage] = useState<'both' | 'en' | 'ar'>('both');

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 300);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const terms = [
    {
      en: "The Touch Paint service is free of charge and the company does not bear any responsibility for the result of Touch Paint - you must know that there is a difference between (Touch Paint) and (Smart Paint)",
      ar: "خدمة Touch Paint مجانا ولا تتحمل الشركة أي مسئولية عن نتيجة Touch Paint - يجب العلم هناك فرق بين (Touch Paint) و (Smart Paint)"
    },
    {
      en: "The company undertakes to provide the PDR service according to the mentioned percentage and does not bear any responsibility for scratches. The work is done on adjusting the strike only",
      ar: "الشركة تتعهد في خدمة PDR حسب النسبة المذكورة ولا تتحمل أي مسئولية عن الخدوش. العمل يتم على تعديل الضربة فقط"
    },
    {
      en: "The company does not bear any responsibility for any electrical or mechanical malfunctions inside the car",
      ar: "الشركة لا تتحمل أي مسئولية عن أي أعطال كهربائية أو ميكانيكية داخل السيارة"
    },
    {
      en: "Sometimes working on the car requires making an opening in some areas of the car if necessary - sometimes we resort to dismantling some parts of the car",
      ar: "أحيانا يتطلب العمل على السيارة إجراء فتحة في بعض المناطق في السيارة إذا لزم الأمر - أحيانا نلجأ إلى فك بعض أجزاء السيارة"
    },
    {
      en: "The company does not bear any responsibility for any scratch inside the car because Golden Octopus Company specializes in the exterior car body",
      ar: "لا تتحمل الشركة أي مسؤولية عن أي خدش داخل السيارة لأن شركة الأخطبوط الذهبي اختصاصها هيكل السيارة الخارجي"
    },
    {
      en: "The deposit paid is non-refundable",
      ar: "العربون المدفوع لا يسترد"
    },
    {
      en: "It is possible for the dye to break. If it happens, the company will take care of the smart dyeing for free",
      ar: "من الممكن حدوث كسر في الصبغ، إذا حدث ستتكفل الشركة بعمل الصبغ الذكي مجانا"
    },
    {
      en: "If there are damaged spare parts, the company is not concerned with them",
      ar: "إذا كان هناك قطع غيار تالفة فالشركة غير معنية بها"
    },
    {
      en: "In most cases, the interior decoration of the car is removed",
      ar: "في أغلب الأحيان يتم فك الديكور الداخلي للسيارة"
    },
    {
      en: "The company is not responsible for removing the switch or protection from the car parts",
      ar: "الشركة غير مسئولة عن إزالة الجلاد أو الحماية عن أجزاء السيارة"
    },
    {
      en: "Sometimes, in order for the color to be consistent in dyeing, we resort to pulling some of the dye onto the piece adjacent to the stroke",
      ar: "في بعض الأحيان ليتناسق اللون في الصبغ نلجأ إلى سحب بعض من الصبغ إلى القطعة الملاصقة للضربة"
    },
    {
      en: "The price does not include the price of the parts",
      ar: "السعر غير شامل ثمن القطع"
    },
    {
      en: "When work on the car is completed and the customer is informed of this after 48 hours, the company does not bear any responsibility for natural accidents or any damage to the car",
      ar: "عند انتهاء العمل على السيارة وإخبار العميل بذلك بعد استغراق 48 ساعة الشركة لا تتحمل أي مسؤولية عن الحوادث الطبيعية أو وقوع أي أضرار بالسيارة"
    },
    {
      en: "When applying Smart Paint to any part of the car, it is mandatory to apply lacquer to the entire piece",
      ar: "عند عمل صبغ سمارت بينت لأي قطعة في السيارة إجباري وضع لكر لكامل القطعة"
    },
    {
      en: "When the work on the car is finished and the customer is informed of that after 48 hours, 50 dirhams are charged per day for parking",
      ar: "عند انتهاء العمل على السيارة وإخبار العميل بذلك بعد استغراق 48 ساعة يحسب على كل يوم 50 درهم حساب باركنج"
    },
    {
      en: "It must be known that the dyeing technology, whether it is Smart Paint or dyeing the entire piece (except for the agency pieces), is in stages, starting with adjusting the stroke, then putty, then primer, then dye, then lacquer",
      ar: "يجب العلم بأن تكنولوجية الصبغ إن كانت سمارت بينت أو صبغ كامل القطعة (باستثناء القطع الوكالة) يكون على مراحل بداية تعديل الضربة ثم معجون ثم برايمر ثم صبغ ثم اللكر"
    },
    {
      en: "The company is not responsible for the degree of measurement inspection",
      ar: "الشركة غير مسئولة عن درجة فحص القياس"
    },
    {
      en: "If the customer signs, he agrees to all terms of service",
      ar: "في حالة إمضاء العميل فإنه يوافق على جميع بنود الخدمة"
    },
    {
      en: "The company is not responsible for any belongings inside the car",
      ar: "الشركة لا تتحمل أي مقتنيات داخل السيارة"
    },
    {
      en: "The paint is guaranteed for five years, but the warranty does not cover accidents",
      ar: "ضمان الصبغ خمس سنوات ولا يشمل الضمان على الحوادث"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between py-6">
            <div className="flex items-center space-x-4">
              <div className="relative w-20 h-20">
                <Image
                  src="/Final-logo.webp"
                  alt="Golden Octopus Logo"
                  fill
                  className="object-contain"
                  priority
                />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Al Akhtaboot Althabi Auto.maint & Repair LLC</h1>
                <p className="text-sm text-gray-600 mt-1" dir="rtl">الأخطبوط الذهبي لصيانة و إصلاح السيارات ذ م م</p>
              </div>
            </div>

            {/* Language Toggle */}
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setLanguage('both')}
                className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
                  language === 'both'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                Both
              </button>
              <button
                onClick={() => setLanguage('en')}
                className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
                  language === 'en'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                English
              </button>
              <button
                onClick={() => setLanguage('ar')}
                className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
                  language === 'ar'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                العربية
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          {/* Title Section */}
          <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-8">
            <h2 className="text-3xl font-bold text-center mb-2">Terms and Conditions</h2>
            <p className="text-2xl text-center" dir="rtl">الشروط والأحكام</p>
          </div>

          {/* Terms List */}
          <div className="p-8">
            <div className="space-y-8">
              {terms.map((term, index) => (
                <div
                  key={index}
                  className="border-b border-gray-200 pb-6 last:border-b-0"
                >
                  <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0">
                      <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-blue-100 text-blue-600 font-semibold text-sm">
                        {index + 1}
                      </span>
                    </div>
                    <div className="flex-grow">
                      {language === 'both' && (
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                          <div className="space-y-2">
                            <p className="text-gray-800 leading-relaxed">
                              {term.en}
                            </p>
                          </div>
                          <div className="space-y-2">
                            <p className="text-gray-800 leading-relaxed text-right" dir="rtl">
                              {term.ar}
                            </p>
                          </div>
                        </div>
                      )}
                      {language === 'en' && (
                        <p className="text-gray-800 leading-relaxed">
                          {term.en}
                        </p>
                      )}
                      {language === 'ar' && (
                        <p className="text-gray-800 leading-relaxed text-right" dir="rtl">
                          {term.ar}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Agreement Section */}
            <div className="mt-12 pt-8 border-t-2 border-gray-300">
              <div className="bg-blue-50 rounded-lg p-6">
                <p className="text-center text-gray-700 font-medium mb-2">
                  By using our services, you agree to all the terms and conditions listed above.
                </p>
                <p className="text-center text-gray-700 font-medium" dir="rtl">
                  باستخدام خدماتنا، فإنك توافق على جميع الشروط والأحكام المذكورة أعلاه.
                </p>
              </div>
            </div>

            {/* Contact Information */}
            <div className="mt-8 text-center text-sm text-gray-600">
              <p>For any questions regarding these terms, please contact us.</p>
              <p className="mt-2" dir="rtl">لأي استفسارات بخصوص هذه الشروط، يرجى الاتصال بنا.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll to Top Button */}
      {showScrollTop && (
        <button
          onClick={scrollToTop}
          className="fixed bottom-8 right-8 bg-blue-600 text-white p-3 rounded-full shadow-lg hover:bg-blue-700 transition-colors z-50"
          aria-label="Scroll to top"
        >
          <ChevronUp className="w-6 h-6" />
        </button>
      )}

      {/* Print Styles */}
      <style jsx global>{`
        @media print {
          .sticky {
            position: static !important;
          }
          button {
            display: none !important;
          }
          .shadow-lg {
            box-shadow: none !important;
          }
          .bg-gray-50 {
            background-color: white !important;
          }
        }
      `}</style>
    </div>
  );
}