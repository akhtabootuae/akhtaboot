import React from 'react';
import TermsContent from './TermsContent';

export default function TermsAndConditions() {
  return <TermsContent />;
}