// Simple script to test the API response structure
const http = require('http');

const options = {
  hostname: 'localhost',
  port: 3000,
  path: '/api/invoices/some_test_id', // Replace with a real ID if needed
  method: 'GET',
  headers: {
    'Content-Type': 'application/json'
  }
};

const req = http.request(options, res => {
  console.log(`Status Code: ${res.statusCode}`);

  let data = '';
  res.on('data', chunk => {
    data += chunk;
  });

  res.on('end', () => {
    try {
      const parsedData = JSON.parse(data);
      console.log('API Response Structure:');
      console.log(JSON.stringify(parsedData, null, 2));
    } catch (e) {
      console.error('Error parsing API response:', e);
      console.log('Raw response:', data);
    }
  });
});

req.on('error', error => {
  console.error('Error making request:', error);
});

req.end();
