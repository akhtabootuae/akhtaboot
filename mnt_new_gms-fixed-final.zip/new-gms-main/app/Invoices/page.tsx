'use client';

import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useRouteProtection } from '@/services/route-protection';
import useDebounce from '../hooks/useDebounce';
import InvoiceSearchBar from '../components/Invoices/InvoiceSearchBar';
import InvoiceRow from '../components/Invoices/InvoiceRow';
import api from '@/services/api';
import Link from 'next/link';

interface Invoice {
  invoice_id: string;
  invoice_number: string;
  customer: string;
  customer_id: string;
  license_plate: string;
  car_info: string;
  total: number;
  price_before_vat: number;
  vat_amount: number;
  vat_percentage: number;
  is_taxed: boolean;
  total_paid: number;
  remaining_balance: number;
  payment_status: 'PAID' | 'PARTIAL' | 'UNPAID';
  payment_count: number;
  created_at: string;
  invoice_date: string;
  vehicle_id: number;
  work_order_id: string;
}

const PAGE_SIZE = 10;

export default function InvoicesPage() {
  const { user, isAuthenticated, isLoading } = useAuth();

  // Route protection for authenticated users
  const hasAccess = useRouteProtection(isAuthenticated, user, {});

  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [invoicesLoading, setInvoicesLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [paymentStatus, setPaymentStatus] = useState('All Statuses');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [currentPage, setCurrentPage] = useState(1);

  // Debounced search will only update 300ms after the last keystroke
  const debouncedSearch = useDebounce(search, 300);

  useEffect(() => {
    const fetchInvoices = async () => {
      setInvoicesLoading(true);
      try {
        const response = await api.get('/api/invoices/list');
        if (response && response.invoices && Array.isArray(response.invoices)) {
          setInvoices(response.invoices);
        } else {
          setInvoices([]);
        }
      } catch (error) {
        setInvoices([]);
      } finally {
        setInvoicesLoading(false);
      }
    };
    fetchInvoices();
  }, []);

  // Reset to page 1 when search changes
  useEffect(() => {
    setCurrentPage(1);
  }, [debouncedSearch, paymentStatus, startDate, endDate]);

  // Show loading state while checking auth
  if (isLoading || !hasAccess) {
    return (
      <div className="p-6 bg-gray-50 min-h-screen flex items-center justify-center">
        <div className="text-xl text-gray-600">Loading...</div>
      </div>
    );
  }

  // Filter invoices based on search and filters
  const filtered = invoices.filter(invoice => {
    const searchTerm = debouncedSearch.toLowerCase();
    const matchesSearch = !searchTerm || 
      invoice.invoice_number.toLowerCase().includes(searchTerm) ||
      invoice.customer.toLowerCase().includes(searchTerm) ||
      invoice.license_plate.toLowerCase().includes(searchTerm) ||
      invoice.car_info.toLowerCase().includes(searchTerm);

    // Map API payment status to filter status
    const mapPaymentStatus = (status: string) => {
      switch (status) {
        case 'PAID': return 'Paid';
        case 'PARTIAL': return 'Partially Paid';
        case 'UNPAID': return 'Unpaid';
        default: return status;
      }
    };

    const matchesStatus = paymentStatus === 'All Statuses' || 
      mapPaymentStatus(invoice.payment_status) === paymentStatus;

    const matchesStartDate = !startDate || 
      new Date(invoice.created_at) >= new Date(startDate);

    const matchesEndDate = !endDate || 
      new Date(invoice.created_at) <= new Date(endDate);

    return matchesSearch && matchesStatus && matchesStartDate && matchesEndDate;
  });

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const startIdx = (currentPage - 1) * PAGE_SIZE;
  const visible = filtered.slice(startIdx, startIdx + PAGE_SIZE);

  const clearFilters = () => {
    setSearch('');
    setPaymentStatus('All Statuses');
    setStartDate('');
    setEndDate('');
    setCurrentPage(1);
  };

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      <div className="w-full">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center">
            <div className="bg-blue-100 p-3 rounded-full mr-4">
              <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-600">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                <polyline points="14,2 14,8 20,8"></polyline>
                <line x1="16" y1="13" x2="8" y2="13"></line>
                <line x1="16" y1="17" x2="8" y2="17"></line>
                <polyline points="10,9 9,9 8,9"></polyline>
              </svg>
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                Invoice Management
              </h1>
              <div className="flex items-center mt-2">
                <div className="text-sm bg-blue-100 text-blue-800 py-1 px-3 rounded-full font-medium">
                  {invoicesLoading ? 'Loading...' : `${filtered.length} invoices`}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Search and Filters Card */}
        <div className="bg-white rounded-lg shadow-md mb-8 overflow-hidden">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-800">Search & Filter Invoices</h2>
            <p className="text-sm text-gray-600">Find invoices by number, customer, license plate, or filter by status and date</p>
          </div>
          <div className="p-6">
            <InvoiceSearchBar 
              search={search}
              onSearchChange={setSearch}
              paymentStatus={paymentStatus}
              onPaymentStatusChange={setPaymentStatus}
              startDate={startDate}
              onStartDateChange={setStartDate}
              endDate={endDate}
              onEndDateChange={setEndDate}
              onClearFilters={clearFilters}
            />
          </div>
        </div>

        {/* Invoices Table Card */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-800">Invoice List</h2>
            <p className="text-sm text-gray-600">Manage and view invoice details</p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full table-auto">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Invoice #</th>
                  <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer</th>
                  <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">License</th>
                  <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                  <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Due Date</th>
                  <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {invoicesLoading ? (
                  <tr>
                    <td colSpan={7} className="px-6 py-16 text-center">
                      <div className="flex flex-col items-center justify-center">
                        <div className="w-12 h-12 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mb-4"></div>
                        <p className="text-lg font-medium text-gray-700">Loading invoices...</p>
                        <p className="text-sm text-gray-500 mt-1">Please wait while we fetch your data</p>
                      </div>
                    </td>
                  </tr>
                ) : visible.length > 0 ? (
                  visible.map(invoice => <InvoiceRow key={invoice.invoice_id} invoice={invoice} />)
                ) : (
                  <tr>
                    <td colSpan={7} className="px-6 py-12 text-center text-gray-500">
                      <div className="flex flex-col items-center justify-center">
                        <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" className="text-gray-300 mb-3">
                          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                          <polyline points="14,2 14,8 20,8"></polyline>
                          <line x1="16" y1="13" x2="8" y2="13"></line>
                          <line x1="16" y1="17" x2="8" y2="17"></line>
                        </svg>
                        <p className="text-base font-medium">No invoices found</p>
                        <p className="text-sm text-gray-400">Try adjusting your search criteria</p>
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination footer */}
          <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex items-center justify-between">
            <div className="text-sm text-gray-600 font-medium">
              {invoicesLoading
                ? 'Loading invoice data...'
                : `Showing ${startIdx + 1}–${Math.min(startIdx + PAGE_SIZE, filtered.length)} of ${filtered.length} invoices`
              }
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1 || invoicesLoading}
                className="px-4 py-2 bg-white border border-gray-300 rounded-lg text-gray-700 text-sm font-medium hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                Previous
              </button>
              <span className="text-sm text-gray-700 font-medium px-3">
                Page {currentPage} of {totalPages}
              </span>
              <button
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages || invoicesLoading}
                className="px-4 py-2 bg-white border border-gray-300 rounded-lg text-gray-700 text-sm font-medium hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                Next
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}