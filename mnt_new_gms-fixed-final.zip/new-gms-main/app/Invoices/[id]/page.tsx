'use client';

import React, { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import axios from 'axios';
import api from '@/services/api';
import ProtectedRoute from '@/components/ProtectedRoute';
import { SupervisorAndUp, AccountantOnly } from '@/app/components/ui/RoleGuard';
import { Invoice } from '@/app/types/invoice';
import ProgressLoader from '@/app/components/ui/ProgressLoader';
import useProgressTracker from '@/app/hooks/useProgressTracker';

// Import all the new components
import {
  InvoiceHeader,
  LoadingState,
  ErrorState,
  InvoiceSummary,
  PaymentRecords,
  CustomerInfo,
  VehicleInfo,
  InvoiceImages,
  WorkOrderInfo,
  ServiceDetails,
  ExternalServices,
  SignedInvoice,
  SignedJobOrder,
  InvoiceDataProcessor,
  calculateInvoiceTotals
} from '@/app/components/Invoices/details';

export default function InvoiceDetailsPage() {
  const router = useRouter();
  const params = useParams();
  const id = params.id as string;
  
  const [invoice, setInvoice] = useState<Invoice | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isPrintLoading, setIsPrintLoading] = useState(false);
  const [isCarJobPrintLoading, setIsCarJobPrintLoading] = useState(false);
  const [isAddTaxLoading, setIsAddTaxLoading] = useState(false);
  const [isRemoveTaxLoading, setIsRemoveTaxLoading] = useState(false);

  // Progress tracking for invoice printing
  const invoicePrintSteps = [
    {
      id: 'preparation',
      name: 'Preparing Invoice',
      description: 'Gathering invoice data and formatting...',
      weight: 20,
      estimatedDuration: 2000
    },
    {
      id: 'generation',
      name: 'Generating PDF',
      description: 'Creating PDF document...',
      weight: 50,
      estimatedDuration: 4000
    },
    {
      id: 'processing',
      name: 'Processing Document',
      description: 'Finalizing document formatting...',
      weight: 20,
      estimatedDuration: 2000
    },
    {
      id: 'download',
      name: 'Preparing Download',
      description: 'Setting up document for printing...',
      weight: 10,
      estimatedDuration: 1000
    }
  ];

  // Progress tracking for car job printing
  const carJobPrintSteps = [
    {
      id: 'preparation',
      name: 'Preparing Car Job',
      description: 'Gathering job order data...',
      weight: 25,
      estimatedDuration: 2000
    },
    {
      id: 'generation',
      name: 'Generating PDF',
      description: 'Creating car job PDF document...',
      weight: 45,
      estimatedDuration: 3500
    },
    {
      id: 'formatting',
      name: 'Formatting Document',
      description: 'Applying car job template...',
      weight: 20,
      estimatedDuration: 1500
    },
    {
      id: 'download',
      name: 'Preparing Download',
      description: 'Setting up document for printing...',
      weight: 10,
      estimatedDuration: 1000
    }
  ];

  const invoicePrintTracker = useProgressTracker({
    steps: invoicePrintSteps,
    onComplete: () => {},
    onError: (error, step) => {
      console.error(`Invoice print step ${step.name} failed:`, error);
    }
  });

  const carJobPrintTracker = useProgressTracker({
    steps: carJobPrintSteps,
    onComplete: () => {},
    onError: (error, step) => {
      console.error(`Car job print step ${step.name} failed:`, error);
    }
  });

  const fetchInvoice = async () => {
    if (!id) {
      setError('No invoice ID provided');
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      const response = await api.get(`/api/invoices/${id}`);
      
      if (response) {
        let invoiceData: any = null;
        
        // Handle case where response is the direct invoice object
        if (response && typeof response === 'object' && '_id' in response) {
          invoiceData = response;
        } 
        // Handle case where response has data property containing invoice
        else if (response && typeof response === 'object' && 'data' in response) {
          invoiceData = response.data;
        }
        
        if (invoiceData) {
          // Process the invoice data using our processor
          const processedInvoice = await InvoiceDataProcessor.processInvoiceData(invoiceData);
          
          // Set the invoice data in state
          setInvoice(processedInvoice as unknown as Invoice);
          
        } else {
          console.error('Invalid invoice data format:', response);
          setError('Invalid invoice data format');
        }
      } else {
        setError('Failed to load invoice details');
      }
    } catch (err) {
      console.error('Error fetching invoice:', err);
      setError('Error loading invoice details');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchInvoice();
  }, [id]);

  // Get invoice totals
  const { subtotal, total, amountPaid, amountDue } = calculateInvoiceTotals(invoice);

  // Handler functions
  const handleBack = () => {
    router.back();
  };

  const handlePrint = async () => {
    try {
      if (!id) return;

      setIsPrintLoading(true);

      // Start progress tracking
      invoicePrintTracker.start();
      invoicePrintTracker.startStep('preparation');

      // Simulate preparation step
      await new Promise(resolve => setTimeout(resolve, 1000));
      invoicePrintTracker.completeStep('preparation');
      invoicePrintTracker.startStep('generation');

      // For PDF printing, we need to use axios directly to get the blob response
      const response = await axios.get(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000'}/api/invoices/${id}/pdf`, {
        responseType: 'blob',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('authToken')}`,
        }
      });

      invoicePrintTracker.completeStep('generation');
      invoicePrintTracker.startStep('processing');

      if (response.data) {
        // Simulate processing step
        await new Promise(resolve => setTimeout(resolve, 800));

        // Create a blob URL and open in new window for printing
        const blob = new Blob([response.data], { type: 'application/pdf' });
        const url = window.URL.createObjectURL(blob);

        invoicePrintTracker.completeStep('processing');
        invoicePrintTracker.startStep('download');

        // Open PDF in new window and trigger print
        const printWindow = window.open(url, '_blank');
        if (printWindow) {
          printWindow.onload = () => {
            printWindow.print();
          };
        }

        // Clean up URL after a delay
        setTimeout(() => {
          window.URL.revokeObjectURL(url);
        }, 1000);

        await new Promise(resolve => setTimeout(resolve, 500));
        invoicePrintTracker.completeStep('download');

      }
    } catch (error) {
      console.error('Error generating PDF:', error);
      invoicePrintTracker.failStep(invoicePrintTracker.currentStep?.id || 'unknown',
        error instanceof Error ? error.message : 'Failed to generate PDF. Please try again.');
    } finally {
      setIsPrintLoading(false);
    }
  };

  const handlePrintCarJob = async () => {
    try {
      if (!id) return;

      setIsCarJobPrintLoading(true);

      // Start progress tracking
      carJobPrintTracker.start();
      carJobPrintTracker.startStep('preparation');

      // Simulate preparation step
      await new Promise(resolve => setTimeout(resolve, 1200));
      carJobPrintTracker.completeStep('preparation');
      carJobPrintTracker.startStep('generation');

      // For PDF printing, we need to use axios directly to get the blob response
      const response = await axios.get(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000'}/api/invoices/${id}/carjob-pdf`, {
        responseType: 'blob',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('authToken')}`,
        }
      });

      carJobPrintTracker.completeStep('generation');
      carJobPrintTracker.startStep('formatting');

      if (response.data) {
        // Simulate formatting step
        await new Promise(resolve => setTimeout(resolve, 1000));

        // Create a blob URL and open in new window for printing
        const blob = new Blob([response.data], { type: 'application/pdf' });
        const url = window.URL.createObjectURL(blob);

        carJobPrintTracker.completeStep('formatting');
        carJobPrintTracker.startStep('download');

        // Open PDF in new window and trigger print
        const printWindow = window.open(url, '_blank');
        if (printWindow) {
          printWindow.onload = () => {
            printWindow.print();
          };
        }

        // Clean up URL after a delay
        setTimeout(() => {
          window.URL.revokeObjectURL(url);
        }, 1000);

        await new Promise(resolve => setTimeout(resolve, 600));
        carJobPrintTracker.completeStep('download');

      }
    } catch (error) {
      console.error('Error generating Car Job PDF:', error);
      carJobPrintTracker.failStep(carJobPrintTracker.currentStep?.id || 'unknown',
        error instanceof Error ? error.message : 'Failed to generate Car Job PDF. Please try again.');
    } finally {
      setIsCarJobPrintLoading(false);
    }
  };

  const handleAddPayment = async (paymentData: any) => {
    try {
      if (!id) return;
      
      const normalizedPaymentData = {
        payment_date: paymentData.payment_date || new Date(),
        amount: Number(paymentData.amount),
        payment_method: paymentData.payment_method || 'Cash',
        reference_number: paymentData.reference_number || undefined,
        notes: paymentData.notes || ''
      };
      
      const result = await api.post(`/api/invoices/${id}/payments`, normalizedPaymentData);
      
      if (result) {
        // Refresh invoice data after adding payment
        const updatedInvoice = await api.get(`/api/invoices/${id}`);
        
        const updatedInvoiceData = (typeof updatedInvoice === 'object' && '_id' in updatedInvoice) ? 
          updatedInvoice : 
          (typeof updatedInvoice === 'object' && 'data' in updatedInvoice) ? 
            updatedInvoice.data : null;
        
        if (updatedInvoiceData) {
          const processedInvoice = await InvoiceDataProcessor.processInvoiceData(updatedInvoiceData);
          setInvoice(processedInvoice as unknown as Invoice);
        }
      }
    } catch (error) {
      console.error('Error adding payment:', error);
      console.error('Failed to add payment. Please try again.');
    }
  };
  


  const handleAddImage = async (imageData: { url: string, description?: string }) => {
    try {
      if (!id) return;
      
      const imageWithTimestamp = {
        ...imageData,
        added_at: new Date()
      };
      
      const result = await api.post(`/api/invoices/${id}/images`, imageWithTimestamp);
      
      if (result) {
        const updatedInvoice = await api.get(`/api/invoices/${id}`);
        
        const updatedInvoiceData = (typeof updatedInvoice === 'object' && '_id' in updatedInvoice) ? 
          updatedInvoice : 
          (typeof updatedInvoice === 'object' && 'data' in updatedInvoice) ? 
            updatedInvoice.data : null;
        
        if (updatedInvoiceData) {
          const processedInvoice = await InvoiceDataProcessor.processInvoiceData(updatedInvoiceData);
          setInvoice(processedInvoice as unknown as Invoice);
        }
      }
    } catch (error) {
      console.error('Error adding image:', error);
      console.error('Failed to add image. Please try again.');
    }
  };
  
  const handleRemoveImage = async (imageUrl: string) => {
    try {
      if (!id) return;
      
      const confirmDelete = window.confirm('Are you sure you want to delete this image?');
      
      if (confirmDelete) {
        const imageToDelete = invoice?.images?.find((img: any) => img.url === imageUrl);
        const imageId = imageToDelete && (imageToDelete as any)._id;
        
        let result;
        
        if (imageId) {
          result = await api.delete(`/api/invoices/${id}/images/${imageId}`);
        } else {
          result = await api.delete(`/api/invoices/${id}/images`, {
            data: { imageUrl }
          });
        }
        
        if (result) {
          const updatedInvoice = await api.get(`/api/invoices/${id}`);
          
          const updatedInvoiceData = (typeof updatedInvoice === 'object' && '_id' in updatedInvoice) ? 
            updatedInvoice : 
            (typeof updatedInvoice === 'object' && 'data' in updatedInvoice) ? 
              updatedInvoice.data : null;
          
          if (updatedInvoiceData) {
            const processedInvoice = await InvoiceDataProcessor.processInvoiceData(updatedInvoiceData);
            setInvoice(processedInvoice as unknown as Invoice);
          }
        }
      }
    } catch (error) {
      console.error('Error removing image:', error);
      console.error('Failed to remove image. Please try again.');
    }
  };

  const handleAddTax = async () => {
    try {
      if (!id) return;
      
      setIsAddTaxLoading(true);
      const result = await api.put(`/api/invoices/${id}/add-tax`);
      if (result) {
        
        // Refresh invoice data after adding tax
        const updatedInvoice = await api.get(`/api/invoices/${id}`);
        
        const updatedInvoiceData = (typeof updatedInvoice === 'object' && '_id' in updatedInvoice) ? 
          updatedInvoice : 
          (typeof updatedInvoice === 'object' && 'data' in updatedInvoice) ? 
            updatedInvoice.data : null;
        
        if (updatedInvoiceData) {
          const processedInvoice = await InvoiceDataProcessor.processInvoiceData(updatedInvoiceData);
          setInvoice(processedInvoice as unknown as Invoice);
        }
      }
    } catch (error: any) {
      console.error('Error adding tax:', error);
      // Show more detailed error message
      const errorMessage = error?.response?.data?.message || 
                          error?.response?.data?.error || 
                          error?.message || 
                          'Failed to add tax. Please try again.';
      console.error(errorMessage);
    } finally {
      setIsAddTaxLoading(false);
    }
  };

  const handleRemoveTax = async () => {
    try {
      if (!id) return;
      
      const confirmRemove = window.confirm('Are you sure you want to remove tax from this invoice?');
      
      if (confirmRemove) {
        setIsRemoveTaxLoading(true);
        const result = await api.put(`/api/invoices/${id}/remove-tax`);

        if (result) {
          
          // Refresh invoice data after removing tax
          const updatedInvoice = await api.get(`/api/invoices/${id}`);
          
          const updatedInvoiceData = (typeof updatedInvoice === 'object' && '_id' in updatedInvoice) ? 
            updatedInvoice : 
            (typeof updatedInvoice === 'object' && 'data' in updatedInvoice) ? 
              updatedInvoice.data : null;
          
          if (updatedInvoiceData) {
            const processedInvoice = await InvoiceDataProcessor.processInvoiceData(updatedInvoiceData);
            setInvoice(processedInvoice as unknown as Invoice);
          }
        }
      }
    } catch (error: any) {
      console.error('Error removing tax:', error);
      // Show more detailed error message
      const errorMessage = error?.response?.data?.message || 
                          error?.response?.data?.error || 
                          error?.message || 
                          'Failed to remove tax. Please try again.';
      console.error(errorMessage);
    } finally {
      setIsRemoveTaxLoading(false);
    }
  };

  return (
    <ProtectedRoute>
      <div className="p-6 bg-gray-50 min-h-screen">
        <div className="max-w-7xl mx-auto">
          <InvoiceHeader
            invoice={invoice}
            onBack={handleBack}
            onPrint={handlePrint}
            onPrintCarJob={handlePrintCarJob}
            isPrintLoading={isPrintLoading}
            isCarJobPrintLoading={isCarJobPrintLoading}
            onAddTax={handleAddTax}
            onRemoveTax={handleRemoveTax}
            isAddTaxLoading={isAddTaxLoading}
            isRemoveTaxLoading={isRemoveTaxLoading}
          />

          {loading ? (
            <LoadingState />
          ) : error ? (
            <ErrorState error={error} />
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Main Content */}
              <div className="lg:col-span-2">
                <InvoiceSummary
                  invoice={invoice}
                  subtotal={subtotal}
                  total={total}
                  amountPaid={amountPaid}
                  amountDue={amountDue}
                />
                
                <SupervisorAndUp>
                  <ServiceDetails invoiceId={id} />
                </SupervisorAndUp>
                
                <ExternalServices 
                  invoiceId={id} 
                  invoice={invoice}
                  onServiceAdded={() => {
                    // Refresh invoice data when external service is added
                    if (id) {
                      fetchInvoice();
                    }
                  }} 
                />

                <AccountantOnly>
                  <SignedInvoice 
                    invoiceId={id} 
                    invoice={invoice}
                    onSignedInvoiceUpdated={() => {
                      // Refresh invoice data when signed invoice is updated
                      if (id) {
                        fetchInvoice();
                      }
                    }} 
                  />
                </AccountantOnly>

                <SignedJobOrder 
                  invoiceId={id} 
                  invoice={invoice}
                  onSignedJobOrderUpdated={() => {
                    // Refresh invoice data when signed job order is updated
                    if (id) {
                      fetchInvoice();
                    }
                  }} 
                />
                                
                <AccountantOnly>
                  <PaymentRecords
                    invoice={invoice}
                    onAddPayment={handleAddPayment}
                  />
                </AccountantOnly>
              </div>
              
              {/* Sidebar */}
              <div className="lg:col-span-1">
                <SupervisorAndUp>
                  <WorkOrderInfo invoiceId={id} />
                </SupervisorAndUp>
                
                <CustomerInfo invoice={invoice} />
                
                <VehicleInfo invoice={invoice} />

                <InvoiceImages
                  invoice={invoice}
                  onAddImage={handleAddImage}
                  onRemoveImage={handleRemoveImage}
                />
              </div>
            </div>
          )}
        </div>

        {/* Invoice Print Progress Loader */}
        <ProgressLoader
          isVisible={invoicePrintTracker.isActive}
          currentStep={invoicePrintTracker.currentStep}
          steps={invoicePrintTracker.steps}
          totalPercentage={invoicePrintTracker.totalPercentage}
          elapsedTime={invoicePrintTracker.elapsedTime}
          estimatedTimeRemaining={invoicePrintTracker.estimatedTimeRemaining}
          title="Printing Invoice"
          subtitle="Generating PDF document for printing"
          error={invoicePrintTracker.error}
        />

        {/* Car Job Print Progress Loader */}
        <ProgressLoader
          isVisible={carJobPrintTracker.isActive}
          currentStep={carJobPrintTracker.currentStep}
          steps={carJobPrintTracker.steps}
          totalPercentage={carJobPrintTracker.totalPercentage}
          elapsedTime={carJobPrintTracker.elapsedTime}
          estimatedTimeRemaining={carJobPrintTracker.estimatedTimeRemaining}
          title="Printing Car Job"
          subtitle="Generating car job PDF document for printing"
          error={carJobPrintTracker.error}
        />
      </div>
    </ProtectedRoute>
  );
}
