'use client';

import React from 'react';
import { X, Clock, User, Globe, Monitor, Building, AlertTriangle, Info, CheckCircle } from 'lucide-react';
import type { ExpenseLog } from '../../../types/expense-logs';

interface ExpenseLogDetailsModalProps {
  log: ExpenseLog | null;
  isOpen: boolean;
  onClose: () => void;
}

export const ExpenseLogDetailsModal: React.FC<ExpenseLogDetailsModalProps> = ({
  log,
  isOpen,
  onClose
}) => {
  if (!isOpen || !log) return null;

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high':
        return 'text-red-600 bg-red-50 border-red-200';
      case 'medium':
        return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'low':
        return 'text-green-600 bg-green-50 border-green-200';
      default:
        return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'high':
        return <AlertTriangle className="h-4 w-4" />;
      case 'medium':
        return <Info className="h-4 w-4" />;
      case 'low':
        return <CheckCircle className="h-4 w-4" />;
      default:
        return <Info className="h-4 w-4" />;
    }
  };

  const formatTimestamp = (timestamp: string) => {
    return new Date(timestamp).toLocaleString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      timeZoneName: 'short'
    });
  };

  const formatAction = (action: string) => {
    return action.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
  };

  const formatCategory = (category: string) => {
    return category.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-lg border ${getSeverityColor(log.severity)}`}>
              {getSeverityIcon(log.severity)}
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">
                Expense Log Details
              </h2>
              <p className="text-sm text-gray-500">
                {formatAction(log.action)} • {formatTimestamp(log.timestamp)}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(90vh-120px)]">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Basic Information */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Basic Information</h3>
              
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <Clock className="h-5 w-5 text-gray-400 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-gray-700">Timestamp</p>
                    <p className="text-sm text-gray-600">{formatTimestamp(log.timestamp)}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <User className="h-5 w-5 text-gray-400 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-gray-700">User</p>
                    <p className="text-sm text-gray-600">{log.user_email}</p>
                    <p className="text-xs text-gray-500">ID: {log.user_id}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Globe className="h-5 w-5 text-gray-400 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-gray-700">IP Address</p>
                    <p className="text-sm text-gray-600">{log.ip_address}</p>
                  </div>
                </div>

                {log.branch_id && (
                  <div className="flex items-start gap-3">
                    <Building className="h-5 w-5 text-gray-400 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-gray-700">Branch</p>
                      <p className="text-sm text-gray-600">{log.branch_id}</p>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Action Details */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Action Details</h3>
              
              <div className="space-y-3">
                <div>
                  <p className="text-sm font-medium text-gray-700 mb-1">Action</p>
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800">
                    {formatAction(log.action)}
                  </span>
                </div>

                <div>
                  <p className="text-sm font-medium text-gray-700 mb-1">Severity</p>
                  <span className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium border ${getSeverityColor(log.severity)}`}>
                    {getSeverityIcon(log.severity)}
                    {log.severity.charAt(0).toUpperCase() + log.severity.slice(1)}
                  </span>
                </div>

                <div>
                  <p className="text-sm font-medium text-gray-700 mb-1">Category</p>
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-gray-100 text-gray-800">
                    {formatCategory(log.category)}
                  </span>
                </div>

                <div>
                  <p className="text-sm font-medium text-gray-700 mb-1">Entity Type</p>
                  <p className="text-sm text-gray-600">{log.entity_type}</p>
                </div>

                {log.entity_id && (
                  <div>
                    <p className="text-sm font-medium text-gray-700 mb-1">Entity ID</p>
                    <p className="text-sm text-gray-600 font-mono">{log.entity_id}</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* User Agent */}
          {log.user_agent && (
            <div className="mt-6">
              <h3 className="text-lg font-medium text-gray-900 mb-3">Browser Information</h3>
              <div className="flex items-start gap-3">
                <Monitor className="h-5 w-5 text-gray-400 mt-0.5" />
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-700 mb-1">User Agent</p>
                  <p className="text-sm text-gray-600 break-all">{log.user_agent}</p>
                </div>
              </div>
            </div>
          )}

          {/* Details */}
          {log.details && Object.keys(log.details).length > 0 && (
            <div className="mt-6">
              <h3 className="text-lg font-medium text-gray-900 mb-3">Additional Details</h3>
              <div className="bg-gray-50 rounded-lg p-4 border">
                <pre className="text-sm text-gray-700 whitespace-pre-wrap overflow-x-auto">
                  {JSON.stringify(log.details, null, 2)}
                </pre>
              </div>
            </div>
          )}

          {/* Raw Log Data */}
          <div className="mt-6">
            <h3 className="text-lg font-medium text-gray-900 mb-3">Raw Log Data</h3>
            <div className="bg-gray-900 rounded-lg p-4 text-green-400 font-mono text-sm overflow-x-auto">
              <pre>{JSON.stringify(log, null, 2)}</pre>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex justify-end gap-3 p-6 border-t border-gray-200 bg-gray-50">
          <button
            onClick={onClose}
            className="px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default ExpenseLogDetailsModal;
