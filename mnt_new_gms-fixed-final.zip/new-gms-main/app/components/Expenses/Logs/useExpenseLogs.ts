'use client';

import { useState, useEffect, useCallback } from 'react';
import api from '../../../../services/api';
import type { ExpenseLog } from '../../../types/expense-logs';

export const useExpenseLogs = () => {
  const [logs, setLogs] = useState<ExpenseLog[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pagination, setPagination] = useState({
    currentPage: 1,
    totalPages: 1,
    totalLogs: 0,
    hasNextPage: false,
    hasPrevPage: false,
  });

  // Filter states
  const [search, setSearch] = useState('');
  const [selectedUserId, setSelectedUserId] = useState('');
  const [selectedAction, setSelectedAction] = useState('');
  const [selectedSeverity, setSelectedSeverity] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  // Clear all filters
  const clearFilters = useCallback(() => {
    setSearch('');
    setSelectedUserId('');
    setSelectedAction('');
    setSelectedSeverity('');
    setSelectedCategory('');
    setStartDate('');
    setEndDate('');
  }, []);

  // Update page
  const setPage = useCallback((page: number) => {
    setPagination(prev => ({ ...prev, currentPage: page }));
  }, []);

  // Update page size  
  const setPageSize = useCallback((limit: number) => {
    setPagination(prev => ({ ...prev, limit, currentPage: 1 }));
  }, []);

  // Fetch logs with current filters
  const fetchLogs = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      // If we have a search term, use the search endpoint
      if (search && search.trim()) {
        const params = new URLSearchParams();
        params.append('q', search.trim());
        params.append('page', pagination.currentPage.toString());
        params.append('limit', '50');
        
        // Add other filters to search
        if (selectedUserId) params.append('user_id', selectedUserId);
        if (selectedAction) params.append('action', selectedAction);
        if (startDate) params.append('start_date', startDate);
        if (endDate) params.append('end_date', endDate);

        console.log('Searching logs with params:', params.toString());
        const response: any = await api.get(`/api/expenses/logs/search?${params.toString()}`);
        
        setLogs(response.results || []);
        setPagination(prev => ({
          ...prev,
          totalPages: Math.ceil((response.results?.length || 0) / 50),
          totalLogs: response.results?.length || 0,
          hasNextPage: false,
          hasPrevPage: false
        }));
      } else {
        // Use the recent activity endpoint for general listing when no search term
        // This is the best available endpoint for listing logs
        const hours = 24 * 30; // Get last 30 days of activity
        const limit = 1000; // Get more logs to allow client-side filtering
        
        console.log('Fetching recent logs...');
        const response: any = await api.get(`/api/expenses/logs/recent?hours=${hours}&limit=${limit}`);
        
        console.log('Recent logs response:', response);
        
        let filteredLogs = response.recent_activity || [];
        
        // Apply client-side filtering since the backend doesn't support filtering on recent endpoint
        if (selectedUserId) {
          filteredLogs = filteredLogs.filter((log: any) => log.user_id === selectedUserId);
        }
        if (selectedAction) {
          filteredLogs = filteredLogs.filter((log: any) => log.action === selectedAction);
        }
        if (selectedSeverity) {
          filteredLogs = filteredLogs.filter((log: any) => log.severity === selectedSeverity);
        }
        if (selectedCategory) {
          filteredLogs = filteredLogs.filter((log: any) => log.category === selectedCategory);
        }
        if (startDate) {
          const start = new Date(startDate);
          filteredLogs = filteredLogs.filter((log: any) => new Date(log.timestamp) >= start);
        }
        if (endDate) {
          const end = new Date(endDate);
          filteredLogs = filteredLogs.filter((log: any) => new Date(log.timestamp) <= end);
        }
        
        // Apply pagination client-side
        const startIndex = (pagination.currentPage - 1) * 50;
        const endIndex = startIndex + 50;
        const paginatedLogs = filteredLogs.slice(startIndex, endIndex);
        
        setLogs(paginatedLogs);
        setPagination(prev => ({
          ...prev,
          totalPages: Math.ceil(filteredLogs.length / 50),
          totalLogs: filteredLogs.length,
          hasNextPage: pagination.currentPage < Math.ceil(filteredLogs.length / 50),
          hasPrevPage: pagination.currentPage > 1
        }));
      }

    } catch (err: any) {
      console.error('Error fetching logs:', err);
      setError(err?.response?.data?.message || err?.message || 'Failed to fetch expense logs');
      setLogs([]);
    } finally {
      setLoading(false);
    }
  }, [selectedUserId, selectedAction, selectedSeverity, selectedCategory, startDate, endDate, pagination.currentPage, search]);

  // Search logs using the search endpoint
  const searchLogs = useCallback(async (searchTerm: string) => {
    setSearch(searchTerm);
    setPagination(prev => ({ ...prev, currentPage: 1 }));
    // The fetchLogs function will handle the search since it checks for the search term
  }, []);

  // Export logs
  const exportLogs = useCallback(async (format: 'csv' | 'json') => {
    try {
      // Build query parameters for the current filters using the export endpoint
      const params = new URLSearchParams();
      
      if (selectedUserId) params.append('user_id', selectedUserId);
      if (selectedAction) params.append('action', selectedAction);
      if (selectedSeverity) params.append('severity', selectedSeverity);
      if (selectedCategory) params.append('category', selectedCategory);
      if (startDate) params.append('start_date', startDate);
      if (endDate) params.append('end_date', endDate);
      if (search) params.append('q', search); // Use 'q' for search term
      params.append('format', format);

      // Use the export endpoint
      const response: any = await api.get(`/api/expenses/logs/export?${params.toString()}`);
      
      if (format === 'json') {
        // Handle JSON download
        const blob = new Blob([JSON.stringify(response, null, 2)], { type: 'application/json' });
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `expense-logs-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
      }
    } catch (err: any) {
      console.error('Error exporting logs:', err);
      throw new Error(err?.message || 'Failed to export expense logs');
    }
  }, [selectedUserId, selectedAction, selectedSeverity, selectedCategory, startDate, endDate, search]);

  // Get recent activity
  const fetchRecentActivity = useCallback(async (hours = 24, limit = 50) => {
    try {
      setLoading(true);
      setError(null);

      // Use the recent activity endpoint
      const response: any = await api.get(`/api/expenses/logs/recent?hours=${hours}&limit=${limit}`);
      setLogs(response?.logs || response?.recent_activity || []);
      setPagination({
        currentPage: 1,
        totalPages: response?.pagination?.total_pages || 1,
        totalLogs: response?.pagination?.total_logs || response?.activity_count || 0,
        hasNextPage: response?.pagination?.current_page < response?.pagination?.total_pages,
        hasPrevPage: false,
      });
    } catch (err: any) {
      console.error('Error fetching recent activity:', err);
      setError(err?.message || 'Failed to fetch recent activity');
      setLogs([]);
    } finally {
      setLoading(false);
    }
  }, []);

  // Initial load and effect to refetch when filters change
  useEffect(() => {
    fetchLogs();
  }, [fetchLogs]);

  return {
    // Data
    logs,
    pagination,
    loading,
    error,

    // Filters
    search,
    setSearch,
    selectedUserId,
    setSelectedUserId,
    selectedAction,
    setSelectedAction,
    selectedSeverity,
    setSelectedSeverity,
    selectedCategory,
    setSelectedCategory,
    startDate,
    setStartDate,
    endDate,
    setEndDate,

    // Actions
    fetchLogs,
    searchLogs,
    exportLogs,
    fetchRecentActivity,
    clearFilters,
    setPage,
    setPageSize,
  };
};

export default useExpenseLogs;
