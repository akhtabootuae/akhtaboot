'use client';

import React from 'react';
import { 
  Activity, 
  Users, 
  AlertTriangle, 
  TrendingUp, 
  Clock,
  BarChart3,
  PieChart
} from 'lucide-react';
import type { DashboardResponse } from '../../../types/expense-logs';

interface ExpenseLogsStatsProps {
  dashboard: DashboardResponse | null;
  loading?: boolean;
  error?: string | null;
  onRefresh?: () => void;
}

export const ExpenseLogsStats: React.FC<ExpenseLogsStatsProps> = ({
  dashboard,
  loading = false,
  error = null,
  onRefresh
}) => {
  // Debug logging
  console.log('🎨 ExpenseLogsStats render:', {
    dashboard,
    loading,
    error,
    hasDashboard: !!dashboard,
    dashboardKeys: dashboard ? Object.keys(dashboard) : 'null'
  });
  
  if (dashboard) {
    console.log('📊 Dashboard details:', {
      statistics: dashboard.statistics,
      breakdowns: dashboard.breakdowns,
      period: dashboard.period,
      recentActivity: dashboard.recent_activity?.length || 0
    });
  }
  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="animate-pulse">
              <div className="h-4 bg-gray-200 rounded mb-2"></div>
              <div className="h-8 bg-gray-200 rounded mb-2"></div>
              <div className="h-3 bg-gray-200 rounded w-2/3"></div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-6 mb-8">
        <div className="flex items-center gap-3 text-red-700">
          <AlertTriangle className="h-5 w-5" />
          <p>Failed to load statistics: {error}</p>
          {onRefresh && (
            <button
              onClick={onRefresh}
              className="ml-auto px-3 py-1 bg-red-600 text-white rounded hover:bg-red-700"
            >
              Retry
            </button>
          )}
        </div>
      </div>
    );
  }

  if (!dashboard) {
    return null;
  }

  const { statistics, breakdowns, recent_activity } = dashboard;

  // Calculate some derived stats
  const totalLogs = statistics?.total_logs || 0;
  const uniqueUsers = statistics?.unique_users || 0;
  const recentActivityCount = recent_activity?.length || 0;
  
  // Get most common action
  const mostCommonAction = breakdowns?.by_action?.[0];
  
  // Get severity distribution
  const highSeverityCount = breakdowns?.by_severity?.find(s => s._id === 'high')?.count || 0;
  const mediumSeverityCount = breakdowns?.by_severity?.find(s => s._id === 'medium')?.count || 0;
  const lowSeverityCount = breakdowns?.by_severity?.find(s => s._id === 'low')?.count || 0;

  const StatCard = ({ icon: Icon, title, value, subtitle, color = 'blue' }: {
    icon: any;
    title: string;
    value: string | number;
    subtitle?: string;
    color?: 'blue' | 'green' | 'yellow' | 'red' | 'purple';
  }) => {
    const colorClasses = {
      blue: 'bg-blue-50 text-blue-600 border-blue-200',
      green: 'bg-green-50 text-green-600 border-green-200',
      yellow: 'bg-yellow-50 text-yellow-600 border-yellow-200',
      red: 'bg-red-50 text-red-600 border-red-200',
      purple: 'bg-purple-50 text-purple-600 border-purple-200'
    };

    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">{title}</p>
            <p className="text-2xl font-bold text-gray-900 mt-2">{value}</p>
            {subtitle && (
              <p className="text-sm text-gray-500 mt-1">{subtitle}</p>
            )}
          </div>
          <div className={`p-3 rounded-lg ${colorClasses[color]}`}>
            <Icon className="h-6 w-6" />
          </div>
        </div>
      </div>
    );
  };

  return (
    <>
      {/* Main Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard
          icon={Activity}
          title="Total Activity"
          value={totalLogs.toLocaleString()}
          subtitle={`Past ${dashboard.period.days} days`}
          color="blue"
        />
        
        <StatCard
          icon={Users}
          title="Active Users"
          value={uniqueUsers}
          subtitle="Unique users"
          color="green"
        />
        
        <StatCard
          icon={Clock}
          title="Recent Activity"
          value={recentActivityCount}
          subtitle="Last 24 hours"
          color="purple"
        />
        
        <StatCard
          icon={AlertTriangle}
          title="High Severity"
          value={highSeverityCount}
          subtitle="Critical activities"
          color="red"
        />
      </div>

      {/* Detailed Breakdowns */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Action Breakdown */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center gap-3 mb-4">
            <BarChart3 className="h-5 w-5 text-blue-600" />
            <h3 className="text-lg font-semibold text-gray-900">Top Actions</h3>
          </div>
          
          <div className="space-y-3">
            {breakdowns?.by_action?.slice(0, 5).map((action, index) => {
              const percentage = totalLogs > 0 ? (action.count / totalLogs) * 100 : 0;
              return (
                <div key={action._id} className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-sm font-medium text-gray-700">
                        {action._id.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                      </span>
                      <span className="text-sm text-gray-500">{action.count}</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${Math.min(percentage, 100)}%` }}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Severity Breakdown */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center gap-3 mb-4">
            <PieChart className="h-5 w-5 text-purple-600" />
            <h3 className="text-lg font-semibold text-gray-900">Severity Distribution</h3>
          </div>
          
          <div className="space-y-4">
            {[
              { severity: 'high', count: highSeverityCount, color: 'bg-red-500', label: 'High' },
              { severity: 'medium', count: mediumSeverityCount, color: 'bg-yellow-500', label: 'Medium' },
              { severity: 'low', count: lowSeverityCount, color: 'bg-green-500', label: 'Low' }
            ].map((item) => {
              const percentage = totalLogs > 0 ? (item.count / totalLogs) * 100 : 0;
              return (
                <div key={item.severity} className="flex items-center gap-3">
                  <div className={`w-4 h-4 rounded-full ${item.color}`} />
                  <div className="flex-1">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-sm font-medium text-gray-700">{item.label}</span>
                      <span className="text-sm text-gray-500">
                        {item.count} ({percentage.toFixed(1)}%)
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className={`h-2 rounded-full transition-all duration-300 ${item.color}`}
                        style={{ width: `${Math.min(percentage, 100)}%` }}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Daily Activity Trend */}
      {breakdowns?.daily_trend && breakdowns.daily_trend.length > 0 && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8">
          <div className="flex items-center gap-3 mb-4">
            <TrendingUp className="h-5 w-5 text-green-600" />
            <h3 className="text-lg font-semibold text-gray-900">Daily Activity Trend</h3>
          </div>
          
          <div className="grid grid-cols-7 gap-2">
            {breakdowns.daily_trend.map((day) => {
              const maxCount = Math.max(...breakdowns.daily_trend.map(d => d.count));
              const height = maxCount > 0 ? (day.count / maxCount) * 100 : 0;
              
              return (
                <div key={day._id} className="flex flex-col items-center">
                  <div className="w-full h-20 bg-gray-100 rounded flex items-end justify-center relative">
                    <div
                      className="bg-blue-500 rounded-t w-full transition-all duration-300"
                      style={{ height: `${height}%` }}
                    />
                    <span className="absolute bottom-1 text-xs text-gray-600 font-medium">
                      {day.count}
                    </span>
                  </div>
                  <span className="text-xs text-gray-500 mt-2">
                    {new Date(day._id).toLocaleDateString('en-US', { 
                      month: 'short', 
                      day: 'numeric' 
                    })}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </>
  );
};
