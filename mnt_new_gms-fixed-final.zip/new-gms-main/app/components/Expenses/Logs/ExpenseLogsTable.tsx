'use client';

import React, { useState } from 'react';
import { 
  Eye, 
  Clock, 
  User, 
  AlertTriangle, 
  Info, 
  CheckCircle,
  ChevronDown,
  ChevronRight
} from 'lucide-react';
import type { ExpenseLog } from '../../../types/expense-logs';

interface ExpenseLogsTableProps {
  logs: ExpenseLog[];
  loading?: boolean;
  error?: string | null;
  onViewDetails?: (log: ExpenseLog) => void;
}

export const ExpenseLogsTable: React.FC<ExpenseLogsTableProps> = ({
  logs,
  loading = false,
  error = null,
  onViewDetails
}) => {
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());

  const toggleExpanded = (logId: string) => {
    const newExpanded = new Set(expandedRows);
    if (newExpanded.has(logId)) {
      newExpanded.delete(logId);
    } else {
      newExpanded.add(logId);
    }
    setExpandedRows(newExpanded);
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low':
        return 'bg-green-100 text-green-800 border-green-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'high':
        return <AlertTriangle className="h-3 w-3" />;
      case 'medium':
        return <Info className="h-3 w-3" />;
      case 'low':
        return <CheckCircle className="h-3 w-3" />;
      default:
        return <Info className="h-3 w-3" />;
    }
  };

  const formatTimestamp = (timestamp: string) => {
    return new Date(timestamp).toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  const formatAction = (action: string) => {
    return action.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
  };

  if (loading) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="p-6">
          <div className="animate-pulse space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="flex items-center space-x-4">
                <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                <div className="h-4 bg-gray-200 rounded w-1/6"></div>
                <div className="h-4 bg-gray-200 rounded w-1/5"></div>
                <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                <div className="h-4 bg-gray-200 rounded w-1/6"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center gap-3 text-red-700">
          <AlertTriangle className="h-5 w-5" />
          <p>Failed to load logs: {error}</p>
        </div>
      </div>
    );
  }

  if (!logs || logs.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-12">
        <div className="text-center">
          <Clock className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No Logs Found</h3>
          <p className="text-gray-500">
            No expense activity logs match your current filters.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 w-full overflow-hidden">
      <div className="overflow-x-auto scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100">
        <table className="w-full min-w-[800px] divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-3 sm:px-4 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">
                Time
              </th>
              <th className="px-3 sm:px-4 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">
                User
              </th>
              <th className="px-3 sm:px-4 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">
                Action
              </th>
              <th className="hidden md:table-cell px-3 sm:px-4 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">
                Entity
              </th>
              <th className="px-3 sm:px-4 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">
                Severity
              </th>
              <th className="hidden lg:table-cell px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">
                Category
              </th>
              <th className="px-3 sm:px-4 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {logs.map((log) => (
              <React.Fragment key={log._id}>
                <tr className="hover:bg-gray-50 transition-colors">
                  <td className="px-3 sm:px-4 lg:px-6 py-3 text-xs sm:text-sm text-gray-900">
                    <div className="flex items-center gap-1 sm:gap-2">
                      <Clock className="h-3 w-3 sm:h-4 sm:w-4 text-gray-400 flex-shrink-0" />
                      <span className="truncate min-w-0">{formatTimestamp(log.timestamp)}</span>
                    </div>
                  </td>
                  
                  <td className="px-3 sm:px-4 lg:px-6 py-3 text-xs sm:text-sm text-gray-900">
                    <div className="flex items-center gap-1 sm:gap-2">
                      <User className="h-3 w-3 sm:h-4 sm:w-4 text-gray-400 flex-shrink-0" />
                      <div className="min-w-0 max-w-[120px] sm:max-w-[180px] lg:max-w-none">
                        <div className="font-medium truncate text-xs sm:text-sm">{log.user_email}</div>
                        <div className="text-xs text-gray-500 truncate hidden sm:block">{log.ip_address}</div>
                      </div>
                    </div>
                  </td>
                  
                  <td className="px-3 sm:px-4 lg:px-6 py-3 text-xs sm:text-sm text-gray-900">
                    <span className="inline-flex items-center px-1.5 sm:px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 max-w-[100px] sm:max-w-none">
                      <span className="truncate">{formatAction(log.action)}</span>
                    </span>
                  </td>
                  
                  <td className="hidden md:table-cell px-3 sm:px-4 lg:px-6 py-3 text-sm text-gray-900">
                    <div className="min-w-0">
                      <div className="font-medium truncate max-w-[120px] lg:max-w-none">{log.entity_type}</div>
                      {log.entity_id && (
                        <div className="text-xs text-gray-500 truncate max-w-[120px] lg:max-w-[180px]">
                          {log.entity_id}
                        </div>
                      )}
                    </div>
                  </td>
                  
                  <td className="px-3 sm:px-4 lg:px-6 py-3 text-xs sm:text-sm">
                    <span className={`inline-flex items-center gap-1 px-1.5 sm:px-2.5 py-0.5 rounded-full text-xs font-medium border ${getSeverityColor(log.severity)}`}>
                      {getSeverityIcon(log.severity)}
                      <span className="hidden sm:inline">{log.severity.charAt(0).toUpperCase() + log.severity.slice(1)}</span>
                    </span>
                  </td>
                  
                  <td className="hidden lg:table-cell px-6 py-3 text-sm text-gray-900">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800 max-w-[140px]">
                      <span className="truncate">{log.category.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</span>
                    </span>
                  </td>
                  
                  <td className="px-3 sm:px-4 lg:px-6 py-3 text-xs sm:text-sm text-gray-500">
                    <div className="flex items-center gap-1 sm:gap-2">
                      <button
                        onClick={() => toggleExpanded(log._id)}
                        className="text-gray-400 hover:text-gray-600 flex-shrink-0 p-1 rounded transition-colors"
                        title="Toggle details"
                      >
                        {expandedRows.has(log._id) ? (
                          <ChevronDown className="h-3 w-3 sm:h-4 sm:w-4" />
                        ) : (
                          <ChevronRight className="h-3 w-3 sm:h-4 sm:w-4" />
                        )}
                      </button>
                      
                      {onViewDetails && (
                        <button
                          onClick={() => onViewDetails(log)}
                          className="text-blue-600 hover:text-blue-800 flex-shrink-0 p-1 rounded transition-colors"
                          title="View details"
                        >
                          <Eye className="h-3 w-3 sm:h-4 sm:w-4" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
                
                {/* Expanded Details Row */}
                {expandedRows.has(log._id) && (
                  <tr className="bg-gray-50">
                    <td colSpan={7} className="px-3 sm:px-4 lg:px-6 py-3 sm:py-4">
                      <div className="space-y-3 sm:space-y-4 max-w-full">
                        {/* Mobile-only info that's hidden in columns */}
                        <div className="md:hidden space-y-2">
                          <div className="break-words">
                            <span className="text-xs font-medium text-gray-700">IP Address: </span>
                            <span className="text-xs text-gray-600">{log.ip_address}</span>
                          </div>
                          <div className="break-words">
                            <span className="text-xs font-medium text-gray-700">Entity: </span>
                            <span className="text-xs text-gray-600">{log.entity_type}</span>
                            {log.entity_id && (
                              <>
                                <br />
                                <span className="text-xs text-gray-500 break-all">{log.entity_id}</span>
                              </>
                            )}
                          </div>
                          <div className="lg:hidden break-words">
                            <span className="text-xs font-medium text-gray-700">Category: </span>
                            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                              {log.category.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                            </span>
                          </div>
                        </div>
                        
                        {/* User Agent */}
                        {log.user_agent && (
                          <div>
                            <h4 className="text-xs sm:text-sm font-medium text-gray-700 mb-1">User Agent:</h4>
                            <p className="text-xs sm:text-sm text-gray-600 break-all bg-gray-100 rounded p-2">{log.user_agent}</p>
                          </div>
                        )}
                        
                        {/* Branch */}
                        {log.branch_id && (
                          <div>
                            <h4 className="text-xs sm:text-sm font-medium text-gray-700 mb-1">Branch ID:</h4>
                            <p className="text-xs sm:text-sm text-gray-600 break-words">{log.branch_id}</p>
                          </div>
                        )}
                        
                        {/* Details */}
                        {log.details && Object.keys(log.details).length > 0 && (
                          <div>
                            <h4 className="text-xs sm:text-sm font-medium text-gray-700 mb-2">Details:</h4>
                            <div className="bg-white rounded border p-2 sm:p-3 overflow-auto max-h-64">
                              <pre className="text-xs text-gray-600 whitespace-pre-wrap break-words">{JSON.stringify(log.details, null, 2)}</pre>
                            </div>
                          </div>
                        )}
                      </div>
                    </td>
                  </tr>
                )}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ExpenseLogsTable;
