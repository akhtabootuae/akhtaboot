'use client';

import React from 'react';
import { Search, Filter, Calendar, Download, RefreshCw, X } from 'lucide-react';

interface ExpenseLogsFiltersProps {
  // Search and filters
  searchTerm: string;
  onSearchChange: (term: string) => void;
  onSearch: () => void;
  
  // Filter values
  filters: {
    user_id?: string;
    action?: string;
    severity?: string;
    category?: string;
    start_date?: string;
    end_date?: string;
  };
  onFiltersChange: (filters: any) => void;
  
  // Actions
  onClearFilters: () => void;
  onExport: (format: 'csv' | 'json') => void;
  onRefresh: () => void;
  
  // Loading states
  searchLoading?: boolean;
  exportLoading?: boolean;
  
  // Options for dropdowns
  users?: Array<{ id: string; email: string }>;
  actions?: string[];
  severities?: string[];
  categories?: string[];
}

export const ExpenseLogsFilters: React.FC<ExpenseLogsFiltersProps> = ({
  searchTerm,
  onSearchChange,
  onSearch,
  filters,
  onFiltersChange,
  onClearFilters,
  onExport,
  onRefresh,
  searchLoading = false,
  exportLoading = false,
  users = [],
  actions = [
    'create_expense',
    'update_expense',
    'delete_expense',
    'approve_expense',
    'reject_expense',
    'submit_expense',
    'view_expense',
    'export_expenses',
    'bulk_update_expenses'
  ],
  severities = ['low', 'medium', 'high'],
  categories = [
    'data_access',
    'data_modification',
    'system',
    'authentication',
    'authorization',
    'export',
    'import'
  ]
}) => {
  const handleFilterChange = (key: string, value: string) => {
    onFiltersChange({
      ...filters,
      [key]: value
    });
  };

  const hasActiveFilters = Object.values(filters).some(value => value && value !== '');

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-3 sm:p-4 lg:p-6 mb-4 md:mb-6 w-full">
      {/* Search Bar */}
      <div className="flex flex-col lg:flex-row gap-3 sm:gap-4 mb-4 md:mb-6">
        <div className="flex-1 min-w-0">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <input
              type="text"
              placeholder="Search logs by user email, action, details..."
              value={searchTerm}
              onChange={(e) => onSearchChange(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && onSearch()}
              className="w-full pl-10 pr-4 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
            />
          </div>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-2 sm:gap-3">
          <button
            onClick={onSearch}
            disabled={searchLoading}
            className="px-3 sm:px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 whitespace-nowrap text-sm transition-colors"
          >
            {searchLoading ? (
              <RefreshCw className="h-4 w-4 animate-spin" />
            ) : (
              <Search className="h-4 w-4" />
            )}
            <span className="hidden xs:inline">Search</span>
            <span className="xs:hidden">Search</span>
          </button>
          
          <button
            onClick={onRefresh}
            className="px-3 sm:px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 flex items-center justify-center gap-2 whitespace-nowrap text-sm transition-colors"
          >
            <RefreshCw className="h-4 w-4" />
            <span className="hidden xs:inline">Refresh</span>
            <span className="xs:hidden">Refresh</span>
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-3 sm:gap-4 mb-4 md:mb-6">
        {/* User Filter */}
        <div>
          <label className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">
            User
          </label>
          <select
            value={filters.user_id || ''}
            onChange={(e) => handleFilterChange('user_id', e.target.value)}
            className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
          >
            <option value="">All Users</option>
            {users.map((user) => (
              <option key={user.id} value={user.id}>
                {user.email}
              </option>
            ))}
          </select>
        </div>

        {/* Action Filter */}
        <div>
          <label className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">
            Action
          </label>
          <select
            value={filters.action || ''}
            onChange={(e) => handleFilterChange('action', e.target.value)}
            className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">All Actions</option>
            {actions.map((action) => (
              <option key={action} value={action}>
                {action.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
              </option>
            ))}
          </select>
        </div>

        {/* Severity Filter */}
        <div>
          <label className="block text-xs md:text-sm font-medium text-gray-700 mb-1">
            Severity
          </label>
          <select
            value={filters.severity || ''}
            onChange={(e) => handleFilterChange('severity', e.target.value)}
            className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">All Severities</option>
            {severities.map((severity) => (
              <option key={severity} value={severity}>
                {severity.charAt(0).toUpperCase() + severity.slice(1)}
              </option>
            ))}
          </select>
        </div>

        {/* Category Filter */}
        <div>
          <label className="block text-xs md:text-sm font-medium text-gray-700 mb-1">
            Category
          </label>
          <select
            value={filters.category || ''}
            onChange={(e) => handleFilterChange('category', e.target.value)}
            className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">All Categories</option>
            {categories.map((category) => (
              <option key={category} value={category}>
                {category.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Date Range Filters */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4 mb-4 md:mb-6">
        <div>
          <label className="block text-xs md:text-sm font-medium text-gray-700 mb-1">
            Start Date
          </label>
          <div className="relative">
            <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <input
              type="date"
              value={filters.start_date || ''}
              onChange={(e) => handleFilterChange('start_date', e.target.value)}
              className="w-full pl-10 pr-4 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs md:text-sm font-medium text-gray-700 mb-1">
            End Date
          </label>
          <div className="relative">
            <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <input
              type="date"
              value={filters.end_date || ''}
              onChange={(e) => handleFilterChange('end_date', e.target.value)}
              className="w-full pl-10 pr-4 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row flex-wrap gap-3">
        {hasActiveFilters && (
          <button
            onClick={onClearFilters}
            className="px-3 md:px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 flex items-center justify-center gap-2 whitespace-nowrap text-sm"
          >
            <X className="h-4 w-4" />
            Clear Filters
          </button>
        )}

        <div className="flex flex-col sm:flex-row gap-2">
          <button
            onClick={() => onExport('json')}
            disabled={exportLoading}
            className="px-3 md:px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 whitespace-nowrap text-sm"
          >
            {exportLoading ? (
              <RefreshCw className="h-4 w-4 animate-spin" />
            ) : (
              <Download className="h-4 w-4" />
            )}
            Export JSON
          </button>
        </div>
      </div>
    </div>
  );
};

export default ExpenseLogsFilters;
