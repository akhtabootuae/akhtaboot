import React from 'react';
import { useRouter } from 'next/navigation';
import { ExpenseResponse, formatCurrency, formatDate, getCategoryDisplay } from '../../types/expense';

interface ExpenseTableProps {
  expenses: ExpenseResponse[];
  onEdit: (expense: ExpenseResponse) => void;
}

const ExpenseTable: React.FC<ExpenseTableProps> = ({
  expenses,
  onEdit,
}) => {
  const router = useRouter();

  const getActionButtons = (expense: ExpenseResponse) => {
    const buttons = [];

    // View Details button (always available)
    buttons.push(
      <button
        key="view"
        onClick={() => router.push(`/expenses/${expense._id}`)}
        className="text-blue-600 hover:text-blue-800 text-sm font-medium mr-3"
      >
        👁️ View
      </button>
    );

    // Edit button (always available)
    buttons.push(
      <button
        key="edit"
        onClick={() => onEdit(expense)}
        className="text-blue-600 hover:text-blue-800 text-sm font-medium mr-3"
      >
        ✏️ Edit
      </button>
    );

    return buttons;
  };

  if (expenses.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-md p-8 text-center">
        <div className="text-gray-500 text-lg mb-2">📋</div>
        <p className="text-gray-500">No expenses found</p>
        <p className="text-sm text-gray-400 mt-1">
          Try adjusting your filters or create a new expense
        </p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Expense Details
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Amount
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Category
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Date
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {expenses.map((expense) => {
              const categoryDisplay = getCategoryDisplay(expense.expense_type);

              return (
                <tr key={expense._id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-gray-900">
                        {expense.expense_number}
                      </div>
                      <div className="text-sm text-gray-500 truncate max-w-xs">
                        {expense.description || expense.title}
                      </div>
                      <div className="flex items-center space-x-2 mt-1">
                        {expense.vendor && (
                          <div className="text-xs text-gray-400">
                            📍 {expense.vendor}
                          </div>
                        )}
                        {expense.invoice_image && (
                          <div className="text-xs text-green-600 bg-green-50 px-2 py-1 rounded-full">
                            📄 Invoice
                          </div>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">
                      {formatCurrency(expense.amount)}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center text-sm text-gray-900">
                      <span className="mr-2">{categoryDisplay.icon}</span>
                      {categoryDisplay.label}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {formatDate(expense.date)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex items-center space-x-2">
                      {getActionButtons(expense)}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ExpenseTable;
