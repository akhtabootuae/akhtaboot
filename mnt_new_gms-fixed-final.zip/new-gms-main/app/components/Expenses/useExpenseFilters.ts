import { useState, useEffect, useCallback } from 'react';
import { ExpenseResponse, ExpenseRequest, ExpenseStatistics } from '../../types/expense';
import { ExpenseFilters } from '@/app/types/api';
import useDebounce from '../../hooks/useDebounce';
import { 
  fetchExpenses as apiFetchExpenses,
  fetchExpenseStatistics,
  createExpense as apiCreateExpense,
  updateExpense as apiUpdateExpense,
  deleteExpense as apiDeleteExpense,
} from '../../../services/api';

export const useExpenseFilters = () => {
  const [expenses, setExpenses] = useState<ExpenseResponse[]>([]);
  const [statistics, setStatistics] = useState<ExpenseStatistics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Filter states
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [vendor, setVendor] = useState('');

  // Debounce search and vendor inputs to avoid excessive API calls
  const debouncedSearch = useDebounce(search, 500);
  const debouncedVendor = useDebounce(vendor, 500);

  const fetchExpenses = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      const filters: Partial<ExpenseFilters> = {};
      if (debouncedSearch) filters.search = debouncedSearch;
      if (category) filters.expense_type = category;
      if (startDate) filters.date_from = startDate;
      if (endDate) filters.date_to = endDate;
      if (debouncedVendor) filters.vendor = debouncedVendor;

      const response = await apiFetchExpenses(filters);
      // Handle the response data structure from your API
      const data = response?.data || response;
      setExpenses(Array.isArray(data) ? data : []);
    } catch (err: Error | unknown) {
      console.error('Error fetching expenses:', err);
      setError((err as Error)?.message || 'Failed to fetch expenses');
      setExpenses([]);
    } finally {
      setLoading(false);
    }
  }, [debouncedSearch, category, startDate, endDate, debouncedVendor]);

  const fetchStatistics = useCallback(async () => {
    try {
      const filters: Partial<ExpenseFilters> = {};
      if (startDate) filters.date_from = startDate;
      if (endDate) filters.date_to = endDate;

      const response = await fetchExpenseStatistics(filters);
      // Handle the response data structure from your API
      const data = response?.data || response;
      setStatistics(data);
    } catch (err: Error | unknown) {
      console.error('Error fetching statistics:', err);
    }
  }, [startDate, endDate]);

  // Auto-trigger search when debounced values change
  useEffect(() => {
    fetchExpenses();
  }, [fetchExpenses]);

  // Initial load
  useEffect(() => {
    fetchExpenses();
    fetchStatistics();
  }, []); // Only run once on mount

  const createExpense = async (expenseData: ExpenseRequest) => {
    try {
      setError(null);
      console.log('Creating expense with data:', expenseData);
      
      // Ensure invoice_image is provided for new expenses
      if (!expenseData.invoice_image) {
        throw new Error('Invoice image is required for new expenses');
      }
      
      const newExpense = await apiCreateExpense(expenseData);
      return newExpense;
    } catch (err: Error | unknown) {
      console.error('Error creating expense:', err);
      console.error('Error response:', err.response?.data);
      console.error('Error status:', err.response?.status);
      console.error('Error details:', err.response?.data?.details);
      
      // Handle specific error types
      let errorMessage = 'Failed to create expense';
      
      if (err.response?.status === 500 && 
          err.response?.data?.message?.includes('E11000') && 
          err.response?.data?.message?.includes('expense_number')) {
        errorMessage = 'Failed to generate unique expense number. This may be due to concurrent operations or existing data conflicts. Please try again in a moment.';
      } else if (err.response?.data?.message) {
        errorMessage = err.response.data.message;
      } else if (err.message) {
        errorMessage = err.message;
      }
      
      setError(errorMessage);
      throw err;
    }
  };

  const updateExpense = async (expenseId: string, expenseData: Partial<ExpenseRequest>) => {
    try {
      setError(null);
      const updatedExpense = await apiUpdateExpense(expenseId, expenseData);
      return updatedExpense;
    } catch (err: Error | unknown) {
      console.error('Error updating expense:', err);
      setError(err.message || 'Failed to update expense');
      throw err;
    }
  };

  const deleteExpense = async (expenseId: string) => {
    try {
      setError(null);
      await apiDeleteExpense(expenseId);
    } catch (err: Error | unknown) {
      console.error('Error deleting expense:', err);
      setError(err.message || 'Failed to delete expense');
      throw err;
    }
  };

  const clearFilters = () => {
    setSearch('');
    setCategory('');
    setStartDate('');
    setEndDate('');
    setVendor('');
  };

  useEffect(() => {
    fetchExpenses();
  }, [fetchExpenses]);

  useEffect(() => {
    fetchStatistics();
  }, [fetchStatistics]);

  return {
    expenses,
    statistics,
    loading,
    error,
    search,
    setSearch,
    category,
    setCategory,
    startDate,
    setStartDate,
    endDate,
    setEndDate,
    vendor,
    setVendor,
    clearFilters,
    fetchExpenses,
    fetchStatistics,
    createExpense,
    updateExpense,
    deleteExpense,
  };
};
