import React from 'react';

interface ErrorMessageProps {
  message: string;
}

const ErrorMessage: React.FC<ErrorMessageProps> = ({ message }) => {
  return (
    <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
      <div className="text-red-500 text-lg mb-2">⚠️</div>
      <p className="text-red-700 font-medium mb-1">Error</p>
      <p className="text-red-600 text-sm">{message}</p>
    </div>
  );
};

export default ErrorMessage;
