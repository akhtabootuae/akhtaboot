import React from 'react';
import { ExpenseStatistics, formatCurrency } from '../../types/expense';

interface ExpenseStatsProps {
  statistics: ExpenseStatistics;
}

const ExpenseStats: React.FC<ExpenseStatsProps> = ({ statistics }) => {
  // Provide default values to handle missing data
  const safeStats = {
    totalExpenses: statistics?.totalExpenses || 0,
    totalAmount: statistics?.totalAmount || 0,
    byCategory: statistics?.byCategory || {},
    monthlyTrend: statistics?.monthlyTrend || [],
  };


  return (
    <div className="mb-6">
      {/* Main Stats Cards */}
      <div className="mb-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Expenses</p>
              <p className="text-3xl font-bold text-gray-900">{safeStats.totalExpenses}</p>
              <p className="text-lg text-gray-500">{formatCurrency(safeStats.totalAmount)}</p>
            </div>
            <div className="bg-blue-500 rounded-full p-4 text-white text-2xl">
              📊
            </div>
          </div>
        </div>
      </div>

      {/* Category Breakdown */}
      {Object.keys(safeStats.byCategory).length > 0 && (
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">By Category</h3>
            <span className="text-sm text-gray-500">📈</span>
          </div>
          <div className="space-y-3">
            {Object.entries(safeStats.byCategory)
              .sort(([,a], [,b]) => b.amount - a.amount)
              .slice(0, 8)
              .map(([category, data]) => (
                <div key={category} className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium text-gray-700 capitalize">
                      {category.replace('_', ' ')}
                    </span>
                    <span className="text-xs text-gray-500">({data.count})</span>
                  </div>
                  <span className="text-sm font-semibold text-gray-900">
                    {formatCurrency(data.amount)}
                  </span>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* Monthly Trend */}
      {safeStats.monthlyTrend && safeStats.monthlyTrend.length > 0 && (
        <div className="bg-white rounded-lg shadow-md p-6 mt-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Monthly Trend</h3>
            <span className="text-sm text-gray-500">📈</span>
          </div>
          <div className="space-y-3">
            {safeStats.monthlyTrend.slice(-6).map((month) => (
              <div key={month.month} className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <span className="text-sm font-medium text-gray-700">
                    {month.month}
                  </span>
                  <span className="text-xs text-gray-500">({month.count})</span>
                </div>
                <span className="text-sm font-semibold text-gray-900">
                  {formatCurrency(month.amount)}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ExpenseStats;
