import React, { useState, useEffect } from 'react';
import { ExpenseRequest, ExpenseResponse, EXPENSE_TYPES, PAYMENT_METHODS } from '../../types/expense';
import { generateExpenseInvoicePDF } from '../../../services/api';

interface ExpenseFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (expenseData: ExpenseRequest) => void;
  expense?: ExpenseResponse | null;
  title: string;
}

const ExpenseFormModal: React.FC<ExpenseFormModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  expense,
  title,
}) => {
  const [formData, setFormData] = useState<ExpenseRequest>({
    description: '',
    amount: 0,
    category: '',
    date: new Date().toISOString().split('T')[0],
    vendor: '',
    invoice_number: '',
    payment_method: undefined,
    phone_number: '',
    tags: [],
    notes: '',
    receipt_images: [],
    invoice_image: null as any, // Will be set when file is selected
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [tagInput, setTagInput] = useState('');
  const [isGeneratingInvoice, setIsGeneratingInvoice] = useState(false);
  const [hasVendorInvoice, setHasVendorInvoice] = useState<boolean | null>(null);

  useEffect(() => {
    if (expense) {
      setFormData({
        description: expense.description || expense.title,
        amount: expense.amount,
        category: expense.expense_type,
        date: expense.date ? new Date(expense.date).toISOString().split('T')[0] : new Date().toISOString().split('T')[0],
        vendor: expense.vendor || '',
        invoice_number: expense.invoice_number || '',
        payment_method: expense.payment_method || undefined,
        phone_number: expense.phone_number || '',
        tags: expense.tags || [],
        notes: expense.notes || '',
        receipt_images: expense.receipt_images || [],
        invoice_image: null as any, // Editing doesn't require a new invoice image
      });
    } else {
      setFormData({
        description: '',
        amount: 0,
        category: 'office_supplies', // Set a default category
        date: new Date().toISOString().split('T')[0],
        vendor: '',
        invoice_number: '',
        payment_method: undefined,
        phone_number: '',
        tags: [],
        notes: '',
        receipt_images: [],
        invoice_image: null as any, // Required for new expenses
      });
    }
    setErrors({});
    setIsGeneratingInvoice(false);
    setHasVendorInvoice(null);
  }, [expense, isOpen]);

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!formData.description.trim()) {
      newErrors.description = 'Description is required';
    }

    if (!formData.amount || formData.amount <= 0) {
      newErrors.amount = 'Amount must be greater than 0';
    }

    if (formData.amount > 1000000) {
      newErrors.amount = 'Amount cannot exceed 1,000,000';
    }

    if (!formData.category || formData.category.trim() === '') {
      newErrors.category = 'Category is required';
    }

    if (!formData.date) {
      newErrors.date = 'Date is required';
    }

    // Only require invoice image for new expenses, not when editing
    if (!expense && !formData.invoice_image) {
      newErrors.invoice_image = 'Invoice image is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    // Transform the data to match backend expectations
    const transformedData: ExpenseRequest = {
      description: formData.description,
      amount: Number(formData.amount),
      category: formData.category, // Backend maps this to expense_type
      date: formData.date ? new Date(formData.date).toISOString() : new Date().toISOString(),
      vendor: formData.vendor || undefined,
      invoice_number: formData.invoice_number || undefined,
      payment_method: formData.payment_method || undefined,
      phone_number: formData.phone_number || undefined,
      tags: formData.tags && formData.tags.length > 0 ? formData.tags : undefined,
      notes: formData.notes || undefined,
      receipt_images: formData.receipt_images && formData.receipt_images.length > 0 ? formData.receipt_images : undefined,
      invoice_image: formData.invoice_image, // Include the invoice image file
    };

    console.log('Form: Submitting transformed expense data:', JSON.stringify(transformedData, null, 2));
    onSubmit(transformedData);
  };

  const handleInputChange = (field: keyof ExpenseRequest, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));

    // Clear error for this field
    if (errors[field]) {
      setErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }
  };

  const addTag = () => {
    if (tagInput.trim() && !formData.tags?.includes(tagInput.trim())) {
      handleInputChange('tags', [...(formData.tags || []), tagInput.trim()]);
      setTagInput('');
    }
  };

  const removeTag = (tagToRemove: string) => {
    handleInputChange('tags', formData.tags?.filter(tag => tag !== tagToRemove) || []);
  };

  const handleTagKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      addTag();
    }
  };

  const handleInvoiceImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validate file type - allow images and PDFs
      const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp', 'application/pdf'];
      if (!allowedTypes.includes(file.type)) {
        setErrors(prev => ({
          ...prev,
          invoice_image: 'Please select a valid file (JPEG, PNG, GIF, WebP, or PDF)'
        }));
        return;
      }

      // Validate file size (max 10MB)
      const maxSize = 10 * 1024 * 1024; // 10MB
      if (file.size > maxSize) {
        setErrors(prev => ({
          ...prev,
          invoice_image: 'File size must be less than 10MB'
        }));
        return;
      }

      // Clear any previous errors
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors.invoice_image;
        return newErrors;
      });

      // Update form data with the file
      handleInputChange('invoice_image', file);
    }
  };

  const removeInvoiceImage = () => {
    handleInputChange('invoice_image', null);
    
    // Reset file input
    const fileInput = document.getElementById('invoice_image') as HTMLInputElement;
    if (fileInput) {
      fileInput.value = '';
    }
  };

  const handleGenerateInvoice = async () => {
    try {
      setIsGeneratingInvoice(true);
      
      // Validate required fields before generating
      if (!formData.description?.trim()) {
        setErrors(prev => ({
          ...prev,
          description: 'Description is required to generate invoice'
        }));
        setIsGeneratingInvoice(false);
        return;
      }

      if (!formData.amount || formData.amount <= 0) {
        setErrors(prev => ({
          ...prev,
          amount: 'Amount is required to generate invoice'
        }));
        setIsGeneratingInvoice(false);
        return;
      }

      if (!formData.category?.trim()) {
        setErrors(prev => ({
          ...prev,
          category: 'Category is required to generate invoice'
        }));
        setIsGeneratingInvoice(false);
        return;
      }
      
      // Create expense data for PDF generation with correct field names
      const expenseDataForPDF = {
        title: formData.description.trim(),
        description: formData.description.trim(),
        amount: Number(formData.amount),
        expense_type: formData.category, // Backend expects expense_type, not category
        date: formData.date || new Date().toISOString().split('T')[0],
        vendor: formData.vendor?.trim() || undefined,
        invoice_number: formData.invoice_number?.trim() || undefined,
        payment_method: formData.payment_method || 'cash',
        payment_reference: undefined,
        tags: formData.tags && formData.tags.length > 0 ? formData.tags : undefined,
        notes: formData.notes?.trim() || undefined,
      };

      console.log('Generating PDF with data:', expenseDataForPDF);

      const blob = await generateExpenseInvoicePDF(expenseDataForPDF);
      
      // Create a URL for the blob and open it in a new tab for printing
      const blobUrl = URL.createObjectURL(blob);
      const fileName = `invoice-${formData.invoice_number?.trim() || Date.now()}.pdf`;
      
      // Open PDF in new tab/window for printing
      const newWindow = window.open(blobUrl, '_blank');
      if (!newWindow) {
        // Fallback: download the file if popup was blocked
        const link = document.createElement('a');
        link.href = blobUrl;
        link.download = fileName;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        console.error('PDF download started. Please print and sign the document, then upload the signed version.');
      } else {
        // Show instruction message
        console.error('PDF opened in new tab. Please print the document, sign it, and then upload the signed version using the file upload above.');
      }
      
      // Clean up the blob URL after a delay
      setTimeout(() => {
        URL.revokeObjectURL(blobUrl);
      }, 60000); // Clean up after 1 minute
      
      // Clear any previous errors
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors.description;
        delete newErrors.amount;
        delete newErrors.category;
        return newErrors;
      });
      
    } catch (error) {
      console.error('Error generating invoice:', error);
      setErrors(prev => ({
        ...prev,
        invoice_image: error instanceof Error ? error.message : 'Failed to generate invoice. Please try again.'
      }));
    } finally {
      setIsGeneratingInvoice(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
      <div className="relative top-10 mx-auto p-5 border max-w-2xl shadow-lg rounded-md bg-white">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-bold text-gray-900">{title}</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 text-2xl font-bold"
          >
            ×
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Description */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Description *
            </label>
            <input
              type="text"
              value={formData.description}
              onChange={(e) => handleInputChange('description', e.target.value)}
              className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                errors.description ? 'border-red-500' : 'border-gray-300'
              }`}
              placeholder="Enter expense description..."
            />
            {errors.description && (
              <p className="text-red-500 text-sm mt-1">{errors.description}</p>
            )}
          </div>

          {/* Amount and Category */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Amount *
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                value={formData.amount}
                onChange={(e) => handleInputChange('amount', parseFloat(e.target.value) || 0)}
                className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                  errors.amount ? 'border-red-500' : 'border-gray-300'
                }`}
                placeholder="0.00"
              />
              {errors.amount && (
                <p className="text-red-500 text-sm mt-1">{errors.amount}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Category *
              </label>
              <select
                value={formData.category}
                onChange={(e) => handleInputChange('category', e.target.value)}
                className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                  errors.category ? 'border-red-500' : 'border-gray-300'
                }`}
              >
                <option value="">Select category...</option>
                {EXPENSE_TYPES.map((type) => (
                  <option key={type.value} value={type.value}>
                    {type.icon} {type.label}
                  </option>
                ))}
              </select>
              {errors.category && (
                <p className="text-red-500 text-sm mt-1">{errors.category}</p>
              )}
            </div>
          </div>

          {/* Date and Vendor */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Date *
              </label>
              <input
                type="date"
                value={formData.date}
                onChange={(e) => handleInputChange('date', e.target.value)}
                className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                  errors.date ? 'border-red-500' : 'border-gray-300'
                }`}
              />
              {errors.date && (
                <p className="text-red-500 text-sm mt-1">{errors.date}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Vendor
              </label>
              <input
                type="text"
                value={formData.vendor}
                onChange={(e) => handleInputChange('vendor', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Vendor name..."
              />
            </div>
          </div>

          {/* Invoice Number and Payment Method */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Invoice Number
              </label>
              <input
                type="text"
                value={formData.invoice_number}
                onChange={(e) => handleInputChange('invoice_number', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Invoice #..."
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Payment Method
              </label>
              <select
                value={formData.payment_method || ''}
                onChange={(e) => handleInputChange('payment_method', e.target.value === '' ? undefined : e.target.value as any)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">Select payment method...</option>
                {PAYMENT_METHODS.map((method) => (
                  <option key={method.value} value={method.value}>
                    {method.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Phone Number */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Phone Number
            </label>
            <input
              type="tel"
              value={formData.phone_number}
              onChange={(e) => handleInputChange('phone_number', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="+971501234567"
            />
            <p className="text-xs text-gray-500 mt-1">
              Optional - Contact number for this expense
            </p>
          </div>

          {/* Tags */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Tags
            </label>
            <div className="flex space-x-2 mb-2">
              <input
                type="text"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyPress={handleTagKeyPress}
                className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Add tag and press Enter..."
              />
              <button
                type="button"
                onClick={addTag}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
              >
                Add
              </button>
            </div>
            <div className="flex flex-wrap gap-2">
              {formData.tags?.map((tag, index) => (
                <span
                  key={index}
                  className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-blue-100 text-blue-800"
                >
                  {tag}
                  <button
                    type="button"
                    onClick={() => removeTag(tag)}
                    className="ml-2 text-blue-600 hover:text-blue-800"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Notes
            </label>
            <textarea
              value={formData.notes}
              onChange={(e) => handleInputChange('notes', e.target.value)}
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Additional notes..."
            />
          </div>

          {/* Invoice Image Upload - Required for new expenses */}
          {!expense && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Invoice Image *
              </label>
              
              {/* Question about vendor invoice */}
              <div className="mb-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
                <p className="text-sm font-medium text-blue-900 mb-3">
                  Do you have an invoice from the vendor?
                </p>
                <div className="flex space-x-4">
                  <label className="flex items-center">
                    <input
                      type="radio"
                      name="hasVendorInvoice"
                      value="yes"
                      checked={hasVendorInvoice === true}
                      onChange={() => setHasVendorInvoice(true)}
                      className="mr-2 text-blue-600"
                    />
                    <span className="text-sm text-blue-800">Yes, I have an invoice</span>
                  </label>
                  <label className="flex items-center">
                    <input
                      type="radio"
                      name="hasVendorInvoice"
                      value="no"
                      checked={hasVendorInvoice === false}
                      onChange={() => setHasVendorInvoice(false)}
                      className="mr-2 text-blue-600"
                    />
                    <span className="text-sm text-blue-800">No, I need to generate one</span>
                  </label>
                </div>
              </div>

              {/* Show appropriate UI based on selection */}
              {hasVendorInvoice === true && (
                <div className="space-y-3">
                  <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                    <p className="text-sm text-green-800">
                      📎 Please upload your vendor invoice below
                    </p>
                  </div>
                  
                  <input
                    id="invoice_image"
                    type="file"
                    accept="image/*,.pdf"
                    onChange={handleInvoiceImageChange}
                    className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                      errors.invoice_image ? 'border-red-500' : 'border-gray-300'
                    }`}
                  />
                  
                  <p className="text-xs text-gray-500">
                    Upload an image or PDF of the vendor invoice (JPEG, PNG, GIF, WebP, or PDF, max 10MB)
                  </p>
                </div>
              )}

              {hasVendorInvoice === false && (
                <div className="space-y-3">
                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                    <p className="text-sm text-yellow-800 mb-2">
                      📄 <strong>Generate Invoice Workflow:</strong>
                    </p>
                    <ol className="text-xs text-yellow-700 space-y-1 ml-4 list-decimal">
                      <li>Fill out Description, Amount, and Category above</li>
                      <li>Click "Generate Invoice for Signing" button</li>
                      <li>Print the generated invoice from the new tab</li>
                      <li>Sign the printed invoice</li>
                      <li>Upload the signed invoice using the file input below</li>
                    </ol>
                  </div>
                  
                  {/* Generate Invoice Button */}
                  <div className="flex justify-center">
                    <button
                      type="button"
                      onClick={handleGenerateInvoice}
                      disabled={isGeneratingInvoice}
                      className={`px-6 py-3 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center ${
                        isGeneratingInvoice ? 'cursor-not-allowed' : ''
                      }`}
                    >
                      {isGeneratingInvoice ? (
                        <>
                          <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                          </svg>
                          Generating Invoice...
                        </>
                      ) : (
                        <>
                          📄 Generate Invoice for Signing
                        </>
                      )}
                    </button>
                  </div>
                  
                  {/* Upload section for signed invoice */}
                  <div className="border-t pt-3">
                    <p className="text-sm font-medium text-gray-700 mb-2">
                      Upload Signed Invoice:
                    </p>
                    <input
                      id="invoice_image"
                      type="file"
                      accept="image/*,.pdf"
                      onChange={handleInvoiceImageChange}
                      className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                        errors.invoice_image ? 'border-red-500' : 'border-gray-300'
                      }`}
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Upload the signed invoice (JPEG, PNG, GIF, WebP, or PDF, max 10MB)
                    </p>
                  </div>
                </div>
              )}

              {hasVendorInvoice === null && (
                <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 text-center">
                  <p className="text-sm text-gray-600">
                    👆 Please select whether you have a vendor invoice or need to generate one
                  </p>
                </div>
              )}

              {/* Current File Display */}
              {formData.invoice_image && (
                <div className="bg-gray-50 border rounded-md p-3 mt-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <svg className="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                      </svg>
                      <div>
                        <p className="text-sm font-medium text-gray-900">
                          {formData.invoice_image.name}
                        </p>
                        <p className="text-xs text-gray-500">
                          {(formData.invoice_image.size / 1024 / 1024).toFixed(2)} MB
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={removeInvoiceImage}
                      className="text-red-600 hover:text-red-800 text-sm"
                    >
                      Remove
                    </button>
                  </div>
                </div>
              )}

              {errors.invoice_image && (
                <p className="text-red-500 text-sm mt-2">{errors.invoice_image}</p>
              )}
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex justify-end space-x-3 pt-6 border-t">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
            >
              {expense ? 'Update Expense' : 'Create Expense'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ExpenseFormModal;
