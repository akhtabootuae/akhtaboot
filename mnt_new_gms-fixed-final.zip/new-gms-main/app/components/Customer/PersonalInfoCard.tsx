import { Customer } from '@/types/CustomerIndex';

interface PersonalInfoCardProps {
  customer: Customer;
  onEdit?: () => void;
}

export default function PersonalInfoCard({ customer, onEdit }: PersonalInfoCardProps) {
  return (
    <div className="p-5">
      <div className="flex justify-between items-center pb-3 mb-4 border-b border-gray-100">
        <h2 className="text-lg font-semibold text-gray-800">Personal Information</h2>
        {onEdit && (
          <button 
            onClick={onEdit} 
            className="flex items-center gap-1 bg-blue-600 text-white px-3 py-1.5 rounded-md hover:bg-blue-700 text-sm font-medium"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M17 3a2.85 2.85 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/>
            </svg>
            Edit
          </button>
        )}
      </div>
      <div className="grid grid-cols-2 gap-5">
        <div className="border-l-2 border-blue-100 pl-3">
          <p className="text-xs font-medium text-gray-500 uppercase tracking-wider mb-1">Name</p>
          <p className="text-sm font-medium text-gray-800">{customer.first_name} {customer.last_name}</p>
        </div>
        <div className="border-l-2 border-blue-100 pl-3">
          <p className="text-xs font-medium text-gray-500 uppercase tracking-wider mb-1">Email</p>
          <p className="text-sm font-medium text-gray-800">{customer.email}</p>
        </div>
        <div className="border-l-2 border-blue-100 pl-3">
          <p className="text-xs font-medium text-gray-500 uppercase tracking-wider mb-1">Phone</p>
          <p className="text-sm font-medium text-gray-800">{customer.phone || '—'}</p>
        </div>
        <div className="border-l-2 border-blue-100 pl-3">
          <p className="text-xs font-medium text-gray-500 uppercase tracking-wider mb-1">City</p>
          <p className="text-sm font-medium text-gray-800">{customer.city || '—'}</p>
        </div>
        <div className="border-l-2 border-blue-100 pl-3">
          <p className="text-xs font-medium text-gray-500 uppercase tracking-wider mb-1">Country</p>
          <p className="text-sm font-medium text-gray-800">{customer.country || '—'}</p>
        </div>
        {customer.branch && (
          <div className="border-l-2 border-blue-100 pl-3">
            <p className="text-xs font-medium text-gray-500 uppercase tracking-wider mb-1">Branch</p>
            <p className="text-sm font-medium text-gray-800">{customer.branch.branch_name}</p>
          </div>
        )}
      </div>
    </div>
  );
}
