import { Vehicle } from '@/types/CustomerIndex';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { useState, useEffect, useRef } from 'react';
import { toast } from 'react-hot-toast';
import { carMakes } from '@/app/new_reg/page';

interface VehicleFormData {
  make: string;
  model: string;
  license_plate: string;
  color: string;
}

const plateRegExp = /^[A-Z0-9- ]+$/i;
const colorRegExp = /^[A-Za-z- ]+$/;
const makeModelRegExp = /^[a-zA-Z0-9\s\-\.&]+$/;

const vehicleSchema = yup.object().shape({
  make: yup
    .string()
    .required('Make is required')
    .matches(makeModelRegExp, 'Make can only contain letters, numbers, spaces, hyphens, periods, and ampersands')
    .min(2, 'Make must be at least 2 characters')
    .max(50, 'Make must be less than 50 characters'),
  model: yup
    .string()
    .required('Model is required')
    .matches(makeModelRegExp, 'Model can only contain letters, numbers, spaces, hyphens, periods, and ampersands')
    .min(2, 'Model must be at least 2 characters')
    .max(50, 'Model must be less than 50 characters'),
  license_plate: yup
    .string()
    .required('License plate is required')
    .matches(plateRegExp, 'License plate can only contain letters, numbers, spaces, and hyphens')
    .min(2, 'License plate must be at least 2 characters')
    .max(10, 'License plate must be less than 10 characters'),
  color: yup
    .string()
    .required('Color is required')
    .matches(colorRegExp, 'Color can only contain letters, spaces, and hyphens')
    .min(2, 'Color must be at least 2 characters')
    .max(20, 'Color must be less than 20 characters'),
}) as yup.ObjectSchema<VehicleFormData>;

// Car models mapping (same as in StepOne)
const carModels: Record<string, string[]> = {
  "Toyota": ["Camry", "Corolla", "RAV4", "Land Cruiser", "Fortuner", "Prado", "Yaris"],
  "Honda": ["Civic", "Accord", "CR-V", "Pilot", "HR-V"],
  "Nissan": ["Altima", "Maxima", "Patrol", "Sunny", "X-Trail"],
  "BMW": ["3 Series", "5 Series", "7 Series", "X3", "X5", "X7"],
  "Mercedes-Benz": ["C-Class", "E-Class", "S-Class", "GLC", "GLE"],
  "Ford": ["F-150", "Mustang", "Explorer", "Escape", "Edge"],
  "Chevrolet": ["Tahoe", "Malibu", "Camaro", "Silverado", "Suburban"],
  "Hyundai": ["Sonata", "Elantra", "Tucson", "Santa Fe", "Accent"],
  "Kia": ["Optima", "Sorento", "Sportage", "Forte", "Soul"],
  "Audi": ["A4", "A6", "Q5", "Q7", "A8"],
  "Lexus": ["IS", "ES", "LS", "RX", "GX", "LX"],
  "Mazda": ["Mazda3", "Mazda6", "CX-5", "CX-9", "MX-5"],
  "Subaru": ["Outback", "Forester", "Impreza", "Legacy", "Crosstrek"],
  "Volkswagen": ["Jetta", "Passat", "Golf", "Tiguan", "Atlas"],
  "Jeep": ["Grand Cherokee", "Wrangler", "Cherokee", "Compass", "Renegade"],
  "Dodge": ["Charger", "Challenger", "Durango", "Journey", "Grand Caravan"],
  "Mitsubishi": ["Outlander", "Eclipse Cross", "Mirage", "Pajero", "L200"],
};

interface VehicleEditModalProps {
  vehicle: Vehicle;
  isOpen: boolean;
  isSaving: boolean;
  error: string | null;
  onClose: () => void;
  onSubmit: (data: VehicleFormData) => Promise<void>;
}

export default function VehicleEditModal({ 
  vehicle, 
  isOpen, 
  isSaving, 
  error, 
  onClose, 
  onSubmit 
}: VehicleEditModalProps) {
  const [showMakeDropdown, setShowMakeDropdown] = useState(false);
  const [showModelDropdown, setShowModelDropdown] = useState(false);
  const [filteredMakes, setFilteredMakes] = useState<string[]>([]);
  const [availableModels, setAvailableModels] = useState<string[]>([]);
  const [isCustomMake, setIsCustomMake] = useState(false);
  const [isCustomModel, setIsCustomModel] = useState(false);
  const [customMakes, setCustomMakes] = useState<Array<{name: string; addedAt: number}>>([]);
  const [customModels, setCustomModels] = useState<{[key: string]: Array<{name: string; addedAt: number}>}>({});
  const makeDropdownRef = useRef<HTMLDivElement>(null);
  const modelDropdownRef = useRef<HTMLDivElement>(null);

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    watch,
  } = useForm<VehicleFormData>({
    resolver: yupResolver(vehicleSchema),
    defaultValues: {
      make: vehicle.make,
      model: vehicle.model,
      license_plate: vehicle.license_plate,
      color: vehicle.color,
    }
  });

  const watchMake = watch('make');
  const watchModel = watch('model');

  // Load custom makes and models from localStorage
  useEffect(() => {
    const savedCustomMakes = localStorage.getItem('customCarMakes');
    if (savedCustomMakes) {
      try {
        const parsed = JSON.parse(savedCustomMakes);
        setCustomMakes(Array.isArray(parsed) ? parsed : []);
      } catch (error) {
        console.error('Error parsing custom makes:', error);
      }
    }

    const savedCustomModels = localStorage.getItem('customCarModels');
    if (savedCustomModels) {
      try {
        setCustomModels(JSON.parse(savedCustomModels) || {});
      } catch (error) {
        console.error('Error parsing custom models:', error);
      }
    }
  }, []);

  // Get all makes including custom ones
  const getAllMakes = (): string[] => {
    const customMakeNames = customMakes.map(m => m.name);
    return [...carMakes, ...customMakeNames];
  };

  // Get all models for a make including custom ones
  const getAllModelsForMake = (make: string): string[] => {
    const standardModels = carModels[make] || [];
    const savedCustomModels = customModels[make] || [];
    const customModelNames = savedCustomModels.map(m => m.name);
    return [...standardModels, ...customModelNames];
  };

  // Check if entry is custom
  const isCustomMakeEntry = (makeName: string): boolean => {
    return customMakes.some(m => m.name === makeName);
  };

  const isCustomModelEntry = (make: string, modelName: string): boolean => {
    return customModels[make]?.some(m => m.name === modelName) || false;
  };

  // Check if recently added (within 7 days)
  const isRecentlyAdded = (timestamp: number): boolean => {
    const sevenDaysAgo = Date.now() - (7 * 24 * 60 * 60 * 1000);
    return timestamp > sevenDaysAgo;
  };

  // Update available models when make changes
  useEffect(() => {
    if (watchMake && !isCustomMake) {
      setAvailableModels(getAllModelsForMake(watchMake));
    }
  }, [watchMake, customModels]);

  // Initialize filtered makes
  useEffect(() => {
    setFilteredMakes(getAllMakes());
  }, [customMakes]);
  
  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (makeDropdownRef.current && !makeDropdownRef.current.contains(e.target as Node)) {
        setShowMakeDropdown(false);
      }
      if (modelDropdownRef.current && !modelDropdownRef.current.contains(e.target as Node)) {
        setShowModelDropdown(false);
      }
    };
    
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      return () => {
        document.removeEventListener('mousedown', handleClickOutside);
      };
    }
  }, [isOpen]);

  // Handle make input change
  const handleMakeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setValue('make', value);
    
    if (!isCustomMake) {
      setFilteredMakes(
        getAllMakes().filter(make => 
          make.toLowerCase().includes(value.toLowerCase())
        )
      );
      setShowMakeDropdown(true);
    }
  };

  // Handle model input change
  const handleModelChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setValue('model', value);
    
    if (!isCustomModel) {
      setShowModelDropdown(true);
    }
  };

  // Handle make selection
  const handleMakeSelect = (make: string) => {
    if (make === "Other") {
      setIsCustomMake(true);
      setValue('make', '');
      setValue('model', '');
      setAvailableModels([]);
    } else {
      setValue('make', make);
      setIsCustomMake(false);
      setAvailableModels(getAllModelsForMake(make));
      setValue('model', '');
    }
    setShowMakeDropdown(false);
  };

  // Handle model selection
  const handleModelSelect = (model: string) => {
    if (model === "Other") {
      setIsCustomModel(true);
      setValue('model', '');
    } else {
      setValue('model', model);
      setIsCustomModel(false);
    }
    setShowModelDropdown(false);
  };

  // Save custom make
  const saveCustomMake = (make: string) => {
    if (!customMakes.some(m => m.name.toLowerCase() === make.toLowerCase())) {
      const updatedCustomMakes = [...customMakes, { name: make, addedAt: Date.now() }];
      setCustomMakes(updatedCustomMakes);
      localStorage.setItem('customCarMakes', JSON.stringify(updatedCustomMakes));
      toast.success(`Custom make "${make}" added successfully`);
    }
  };

  // Save custom model
  const saveCustomModel = (make: string, model: string) => {
    const updatedCustomModels = { ...customModels };
    if (!updatedCustomModels[make]) {
      updatedCustomModels[make] = [];
    }
    if (!updatedCustomModels[make].some(m => m.name.toLowerCase() === model.toLowerCase())) {
      updatedCustomModels[make].push({ name: model, addedAt: Date.now() });
      setCustomModels(updatedCustomModels);
      localStorage.setItem('customCarModels', JSON.stringify(updatedCustomModels));
      toast.success(`Custom model "${model}" added successfully`);
    }
  };

  // Handle custom make blur
  const handleCustomMakeBlur = () => {
    const make = watchMake?.trim();
    if (make && isCustomMake) {
      saveCustomMake(make);
      setIsCustomMake(false);
      setFilteredMakes(getAllMakes());
      setAvailableModels([]);
    }
  };

  // Handle custom model blur
  const handleCustomModelBlur = () => {
    const model = watchModel?.trim();
    if (model && watchMake && isCustomModel) {
      saveCustomModel(watchMake, model);
      setIsCustomModel(false);
      setAvailableModels(getAllModelsForMake(watchMake));
    }
  };

  // Remove custom make
  const removeCustomMake = (makeName: string) => {
    const updatedCustomMakes = customMakes.filter(m => m.name !== makeName);
    setCustomMakes(updatedCustomMakes);
    localStorage.setItem('customCarMakes', JSON.stringify(updatedCustomMakes));
    
    // Also remove custom models for this make
    const updatedCustomModels = { ...customModels };
    delete updatedCustomModels[makeName];
    setCustomModels(updatedCustomModels);
    localStorage.setItem('customCarModels', JSON.stringify(updatedCustomModels));
    
    setFilteredMakes(getAllMakes());
    
    if (watchMake === makeName) {
      setValue('make', '');
      setValue('model', '');
      setAvailableModels([]);
    }
    
    toast.success(`Custom make "${makeName}" removed`);
  };

  // Remove custom model
  const removeCustomModel = (make: string, modelName: string) => {
    const updatedCustomModels = { ...customModels };
    if (updatedCustomModels[make]) {
      updatedCustomModels[make] = updatedCustomModels[make].filter(m => m.name !== modelName);
      if (updatedCustomModels[make].length === 0) {
        delete updatedCustomModels[make];
      }
      setCustomModels(updatedCustomModels);
      localStorage.setItem('customCarModels', JSON.stringify(updatedCustomModels));
      
      setAvailableModels(getAllModelsForMake(watchMake));
      
      if (watchModel === modelName) {
        setValue('model', '');
      }
      
      toast.success(`Custom model "${modelName}" removed`);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-5 w-[600px] max-w-[90%]">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-semibold text-black">Edit Vehicle</h2>
          <button 
            onClick={onClose}
            className="text-black hover:text-gray-700 text-2xl"
          >
            ×
          </button>
        </div>
        
        {error && (
          <div className="bg-red-50 text-red-600 p-3 rounded mb-4">
            {error}
          </div>
        )}

        <div className="mb-4">
          <p className="text-sm text-gray-500">
            VIN: {vehicle.vin} | Year: {vehicle.year}
          </p>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            {/* Make Field */}
            <div className="relative" ref={makeDropdownRef}>
              <label className="block text-sm mb-1 text-black font-medium">Make</label>
              <input
                type="text"
                {...register('make')}
                onChange={handleMakeChange}
                onBlur={isCustomMake ? handleCustomMakeBlur : undefined}
                onFocus={() => !isCustomMake && setShowMakeDropdown(true)}
                className="w-full p-2 border rounded focus:border-blue-500 focus:outline-none text-black"
                placeholder={isCustomMake ? "Enter custom make..." : "Search make..."}
              />
              {errors.make && (
                <p className="text-red-500 text-xs mt-1">{errors.make.message}</p>
              )}
              
              {showMakeDropdown && !isCustomMake && (
                <div className="absolute z-50 mt-1 w-full bg-white shadow-lg border rounded-md max-h-60 overflow-auto">
                  <ul className="divide-y divide-gray-200">
                    {filteredMakes.map((make, index) => {
                      const isCustom = isCustomMakeEntry(make);
                      const customMake = customMakes.find(m => m.name === make);
                      const isRecent = customMake ? isRecentlyAdded(customMake.addedAt) : false;
                      
                      return (
                        <li key={index} className="hover:bg-blue-50 transition-colors cursor-pointer group">
                          <div className="w-full px-4 py-3 flex items-center justify-between">
                            <div 
                              className="flex-1 min-w-0 flex items-center gap-2"
                              onClick={() => handleMakeSelect(make)}
                            >
                              <p className="text-sm font-medium text-gray-900 truncate">
                                {make}
                              </p>
                              {isCustom && (
                                <span className={`text-xs px-2 py-0.5 rounded-full ${
                                  isRecent 
                                    ? 'bg-green-100 text-green-700' 
                                    : 'bg-gray-100 text-gray-600'
                                }`}>
                                  {isRecent ? 'New' : 'Custom'}
                                </span>
                              )}
                            </div>
                            {isCustom && (
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  removeCustomMake(make);
                                }}
                                className="opacity-0 group-hover:opacity-100 text-red-500 hover:text-red-700 p-1 transition-opacity"
                                title="Remove custom make"
                              >
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                </svg>
                              </button>
                            )}
                          </div>
                        </li>
                      );
                    })}
                    <li 
                      className="hover:bg-blue-50 transition-colors cursor-pointer border-t-2 border-gray-300"
                      onClick={() => handleMakeSelect("Other")}
                    >
                      <div className="w-full px-4 py-3 flex items-center">
                        <p className="text-sm font-medium text-blue-600 truncate">
                          + Add Custom Make
                        </p>
                      </div>
                    </li>
                  </ul>
                </div>
              )}
            </div>

            {/* Model Field */}
            <div className="relative" ref={modelDropdownRef}>
              <label className="block text-sm mb-1 text-black font-medium">Model</label>
              <input
                type="text"
                {...register('model')}
                onChange={handleModelChange}
                onBlur={isCustomModel ? handleCustomModelBlur : undefined}
                onFocus={() => watchMake && !isCustomModel && setShowModelDropdown(true)}
                className="w-full p-2 border rounded focus:border-blue-500 focus:outline-none text-black"
                placeholder={
                  isCustomModel 
                    ? "Enter custom model..." 
                    : watchMake 
                      ? "Search model..." 
                      : "Select make first"
                }
                disabled={!watchMake}
              />
              {errors.model && (
                <p className="text-red-500 text-xs mt-1">{errors.model.message}</p>
              )}
              
              {showModelDropdown && watchMake && !isCustomModel && (
                <div className="absolute z-50 mt-1 w-full bg-white shadow-lg border rounded-md max-h-60 overflow-auto">
                  <ul className="divide-y divide-gray-200">
                    {availableModels
                      .filter(model => 
                        model.toLowerCase().includes(watchModel?.toLowerCase() || '')
                      )
                      .map((model, index) => {
                        const isCustom = isCustomModelEntry(watchMake, model);
                        const customModel = customModels[watchMake]?.find(m => m.name === model);
                        const isRecent = customModel ? isRecentlyAdded(customModel.addedAt) : false;
                        
                        return (
                          <li key={index} className="hover:bg-blue-50 transition-colors cursor-pointer group">
                            <div className="w-full px-4 py-3 flex items-center justify-between">
                              <div 
                                className="flex-1 min-w-0 flex items-center gap-2"
                                onClick={() => handleModelSelect(model)}
                              >
                                <p className="text-sm font-medium text-gray-900 truncate">
                                  {model}
                                </p>
                                {isCustom && (
                                  <span className={`text-xs px-2 py-0.5 rounded-full ${
                                    isRecent 
                                      ? 'bg-green-100 text-green-700' 
                                      : 'bg-gray-100 text-gray-600'
                                  }`}>
                                    {isRecent ? 'New' : 'Custom'}
                                  </span>
                                )}
                              </div>
                              {isCustom && (
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    removeCustomModel(watchMake, model);
                                  }}
                                  className="opacity-0 group-hover:opacity-100 text-red-500 hover:text-red-700 p-1 transition-opacity"
                                  title="Remove custom model"
                                >
                                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                  </svg>
                                </button>
                              )}
                            </div>
                          </li>
                        );
                      })}
                    <li 
                      className="hover:bg-blue-50 transition-colors cursor-pointer border-t-2 border-gray-300"
                      onClick={() => handleModelSelect("Other")}
                    >
                      <div className="w-full px-4 py-3 flex items-center">
                        <p className="text-sm font-medium text-blue-600 truncate">
                          + Add Custom Model
                        </p>
                      </div>
                    </li>
                  </ul>
                </div>
              )}
            </div>
          </div>

          <div>
            <label className="block text-sm mb-1 text-black font-medium">License Plate</label>
            <input
              type="text"
              {...register('license_plate')}
              className="w-full p-2 border rounded focus:border-blue-500 focus:outline-none text-black uppercase"
            />
            {errors.license_plate && (
              <p className="text-red-500 text-xs mt-1">{errors.license_plate.message}</p>
            )}
          </div>

          <div>
            <label className="block text-sm mb-1 text-black font-medium">Color</label>
            <input
              type="text"
              {...register('color')}
              className="w-full p-2 border rounded focus:border-blue-500 focus:outline-none text-black"
            />
            {errors.color && (
              <p className="text-red-500 text-xs mt-1">{errors.color.message}</p>
            )}
          </div>

          <div className="flex justify-end gap-3 mt-6">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2 text-sm bg-gray-100 text-black rounded hover:bg-gray-200"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="px-6 py-2 text-sm bg-blue-500 text-white rounded hover:bg-blue-600 disabled:opacity-50"
            >
              {isSaving ? 'Saving...' : 'Save Changes'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}