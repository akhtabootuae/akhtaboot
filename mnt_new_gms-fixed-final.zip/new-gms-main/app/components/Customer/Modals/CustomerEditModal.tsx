import { Customer } from '@/types/CustomerIndex';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';

interface FormData {
  first_name: string;
  last_name: string;
  email: string;
  phone: string | null;
}

const nameRegExp = /^[A-Za-z\s-']+$/;
const phoneRegExp = /^\+?[1-9]\d{1,13}$/;
const emailRegExp = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}$/;

const schema = yup.object().shape({
  first_name: yup
    .string()
    .required('First name is required')
    .matches(nameRegExp, 'First name should only contain letters, spaces, hyphens, and apostrophes')
    .min(2, 'First name must be at least 2 characters')
    .max(50, 'First name must be less than 50 characters'),
  last_name: yup
    .string()
    .required('Last name is required')
    .matches(nameRegExp, 'Last name should only contain letters, spaces, hyphens, and apostrophes')
    .min(2, 'Last name must be at least 2 characters')
    .max(50, 'Last name must be less than 50 characters'),
  email: yup
    .string()
    .nullable()
    .transform((value) => (value === '' ? null : value))
    .matches(emailRegExp, 'Please enter a valid email address')
    .email('Must be a valid email'),
  phone: yup
    .string()
    .nullable()
    .transform((value) => (value === '' ? null : value))
    .max(14, 'Phone number cannot exceed 14 characters including +')
    .matches(phoneRegExp, 'Please enter a valid phone number (e.g., +1234567890)')
}) as yup.ObjectSchema<FormData>;

interface CustomerEditModalProps {
  customer: Customer;
  isOpen: boolean;
  isSaving: boolean;
  error: string | null;
  onClose: () => void;
  onSubmit: (data: FormData) => Promise<void>;
}

export default function CustomerEditModal({ 
  customer, 
  isOpen, 
  isSaving, 
  error, 
  onClose, 
  onSubmit 
}: CustomerEditModalProps) {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<FormData>({
    resolver: yupResolver(schema),
    defaultValues: {
      first_name: customer.first_name,
      last_name: customer.last_name,
      email: customer.email,
      phone: customer.phone || '',
    }
  });

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-5 w-[450px] max-w-[90%]">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-semibold text-black">Edit Customer</h2>
          <button 
            onClick={onClose}
            className="text-black hover:text-gray-700 text-2xl"
          >
            ×
          </button>
        </div>
        
        {error && (
          <div className="bg-red-50 text-red-600 p-3 rounded mb-4">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <label className="block text-sm mb-1 text-black font-medium">First Name</label>
            <input
              type="text"
              {...register('first_name')}
              className="w-full p-2 border rounded focus:border-blue-500 focus:outline-none text-black"
            />
            {errors.first_name && (
              <p className="text-red-500 text-xs mt-1">{errors.first_name.message}</p>
            )}
          </div>

          <div>
            <label className="block text-sm mb-1 text-black font-medium">Last Name</label>
            <input
              type="text"
              {...register('last_name')}
              className="w-full p-2 border rounded focus:border-blue-500 focus:outline-none text-black"
            />
            {errors.last_name && (
              <p className="text-red-500 text-xs mt-1">{errors.last_name.message}</p>
            )}
          </div>

          <div>
            <label className="block text-sm mb-1 text-black font-medium">Email</label>
            <input
              type="email"
              {...register('email')}
              className="w-full p-2 border rounded focus:border-blue-500 focus:outline-none text-black"
            />
            {errors.email && (
              <p className="text-red-500 text-xs mt-1">{errors.email.message}</p>
            )}
          </div>

          <div>
            <label className="block text-sm mb-1 text-black font-medium">
              Phone
              <span className="text-xs text-gray-500 ml-1">(Max 14 characters)</span>
            </label>
            <input
              type="tel"
              {...register('phone')}
              className="w-full p-2 border rounded focus:border-blue-500 focus:outline-none text-black"
              placeholder="+1234567890"
              maxLength={14}
            />
            {errors.phone && (
              <p className="text-red-500 text-xs mt-1">{errors.phone.message}</p>
            )}
          </div>

          <div className="flex justify-end gap-3 mt-6">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2 text-sm bg-gray-100 text-black rounded hover:bg-gray-200"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="px-6 py-2 text-sm bg-blue-500 text-white rounded hover:bg-blue-600 disabled:opacity-50"
            >
              {isSaving ? 'Saving...' : 'Save Changes'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
