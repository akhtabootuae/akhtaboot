import { WorkOrder, Vehicle } from '@/types/CustomerIndex';
import { useRouter } from 'next/navigation';

interface WorkOrdersCardProps {
  workOrders: WorkOrder[];
  vehicles: Vehicle[];
}

export default function WorkOrdersCard({ workOrders, vehicles }: WorkOrdersCardProps) {
  const router = useRouter();

  const handleWorkOrderClick = (workOrderId: string) => {
    router.push(`/workOrders/${workOrderId}`);
  };

  return (
    <div className="p-5">
      <div className="flex justify-between items-center pb-3 mb-4 border-b border-gray-100">
        <h2 className="text-lg font-semibold text-gray-800">Work Orders</h2>
        <div className="bg-blue-50 text-blue-600 text-xs font-medium px-2 py-1 rounded-full">
          {workOrders.length} {workOrders.length === 1 ? 'order' : 'orders'}
        </div>
      </div>
      <div className="space-y-5">
        {workOrders.length > 0 ? (
          workOrders.map((workOrder) => {
            const vehicle = vehicles.find(v => v.vehicle_id === workOrder.vehicle_id);
            
            return (
              <div 
                key={workOrder._id} 
                onClick={() => handleWorkOrderClick(workOrder._id)}
                className="bg-gray-50 rounded-lg p-4 border border-gray-100 cursor-pointer transition-all duration-200 hover:bg-gray-100 hover:border-gray-200 hover:shadow-md group"
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <span className={`text-sm font-medium py-1 px-2.5 rounded-full ${
                      workOrder.status === 'open' ? 'bg-yellow-100 text-yellow-800' : 
                      workOrder.status === 'in_progress' ? 'bg-blue-100 text-blue-800' :
                      workOrder.status === 'on_hold' ? 'bg-orange-100 text-orange-800' :
                      workOrder.status === 'completed' ? 'bg-green-100 text-green-800' : 
                      'bg-gray-100 text-gray-800'
                    }`}>
                      {workOrder.status.replace('_', ' ').toUpperCase()}
                    </span>
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-gray-500">
                      <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>
                    </svg>
                    <p className="text-base font-medium text-gray-800 group-hover:text-blue-600 transition-colors duration-200">
                      #{workOrder.workOrderNumber}
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="text-xs text-gray-500">
                      {new Date(workOrder.createdAt).toLocaleDateString()}
                    </div>
                    <div className="flex items-center text-xs text-gray-400 group-hover:text-blue-500 transition-colors duration-200">
                      <span className="mr-1">View details</span>
                      <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M9 18l6-6-6-6"/>
                      </svg>
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-x-6 gap-y-3">
                  <div className="border-l-2 border-blue-100 pl-3">
                    <p className="text-xs font-medium text-gray-500 uppercase tracking-wider mb-1">Description</p>
                    <p className="text-sm font-medium text-gray-800">
                      {workOrder.description || 'No description provided'}
                    </p>
                  </div>
                  
                  <div className="border-l-2 border-blue-100 pl-3">
                    <p className="text-xs font-medium text-gray-500 uppercase tracking-wider mb-1">Parts Status</p>
                    <p className="text-sm font-medium text-gray-800">
                      {workOrder.parts.filter(p => p.status === 'completed').length}/{workOrder.parts.length} completed
                    </p>
                  </div>
                  
                  {vehicle && (
                    <div className="border-l-2 border-blue-100 pl-3">
                      <p className="text-xs font-medium text-gray-500 uppercase tracking-wider mb-1">Vehicle</p>
                      <p className="text-sm font-medium text-gray-800">
                        {vehicle.make} {vehicle.model} ({vehicle.year})
                      </p>
                      <p className="text-xs text-gray-500">
                        License: {vehicle.license_plate}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            );
          })
        ) : (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" className="text-gray-300 mb-3">
              <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>
            </svg>
            <p className="text-base font-medium text-gray-600">No work orders found</p>
            <p className="text-sm text-gray-400">This customer has no service history yet</p>
          </div>
        )}
      </div>
    </div>
  );
}
