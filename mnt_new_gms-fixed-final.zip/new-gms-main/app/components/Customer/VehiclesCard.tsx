import { Vehicle } from '@/types/CustomerIndex';

interface VehiclesCardProps {
  vehicles: Vehicle[];
  onEditVehicle?: (vehicle: Vehicle) => void;
}

export default function VehiclesCard({ vehicles, onEditVehicle }: VehiclesCardProps) {
  return (
    <div className="p-5">
      <div className="flex justify-between items-center pb-3 mb-4 border-b border-gray-100">
        <h2 className="text-lg font-semibold text-gray-800">Vehicles</h2>
        <div className="bg-blue-50 text-blue-600 text-xs font-medium px-2 py-1 rounded-full">
          {vehicles.length} {vehicles.length === 1 ? 'vehicle' : 'vehicles'}
        </div>
      </div>
      
      {vehicles && vehicles.length > 0 ? (
        <div className="flex flex-col gap-4">
          {vehicles.map((vehicle) => (
            <div key={vehicle.vehicle_id} className="relative bg-gray-50 rounded-lg p-4 border border-gray-100 w-full">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-600 mr-2">
                    <path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2"/>
                    <circle cx="7" cy="17" r="2"/>
                    <path d="M9 17h6"/>
                    <circle cx="17" cy="17" r="2"/>
                  </svg>
                  <span className="font-medium text-gray-900">{vehicle.make} {vehicle.model}</span>
                </div>
                {onEditVehicle && (
                  <button
                    onClick={() => onEditVehicle(vehicle)}
                    className="flex items-center gap-1 text-blue-600 hover:text-blue-700 text-sm font-medium"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M17 3a2.85 2.85 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/>
                    </svg>
                    Edit
                  </button>
                )}
              </div>
              
              <div className="grid grid-cols-2 gap-x-6 gap-y-3">
                <div className="border-l-2 border-blue-100 pl-3">
                  <p className="text-xs font-medium text-gray-500 uppercase tracking-wider mb-1">Make</p>
                  <p className="text-sm font-medium text-gray-800">{vehicle.make}</p>
                </div>
                <div className="border-l-2 border-blue-100 pl-3">
                  <p className="text-xs font-medium text-gray-500 uppercase tracking-wider mb-1">License Plate</p>
                  <p className="text-sm font-medium text-gray-800">{vehicle.license_plate}</p>
                </div>
                <div className="border-l-2 border-blue-100 pl-3">
                  <p className="text-xs font-medium text-gray-500 uppercase tracking-wider mb-1">Model</p>
                  <p className="text-sm font-medium text-gray-800">{vehicle.model}</p>
                </div>
                <div className="border-l-2 border-blue-100 pl-3">
                  <p className="text-xs font-medium text-gray-500 uppercase tracking-wider mb-1">VIN</p>
                  <p className="text-sm font-medium text-gray-800">{vehicle.vin}</p>
                </div>
                <div className="border-l-2 border-blue-100 pl-3">
                  <p className="text-xs font-medium text-gray-500 uppercase tracking-wider mb-1">Year</p>
                  <p className="text-sm font-medium text-gray-800">{vehicle.year}</p>
                </div>
                <div className="border-l-2 border-blue-100 pl-3">
                  <p className="text-xs font-medium text-gray-500 uppercase tracking-wider mb-1">Color</p>
                  <p className="text-sm font-medium text-gray-800">{vehicle.color}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-sm text-black px-2">No vehicles registered</p>
      )}
    </div>
  );
}
