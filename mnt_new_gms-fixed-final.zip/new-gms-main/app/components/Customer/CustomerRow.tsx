'use client';

import Link from 'next/link';

interface CustomerRowProps {
  customer: {
    _id: string;
    first_name: string;
    last_name: string;
    email: string;
    phone?: string;
    vehicles?: any[];
    created_at?: string;
  };
}

const CustomerRow: React.FC<CustomerRowProps> = ({ customer }) => {
  const dateStr = customer.created_at;
  const since = dateStr && !isNaN(Date.parse(dateStr))
    ? new Date(dateStr).toLocaleDateString()
    : '—';

  return (
    <tr className="border-t hover:bg-gray-50">
      <td className="px-4 py-3">
        <Link
          href={`/Customers/${customer._id}`}
          className="font-medium text-gray-700 hover:text-blue-600"
        >
          {customer.first_name} {customer.last_name}
        </Link>
      </td>
      <td className="px-4 py-3 text-gray-600">
        {customer.email}
      </td>
      <td className="px-4 py-3 text-gray-600">
        {customer.phone || '—'}
      </td>
      <td className="px-4 py-3 text-gray-600">
        {customer.vehicles?.length || 0} vehicle
        {customer.vehicles?.length === 1 ? '' : 's'}
      </td>
      <td className="px-4 py-3 text-gray-500 text-sm">
        {since}
      </td>
      <td className="px-4 py-3 text-left">
        <Link
          href={`/Customers/${customer._id}`}
          className="text-blue-600 hover:text-blue-800 inline-flex items-center gap-1"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"></path>
            <circle cx="12" cy="12" r="3"></circle>
          </svg>
          View Details
        </Link>
      </td>
    </tr>
  );
};

export default CustomerRow;