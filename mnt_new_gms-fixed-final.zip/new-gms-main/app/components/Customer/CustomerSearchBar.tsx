'use client';

import React from 'react';
import { Input } from '../ui/input';
import { Search } from 'lucide-react';

interface Props {
  search: string;
  onSearchChange: (value: string) => void;
}

const CustomerSearchBar: React.FC<Props> = ({ search, onSearchChange }) => (
  <div className="flex items-center gap-2">
    {/* Search box */}
    <div className="relative flex-1">
      <Search
        size={18}
        className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
      />
      <Input
        type="text"
        value={search}
        onChange={e => onSearchChange(e.currentTarget.value)}
        placeholder="Search by name, email, phone, or vehicle details..."
        className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
      />
    </div>
    {/* Search button */}
    <button
      onClick={() => onSearchChange(search)}
      className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-sm font-medium"
    >
      Search
    </button>
  </div>
);

export default CustomerSearchBar;