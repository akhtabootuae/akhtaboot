"use client";

import React, { useState, useRef, useEffect } from "react";
import { Settings, User, LogOut, ChevronDown, MessageCircle, Bell, Menu, Wrench, DollarSign } from "lucide-react";
import { Input } from "../ui/input";
import { useCollapsed } from "../../context/CollapsedContext";
import { useAuth } from "../../context/AuthContext";
import { useNotifications } from "../../context/NotificationContext";
import { Badge } from "../ui/badge";
import Link from "next/link";
import { usePathname } from "next/navigation";

export default function NavBar({ title = "Page" }: { title?: string }) {
  const { collapsed, isMobile, toggle } = useCollapsed();
  const { user, logout, isAuthenticated } = useAuth();
  const { notificationStats } = useNotifications();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [settingsDropdownOpen, setSettingsDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const settingsDropdownRef = useRef<HTMLDivElement>(null);
  const pathname = usePathname();

  // Helper function for case-insensitive admin check
  const isAdmin = user?.role_name?.toLowerCase() === 'admin';

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownOpen(false);
      }
      if (settingsDropdownRef.current && !settingsDropdownRef.current.contains(event.target as Node)) {
        setSettingsDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  // Don't show navbar on login page
  if (pathname === '/login') {
    return null;
  }

  return (
    <nav
      className={
        `flex items-center justify-between bg-slate-100 border-b px-4 md:px-6
         transition-all duration-300
         ${collapsed ? "py-3" : "py-6 md:py-9"}`
      }
    >
      {/* Left side - Burger menu (mobile/tablet) + Page Title */}
      <div className="flex items-center gap-3">
        {/* Burger Menu Button - Only show on mobile/tablet */}
        {isMobile && (
          <button
            onClick={toggle}
            className="p-2 rounded-lg hover:bg-gray-200 transition-colors lg:hidden"
            aria-label="Toggle menu"
          >
            <Menu className="w-6 h-6 text-gray-700" />
          </button>
        )}
        
        {/* Page Title - Responsive text size */}
        <h1 className="text-lg md:text-xl lg:text-2xl font-semibold text-gray-800 truncate">
          {title}
        </h1>
      </div>

      {/* Right side - Actions */}
      <div className="flex items-center gap-2 md:gap-4">
        {/* Search - Hide on small screens, show on tablets and up */}
        <div className="hidden sm:block">
          <Input
            type="text"
            placeholder="Search..."
            className="px-3 py-1.5 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm w-32 md:w-48 lg:w-56"
          />
        </div>
        
        {/* Icons with responsive sizing */}
        <Link href="/Messaging" className="p-1.5 md:p-2 rounded hover:bg-gray-100">
          <MessageCircle className="w-5 h-5 md:w-6 md:h-6 text-gray-600" />
        </Link>
        
        <Link href="/notifications" className="p-1.5 md:p-2 rounded hover:bg-gray-100 relative">
          <Bell className="w-5 h-5 md:w-6 md:h-6 text-gray-600" />
          {notificationStats.unread > 0 && (
            <Badge
              variant={notificationStats.highPriority > 0 ? "destructive" : "default"}
              className="absolute -top-1 -right-1 h-4 w-4 md:h-5 md:w-5 flex items-center justify-center p-0 text-xs"
            >
              {notificationStats.unread > 99 ? "99+" : notificationStats.unread}
            </Badge>
          )}
        </Link>
        
        {isAdmin && (
          <div className="relative" ref={settingsDropdownRef}>
            <button 
              className="p-1.5 md:p-2 rounded hover:bg-gray-100"
              onClick={() => setSettingsDropdownOpen(!settingsDropdownOpen)}
            >
              <Settings className="w-5 h-5 md:w-6 md:h-6 text-gray-600" />
            </button>
            
            {settingsDropdownOpen && (
              <div className="absolute right-0 mt-2 w-56 bg-white rounded-md shadow-lg z-10">
                <div className="p-2">
                  <p className="px-3 py-2 text-sm font-semibold text-gray-700">Settings</p>
                  <Link 
                    href="/settings" 
                    className="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded"
                    onClick={() => setSettingsDropdownOpen(false)}
                  >
                    <div className="flex items-center gap-2">
                      <Wrench className="w-4 h-4" />
                      Variation Settings
                    </div>
                  </Link>
                  <Link 
                    href="/settings/system-deductions" 
                    className="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded"
                    onClick={() => setSettingsDropdownOpen(false)}
                  >
                    <div className="flex items-center gap-2">
                      <DollarSign className="w-4 h-4" />
                      System Deductions
                    </div>
                  </Link>
                </div>
              </div>
            )}
          </div>
        )}
        
        {isAuthenticated ? (
          <div className="relative" ref={dropdownRef}>
            <button 
              className="flex items-center gap-2 p-1 rounded-full hover:bg-gray-200"
              onClick={() => setDropdownOpen(!dropdownOpen)}
            >
              <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center text-white">
                {user?.name.charAt(0)}
              </div>
              <ChevronDown className="w-4 h-4 text-gray-600" />
            </button>
            
            {dropdownOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg z-10">
                <div className="p-3 border-b">
                  <p className="font-medium">{user?.name}</p>
                  <p className="text-sm text-gray-500">{user?.email}</p>
                  <p className="text-xs text-gray-500 mt-1">Role: {user?.role_name}</p>
                </div>
                <div>
                  <Link 
                    href="/profile" 
                    className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    onClick={() => setDropdownOpen(false)}
                  >
                    Profile Settings
                  </Link>
                  
                  <button 
                    onClick={() => {
                      logout();
                      setDropdownOpen(false);
                    }}
                    className="block w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-gray-100 border-t"
                  >
                    <div className="flex items-center gap-2">
                      <LogOut className="w-4 h-4" />
                      Sign out
                    </div>
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : (
          <Link 
            href="/login"
            className="flex items-center gap-2 px-4 py-2 rounded-md bg-blue-600 text-white hover:bg-blue-700"
          >
            <User className="w-4 h-4" />
            Sign in
          </Link>
        )}
      </div>
    </nav>
  )
}