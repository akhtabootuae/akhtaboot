'use client';

import React from 'react';
import { PieChart, BarChart3, TrendingUp, TrendingDown } from 'lucide-react';

interface ChartData {
  labels: string[];
  values: number[];
  colors?: string[];
}

interface FinanceChartProps {
  type: 'pie' | 'bar' | 'line';
  data: ChartData;
  title: string;
  height?: number;
  className?: string;
}

export const FinanceChart: React.FC<FinanceChartProps> = ({
  type,
  data,
  title,
  height = 300,
  className = ''
}) => {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-AE', {
      style: 'currency',
      currency: 'AED',
    }).format(amount);
  };

  const maxValue = Math.max(...data.values);
  const colors = data.colors || [
    '#3B82F6', '#EF4444', '#10B981', '#F59E0B', '#8B5CF6',
    '#EC4899', '#14B8A6', '#F97316', '#84CC16', '#6366F1'
  ];

  if (type === 'pie') {
    const total = data.values.reduce((sum, value) => sum + value, 0);
    let cumulativePercentage = 0;

    return (
      <div className={`bg-white rounded-lg shadow-sm border border-gray-200 p-6 ${className}`}>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">{title}</h3>
        <div className="flex items-center justify-center" style={{ height }}>
          <div className="relative">
            <svg width="200" height="200" viewBox="0 0 200 200">
              {data.labels.map((label, index) => {
                const percentage = (data.values[index] / total) * 100;
                const angle = (percentage / 100) * 360;
                const startAngle = (cumulativePercentage / 100) * 360;
                
                const startX = 100 + 80 * Math.cos((startAngle - 90) * Math.PI / 180);
                const startY = 100 + 80 * Math.sin((startAngle - 90) * Math.PI / 180);
                const endX = 100 + 80 * Math.cos((startAngle + angle - 90) * Math.PI / 180);
                const endY = 100 + 80 * Math.sin((startAngle + angle - 90) * Math.PI / 180);
                
                const largeArcFlag = angle > 180 ? 1 : 0;
                
                const pathData = `M 100 100 L ${startX} ${startY} A 80 80 0 ${largeArcFlag} 1 ${endX} ${endY} Z`;
                
                cumulativePercentage += percentage;
                
                return (
                  <path
                    key={index}
                    d={pathData}
                    fill={colors[index % colors.length]}
                    stroke="#fff"
                    strokeWidth="2"
                  />
                );
              })}
            </svg>
          </div>
          <div className="ml-8 space-y-2">
            {data.labels.map((label, index) => (
              <div key={index} className="flex items-center gap-2 text-sm">
                <div
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: colors[index % colors.length] }}
                />
                <span className="text-gray-600">{label}:</span>
                <span className="font-medium">{formatCurrency(data.values[index])}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (type === 'bar') {
    return (
      <div className={`bg-white rounded-lg shadow-sm border border-gray-200 p-6 ${className}`}>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">{title}</h3>
        <div style={{ height }}>
          <div className="h-full flex items-end justify-between gap-2">
            {data.labels.map((label, index) => {
              const barHeight = (data.values[index] / maxValue) * (height - 60);
              return (
                <div key={index} className="flex flex-col items-center flex-1">
                  <div className="text-xs text-gray-600 mb-2">
                    {formatCurrency(data.values[index])}
                  </div>
                  <div
                    className="w-full rounded-t"
                    style={{
                      height: `${barHeight}px`,
                      backgroundColor: colors[index % colors.length],
                      minHeight: '4px'
                    }}
                  />
                  <div className="text-xs text-gray-600 mt-2 text-center">
                    {label}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  if (type === 'line') {
    const svgHeight = height - 60;
    const svgWidth = 400;
    const padding = 40;
    
    const xStep = (svgWidth - 2 * padding) / (data.labels.length - 1);
    
    const points = data.values.map((value, index) => {
      const x = padding + index * xStep;
      const y = svgHeight - ((value / maxValue) * (svgHeight - 2 * padding)) - padding;
      return `${x},${y}`;
    }).join(' ');

    return (
      <div className={`bg-white rounded-lg shadow-sm border border-gray-200 p-6 ${className}`}>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">{title}</h3>
        <div style={{ height }}>
          <svg width={svgWidth} height={svgHeight} className="w-full">
            {/* Grid lines */}
            {[0, 0.25, 0.5, 0.75, 1].map((ratio) => {
              const y = svgHeight - (ratio * (svgHeight - 2 * padding)) - padding;
              return (
                <line
                  key={ratio}
                  x1={padding}
                  y1={y}
                  x2={svgWidth - padding}
                  y2={y}
                  stroke="#E5E7EB"
                  strokeWidth="1"
                />
              );
            })}
            
            {/* Line */}
            <polyline
              points={points}
              fill="none"
              stroke={colors[0]}
              strokeWidth="3"
              strokeLinejoin="round"
              strokeLinecap="round"
            />
            
            {/* Points */}
            {data.values.map((value, index) => {
              const x = padding + index * xStep;
              const y = svgHeight - ((value / maxValue) * (svgHeight - 2 * padding)) - padding;
              return (
                <circle
                  key={index}
                  cx={x}
                  cy={y}
                  r="4"
                  fill={colors[0]}
                  stroke="#fff"
                  strokeWidth="2"
                />
              );
            })}
          </svg>
          
          {/* X-axis labels */}
          <div className="flex justify-between mt-2 px-10">
            {data.labels.map((label, index) => (
              <div key={index} className="text-xs text-gray-600 text-center">
                {label}
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return null;
};

export default FinanceChart;
