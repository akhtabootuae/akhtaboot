'use client';

import React, { useState, useEffect } from 'react';
import { financeApi, dataApi } from '@/services/api';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  LineElement,
  PointElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Bar, Pie, Line } from 'react-chartjs-2';
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  PieChart,
  BarChart3,
  Building2,
  RefreshCw,
  Download,
  Filter,
  ChevronDown,
  AlertCircle,
  Activity,
  FileText,
  Database
} from 'lucide-react';
import type {
  RevenueData,
  ExpenseData,
  PayrollData,
  ProfitLossData,
  CashFlowData,
  FinancialSummary,
  BranchComparison,
  FinanceDashboard,
  FinanceFilters
} from '../../types/finance';

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  LineElement,
  PointElement,
  Title,
  Tooltip,
  Legend
);

interface StatCardProps {
  title: string;
  value: string;
  change?: string;
  changeType?: 'positive' | 'negative' | 'neutral';
  icon: React.ReactNode;
  loading?: boolean;
}

const StatCard: React.FC<StatCardProps> = ({ title, value, change, changeType, icon, loading }) => {
  const getBorderColor = () => {
    switch (changeType) {
      case 'positive': return 'border-green-500';
      case 'negative': return 'border-red-500';
      default: return 'border-blue-500';
    }
  };

  const getIconBgColor = () => {
    switch (changeType) {
      case 'positive': return 'bg-green-100';
      case 'negative': return 'bg-red-100';
      default: return 'bg-blue-100';
    }
  };

  const getIconTextColor = () => {
    switch (changeType) {
      case 'positive': return 'text-green-600';
      case 'negative': return 'text-red-600';
      default: return 'text-blue-600';
    }
  };

  const getValueColor = () => {
    switch (changeType) {
      case 'positive': return 'text-green-600';
      case 'negative': return 'text-red-600';
      default: return 'text-blue-600';
    }
  };

  return (
    <div className={`bg-white p-4 rounded-lg shadow-md border-l-4 ${getBorderColor()}`}>
      <div className="flex items-center">
        <div className={`${getIconBgColor()} p-2 rounded-full`}>
          <div className={`w-5 h-5 ${getIconTextColor()}`}>
            {icon}
          </div>
        </div>
        <div className="ml-3">
          <h3 className="text-sm font-semibold text-gray-700">{title}</h3>
          {loading ? (
            <div className="animate-pulse bg-gray-200 h-5 w-16 rounded mt-1"></div>
          ) : (
            <p className={`text-xl font-bold ${getValueColor()}`}>{value}</p>
          )}
          {change && !loading && (
            <p className="text-xs text-gray-500 mt-1">{change}</p>
          )}
        </div>
      </div>
    </div>
  );
};

interface FilterPanelProps {
  filters: FinanceFilters;
  onFiltersChange: (filters: FinanceFilters) => void;
  branches: Array<{ id: string; name: string; code: string }>;
  loading?: boolean;
}

const FilterPanel: React.FC<FilterPanelProps> = ({ filters, onFiltersChange, branches, loading }) => {
  const [isOpen, setIsOpen] = useState(false);

  const handleFilterChange = (key: keyof FinanceFilters, value: string) => {
    onFiltersChange({
      ...filters,
      [key]: value || undefined
    });
  };

  const clearFilters = () => {
    onFiltersChange({});
    setIsOpen(false);
  };

  const getQuickDateRange = (range: string) => {
    const today = new Date();
    const start = new Date(today);
    
    switch (range) {
      case 'today':
        return {
          start_date: today.toISOString().split('T')[0],
          end_date: today.toISOString().split('T')[0]
        };
      case 'week':
        start.setDate(today.getDate() - 7);
        return {
          start_date: start.toISOString().split('T')[0],
          end_date: today.toISOString().split('T')[0]
        };
      case 'month':
        start.setMonth(today.getMonth() - 1);
        return {
          start_date: start.toISOString().split('T')[0],
          end_date: today.toISOString().split('T')[0]
        };
      case 'quarter':
        start.setMonth(today.getMonth() - 3);
        return {
          start_date: start.toISOString().split('T')[0],
          end_date: today.toISOString().split('T')[0]
        };
      case 'year':
        start.setFullYear(today.getFullYear() - 1);
        return {
          start_date: start.toISOString().split('T')[0],
          end_date: today.toISOString().split('T')[0]
        };
      default:
        return {};
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 mb-6">
      <div className="p-4 border-b border-gray-200">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="flex items-center gap-2 text-sm font-medium text-gray-700 hover:text-gray-900"
          disabled={loading}
        >
          <Filter className="h-4 w-4" />
          Filters
          <ChevronDown className={`h-4 w-4 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
        </button>
      </div>
      
      {isOpen && (
        <div className="p-4 space-y-4">
          {/* Quick Date Range Buttons */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Quick Date Ranges</label>
            <div className="flex flex-wrap gap-2">
              {['today', 'week', 'month', 'quarter', 'year'].map((range) => (
                <button
                  key={range}
                  onClick={() => {
                    const dateRange = getQuickDateRange(range);
                    onFiltersChange({ ...filters, ...dateRange });
                  }}
                  className="px-3 py-1 text-xs font-medium bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 transition-colors"
                  disabled={loading}
                >
                  {range.charAt(0).toUpperCase() + range.slice(1)}
                </button>
              ))}
            </div>
          </div>

          {/* Custom Date Range */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Start Date</label>
              <input
                type="date"
                value={filters.start_date || ''}
                onChange={(e) => handleFilterChange('start_date', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                disabled={loading}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">End Date</label>
              <input
                type="date"
                value={filters.end_date || ''}
                onChange={(e) => handleFilterChange('end_date', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                disabled={loading}
              />
            </div>
          </div>

          {/* Branch Filter */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Branch</label>
            <select
              value={filters.branch_id || ''}
              onChange={(e) => handleFilterChange('branch_id', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
              disabled={loading}
            >
              <option value="">All Branches</option>
              {branches.map((branch) => (
                <option key={branch.id} value={branch.id}>
                  {branch.name} ({branch.code})
                </option>
              ))}
            </select>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2 pt-2">
            <button
              onClick={clearFilters}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200 transition-colors"
              disabled={loading}
            >
              Clear Filters
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default function FinancialAnalytics() {
  // State
  const [activeTab, setActiveTab] = useState<'dashboard' | 'revenue' | 'expenses' | 'payroll' | 'profit-loss' | 'cash-flow' | 'branches'>('dashboard');
  const [filters, setFilters] = useState<FinanceFilters>({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showExportDropdown, setShowExportDropdown] = useState(false);

  // Data state
  const [dashboardData, setDashboardData] = useState<FinanceDashboard | null>(null);
  const [revenueData, setRevenueData] = useState<RevenueData | null>(null);
  const [expenseData, setExpenseData] = useState<ExpenseData | null>(null);
  const [payrollData, setPayrollData] = useState<PayrollData | null>(null);
  const [profitLossData, setProfitLossData] = useState<ProfitLossData | null>(null);
  const [cashFlowData, setCashFlowData] = useState<CashFlowData | null>(null);
  const [branchData, setBranchData] = useState<BranchComparison | null>(null);
  const [summaryData, setSummaryData] = useState<FinancialSummary | null>(null);
  const [branches, setBranches] = useState<Array<{ id: string; name: string; code: string }>>([]);

  // Fetch branches on component mount
  useEffect(() => {
    const fetchBranches = async () => {
      try {
        const response = await dataApi.getBranches();
        const branchesData = response.data || response;
        if (Array.isArray(branchesData)) {
          setBranches(branchesData.map((branch: any) => ({
            id: branch._id || branch.id,
            name: branch.branch_name || branch.name,
            code: branch.branch_code || branch.code || 'N/A'
          })));
        }
      } catch (error) {
        console.error('Error fetching branches:', error);
        // Keep empty array as fallback
      }
    };

    fetchBranches();
  }, []);

  // Close export dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as Element;
      if (showExportDropdown && !target.closest('.export-dropdown')) {
        setShowExportDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [showExportDropdown]);

  // Format date or return 'Lifetime' for empty/invalid dates
  const formatDateOrLifetime = (dateString: string | undefined | null) => {
    if (!dateString || dateString === 'Invalid Date') {
      return 'Lifetime';
    }
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) {
        return 'Lifetime';
      }
      return date.toLocaleDateString();
    } catch {
      return 'Lifetime';
    }
  };

  // Format branch display name
  const formatBranchDisplay = (branchId: string | undefined | null) => {
    if (!branchId) {
      return 'All branches';
    }
    
    const branch = branches.find(b => b.id === branchId);
    if (branch) {
      return `${branch.name} (${branch.code})`;
    }
    
    return 'All branches';
  };

  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-AE', {
      style: 'currency',
      currency: 'AED',
    }).format(amount);
  };

  // Format percentage
  const formatPercentage = (value: number) => {
    return `${value.toFixed(2)}%`;
  };

  // Load data based on active tab and filters
  const loadData = async () => {
    setLoading(true);
    setError(null);

    try {
      switch (activeTab) {
        case 'dashboard':
          const [dashResult, summaryResult] = await Promise.all([
            financeApi.getDashboard(filters),
            financeApi.getSummary(filters)
          ]);
          setDashboardData(dashResult.data);
          setSummaryData(summaryResult.data);
          break;

        case 'revenue':
          const revenueResult = await financeApi.getRevenue(filters);
          setRevenueData(revenueResult.data);
          break;

        case 'expenses':
          const expenseResult = await financeApi.getExpenses(filters);
          setExpenseData(expenseResult.data);
          break;

        case 'payroll':
          const payrollResult = await financeApi.getPayroll(filters);
          setPayrollData(payrollResult.data);
          break;

        case 'profit-loss':
          const profitLossResult = await financeApi.getProfitLoss(filters);
          setProfitLossData(profitLossResult.data);
          break;

        case 'cash-flow':
          const cashFlowResult = await financeApi.getCashFlow(filters);
          setCashFlowData(cashFlowResult.data);
          break;

        case 'branches':
          const branchResult = await financeApi.getBranchComparison(filters);
          setBranchData(branchResult.data);
          break;
      }
    } catch (err) {
      console.error('Error loading finance data:', err);
      setError('Failed to load financial data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Load data when tab or filters change
  useEffect(() => {
    loadData();
  }, [activeTab, filters]);

  // Export handlers - Complete export functionality preserved
  const handleExport = async (exportType: string = 'summary', detailed: boolean = false) => {
    try {
      setLoading(true);
      
      const exportFilters = {
        ...filters,
        type: exportType
      };

      let response;
      if (detailed) {
        response = await financeApi.exportDetailedCSV(exportFilters);
      } else {
        response = await financeApi.exportCSV(exportFilters);
      }

      // Create blob and download
      const blob = new Blob([response.data], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      
      // Extract filename from response headers or create default
      const contentDisposition = response.headers['content-disposition'];
      let filename = 'financial_export.csv';
      if (contentDisposition) {
        const filenameMatch = contentDisposition.match(/filename="(.+)"/);
        if (filenameMatch) {
          filename = filenameMatch[1];
        }
      }
      
      link.setAttribute('download', filename);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
      
    } catch (error) {
      console.error('Export failed:', error);
      setError('Failed to export data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const tabs = [
    { id: 'dashboard', label: 'Dashboard', icon: Activity },
    { id: 'revenue', label: 'Revenue', icon: TrendingUp },
    { id: 'expenses', label: 'Expenses', icon: TrendingDown },
    { id: 'payroll', label: 'Payroll', icon: DollarSign },
    { id: 'profit-loss', label: 'P&L', icon: BarChart3 },
    { id: 'cash-flow', label: 'Cash Flow', icon: PieChart },
    { id: 'branches', label: 'Branches', icon: Building2 },
  ];

  return (
    <div className="space-y-4">
      {/* Header with Export Functionality */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Financial Analytics</h3>
          <p className="text-gray-600 text-xs mt-1">
            Comprehensive financial analytics and reporting
          </p>
        </div>
        <div className="flex items-center gap-3">
          {/* Export Dropdown - Complete functionality preserved */}
          <div className="relative export-dropdown">
            <button
              onClick={() => setShowExportDropdown(!showExportDropdown)}
              className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              disabled={loading}
            >
              <Download className="h-4 w-4" />
              Export
              <ChevronDown className="h-4 w-4" />
            </button>
            
            {showExportDropdown && (
              <div className="absolute right-0 mt-2 w-64 bg-white rounded-lg shadow-lg border border-gray-200 z-10">
                <div className="p-2">
                  <div className="text-xs font-medium text-gray-500 px-3 py-2">Summary Reports</div>
                  <button
                    onClick={() => {
                      handleExport('summary');
                      setShowExportDropdown(false);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-sm text-left hover:bg-gray-50 rounded"
                  >
                    <FileText className="h-4 w-4" />
                    Financial Summary
                  </button>
                  <button
                    onClick={() => {
                      handleExport('revenue');
                      setShowExportDropdown(false);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-sm text-left hover:bg-gray-50 rounded"
                  >
                    <TrendingUp className="h-4 w-4" />
                    Revenue Report
                  </button>
                  <button
                    onClick={() => {
                      handleExport('expenses');
                      setShowExportDropdown(false);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-sm text-left hover:bg-gray-50 rounded"
                  >
                    <TrendingDown className="h-4 w-4" />
                    Expenses Report
                  </button>
                  <button
                    onClick={() => {
                      handleExport('payroll');
                      setShowExportDropdown(false);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-sm text-left hover:bg-gray-50 rounded"
                  >
                    <DollarSign className="h-4 w-4" />
                    Payroll Report
                  </button>
                  <button
                    onClick={() => {
                      handleExport('branches');
                      setShowExportDropdown(false);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-sm text-left hover:bg-gray-50 rounded"
                  >
                    <Building2 className="h-4 w-4" />
                    Branch Comparison
                  </button>
                  
                  <hr className="my-2" />
                  
                  <div className="text-xs font-medium text-gray-500 px-3 py-2">Detailed Data</div>
                  <button
                    onClick={() => {
                      handleExport('invoices', true);
                      setShowExportDropdown(false);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-sm text-left hover:bg-gray-50 rounded"
                  >
                    <Database className="h-4 w-4" />
                    Detailed Invoices
                  </button>
                  <button
                    onClick={() => {
                      handleExport('expenses', true);
                      setShowExportDropdown(false);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-sm text-left hover:bg-gray-50 rounded"
                  >
                    <Database className="h-4 w-4" />
                    Detailed Expenses
                  </button>
                  <button
                    onClick={() => {
                      handleExport('payroll', true);
                      setShowExportDropdown(false);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-sm text-left hover:bg-gray-50 rounded"
                  >
                    <Database className="h-4 w-4" />
                    Detailed Payroll
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Filters */}
      <FilterPanel
        filters={filters}
        onFiltersChange={setFilters}
        branches={branches}
        loading={loading}
      />

      {/* Error Message */}
      {error && (
        <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2">
          <AlertCircle className="h-4 w-4 text-red-600" />
          <p className="text-red-700 text-sm">{error}</p>
        </div>
      )}

      {/* Navigation Tabs */}
      <div className="border-b border-gray-200">
        <nav className="flex space-x-6">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 py-3 px-1 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <Icon className="h-4 w-4" />
                {tab.label}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Tab Content - All content preserved from finance page */}
      <div className="space-y-4">
        {/* Dashboard Tab */}
        {activeTab === 'dashboard' && (
          <div className="space-y-4">
            {summaryData && (
              <>
                {/* Key Metrics */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <StatCard
                    title="Total Revenue"
                    value={formatCurrency(summaryData.key_metrics.total_revenue)}
                    icon={<TrendingUp className="h-5 w-5" />}
                    loading={loading}
                  />
                  <StatCard
                    title="Total Expenses"
                    value={formatCurrency(summaryData.key_metrics.total_expenses)}
                    icon={<TrendingDown className="h-5 w-5" />}
                    loading={loading}
                  />
                  <StatCard
                    title="Net Profit"
                    value={formatCurrency(summaryData.key_metrics.net_profit)}
                    changeType={summaryData.key_metrics.net_profit >= 0 ? 'positive' : 'negative'}
                    icon={<BarChart3 className="h-5 w-5" />}
                    loading={loading}
                  />
                  <StatCard
                    title="Profit Margin"
                    value={formatPercentage(summaryData.key_metrics.profit_margin)}
                    changeType={summaryData.key_metrics.profit_margin >= 0 ? 'positive' : 'negative'}
                    icon={<PieChart className="h-5 w-5" />}
                    loading={loading}
                  />
                </div>

                {/* Period Info */}
                <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
                  <h3 className="text-base font-semibold text-gray-900 mb-3">Report Period</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm">
                    <div>
                      <span className="text-gray-600">Start Date:</span>
                      <span className="ml-2 font-medium">
                        {formatDateOrLifetime(summaryData.period.start_date)}
                      </span>
                    </div>
                    <div>
                      <span className="text-gray-600">End Date:</span>
                      <span className="ml-2 font-medium">
                        {formatDateOrLifetime(summaryData.period.end_date)}
                      </span>
                    </div>
                    <div>
                      <span className="text-gray-600">Branch:</span>
                      <span className="ml-2 font-medium">{formatBranchDisplay(summaryData.period.branch_id)}</span>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        )}

        {/* Revenue Tab - Complete content preserved */}
        {activeTab === 'revenue' && revenueData && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <StatCard
                title="Total Revenue"
                value={formatCurrency(revenueData.total_revenue)}
                icon={<DollarSign className="h-5 w-5" />}
                loading={loading}
              />
              <StatCard
                title="Total Invoices"
                value={revenueData.total_invoices.toLocaleString()}
                icon={<BarChart3 className="h-5 w-5" />}
                loading={loading}
              />
              <StatCard
                title="Avg Invoice Value"
                value={formatCurrency(revenueData.average_invoice_value)}
                icon={<TrendingUp className="h-5 w-5" />}
                loading={loading}
              />
              <StatCard
                title="Amount Paid"
                value={formatCurrency(revenueData.total_paid)}
                icon={<PieChart className="h-5 w-5" />}
                loading={loading}
              />
              <StatCard
                title="Outstanding"
                value={formatCurrency(revenueData.outstanding_amount)}
                changeType="negative"
                icon={<AlertCircle className="h-5 w-5" />}
                loading={loading}
              />
              <StatCard
                title="VAT Amount"
                value={formatCurrency(revenueData.total_vat_amount)}
                icon={<DollarSign className="h-5 w-5" />}
                loading={loading}
              />
            </div>

            {/* Revenue Breakdown Chart */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <div className="bg-white p-4 rounded-lg shadow-md">
                <h4 className="text-base font-semibold text-gray-900 mb-3">Revenue vs Outstanding</h4>
                <div style={{ height: '250px' }}>
                  <Pie
                    data={{
                      labels: ['Paid Amount', 'Outstanding Amount'],
                      datasets: [{
                        data: [revenueData.total_paid, revenueData.outstanding_amount],
                        backgroundColor: ['#10B981', '#EF4444'],
                        borderWidth: 2,
                        borderColor: '#fff'
                      }]
                    }}
                    options={{
                      responsive: true,
                      maintainAspectRatio: false,
                      plugins: {
                        title: { display: false },
                        legend: { display: false },
                        tooltip: {
                          callbacks: {
                            label: (context: any) => {
                              const label = context.label || '';
                              const value = formatCurrency(context.parsed);
                              return `${label}: ${value}`;
                            }
                          }
                        }
                      }
                    }}
                  />
                </div>
                {/* Custom Legend */}
                <div className="mt-4 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
                      <span className="text-sm text-gray-600">Paid Amount:</span>
                    </div>
                    <span className="text-sm font-medium text-gray-900">{formatCurrency(revenueData.total_paid)}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-3 h-3 bg-red-500 rounded-full mr-2"></div>
                      <span className="text-sm text-gray-600">Outstanding Amount:</span>
                    </div>
                    <span className="text-sm font-medium text-gray-900">{formatCurrency(revenueData.outstanding_amount)}</span>
                  </div>
                </div>
              </div>
              
              <div className="bg-white p-4 rounded-lg shadow-md">
                <h4 className="text-base font-semibold text-gray-900 mb-3">Revenue with VAT Breakdown</h4>
                <div style={{ height: '250px' }}>
                  <Pie
                    data={{
                      labels: ['Revenue (Before VAT)', 'VAT Amount'],
                      datasets: [{
                        data: [revenueData.total_revenue_before_vat, revenueData.total_vat_amount],
                        backgroundColor: ['#3B82F6', '#F59E0B'],
                        borderWidth: 2,
                        borderColor: '#fff'
                      }]
                    }}
                    options={{
                      responsive: true,
                      maintainAspectRatio: false,
                      plugins: {
                        title: { display: false },
                        legend: { display: false },
                        tooltip: {
                          callbacks: {
                            label: (context: any) => {
                              const label = context.label || '';
                              const value = formatCurrency(context.parsed);
                              return `${label}: ${value}`;
                            }
                          }
                        }
                      }
                    }}
                  />
                </div>
                {/* Custom Legend */}
                <div className="mt-4 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-3 h-3 bg-blue-500 rounded-full mr-2"></div>
                      <span className="text-sm text-gray-600">Revenue (Before VAT):</span>
                    </div>
                    <span className="text-sm font-medium text-gray-900">{formatCurrency(revenueData.total_revenue_before_vat)}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-3 h-3 bg-amber-500 rounded-full mr-2"></div>
                      <span className="text-sm text-gray-600">VAT Amount:</span>
                    </div>
                    <span className="text-sm font-medium text-gray-900">{formatCurrency(revenueData.total_vat_amount)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Expenses Tab */}
        {activeTab === 'expenses' && expenseData && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <StatCard
                title="Total Expenses"
                value={formatCurrency(expenseData.summary.total_amount)}
                icon={<TrendingDown className="h-5 w-5" />}
                loading={loading}
              />
              <StatCard
                title="Number of Expenses"
                value={expenseData.summary.total_expenses.toLocaleString()}
                icon={<BarChart3 className="h-5 w-5" />}
                loading={loading}
              />
              <StatCard
                title="Average Expense"
                value={formatCurrency(expenseData.summary.average_expense)}
                icon={<DollarSign className="h-5 w-5" />}
                loading={loading}
              />
            </div>

            {/* Expense Categories */}
            {expenseData.by_category.length > 0 && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
                  <h3 className="text-base font-semibold text-gray-900 mb-3">Expenses by Category</h3>
                  <div className="space-y-3">
                    {expenseData.by_category.map((category: any) => (
                      <div key={category._id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium text-gray-900 capitalize">
                            {category._id.replace('_', ' ')}
                          </p>
                          <p className="text-sm text-gray-600">
                            {category.count} expense{category.count !== 1 ? 's' : ''}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold text-gray-900">
                            {formatCurrency(category.total_amount)}
                          </p>
                          <p className="text-sm text-gray-600">
                            Avg: {formatCurrency(category.average_amount)}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div className="bg-white p-4 rounded-lg shadow-md">
                  <h4 className="text-base font-semibold text-gray-900 mb-3">Expenses by Category</h4>
                  <div style={{ height: '250px' }}>
                    <Pie
                      data={{
                        labels: expenseData.by_category.map((cat: any) => cat._id.replace('_', ' ')),
                        datasets: [{
                          data: expenseData.by_category.map((cat: any) => cat.total_amount),
                          backgroundColor: ['#EF4444', '#F59E0B', '#10B981', '#3B82F6', '#8B5CF6'],
                          borderWidth: 2,
                          borderColor: '#fff'
                        }]
                      }}
                      options={{
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                          title: { display: false },
                          legend: { display: false },
                          tooltip: {
                            callbacks: {
                              label: (context: any) => {
                                const label = context.label || '';
                                const value = formatCurrency(context.parsed);
                                return `${label}: ${value}`;
                              }
                            }
                          }
                        }
                      }}
                    />
                  </div>
                  {/* Custom Legend */}
                  <div className="mt-4 space-y-2">
                    {expenseData.by_category.map((category: any, index: number) => {
                      const colors = ['#EF4444', '#F59E0B', '#10B981', '#3B82F6', '#8B5CF6'];
                      return (
                        <div key={category._id} className="flex items-center justify-between">
                          <div className="flex items-center">
                            <div 
                              className="w-3 h-3 rounded-full mr-2" 
                              style={{ backgroundColor: colors[index % colors.length] }}
                            ></div>
                            <span className="text-sm text-gray-600 capitalize">
                              {category._id.replace('_', ' ')}:
                            </span>
                          </div>
                          <span className="text-sm font-medium text-gray-900">
                            {formatCurrency(category.total_amount)}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Payroll Tab */}
        {activeTab === 'payroll' && payrollData && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <StatCard
                title="Total Employees"
                value={payrollData.employee_count.toLocaleString()}
                icon={<DollarSign className="h-6 w-6" />}
                loading={loading}
              />
              <StatCard
                title="Total Gross Pay"
                value={formatCurrency(payrollData.total_gross_pay)}
                icon={<TrendingUp className="h-6 w-6" />}
                loading={loading}
              />
              <StatCard
                title="Total Net Pay"
                value={formatCurrency(payrollData.total_net_pay)}
                icon={<DollarSign className="h-6 w-6" />}
                loading={loading}
              />
              <StatCard
                title="Total Deductions"
                value={formatCurrency(payrollData.total_deductions)}
                icon={<TrendingDown className="h-6 w-6" />}
                loading={loading}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Pay Breakdown</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Regular Pay:</span>
                    <span className="font-medium">{formatCurrency(payrollData.total_regular_pay)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Overtime Pay:</span>
                    <span className="font-medium">{formatCurrency(payrollData.total_overtime_pay)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Average Gross Pay:</span>
                    <span className="font-medium">{formatCurrency(payrollData.average_gross_pay)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Average Net Pay:</span>
                    <span className="font-medium">{formatCurrency(payrollData.average_net_pay)}</span>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Hours Summary</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Total Hours:</span>
                    <span className="font-medium">{payrollData.total_hours.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Overtime Hours:</span>
                    <span className="font-medium">{payrollData.total_overtime_hours.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Avg Hours per Employee:</span>
                    <span className="font-medium">
                      {(payrollData.total_hours / payrollData.employee_count).toFixed(1)}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Profit & Loss Tab */}
        {activeTab === 'profit-loss' && profitLossData && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <StatCard
                title="Gross Profit"
                value={formatCurrency(profitLossData.period_summary.gross_profit)}
                changeType={profitLossData.period_summary.gross_profit >= 0 ? 'positive' : 'negative'}
                icon={<TrendingUp className="h-6 w-6" />}
                loading={loading}
              />
              <StatCard
                title="Net Profit"
                value={formatCurrency(profitLossData.period_summary.net_profit)}
                changeType={profitLossData.period_summary.net_profit >= 0 ? 'positive' : 'negative'}
                icon={<BarChart3 className="h-6 w-6" />}
                loading={loading}
              />
              <StatCard
                title="Profit Margin"
                value={formatPercentage(profitLossData.period_summary.profit_margin)}
                changeType={profitLossData.period_summary.profit_margin >= 0 ? 'positive' : 'negative'}
                icon={<PieChart className="h-6 w-6" />}
                loading={loading}
              />
              <StatCard
                title="Net Margin"
                value={formatPercentage(profitLossData.period_summary.net_profit_margin)}
                changeType={profitLossData.period_summary.net_profit_margin >= 0 ? 'positive' : 'negative'}
                icon={<DollarSign className="h-6 w-6" />}
                loading={loading}
              />
            </div>

            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Profit & Loss Statement</h3>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4 p-4 bg-green-50 rounded-lg">
                  <div>
                    <h4 className="font-medium text-green-900">Revenue</h4>
                    <p className="text-2xl font-bold text-green-700">
                      {formatCurrency(profitLossData.period_summary.total_revenue)}
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium text-green-900">Paid Amount</h4>
                    <p className="text-lg font-semibold text-green-600">
                      {formatCurrency(profitLossData.period_summary.total_paid)}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 p-4 bg-red-50 rounded-lg">
                  <div>
                    <h4 className="font-medium text-red-900">Total Costs</h4>
                    <p className="text-2xl font-bold text-red-700">
                      {formatCurrency(profitLossData.period_summary.total_costs)}
                    </p>
                    <div className="mt-2 text-sm text-red-600">
                      <div>Expenses: {formatCurrency(profitLossData.period_summary.total_expenses)}</div>
                      <div>Payroll: {formatCurrency(profitLossData.period_summary.total_payroll_costs)}</div>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-medium text-red-900">Outstanding</h4>
                    <p className="text-lg font-semibold text-red-600">
                      {formatCurrency(profitLossData.period_summary.outstanding_amount)}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Cash Flow Tab */}
        {activeTab === 'cash-flow' && cashFlowData && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <StatCard
                title="Cash Inflows"
                value={formatCurrency(cashFlowData.cash_inflows.total)}
                changeType="positive"
                icon={<TrendingUp className="h-6 w-6" />}
                loading={loading}
              />
              <StatCard
                title="Cash Outflows"
                value={formatCurrency(cashFlowData.cash_outflows.total)}
                changeType="negative"
                icon={<TrendingDown className="h-6 w-6" />}
                loading={loading}
              />
              <StatCard
                title="Net Cash Flow"
                value={formatCurrency(cashFlowData.net_cash_flow)}
                changeType={cashFlowData.net_cash_flow >= 0 ? 'positive' : 'negative'}
                icon={<BarChart3 className="h-6 w-6" />}
                loading={loading}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Cash Inflows</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">From Invoices:</span>
                    <span className="font-medium text-green-600">
                      {formatCurrency(cashFlowData.cash_inflows.from_invoices)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Pending Receivables:</span>
                    <span className="font-medium text-yellow-600">
                      {formatCurrency(cashFlowData.cash_inflows.pending_receivables)}
                    </span>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Cash Outflows</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Expenses:</span>
                    <span className="font-medium text-red-600">
                      {formatCurrency(cashFlowData.cash_outflows.expenses)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Payroll:</span>
                    <span className="font-medium text-red-600">
                      {formatCurrency(cashFlowData.cash_outflows.payroll)}
                    </span>
                  </div>
                  <div className="flex justify-between pt-2 border-t border-gray-200">
                    <span className="text-gray-600">Cash Flow Ratio:</span>
                    <span className="font-medium">
                      {cashFlowData.cash_flow_ratio.toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Branches Tab */}
        {activeTab === 'branches' && branchData && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <StatCard
                title="Total Branches"
                value={branchData.totals.branch_count.toString()}
                icon={<Building2 className="h-6 w-6" />}
                loading={loading}
              />
              <StatCard
                title="Total Revenue"
                value={formatCurrency(branchData.totals.total_revenue)}
                icon={<TrendingUp className="h-6 w-6" />}
                loading={loading}
              />
              <StatCard
                title="Total Expenses"
                value={formatCurrency(branchData.totals.total_expenses)}
                icon={<TrendingDown className="h-6 w-6" />}
                loading={loading}
              />
              <StatCard
                title="Total Profit"
                value={formatCurrency(branchData.totals.total_profit)}
                changeType={branchData.totals.total_profit >= 0 ? 'positive' : 'negative'}
                icon={<BarChart3 className="h-6 w-6" />}
                loading={loading}
              />
            </div>

            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Branch Performance</h3>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <th className="text-left py-3 px-4 font-medium text-gray-900">Branch</th>
                      <th className="text-right py-3 px-4 font-medium text-gray-900">Revenue</th>
                      <th className="text-right py-3 px-4 font-medium text-gray-900">Expenses</th>
                      <th className="text-right py-3 px-4 font-medium text-gray-900">Profit</th>
                      <th className="text-right py-3 px-4 font-medium text-gray-900">Margin</th>
                      <th className="text-right py-3 px-4 font-medium text-gray-900">Invoices</th>
                    </tr>
                  </thead>
                  <tbody>
                    {branchData.branches.map((branch: any) => (
                      <tr key={branch.branch.id} className="border-b border-gray-100 hover:bg-gray-50">
                        <td className="py-3 px-4">
                          <div>
                            <div className="font-medium text-gray-900">{branch.branch.name}</div>
                            <div className="text-sm text-gray-600">{branch.branch.code}</div>
                          </div>
                        </td>
                        <td className="text-right py-3 px-4 font-medium">
                          {formatCurrency(branch.metrics.revenue)}
                        </td>
                        <td className="text-right py-3 px-4 font-medium text-red-600">
                          {formatCurrency(branch.metrics.expenses)}
                        </td>
                        <td className={`text-right py-3 px-4 font-medium ${
                          branch.metrics.profit >= 0 ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {formatCurrency(branch.metrics.profit)}
                        </td>
                        <td className={`text-right py-3 px-4 font-medium ${
                          branch.metrics.profit_margin >= 0 ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {formatPercentage(branch.metrics.profit_margin)}
                        </td>
                        <td className="text-right py-3 px-4 font-medium">
                          {branch.metrics.invoice_count}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
        
      </div>
    </div>
  );
}
