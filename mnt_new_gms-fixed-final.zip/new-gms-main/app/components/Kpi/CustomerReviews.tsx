'use client';

import React, { useState } from 'react';
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
  Title
} from 'chart.js';
import { Doughnut } from 'react-chartjs-2';

ChartJS.register(ArcElement, Tooltip, Legend, Title);

interface Review {
  _id: string;
  rating: number;
  phone_number?: string;
  comment?: string;
  referral?: string;
  created_at: string;
  updated_at: string;
}

interface ReviewStatistics {
  totalReviews: number;
  averageRating: number;
  ratingDistribution: {
    [key: string]: number;
  };
  referralDistribution?: {
    [key: string]: number;
  };
}

interface CustomerReviewsData {
  reviews: Review[];
  statistics: ReviewStatistics;
  totalReviews: number;
  averageRating: number;
}

interface CustomerReviewsProps {
  reviewData: CustomerReviewsData;
}

interface ReviewDetailModalProps {
  review: Review | null;
  isOpen: boolean;
  onClose: () => void;
  reviewNumber: number;
}

const CustomerReviews: React.FC<CustomerReviewsProps> = ({ reviewData }) => {
  const [selectedReview, setSelectedReview] = useState<Review | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc' | 'none'>('none');
  const reviewsPerPage = 5;

  // Filter and sort reviews
  const filteredAndSortedReviews = React.useMemo(() => {
    let filtered = reviewData.reviews;

    // Apply search filter
    if (searchTerm) {
      filtered = reviewData.reviews.filter((review, index) => {
        const reviewNumber = (reviewData.totalReviews - index).toString();
        const phoneNumber = review.phone_number || '';
        
        return (
          reviewNumber.includes(searchTerm) ||
          phoneNumber.toLowerCase().includes(searchTerm.toLowerCase())
        );
      });
    }

    // Apply sorting
    if (sortOrder !== 'none') {
      filtered = [...filtered].sort((a, b) => {
        if (sortOrder === 'asc') {
          return a.rating - b.rating;
        } else {
          return b.rating - a.rating;
        }
      });
    }

    return filtered;
  }, [reviewData.reviews, reviewData.totalReviews, searchTerm, sortOrder]);

  // Calculate pagination
  const totalPages = Math.ceil(filteredAndSortedReviews.length / reviewsPerPage);
  const startIndex = (currentPage - 1) * reviewsPerPage;
  const endIndex = startIndex + reviewsPerPage;
  const currentReviews = filteredAndSortedReviews.slice(startIndex, endIndex);

  // Generate review number based on original index in unfiltered data
  const getReviewNumber = (review: Review) => {
    const originalIndex = reviewData.reviews.findIndex(r => r._id === review._id);
    return reviewData.totalReviews - originalIndex;
  };

  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Render star rating
  const renderStars = (rating: number, size: 'sm' | 'lg' = 'sm') => {
    const sizeClass = size === 'lg' ? 'w-8 h-8' : 'w-5 h-5';
    
    return (
      <div className="flex items-center">
        {[1, 2, 3, 4, 5].map((star) => (
          <svg
            key={star}
            className={`${sizeClass} ${star <= rating ? 'text-yellow-400' : 'text-gray-300'}`}
            fill="currentColor"
            viewBox="0 0 20 20"
          >
            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
          </svg>
        ))}
      </div>
    );
  };

  // Get rating label
  const getRatingLabel = (rating: number) => {
    switch (rating) {
      case 1: return 'Very Poor';
      case 2: return 'Poor';
      case 3: return 'Average';
      case 4: return 'Good';
      case 5: return 'Excellent';
      default: return '';
    }
  };

  // Calculate referral distribution from reviews
  const calculateReferralDistribution = () => {
    const distribution: { [key: string]: number } = {};
    
    reviewData.reviews.forEach(review => {
      if (review.referral) {
        let referralKey = review.referral;
        
        // Handle "other:" prefix for custom referrals
        if (referralKey.startsWith('other:')) {
          referralKey = 'Other Sources';
        }
        
        distribution[referralKey] = (distribution[referralKey] || 0) + 1;
      } else {
        distribution['Not Specified'] = (distribution['Not Specified'] || 0) + 1;
      }
    });
    
    return distribution;
  };

  const referralDistribution = calculateReferralDistribution();

  // Get most used referral source
  const getMostUsedReferral = () => {
    const entries = Object.entries(referralDistribution);
    if (entries.length === 0) return { source: 'No data', count: 0 };
    
    const sorted = entries.sort(([,a], [,b]) => b - a);
    return { source: sorted[0][0], count: sorted[0][1] };
  };

  const mostUsedReferral = getMostUsedReferral();

  // Prepare doughnut chart data
  const chartData = {
    labels: ['5 Stars', '4 Stars', '3 Stars', '2 Stars', '1 Star'],
    datasets: [
      {
        data: [
          reviewData.statistics?.ratingDistribution?.['5'] || 0,
          reviewData.statistics?.ratingDistribution?.['4'] || 0,
          reviewData.statistics?.ratingDistribution?.['3'] || 0,
          reviewData.statistics?.ratingDistribution?.['2'] || 0,
          reviewData.statistics?.ratingDistribution?.['1'] || 0,
        ],
        backgroundColor: [
          '#10B981', // Green for 5 stars
          '#84CC16', // Light green for 4 stars
          '#FCD34D', // Yellow for 3 stars
          '#F97316', // Orange for 2 stars
          '#EF4444', // Red for 1 star
        ],
        borderColor: '#fff',
        borderWidth: 2,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom' as const,
        labels: {
          padding: 20,
          usePointStyle: true,
          font: {
            size: 12,
          },
        },
      },
      title: {
        display: true,
        text: 'Rating Distribution',
        font: {
          size: 16,
          weight: 'bold' as const,
        },
        padding: {
          bottom: 20,
        },
      },
      tooltip: {
        callbacks: {
          label: (context: any) => {
            const label = context.label || '';
            const value = context.parsed || 0;
            const total = reviewData.totalReviews;
            const percentage = total > 0 ? ((value / total) * 100).toFixed(1) : '0';
            return `${label}: ${value} reviews (${percentage}%)`;
          },
        },
      },
    },
  };

  // Prepare referral chart data
  const referralChartData = {
    labels: Object.keys(referralDistribution),
    datasets: [
      {
        data: Object.values(referralDistribution),
        backgroundColor: [
          '#3B82F6', // Blue for TikTok
          '#EC4899', // Pink for Instagram  
          '#EF4444', // Red for YouTube
          '#10B981', // Green for Recommended by a friend
          '#8B5CF6', // Purple for Other
          '#6B7280', // Gray for Not Specified
          '#F59E0B', // Amber for additional sources
          '#06B6D4', // Cyan for additional sources
        ],
        borderColor: '#fff',
        borderWidth: 2,
      },
    ],
  };

  const referralChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom' as const,
        labels: {
          padding: 20,
          usePointStyle: true,
          font: {
            size: 12,
          },
        },
      },
      title: {
        display: true,
        text: 'Referral Sources',
        font: {
          size: 16,
          weight: 'bold' as const,
        },
        padding: {
          bottom: 20,
        },
      },
      tooltip: {
        callbacks: {
          label: (context: any) => {
            const label = context.label || '';
            const value = context.parsed || 0;
            const total = reviewData.totalReviews;
            const percentage = total > 0 ? ((value / total) * 100).toFixed(1) : '0';
            return `${label}: ${value} reviews (${percentage}%)`;
          },
        },
      },
    },
  };

  // Handle review click
  const handleReviewClick = (review: Review) => {
    setSelectedReview(review);
    setIsModalOpen(true);
  };

  // Handle pagination
  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  // Handle search
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
    setCurrentPage(1); // Reset to first page when searching
  };

  // Handle sort
  const handleSortChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSortOrder(e.target.value as 'asc' | 'desc' | 'none');
    setCurrentPage(1); // Reset to first page when sorting
  };

  return (
    <div className="space-y-8">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
        {/* Total Reviews */}
        <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-blue-500">
          <div className="flex items-center">
            <div className="flex items-center justify-center w-12 h-12 bg-blue-100 rounded-lg mr-4">
              <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
              </svg>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-800">Total Reviews</h3>
              <p className="text-3xl font-bold text-blue-600">{reviewData.totalReviews}</p>
              <p className="text-sm text-gray-600">Customer feedback</p>
            </div>
          </div>
        </div>

        {/* Average Rating */}
        <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-green-500">
          <div className="flex items-center">
            <div className="flex items-center justify-center w-12 h-12 bg-green-100 rounded-lg mr-4">
              <svg className="w-6 h-6 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
              </svg>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-800">Average Rating</h3>
              <p className="text-3xl font-bold text-green-600">{reviewData.averageRating?.toFixed(1) || '0.0'}</p>
              <p className="text-sm text-gray-600">{getRatingLabel(Math.round(reviewData.averageRating || 0))} satisfaction</p>
            </div>
          </div>
        </div>

        {/* Most Used Referral */}
        <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-orange-500">
          <div className="flex items-center">
            <div className="flex items-center justify-center w-12 h-12 bg-orange-100 rounded-lg mr-4">
              <svg className="w-6 h-6 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-800">Top Referral</h3>
              <p className="text-3xl font-bold text-orange-600">{mostUsedReferral.count}</p>
              <p className="text-sm text-gray-600 truncate">{mostUsedReferral.source}</p>
            </div>
          </div>
        </div>

        {/* Excellent Reviews */}
        <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-purple-500">
          <div className="flex items-center">
            <div className="flex items-center justify-center w-12 h-12 bg-purple-100 rounded-lg mr-4">
              <svg className="w-6 h-6 text-purple-600" fill="currentColor" viewBox="0 0 20 20">
                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
              </svg>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-800">Excellent Reviews</h3>
              <p className="text-3xl font-bold text-purple-600">{reviewData.statistics?.ratingDistribution?.['5'] || 0}</p>
              <p className="text-sm text-gray-600">5-star ratings</p>
            </div>
          </div>
        </div>

        {/* Poor Reviews */}
        <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-red-500">
          <div className="flex items-center">
            <div className="flex items-center justify-center w-12 h-12 bg-red-100 rounded-lg mr-4">
              <svg className="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
              </svg>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-800">Poor Reviews</h3>
              <p className="text-3xl font-bold text-red-600">{(reviewData.statistics?.ratingDistribution?.['1'] || 0) + (reviewData.statistics?.ratingDistribution?.['2'] || 0)}</p>
              <p className="text-sm text-gray-600">1-2 star ratings</p>
            </div>
          </div>
        </div>
      </div>

      {/* Reviews Table - Move to Top */}
      <div className="bg-white rounded-lg shadow-md border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-semibold text-gray-800">Recent Reviews</h3>
              <p className="text-sm text-gray-600 mt-1">Click on any review to view details</p>
            </div>
          </div>
          
          {/* Search and Sort Controls */}
          <div className="flex flex-col sm:flex-row gap-4 mb-4">
            <div className="flex-1">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <svg className="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                </div>
                <input
                  type="text"
                  placeholder="Search by Review # or Phone..."
                  value={searchTerm}
                  onChange={handleSearchChange}
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-sm"
                />
              </div>
            </div>
            <div className="sm:w-48">
              <div className="relative">
                <select
                  value={sortOrder}
                  onChange={handleSortChange}
                  className="block w-full px-3 py-2 pl-3 pr-10 border border-gray-300 rounded-md bg-white text-sm text-gray-700 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 hover:border-gray-400 transition-colors duration-200 appearance-none cursor-pointer"
                >
                  <option value="none">Sort by Rating</option>
                  <option value="desc">Highest Rating First</option>
                  <option value="asc">Lowest Rating First</option>
                </select>
                {/* Custom dropdown arrow */}
                <div className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none">
                  <svg className="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 9l4-4 4 4m0 6l-4 4-4-4" />
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Review #
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Rating
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Contact Info
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Date
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {currentReviews.length > 0 ? (
                currentReviews.map((review) => (
                  <tr
                    key={review._id}
                    onClick={() => handleReviewClick(review)}
                    className={`cursor-pointer transition-colors duration-200 ${
                      review.rating <= 2 
                        ? 'bg-red-50 hover:bg-red-100 border-l-4 border-red-400' 
                        : 'hover:bg-gray-50'
                    }`}
                  >
                    <td className="px-4 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className={`rounded-full w-8 h-8 flex items-center justify-center text-sm font-medium ${
                          review.rating <= 2 
                            ? 'bg-red-100 text-red-800' 
                            : 'bg-blue-100 text-blue-800'
                        }`}>
                          {getReviewNumber(review)}
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-4 whitespace-nowrap">
                      <div className="flex items-center space-x-2">
                        {renderStars(review.rating)}
                        <span className={`text-sm font-medium ${
                          review.rating <= 2 ? 'text-red-900' : 'text-gray-900'
                        }`}>
                          {review.rating}/5
                        </span>
                        {review.rating <= 2 && (
                          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800">
                            Poor
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-4 whitespace-nowrap">
                      <div className="flex items-center space-x-2">
                        <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                        </svg>
                        <span className="text-sm text-gray-900">
                          {review.phone_number && review.phone_number !== 'anonymous' 
                            ? review.phone_number 
                            : (
                              <span className="flex items-center">
                                <span className="text-gray-500">Anonymous</span>
                                <span className="ml-1 px-2 py-1 bg-gray-100 text-gray-600 rounded-full text-xs">
                                  Private
                                </span>
                              </span>
                            )
                          }
                        </span>
                      </div>
                    </td>
                    <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">
                      {formatDate(review.created_at)}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={4} className="px-4 py-8 text-center text-gray-500">
                    {searchTerm ? (
                      <div>
                        <svg className="mx-auto h-12 w-12 text-gray-400 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                        </svg>
                        <p className="text-lg font-medium text-gray-900 mb-2">No reviews found</p>
                        <p>No reviews match your search "{searchTerm}"</p>
                        <button
                          onClick={() => setSearchTerm('')}
                          className="mt-3 text-blue-600 hover:text-blue-800 text-sm font-medium"
                        >
                          Clear search
                        </button>
                      </div>
                    ) : (
                      <div>
                        <svg className="mx-auto h-12 w-12 text-gray-400 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                        </svg>
                        <p className="text-lg font-medium text-gray-900 mb-2">No reviews yet</p>
                        <p>Be the first to leave a review!</p>
                      </div>
                    )}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="px-6 py-3 border-t border-gray-200 flex items-center justify-between">
            <div className="text-sm text-gray-700">
              Showing {startIndex + 1} to {Math.min(endIndex, filteredAndSortedReviews.length)} of {filteredAndSortedReviews.length} reviews
              {searchTerm && (
                <span className="text-gray-500 ml-2">
                  (filtered from {reviewData.reviews.length} total)
                </span>
              )}
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => handlePageChange(currentPage - 1)}
                disabled={currentPage === 1}
                className="px-3 py-1 rounded border border-gray-300 text-sm font-medium text-gray-500 hover:text-gray-700 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Previous
              </button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                <button
                  key={page}
                  onClick={() => handlePageChange(page)}
                  className={`px-3 py-1 rounded text-sm font-medium ${
                    currentPage === page
                      ? 'bg-blue-600 text-white'
                      : 'border border-gray-300 text-gray-500 hover:text-gray-700'
                  }`}
                >
                  {page}
                </button>
              ))}
              <button
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={currentPage === totalPages}
                className="px-3 py-1 rounded border border-gray-300 text-sm font-medium text-gray-500 hover:text-gray-700 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Next
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Charts Section - Below Table */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Rating Distribution Chart */}
        <div className="bg-white rounded-lg shadow-md p-6 border border-gray-200">
          <div className="h-80">
            <Doughnut data={chartData} options={chartOptions} />
          </div>
          <div className="mt-4 text-center text-sm text-gray-600">
            Distribution of customer ratings
          </div>
        </div>

        {/* Referral Sources Chart */}
        <div className="bg-white rounded-lg shadow-md p-6 border border-gray-200">
          <div className="h-80">
            <Doughnut data={referralChartData} options={referralChartOptions} />
          </div>
          <div className="mt-4 text-center text-sm text-gray-600">
            How customers found us
          </div>
        </div>
      </div>

      {/* Review Detail Modal */}
      <ReviewDetailModal
        review={selectedReview}
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setSelectedReview(null);
        }}
        reviewNumber={selectedReview ? getReviewNumber(selectedReview) : 0}
      />
    </div>
  );
};

// Review Detail Modal Component
const ReviewDetailModal: React.FC<ReviewDetailModalProps> = ({ review, isOpen, onClose, reviewNumber }) => {
  if (!isOpen || !review) return null;

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const renderStars = (rating: number) => {
    return (
      <div className="flex items-center">
        {[1, 2, 3, 4, 5].map((star) => (
          <svg
            key={star}
            className={`w-6 h-6 ${star <= rating ? 'text-yellow-400' : 'text-gray-300'}`}
            fill="currentColor"
            viewBox="0 0 20 20"
          >
            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
          </svg>
        ))}
      </div>
    );
  };

  const getRatingLabel = (rating: number) => {
    switch (rating) {
      case 1: return 'Very Poor';
      case 2: return 'Poor';
      case 3: return 'Average';
      case 4: return 'Good';
      case 5: return 'Excellent';
      default: return '';
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white p-6 rounded-t-lg">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold">Review #{reviewNumber}</h2>
              <p className="text-blue-100 mt-1">Customer Feedback Details</p>
            </div>
            <button
              onClick={onClose}
              className="text-white hover:text-gray-200 transition-colors duration-200"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Rating Section */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Rating</h3>
            <div className="flex items-center space-x-4">
              {renderStars(review.rating)}
              <div className="text-2xl font-bold text-gray-900">{review.rating}/5</div>
              <div className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                {getRatingLabel(review.rating)}
              </div>
            </div>
          </div>

          {/* Contact Information Section */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Contact Information</h3>
            <div className="flex items-center space-x-2">
              <svg className="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
              </svg>
              <span className="text-gray-900 font-medium">
                {review.phone_number && review.phone_number !== 'anonymous' ? review.phone_number : 'Anonymous'}
              </span>
              {!review.phone_number || review.phone_number === 'anonymous' ? (
                <span className="px-2 py-1 bg-gray-200 text-gray-600 rounded-full text-xs">Anonymous Review</span>
              ) : null}
            </div>
          </div>

          {/* Referral Section */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h3 className="text-lg font-semibold text-gray-800 mb-3">How They Found Us</h3>
            <div className="flex items-center space-x-2">
              <svg className="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <span className="text-gray-900 font-medium">
                {review.referral ? (
                  review.referral.startsWith('other:') ? 
                    `Other Sources - ${review.referral.substring(6)}` : 
                    review.referral
                ) : 'Not specified'}
              </span>
              {review.referral && (
                <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs">
                  {review.referral.startsWith('other:') ? 'Custom Source' : 'Standard Source'}
                </span>
              )}
            </div>
          </div>

          {/* Comment Section */}
          {review.comment && (
            <div className="bg-gray-50 rounded-lg p-4">
              <h3 className="text-lg font-semibold text-gray-800 mb-3">Customer Comment</h3>
              <div className="bg-white rounded-lg p-4 border-l-4 border-blue-500">
                <p className="text-gray-700 leading-relaxed">{review.comment}</p>
              </div>
            </div>
          )}

          {/* Review Date */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Review Date</h3>
            <div className="flex items-center space-x-2">
              <svg className="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 01-2 2z" />
              </svg>
              <span className="font-medium text-gray-900">{formatDate(review.created_at)}</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-gray-100 px-6 py-4 rounded-b-lg">
          <div className="flex justify-end">
            <button
              onClick={onClose}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CustomerReviews;
