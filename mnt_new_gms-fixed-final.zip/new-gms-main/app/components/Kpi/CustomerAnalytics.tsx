'use client';

import React, { useState, useEffect } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Bar, Pie } from 'react-chartjs-2';
import { dataApi } from '../../../services/api';

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
);

interface CustomerData {
  byBranch: any;
  byCity: any;
  topBranches: any[];
  totalCustomers: number;
  customers?: any[]; // Add customers array for KPI processing
}

interface CustomerAnalyticsProps {
  customerData: CustomerData;
}

const CustomerAnalytics: React.FC<CustomerAnalyticsProps> = ({ customerData }) => {
  const [monthlyKpiData, setMonthlyKpiData] = useState<any>(null);
  const [isLoadingKpi, setIsLoadingKpi] = useState(false);

  // Process monthly KPI data - simple approach
  const processMonthlyKpi = (customers: any[], workOrders: any[]) => {
    // Generate last 6 months (simpler than 12)
    const months = [];
    const currentDate = new Date();
    
    for (let i = 5; i >= 0; i--) {
      const date = new Date(currentDate.getFullYear(), currentDate.getMonth() - i, 1);
      const monthName = date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
      const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      
      months.push({ monthName, monthKey, newClients: 0, recurringClients: 0 });
    }

    // Count new clients
    customers.forEach(customer => {
      if (customer.created_at) {
        const createdDate = new Date(customer.created_at);
        const monthKey = `${createdDate.getFullYear()}-${String(createdDate.getMonth() + 1).padStart(2, '0')}`;
        
        const monthData = months.find(m => m.monthKey === monthKey);
        if (monthData) {
          monthData.newClients++;
        }
      }
    });

    // Count recurring clients (existing customers with work orders in each month)
    months.forEach(monthData => {
      const [year, month] = monthData.monthKey.split('-');
      const monthStart = new Date(parseInt(year), parseInt(month) - 1, 1);
      const monthEnd = new Date(parseInt(year), parseInt(month), 0, 23, 59, 59);

      const recurringCustomerIds = new Set();
      
      workOrders.forEach(workOrder => {
        if (workOrder.created_at && workOrder.customer_id) {
          const workOrderDate = new Date(workOrder.created_at);
          if (workOrderDate >= monthStart && workOrderDate <= monthEnd) {
            // Check if customer was created before this month
            const customer = customers.find(c => c._id === workOrder.customer_id);
            if (customer && customer.created_at) {
              const customerCreatedDate = new Date(customer.created_at);
              if (customerCreatedDate < monthStart) {
                recurringCustomerIds.add(workOrder.customer_id);
              }
            }
          }
        }
      });

      monthData.recurringClients = recurringCustomerIds.size;
    });

    return {
      labels: months.map(m => m.monthName),
      datasets: [
        {
          label: 'New Customers',
          data: months.map(m => m.newClients),
          backgroundColor: '#3B82F6',
          borderColor: '#2563EB',
          borderWidth: 1,
        },
        {
          label: 'Recurring Customers',
          data: months.map(m => m.recurringClients),
          backgroundColor: '#10B981',
          borderColor: '#059669',
          borderWidth: 1,
        }
      ]
    };
  };

  // Fetch data and process KPI
  useEffect(() => {
    const fetchKpiData = async () => {
      if (!customerData.customers || customerData.customers.length === 0) return;
      
      setIsLoadingKpi(true);
      try {
        const workOrdersResponse = await dataApi.getWorkOrders();
        const workOrders = Array.isArray(workOrdersResponse) ? workOrdersResponse : workOrdersResponse?.data || [];
        
        const kpiChartData = processMonthlyKpi(customerData.customers, workOrders);
        setMonthlyKpiData(kpiChartData);
      } catch (error) {
        console.error('Error fetching KPI data:', error);
      } finally {
        setIsLoadingKpi(false);
      }
    };

    fetchKpiData();
  }, [customerData.customers]);

  return (
    <>
      {/* Customer KPI Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-blue-500">
          <div className="flex items-center">
            <div className="bg-blue-100 p-3 rounded-full">
              <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z" />
              </svg>
            </div>
            <div className="ml-4">
              <h3 className="text-lg font-semibold text-gray-700">Total Customers</h3>
              <p className="text-3xl font-bold text-blue-600">{customerData.totalCustomers}</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-green-500">
          <div className="flex items-center">
            <div className="bg-green-100 p-3 rounded-full">
              <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
              </svg>
            </div>
            <div className="ml-4">
              <h3 className="text-lg font-semibold text-gray-700">Active Branches</h3>
              <p className="text-3xl font-bold text-green-600">
                {customerData.byBranch?.labels?.length || 0}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-purple-500">
          <div className="flex items-center">
            <div className="bg-purple-100 p-3 rounded-full">
              <svg className="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
            </div>
            <div className="ml-4">
              <h3 className="text-lg font-semibold text-gray-700">Cities Served</h3>
              <p className="text-3xl font-bold text-purple-600">
                {customerData.byCity?.labels?.length || 0}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-orange-500">
          <div className="flex items-center">
            <div className="bg-orange-100 p-3 rounded-full">
              <svg className="w-6 h-6 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
              </svg>
            </div>
            <div className="ml-4">
              <h3 className="text-lg font-semibold text-gray-700">Top Branch</h3>
              <p className="text-xl font-bold text-orange-600">
                {customerData.topBranches[0]?.name || 'N/A'}
              </p>
              <p className="text-sm text-gray-500">
                {customerData.topBranches[0]?.customerCount || 0} customers
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Customer Analytics Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        {/* Customer Distribution by Branch - Bar Chart */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h4 className="text-xl font-semibold text-gray-800 mb-6 flex items-center">
            <svg className="w-5 h-5 mr-2 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
            Customer Distribution by Branch
          </h4>
          {customerData.byBranch && (
            <div style={{ height: '400px' }}>
              <Bar 
                data={customerData.byBranch} 
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    title: {
                      display: false
                    },
                    legend: {
                      display: false
                    },
                    tooltip: {
                      callbacks: {
                        label: function(context: any) {
                          return `Customers: ${context.parsed.y}`;
                        }
                      }
                    }
                  },
                  scales: {
                    y: {
                      beginAtZero: true,
                      title: {
                        display: true,
                        text: 'Number of Customers'
                      },
                      grid: {
                        color: '#f3f4f6'
                      }
                    },
                    x: {
                      title: {
                        display: true,
                        text: 'Branches'
                      },
                      grid: {
                        display: false
                      }
                    }
                  }
                }}
              />
            </div>
          )}
        </div>

        {/* Customer Distribution by City - Pie Chart */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h4 className="text-xl font-semibold text-gray-800 mb-6 flex items-center">
            <svg className="w-5 h-5 mr-2 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
            Customer Distribution by City
          </h4>
          {customerData.byCity && (
            <div style={{ height: '400px' }}>
              <Pie 
                data={customerData.byCity} 
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    title: {
                      display: false
                    },
                    legend: {
                      position: 'bottom',
                      labels: {
                        padding: 20,
                        usePointStyle: true
                      }
                    },
                    tooltip: {
                      callbacks: {
                        label: function(context: any) {
                          const label = context.label || '';
                          const value = context.parsed;
                          const total = context.dataset.data.reduce((acc: number, data: number) => acc + data, 0);
                          const percentage = ((value / total) * 100).toFixed(1);
                          return `${label}: ${value} (${percentage}%)`;
                        }
                      }
                    }
                  }
                }}
              />
            </div>
          )}
        </div>
      </div>

      {/* Top Branches Performance Table */}
      <div className="bg-white rounded-lg shadow-md">
        <div className="p-6 border-b border-gray-200">
          <h4 className="text-xl font-semibold text-gray-800 flex items-center">
            <svg className="w-5 h-5 mr-2 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
            </svg>
            Top Performing Branches
          </h4>
          <p className="text-gray-600 mt-1">Branches ranked by customer count</p>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Rank
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Branch Name
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Customer Count
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Performance
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {customerData.topBranches.map((branch: any, index) => (
                <tr key={branch.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <span className={`inline-flex items-center justify-center w-6 h-6 rounded-full text-xs font-bold text-white ${
                        index === 0 ? 'bg-yellow-500' : 
                        index === 1 ? 'bg-gray-400' : 
                        index === 2 ? 'bg-orange-600' : 'bg-gray-300'
                      }`}>
                        {index + 1}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{branch.name}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900 font-semibold">{branch.customerCount}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="w-16 bg-gray-200 rounded-full h-2 mr-2">
                        <div 
                          className="bg-blue-600 h-2 rounded-full" 
                          style={{ 
                            width: `${(branch.customerCount / customerData.topBranches[0]?.customerCount) * 100}%` 
                          }}
                        ></div>
                      </div>
                      <span className="text-xs text-gray-500">
                        {Math.round((branch.customerCount / customerData.totalCustomers) * 100)}%
                      </span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Monthly KPI Chart - New vs Recurring Customers */}
      <div className="bg-white p-6 rounded-lg shadow-md mb-8">
        <h4 className="text-xl font-semibold text-gray-800 mb-6 flex items-center">
          <svg className="w-5 h-5 mr-2 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
          </svg>
          Monthly Customer Analytics - New vs Recurring
        </h4>
        
        {isLoadingKpi ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mr-3"></div>
            <span className="text-gray-600">Loading KPI data...</span>
          </div>
        ) : monthlyKpiData ? (
          <div style={{ height: '400px' }}>
            <Bar 
              data={monthlyKpiData} 
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  title: {
                    display: false
                  },
                  legend: {
                    position: 'top',
                    labels: {
                      padding: 20,
                      usePointStyle: true
                    }
                  },
                  tooltip: {
                    callbacks: {
                      label: function(context: any) {
                        return `${context.dataset.label}: ${context.parsed.y} customers`;
                      }
                    }
                  }
                },
                scales: {
                  x: {
                    title: {
                      display: true,
                      text: 'Month'
                    },
                    grid: {
                      display: false
                    }
                  },
                  y: {
                    beginAtZero: true,
                    title: {
                      display: true,
                      text: 'Number of Customers'
                    },
                    grid: {
                      color: '#f3f4f6'
                    }
                  }
                }
              }}
            />
          </div>
        ) : (
          <div className="text-center py-8 text-gray-500">
            <p>No KPI data available</p>
          </div>
        )}
      </div>
    </>
  );
};

export default CustomerAnalytics;
