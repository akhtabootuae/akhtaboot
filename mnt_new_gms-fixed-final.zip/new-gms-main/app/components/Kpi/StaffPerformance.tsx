'use client';

import React, { useState } from 'react';
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
  Title
} from 'chart.js';
import { Doughnut } from 'react-chartjs-2';
import { dataApi } from '../../../services/api';

ChartJS.register(ArcElement, Tooltip, Legend, Title);

interface StaffPerformanceData {
  workOrderPerformance: any[];
  evaluationRatings: any[];
  totalStaff: number;
  highPerformers: number;
  excellentRatings: number;
  needsAttention: number;
}

interface StaffPerformanceProps {
  staffData: StaffPerformanceData;
  customerData: {
    byBranch: any;
    byCity: any;
    topBranches: any[];
    totalCustomers: number;
    customers?: any[];
  };
}

interface ModalData {
  title: string;
  type: 'workOrder';
  tier: string;
  technicians: any[];
}

const StaffPerformance: React.FC<StaffPerformanceProps> = ({ staffData, customerData }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalData, setModalData] = useState<ModalData | null>(null);
  const [loading, setLoading] = useState(false);

  // Customer lookup function
  const getCustomerName = (customerId: string): string => {
    if (!customerData.customers || !Array.isArray(customerData.customers)) {
      return 'Unknown Customer';
    }
    
    const customer = customerData.customers.find(c => c._id === customerId);
    if (customer) {
      return customer.name || 
             `${customer.first_name || ''} ${customer.last_name || ''}`.trim() || 
             'Unknown Customer';
    }
    
    return 'Unknown Customer';
  };

  // Handle chart click events - only for work order chart
  const handleWorkOrderChartClick = async (event: any, elements: any[]) => {
    if (elements.length === 0) return;

    const clickedElementIndex = elements[0].index;
    setLoading(true);

    try {
      const clickedTier = staffData.workOrderPerformance[clickedElementIndex];
      await fetchTechniciansForTier(clickedTier.tier, 'workOrder');
    } catch (error) {
      console.error('Error fetching technician details:', error);
    } finally {
      setLoading(false);
    }
  };

  // Fetch technicians for a specific work order tier
  const fetchTechniciansForTier = async (tier: string, type: 'workOrder') => {
    try {
      // Get all technicians
      const techniciansResponse = await dataApi.getTechnicians();
      const allTechnicians = Array.isArray(techniciansResponse) ? techniciansResponse : [];
      const relevantTechnicians = [];

      // For work orders, we need to check each technician's work order count
      for (const tech of allTechnicians) {
        try {
          const workOrdersResponse: any = await dataApi.getUserWorkOrders(tech._id, 1, 100, 'all');
          const workOrders = workOrdersResponse?.workorders || 
                            workOrdersResponse?.data?.workorders || 
                            (Array.isArray(workOrdersResponse) ? workOrdersResponse : []);
          
          const activeWorkOrders = workOrders.filter((wo: any) => 
            wo.status === 'open' || wo.status === 'in_progress' || wo.status === 'In Progress' || wo.status === 'Active'
          );
          
          const workOrderCount = activeWorkOrders.length;

          // Check if this technician belongs to the clicked tier
          let belongsToTier = false;
          if (tier.includes('5+') && workOrderCount >= 5) {
            belongsToTier = true;
          } else if (tier.includes('3-4') && workOrderCount >= 3 && workOrderCount <= 4) {
            belongsToTier = true;
          } else if (tier.includes('1-2') && workOrderCount >= 1 && workOrderCount <= 2) {
            belongsToTier = true;
          } else if (tier.includes('0') && workOrderCount === 0) {
            belongsToTier = true;
          }

          if (belongsToTier) {
            relevantTechnicians.push({
              ...tech,
              workOrderCount,
              activeWorkOrders: activeWorkOrders.map((wo: any) => ({
                id: wo._id,
                workOrderNumber: wo.workOrderNumber || wo.work_order_number || `#${wo._id.slice(-6)}`,
                status: wo.status,
                description: wo.description || 'No description',
                customer: getCustomerName(wo.customer_id || wo.customerId || wo.customer?._id || wo.customer)
              }))
            });
          }
        } catch (error) {
          console.error(`Error fetching work orders for ${tech.name}:`, error);
        }
      }

      setModalData({
        title: `${tier} - Staff Details`,
        type,
        tier,
        technicians: relevantTechnicians
      });
      setIsModalOpen(true);
    } catch (error) {
      console.error('Error fetching technicians:', error);
    }
  };
  // Chart configuration for Work Order Performance
  const workOrderChartData = staffData.workOrderPerformance ? {
    labels: staffData.workOrderPerformance.map(item => `${item.tier} (${item.percentage}%)`),
    datasets: [{
      data: staffData.workOrderPerformance.map(item => item.count),
      backgroundColor: [
        '#10B981', // Green for 5+ orders
        '#3B82F6', // Blue for 3-4 orders  
        '#F59E0B', // Yellow for 1-2 orders
        '#EF4444', // Red for 0 orders
      ],
      borderWidth: 2,
      borderColor: '#ffffff',
    }]
  } : null;

  // Chart configuration for Evaluation Ratings
  const evaluationChartData = staffData.evaluationRatings ? {
    labels: staffData.evaluationRatings.map(item => `${item.range} (${item.percentage}%)`),
    datasets: [{
      data: staffData.evaluationRatings.map(item => item.count),
      backgroundColor: [
        '#059669', // Dark green for 4-5 (Excellent)
        '#10B981', // Green for 3-4 (Good)
        '#F59E0B', // Yellow for 2-3 (Average)
        '#F97316', // Orange for 1-2 (Below Average)
        '#DC2626', // Red for 0-1 (Poor)
        '#6B7280', // Gray for No Evaluations
      ],
      borderWidth: 2,
      borderColor: '#ffffff',
    }]
  } : null;

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom' as const,
        labels: {
          padding: 20,
          usePointStyle: true,
          font: {
            size: 12
          }
        }
      },
      tooltip: {
        callbacks: {
          label: function(context: any) {
            const label = context.label || '';
            const value = context.parsed || 0;
            return `${label}: ${value} staff members`;
          }
        }
      }
    },
    cutout: '60%',
    onClick: (event: any, elements: any[]) => handleWorkOrderChartClick(event, elements)
  };

  const evaluationChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom' as const,
        labels: {
          padding: 20,
          usePointStyle: true,
          font: {
            size: 12
          }
        }
      },
      tooltip: {
        callbacks: {
          label: function(context: any) {
            const label = context.label || '';
            const value = context.parsed || 0;
            return `${label}: ${value} staff members`;
          }
        }
      }
    },
    cutout: '60%'
    // No click handler for evaluation chart
  };

  return (
    <>
      {/* Staff KPI Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-blue-500">
          <div className="flex items-center">
            <div className="bg-blue-100 p-3 rounded-full">
              <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
              </svg>
            </div>
            <div className="ml-4">
              <h3 className="text-lg font-semibold text-gray-700">Total Staff</h3>
              <p className="text-3xl font-bold text-blue-600">{staffData.totalStaff}</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-green-500">
          <div className="flex items-center">
            <div className="bg-green-100 p-3 rounded-full">
              <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
              </svg>
            </div>
            <div className="ml-4">
              <h3 className="text-lg font-semibold text-gray-700">High Performers</h3>
              <p className="text-3xl font-bold text-green-600">{staffData.highPerformers}</p>
              <p className="text-sm text-gray-500">5+ active orders</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-purple-500">
          <div className="flex items-center">
            <div className="bg-purple-100 p-3 rounded-full">
              <svg className="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
              </svg>
            </div>
            <div className="ml-4">
              <h3 className="text-lg font-semibold text-gray-700">Excellent Ratings</h3>
              <p className="text-3xl font-bold text-purple-600">{staffData.excellentRatings}</p>
              <p className="text-sm text-gray-500">4-5 average rating</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-red-500">
          <div className="flex items-center">
            <div className="bg-red-100 p-3 rounded-full">
              <svg className="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
              </svg>
            </div>
            <div className="ml-4">
              <h3 className="text-lg font-semibold text-gray-700">Needs Attention</h3>
              <p className="text-3xl font-bold text-red-600">{staffData.needsAttention}</p>
              <p className="text-sm text-gray-500">No active orders</p>
            </div>
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        {/* Daily Work Order Performance Chart */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h4 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
            <svg className="w-5 h-5 mr-2 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
            </svg>
            Daily Work Order Performance
          </h4>
          <p className="text-sm text-gray-600 mb-6">
            Staff distribution by active work orders assigned
          </p>
          <div style={{ height: '300px', position: 'relative' }}>
            {workOrderChartData && (
              <Doughnut data={workOrderChartData} options={chartOptions} />
            )}
            {/* Center text */}
            <div 
              className="absolute pointer-events-none" 
              style={{
                top: '45%',
                left: '50%',
                transform: 'translate(-50%, -50%)',
                textAlign: 'center'
              }}
            >
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">
                  {staffData.totalStaff}
                </div>
                <div className="text-sm text-gray-500">Total Staff</div>
              </div>
            </div>
          </div>
        </div>

        {/* Staff Evaluation Ratings Chart */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h4 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
            <svg className="w-5 h-5 mr-2 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
            </svg>
            Staff Evaluation Ratings Distribution
          </h4>
          <p className="text-sm text-gray-600 mb-6">
            Staff distribution by average evaluation ratings
          </p>
          <div style={{ height: '300px', position: 'relative' }}>
            {evaluationChartData && (
              <Doughnut data={evaluationChartData} options={evaluationChartOptions} />
            )}
            {/* Center text */}
            <div 
              className="absolute pointer-events-none" 
              style={{
                top: '40%',
                left: '50%',
                transform: 'translate(-50%, -50%)',
                textAlign: 'center'
              }}
            >
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">
                  {staffData.totalStaff}
                </div>
                <div className="text-sm text-gray-500">Total Staff</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Modal for displaying staff details */}
      {isModalOpen && modalData && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 px-6 py-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold text-white">
                  {modalData.title}
                </h3>
                <button
                  onClick={() => setIsModalOpen(false)}
                  className="text-white hover:text-gray-200 transition-colors"
                >
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
              <p className="text-blue-100 mt-2">
                {modalData.technicians.length} staff member(s) in this category
              </p>
            </div>

            {/* Modal Content */}
            <div className="p-6 overflow-y-auto max-h-[70vh]">
              {loading ? (
                <div className="flex items-center justify-center py-12">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
                  <span className="ml-4 text-gray-600">Loading staff details...</span>
                </div>
              ) : modalData.technicians.length === 0 ? (
                <div className="text-center py-12">
                  <div className="text-gray-400 mb-4">
                    <svg className="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4" />
                    </svg>
                  </div>
                  <h4 className="text-lg font-semibold text-gray-700 mb-2">No staff found</h4>
                  <p className="text-gray-500">No technicians match this criteria.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {modalData.technicians.map((tech: any) => (
                    <div key={tech._id} className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                      <div className="flex items-start justify-between">
                        <div className="flex items-center space-x-4">
                          <div className="bg-blue-100 p-3 rounded-full">
                            <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                            </svg>
                          </div>
                          <div>
                            <h5 className="text-lg font-semibold text-gray-900">{tech.name}</h5>
                            <p className="text-sm text-gray-600">{tech.email}</p>
                            <p className="text-sm text-gray-500">{tech.phone || 'No phone number'}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="flex items-center space-x-2">
                            <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                              tech.workOrderCount === 0 
                                ? 'bg-red-100 text-red-800' 
                                : tech.workOrderCount >= 5 
                                ? 'bg-green-100 text-green-800'
                                : tech.workOrderCount >= 3
                                ? 'bg-blue-100 text-blue-800'
                                : 'bg-yellow-100 text-yellow-800'
                            }`}>
                              {tech.workOrderCount} Work Orders
                            </span>
                          </div>
                        </div>
                      </div>
                      
                      {/* Work Orders Details */}
                      {tech.activeWorkOrders && tech.activeWorkOrders.length > 0 && (
                        <div className="mt-4 pt-4 border-t border-gray-200">
                          <h6 className="text-sm font-medium text-gray-700 mb-2">Active Work Orders:</h6>
                          <div className="space-y-2">
                            {tech.activeWorkOrders.map((wo: any) => (
                              <div key={wo.id} className="bg-white p-3 rounded border border-gray-200">
                                <div className="flex items-center justify-between">
                                  <div>
                                    <p className="text-sm font-medium text-gray-900">{wo.workOrderNumber}</p>
                                    <p className="text-xs text-gray-600">{wo.description}</p>
                                    <p className="text-xs text-gray-500">Customer: {wo.customer}</p>                                  </div>
                                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                                    wo.status === 'open' 
                                      ? 'bg-blue-100 text-blue-800'
                                      : 'bg-orange-100 text-orange-800'
                                  }`}>
                                    {wo.status}
                                  </span>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* No Work Orders Message */}
                      {tech.workOrderCount === 0 && (
                        <div className="mt-4 pt-4 border-t border-gray-200">
                          <div className="flex items-center space-x-2 text-red-600">
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
                            </svg>
                            <p className="text-sm font-medium">No active work orders assigned</p>
                          </div>
                          <p className="text-xs text-gray-500 mt-1">This technician may need new work assignments.</p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="bg-gray-50 px-6 py-4 border-t border-gray-200">
              <div className="flex items-center justify-between">
                <div className="text-sm text-gray-600">
                  Click on work order chart segments to explore staff performance details
                </div>
                <button
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default StaffPerformance;