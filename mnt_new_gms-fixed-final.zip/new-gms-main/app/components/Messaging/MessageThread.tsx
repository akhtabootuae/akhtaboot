"use client";

import React, { useState, useRef } from 'react';
import { Message } from '@/app/types/messaging';
import { Megaphone, Play, Pause } from 'lucide-react';
import { messagingApi } from '@/services/api';

interface VoiceNotePlayerProps {
  message: Message;
  onError: (audio: HTMLAudioElement) => void;
  isOwn: boolean;
}

const VoiceNotePlayer: React.FC<VoiceNotePlayerProps> = ({ message, onError, isOwn }) => {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(message.duration || 0);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [canPlay, setCanPlay] = useState(false);

  const playbackSpeeds = [1, 1.5, 2];

  const togglePlay = () => {
    if (!audioRef.current || !canPlay) return;
    
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play().catch(console.error);
    }
  };

  const handleCanPlay = () => {
    setCanPlay(true);
    if (audioRef.current && audioRef.current.duration) {
      setDuration(audioRef.current.duration);
    }
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime || 0);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = parseFloat(e.target.value);
    if (audioRef.current && !isNaN(time)) {
      audioRef.current.currentTime = time;
      setCurrentTime(time);
    }
  };

  const handleSpeedChange = () => {
    if (!audioRef.current) return;
    
    const currentIndex = playbackSpeeds.indexOf(playbackRate);
    const nextIndex = (currentIndex + 1) % playbackSpeeds.length;
    const newSpeed = playbackSpeeds[nextIndex];
    
    setPlaybackRate(newSpeed);
    audioRef.current.playbackRate = newSpeed;
  };

  const formatDuration = (seconds: number) => {
    if (!seconds || isNaN(seconds)) return '0:00';
    const totalSeconds = Math.floor(seconds);
    const minutes = Math.floor(totalSeconds / 60);
    const remainingSeconds = totalSeconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const progress = duration > 0 ? Math.min(100, (currentTime / duration) * 100) : 0;
  const progressColor = isOwn ? 'rgba(255,255,255,0.9)' : '#3b82f6';
  const trackColor = isOwn ? 'rgba(255,255,255,0.3)' : '#e5e7eb';

  // Reset when message changes
  React.useEffect(() => {
    setIsPlaying(false);
    setCurrentTime(0);
    setCanPlay(false);
    if (audioRef.current) {
      audioRef.current.load();
    }
  }, [message.signed_url]);


  // Add: Try to refresh signed_url for own just-sent voice notes if initial load fails
  const triedRefresh = React.useRef(false);
  const handleAudioError = async () => {
    setCanPlay(false);
    if (isOwn && message.s3_key && !triedRefresh.current) {
      triedRefresh.current = true;
      try {
        const newUrl = await messagingApi.refreshFileUrl(message.s3_key);
        if (newUrl && audioRef.current) {
          audioRef.current.src = newUrl;
          audioRef.current.load();
        }
      } catch (e) {
        // ignore
      }
    }
  };

  return (
    <div className="flex items-center space-x-3 py-2 min-w-0">
      <audio
        ref={audioRef}
        onCanPlay={handleCanPlay}
        onTimeUpdate={handleTimeUpdate}
        onEnded={() => setIsPlaying(false)}
        onPause={() => setIsPlaying(false)}
        onPlay={() => setIsPlaying(true)}
        onError={handleAudioError}
        preload="metadata"
      >
        <source src={message.signed_url} type={message.mime_type || 'audio/mpeg'} />
      </audio>
      
      <button
        onClick={togglePlay}
        disabled={!canPlay}
        className={`w-9 h-9 rounded-full flex items-center justify-center transition-all duration-200 hover:scale-105 disabled:opacity-50 ${
          isOwn 
            ? 'bg-white/20 hover:bg-white/30 text-white' 
            : 'bg-blue-500 hover:bg-blue-600 text-white'
        }`}
        title={!canPlay ? 'Loading audio...' : isPlaying ? 'Pause' : 'Play'}
      >
        {!canPlay ? (
          <div className="w-3 h-3 border-2 border-current border-t-transparent rounded-full animate-spin" />
        ) : isPlaying ? (
          <Pause className="w-3.5 h-3.5" />
        ) : (
          <Play className="w-3.5 h-3.5 ml-0.5" />
        )}
      </button>
      
      <div className="flex-1 min-w-0 relative">
        <div className="relative h-2 bg-transparent rounded-full overflow-hidden">
          <div 
            className="absolute inset-0 rounded-full"
            style={{ backgroundColor: trackColor }}
          />
          <div 
            className="absolute inset-y-0 left-0 rounded-full transition-all duration-150 ease-out"
            style={{ 
              backgroundColor: progressColor,
              width: `${progress}%`
            }}
          />
        </div>
        <input
          type="range"
          min="0"
          max={duration || 100}
          value={currentTime || 0}
          onChange={handleSeek}
          disabled={!canPlay}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer disabled:cursor-not-allowed"
          style={{ margin: 0 }}
        />
      </div>

      <div className={`text-xs font-mono tabular-nums min-w-[3rem] text-right ${isOwn ? 'text-white/90' : 'text-gray-600'}`}>
        <span className="block">
          {formatDuration(currentTime)} / {formatDuration(duration)}
        </span>
      </div>

      <button
        onClick={handleSpeedChange}
        disabled={!canPlay}
        className={`px-2.5 py-1.5 rounded-md text-xs font-medium transition-all duration-200 hover:scale-105 disabled:opacity-50 ${
          isOwn 
            ? 'bg-white/20 hover:bg-white/30 text-white' 
            : 'bg-gray-200 hover:bg-gray-300 text-gray-700'
        }`}
      >
        {playbackRate}×
      </button>
    </div>
  );
};

interface MessageThreadProps {
  messages: Message[];
  currentUserId: string;
  selectedConversation?: any;
}

export default function MessageThread({ messages, currentUserId, selectedConversation }: MessageThreadProps) {
  const [retryAttempts, setRetryAttempts] = React.useState<Map<string, number>>(new Map());

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const units = ['Bytes', 'KB', 'MB', 'GB'];
    const threshold = 1024;
    const unitIndex = Math.floor(Math.log(bytes) / Math.log(threshold));
    return parseFloat((bytes / Math.pow(threshold, unitIndex)).toFixed(2)) + ' ' + units[unitIndex];
  };

  const getSenderName = (message: Message) => {
    if (message.sender_name && message.sender_name !== 'Unknown') {
      return message.sender_name;
    }
    
    if (selectedConversation?.participants && message.sender_id) {
      const participant = selectedConversation.participants.find(
        (p: any) => p.user_id === message.sender_id
      );
      if (participant?.name) {
        return participant.name;
      }
    }
    
    return 'Unknown';
  };

  const getSenderRole = (message: Message) => {
    if (message.sender_role) {
      return message.sender_role;
    }
    
    if (selectedConversation?.participants && message.sender_id) {
      const participant = selectedConversation.participants.find(
        (p: any) => p.user_id === message.sender_id
      );
      if (participant?.role_name) {
        return participant.role_name;
      }
    }
    
    return '';
  };

  const handleImageError = async (imgElement: HTMLImageElement, s3Key: string) => {
    if (!s3Key) {
      imgElement.style.display = 'none';
      return;
    }

    const attempts = retryAttempts.get(s3Key) || 0;
    if (attempts >= 2) {
      imgElement.style.display = 'none';
      return;
    }

    try {
      setRetryAttempts(prev => new Map(prev).set(s3Key, attempts + 1));
      const newUrl = await messagingApi.refreshFileUrl(s3Key);
      if (newUrl && newUrl !== imgElement.src) {
        imgElement.src = newUrl;
      } else {
        imgElement.style.display = 'none';
      }
    } catch (error) {
      imgElement.style.display = 'none';
    }
  };

  const handleAudioError = async (audioElement: HTMLAudioElement, s3Key: string) => {
    if (!s3Key || !audioElement || typeof audioElement.load !== 'function') {
      return;
    }

    const attempts = retryAttempts.get(`audio_${s3Key}`) || 0;
    if (attempts >= 2) {
      return;
    }

    try {
      setRetryAttempts(prev => new Map(prev).set(`audio_${s3Key}`, attempts + 1));
      const newUrl = await messagingApi.refreshFileUrl(s3Key);
      if (newUrl && newUrl !== audioElement.src) {
        audioElement.src = newUrl;
        audioElement.load();
      }
    } catch (error) {
      // Silently handle error
    }
  };

  const isSystemMessage = (message: Message) => {
    const content = message.content.toLowerCase();
    const patterns = [
      /was added to the group/, /was removed from the group/, /has joined the group/,
      /has left the group/, /created the group/, /changed the group name/,
      /changed the group description/, /promoted .* to admin/, /removed admin privileges from/
    ];
    return patterns.some(pattern => pattern.test(content));
  };

  const renderMessage = (message: Message, index: number) => {
    const isOwn = message.sender_id === currentUserId;
    const isAnnouncement = message.message_type === 'announcement';
    const isSystem = isSystemMessage(message);
    
    const prevMessage = index > 0 ? messages[index - 1] : null;
    const isSameSender = prevMessage && prevMessage.sender_id === message.sender_id;
    const showSenderName = !isSameSender || isAnnouncement || isSystem;

    if (isSystem) {
      return (
        <div key={message._id} className="flex justify-center my-6">
          <div className="bg-gray-50/60 border border-gray-200/30 rounded-lg px-4 py-2 shadow-sm max-w-md mx-4">
            <p className="text-xs text-gray-700 text-center font-normal">{message.content}</p>
            <p className="text-xs text-gray-400 text-center mt-1">{formatTime(message.created_at)}</p>
          </div>
        </div>
      );
    }

    if (isAnnouncement) {
      return (
        <div key={message._id} className="flex justify-center mb-8">
          <div className="max-w-2xl w-full">
            <div className="bg-orange-50/80 border border-orange-200/50 rounded-xl p-6 shadow-lg">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-8 h-8 bg-orange-500 rounded-xl flex items-center justify-center">
                  <Megaphone className="h-4 w-4 text-white" />
                </div>
                <div>
                  <span className="text-sm font-bold text-orange-800 block">📢 Announcement</span>
                  <span className="text-xs text-orange-600">from {getSenderName(message)}</span>
                </div>
              </div>
              <div className="text-gray-800 whitespace-pre-wrap font-medium">{message.content}</div>
              <div className="text-xs text-orange-600 mt-4 font-semibold">{formatTime(message.created_at)}</div>
            </div>
          </div>
        </div>
      );
    }

    return (
      <div key={message._id} className={`flex mb-6 ${isOwn ? 'justify-end' : 'justify-start'}`}>
        <div className={`max-w-xs lg:max-w-md ${isOwn ? 'order-2' : 'order-1'}`}>
          {showSenderName && !isOwn && (
            <div className="text-xs text-gray-600 mb-2 px-4 flex items-center space-x-2">
              <div className="w-6 h-6 bg-blue-400 rounded-full flex items-center justify-center">
                <span className="text-white text-xs font-bold">
                  {getSenderName(message).charAt(0).toUpperCase()}
                </span>
              </div>
              <div>
                <span className="font-semibold">{getSenderName(message)}</span>
                {getSenderRole(message) && (
                  <span className="ml-2 text-xs text-gray-400 px-2 py-0.5 bg-gray-100 rounded-full">
                    {getSenderRole(message)}
                  </span>
                )}
              </div>
            </div>
          )}
          
          <div className={`px-5 py-3 transition-all duration-200 hover:shadow-md ${
              isOwn
                ? 'bg-blue-500 text-white rounded-2xl rounded-br-lg shadow-lg'
                : 'bg-white/80 text-gray-900 rounded-2xl rounded-bl-lg shadow-sm border border-gray-200/50'
            }`}>
            {message.message_type === 'image' ? (
              <div className="space-y-2">
                <img
                  src={message.signed_url}
                  alt={message.original_name || 'Image'}
                  className="max-w-xs rounded-lg cursor-pointer hover:opacity-90 transition-opacity"
                  onClick={() => window.open(message.signed_url, '_blank')}
                  onError={(e) => {
                    const img = e.currentTarget as HTMLImageElement;
                    handleImageError(img, message.s3_key || '');
                  }}
                />
                {message.content && message.content.trim() !== '' && (
                  <p className="text-sm italic mt-2">{message.content}</p>
                )}
                <div className="text-xs opacity-70">
                  {message.original_name} • {formatFileSize(message.file_size || 0)}
                </div>
              </div>
            ) : message.message_type === 'voice_note' ? (
              <VoiceNotePlayer 
                message={message}
                onError={(audio) => handleAudioError(audio, message.s3_key || '')}
                isOwn={isOwn}
              />
            ) : (
              <div className="whitespace-pre-wrap break-words">{message.content}</div>
            )}
          </div>
          
          <div className={`text-xs text-gray-500 mt-2 px-4 ${isOwn ? 'text-right' : 'text-left'}`}>
            {formatTime(message.created_at)}
          </div>
        </div>
      </div>
    );
  };

  if (messages.length === 0) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="w-16 h-16 bg-blue-500 rounded-full mx-auto flex items-center justify-center mb-6">
            <span className="text-2xl">💬</span>
          </div>
          <h3 className="text-lg font-bold text-gray-900 mb-2">No messages yet</h3>
          <p className="text-gray-600">Be the first to start the conversation!</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-1">
      {messages.map((message, index) => renderMessage(message, index))}
    </div>
  );
}
