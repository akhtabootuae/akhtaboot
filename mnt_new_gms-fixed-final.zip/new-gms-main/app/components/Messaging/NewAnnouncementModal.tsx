'use client';

import React, { useState, useEffect } from 'react';
import { X, Megaphone, Users, Clock, UserCheck, Settings } from 'lucide-react';
import { messagingApi, dataApi } from '@/services/api';
import { toast } from 'react-hot-toast';

interface User {
  _id: string;
  name: string;
  email: string;
  role_name?: string;
  speciality?: string;
}

interface Role {
  _id: string;
  role_name: string;
  description?: string;
}

interface NewAnnouncementModalProps {
  isOpen: boolean;
  onCloseAction: () => void;
  onAnnouncementCreatedAction: () => void;
  currentUser: any;
}

const SPECIALTIES = [
  'PDR',
  'Fix/Remove',
  'Paint',
  'Body Work',
  'Mechanical',
  'Electrical',
  'General',
  'PDR & Paint Supervision',
  'System Administration',
  'Supervision',
  'Management',
];

export default function NewAnnouncementModal({
  isOpen,
  onCloseAction,
  onAnnouncementCreatedAction,
  currentUser
}: NewAnnouncementModalProps) {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [recipientType, setRecipientType] = useState<'roles' | 'specialties' | 'users' | 'all'>('roles');
  const [selectedRoles, setSelectedRoles] = useState<string[]>([]);
  const [selectedSpecialties, setSelectedSpecialties] = useState<string[]>([]);
  const [selectedUsers, setSelectedUsers] = useState<User[]>([]);
  const [timeSpan, setTimeSpan] = useState<'1hour' | '6hours' | '1day' | '3days' | '1week' | 'permanent' | 'custom'>('1day');
  const [customDate, setCustomDate] = useState<string>('');
  
  const [roles, setRoles] = useState<Role[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [loadingData, setLoadingData] = useState(false);

  // Load initial data
  useEffect(() => {
    if (isOpen) {
      loadRoles();
      loadUsers();
    }
  }, [isOpen]);

  // Reset form when modal opens
  useEffect(() => {
    if (isOpen) {
      setTitle('');
      setContent('');
      setRecipientType('roles');
      setSelectedRoles([]);
      setSelectedSpecialties([]);
      setSelectedUsers([]);
      setTimeSpan('1day');
      setSearchQuery('');
    }
  }, [isOpen]);

  const loadRoles = async () => {
    try {
      setLoadingData(true);
      const response = await dataApi.getRoles() as any;
      if (Array.isArray(response)) {
        setRoles(response);
      }
    } catch (error) {
      console.error('Error loading roles:', error);
      toast.error('Failed to load roles');
    } finally {
      setLoadingData(false);
    }
  };

  const loadUsers = async () => {
    try {
      const response = await dataApi.getUsers() as any;
      if (Array.isArray(response)) {
        const formattedUsers = response
          .filter((user: any) => user._id !== currentUser?.id && user.is_active !== false)
          .map((user: any) => ({
            _id: user._id,
            name: user.name || `${user.first_name || ''} ${user.last_name || ''}`.trim(),
            email: user.email,
            role_name: user.role_name || user.role || '',
            speciality: user.speciality
          }));
        setUsers(formattedUsers);
      }
    } catch (error) {
      console.error('Error loading users:', error);
      toast.error('Failed to load users');
    }
  };

  const getRecipientIds = async (): Promise<string[]> => {
    let recipientIds: string[] = [];

    if (recipientType === 'roles') {
      // Get users by selected roles
      for (const roleId of selectedRoles) {
        try {
          const response = await dataApi.getUsersByRole(roleId) as any;
          if (Array.isArray(response)) {
            const userIds = response
              .filter((user: any) => user.is_active !== false)
              .map((user: any) => user._id);
            recipientIds.push(...userIds);
          }
        } catch (error) {
          console.error(`Error getting users for role ${roleId}:`, error);
        }
      }
    } else if (recipientType === 'specialties') {
      // Get users by selected specialties
      for (const specialty of selectedSpecialties) {
        try {
          const response = await dataApi.getTechniciansBySpecialty(specialty) as any;
          if (Array.isArray(response)) {
            const userIds = response.map((user: any) => user._id);
            recipientIds.push(...userIds);
          }
        } catch (error) {
          console.error(`Error getting users for specialty ${specialty}:`, error);
        }
      }
    } else if (recipientType === 'users') {
      recipientIds = selectedUsers.map(user => user._id);
    } else if (recipientType === 'all') {
      // All users, no need to fetch IDs
      recipientIds = users.map(user => user._id);
    }

    // Remove duplicates and current user
    return [...new Set(recipientIds)].filter(id => id !== currentUser?.id);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title.trim()) {
      toast.error('Please enter an announcement title');
      return;
    }

    if (!content.trim()) {
      toast.error('Please enter announcement content');
      return;
    }

    if (recipientType === 'roles' && selectedRoles.length === 0) {
      toast.error('Please select at least one role');
      return;
    }

    if (recipientType === 'specialties' && selectedSpecialties.length === 0) {
      toast.error('Please select at least one specialty');
      return;
    }

    if (recipientType === 'users' && selectedUsers.length === 0) {
      toast.error('Please select at least one user');
      return;
    }

    if (recipientType === 'all') {
      const confirmed = window.confirm('This will send the announcement to all users. Do you want to continue?');
      if (!confirmed) return;
    }

    if (timeSpan === 'custom' && !customDate) {
      toast.error('Please select a custom expiration date/time');
      return;
    }

    try {
      setLoading(true);
      
      const recipientIds = await getRecipientIds();
      
      if (recipientIds.length === 0) {
        toast.error('No valid recipients found');
        return;
      }

      // Map timeSpan to duration_minutes for backend
      const duration_minutes = timeSpanToMinutes(timeSpan);
      const payload: any = {
        title: title.trim(),
        description: content.trim(),
        recipient_ids: recipientIds,
      };
      if (duration_minutes) {
        payload.duration_minutes = duration_minutes;
      }

      const response = await messagingApi.createAnnouncement(payload);

      if (response && (response as any).success) {
        toast.success(`Announcement created successfully for ${recipientIds.length} recipient(s)`);
        onAnnouncementCreatedAction();
      } else {
        throw new Error((response as any)?.message || 'Failed to create announcement');
      }
    } catch (error: any) {
      console.error('Error creating announcement:', error);
      toast.error(error.message || 'Failed to create announcement');
    } finally {
      setLoading(false);
    }
  };

  const handleRoleToggle = (roleId: string) => {
    setSelectedRoles(prev => 
      prev.includes(roleId) 
        ? prev.filter(id => id !== roleId)
        : [...prev, roleId]
    );
  };

  const handleSpecialtyToggle = (specialty: string) => {
    setSelectedSpecialties(prev => 
      prev.includes(specialty) 
        ? prev.filter(s => s !== specialty)
        : [...prev, specialty]
    );
  };

  const handleUserToggle = (user: User) => {
    setSelectedUsers(prev => 
      prev.some(u => u._id === user._id)
        ? prev.filter(u => u._id !== user._id)
        : [...prev, user]
    );
  };

  const filteredUsers = users.filter(user =>
    user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.email.toLowerCase().includes(searchQuery.toLowerCase())
  );
  

  // Add a mapping from timeSpan to duration_minutes
  const timeSpanToMinutes = (span: string) => {
    switch (span) {
      case '1hour': return 60;
      case '6hours': return 360;
      case '1day': return 1440;
      case '3days': return 4320;
      case '1week': return 10080;
      case 'permanent': return null; // null or undefined for permanent
      case 'custom':
        if (customDate) {
          const now = new Date();
          const custom = new Date(customDate);
          const diffMs = custom.getTime() - now.getTime();
          if (diffMs > 0) {
            return Math.ceil(diffMs / 60000); // ms to minutes
          }
        }
        return null;
      default: return 1440;
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b">
          <div className="flex items-center space-x-3">
            <Megaphone className="h-6 w-6 text-orange-600" />
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Create New Announcement</h2>
              <p className="text-sm text-gray-600">Send important updates to your team</p>
            </div>
          </div>
          <button
            onClick={onCloseAction}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            disabled={loading}
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-hidden">
          <div className="p-6 space-y-6 overflow-y-auto max-h-[calc(90vh-200px)]">
            {/* Title */}
            <div>
              <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-2">
                Announcement Title *
              </label>
              <input
                type="text"
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Enter announcement title..."
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                maxLength={100}
                required
              />
            </div>

            {/* Content */}
            <div>
              <label htmlFor="content" className="block text-sm font-medium text-gray-700 mb-2">
                Announcement Content *
              </label>
              <textarea
                id="content"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Enter your announcement message..."
                rows={4}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                maxLength={1000}
                required
              />
              <p className="text-xs text-gray-500 mt-1">{content.length}/1000 characters</p>
            </div>

            {/* Recipient Type */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Send Announcement To *
              </label>
              <div className="grid grid-cols-4 gap-3">
                <button
                  type="button"
                  onClick={() => setRecipientType('roles')}
                  className={`p-3 border rounded-lg text-center transition-colors ${
                    recipientType === 'roles'
                      ? 'border-orange-500 bg-orange-50 text-orange-700'
                      : 'border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  <Settings className="h-5 w-5 mx-auto mb-2" />
                  <span className="text-sm font-medium">By Roles</span>
                </button>
                <button
                  type="button"
                  onClick={() => setRecipientType('specialties')}
                  className={`p-3 border rounded-lg text-center transition-colors ${
                    recipientType === 'specialties'
                      ? 'border-orange-500 bg-orange-50 text-orange-700'
                      : 'border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  <UserCheck className="h-5 w-5 mx-auto mb-2" />
                  <span className="text-sm font-medium">By Specialties</span>
                </button>
                <button
                  type="button"
                  onClick={() => setRecipientType('users')}
                  className={`p-3 border rounded-lg text-center transition-colors ${
                    recipientType === 'users'
                      ? 'border-orange-500 bg-orange-50 text-orange-700'
                      : 'border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  <Users className="h-5 w-5 mx-auto mb-2" />
                  <span className="text-sm font-medium">Specific Users</span>
                </button>
                <button
                  type="button"
                  onClick={() => setRecipientType('all')}
                  className={`p-3 border rounded-lg text-center transition-colors ${
                    recipientType === 'all'
                      ? 'border-orange-500 bg-orange-50 text-orange-700'
                      : 'border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  <Megaphone className="h-5 w-5 mx-auto mb-2" />
                  <span className="text-sm font-medium">All Users</span>
                </button>
              </div>
            </div>

            {/* Recipients Selection */}
            {recipientType === 'roles' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Select Roles ({selectedRoles.length} selected)
                </label>
                {loadingData ? (
                  <div className="text-center py-4">Loading roles...</div>
                ) : (
                  <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto border border-gray-200 rounded-lg p-3">
                    {roles.map((role) => (
                      <label key={role._id} className="flex items-center space-x-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={selectedRoles.includes(role._id)}
                          onChange={() => handleRoleToggle(role._id)}
                          className="h-4 w-4 text-orange-600 focus:ring-orange-500 border-gray-300 rounded"
                        />
                        <span className="text-sm">{role.role_name}</span>
                      </label>
                    ))}
                  </div>
                )}
              </div>
            )}

            {recipientType === 'specialties' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Select Specialties ({selectedSpecialties.length} selected)
                </label>
                <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto border border-gray-200 rounded-lg p-3">
                  {SPECIALTIES.map((specialty) => (
                    <label key={specialty} className="flex items-center space-x-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={selectedSpecialties.includes(specialty)}
                        onChange={() => handleSpecialtyToggle(specialty)}
                        className="h-4 w-4 text-orange-600 focus:ring-orange-500 border-gray-300 rounded"
                      />
                      <span className="text-sm">{specialty}</span>
                    </label>
                  ))}
                </div>
              </div>
            )}

            {recipientType === 'users' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Select Users ({selectedUsers.length} selected)
                </label>
                <div className="space-y-3">
                  <input
                    type="text"
                    placeholder="Search users..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                  />
                  <div className="max-h-48 overflow-y-auto border border-gray-200 rounded-lg">
                    {filteredUsers.map((user) => (
                      <label
                        key={user._id}
                        className="flex items-center space-x-3 p-3 hover:bg-gray-50 cursor-pointer border-b border-gray-100 last:border-b-0"
                      >
                        <input
                          type="checkbox"
                          checked={selectedUsers.some(u => u._id === user._id)}
                          onChange={() => handleUserToggle(user)}
                          className="h-4 w-4 text-orange-600 focus:ring-orange-500 border-gray-300 rounded"
                        />
                        <div className="flex-1">
                          <p className="text-sm font-medium text-gray-900">{user.name}</p>
                          <p className="text-xs text-gray-500">{user.email}</p>
                          {user.role_name && (
                            <p className="text-xs text-gray-400">{user.role_name}</p>
                          )}
                        </div>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {recipientType === 'all' && (
              <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg text-orange-700 text-center">
                <Megaphone className="inline h-5 w-5 mr-2 align-text-bottom" />
                This announcement will be sent to <b>all users</b> in the system.
              </div>
            )}

            {/* Time Span */}
            <div>
              <label htmlFor="timeSpan" className="block text-sm font-medium text-gray-700 mb-2">
                <Clock className="h-4 w-4 inline mr-1" />
                Announcement Duration
              </label>
              <div className="relative">
                <select
                  id="timeSpan"
                  value={timeSpan}
                  onChange={(e) => setTimeSpan(e.target.value as any)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 appearance-none bg-white pr-8"
                  style={{ minHeight: '44px' }}
                >
                  <option value="1hour">Delete after 1 Hour</option>
                  <option value="6hours">Delete after 6 Hours</option>
                  <option value="1day">Delete after 1 Day</option>
                  <option value="3days">Delete after 3 Days</option>
                  <option value="1week">Delete after 1 Week</option>
                  <option value="permanent">Keep Permanently</option>
                  <option value="custom">Custom Date/Time</option>
                </select>
                <span className="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400">
                  <svg className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" /></svg>
                </span>
              </div>
              {timeSpan === 'custom' && (
                <div className="mt-3">
                  <label htmlFor="customDate" className="block text-xs font-medium text-gray-600 mb-1">Select Expiration Date/Time</label>
                  <input
                    type="datetime-local"
                    id="customDate"
                    value={customDate}
                    onChange={e => setCustomDate(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                    min={new Date().toISOString().slice(0, 16)}
                    required
                  />
                </div>
              )}
            </div>
          </div>

          {/* Footer */}
          <div className="flex justify-between items-center p-6 border-t bg-gray-50">
            <button
              type="button"
              onClick={onCloseAction}
              disabled={loading}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors disabled:opacity-50"
            >
              Cancel
            </button>
            <div className="flex space-x-3">
              <span className="text-sm text-gray-600">
                Recipients: {
                  recipientType === 'roles' ? selectedRoles.length :
                  recipientType === 'specialties' ? selectedSpecialties.length :
                  recipientType === 'users' ? selectedUsers.length :
                  'All Users'
                } selected
              </span>
              <button
                type="submit"
                disabled={loading}
                className="px-6 py-2 text-sm font-medium text-white bg-orange-600 rounded-lg hover:bg-orange-700 transition-colors disabled:opacity-50"
              >
                {loading ? 'Creating...' : 'Create Announcement'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
