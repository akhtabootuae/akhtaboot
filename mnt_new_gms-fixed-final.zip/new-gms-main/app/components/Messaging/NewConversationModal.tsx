"use client";

import React, { useState, useEffect } from 'react';
import { messagingApi, dataApi } from '@/services/api';
import { UserSearchResult, ConversationType } from '@/app/types/messaging';
import { X, Search, Users, User, Plus, Trash2 } from 'lucide-react';
import { toast } from 'react-hot-toast';

interface NewConversationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConversationCreated: () => void;
  canCreateGroups: boolean;
  currentUser: any;
}

export default function NewConversationModal({
  isOpen,
  onClose,
  onConversationCreated,
  canCreateGroups,
  currentUser
}: NewConversationModalProps) {
  const [conversationType, setConversationType] = useState<ConversationType>('private');
  const [title, setTitle] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<UserSearchResult[]>([]);
  const [selectedUsers, setSelectedUsers] = useState<UserSearchResult[]>([]);
  const [searching, setSearching] = useState(false);
  const [creating, setCreating] = useState(false);

  // Reset form when modal opens/closes
  useEffect(() => {
    if (isOpen) {
      setConversationType('private');
      setTitle('');
      setSearchQuery('');
      setSearchResults([]);
      setSelectedUsers([]);
    }
  }, [isOpen]);

  // Search users with debouncing
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (searchQuery.trim()) {
        searchUsers();
      } else {
        setSearchResults([]);
      }
    }, 300);

    return () => clearTimeout(timeoutId);
  }, [searchQuery]);

  const searchUsers = async () => {
    try {
      setSearching(true);
      const response = await dataApi.getUsers() as any;
      
      if (response && Array.isArray(response)) {
        // Filter users based on search query and exclude current user and selected users
        const searchTerm = searchQuery.trim().toLowerCase();
        const filteredUsers = response
          .filter((user: any) => 
            user._id !== currentUser?.id && 
            !selectedUsers.some(selected => selected._id === user._id) &&
            (user.name?.toLowerCase().includes(searchTerm) || 
             user.email?.toLowerCase().includes(searchTerm) ||
             `${user.first_name || ''} ${user.last_name || ''}`.toLowerCase().includes(searchTerm))
          )
          .slice(0, 20) // Limit to 20 results
          .map((user: any) => ({
            _id: user._id,
            name: user.name || `${user.first_name || ''} ${user.last_name || ''}`.trim(),
            email: user.email,
            role_name: user.role_name || user.role || '',
            branch: user.branch
          }));
        
        setSearchResults(filteredUsers);
      }
    } catch (error: any) {
      console.error('Error searching users:', error);
      toast.error('Failed to search users');
    } finally {
      setSearching(false);
    }
  };

  const addUser = (user: UserSearchResult) => {
    setSelectedUsers(prev => [...prev, user]);
    setSearchResults(prev => prev.filter(u => u._id !== user._id));
    setSearchQuery('');
  };

  const removeUser = (userId: string) => {
    setSelectedUsers(prev => prev.filter(user => user._id !== userId));
  };

  const validateForm = () => {
    if (conversationType === 'private') {
      return selectedUsers.length === 1;
    } else if (conversationType === 'group') {
      return title.trim() && selectedUsers.length >= 1;
    }
    return false;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm() || creating) {
      return;
    }

    try {
      setCreating(true);

      let response;
      switch (conversationType) {
        case 'private':
          response = await messagingApi.createPrivateConversation(selectedUsers[0]._id);
          break;
        case 'group':
          response = await messagingApi.createGroupConversation({
            title: title.trim(),
            participant_ids: selectedUsers.map(user => user._id)
          });
          break;
      }

      if (response && response.success) {
        onConversationCreated();
        onClose();
        toast.success(`${conversationType === 'private' ? 'Private conversation' : 'Group conversation'} created successfully`);
      } else {
        throw new Error(response?.message || 'Failed to create conversation');
      }
    } catch (error: any) {
      console.error('Error creating conversation:', error);
      toast.error(error.message || 'Failed to create conversation');
    } finally {
      setCreating(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">New Conversation</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Conversation type selector */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Conversation Type
            </label>
            <div className="space-y-2">
              <label className="flex items-center space-x-3 cursor-pointer">
                <input
                  type="radio"
                  name="conversationType"
                  value="private"
                  checked={conversationType === 'private'}
                  onChange={(e) => setConversationType(e.target.value as ConversationType)}
                  className="text-blue-600 focus:ring-blue-500"
                />
                <User className="h-5 w-5 text-gray-500" />
                <div>
                  <span className="text-sm font-medium text-gray-900">Private Chat</span>
                  <p className="text-xs text-gray-500">One-on-one conversation</p>
                </div>
              </label>

              {canCreateGroups && (
                <label className="flex items-center space-x-3 cursor-pointer">
                  <input
                    type="radio"
                    name="conversationType"
                    value="group"
                    checked={conversationType === 'group'}
                    onChange={(e) => setConversationType(e.target.value as ConversationType)}
                    className="text-blue-600 focus:ring-blue-500"
                  />
                  <Users className="h-5 w-5 text-gray-500" />
                  <div>
                    <span className="text-sm font-medium text-gray-900">Group Chat</span>
                    <p className="text-xs text-gray-500">Multiple participants</p>
                  </div>
                </label>
              )}
            </div>
          </div>

          {/* Title field for group */}
          {conversationType === 'group' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Group Name *
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Enter group name..."
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                maxLength={100}
                required
              />
            </div>
          )}

          {/* User selection for private and group conversations */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {conversationType === 'private' ? 'Select User' : 'Add Participants'} *
            </label>
            
            {/* User search */}
            <div className="relative mb-3">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search users by name or email..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>

            {/* Search results */}
            {searchResults.length > 0 && (
              <div className="border border-gray-200 rounded-lg max-h-32 overflow-y-auto mb-3">
                {searchResults.map(user => (
                  <button
                    key={user._id}
                    type="button"
                    onClick={() => addUser(user)}
                    className="w-full flex items-center space-x-3 p-3 hover:bg-gray-50 border-b border-gray-100 last:border-b-0"
                  >
                    <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-medium">
                      {user.name.charAt(0).toUpperCase()}
                    </div>
                    <div className="flex-1 text-left">
                      <p className="text-sm font-medium text-gray-900">{user.name}</p>
                      <p className="text-xs text-gray-500">{user.email}</p>
                      {user.branch && (
                        <p className="text-xs text-gray-400">{user.branch.branch_name}</p>
                      )}
                    </div>
                    <Plus className="h-4 w-4 text-gray-400" />
                  </button>
                ))}
              </div>
            )}

            {/* Selected users */}
            {selectedUsers.length > 0 && (
              <div className="space-y-2">
                <p className="text-sm font-medium text-gray-700">
                  Selected {conversationType === 'private' ? 'User' : 'Participants'}:
                </p>
                <div className="space-y-1">
                  {selectedUsers.map(user => (
                    <div key={user._id} className="flex items-center justify-between p-2 bg-blue-50 rounded-lg">
                      <div className="flex items-center space-x-2">
                        <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center text-white text-xs font-medium">
                          {user.name.charAt(0).toUpperCase()}
                        </div>
                        <span className="text-sm text-gray-900">{user.name}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => removeUser(user._id)}
                        className="p-1 hover:bg-blue-100 rounded"
                      >
                        <Trash2 className="h-4 w-4 text-gray-500" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Validation message */}
            {conversationType === 'private' && selectedUsers.length !== 1 && (
              <p className="text-sm text-gray-500 mt-2">
                Please select exactly one user for a private conversation.
              </p>
            )}
            {conversationType === 'group' && selectedUsers.length === 0 && (
              <p className="text-sm text-gray-500 mt-2">
                Please add at least one participant to the group.
              </p>
            )}
          </div>

          {/* Actions */}
          <div className="flex justify-end space-x-3 pt-4 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50"
              disabled={creating}
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!validateForm() || creating}
              className="px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300 rounded-lg transition-colors disabled:cursor-not-allowed"
            >
              {creating ? (
                <>
                  <div className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                  Creating...
                </>
              ) : (
                `Create ${conversationType === 'private' ? 'Chat' : 'Group'}`
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
