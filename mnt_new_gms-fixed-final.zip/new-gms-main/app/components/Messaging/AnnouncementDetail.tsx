'use client';

import React from 'react';
import { Conversation } from '@/app/types/messaging';
import { Megaphone, User, Calendar, Clock, Trash2, Users } from 'lucide-react';
import { messagingApi } from '@/services/api';
import { toast } from 'react-hot-toast';

interface AnnouncementDetailProps {
  announcement: Conversation;
  currentUser: any;
  onAnnouncementDeletedAction: () => void;
}

export default function AnnouncementDetail({
  announcement,
  currentUser,
  onAnnouncementDeletedAction
}: AnnouncementDetailProps) {
  const [deleting, setDeleting] = React.useState(false);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  const handleDeleteAnnouncement = async () => {
    if (!window.confirm('Are you sure you want to delete this announcement?')) {
      return;
    }

    try {
      setDeleting(true);
      const response = await messagingApi.deleteAnnouncement(announcement._id);
      
      if (response && (response as any).success) {
        toast.success('Announcement deleted successfully');
        onAnnouncementDeletedAction();
      } else {
        throw new Error((response as any)?.message || 'Failed to delete announcement');
      }
    } catch (error: any) {
      console.error('Error deleting announcement:', error);
      toast.error(error.message || 'Failed to delete announcement');
    } finally {
      setDeleting(false);
    }
  };

  // Check if current user can delete this announcement
  const canDelete = currentUser?.id === announcement.created_by || 
                   currentUser?.role_name?.toLowerCase() === 'admin';

  return (
    <div className="flex-1 flex flex-col h-full bg-white">
      {/* Announcement Info Card */}
      <div className="mt-4 mx-6 bg-white rounded-lg border border-gray-200 p-4 flex items-center gap-4">
        <div className="flex items-center gap-2 text-gray-700">
          <span className="font-small">
            {(() => {
              const creator = announcement.participants.find(p => p.user_id === announcement.created_by) as any;
              return "Created by: " +  creator?.name || 'Unknown';
            })()}
          </span>
          {(() => {
            // Use 'as any' to access branch_name since it's present in your data but not in the type
            const creator = announcement.participants.find(p => p.user_id === announcement.created_by) as any;
            return creator?.branch_name ? (
              <span className="ml-2 px-2 py-0.5 bg-gray-100 border border-gray-200 rounded text-xs text-gray-600 min-w-[90px] text-center inline-block align-middle">{creator.branch_name}</span>
            ) : null;
          })()}
        </div>
        <div className="flex items-center gap-2 text-xs text-gray-500">
          <Calendar className="h-4 w-4" />
          <span>{formatDate(announcement.created_at)}</span>
        </div>
        {canDelete && (
          <button
            onClick={handleDeleteAnnouncement}
            disabled={deleting}
            className="ml-auto p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors disabled:opacity-50"
            title="Delete announcement"
          >
            <Trash2 className="h-5 w-5" />
          </button>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-6">
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Announcement Content</h3>
            <div className="prose prose-sm max-w-none">
              <p className="text-gray-700 leading-relaxed whitespace-pre-wrap">
                {announcement.description || 'No content provided.'}
              </p>
            </div>
          </div>

          {/* Recipients Info */}
          <div className="mt-6 bg-gray-50 rounded-lg p-4">
            <h4 className="text-sm font-medium text-gray-900 mb-3 flex items-center">
              <Users className="h-4 w-4 mr-2" />
              Recipients ({announcement.participants.length})
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {announcement.participants.map((participant) => (
                <div
                  key={participant.user_id}
                  className="flex items-center space-x-2 text-sm"
                >
                  <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center">
                    <span className="text-xs font-medium text-blue-600">
                      {participant.name?.charAt(0)?.toUpperCase() || '?'}
                    </span>
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{participant.name}</p>
                    {participant.role && (
                      <p className="text-xs text-gray-500">{participant.role}</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Time Info */}
          {announcement.updated_at !== announcement.created_at && (
            <div className="mt-4 bg-blue-50 rounded-lg p-4">
              <div className="flex items-center space-x-2 text-sm text-blue-700">
                <Clock className="h-4 w-4" />
                <span>Last updated: {formatDate(announcement.updated_at)}</span>
              </div>
            </div>
          )}

          {/* Expiration Info */}
          {announcement.expiresAt && (
            <div className="mt-4 bg-orange-50 rounded-lg p-4">
              <div className="flex items-center space-x-2 text-sm text-orange-700">
                <Clock className="h-4 w-4" />
                <span>
                  Expires: {formatDate(announcement.expiresAt)}
                </span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
