"use client";

import React from 'react';
import { Conversation } from '@/app/types/messaging';
import { Users, User, Megaphone, MessageCircle } from 'lucide-react';

interface ConversationListProps {
  conversations: Conversation[];
  selectedConversation: Conversation | null;
  onConversationSelect: (conversation: Conversation) => void;
  currentUserId: string;
}

export default function ConversationList({
  conversations,
  selectedConversation,
  onConversationSelect,
  currentUserId
}: ConversationListProps) {
  
  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = diff / (1000 * 60 * 60);
    
    if (hours < 1) {
      return 'Just now';
    } else if (hours < 24) {
      return date.toLocaleTimeString('en-US', { 
        hour: 'numeric', 
        minute: '2-digit',
        hour12: true 
      });
    } else if (hours < 168) { // 7 days
      return date.toLocaleDateString('en-US', { weekday: 'short' });
    } else {
      return date.toLocaleDateString('en-US', { 
        month: 'short', 
        day: 'numeric' 
      });
    }
  };

  const getConversationIcon = (conversation: Conversation) => {
    switch (conversation.type) {
      case 'group':
        return <Users className="h-5 w-5 text-blue-700" />;
      case 'announcement':
        return <Megaphone className="h-5 w-5 text-orange-700" />;
      default:
        return <User className="h-5 w-5 text-emerald-700" />;
    }
  };

  const getOtherParticipant = (conversation: Conversation) => {
    if (conversation.type !== 'private') return null;
    return conversation.participants.find(p => p.user_id !== currentUserId);
  };

  const getDisplayTitle = (conversation: Conversation) => {
    if (conversation.type === 'private') {
      const otherParticipant = getOtherParticipant(conversation);
      return otherParticipant?.name || 'Unknown User';
    }
    return conversation.title;
  };

  const truncateContent = (content: string | undefined | null, maxLength: number = 50) => {
    if (!content) return '';
    if (content.length <= maxLength) return content;
    return content.substring(0, maxLength) + '...';
  };

  if (conversations.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-gray-500">
        <MessageCircle className="h-12 w-12 mb-4 text-gray-300" />
        <p className="text-center">No conversations yet</p>
        <p className="text-sm text-center mt-1">Start a new conversation to get started</p>
      </div>
    );
  }

  return (
    <div className="space-y-1">
      {conversations.map((conversation) => (
        <div
          key={conversation._id}
          onClick={() => onConversationSelect(conversation)}
          className={`mx-2 p-4 cursor-pointer transition-all duration-300 rounded-xl backdrop-blur-sm border ${
            selectedConversation?._id === conversation._id
              ? 'bg-gradient-to-r from-blue-50/80 to-indigo-50/80 border-blue-200/50 shadow-lg transform scale-[1.02] ring-1 ring-blue-200/50'
              : 'bg-white/40 border-gray-200/30 hover:bg-white/60 hover:border-gray-300/50 hover:shadow-md hover:transform hover:scale-[1.01]'
          }`}
        >
          <div className="flex items-start space-x-3">
            {/* Enhanced Avatar/Icon */}
            <div className="flex-shrink-0 relative">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all duration-200 ${
                conversation.type === 'private' 
                  ? 'bg-gradient-to-br from-emerald-100 to-emerald-200 text-emerald-700' 
                  : conversation.type === 'group'
                  ? 'bg-gradient-to-br from-blue-100 to-blue-200 text-blue-700'
                  : 'bg-gradient-to-br from-orange-100 to-orange-200 text-orange-700'
              }`}>
                {conversation.type === 'private' ? (
                  <span className="text-lg font-bold">
                    {getDisplayTitle(conversation).charAt(0).toUpperCase()}
                  </span>
                ) : (
                  getConversationIcon(conversation)
                )}
              </div>
              {/* Online status indicator for active conversations */}
              {selectedConversation?._id === conversation._id && (
                <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-emerald-500 rounded-full border-2 border-white shadow-sm animate-pulse"></div>
              )}
            </div>

            {/* Enhanced Conversation content */}
            <div className="flex-1 min-w-0 overflow-hidden">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-base font-bold text-gray-900 truncate flex-1 min-w-0 pr-2">
                  {getDisplayTitle(conversation)}
                </h3>
                <div className="flex items-center space-x-2 flex-shrink-0">
                  {conversation.last_message && (
                    <span className="text-xs font-medium text-gray-500 whitespace-nowrap">
                      {formatTime(conversation.last_message.created_at)}
                    </span>
                  )}
                  {conversation.unread_count && conversation.unread_count > 0 && (
                    <span className="inline-flex items-center justify-center w-6 h-6 text-xs font-bold text-white bg-gradient-to-r from-blue-500 to-blue-600 rounded-full shadow-lg animate-pulse">
                      {conversation.unread_count > 9 ? '9+' : conversation.unread_count}
                    </span>
                  )}
                </div>
              </div>

              {/* Enhanced Last message preview */}
              {conversation.last_message ? (
                <div className="mb-3 overflow-hidden">
                  <p className="text-sm leading-relaxed">
                    <span className="font-semibold text-gray-800">
                      {conversation.last_message.sender_name}:
                    </span>{' '}
                    <span className="text-gray-600">
                      {truncateContent(conversation.last_message.content || 'No content', 40)}
                    </span>
                  </p>
                </div>
              ) : conversation.type !== 'announcement' ? (
                <p className="text-sm text-gray-400 italic mb-3">
                  No messages yet
                </p>
              ) : (
                <div className="mb-3"></div>
              )}

              {/* Enhanced Conversation type indicator */}
              {conversation.type !== 'private' && (
                <div className="flex items-center space-x-1 overflow-hidden">
                  {conversation.type === 'group' && (
                    <span className="inline-flex items-center px-3 py-1 text-xs font-semibold text-blue-700 bg-gradient-to-r from-blue-100/80 to-blue-200/80 rounded-full backdrop-blur-sm border border-blue-200/50">
                      <Users className="w-3 h-3 mr-1 flex-shrink-0" />
                      <span className="truncate">{conversation.participants.length} members</span>
                    </span>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
