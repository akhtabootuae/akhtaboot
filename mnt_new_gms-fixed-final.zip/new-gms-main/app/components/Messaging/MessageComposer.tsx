"use client";

import React, { useState, useRef } from 'react';
import { createPortal } from 'react-dom';
import { ConversationType } from '@/app/types/messaging';
import { Send, Megaphone, Image as ImageIcon, Mic, Square } from 'lucide-react';
import { messagingApi } from '@/services/api';
import { toast } from 'react-hot-toast';

interface MessageComposerProps {
  onSendMessage: (content: string, messageType?: 'text' | 'announcement') => void;
  onMediaSent: (messageType: 'image' | 'voice_note') => void; // Add message type parameter
  conversationType: ConversationType;
  canSendAnnouncements: boolean;
  selectedConversation?: any; // Add conversation context for media upload
}

export default function MessageComposer({
  onSendMessage,
  onMediaSent,
  conversationType,
  canSendAnnouncements,
  selectedConversation
}: MessageComposerProps) {
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState<'text' | 'announcement'>('text');
  const [sending, setSending] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  // Media states
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imageCaption, setImageCaption] = useState('');
  const [showImagePreview, setShowImagePreview] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
  const [recordedBlob, setRecordedBlob] = useState<Blob | null>(null);

  // Media utility functions
  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Check file size (25MB limit)
      if (file.size > 25 * 1024 * 1024) {
        toast.error('Image size must be less than 25MB');
        e.target.value = '';
        return;
      }
      // Check file type
      if (!file.type.startsWith('image/')) {
        toast.error('Please select a valid image file');
        e.target.value = '';
        return;
      }
      setSelectedImage(file);
      setShowImagePreview(true);
    }
    // Always clear input so same file can be selected again
    e.target.value = '';
  };

  const handleSendImage = async () => {
    if (!selectedImage || !selectedConversation) return;
    
    try {
      setSending(true);
      const response = await messagingApi.sendImage(
        selectedConversation._id, 
        selectedImage, 
        imageCaption
      ) as any;
      
      toast.success('Image sent successfully');
      resetImageState();
      // Trigger message refresh to show the new image immediately
      onMediaSent('image');
      
    } catch (error: any) {
      const errorMessage = error.response?.data?.message || error.message || 'Error sending image';
      toast.error(errorMessage);
    } finally {
      setSending(false);
      // Always reset input after send attempt
      if (imageInputRef.current) imageInputRef.current.value = '';
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        }
      });
      
      const recorder = new MediaRecorder(stream);
      const chunks: BlobPart[] = [];
      
      recorder.ondataavailable = (e) => chunks.push(e.data);
      recorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'audio/webm' });
        setRecordedBlob(blob);
        stream.getTracks().forEach(track => track.stop());
      };
      
      recorder.start();
      setMediaRecorder(recorder);
      setIsRecording(true);
      setRecordingTime(0);
      
      // Start timer
      const timer = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
      
      (recorder as any).timer = timer;
      
    } catch (error) {
      toast.error('Could not access microphone');
    }
  };

  const stopRecording = () => {
    if (mediaRecorder && isRecording) {
      mediaRecorder.stop();
      clearInterval((mediaRecorder as any).timer);
      setIsRecording(false);
    }
  };

  const sendVoiceNote = async () => {
    if (!recordedBlob || !selectedConversation) return;
    
    try {
      setSending(true);
      const file = new File([recordedBlob], `voice_${Date.now()}.webm`, { type: 'audio/webm' });
      const response = await messagingApi.sendVoice(
        selectedConversation._id, 
        file, 
        recordingTime
      ) as any;
      
      toast.success('Voice note sent successfully');
      setRecordedBlob(null);
      setRecordingTime(0);
      
      // Trigger message refresh to show the new voice note immediately
      onMediaSent('voice_note');
      
    } catch (error: any) {
      const errorMessage = error.response?.data?.message || error.message || 'Error sending voice note';
      toast.error(errorMessage);
    } finally {
      setSending(false);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!message.trim() || sending) return;

    try {
      setSending(true);
      await onSendMessage(message.trim(), messageType);
      setMessage('');
      setMessageType('text');
      
      // Reset textarea height
      if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
      }
    } catch (error) {
      console.error('Error sending message:', error);
    } finally {
      setSending(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const handleTextareaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setMessage(e.target.value);
    
    // Auto-resize textarea
    const textarea = e.target;
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 120) + 'px';
  };

  const resetImageState = () => {
    setShowImagePreview(false);
    setSelectedImage(null);
    setImageCaption('');
    if (imageInputRef.current) imageInputRef.current.value = '';
  };

  const maxMessageLength = 10000; // 10KB limit as per backend
  const remainingChars = maxMessageLength - message.length;

  return (
    <div className="p-2 bg-gradient-to-r from-white/90 to-gray-50/90 backdrop-blur-sm">
      <form onSubmit={handleSubmit} className="space-y-2">
        {/* Compact Message type selector for announcements */}
        {conversationType === 'announcement' && canSendAnnouncements && (
          <div className="flex items-center space-x-3 p-1.5 bg-white/60 backdrop-blur-sm rounded-lg border border-gray-200/50">
            <label className="flex items-center space-x-1.5 cursor-pointer group">
              <input
                type="radio"
                name="messageType"
                value="text"
                checked={messageType === 'text'}
                onChange={(e) => setMessageType(e.target.value as 'text')}
                className="w-3 h-3 text-blue-600 focus:ring-blue-500/20 focus:ring-1 border-gray-300"
              />
              <span className="text-xs font-medium text-gray-700 group-hover:text-blue-600 transition-colors">
                Regular
              </span>
            </label>
            <label className="flex items-center space-x-1.5 cursor-pointer group">
              <input
                type="radio"
                name="messageType"
                value="announcement"
                checked={messageType === 'announcement'}
                onChange={(e) => setMessageType(e.target.value as 'announcement')}
                className="w-3 h-3 text-orange-600 focus:ring-orange-500/20 focus:ring-1 border-gray-300"
              />
              <div className="flex items-center space-x-1 group-hover:text-orange-600 transition-colors">
                <Megaphone className="h-3 w-3 text-orange-600 group-hover:scale-110 transition-transform" />
                <span className="text-xs font-medium text-gray-700 group-hover:text-orange-600 transition-colors">
                  Announcement
                </span>
              </div>
            </label>
          </div>
        )}

        {/* Compact Message Input Container */}
        <div className="relative">
          {/* Main input container with compact styling */}
          <div className={`relative bg-white rounded-2xl border transition-all duration-200 shadow-sm hover:shadow-md ${
            messageType === 'announcement'
              ? 'border-orange-200 focus-within:border-orange-400'
              : 'border-gray-200 focus-within:border-blue-400'
          }`}>
            
            {/* Compact media buttons row */}
            {conversationType !== 'announcement' && (
              <div className="flex items-center px-3 pt-2 pb-1 border-b border-gray-100/50">
                <div className="flex items-center space-x-0.5">
                  {/* Image Button */}
                  <input
                    ref={imageInputRef}
                    type="file"
                    accept="image/jpeg,image/png,image/gif,image/webp"
                    onChange={handleImageSelect}
                    className="hidden"
                    id="image-input"
                  />
                  <button
                    type="button"
                    onClick={() => document.getElementById('image-input')?.click()}
                    disabled={sending}
                    className="group flex items-center justify-center w-7 h-7 rounded-full bg-blue-50 hover:bg-blue-100 text-blue-600 hover:text-blue-700 transition-all duration-200 disabled:opacity-50"
                    title="Attach Image"
                  >
                    <ImageIcon className="h-3.5 w-3.5" />
                  </button>

                  {/* Voice Recording Button */}
                  <button
                    type="button"
                    onClick={isRecording ? stopRecording : startRecording}
                    disabled={sending}
                    className={`group flex items-center justify-center w-7 h-7 rounded-full transition-all duration-200 disabled:opacity-50 ${
                      isRecording 
                        ? 'bg-red-100 hover:bg-red-200 text-red-600 hover:text-red-700 animate-pulse' 
                        : 'bg-orange-50 hover:bg-orange-100 text-orange-600 hover:text-orange-700'
                    }`}
                    title={isRecording ? 'Stop Recording' : 'Record Voice Note'}
                  >
                    {isRecording ? (
                      <Square className="h-3.5 w-3.5" />
                    ) : (
                      <Mic className="h-3.5 w-3.5" />
                    )}
                  </button>
                </div>
                
                {/* Compact recording indicator */}
                {isRecording && (
                  <div className="ml-2 flex items-center space-x-1.5 text-red-600">
                    <div className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse"></div>
                    <span className="text-xs font-medium">{formatTime(recordingTime)}</span>
                  </div>
                )}
              </div>
            )}

            {/* Compact text input area */}
            <div className="relative px-3 py-2">
              <div className="flex items-end space-x-2">
                {/* Text input */}
                <div className="flex-1 relative">
                  <textarea
                    ref={textareaRef}
                    value={message}
                    onChange={handleTextareaChange}
                    onKeyDown={handleKeyDown}
                    placeholder={
                      messageType === 'announcement' 
                        ? "✨ Type announcement..."
                        : "💬 Type message..."
                    }
                    className="w-full px-0 py-0.5 bg-transparent border-0 resize-none outline-none placeholder-gray-400 text-gray-800 text-sm leading-tight"
                    style={{ minHeight: '18px', maxHeight: '72px' }}
                    disabled={sending}
                    maxLength={maxMessageLength}
                  />
                  
                  {/* Character count - compact floating */}
                  {message.length > maxMessageLength * 0.8 && (
                    <div className={`absolute -top-6 right-0 text-xs px-1.5 py-0.5 rounded-md bg-white shadow-sm border ${
                      remainingChars < 100 ? 'text-red-500 border-red-200' : 'text-amber-500 border-amber-200'
                    }`}>
                      {remainingChars}
                    </div>
                  )}
                </div>

                {/* Compact send button */}
                <div className="flex-shrink-0">
                  <button
                    type="submit"
                    disabled={(!message.trim() && !recordedBlob) || sending || remainingChars < 0}
                    className={`group relative flex items-center justify-center w-8 h-8 rounded-xl transition-all duration-200 transform hover:scale-105 disabled:transform-none disabled:opacity-40 shadow-sm hover:shadow-md ${
                      messageType === 'announcement'
                        ? 'bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700'
                        : 'bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700'
                    } text-white disabled:cursor-not-allowed`}
                  >
                    {sending ? (
                      <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <Send className="h-3.5 w-3.5 group-hover:translate-x-0.5 transition-transform" />
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>
          
          {/* Compact help text */}
          <div className="flex justify-between items-center mt-1.5 px-1">
            <div className="text-xs text-gray-400 flex items-center space-x-1">
              <span>💡</span>
              <span>Enter to send • Shift+Enter for new line</span>
            </div>
            {remainingChars <= 1000 && message.length > maxMessageLength * 0.7 && (
              <div className={`text-xs font-medium px-1.5 py-0.5 rounded-md ${
                remainingChars < 100 
                  ? 'text-red-600 bg-red-50' 
                  : remainingChars < 500 
                  ? 'text-amber-600 bg-amber-50' 
                  : 'text-gray-600 bg-gray-50'
              }`}>
                {remainingChars} left
              </div>
            )}
          </div>
        </div>

        {/* Compact Recording Status */}
        {isRecording && (
          <div className="flex items-center justify-center space-x-2 py-1.5 bg-red-50 rounded-lg border border-red-200">
            <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
            <span className="text-red-700 font-medium text-sm">Recording: {formatTime(recordingTime)}</span>
          </div>
        )}

        {/* Compact Voice Note Preview */}
        {recordedBlob && !isRecording && (
          <div className="flex items-center justify-between p-2 bg-orange-50 rounded-lg border border-orange-200">
            <div className="flex items-center space-x-2">
              <Mic className="h-3.5 w-3.5 text-orange-600" />
              <span className="text-orange-800 text-sm">Voice note ({formatTime(recordingTime)})</span>
            </div>
            <div className="flex space-x-1.5">
              <button
                onClick={sendVoiceNote}
                disabled={sending}
                className="px-2 py-1 bg-orange-600 text-white rounded-md hover:bg-orange-700 disabled:opacity-50 text-xs"
              >
                Send
              </button>
              <button
                onClick={() => {
                  setRecordedBlob(null);
                  setRecordingTime(0);
                }}
                className="px-2 py-1 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400 text-xs"
              >
                Cancel
              </button>
            </div>
          </div>
        )}

        {/* Image Preview Modal - Rendered using Portal */}
        {showImagePreview && selectedImage && typeof document !== 'undefined' && createPortal(
          <div className="fixed inset-0 bg-black/70 backdrop-blur-md flex items-center justify-center z-[9999] p-4">
            <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto transform transition-all duration-300 scale-100 animate-in fade-in-0 zoom-in-95">
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-bold text-gray-900">Send Image</h3>
                  <button
                    onClick={() => {
                      setShowImagePreview(false);
                      setSelectedImage(null);
                      setImageCaption('');
                    }}
                    className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                  >
                    <svg className="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>
                
                <div className="space-y-4">
                  <div className="relative">
                    <img
                      src={URL.createObjectURL(selectedImage)}
                      alt="Preview"
                      className="w-full max-h-64 object-cover rounded-lg border"
                    />
                    <div className="absolute bottom-2 left-2 bg-black/50 text-white text-xs px-2 py-1 rounded">
                      {(selectedImage.size / 1024 / 1024).toFixed(1)} MB
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Caption (optional)
                    </label>
                    <textarea
                      value={imageCaption}
                      onChange={(e) => setImageCaption(e.target.value)}
                      placeholder="Add a caption to your image..."
                      className="w-full p-3 border border-gray-300 rounded-lg resize-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      maxLength={500}
                      rows={3}
                    />
                    <div className="text-xs text-gray-500 mt-1">
                      {imageCaption.length}/500 characters
                    </div>
                  </div>
                </div>
                
                <div className="flex justify-end space-x-3 mt-6 pt-4 border-t">
                  <button
                    onClick={() => {
                      setShowImagePreview(false);
                      setSelectedImage(null);
                      setImageCaption('');
                    }}
                    disabled={sending}
                    className="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors disabled:opacity-50"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSendImage}
                    disabled={sending}
                    className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 flex items-center space-x-2"
                  >
                    {sending ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        <span>Sending...</span>
                      </>
                    ) : (
                      <>
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                        </svg>
                        <span>Send Image</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>,
          document.body
        )}

        {/* Enhanced Announcement notice */}
        {messageType === 'announcement' && (
          <div className="bg-gradient-to-r from-orange-50/80 to-amber-50/80 backdrop-blur-sm border border-orange-200/50 rounded-xl p-3 shadow-sm">
            <div className="flex items-center space-x-2 mb-2">
              <div className="w-6 h-6 bg-gradient-to-r from-orange-500 to-orange-600 rounded-lg flex items-center justify-center">
                <Megaphone className="h-3 w-3 text-white" />
              </div>
              <span className="text-sm font-bold text-orange-800">
                Announcement Mode Active
              </span>
            </div>
            <p className="text-xs text-orange-700 leading-relaxed pl-8">
              This message will be highlighted and emphasized for all participants.
            </p>
          </div>
        )}
      </form>
    </div>
  );
}
