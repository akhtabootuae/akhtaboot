'use client';

import React, { useState, useEffect } from 'react';
import { X, UserPlus, UserMinus, Search, Users, Plus } from 'lucide-react';
import { messagingApi, dataApi } from '@/services/api';
import { toast } from 'react-hot-toast';

interface User {
  _id: string;
  name: string;
  email: string;
  role_name?: string;
  branch?: {
    branch_name: string;
  };
}

interface Participant {
  user_id: string;
  name: string;
  email: string;
  role_name?: string;
  branch_name?: string;
  joined_at: string;
  is_admin?: boolean;
  show_previous_messages?: boolean;
}

interface Conversation {
  _id: string;
  type: string;
  title: string;
  participants: Participant[];
}

interface GroupManagementModalProps {
  isOpen: boolean;
  onCloseAction: () => void;
  conversation: Conversation | null;
  currentUserId: string;
  onConversationUpdatedAction: () => void;
}

export default function GroupManagementModal({
  isOpen,
  onCloseAction,
  conversation,
  currentUserId,
  onConversationUpdatedAction
}: GroupManagementModalProps) {
  const [activeTab, setActiveTab] = useState<'members' | 'add'>('members');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<User[]>([]);
  const [searching, setSearching] = useState(false);
  const [loading, setLoading] = useState(false);
  const [showPreviousMessages, setShowPreviousMessages] = useState(true);

  // Check if current user is admin
  const currentUserParticipant = conversation?.participants.find(p => p.user_id === currentUserId);
  const isCurrentUserAdmin = currentUserParticipant?.is_admin === true || currentUserParticipant?.role_name === 'Admin';

  // Reset state when modal opens/closes
  useEffect(() => {
    if (isOpen) {
      setActiveTab('members');
      setSearchQuery('');
      setSearchResults([]);
      setShowPreviousMessages(true);
    }
  }, [isOpen]);

  // Search users with debouncing
  useEffect(() => {
    if (activeTab !== 'add') return;

    const timeoutId = setTimeout(() => {
      if (searchQuery.trim()) {
        searchUsers();
      } else {
        setSearchResults([]);
      }
    }, 300);

    return () => clearTimeout(timeoutId);
  }, [searchQuery, activeTab]);

  const searchUsers = async () => {
    try {
      setSearching(true);
      const response = await dataApi.getUsers() as any;
      
      if (response && Array.isArray(response)) {
        const searchTerm = searchQuery.trim().toLowerCase();
        const currentParticipantIds = conversation?.participants.map(p => p.user_id) || [];
        
        const filteredUsers = response
          .filter((user: any) => 
            user._id !== currentUserId && 
            !currentParticipantIds.includes(user._id) &&
            (user.name?.toLowerCase().includes(searchTerm) || 
             user.email?.toLowerCase().includes(searchTerm) ||
             `${user.first_name || ''} ${user.last_name || ''}`.toLowerCase().includes(searchTerm))
          )
          .slice(0, 20)
          .map((user: any) => ({
            _id: user._id,
            name: user.name || `${user.first_name || ''} ${user.last_name || ''}`.trim(),
            email: user.email,
            role_name: user.role_name || user.role || '',
            branch: user.branch
          }));
        
        setSearchResults(filteredUsers);
      } else {
        setSearchResults([]);
      }
    } catch (error: any) {
      console.error('Error searching users:', error);
      toast.error('Failed to search users');
      setSearchResults([]);
    } finally {
      setSearching(false);
    }
  };

  const handleAddUser = async (user: User) => {
    if (!conversation || !isCurrentUserAdmin) {
      toast.error('Only admins can add users to the group');
      return;
    }

    try {
      setLoading(true);
      const response = await messagingApi.addUserToGroup(conversation._id, {
        user_id: user._id,
        show_previous_messages: showPreviousMessages
      });

      if (response && (response as any).success) {
        toast.success(`${user.name} has been added to the group`);
        setSearchQuery('');
        setSearchResults([]);
        onConversationUpdatedAction();
        setActiveTab('members');
      } else {
        throw new Error((response as any)?.message || 'Failed to add user to group');
      }
    } catch (error: any) {
      console.error('Error adding user to group:', error);
      toast.error(error.message || 'Failed to add user to group');
    } finally {
      setLoading(false);
    }
  };

  const handleRemoveUser = async (participant: Participant) => {
    if (!conversation || !isCurrentUserAdmin) {
      toast.error('Only admins can remove users from the group');
      return;
    }

    if (participant.user_id === currentUserId) {
      toast.error('You cannot remove yourself from the group');
      return;
    }

    if (!confirm(`Are you sure you want to remove ${participant.name} from this group?`)) {
      return;
    }

    try {
      setLoading(true);
      const response = await messagingApi.removeUserFromGroup(conversation._id, {
        user_id: participant.user_id
      });

      if (response && (response as any).success) {
        toast.success(`${participant.name} has been removed from the group`);
        onConversationUpdatedAction();
      } else {
        throw new Error((response as any)?.message || 'Failed to remove user from group');
      }
    } catch (error: any) {
      console.error('Error removing user from group:', error);
      toast.error(error.message || 'Failed to remove user from group');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen || !conversation || conversation.type !== 'group') return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[80vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b">
          <div>
            <h2 className="text-xl font-semibold text-gray-900">Manage Group</h2>
            <p className="text-sm text-gray-600 mt-1">{conversation.title}</p>
          </div>
          <button
            onClick={onCloseAction}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            disabled={loading}
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b">
          <button
            onClick={() => setActiveTab('members')}
            className={`px-6 py-3 text-sm font-medium border-b-2 transition-colors ${
              activeTab === 'members'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            <Users className="h-4 w-4 inline mr-2" />
            Members ({conversation.participants.length})
          </button>
          {isCurrentUserAdmin && (
            <button
              onClick={() => setActiveTab('add')}
              className={`px-6 py-3 text-sm font-medium border-b-2 transition-colors ${
                activeTab === 'add'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              <UserPlus className="h-4 w-4 inline mr-2" />
              Add Users
            </button>
          )}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-hidden">
          {activeTab === 'members' && (
            <div className="p-6">
              {!isCurrentUserAdmin && (
                <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                  <p className="text-sm text-blue-700">
                    <Users className="h-4 w-4 inline mr-1" />
                    You can view group members. Only admins can add or remove users.
                  </p>
                </div>
              )}
              <div className="space-y-3 max-h-[400px] overflow-y-auto">
                {conversation.participants.map((participant) => (
                  <div
                    key={participant.user_id}
                    className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                  >
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white font-medium">
                        {participant.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{participant.name}</p>
                        <p className="text-sm text-gray-500">{participant.email}</p>
                        {participant.branch_name && (
                          <p className="text-xs text-gray-400">{participant.branch_name}</p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {participant.is_admin && (
                        <span className="px-2 py-1 text-xs font-medium text-green-700 bg-green-100 rounded-full">
                          Admin
                        </span>
                      )}
                      {participant.user_id !== currentUserId && isCurrentUserAdmin && (
                        <button
                          onClick={() => handleRemoveUser(participant)}
                          disabled={loading}
                          className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors disabled:opacity-50"
                          title="Remove from group"
                        >
                          <UserMinus className="h-4 w-4" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'add' && isCurrentUserAdmin && (
            <div className="p-6 space-y-4">
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search users by name or email..."
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              {/* Options */}
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="showPreviousMessages"
                  checked={showPreviousMessages}
                  onChange={(e) => setShowPreviousMessages(e.target.checked)}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                />
                <label htmlFor="showPreviousMessages" className="text-sm text-gray-700">
                  Allow new members to see previous messages
                </label>
              </div>

              {/* Search Results */}
              {searchQuery && (
                <div className="max-h-[300px] overflow-y-auto">
                  {searching ? (
                    <div className="text-center py-4">
                      <div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
                      <p className="text-sm text-gray-500 mt-2">Searching...</p>
                    </div>
                  ) : searchResults.length > 0 ? (
                    <div className="space-y-2">
                      {searchResults.map((user) => (
                        <div
                          key={user._id}
                          className="flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50"
                        >
                          <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-medium">
                              {user.name.charAt(0).toUpperCase()}
                            </div>
                            <div>
                              <p className="text-sm font-medium text-gray-900">{user.name}</p>
                              <p className="text-xs text-gray-500">{user.email}</p>
                              {user.branch && (
                                <p className="text-xs text-gray-400">{user.branch.branch_name}</p>
                              )}
                            </div>
                          </div>
                          <button
                            onClick={() => handleAddUser(user)}
                            disabled={loading}
                            className="flex items-center space-x-1 px-3 py-1 text-sm text-blue-600 hover:bg-blue-50 rounded-lg transition-colors disabled:opacity-50"
                          >
                            <Plus className="h-4 w-4" />
                            <span>Add</span>
                          </button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-4">
                      <p className="text-sm text-gray-500">No users found</p>
                    </div>
                  )}
                </div>
              )}

              {!searchQuery && (
                <div className="text-center py-8">
                  <Users className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">Search for users to add to this group</p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex justify-end items-center p-6 border-t bg-gray-50">
          <button
            onClick={onCloseAction}
            disabled={loading}
            className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors disabled:opacity-50"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
