'use client';

import React, { useState } from 'react';
import { X, KeyRound, AlertCircle } from 'lucide-react';
import api from '@/services/api';

interface PasswordResetModalProps {
  staff: { _id: string; first_name: string; last_name: string; email: string } | null;
  isOpen: boolean;
  onCloseAction: () => void;
  onUpdateAction: () => void;
}

export default function PasswordResetModal({ 
  staff, 
  isOpen, 
  onCloseAction, 
  onUpdateAction 
}: PasswordResetModalProps) {
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [validationErrors, setValidationErrors] = useState<{[key: string]: string}>({});

  // Reset form when modal opens/closes
  React.useEffect(() => {
    if (isOpen) {
      setNewPassword('');
      setConfirmPassword('');
      setError(null);
      setSuccess(false);
      setValidationErrors({});
    }
  }, [isOpen]);

  // Validate password - minimal requirements
  const validatePassword = (password: string): string | null => {
    if (!password || password.length === 0) {
      return 'Password cannot be empty';
    }
    return null;
  };

  const handlePasswordChange = (value: string) => {
    setNewPassword(value);
    setValidationErrors(prev => {
      const newErrors = { ...prev };
      delete newErrors.newPassword;
      delete newErrors.confirmPassword;
      return newErrors;
    });
  };

  const handleConfirmPasswordChange = (value: string) => {
    setConfirmPassword(value);
    setValidationErrors(prev => {
      const newErrors = { ...prev };
      delete newErrors.confirmPassword;
      return newErrors;
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!staff) return;

    // Reset states
    setError(null);
    setValidationErrors({});

    // Validate form
    const errors: {[key: string]: string} = {};
    
    // Validate new password
    const passwordError = validatePassword(newPassword);
    if (passwordError) {
      errors.newPassword = passwordError;
    }

    // Check if passwords match
    if (newPassword !== confirmPassword) {
      errors.confirmPassword = 'Passwords do not match';
    }

    if (Object.keys(errors).length > 0) {
      setValidationErrors(errors);
      return;
    }

    setLoading(true);

    try {
      // Call API to update user with new password
      // Note: This uses the regular user update endpoint with password field
      await api.put(`/api/users/${staff._id}`, {
        password: newPassword
      });

      setSuccess(true);
      
      // Close modal after short delay to show success
      setTimeout(() => {
        onUpdateAction();
        onCloseAction();
      }, 1500);
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to reset password');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen || !staff) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center">
            <div className="bg-yellow-100 p-2 rounded-full mr-3">
              <KeyRound size={20} className="text-yellow-600" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">
                Reset Password
              </h2>
              <p className="text-sm text-gray-500">
                {staff.first_name} {staff.last_name}
              </p>
            </div>
          </div>
          <button
            onClick={onCloseAction}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X size={20} className="text-gray-500" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="p-6">
          {/* Warning Message */}
          <div className="bg-amber-50 border border-amber-200 rounded-md p-4 mb-6">
            <div className="flex">
              <AlertCircle className="h-5 w-5 text-amber-400 mt-0.5" />
              <div className="ml-3">
                <h3 className="text-sm font-medium text-amber-800">
                  Password Reset Warning
                </h3>
                <p className="text-sm text-amber-700 mt-1">
                  You are about to reset the password for <strong>{staff.email}</strong>. 
                  This action cannot be undone. The user will need to use the new password to log in.
                </p>
              </div>
            </div>
          </div>

          {/* Error Message */}
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-md p-4 mb-6">
              <p className="text-red-600 text-sm">{error}</p>
            </div>
          )}

          {/* Success Message */}
          {success && (
            <div className="bg-green-50 border border-green-200 rounded-md p-4 mb-6">
              <p className="text-green-600 text-sm font-medium">
                Password successfully reset!
              </p>
            </div>
          )}

          {/* Password Fields */}
          {!success && (
            <>
              <div className="space-y-4">
                <div>
                  <label htmlFor="newPassword" className="block text-sm font-medium text-gray-700 mb-2">
                    New Password
                  </label>
                  <input
                    type="password"
                    id="newPassword"
                    value={newPassword}
                    onChange={(e) => handlePasswordChange(e.target.value)}
                    className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:border-transparent ${
                      validationErrors.newPassword 
                        ? 'border-red-300 focus:ring-red-500' 
                        : 'border-gray-300 focus:ring-blue-500'
                    }`}
                    placeholder="Enter new password"
                    required
                  />
                  {validationErrors.newPassword && (
                    <p className="text-red-500 text-xs mt-1">{validationErrors.newPassword}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-2">
                    Confirm Password
                  </label>
                  <input
                    type="password"
                    id="confirmPassword"
                    value={confirmPassword}
                    onChange={(e) => handleConfirmPasswordChange(e.target.value)}
                    className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:border-transparent ${
                      validationErrors.confirmPassword 
                        ? 'border-red-300 focus:ring-red-500' 
                        : 'border-gray-300 focus:ring-blue-500'
                    }`}
                    placeholder="Confirm new password"
                    required
                  />
                  {validationErrors.confirmPassword && (
                    <p className="text-red-500 text-xs mt-1">{validationErrors.confirmPassword}</p>
                  )}
                </div>
              </div>

              {/* Password Info */}
              <div className="mt-4 text-xs text-gray-600 bg-gray-50 p-3 rounded">
                <p className="font-medium mb-1">Password Info:</p>
                <p>Enter any password you want. No special requirements.</p>
              </div>
            </>
          )}

          {/* Actions */}
          <div className="flex justify-end space-x-3 mt-6">
            <button
              type="button"
              onClick={onCloseAction}
              className="px-4 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md transition-colors"
              disabled={loading}
            >
              Cancel
            </button>
            {!success && (
              <button
                type="submit"
                disabled={loading || !newPassword || !confirmPassword}
                className="px-4 py-2 bg-yellow-600 text-white rounded-md hover:bg-yellow-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center"
              >
                <KeyRound size={16} className="mr-2" />
                {loading ? 'Resetting...' : 'Reset Password'}
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
}