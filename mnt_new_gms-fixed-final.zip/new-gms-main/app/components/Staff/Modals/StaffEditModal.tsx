'use client';

import React, { useState, useEffect } from 'react';
import { X, User, Shield, Save, CheckCircle2, XCircle, ChevronDown, ChevronRight } from 'lucide-react';
import { useAuth } from '@/app/context/AuthContext';
import api from '@/services/api';

// Types
interface StaffMember {
  _id: string;
  first_name: string;
  last_name: string;
  email: string;
  phone?: string;
  speciality?: string;
  role: string;
  role_id: string;
  is_active?: boolean;
  permissions?: Permission[];
}

interface Permission {
  permission_id: number;
  permission_name: string;
  permission_description?: string;
  category?: string;
  granted: boolean;
}

interface AllPermissions {
  [category: string]: {
    id: string;
    name: string;
    description: string;
  }[];
}

interface GrantedPermissions {
  permission_id: string;
  permission_name: string;
  description: string;
}

interface StaffEditModalProps {
  staff: StaffMember | null;
  isOpen: boolean;
  onCloseAction: () => void;
  onUpdateAction: () => void;
}

interface PersonalFormData {
  first_name: string;
  last_name: string;
  phone: string;
  speciality: string;
}

export default function StaffEditModal({ 
  staff, 
  isOpen, 
  onCloseAction, 
  onUpdateAction 
}: StaffEditModalProps) {
  const { user, logout } = useAuth();
  const [activeTab, setActiveTab] = useState<'personal' | 'permissions'>('personal');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [validationErrors, setValidationErrors] = useState<{[key: string]: string}>({});
  
  // Personal Info Form State
  const [personalForm, setPersonalForm] = useState<PersonalFormData>({
    first_name: '',
    last_name: '',
    phone: '',
    speciality: ''
  });

  // Permissions State
  const [allPermissions, setAllPermissions] = useState<AllPermissions>({});
  const [grantedPermissions, setGrantedPermissions] = useState<GrantedPermissions[]>([]);
  const [permissionChanges, setPermissionChanges] = useState<{[key: string]: boolean}>({});
  const [expandedCategories, setExpandedCategories] = useState<{[key: string]: boolean}>({});
  const [permissionsLoading, setPermissionsLoading] = useState(false);

  // Check if user can edit permissions
  const canEditPermissions = () => {
    if (!user || !staff) return false;
    
    // No one can edit Admin permissions (including their own)
    if (staff.role === 'Admin') return false;
    
    // Admins cannot edit their own permissions
    if (user.role_name === 'Admin' && user.id === staff._id) return false;
    
    const isAdmin = user.role_name === 'Admin';
    const hasManagePermissions = user.permissions?.some(p => 
      p.permission_name === 'manage_permissions' && p.granted
    );
    
    return isAdmin || hasManagePermissions;
  };

  // Check if user can edit personal info
  const canEditPersonalInfo = () => {
    if (!user || !staff) return false;
    
    const isAdmin = user.role_name === 'Admin';
    const hasUpdateUser = user.permissions?.some(p => 
      p.permission_name === 'update_user' && p.granted
    );
    return isAdmin || hasUpdateUser;
  };

  // Check if staff member is a technician (only techs have specialities)
  const isTechnician = () => {
    if (!staff) return false;
    return staff.role?.toLowerCase().includes('technician') || staff.role?.toLowerCase().includes('tech');
  };

  // Check if staff member is supervisor or admin (should have "Other" specialty)
  const isSupervisorOrAdmin = () => {
    if (!staff) return false;
    return staff.role?.toLowerCase().includes('supervisor') || staff.role?.toLowerCase().includes('admin');
  };

  // Initialize form data
  useEffect(() => {
    if (staff) {
      // Determine specialty based on role
      let defaultSpeciality = staff.speciality || '';
      
      // Auto-set "Other" for supervisors and admins
      if (staff.role?.toLowerCase().includes('supervisor') || staff.role?.toLowerCase().includes('admin')) {
        defaultSpeciality = 'Other';
      }
      
      setPersonalForm({
        first_name: staff.first_name || '',
        last_name: staff.last_name || '',
        phone: staff.phone || '',
        speciality: defaultSpeciality
      });
      
      // Reset permission changes and validation errors
      setPermissionChanges({});
      setExpandedCategories({});
      setValidationErrors({});
      
      // If editing an Admin user, ensure personal tab is selected
      if (staff.role === 'Admin') {
        setActiveTab('personal');
      }
    }
  }, [staff]);

  // Load permissions data when permissions tab is selected
  useEffect(() => {
    if (activeTab === 'permissions' && canEditPermissions() && staff && staff.role !== 'Admin') {
      loadPermissionsData();
    }
  }, [activeTab, staff]);

  const loadPermissionsData = async () => {
    if (!staff) return;
    
    setPermissionsLoading(true);
    try {
      // Load all available permissions
      const allPermsResponse = await api.get('/api/users/permissions/all');
      
      // Load currently granted permissions
      const grantedPermsResponse = await api.get(`/api/users/${staff._id}/granted-permissions`);
      
      setAllPermissions((allPermsResponse as any).permissions_by_category || {});
      setGrantedPermissions((grantedPermsResponse as any).granted_permissions || []);
      
    } catch (err: any) {
      setError('Failed to load permissions data');
      console.error('Error loading permissions:', err);
    } finally {
      setPermissionsLoading(false);
    }
  };

  // Handle personal info form changes
  const handlePersonalFormChange = (field: keyof PersonalFormData, value: string) => {
    // Clear any existing validation error for this field
    setValidationErrors(prev => {
      const newErrors = { ...prev };
      delete newErrors[field];
      return newErrors;
    });

    // Validation for phone field
    if (field === 'phone') {
      // Remove any non-numeric characters except + and spaces for validation
      const cleanValue = value.replace(/[^\d+\s-()]/g, '');
      
      // Limit to 14 characters including the +
      if (cleanValue.length > 14) {
        setValidationErrors(prev => ({
          ...prev,
          [field]: 'Phone number cannot exceed 14 characters including +'
        }));
        return; // Don't update if exceeds limit
      }
      
      // Validate phone format
      if (cleanValue && !/^[+]?[\d\s-()]{1,14}$/.test(cleanValue)) {
        setValidationErrors(prev => ({
          ...prev,
          [field]: 'Please enter a valid phone number'
        }));
      }
      
      setPersonalForm(prev => ({
        ...prev,
        [field]: cleanValue
      }));
      return;
    }

    // Validation for name fields
    if (field === 'first_name' || field === 'last_name') {
      // Only allow letters, spaces, hyphens, and apostrophes
      const nameValue = value.replace(/[^a-zA-Z\s'-]/g, '');
      
      // Limit to 50 characters
      if (nameValue.length > 50) {
        setValidationErrors(prev => ({
          ...prev,
          [field]: 'Name cannot exceed 50 characters'
        }));
        return;
      }
      
      // Check minimum length
      if (nameValue.trim().length === 0 && value.length > 0) {
        setValidationErrors(prev => ({
          ...prev,
          [field]: 'Name must contain at least one letter'
        }));
      }
      
      setPersonalForm(prev => ({
        ...prev,
        [field]: nameValue
      }));
      return;
    }

    // Default case for other fields
    setPersonalForm(prev => ({
      ...prev,
      [field]: value
    }));
  };

  // Handle personal info form submit
  const handlePersonalInfoSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!staff || !canEditPersonalInfo()) return;

    // Validate form before submission
    const errors: {[key: string]: string} = {};
    
    // Required field validation
    if (!personalForm.first_name.trim()) {
      errors.first_name = 'First name is required';
    }
    if (!personalForm.last_name.trim()) {
      errors.last_name = 'Last name is required';
    }
    
    // Phone validation
    if (personalForm.phone && personalForm.phone.length > 14) {
      errors.phone = 'Phone number cannot exceed 14 characters including +';
    }
    
    // If there are validation errors, don't submit
    if (Object.keys(errors).length > 0) {
      setValidationErrors(errors);
      return;
    }

    // Prepare form data with auto-set specialty for supervisors and admins
    const formDataToSubmit = { ...personalForm };
    
    // Auto-set "Other" for supervisors and admins
    if (isSupervisorOrAdmin()) {
      formDataToSubmit.speciality = 'Other';
    }

    setLoading(true);
    setError(null);
    setValidationErrors({});

    try {
      await api.put(`/api/users/${staff._id}`, formDataToSubmit);
      onUpdateAction();
      onCloseAction();
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to update personal information');
    } finally {
      setLoading(false);
    }
  };

  // Toggle permission
  const togglePermission = (permissionName: string) => {
    setPermissionChanges(prev => {
      const currentGranted = grantedPermissions.some(p => p.permission_name === permissionName);
      const currentChange = prev[permissionName];
      
      // If there's already a change, toggle it back, otherwise set the opposite of current granted status
      if (currentChange !== undefined) {
        const newChanges = { ...prev };
        delete newChanges[permissionName];
        return newChanges;
      } else {
        return {
          ...prev,
          [permissionName]: !currentGranted
        };
      }
    });
  };

  // Toggle category expansion
  const toggleCategory = (categoryKey: string) => {
    setExpandedCategories(prev => ({
      ...prev,
      [categoryKey]: !prev[categoryKey]
    }));
  };

  // Toggle all permissions in a category
  const toggleAllInCategory = (categoryPerms: any[], granted: boolean) => {
    const changes = { ...permissionChanges };
    
    categoryPerms.forEach(perm => {
      const currentGranted = grantedPermissions.some(p => p.permission_name === perm.name);
      if (currentGranted !== granted) {
        changes[perm.name] = granted;
      } else {
        delete changes[perm.name];
      }
    });
    
    setPermissionChanges(changes);
  };

  // Handle permissions submit
  const handlePermissionsSubmit = async () => {
    if (!staff || Object.keys(permissionChanges).length === 0) return;

    setLoading(true);
    setError(null);

    try {
      const permissions = Object.entries(permissionChanges).map(([permission_name, granted]) => ({
        permission_name,
        granted
      }));

      await api.put(`/api/users/${staff._id}/permissions`, { permissions });
      
      // Check if user is editing their own permissions
      const isEditingOwnPermissions = user && user.id === staff._id;
      
      if (isEditingOwnPermissions) {
        // Show a brief success message before logging out
        onUpdateAction();
        onCloseAction();
        
        // Log out the user after a short delay to show success feedback
        setTimeout(() => {
          logout();
        }, 1000);
      } else {
        // Reload granted permissions for other users
        await loadPermissionsData();
        setPermissionChanges({});
        onUpdateAction();
      }
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to update permissions');
    } finally {
      setLoading(false);
    }
  };

  // Get permission status (current + changes)
  const getPermissionStatus = (permissionName: string) => {
    const currentGranted = grantedPermissions.some(p => p.permission_name === permissionName);
    const hasChange = permissionChanges[permissionName] !== undefined;
    
    if (hasChange) {
      return permissionChanges[permissionName];
    }
    
    return currentGranted;
  };

  if (!isOpen || !staff) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center">
            <div className="bg-blue-100 p-2 rounded-full mr-3">
              <User size={20} className="text-blue-600" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">
                Edit Staff Member
              </h2>
              <p className="text-sm text-gray-500">
                {staff.first_name} {staff.last_name} - {staff.role}
              </p>
            </div>
          </div>
          <button
            onClick={onCloseAction}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X size={20} className="text-gray-500" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-200">
          <button
            onClick={() => setActiveTab('personal')}
            className={`px-6 py-3 font-medium text-sm border-b-2 transition-colors ${
              activeTab === 'personal' 
                ? 'border-blue-500 text-blue-600 bg-blue-50' 
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:bg-gray-50'
            }`}
          >
            <User size={16} className="inline mr-2" />
            Personal Information
          </button>
          
          {/* Only show permissions tab if user can edit permissions and target is not admin */}
          {canEditPermissions() && staff.role !== 'Admin' && (
            <button
              onClick={() => setActiveTab('permissions')}
              className={`px-6 py-3 font-medium text-sm border-b-2 transition-colors ${
                activeTab === 'permissions' 
                  ? 'border-blue-500 text-blue-600 bg-blue-50' 
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:bg-gray-50'
              }`}
            >
              <Shield size={16} className="inline mr-2" />
              Permissions
            </button>
          )}
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(90vh-180px)]">
          {/* Error Message */}
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-md p-4 mb-6">
              <p className="text-red-600 text-sm">{error}</p>
            </div>
          )}

          {/* Personal Information Tab */}
          {activeTab === 'personal' && (
            <form onSubmit={handlePersonalInfoSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="first_name" className="block text-sm font-medium text-gray-700 mb-2">
                    First Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    id="first_name"
                    value={personalForm.first_name}
                    onChange={(e) => handlePersonalFormChange('first_name', e.target.value)}
                    disabled={!canEditPersonalInfo()}
                    className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:border-transparent disabled:bg-gray-100 disabled:cursor-not-allowed ${
                      validationErrors.first_name 
                        ? 'border-red-300 focus:ring-red-500' 
                        : 'border-gray-300 focus:ring-blue-500'
                    }`}
                    required
                    maxLength={50}
                  />
                  {validationErrors.first_name && (
                    <p className="text-red-500 text-xs mt-1">{validationErrors.first_name}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="last_name" className="block text-sm font-medium text-gray-700 mb-2">
                    Last Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    id="last_name"
                    value={personalForm.last_name}
                    onChange={(e) => handlePersonalFormChange('last_name', e.target.value)}
                    disabled={!canEditPersonalInfo()}
                    className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:border-transparent disabled:bg-gray-100 disabled:cursor-not-allowed ${
                      validationErrors.last_name 
                        ? 'border-red-300 focus:ring-red-500' 
                        : 'border-gray-300 focus:ring-blue-500'
                    }`}
                    required
                    maxLength={50}
                  />
                  {validationErrors.last_name && (
                    <p className="text-red-500 text-xs mt-1">{validationErrors.last_name}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">
                    Phone
                    <span className="text-xs text-gray-500 ml-1">(Max 14 characters)</span>
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    value={personalForm.phone}
                    onChange={(e) => handlePersonalFormChange('phone', e.target.value)}
                    disabled={!canEditPersonalInfo()}
                    className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:border-transparent disabled:bg-gray-100 disabled:cursor-not-allowed ${
                      validationErrors.phone 
                        ? 'border-red-300 focus:ring-red-500' 
                        : 'border-gray-300 focus:ring-blue-500'
                    }`}
                    placeholder="+1234567890"
                    maxLength={14}
                  />
                  {validationErrors.phone && (
                    <p className="text-red-500 text-xs mt-1">{validationErrors.phone}</p>
                  )}
                  <p className="text-xs text-gray-500 mt-1">
                    {personalForm.phone.length}/14 characters
                  </p>
                </div>

                <div>
                  <label htmlFor="speciality" className="block text-sm font-medium text-gray-700 mb-2">
                    Speciality
                    {!isTechnician() && !isSupervisorOrAdmin() && (
                      <span className="text-xs text-gray-500 ml-1">(Technicians only)</span>
                    )}
                    {isSupervisorOrAdmin() && (
                      <span className="text-xs text-gray-500 ml-1">(Auto-set to "Other")</span>
                    )}
                  </label>
                  <div className="relative">
                    {isSupervisorOrAdmin() ? (
                      // Read-only input for supervisors and admins
                      <input
                        type="text"
                        id="speciality"
                        value="Other"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100 text-gray-600 cursor-not-allowed"
                        disabled
                        readOnly
                      />
                    ) : (
                      // Dropdown for technicians and other roles
                      <select
                        id="speciality"
                        value={personalForm.speciality}
                        onChange={(e) => handlePersonalFormChange('speciality', e.target.value)}
                        disabled={!canEditPersonalInfo() || !isTechnician()}
                        className={`
                          w-full px-3 py-2 pr-10 border border-gray-300 rounded-md 
                          bg-white appearance-none cursor-pointer
                          focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500
                          hover:border-gray-400 transition-colors duration-200
                          disabled:bg-gray-50 disabled:text-gray-500 disabled:cursor-not-allowed 
                          disabled:border-gray-200 disabled:hover:border-gray-200
                          text-gray-900 placeholder-gray-500
                          ${!isTechnician() ? 'text-gray-400' : ''}
                        `}
                      >
                        <option value="" className="text-gray-500">
                          {isTechnician() ? "Select a speciality..." : "Not applicable for this role"}
                        </option>
                        {isTechnician() && (
                          <>
                            <option value="PDR" className="text-gray-900">PDR</option>
                            <option value="Fix/Remove" className="text-gray-900">Fix/Remove</option>
                            <option value="Paint" className="text-gray-900">Paint</option>
                            <option value="Body Work" className="text-gray-900">Body Work</option>
                            <option value="Mechanical" className="text-gray-900">Mechanical</option>
                            <option value="Electrical" className="text-gray-900">Electrical</option>
                            <option value="General" className="text-gray-900">General</option>
                            <option value="PDR & Paint Supervision" className="text-gray-900">PDR & Paint Supervision</option>
                            <option value="System Administration" className="text-gray-900">System Administration</option>
                            <option value="Supervision" className="text-gray-900">Supervision</option>
                            <option value="Management" className="text-gray-900">Management</option>
                          </>
                        )}
                      </select>
                    )}
                    {/* Custom dropdown arrow - only show for select dropdown */}
                    {!isSupervisorOrAdmin() && (
                      <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                        <ChevronDown 
                          size={16} 
                          className={`
                            transition-colors duration-200
                            ${!canEditPersonalInfo() || !isTechnician() 
                              ? 'text-gray-300' 
                              : 'text-gray-500'
                            }
                          `} 
                        />
                      </div>
                    )}
                  </div>
                  {isSupervisorOrAdmin() && (
                    <p className="text-xs text-gray-500 mt-1">
                      Specialty is automatically set to "Other" for {staff?.role?.toLowerCase()}s
                    </p>
                  )}
                </div>
              </div>

              {/* Personal Info Actions */}
              {canEditPersonalInfo() && (
                <div className="flex justify-end space-x-3 pt-4 border-t border-gray-200">
                  <button
                    type="button"
                    onClick={onCloseAction}
                    className="px-4 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={loading}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center"
                  >
                    <Save size={16} className="mr-2" />
                    {loading ? 'Saving...' : 'Save Changes'}
                  </button>
                </div>
              )}
            </form>
          )}

          {/* Permissions Tab */}
          {activeTab === 'permissions' && (
            <div>
              {!canEditPermissions() ? (
                <div className="text-center py-12">
                  <Shield size={48} className="mx-auto text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">Permission Required</h3>
                  <p className="text-gray-500">
                    You need the "manage_permissions" permission to edit user permissions.
                  </p>
                </div>
              ) : permissionsLoading ? (
                <div className="text-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
                  <p className="text-gray-600">Loading permissions...</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Permission Summary */}
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium text-blue-900">Permission Summary</h4>
                        <p className="text-sm text-blue-700 mt-1">
                          {grantedPermissions.length} permissions currently granted
                          {Object.keys(permissionChanges).length > 0 && (
                            <span className="ml-2 text-blue-600">
                              ({Object.keys(permissionChanges).length} pending changes)
                            </span>
                          )}
                        </p>
                      </div>
                      <div className="bg-blue-100 p-2 rounded-full">
                        <Shield size={24} />
                      </div>
                    </div>
                  </div>

                  {/* Permissions by Category */}
                  <div className="space-y-4">
                    {Object.entries(allPermissions).map(([categoryKey, categoryPerms]) => {
                      const isExpanded = expandedCategories[categoryKey];
                      const categoryName = categoryKey.replace(/_/g, ' ').toLowerCase();
                      const grantedCount = categoryPerms.filter(perm => 
                        getPermissionStatus(perm.name)
                      ).length;
                      const totalCount = categoryPerms.length;

                      return (
                        <div key={categoryKey} className="border border-gray-200 rounded-lg overflow-hidden">
                          <div className="bg-gray-50 p-4">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-3">
                                <button
                                  type="button"
                                  onClick={() => toggleCategory(categoryKey)}
                                  className="p-1 hover:bg-gray-200 rounded transition-colors"
                                >
                                  {isExpanded ? (
                                    <ChevronDown size={16} className="text-gray-600" />
                                  ) : (
                                    <ChevronRight size={16} className="text-gray-600" />
                                  )}
                                </button>
                                <div>
                                  <h3 className="font-medium text-gray-900 capitalize">
                                    {categoryName}
                                  </h3>
                                  <span className="text-sm text-gray-500">
                                    ({grantedCount}/{totalCount} granted)
                                  </span>
                                </div>
                              </div>
                              <div className="flex space-x-2">
                                <button
                                  type="button"
                                  onClick={() => toggleAllInCategory(categoryPerms, true)}
                                  className="px-3 py-1 text-xs bg-green-100 text-green-700 rounded hover:bg-green-200 transition-colors"
                                >
                                  Grant All
                                </button>
                                <button
                                  type="button"
                                  onClick={() => toggleAllInCategory(categoryPerms, false)}
                                  className="px-3 py-1 text-xs bg-red-100 text-red-700 rounded hover:bg-red-200 transition-colors"
                                >
                                  Revoke All
                                </button>
                              </div>
                            </div>
                          </div>

                          {isExpanded && (
                            <div className="p-4 space-y-3">
                              {categoryPerms.map((perm) => {
                                const isGranted = getPermissionStatus(perm.name);
                                const hasChange = permissionChanges[perm.name] !== undefined;

                                return (
                                  <div key={perm.name}>
                                    <div className="flex items-center space-x-3">
                                      <div className={`h-2 w-2 rounded-full ${isGranted ? 'bg-green-500' : 'bg-gray-300'}`}></div>
                                      <div className="flex-1">
                                        <h4 className={`font-medium ${isGranted ? 'text-green-900' : 'text-gray-900'}`}>
                                          {perm.name.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                                        </h4>
                                        {hasChange && (
                                          <span className="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded ml-2">
                                            Changed
                                          </span>
                                        )}
                                      </div>
                                      <button
                                        type="button"
                                        onClick={() => togglePermission(perm.name)}
                                        className={`p-2 rounded-md transition-colors ${
                                          isGranted
                                            ? 'bg-green-100 text-green-700 hover:bg-green-200'
                                            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                                        }`}
                                      >
                                        {isGranted ? (
                                          <CheckCircle2 size={16} />
                                        ) : (
                                          <XCircle size={16} />
                                        )}
                                      </button>
                                    </div>
                                    <p className={`text-sm mt-1 ml-5 ${isGranted ? 'text-green-700' : 'text-gray-600'}`}>
                                      {perm.description}
                                    </p>
                                  </div>
                                );
                              })}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>

                  {/* Permissions Actions */}
                  {Object.keys(permissionChanges).length > 0 && (
                    <div className="flex justify-end space-x-3 pt-4 border-t border-gray-200">
                      <button
                        type="button"
                        onClick={() => setPermissionChanges({})}
                        className="px-4 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md transition-colors"
                      >
                        Reset Changes
                      </button>
                      <button
                        type="button"
                        onClick={handlePermissionsSubmit}
                        disabled={loading}
                        className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center"
                      >
                        <Save size={16} className="mr-2" />
                        {loading ? 'Saving...' : `Save Changes (${Object.keys(permissionChanges).length})`}
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}