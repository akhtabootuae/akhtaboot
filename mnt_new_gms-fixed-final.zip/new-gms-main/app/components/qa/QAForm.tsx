'use client';

import React, { useState } from 'react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import api from '../../../services/api';

interface QAFormProps {
  workOrderId: string;
  workOrderNumber: string;
  onSuccess: (qaRecord: any) => void;
  onCancel: () => void;
}

interface QAFormData {
  WO_ID: string;
  person_name: string;
  passed: boolean;
  description: string;
  images: File[];
}


// Function to send QA failure notification
const sendQAFailureNotification = async (workOrderId: string, inspectorName: string, description: string) => {
  try {
    console.log('Sending QA failure notification for work order:', workOrderId);
    
    // Simple notification data - matching the working test format
    const notificationData = {
      type: "general",
      title: "Quality Assurance Failed",
      message: `Work Order ${workOrderId} has FAILED quality assurance inspection by ${inspectorName}. Immediate attention required.`,
      recipientType: "all",
      priority: "urgent"
    };

    console.log('Sending QA failure notification with data:', notificationData);
    const response = await api.post('/api/notifications', notificationData);
    console.log('QA failure notification response:', response);
    
    if (response.success || response.message === "Notification created") {
      console.log('QA failure notification sent successfully:', response.notificationId || response);
    } else {
      console.error('Failed to send QA failure notification:', response);
    }
    
  } catch (error) {
    console.error('Error sending QA failure notification:', error);
    // Don't fail the QA submission if notification fails
  }
};

// Function to send QA success notification
const sendQASuccessNotification = async (workOrderId: string, inspectorName: string) => {
  try {
    console.log('Sending QA success notification for work order:', workOrderId);
    
    // Simple notification data - matching the working test format
    const notificationData = {
      type: "general",
      title: "Quality Assurance Passed",
      message: `Work Order ${workOrderId} has PASSED quality assurance inspection by ${inspectorName}. Work order is now complete.`,
      recipientType: "all",
      priority: "medium"
    };

    console.log('Sending QA success notification with data:', notificationData);
    const response = await api.post('/api/notifications', notificationData);
    console.log('QA success notification response:', response);
    
    if (response.success || response.message === "Notification created") {
      console.log('QA success notification sent successfully:', response.notificationId || response);
    } else {
      console.error('Failed to send QA success notification:', response);
    }
    
  } catch (error) {
    console.error('Error sending QA success notification:', error);
    // Don't fail the QA submission if notification fails
  }
};

export const QAForm: React.FC<QAFormProps> = ({
  workOrderId,
  workOrderNumber,
  onSuccess,
  onCancel
}) => {
  const [formData, setFormData] = useState<QAFormData>({
    WO_ID: workOrderNumber,
    person_name: '',
    passed: true,
    description: '',
    images: []
  });
  
  const [uploading, setUploading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Handle input changes
  const handleInputChange = (field: keyof QAFormData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  // Handle image selection
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    
    // Validate file count
    if (files.length < 3 || files.length > 5) {
      setErrors(prev => ({ ...prev, images: 'Please select 3-5 images' }));
      return;
    }
    
    // Validate file types and sizes
    const validFiles: File[] = [];
    const invalidFiles: string[] = [];
    
    files.forEach(file => {
      const isImage = file.type.startsWith('image/');
      const isValidSize = file.size <= 10 * 1024 * 1024; // 10MB
      const isValidType = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'].includes(file.type);
      
      if (!isImage || !isValidType) {
        invalidFiles.push(`${file.name}: Invalid file type`);
      } else if (!isValidSize) {
        invalidFiles.push(`${file.name}: File too large (max 10MB)`);
      } else {
        validFiles.push(file);
      }
    });
    
    if (invalidFiles.length > 0) {
      setErrors(prev => ({ ...prev, images: invalidFiles.join(', ') }));
      return;
    }
    
    setFormData(prev => ({ ...prev, images: validFiles }));
    setErrors(prev => ({ ...prev, images: '' }));
  };

  // Validate form
  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.person_name.trim() || formData.person_name.length < 2 || formData.person_name.length > 100) {
      newErrors.person_name = 'Inspector name must be 2-100 characters';
    }
    
    if (!formData.description.trim() || formData.description.length < 10 || formData.description.length > 1000) {
      newErrors.description = 'Description must be 10-1000 characters';
    }
    
    if (formData.images.length < 3 || formData.images.length > 5) {
      newErrors.images = 'Please select 3-5 images';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    console.log('Form submission started');
    console.log('Current form data:', formData);
    
    if (!validateForm()) {
      console.log('Form validation failed');
      return;
    }
    
    console.log('Form validation passed, starting submission...');
    setUploading(true);
    setIsSubmitting(true);
    
    try {
      // Create FormData for multipart upload
      const submitData = new FormData();
      submitData.append('WO_ID', formData.WO_ID);
      submitData.append('person_name', formData.person_name);
      submitData.append('passed', formData.passed.toString());
      submitData.append('description', formData.description);
      
      // Append all images
      formData.images.forEach(image => {
        submitData.append('images', image);
      });
      
      console.log('Submitting QA form for work order:', formData.WO_ID);
      console.log('FormData contents:');
      for (const [key, value] of submitData.entries()) {
        console.log(key, value);
      }
      
      // Submit to QA API
      const response = await api.post('/api/workorder-qa', submitData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      
      if (response.success) {
        console.log('QA submission successful, preparing to send notifications...');
        console.log('QA Result:', formData.passed ? 'PASSED' : 'FAILED');
        console.log('Form data:', {
          WO_ID: formData.WO_ID,
          person_name: formData.person_name,
          passed: formData.passed,
          description: formData.description.substring(0, 100) + '...'
        });
        
        try {
          // Send notifications based on QA result
          if (!formData.passed) {
            // QA Failed - Send urgent notification to admins and supervisors
            console.log('Sending failure notifications...');
            await sendQAFailureNotification(formData.WO_ID, formData.person_name, formData.description);
          } else {
            // QA Passed - Send success notification
            console.log('Sending success notifications...');
            await sendQASuccessNotification(formData.WO_ID, formData.person_name);
          }
          console.log('Notifications sent successfully');
        } catch (notificationError) {
          console.error('Error sending notifications:', notificationError);
          // Don't fail the QA submission if notifications fail
        }
        
        onSuccess(response.data);
      } else {
        console.error('QA submission failed:', response);
        setErrors({ submit: response.error || 'Failed to submit QA record' });
      }
    } catch (error: any) {
      console.error('Error submitting QA:', error);
      setErrors({ submit: error.response?.data?.error || 'Failed to submit QA record' });
    } finally {
      setUploading(false);
      setIsSubmitting(false);
    }
  };

  // Format file size
  const formatFileSize = (bytes: number): string => {
    return (bytes / 1024 / 1024).toFixed(2) + ' MB';
  };

  return (
    <div className="max-w-2xl mx-auto">
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Work Order Info */}
        <div className="bg-gray-50 p-4 rounded-lg">
          <h3 className="font-medium text-gray-900 mb-2">Work Order Information</h3>
          <p className="text-sm text-gray-600">Work Order: {workOrderNumber}</p>
        </div>

        {/* Inspector Name */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Inspector Name *
          </label>
          <Input
            type="text"
            value={formData.person_name}
            onChange={(e) => handleInputChange('person_name', e.target.value)}
            placeholder="Enter inspector name"
            className={errors.person_name ? 'border-red-300' : ''}
            minLength={2}
            maxLength={100}
            required
          />
          {errors.person_name && (
            <p className="mt-1 text-sm text-red-600">{errors.person_name}</p>
          )}
        </div>

        {/* QA Result */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            QA Result *
          </label>
          <div className="flex space-x-4">
            <label className="flex items-center">
              <input
                type="radio"
                name="passed"
                checked={formData.passed === true}
                onChange={() => handleInputChange('passed', true)}
                className="mr-2"
              />
              <span className="text-green-600 font-medium">Pass</span>
            </label>
            <label className="flex items-center">
              <input
                type="radio"
                name="passed"
                checked={formData.passed === false}
                onChange={() => handleInputChange('passed', false)}
                className="mr-2"
              />
              <span className="text-red-600 font-medium">Fail</span>
            </label>
          </div>
        </div>

        {/* Images */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            QA Images (3-5 required) *
          </label>
          <Input
            type="file"
            multiple
            accept="image/jpeg,image/jpg,image/png,image/gif,image/webp"
            onChange={handleImageChange}
            className={errors.images ? 'border-red-300' : ''}
            required
          />
          <p className="mt-1 text-xs text-gray-500">
            Select 3-5 images (JPEG, PNG, GIF, WebP). Max 10MB each.
          </p>
          {errors.images && (
            <p className="mt-1 text-sm text-red-600">{errors.images}</p>
          )}
          
          {/* Selected files preview */}
          {formData.images.length > 0 && (
            <div className="mt-3">
              <p className="text-sm font-medium text-gray-700 mb-2">
                Selected Images ({formData.images.length})
              </p>
              <div className="grid grid-cols-2 gap-2">
                {formData.images.map((file, index) => (
                  <div key={index} className="bg-gray-50 p-2 rounded text-xs">
                    <p className="font-medium truncate">{file.name}</p>
                    <p className="text-gray-500">{formatFileSize(file.size)}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Description */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            QA Description *
          </label>
          <textarea
            value={formData.description}
            onChange={(e) => handleInputChange('description', e.target.value)}
            placeholder="Provide detailed QA notes and observations..."
            className={`w-full p-3 border rounded-md resize-vertical ${
              errors.description ? 'border-red-300' : 'border-gray-300'
            }`}
            rows={4}
            minLength={10}
            maxLength={1000}
            required
          />
          <div className="flex justify-between mt-1">
            {errors.description && (
              <p className="text-sm text-red-600">{errors.description}</p>
            )}
            <p className="text-xs text-gray-500 ml-auto">
              {formData.description.length}/1000 characters
            </p>
          </div>
        </div>

        {/* Submit Error */}
        {errors.submit && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
            {errors.submit}
          </div>
        )}


        {/* Action Buttons */}
        <div className="flex justify-between space-x-3 pt-4">
          <Button
            type="button"
            variant="outline"
            onClick={onCancel}
            disabled={uploading}
            className="flex-1"
          >
            Cancel
          </Button>
          <Button
            type="submit"
            disabled={uploading}
            className={`flex-1 ${
              formData.passed 
                ? 'bg-green-600 hover:bg-green-700' 
                : 'bg-red-600 hover:bg-red-700'
            }`}
          >
            {uploading ? (
              <div className="flex items-center">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                {isSubmitting ? 'Sending notifications...' : 'Uploading...'}
              </div>
            ) : (
              `Submit QA ${formData.passed ? '(Pass)' : '(Fail)'}`
            )}
          </Button>
        </div>
      </form>
    </div>
  );
};