'use client';

import React, { useState, useEffect } from 'react';
import { Button } from '../ui/button';
import api from '../../../services/api';
import { useRouter } from 'next/navigation';

interface QARecord {
  _id: string;
  WO_ID: string;
  work_order_object_id?: string; // Optional ObjectId for direct navigation
  person_name: string;
  passed: boolean;
  images: Array<{
    s3_key: string;
    original_name: string;
    size: number;
    mime_type: string;
    upload_date: string;
    signed_url?: string;
  }>;
  description: string;
  created_at: string;
  updated_at: string;
}

interface QARecordsListProps {
  workOrderId?: string;
  limit?: number;
  showWorkOrderColumn?: boolean;
}

export const QARecordsList: React.FC<QARecordsListProps> = ({
  workOrderId,
  limit = 10,
  showWorkOrderColumn = true
}) => {
  const router = useRouter();
  const [qaRecords, setQaRecords] = useState<QARecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());
  const [showImagesForRecord, setShowImagesForRecord] = useState<Set<string>>(new Set());

  // Fetch QA records
  const fetchQARecords = async () => {
    try {
      setLoading(true);
      setError('');
      
      let url = '/api/workorder-qa';
      const params: any = {};
      
      if (workOrderId) {
        url = `/api/workorder-qa/work-order/${workOrderId}`;
      } else {
        params.limit = limit.toString();
        params.page = '1';
      }
      
      console.log('Fetching QA records from:', url, 'with params:', params);
      const response = await api.get(url, { params });
      
      if (response.success) {
        setQaRecords(response.data);
      } else {
        setError('Failed to fetch QA records');
      }
    } catch (err) {
      console.error('Error fetching QA records:', err);
      setError('Failed to load QA records');
    } finally {
      setLoading(false);
    }
  };

  // Load QA records on mount and when workOrderId changes
  useEffect(() => {
    fetchQARecords();
  }, [workOrderId, limit]);

  // Toggle row expansion
  const toggleRowExpansion = (recordId: string) => {
    const newExpandedRows = new Set(expandedRows);
    if (newExpandedRows.has(recordId)) {
      newExpandedRows.delete(recordId);
    } else {
      newExpandedRows.add(recordId);
    }
    setExpandedRows(newExpandedRows);
  };

  // Toggle image display for a record
  const toggleImageDisplay = (recordId: string) => {
    const newShowImages = new Set(showImagesForRecord);
    if (newShowImages.has(recordId)) {
      newShowImages.delete(recordId);
    } else {
      newShowImages.add(recordId);
    }
    setShowImagesForRecord(newShowImages);
  };

  // Format date
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Format file size
  const formatFileSize = (bytes: number): string => {
    return (bytes / 1024 / 1024).toFixed(2) + ' MB';
  };

  // Handle image download
  const handleImageDownload = async (recordId: string, imageIndex: number) => {
    try {
      const response = await api.get(`/api/workorder-qa/${recordId}/images/${imageIndex}/download`);
      if (response.success && response.data.download_url) {
        window.open(response.data.download_url, '_blank');
      } else {
        console.error('Failed to get image download URL');
      }
    } catch (error) {
      console.error('Error downloading image:', error);
    }
  };

  // Handle work order click - navigate directly to work order detail page
  const handleWorkOrderClick = async (qaRecord: QARecord) => {
    try {
      // If we have the work order ObjectId, use it directly
      if (qaRecord.work_order_object_id) {
        router.push(`/workOrders/${qaRecord.work_order_object_id}`);
        return;
      }
      
      // Search for the work order by its number with a larger limit to overcome pagination issues
      // The API has a bug where search happens after pagination, so we need more records
      const response = await api.get('/api/work-orders', { 
        params: { 
          search: qaRecord.WO_ID,
          limit: '100' // Increased limit to find older work orders
        } 
      });
      
      if (response.success && response.data && response.data.length > 0) {
        const workOrder = response.data[0];
        router.push(`/workOrders/${workOrder._id}`);
      } else {
        // If still not found, try without search and filter manually
        console.log(`Work order ${qaRecord.WO_ID} not found in search, trying broader fetch...`);
        
        const broadResponse = await api.get('/api/work-orders', { 
          params: { 
            limit: '100' // Get more records without search filter
          } 
        });
        
        if (broadResponse.success && broadResponse.data) {
          // Manually search in the results
          const foundWorkOrder = broadResponse.data.find((wo: any) => 
            wo.workOrderNumber === qaRecord.WO_ID || 
            wo.work_order_number === qaRecord.WO_ID ||
            wo.workOrderId === qaRecord.WO_ID
          );
          
          if (foundWorkOrder) {
            router.push(`/workOrders/${foundWorkOrder._id}`);
            return;
          }
        }
        
        console.error(`Work order not found for number: ${qaRecord.WO_ID}`);
        console.error(`Work order ${qaRecord.WO_ID} not found. It may be in an older batch of records.`);
      }
    } catch (error) {
      console.error('Error navigating to work order:', error);
      console.error(`Failed to open work order ${qaRecord.WO_ID}. Please try again.`);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-8">
        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
        <span className="ml-2 text-gray-600">Loading QA records...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
        {error}
      </div>
    );
  }

  if (qaRecords.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        <div className="text-4xl mb-4">📋</div>
        <p className="text-lg font-medium">No QA records found</p>
        <p className="text-sm">QA submissions will appear here once they are created</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {qaRecords.map((record) => (
        <div key={record._id} className="bg-white border border-gray-200 rounded-lg shadow-sm">
          {/* Header */}
          <div className="p-4 border-b border-gray-100">
            <div className="flex justify-between items-start">
              <div className="flex-1">
                <div className="flex items-center space-x-4">
                  {showWorkOrderColumn && (
                    <div>
                      <p className="text-sm font-medium text-gray-900">
                        Work Order: <button
                          onClick={() => handleWorkOrderClick(record)}
                          className="text-blue-600 hover:text-blue-800 hover:underline"
                        >
                          {record.WO_ID}
                        </button>
                      </p>
                    </div>
                  )}
                  <div>
                    <p className="text-sm text-gray-600">
                      Inspector: {record.person_name}
                    </p>
                  </div>
                  <div>
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                      record.passed 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {record.passed ? 'PASSED' : 'FAILED'}
                    </span>
                  </div>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  {formatDate(record.created_at)}
                </p>
              </div>
              <Button
                size="sm"
                variant="outline"
                onClick={() => toggleRowExpansion(record._id)}
              >
                {expandedRows.has(record._id) ? 'Hide Details' : 'Show Details'}
              </Button>
            </div>
          </div>

          {/* Expanded Details */}
          {expandedRows.has(record._id) && (
            <div className="p-4 bg-gray-50">
              <div className="space-y-4">
                {/* Description */}
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">QA Description</h4>
                  <p className="text-sm text-gray-700 bg-white p-3 rounded border">
                    {record.description}
                  </p>
                </div>

                {/* Images */}
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <h4 className="font-medium text-gray-900">
                      QA Images ({record.images.length})
                    </h4>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => toggleImageDisplay(record._id)}
                      className="text-xs"
                    >
                      {showImagesForRecord.has(record._id) ? 'Hide Images' : 'Display Images'}
                    </Button>
                  </div>
                  
                  {showImagesForRecord.has(record._id) && (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {record.images.map((image, index) => (
                        <div key={index} className="bg-white p-3 rounded border">
                          <div className="space-y-2">
                            <div className="flex justify-between items-start">
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-medium text-gray-900 truncate">
                                  {image.original_name}
                                </p>
                                <p className="text-xs text-gray-500">
                                  {formatFileSize(image.size)}
                                </p>
                                <p className="text-xs text-gray-500">
                                  {formatDate(image.upload_date)}
                                </p>
                              </div>
                            </div>
                            
                            {/* Image preview (if signed URL available) */}
                            {image.signed_url && (
                              <div className="aspect-video bg-gray-100 rounded overflow-hidden">
                                <img
                                  src={image.signed_url}
                                  alt={image.original_name}
                                  className="w-full h-full object-cover cursor-pointer hover:opacity-80 transition-opacity"
                                  onClick={() => window.open(image.signed_url, '_blank')}
                                />
                              </div>
                            )}
                            
                            <Button
                              size="sm"
                              variant="outline"
                              className="w-full text-xs"
                              onClick={() => handleImageDownload(record._id, index)}
                            >
                              View Full Size
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Metadata */}
                <div className="border-t pt-3">
                  <div className="grid grid-cols-2 gap-4 text-xs text-gray-500">
                    <div>
                      <span className="font-medium">Created:</span> {formatDate(record.created_at)}
                    </div>
                    <div>
                      <span className="font-medium">Updated:</span> {formatDate(record.updated_at)}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
};