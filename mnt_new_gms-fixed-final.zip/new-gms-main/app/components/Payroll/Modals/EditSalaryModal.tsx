"use client";

import React, { useState } from "react";
import { Button } from "../../ui/button";
import { Input } from "../../ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "../../ui/card";
import { X, DollarSign, Save, AlertCircle } from "lucide-react";
import { payrollApi } from "../../../../services/api";
import api from "../../../../services/api";
import { PayrollEmployee, UpdateSalaryData } from "../../../types/payroll";

interface EditSalaryModalProps {
  employee: PayrollEmployee;
  onClose: () => void;
  onSuccess: () => void;
}

export default function EditSalaryModal({ employee, onClose, onSuccess }: EditSalaryModalProps) {
  const [formData, setFormData] = useState<UpdateSalaryData>({
    monthly_salary: employee.payroll_info.monthly_salary || 
                   (employee.current_rate || employee.payroll_info.current_daily_rate) * 22 || 0,
    reason: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (formData.monthly_salary <= 0) {
      setError('Monthly salary must be greater than 0');
      return;
    }

    const currentSalary = employee.payroll_info.monthly_salary || 
                         (employee.current_rate || employee.payroll_info.current_daily_rate) * 22 || 0;
    
    if (formData.monthly_salary === currentSalary) {
      setError('New salary must be different from current salary');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      
      // Use existing employee rate endpoint (convert monthly salary to daily rate)
      const employeeId = employee.employee_id || employee._id;
      
      if (!employeeId) {
        throw new Error('Employee ID is missing. Cannot update salary.');
      }
      
      console.log('Updating salary for employee ID:', employeeId);
      console.log('Converting monthly salary to daily rate:', formData.monthly_salary, '/ 22 =', Math.round(formData.monthly_salary / 22));
      
      // Convert monthly salary to daily rate (assuming 22 working days per month)
      const dailyRate = Math.round(formData.monthly_salary / 22);
      
      // Try multiple endpoints as fallbacks
      let updateSuccessful = false;
      let errorMessage = '';
      
      // Try salary endpoint first
      try {
        await payrollApi.updateEmployeeSalary(employeeId, formData);
        updateSuccessful = true;
        console.log('Salary updated via salary endpoint');
      } catch (salaryError: any) {
        console.log('Salary endpoint failed:', salaryError.response?.status);
        errorMessage += `Salary endpoint: ${salaryError.response?.status || 'Failed'}. `;
        
        // Try rate endpoint as fallback
        try {
          await payrollApi.updateEmployeeRate(employeeId, {
            daily_rate: dailyRate,
            reason: formData.reason || `Monthly salary update: AED ${formData.monthly_salary.toLocaleString()}`
          });
          updateSuccessful = true;
          console.log('Salary updated via rate endpoint');
        } catch (rateError: any) {
          console.log('Rate endpoint also failed:', rateError.response?.status);
          errorMessage += `Rate endpoint: ${rateError.response?.status || 'Failed'}. `;
        }
      }
      
      if (!updateSuccessful) {
        throw new Error(`Backend Error: The payroll system endpoints are not implemented on the server.\n\nTried endpoints:\n- PUT /api/payroll/employees/${employeeId}/salary (${errorMessage.includes('Salary endpoint: 404') ? '404 Not Found' : 'Failed'})\n- PUT /api/payroll/employees/${employeeId}/rate (${errorMessage.includes('Rate endpoint: 404') ? '404 Not Found' : 'Failed'})\n\nThe backend API server needs to implement these payroll endpoints to support salary updates.`);
      }
      
      // Send notification to admins about salary change
      try {
        const changeAmount = formData.monthly_salary - (employee.payroll_info.monthly_salary || 0);
        const changePercentage = employee.payroll_info.monthly_salary 
          ? ((changeAmount / employee.payroll_info.monthly_salary) * 100).toFixed(1)
          : '100.0';
        const changeType = changeAmount > 0 ? 'increased' : 'decreased';

        await api.post('/api/notifications', {
          title: `Employee Salary ${changeType.charAt(0).toUpperCase() + changeType.slice(1)}`,
          message: `${employee.first_name} ${employee.last_name}'s monthly salary has been ${changeType} from AED ${(employee.payroll_info.monthly_salary || 0).toLocaleString()} to AED ${formData.monthly_salary.toLocaleString()} (${changePercentage}% change). Daily rate updated to AED ${dailyRate}${formData.reason ? `. Reason: ${formData.reason}` : ''}`,
          type: 'salary_change',
          priority: Math.abs(parseFloat(changePercentage)) > 20 ? 'high' : 'medium',
          target_roles: ['admin', 'accountant'],
          metadata: {
            employee_id: employeeId,
            employee_name: `${employee.first_name} ${employee.last_name}`,
            old_salary: employee.payroll_info.monthly_salary || 0,
            new_salary: formData.monthly_salary,
            old_daily_rate: Math.round((employee.payroll_info.monthly_salary || 0) / 22),
            new_daily_rate: dailyRate,
            change_amount: changeAmount,
            change_percentage: changePercentage,
            reason: formData.reason
          }
        });
      } catch (notificationError) {
        console.error('Failed to send salary change notification:', notificationError);
        // Don't fail the entire operation if notification fails
      }

      onSuccess();
    } catch (err: any) {
      console.error('Error updating salary:', err);
      setError(err?.response?.data?.message || err.message || 'Failed to update salary. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-AE', {
      style: 'currency',
      currency: 'AED',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-md">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="w-5 h-5" />
              Edit Monthly Salary
            </CardTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              disabled={loading}
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="mb-6">
            <div className="text-sm text-gray-600 mb-1">Employee</div>
            <div className="font-medium">{employee.first_name} {employee.last_name}</div>
            <div className="text-sm text-gray-500">{employee.email}</div>
            
            {employee.payroll_info.monthly_salary && (
              <div className="mt-3 p-3 bg-gray-50 rounded">
                <div className="text-sm text-gray-600">Current Monthly Salary</div>
                <div className="text-lg font-semibold text-green-600">
                  {formatCurrency(employee.payroll_info.monthly_salary)}
                </div>
              </div>
            )}
          </div>

          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
              <div className="text-sm text-red-600">{error}</div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                New Monthly Salary (AED) *
              </label>
              <Input
                type="number"
                min="1"
                step="1"
                value={formData.monthly_salary}
                onChange={(e) => setFormData({ ...formData, monthly_salary: parseFloat(e.target.value) || 0 })}
                className="w-full"
                disabled={loading}
                required
              />
              <div className="mt-1 text-xs text-gray-500">
                Enter the monthly salary amount (will be converted to daily rate: AED {Math.round((formData.monthly_salary || 0) / 22)}/day)
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Reason for Change
              </label>
              <Input
                type="text"
                value={formData.reason}
                onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
                className="w-full"
                placeholder="e.g., Annual salary review, promotion, performance adjustment"
                disabled={loading}
              />
              <div className="mt-1 text-xs text-gray-500">
                Optional: Provide a reason for the salary change
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                disabled={loading}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="flex items-center gap-2"
                disabled={loading || formData.monthly_salary <= 0}
              >
                {loading ? (
                  <>
                    <div className="w-4 h-4 animate-spin border-2 border-white border-t-transparent rounded-full"></div>
                    Updating...
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    Update Salary
                  </>
                )}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}