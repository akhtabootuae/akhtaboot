"use client";

import React, { useState, useEffect } from "react";
import { Button } from "../../ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../../ui/card";
import { X, History, Calendar, AlertCircle, FileText } from "lucide-react";
import { payrollApi } from "../../../../services/api";
import { PayrollEmployeeDeduction, PayrollDeductionHistory } from "../../../types/payroll";

interface DeductionHistoryModalProps {
  deduction: PayrollEmployeeDeduction;
  onClose: () => void;
}

export default function DeductionHistoryModal({ deduction, onClose }: DeductionHistoryModalProps) {
  const [history, setHistory] = useState<PayrollDeductionHistory[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchHistory = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await payrollApi.getDeductionHistory(deduction._id);
      setHistory(response.history || []);
    } catch (err: any) {
      console.error('Error fetching deduction history:', err);
      setError(err.response?.data?.message || 'Failed to fetch deduction history');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHistory();
  }, [deduction._id]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-AE', {
      style: 'currency',
      currency: 'AED',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const formatDateTime = (dateString: string) => {
    return new Date(dateString).toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const totalProcessed = history.reduce((sum, record) => sum + record.amount_deducted, 0);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-4xl max-h-[90vh] overflow-hidden">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4 border-b">
          <CardTitle className="flex items-center gap-2">
            <History className="w-5 h-5" />
            Deduction History
          </CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="h-6 w-6 p-0"
          >
            <X className="w-4 h-4" />
          </Button>
        </CardHeader>
        
        <CardContent className="p-0">
          {/* Deduction Summary */}
          <div className="p-6 bg-gray-50 border-b">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <h3 className="text-lg font-semibold text-gray-900">
                  {deduction.deduction_type?.name || 'Unknown Type'}
                </h3>
                <p className="text-sm text-gray-600">
                  {deduction.employee?.first_name} {deduction.employee?.last_name}
                </p>
                <p className="text-xs text-gray-500">
                  Status: {deduction.status}
                </p>
              </div>
              
              <div>
                <div className="text-sm text-gray-500">Deduction Amount</div>
                <div className="text-xl font-bold text-blue-600">
                  {deduction.deduction_type?.type === 'percentage' ? `${deduction.amount}%` : formatCurrency(deduction.amount)}
                </div>
                <div className="text-xs text-gray-500">
                  {deduction.frequency.replace('_', ' ')}
                </div>
              </div>

              <div>
                <div className="text-sm text-gray-500">Total Deducted</div>
                <div className="text-xl font-bold text-green-600">
                  {formatCurrency(deduction.total_deducted)}
                </div>
                {deduction.max_total_amount && (
                  <div className="text-xs text-gray-500">
                    of {formatCurrency(deduction.max_total_amount)}
                  </div>
                )}
              </div>

              <div>
                <div className="text-sm text-gray-500">Processing Records</div>
                <div className="text-xl font-bold text-purple-600">
                  {history.length}
                </div>
                <div className="text-xs text-gray-500">
                  pay periods
                </div>
              </div>
            </div>

            {deduction.remaining_balance && deduction.remaining_balance > 0 && (
              <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                <div className="text-sm font-medium text-blue-900">
                  Remaining Balance: {formatCurrency(deduction.remaining_balance)}
                </div>
              </div>
            )}
          </div>

          {/* History Content */}
          <div className="max-h-[60vh] overflow-y-auto">
            {loading ? (
              <div className="flex items-center justify-center h-32">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                <span className="ml-3 text-gray-600">Loading history...</span>
              </div>
            ) : error ? (
              <div className="p-6">
                <div className="flex items-center gap-3 text-red-600 mb-4">
                  <AlertCircle className="w-5 h-5" />
                  <span className="font-medium">Error loading history</span>
                </div>
                <p className="text-red-600 mb-4">{error}</p>
                <Button onClick={fetchHistory} variant="outline">
                  Try Again
                </Button>
              </div>
            ) : history.length === 0 ? (
              <div className="p-6 text-center">
                <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">No processing history found for this deduction.</p>
                <p className="text-sm text-gray-500 mt-2">
                  History will appear here once this deduction is processed during payroll runs.
                </p>
              </div>
            ) : (
              <div className="p-6">
                <div className="space-y-4">
                  {history.map((record, index) => (
                    <div key={record._id} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <div className="text-lg font-bold text-gray-900">
                              {formatCurrency(record.amount_deducted)}
                            </div>
                            <span className="text-sm text-gray-500">
                              #{history.length - index}
                            </span>
                          </div>

                          {/* Pay Period */}
                          <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
                            <Calendar className="w-4 h-4" />
                            <span>
                              Pay Period: {formatDate(record.pay_period_start)} - {formatDate(record.pay_period_end)}
                            </span>
                          </div>

                          {/* Processing Info */}
                          <div className="text-sm text-gray-600 mb-2">
                            <span className="font-medium">Processed:</span> {formatDateTime(record.processed_at)}
                          </div>

                          {/* Gross Pay (if available) */}
                          {record.gross_pay_amount && (
                            <div className="text-sm text-gray-600 mb-2">
                              <span className="font-medium">Gross Pay:</span> {formatCurrency(record.gross_pay_amount)}
                              {deduction.deduction_type?.type === 'percentage' && (
                                <span className="text-gray-500">
                                  {' '}({((record.amount_deducted / record.gross_pay_amount) * 100).toFixed(2)}% deducted)
                                </span>
                              )}
                            </div>
                          )}

                          {/* Remaining Balance After */}
                          {record.remaining_balance_after !== null && record.remaining_balance_after !== undefined && (
                            <div className="text-sm text-gray-600 mb-2">
                              <span className="font-medium">Remaining Balance After:</span> {formatCurrency(record.remaining_balance_after)}
                            </div>
                          )}

                          {/* Variance Reason */}
                          {record.reason_for_variance && (
                            <div className="text-sm text-amber-700 bg-amber-50 p-2 rounded">
                              <span className="font-medium">Variance Note:</span> {record.reason_for_variance}
                            </div>
                          )}
                        </div>

                        {/* Status Indicator */}
                        <div className="ml-4">
                          <div className="w-3 h-3 bg-green-500 rounded-full" title="Processed"></div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Summary */}
                {history.length > 0 && (
                  <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <div className="text-sm font-medium text-blue-900 mb-2">Processing Summary</div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-blue-700">
                      <div>
                        <span className="font-medium">Total Records:</span> {history.length}
                      </div>
                      <div>
                        <span className="font-medium">Total Processed:</span> {formatCurrency(totalProcessed)}
                      </div>
                      <div>
                        <span className="font-medium">Average per Period:</span> {formatCurrency(totalProcessed / history.length)}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="p-4 border-t bg-gray-50">
            <div className="flex justify-between items-center">
              <div className="text-sm text-gray-600">
                {history.length} processing record(s) found
              </div>
              <Button onClick={onClose} variant="outline">
                Close
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}