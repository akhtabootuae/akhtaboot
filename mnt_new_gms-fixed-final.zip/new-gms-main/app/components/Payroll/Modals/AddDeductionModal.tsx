"use client";

import React, { useState, useEffect } from "react";
import { Button } from "../../ui/button";
import { Input } from "../../ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "../../ui/card";
import { X, Plus, AlertCircle } from "lucide-react";
import { payrollApi } from "../../../../services/api";
import api from "../../../../services/api";
import { PayrollEmployee, PayrollDeductionType, CreateDeductionData } from "../../../types/payroll";

interface AddDeductionModalProps {
  employee: PayrollEmployee;
  onClose: () => void;
  onSuccess: () => void;
}

export default function AddDeductionModal({ employee, onClose, onSuccess }: AddDeductionModalProps) {
  const [deductionTypes, setDeductionTypes] = useState<PayrollDeductionType[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState<CreateDeductionData>({
    deduction_type_id: '',
    amount: 0,
    frequency: 'monthly',
    start_date: new Date().toISOString().split('T')[0],
    priority: 5,
  });

  const [selectedType, setSelectedType] = useState<PayrollDeductionType | null>(null);

  useEffect(() => {
    fetchDeductionTypes();
  }, []);

  useEffect(() => {
    if (formData.deduction_type_id) {
      const type = deductionTypes.find(t => t._id === formData.deduction_type_id);
      setSelectedType(type || null);
      
      // Set default values based on selected type
      if (type) {
        setFormData(prev => ({
          ...prev,
          amount: type.default_amount || prev.amount,
          frequency: type.frequency || prev.frequency,
        }));
      }
    }
  }, [formData.deduction_type_id, deductionTypes]);

  const fetchDeductionTypes = async () => {
    try {
      const response = await payrollApi.getDeductionTypes({ active: true });
      setDeductionTypes(response.deduction_types || []);
    } catch (error) {
      console.error('Error fetching deduction types:', error);
      setError('Failed to load deduction types');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.deduction_type_id) {
      setError('Please select a deduction type');
      return;
    }

    if (formData.amount <= 0) {
      setError('Amount must be greater than 0');
      return;
    }

    // Validate percentage limits for percentage-based deductions
    if (selectedType?.type === 'percentage' && selectedType.max_percentage_of_pay) {
      if (formData.amount > selectedType.max_percentage_of_pay) {
        setError(`Percentage cannot exceed ${selectedType.max_percentage_of_pay}%`);
        return;
      }
    }

    try {
      setLoading(true);
      setError(null);
      
      const createResponse = await payrollApi.createEmployeeDeduction(employee._id, formData);
      
      // Send notification to admins about new deduction
      try {
        const notificationData = {
          type: "general",
          title: "New Employee Deduction Created",
          message: `New deduction created for ${employee.first_name} ${employee.last_name}. Type: ${selectedType?.name}. Amount: ${selectedType?.type === 'percentage' ? `${formData.amount}%` : `AED ${formData.amount}`}. Frequency: ${formData.frequency}. Start date: ${formData.start_date}.`,
          recipientType: "admin",
          priority: "medium",
          employeeId: employee._id,
          deductionId: createResponse?.deduction?._id || createResponse?._id
        };
        
        await api.post('/api/notifications', notificationData);
      } catch (notifError) {
        console.error('Error sending deduction creation notification:', notifError);
        // Don't fail the main operation if notification fails
      }
      
      onSuccess();
    } catch (err: any) {
      console.error('Error creating deduction:', err);
      setError(err.response?.data?.message || 'Failed to create deduction');
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (field: keyof CreateDeductionData, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    if (error) setError(null);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-AE', {
      style: 'currency',
      currency: 'AED',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const isLoanOrAdvance = selectedType?.name.toLowerCase().includes('loan') || 
                         selectedType?.name.toLowerCase().includes('advance');

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <CardTitle className="flex items-center gap-2">
            <Plus className="w-5 h-5" />
            Add Employee Deduction
          </CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="h-6 w-6 p-0"
          >
            <X className="w-4 h-4" />
          </Button>
        </CardHeader>
        
        <CardContent>
          {/* Employee Info */}
          <div className="mb-6 p-4 bg-gray-50 rounded-lg">
            <div className="font-medium text-gray-900">
              {employee.first_name} {employee.last_name}
            </div>
            <div className="text-sm text-gray-600">{employee.speciality} • {employee.branch.branch_name}</div>
            <div className="text-sm text-gray-500">
              Monthly Salary: {employee.payroll_info?.monthly_salary ? formatCurrency(employee.payroll_info.monthly_salary) : 'Not set'}
            </div>
          </div>

          {/* Error Display */}
          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
              <AlertCircle className="w-4 h-4" />
              <span className="text-sm">{error}</span>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Deduction Type */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Deduction Type *
              </label>
              <select
                value={formData.deduction_type_id}
                onChange={(e) => handleInputChange('deduction_type_id', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                required
                disabled={loading}
              >
                <option value="">Select a deduction type</option>
                {deductionTypes.map((type) => (
                  <option key={type._id} value={type._id}>
                    {type.name} ({type.type === 'percentage' ? 'Percentage' : 'Fixed Amount'})
                  </option>
                ))}
              </select>
              {selectedType?.description && (
                <p className="mt-1 text-sm text-gray-500">{selectedType.description}</p>
              )}
            </div>

            {/* Amount */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {selectedType?.type === 'percentage' ? 'Percentage (%)' : 'Amount (AED)'} *
              </label>
              <Input
                type="number"
                min="0"
                step={selectedType?.type === 'percentage' ? '0.01' : '1'}
                max={selectedType?.type === 'percentage' ? selectedType.max_percentage_of_pay || 100 : undefined}
                value={formData.amount}
                onChange={(e) => handleInputChange('amount', parseFloat(e.target.value) || 0)}
                placeholder={selectedType?.type === 'percentage' ? 'Enter percentage' : 'Enter amount'}
                required
                disabled={loading}
              />
              {selectedType?.type === 'percentage' && selectedType.max_percentage_of_pay && (
                <p className="mt-1 text-sm text-gray-500">
                  Maximum allowed: {selectedType.max_percentage_of_pay}%
                </p>
              )}
            </div>

            {/* Frequency */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Frequency *
              </label>
              <select
                value={formData.frequency}
                onChange={(e) => handleInputChange('frequency', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                required
                disabled={loading}
              >
                <option value="daily">Daily</option>
                <option value="weekly">Weekly</option>
                <option value="monthly">Monthly</option>
                <option value="per_pay_period">Per Pay Period</option>
                <option value="one_time">One Time</option>
              </select>
            </div>

            {/* Start Date */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Start Date *
              </label>
              <Input
                type="date"
                value={formData.start_date}
                onChange={(e) => handleInputChange('start_date', e.target.value)}
                required
                disabled={loading}
              />
            </div>

            {/* End Date (optional) */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                End Date (Optional)
              </label>
              <Input
                type="date"
                value={formData.end_date || ''}
                onChange={(e) => handleInputChange('end_date', e.target.value || undefined)}
                min={formData.start_date}
                disabled={loading}
              />
            </div>

            {/* Max Total Amount (for loans/advances) */}
            {isLoanOrAdvance && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Total Loan/Advance Amount (AED)
                </label>
                <Input
                  type="number"
                  min="0"
                  step="1"
                  value={formData.max_total_amount || ''}
                  onChange={(e) => handleInputChange('max_total_amount', parseFloat(e.target.value) || undefined)}
                  placeholder="Enter total amount to be deducted"
                  disabled={loading}
                />
                <p className="mt-1 text-sm text-gray-500">
                  The deduction will automatically stop when this amount is reached
                </p>
              </div>
            )}

            {/* Priority */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Priority (1 = Highest, 10 = Lowest)
              </label>
              <Input
                type="number"
                min="1"
                max="10"
                value={formData.priority || 5}
                onChange={(e) => handleInputChange('priority', parseInt(e.target.value) || 5)}
                disabled={loading}
              />
              <p className="mt-1 text-sm text-gray-500">
                Higher priority deductions are processed first during payroll
              </p>
            </div>

            {/* Reference Number */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Reference Number (Optional)
              </label>
              <Input
                type="text"
                value={formData.reference_number || ''}
                onChange={(e) => handleInputChange('reference_number', e.target.value || undefined)}
                placeholder="Court order number, loan ID, etc."
                disabled={loading}
              />
            </div>

            {/* Legal Required */}
            <div className="flex items-center gap-3">
              <input
                type="checkbox"
                id="legal_required"
                checked={formData.legal_required || false}
                onChange={(e) => handleInputChange('legal_required', e.target.checked)}
                disabled={loading}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <label htmlFor="legal_required" className="text-sm text-gray-700">
                This is a legally required deduction (e.g., court order, garnishment)
              </label>
            </div>

            {/* Notes */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Notes (Optional)
              </label>
              <textarea
                value={formData.notes || ''}
                onChange={(e) => handleInputChange('notes', e.target.value || undefined)}
                placeholder="Additional notes about this deduction"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none"
                rows={3}
                disabled={loading}
              />
            </div>

            {/* Approval Notice */}
            {selectedType?.requires_approval && (
              <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                <div className="flex items-center gap-2 text-yellow-800">
                  <AlertCircle className="w-4 h-4" />
                  <span className="text-sm font-medium">Approval Required</span>
                </div>
                <p className="text-sm text-yellow-700 mt-1">
                  This deduction type requires approval before it becomes active. It will be created with 
                  "Pending Approval" status.
                </p>
              </div>
            )}

            {/* Summary */}
            {formData.amount > 0 && formData.frequency && (
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <div className="text-sm font-medium text-blue-900 mb-2">Deduction Summary</div>
                <div className="text-sm text-blue-700 space-y-1">
                  <div>
                    Amount: {selectedType?.type === 'percentage' ? `${formData.amount}%` : formatCurrency(formData.amount)} 
                    ({formData.frequency.replace('_', ' ')})
                  </div>
                  {formData.max_total_amount && (
                    <div>Total to be deducted: {formatCurrency(formData.max_total_amount)}</div>
                  )}
                  <div>Priority: {formData.priority}</div>
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex gap-3 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                disabled={loading}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={loading || !formData.deduction_type_id || formData.amount <= 0}
                className="flex-1 flex items-center gap-2"
              >
                {loading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    Creating...
                  </>
                ) : (
                  <>
                    <Plus className="w-4 h-4" />
                    Create Deduction
                  </>
                )}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}