"use client";

import React, { useState } from "react";
import { Button } from "../../ui/button";
import { Input } from "../../ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "../../ui/card";
import { X, Edit, AlertCircle, Trash2 } from "lucide-react";
import { payrollApi } from "../../../../services/api";
import api from "../../../../services/api";
import { PayrollEmployeeDeduction, UpdateDeductionData } from "../../../types/payroll";

interface EditDeductionModalProps {
  deduction: PayrollEmployeeDeduction;
  onClose: () => void;
  onSuccess: () => void;
}

export default function EditDeductionModal({ deduction, onClose, onSuccess }: EditDeductionModalProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [formData, setFormData] = useState<UpdateDeductionData>({
    amount: deduction.amount,
    frequency: deduction.frequency,
    start_date: deduction.start_date.split('T')[0],
    end_date: deduction.end_date ? deduction.end_date.split('T')[0] : undefined,
    priority: deduction.priority,
    max_total_amount: deduction.max_total_amount,
    notes: deduction.notes,
    reference_number: deduction.reference_number,
    legal_required: deduction.legal_required,
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (formData.amount && formData.amount <= 0) {
      setError('Amount must be greater than 0');
      return;
    }

    // Validate percentage limits for percentage-based deductions
    if (deduction.deduction_type?.type === 'percentage' && deduction.deduction_type.max_percentage_of_pay) {
      if (formData.amount && formData.amount > deduction.deduction_type.max_percentage_of_pay) {
        setError(`Percentage cannot exceed ${deduction.deduction_type.max_percentage_of_pay}%`);
        return;
      }
    }

    // Validate date range
    if (formData.end_date && formData.start_date && new Date(formData.end_date) <= new Date(formData.start_date)) {
      setError('End date must be after start date');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      
      // Only send fields that have changed
      const updatedData: UpdateDeductionData = {};
      Object.keys(formData).forEach(key => {
        const typedKey = key as keyof UpdateDeductionData;
        if (formData[typedKey] !== getOriginalValue(typedKey)) {
          updatedData[typedKey] = formData[typedKey] as any;
        }
      });

      if (Object.keys(updatedData).length === 0) {
        setError('No changes detected');
        return;
      }
      
      await payrollApi.updateDeduction(deduction._id, updatedData);
      
      // Send notification to admins about deduction update
      try {
        const changes = Object.keys(updatedData).map(key => {
          const typedKey = key as keyof UpdateDeductionData;
          const oldValue = getOriginalValue(typedKey);
          const newValue = updatedData[typedKey];
          
          if (key === 'amount') {
            const formatAmount = (amount: number) => deduction.deduction_type?.type === 'percentage' ? `${amount}%` : `AED ${amount}`;
            return `${key}: ${formatAmount(oldValue as number)} → ${formatAmount(newValue as number)}`;
          }
          return `${key}: ${oldValue} → ${newValue}`;
        }).join(', ');
        
        const notificationData = {
          type: "general",
          title: "Employee Deduction Updated",
          message: `Deduction for ${deduction.employee?.first_name} ${deduction.employee?.last_name} has been updated. Type: ${deduction.deduction_type?.name}. Changes: ${changes}.`,
          recipientType: "admin",
          priority: "medium",
          employeeId: deduction.employee_id,
          deductionId: deduction._id
        };
        
        await api.post('/api/notifications', notificationData);
      } catch (notifError) {
        console.error('Error sending deduction update notification:', notifError);
        // Don't fail the main operation if notification fails
      }
      
      onSuccess();
    } catch (err: any) {
      console.error('Error updating deduction:', err);
      setError(err.response?.data?.message || 'Failed to update deduction');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    try {
      setLoading(true);
      setError(null);
      
      await payrollApi.updateDeductionStatus(deduction._id, 'cancelled', 'Cancelled via edit modal');
      
      // Send notification to admins about deduction cancellation
      try {
        const notificationData = {
          type: "general",
          title: "Employee Deduction Cancelled",
          message: `Deduction for ${deduction.employee?.first_name} ${deduction.employee?.last_name} has been cancelled. Type: ${deduction.deduction_type?.name}. Amount: ${deduction.deduction_type?.type === 'percentage' ? `${deduction.amount}%` : `AED ${deduction.amount}`}.`,
          recipientType: "admin",
          priority: "medium",
          employeeId: deduction.employee_id,
          deductionId: deduction._id
        };
        
        await api.post('/api/notifications', notificationData);
      } catch (notifError) {
        console.error('Error sending deduction cancellation notification:', notifError);
        // Don't fail the main operation if notification fails
      }
      
      onSuccess();
    } catch (err: any) {
      console.error('Error cancelling deduction:', err);
      setError(err.response?.data?.message || 'Failed to cancel deduction');
    } finally {
      setLoading(false);
    }
  };

  const getOriginalValue = (field: keyof UpdateDeductionData) => {
    switch (field) {
      case 'start_date':
        return deduction.start_date.split('T')[0];
      case 'end_date':
        return deduction.end_date ? deduction.end_date.split('T')[0] : undefined;
      default:
        return deduction[field as keyof PayrollEmployeeDeduction];
    }
  };

  const handleInputChange = (field: keyof UpdateDeductionData, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    if (error) setError(null);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-AE', {
      style: 'currency',
      currency: 'AED',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const isLoanOrAdvance = deduction.deduction_type?.name.toLowerCase().includes('loan') || 
                         deduction.deduction_type?.name.toLowerCase().includes('advance');

  const canEdit = deduction.status === 'active' || deduction.status === 'paused' || deduction.status === 'pending_approval';

  if (!canEdit) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
            <CardTitle>Cannot Edit Deduction</CardTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="h-6 w-6 p-0"
            >
              <X className="w-4 h-4" />
            </Button>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-3 text-amber-600 mb-4">
              <AlertCircle className="w-5 h-5" />
              <span className="font-medium">Deduction cannot be edited</span>
            </div>
            <p className="text-gray-600 mb-4">
              This deduction has a status of "{deduction.status}" and cannot be modified.
            </p>
            <Button onClick={onClose} className="w-full">
              Close
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <CardTitle className="flex items-center gap-2">
            <Edit className="w-5 h-5" />
            Edit Deduction
          </CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="h-6 w-6 p-0"
          >
            <X className="w-4 h-4" />
          </Button>
        </CardHeader>
        
        <CardContent>
          {/* Deduction Info */}
          <div className="mb-6 p-4 bg-gray-50 rounded-lg">
            <div className="font-medium text-gray-900">
              {deduction.deduction_type?.name || 'Unknown Type'}
            </div>
            <div className="text-sm text-gray-600">
              Employee: {deduction.employee?.first_name} {deduction.employee?.last_name}
            </div>
            <div className="text-sm text-gray-500">
              Status: {deduction.status} • Created: {new Date(deduction.created_at).toLocaleDateString()}
            </div>
            {deduction.max_total_amount && (
              <div className="text-sm text-gray-500">
                Progress: {formatCurrency(deduction.total_deducted)} / {formatCurrency(deduction.max_total_amount)}
              </div>
            )}
          </div>

          {/* Error Display */}
          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
              <AlertCircle className="w-4 h-4" />
              <span className="text-sm">{error}</span>
            </div>
          )}

          {!showDeleteConfirm ? (
            /* Edit Form */
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Amount */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {deduction.deduction_type?.type === 'percentage' ? 'Percentage (%)' : 'Amount (AED)'}
                </label>
                <Input
                  type="number"
                  min="0"
                  step={deduction.deduction_type?.type === 'percentage' ? '0.01' : '1'}
                  max={deduction.deduction_type?.type === 'percentage' ? deduction.deduction_type.max_percentage_of_pay || 100 : undefined}
                  value={formData.amount || ''}
                  onChange={(e) => handleInputChange('amount', parseFloat(e.target.value) || 0)}
                  disabled={loading}
                />
                {deduction.deduction_type?.type === 'percentage' && deduction.deduction_type.max_percentage_of_pay && (
                  <p className="mt-1 text-sm text-gray-500">
                    Maximum allowed: {deduction.deduction_type.max_percentage_of_pay}%
                  </p>
                )}
              </div>

              {/* Frequency */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Frequency
                </label>
                <select
                  value={formData.frequency || deduction.frequency}
                  onChange={(e) => handleInputChange('frequency', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  disabled={loading}
                >
                  <option value="daily">Daily</option>
                  <option value="weekly">Weekly</option>
                  <option value="monthly">Monthly</option>
                  <option value="per_pay_period">Per Pay Period</option>
                  <option value="one_time">One Time</option>
                </select>
              </div>

              {/* Start Date */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Start Date
                </label>
                <Input
                  type="date"
                  value={formData.start_date || ''}
                  onChange={(e) => handleInputChange('start_date', e.target.value)}
                  disabled={loading}
                />
              </div>

              {/* End Date */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  End Date (Optional)
                </label>
                <Input
                  type="date"
                  value={formData.end_date || ''}
                  onChange={(e) => handleInputChange('end_date', e.target.value || undefined)}
                  min={formData.start_date}
                  disabled={loading}
                />
              </div>

              {/* Max Total Amount (for loans/advances) */}
              {isLoanOrAdvance && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Total Loan/Advance Amount (AED)
                  </label>
                  <Input
                    type="number"
                    min="0"
                    step="1"
                    value={formData.max_total_amount || ''}
                    onChange={(e) => handleInputChange('max_total_amount', parseFloat(e.target.value) || undefined)}
                    disabled={loading}
                  />
                  <p className="mt-1 text-sm text-gray-500">
                    Already deducted: {formatCurrency(deduction.total_deducted)}
                  </p>
                </div>
              )}

              {/* Priority */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Priority (1 = Highest, 10 = Lowest)
                </label>
                <Input
                  type="number"
                  min="1"
                  max="10"
                  value={formData.priority || 5}
                  onChange={(e) => handleInputChange('priority', parseInt(e.target.value) || 5)}
                  disabled={loading}
                />
              </div>

              {/* Reference Number */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Reference Number
                </label>
                <Input
                  type="text"
                  value={formData.reference_number || ''}
                  onChange={(e) => handleInputChange('reference_number', e.target.value || undefined)}
                  disabled={loading}
                />
              </div>

              {/* Legal Required */}
              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  id="legal_required_edit"
                  checked={formData.legal_required || false}
                  onChange={(e) => handleInputChange('legal_required', e.target.checked)}
                  disabled={loading}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                />
                <label htmlFor="legal_required_edit" className="text-sm text-gray-700">
                  This is a legally required deduction
                </label>
              </div>

              {/* Notes */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Notes
                </label>
                <textarea
                  value={formData.notes || ''}
                  onChange={(e) => handleInputChange('notes', e.target.value || undefined)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none"
                  rows={3}
                  disabled={loading}
                />
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={onClose}
                  disabled={loading}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowDeleteConfirm(true)}
                  disabled={loading}
                  className="flex items-center gap-2 text-red-600 hover:text-red-700 border-red-300 hover:border-red-400"
                >
                  <Trash2 className="w-4 h-4" />
                  Cancel Deduction
                </Button>
                <Button
                  type="submit"
                  disabled={loading}
                  className="flex-1 flex items-center gap-2"
                >
                  {loading ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      Updating...
                    </>
                  ) : (
                    <>
                      <Edit className="w-4 h-4" />
                      Update Deduction
                    </>
                  )}
                </Button>
              </div>
            </form>
          ) : (
            /* Delete Confirmation */
            <div className="space-y-4">
              <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                <div className="flex items-center gap-2 text-red-800 mb-2">
                  <AlertCircle className="w-5 h-5" />
                  <span className="font-medium">Confirm Cancellation</span>
                </div>
                <p className="text-red-700">
                  Are you sure you want to cancel this deduction? This action cannot be undone. 
                  The deduction will be marked as "cancelled" and will stop being processed.
                </p>
              </div>

              <div className="flex gap-3">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowDeleteConfirm(false)}
                  disabled={loading}
                  className="flex-1"
                >
                  Keep Deduction
                </Button>
                <Button
                  type="button"
                  onClick={handleDelete}
                  disabled={loading}
                  className="flex-1 bg-red-600 hover:bg-red-700 text-white flex items-center gap-2"
                >
                  {loading ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      Cancelling...
                    </>
                  ) : (
                    <>
                      <Trash2 className="w-4 h-4" />
                      Cancel Deduction
                    </>
                  )}
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}