"use client";

import React, { useState, useEffect } from "react";
import { Button } from "../../ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../../ui/card";
import { X, History, DollarSign, Calendar, User, AlertCircle } from "lucide-react";
import { payrollApi } from "../../../../services/api";
import { PayrollEmployee, PayrollRateHistory } from "../../../types/payroll";

interface RateHistoryModalProps {
  employee: PayrollEmployee;
  onClose: () => void;
}

export default function RateHistoryModal({ employee, onClose }: RateHistoryModalProps) {
  const [rateHistory, setRateHistory] = useState<PayrollRateHistory | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchRateHistory = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await payrollApi.getEmployeeRates(employee._id);
      setRateHistory(response);
    } catch (err: any) {
      console.error('Error fetching rate history:', err);
      setError(err.response?.data?.message || 'Failed to fetch rate history');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRateHistory();
  }, [employee._id]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-AE', {
      style: 'currency',
      currency: 'AED',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const formatDateTime = (dateString: string) => {
    return new Date(dateString).toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getRateTypeColor = (type: string) => {
    switch (type) {
      case 'regular':
        return 'bg-blue-100 text-blue-800';
      case 'holiday':
        return 'bg-green-100 text-green-800';
      case 'premium':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusBadge = (rate: any) => {
    const isActive = !rate.end_date;
    return (
      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
        isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-600'
      }`}>
        {isActive ? 'Active' : 'Ended'}
      </span>
    );
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-4xl max-h-[90vh] overflow-hidden">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4 border-b">
          <CardTitle className="flex items-center gap-2">
            <History className="w-5 h-5" />
            Rate History
          </CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="h-6 w-6 p-0"
          >
            <X className="w-4 h-4" />
          </Button>
        </CardHeader>
        
        <CardContent className="p-0">
          {/* Employee Header */}
          <div className="p-6 bg-gray-50 border-b">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-gray-900">
                  {employee.first_name} {employee.last_name}
                </h3>
                <p className="text-sm text-gray-600">{employee.speciality} • {employee.branch.branch_name}</p>
                <p className="text-sm text-gray-500">{employee.email}</p>
              </div>
              <div className="text-right">
                <div className="text-sm text-gray-500">Current Rate</div>
                <div className="text-2xl font-bold text-green-600">
                  {formatCurrency(employee.payroll_info.current_daily_rate)}
                  <span className="text-sm font-normal text-gray-500">/day</span>
                </div>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="max-h-[60vh] overflow-y-auto">
            {loading ? (
              <div className="flex items-center justify-center h-32">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                <span className="ml-3 text-gray-600">Loading rate history...</span>
              </div>
            ) : error ? (
              <div className="p-6">
                <div className="flex items-center gap-3 text-red-600 mb-4">
                  <AlertCircle className="w-5 h-5" />
                  <span className="font-medium">Error loading rate history</span>
                </div>
                <p className="text-red-600 mb-4">{error}</p>
                <Button onClick={fetchRateHistory} variant="outline">
                  Try Again
                </Button>
              </div>
            ) : !rateHistory || rateHistory.rates.length === 0 ? (
              <div className="p-6 text-center">
                <History className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">No rate history found for this employee.</p>
              </div>
            ) : (
              <div className="p-6">
                <div className="space-y-4">
                  {rateHistory.rates.map((rate, index) => {
                    const previousRate = rateHistory.rates[index + 1];
                    const rateChange = previousRate ? rate.daily_rate - previousRate.daily_rate : null;
                    const changePercentage = previousRate ? 
                      ((rate.daily_rate - previousRate.daily_rate) / previousRate.daily_rate) * 100 : null;

                    return (
                      <div key={rate._id} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <div className="text-xl font-bold text-gray-900">
                                {formatCurrency(rate.daily_rate)}
                                <span className="text-sm font-normal text-gray-500">/day</span>
                              </div>
                              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getRateTypeColor(rate.rate_type)}`}>
                                {rate.rate_type.charAt(0).toUpperCase() + rate.rate_type.slice(1)}
                              </span>
                              {getStatusBadge(rate)}
                            </div>

                            {/* Rate Change */}
                            {rateChange !== null && (
                              <div className={`text-sm font-medium mb-2 ${rateChange > 0 ? 'text-green-600' : rateChange < 0 ? 'text-red-600' : 'text-gray-600'}`}>
                                {rateChange > 0 ? '+' : ''}{formatCurrency(rateChange)} 
                                {changePercentage !== null && (
                                  <span className="ml-1">
                                    ({rateChange > 0 ? '+' : ''}{changePercentage.toFixed(1)}%)
                                  </span>
                                )}
                                {rateChange === 0 && ' (No change)'}
                              </div>
                            )}

                            {/* Date Range */}
                            <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
                              <Calendar className="w-4 h-4" />
                              <span>
                                Effective: {formatDate(rate.effective_date)}
                                {rate.end_date && ` - ${formatDate(rate.end_date)}`}
                              </span>
                            </div>

                            {/* Created By */}
                            <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
                              <User className="w-4 h-4" />
                              <span>
                                Set by {rate.created_by.first_name} {rate.created_by.last_name} 
                                on {formatDateTime(rate.created_at)}
                              </span>
                            </div>

                            {/* Notes */}
                            {rate.notes && (
                              <div className="text-sm text-gray-700 bg-gray-100 p-2 rounded">
                                <span className="font-medium">Note: </span>
                                {rate.notes}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="p-4 border-t bg-gray-50">
            <div className="flex justify-between items-center text-sm text-gray-600">
              <span>
                {rateHistory?.rates.length || 0} rate record(s) found
              </span>
              <Button onClick={onClose} variant="outline">
                Close
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}