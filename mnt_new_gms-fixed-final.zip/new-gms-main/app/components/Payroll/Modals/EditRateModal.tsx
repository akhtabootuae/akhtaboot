"use client";

import React, { useState } from "react";
import { Button } from "../../ui/button";
import { Input } from "../../ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "../../ui/card";
import { X, DollarSign, Save, AlertCircle } from "lucide-react";
import { payrollApi } from "../../../../services/api";
import api from "../../../../services/api";
import { PayrollEmployee, UpdateRateData } from "../../../types/payroll";

interface EditRateModalProps {
  employee: PayrollEmployee;
  onClose: () => void;
  onSuccess: () => void;
}

export default function EditRateModal({ employee, onClose, onSuccess }: EditRateModalProps) {
  const [formData, setFormData] = useState<UpdateRateData>({
    daily_rate: employee.payroll_info.current_daily_rate,
    effective_date: new Date().toISOString().split('T')[0], // Today's date in YYYY-MM-DD format
    reason: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (formData.daily_rate <= 0) {
      setError('Daily rate must be greater than 0');
      return;
    }

    if (formData.daily_rate === employee.payroll_info.current_daily_rate) {
      setError('New rate must be different from current rate');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      
      await payrollApi.updateEmployeeRate(employee._id, formData);
      
      // Send notification to admins about rate change
      try {
        const changeAmount = formData.daily_rate - employee.payroll_info.current_daily_rate;
        const changePercentage = ((changeAmount / employee.payroll_info.current_daily_rate) * 100).toFixed(1);
        const changeType = changeAmount > 0 ? 'increased' : 'decreased';
        
        const notificationData = {
          type: "general",
          title: "Employee Rate Change",
          message: `${employee.first_name} ${employee.last_name}'s daily rate has been ${changeType} from AED ${employee.payroll_info.current_daily_rate} to AED ${formData.daily_rate} (${changeAmount > 0 ? '+' : ''}${changePercentage}%). Effective date: ${formData.effective_date}. ${formData.reason ? 'Reason: ' + formData.reason : ''}`,
          recipientType: "admin",
          priority: "medium",
          employeeId: employee._id
        };
        
        await api.post('/api/notifications', notificationData);
      } catch (notifError) {
        console.error('Error sending rate change notification:', notifError);
        // Don't fail the main operation if notification fails
      }
      
      onSuccess();
    } catch (err: any) {
      console.error('Error updating rate:', err);
      setError(err.response?.data?.message || 'Failed to update employee rate');
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (field: keyof UpdateRateData, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    // Clear error when user starts typing
    if (error) setError(null);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-AE', {
      style: 'currency',
      currency: 'AED',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="w-5 h-5" />
            Edit Daily Rate
          </CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="h-6 w-6 p-0"
          >
            <X className="w-4 h-4" />
          </Button>
        </CardHeader>
        
        <CardContent>
          {/* Employee Info */}
          <div className="mb-6 p-3 bg-gray-50 rounded-lg">
            <div className="font-medium text-gray-900">
              {employee.first_name} {employee.last_name}
            </div>
            <div className="text-sm text-gray-600">{employee.speciality}</div>
            <div className="text-sm text-gray-500">
              Current Rate: {formatCurrency(employee.payroll_info.current_daily_rate)}/day
            </div>
          </div>

          {/* Error Display */}
          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
              <AlertCircle className="w-4 h-4" />
              <span className="text-sm">{error}</span>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Daily Rate */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                New Daily Rate (AED) *
              </label>
              <Input
                type="number"
                min="1"
                step="1"
                value={formData.daily_rate}
                onChange={(e) => handleInputChange('daily_rate', parseFloat(e.target.value) || 0)}
                placeholder="Enter daily rate"
                required
                disabled={loading}
              />
            </div>


            {/* Effective Date */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Effective Date *
              </label>
              <Input
                type="date"
                value={formData.effective_date}
                onChange={(e) => handleInputChange('effective_date', e.target.value)}
                required
                disabled={loading}
              />
            </div>

            {/* Reason */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Reason
              </label>
              <textarea
                value={formData.reason}
                onChange={(e) => handleInputChange('reason', e.target.value)}
                placeholder="Reason for rate change (optional)"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none"
                rows={3}
                disabled={loading}
              />
            </div>

            {/* Rate Comparison */}
            {formData.daily_rate !== employee.payroll_info.current_daily_rate && formData.daily_rate > 0 && (
              <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                <div className="text-sm font-medium text-blue-900 mb-1">Rate Change Summary</div>
                <div className="text-sm text-blue-700">
                  <div>Current: {formatCurrency(employee.payroll_info.current_daily_rate)}/day</div>
                  <div>New: {formatCurrency(formData.daily_rate)}/day</div>
                  <div className={`font-medium ${formData.daily_rate > employee.payroll_info.current_daily_rate ? 'text-green-600' : 'text-red-600'}`}>
                    Change: {formData.daily_rate > employee.payroll_info.current_daily_rate ? '+' : ''}
                    {formatCurrency(formData.daily_rate - employee.payroll_info.current_daily_rate)}
                    {' '}({formData.daily_rate > employee.payroll_info.current_daily_rate ? '+' : ''}
                    {(((formData.daily_rate - employee.payroll_info.current_daily_rate) / employee.payroll_info.current_daily_rate) * 100).toFixed(1)}%)
                  </div>
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex gap-3 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                disabled={loading}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={loading || formData.daily_rate <= 0 || formData.daily_rate === employee.payroll_info.current_daily_rate}
                className="flex-1 flex items-center gap-2"
              >
                {loading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    Update Rate
                  </>
                )}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}