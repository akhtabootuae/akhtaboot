"use client";

import React, { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { useRouter } from "next/navigation";
import {
  FaUsers,
  FaTools,
  FaDollarSign,
  FaBox,
  FaUserCheck,
  FaShieldAlt,
  FaPlus,
  FaChevronLeft,
  FaChevronRight,
  FaChevronDown,
  FaChevronUp,
  FaBell,
  FaCalculator,
  FaTachometerAlt,
  FaChartLine,
  FaUser,
  FaCar,
  FaClipboardList,
  FaFileInvoiceDollar,
  FaClock,
  FaReceipt,
  FaChartBar,
  FaWarehouse,
  FaSearch,
  FaUserTie,
  FaUserPlus,
  FaMoneyBillWave,
  FaClipboardCheck,
  FaHistory,
  FaLock,
  FaWrench,
  FaHammer,
  FaComments,
} from "react-icons/fa";
import {
  HiDocumentText,
} from "react-icons/hi";
import {
  MdNotifications,
  MdDashboard,
  MdAnalytics,
} from "react-icons/md";
import { useCollapsed } from "../../context/CollapsedContext";
import { useAuth } from "../../context/AuthContext";
import { useNotifications } from "../../context/NotificationContext";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { usePathname } from "next/navigation";

type SidebarItem = {
  label: string;
  icon: React.ReactNode;
  href?: string;
  children?: Array<{
    label: string;
    href: string;
    icon?: React.ReactNode;
  }>;
};

export default function SideBar() {
  const { collapsed, isMobile, toggle, closeMobile } = useCollapsed();
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);
  const { isAuthenticated, user } = useAuth();
  const { notificationStats } = useNotifications();
  const pathname = usePathname();
  const router = useRouter();
  
  // Don't show sidebar on login page
  if (pathname === '/login') {
    return null;
  }
  
  // Role-based access control
  const userRole = user?.role_name?.toLowerCase();
  const isAdmin = userRole === 'admin';
  const isSupervisor = userRole === 'supervisor';
  const isAccountant = userRole === 'accountant';

  // Define role-based access
  const roleAccess = {
    dashboard: isAdmin || isSupervisor || isAccountant,
    workManagement: isAdmin || isSupervisor, // Only Admin and Supervisor - removed Accountant
    caseManagement: isAdmin || isSupervisor || isAccountant,
    finance: isAdmin || isSupervisor || isAccountant,
    customerManagement: isAdmin || isSupervisor || isAccountant,
    staff: isAdmin || isAccountant, // Admin and Accountant get staff access
    staffReportsOnly: isSupervisor, // Supervisor only gets staff reports
    payroll: isAdmin || isAccountant,
    inventory: isAdmin || isSupervisor || isAccountant,
  };

  // All sections - based on role requirements
  const sections: SidebarItem[] = [
    // Dashboard - Available to all roles
    ...(roleAccess.dashboard ? [{
      label: "Dashboard",
      icon: <FaTachometerAlt className="text-blue-500" />,
      children: [
        { label: "Main Dashboard", href: "/", icon: <MdDashboard className="text-blue-600" /> },
          ...(isAdmin ? [{ label: "Analytics", href: "/kpi", icon: <MdAnalytics className="text-purple-600" /> }] : []), ],
    }] : []),

    // Work Management - Admin & Supervisor only
    ...(roleAccess.workManagement ? [{
      label: "Work Management",
      icon: <FaTools className="text-orange-500" />,
      children: [
        { label: "Car Cards Dashboard", href: "/car_cards", icon: <FaCar className="text-blue-600" /> },
        { label: "Work Orders", href: "/workOrders", icon: <FaClipboardList className="text-orange-600" /> },
        { label: "QA Review", href: "/qa-review", icon: <FaClipboardCheck className="text-green-600" /> },
      ],
    }] : []),

    // Case Management - All roles
    ...(roleAccess.caseManagement ? [{
      label: "Case Management",
      icon: <HiDocumentText className="text-purple-500" />,
      children: [
        { label: "Cases", href: "/cases", icon: <FaClipboardCheck className="text-purple-600" /> },
        ...(isAdmin ? [{ label: "Case Logs", href: "/cases/logs", icon: <FaHistory className="text-purple-600" /> }] : []),
      ],
    }] : []),

    // Finance - All roles
    ...(roleAccess.finance ? [{
      label: "Finance",
      icon: <FaDollarSign className="text-emerald-500" />,
      children: [
        { label: "Invoices", href: "/Invoices", icon: <FaFileInvoiceDollar className="text-green-600" /> },
        { label: "Expenses", href: "/expenses", icon: <FaReceipt className="text-red-600" /> },
        { label: "Financial Reports", href: "/finance", icon: <FaChartBar className="text-indigo-600" /> },
      ],
    }] : []),

    // Customer Management - All roles
    ...(roleAccess.customerManagement ? [{
      label: "Customer Management",
      icon: <FaUsers className="text-green-500" />,
      children: [
        { label: "Customers", href: "/Customers", icon: <FaUser className="text-green-600" /> },
        { label: "Customer Review", href: "/customer-review", icon: <FaClipboardCheck className="text-blue-600" /> },
      ],
    }] : []),

    // Staff - Admin & Accountant get full access
    ...(roleAccess.staff ? [{
      label: "Staff",
      icon: <FaUserCheck className="text-teal-500" />,
      children: [
        { label: "Staff Management", href: "/staff", icon: <FaUserTie className="text-teal-600" /> },
        { label: "Staff Reports", href: "/reports", icon: <FaChartLine className="text-blue-600" /> },
        ...((isAdmin || isAccountant) ? [{ label: "Add New Staff", href: "/register", icon: <FaUserPlus className="text-green-600" /> }] : []),
      ],
    }] : []),

    // Staff Reports Only - For Supervisor (clickable parent)
    ...(roleAccess.staffReportsOnly ? [{
      label: "Staff Reports",
      icon: <FaChartLine className="text-teal-500" />,
      href: "/reports",
    }] : []),

    // Payroll - Admin & Accountant only
    ...(roleAccess.payroll ? [{
      label: "Payroll",
      icon: <FaCalculator className="text-pink-500" />,
      children: [
        { label: "Employee Rates", href: "/payroll/employees", icon: <FaMoneyBillWave className="text-green-600" /> },
        { label: "Dashboard", href: "/payroll", icon: <MdDashboard className="text-pink-600" /> },
        ...(isAdmin ? [
          { label: "Audit Log", href: "/payroll/audit", icon: <FaHistory className="text-gray-600" /> }
        ] : [])
      ],
    }] : []),

    // Inventory - All roles (placed before Settings for admin)
    ...(roleAccess.inventory ? [{
      label: "Inventory",
      icon: <FaBox className="text-indigo-500" />,
      children: [
        { label: "Inventory", href: "/inventory/inventory", icon: <FaSearch className="text-indigo-600" /> },
        { label: "Storage Room", href: "/inventory/storage", icon: <FaWarehouse className="text-gray-600" /> },
      ],
    }] : []),

  ];
    
  return (
    <>
      {/* Mobile Overlay Background */}
      {isMobile && !collapsed && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={closeMobile}
        />
      )}
      
      {/* Sidebar */}
      <aside
        className={`
          ${isMobile 
            ? `fixed top-0 left-0 h-full z-50 transform transition-transform duration-300 ease-in-out
               ${collapsed ? '-translate-x-full' : 'translate-x-0'} w-80`
            : `relative flex flex-col h-screen transition-all duration-300 
               ${collapsed ? "w-24" : "w-72"}`
          }
          bg-white shadow-md text-gray-800 flex flex-col
        `}
      >

      {/* Header with integrated toggle */}
      <div
        className={`flex items-center justify-between border-b transition-all ${
          isMobile ? "p-4" : (collapsed ? "p-3" : "p-4")
        }`}
      >
        <div className="flex items-center justify-center flex-1">
          <Image
            src="/Final-logo.webp"
            alt="Octopus GMS Logo"
            width={isMobile ? 60 : (collapsed ? 40 : 80)}
            height={isMobile ? 60 : (collapsed ? 40 : 80)}
            className="transition-all duration-300"
          />
        </div>
        
        {/* Toggle button for desktop, close button for mobile */}
        <button
          onClick={isMobile ? closeMobile : toggle}
          className="p-2 rounded-lg hover:bg-gray-100 transition-colors duration-200 group"
          aria-label={isMobile ? "Close menu" : "Toggle sidebar"}
        >
          {isMobile ? (
            <FaChevronLeft className="w-4 h-4 text-gray-500 group-hover:text-gray-700 transition-colors" />
          ) : (
            collapsed ? (
              <FaChevronRight className="w-4 h-4 text-gray-500 group-hover:text-gray-700 transition-colors" />
            ) : (
              <FaChevronLeft className="w-4 h-4 text-gray-500 group-hover:text-gray-700 transition-colors" />
            )
          )}
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto px-2 py-4 space-y-1">
        {sections.map((section) => {
          const { label, icon, href, children } = section;
          const isOpen = openDropdown === label;
          const hasChildren = Array.isArray(children);

          const handleSectionClick = () => {
            if (hasChildren) {
              if (collapsed) {
                // When collapsed, navigate to the first child's href
                const firstChild = children[0];
                if (firstChild?.href) {
                  router.push(firstChild.href);
                  if (isMobile) closeMobile(); // Close mobile menu
                }
              } else {
                // When expanded, toggle the dropdown
                setOpenDropdown(isOpen ? null : label);
              }
            } else if (href) {
              // If no children but has href, navigate directly
              router.push(href);
              if (isMobile) closeMobile(); // Close mobile menu
            }
          };

          return (
            <div key={label}>
              <button
                onClick={handleSectionClick}
                className={`flex items-center w-full gap-3 p-2 rounded hover:bg-gray-100 ${collapsed ? "justify-center" : ""}`}
              >
                <span className="w-5 h-5 text-gray-600 relative">
                  {icon}
                  {label === "Notifications" && notificationStats.unread > 0 && (
                    <Badge
                      variant={notificationStats.highPriority > 0 ? "destructive" : "default"}
                      className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center p-0 text-xs"
                    >
                      {notificationStats.unread > 99 ? "99+" : notificationStats.unread}
                    </Badge>
                  )}
                </span>
                {!collapsed && (
                  <>
                    <span className="flex-1 text-base text-left">{label}</span>
                    {hasChildren &&
                      (isOpen ? (
                        <FaChevronUp className="w-4 h-4" />
                      ) : (
                        <FaChevronDown className="w-4 h-4" />
                      ))}
                  </>
                )}
              </button>

              {/* Render children */}
              {!collapsed && isOpen && hasChildren && (
                <div className="ml-8 space-y-1">
                  {children.map((child) => (
                    <Link
                      key={child.label}
                      href={child.href}
                      onClick={isMobile ? closeMobile : undefined}
                      className="flex items-center gap-2 px-2 py-1 rounded text-sm hover:bg-gray-100 transition-colors"
                    >
                      {child.icon && (
                        <span className="w-4 h-4 flex-shrink-0">{child.icon}</span>
                      )}
                      <span>{child.label}</span>
                    </Link>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </nav>

      {/* New Registration */}
      <div className="p-4 border-t">
        <Link href="/new_reg" onClick={isMobile ? closeMobile : undefined}>
          <Button className="flex items-center justify-center w-full gap-2 bg-blue-600 text-white py-2 rounded hover:bg-blue-700">
            <FaPlus className="w-5 h-5" />
            {!collapsed && <span>New Registration</span>}
          </Button>
        </Link>
      </div>
    </aside>
    </>
  );
}