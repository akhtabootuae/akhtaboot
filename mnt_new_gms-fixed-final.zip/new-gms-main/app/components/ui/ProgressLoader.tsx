'use client';

import React from 'react';
import { CheckCircle, Clock, Loader2, AlertCircle, X } from 'lucide-react';

export interface ProgressStep {
  id: string;
  name: string;
  description: string;
  weight: number; // percentage weight (total should be 100)
  estimatedDuration: number; // milliseconds
  status: 'pending' | 'in_progress' | 'completed' | 'error';
}

interface ProgressLoaderProps {
  isVisible: boolean;
  currentStep: ProgressStep | null;
  steps: ProgressStep[];
  totalPercentage: number;
  elapsedTime: number; // milliseconds
  estimatedTimeRemaining: number; // milliseconds
  title: string;
  subtitle?: string;
  error?: string | null;
  onCancel?: () => void;
  onRetry?: () => void;
}

export const ProgressLoader: React.FC<ProgressLoaderProps> = ({
  isVisible,
  currentStep,
  steps,
  totalPercentage,
  elapsedTime,
  estimatedTimeRemaining,
  title,
  subtitle,
  error,
  onCancel,
  onRetry
}) => {
  if (!isVisible) return null;

  const formatTime = (milliseconds: number): string => {
    const seconds = Math.floor(milliseconds / 1000);
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;

    if (minutes > 0) {
      return `${minutes}m ${remainingSeconds}s`;
    }
    return `${remainingSeconds}s`;
  };

  const getStepIcon = (step: ProgressStep) => {
    switch (step.status) {
      case 'completed':
        return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'in_progress':
        return <Loader2 className="h-5 w-5 text-blue-600 animate-spin" />;
      case 'error':
        return <AlertCircle className="h-5 w-5 text-red-600" />;
      default:
        return <div className="h-5 w-5 rounded-full border-2 border-gray-300" />;
    }
  };

  const circumference = 2 * Math.PI * 45; // radius = 45
  const strokeDasharray = circumference;
  const strokeDashoffset = circumference - (totalPercentage / 100) * circumference;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white p-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold">{title}</h2>
              {subtitle && (
                <p className="text-blue-100 text-sm mt-1">{subtitle}</p>
              )}
            </div>
            {onCancel && !error && (
              <button
                onClick={onCancel}
                className="p-2 hover:bg-white/10 rounded-lg transition-colors"
                title="Cancel operation"
              >
                <X className="h-5 w-5" />
              </button>
            )}
          </div>
        </div>

        {/* Progress Circle and Percentage */}
        <div className="p-8 text-center">
          <div className="relative inline-flex items-center justify-center">
            <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 100 100">
              {/* Background circle */}
              <circle
                cx="50"
                cy="50"
                r="45"
                stroke="currentColor"
                strokeWidth="4"
                fill="transparent"
                className="text-gray-200"
              />
              {/* Progress circle */}
              <circle
                cx="50"
                cy="50"
                r="45"
                stroke="currentColor"
                strokeWidth="4"
                fill="transparent"
                strokeDasharray={strokeDasharray}
                strokeDashoffset={strokeDashoffset}
                className={error ? "text-red-500" : "text-blue-500"}
                style={{
                  transition: 'stroke-dashoffset 0.5s ease-in-out',
                }}
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                {error ? (
                  <AlertCircle className="h-8 w-8 text-red-500 mx-auto mb-1" />
                ) : (
                  <div className="text-2xl font-bold text-gray-900">
                    {Math.round(totalPercentage)}%
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Error Message */}
        {error && (
          <div className="px-6 pb-4">
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <div className="flex items-start">
                <AlertCircle className="h-5 w-5 text-red-600 mt-0.5 mr-3 flex-shrink-0" />
                <div className="flex-1">
                  <h4 className="text-sm font-medium text-red-800 mb-1">
                    Operation Failed
                  </h4>
                  <p className="text-sm text-red-700">{error}</p>
                </div>
              </div>
              {onRetry && (
                <div className="mt-3 flex justify-end">
                  <button
                    onClick={onRetry}
                    className="bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-red-700 transition-colors"
                  >
                    Retry
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Current Step and Status */}
        {!error && currentStep && (
          <div className="px-6 pb-4">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-center">
                <Loader2 className="h-5 w-5 text-blue-600 animate-spin mr-3" />
                <div>
                  <h4 className="text-sm font-medium text-blue-900">
                    {currentStep.name}
                  </h4>
                  <p className="text-sm text-blue-700">
                    {currentStep.description}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Time Information */}
        {!error && (
          <div className="px-6 pb-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center">
                <Clock className="h-5 w-5 text-gray-500 mx-auto mb-1" />
                <div className="text-sm text-gray-600">Elapsed</div>
                <div className="text-sm font-medium text-gray-900">
                  {formatTime(elapsedTime)}
                </div>
              </div>
              <div className="text-center">
                <Clock className="h-5 w-5 text-gray-500 mx-auto mb-1" />
                <div className="text-sm text-gray-600">Remaining</div>
                <div className="text-sm font-medium text-gray-900">
                  {estimatedTimeRemaining > 0 ? formatTime(estimatedTimeRemaining) : 'Calculating...'}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Steps List */}
        <div className="px-6 pb-6">
          <div className="border-t pt-4">
            <h4 className="text-sm font-medium text-gray-700 mb-3">Progress Steps</h4>
            <div className="space-y-2 max-h-40 overflow-y-auto">
              {steps.map((step, index) => (
                <div
                  key={step.id}
                  className={`flex items-center p-2 rounded-lg transition-colors ${
                    step.status === 'in_progress'
                      ? 'bg-blue-50 border border-blue-200'
                      : step.status === 'completed'
                      ? 'bg-green-50'
                      : step.status === 'error'
                      ? 'bg-red-50'
                      : 'bg-gray-50'
                  }`}
                >
                  <div className="mr-3">
                    {getStepIcon(step)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-gray-900 truncate">
                      {step.name}
                    </div>
                    {step.status === 'in_progress' && (
                      <div className="text-xs text-blue-600">In progress...</div>
                    )}
                    {step.status === 'completed' && (
                      <div className="text-xs text-green-600">Completed</div>
                    )}
                    {step.status === 'error' && (
                      <div className="text-xs text-red-600">Failed</div>
                    )}
                  </div>
                  <div className="text-xs text-gray-500 ml-2">
                    {step.weight}%
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProgressLoader;