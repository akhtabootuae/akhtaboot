'use client';

import React from 'react';
import { useAuth } from '@/app/context/AuthContext';

// Types for role guard configuration
interface RoleGuardProps {
  children: React.ReactNode;
  allowedRoles?: string[]; // Array of role names that can access the content
  requiredPermissions?: string[]; // Array of permission names that are required
  requireAllPermissions?: boolean; // If true, user must have ALL permissions, if false, just one
  adminOverride?: boolean; // If true, admins bypass all restrictions (default: true)
  fallbackComponent?: React.ReactNode; // Component to show when access is denied
  showFallback?: boolean; // Whether to show fallback or just hide content (default: false)
  onAccessDenied?: () => void; // Callback when access is denied
}

/**
 * RoleGuard Component
 * 
 * Controls visibility of content based on user roles and permissions.
 * 
 * @example
 * // Only show for admins
 * <RoleGuard allowedRoles={['Admin']}>
 *   <AdminPanel />
 * </RoleGuard>
 * 
 * @example
 * // Show for multiple roles
 * <RoleGuard allowedRoles={['Admin', 'Supervisor']}>
 *   <ManagementPanel />
 * </RoleGuard>
 * 
 * @example
 * // Require specific permission
 * <RoleGuard requiredPermissions={['payroll_view']}>
 *   <PayrollData />
 * </RoleGuard>
 * 
 * @example
 * // Require multiple permissions (must have all)
 * <RoleGuard 
 *   requiredPermissions={['payroll_view', 'payroll_manage_rates']} 
 *   requireAllPermissions={true}
 * >
 *   <PayrollRateEditor />
 * </RoleGuard>
 * 
 * @example
 * // Show fallback component when denied
 * <RoleGuard 
 *   allowedRoles={['Admin']} 
 *   showFallback={true}
 *   fallbackComponent={<div>Access Denied</div>}
 * >
 *   <SecureContent />
 * </RoleGuard>
 */
export const RoleGuard: React.FC<RoleGuardProps> = ({
  children,
  allowedRoles = [],
  requiredPermissions = [],
  requireAllPermissions = false,
  adminOverride = true,
  fallbackComponent = null,
  showFallback = false,
  onAccessDenied
}) => {
  const { user, isAuthenticated } = useAuth();

  // If not authenticated, deny access
  if (!isAuthenticated || !user) {
    if (onAccessDenied) onAccessDenied();
    return showFallback ? (fallbackComponent || null) : null;
  }

  // Admin override - admins bypass all restrictions if enabled
  if (adminOverride && user.role_name?.toLowerCase() === 'admin') {
    return <>{children}</>;
  }

  // Check role-based access
  const hasRoleAccess = allowedRoles.length === 0 || 
    allowedRoles.some(role => user.role_name?.toLowerCase() === role.toLowerCase());

  // Check permission-based access
  let hasPermissionAccess = true;
  if (requiredPermissions.length > 0) {
    const userPermissions = user.permissions || [];
    
    if (requireAllPermissions) {
      // User must have ALL required permissions
      hasPermissionAccess = requiredPermissions.every(permission =>
        userPermissions.some(p => 
          p.permission_name === permission && p.granted === true
        )
      );
    } else {
      // User must have at least ONE of the required permissions
      hasPermissionAccess = requiredPermissions.some(permission =>
        userPermissions.some(p => 
          p.permission_name === permission && p.granted === true
        )
      );
    }
  }

  // Grant access if both role and permission checks pass
  const hasAccess = hasRoleAccess && hasPermissionAccess;

  if (!hasAccess) {
    if (onAccessDenied) onAccessDenied();
    return showFallback ? (fallbackComponent || null) : null;
  }

  return <>{children}</>;
};

// Convenience wrapper for admin-only content
export const AdminOnly: React.FC<{
  children: React.ReactNode;
  fallbackComponent?: React.ReactNode;
  showFallback?: boolean;
}> = ({ children, fallbackComponent, showFallback = false }) => (
  <RoleGuard 
    allowedRoles={['Admin']} 
    fallbackComponent={fallbackComponent}
    showFallback={showFallback}
  >
    {children}
  </RoleGuard>
);

// Convenience wrapper for supervisor+ content
export const SupervisorAndUp: React.FC<{
  children: React.ReactNode;
  fallbackComponent?: React.ReactNode;
  showFallback?: boolean;
}> = ({ children, fallbackComponent, showFallback = false }) => (
  <RoleGuard 
    allowedRoles={['Admin', 'Supervisor']} 
    fallbackComponent={fallbackComponent}
    showFallback={showFallback}
  >
    {children}
  </RoleGuard>
);

// Convenience wrapper for accountant-only content (includes Admin)
export const AccountantOnly: React.FC<{
  children: React.ReactNode;
  fallbackComponent?: React.ReactNode;
  showFallback?: boolean;
}> = ({ children, fallbackComponent, showFallback = false }) => (
  <RoleGuard 
    allowedRoles={['Admin', 'Accountant']} 
    fallbackComponent={fallbackComponent}
    showFallback={showFallback}
  >
    {children}
  </RoleGuard>
);

// Convenience wrapper for finance roles (Admin, Supervisor, Accountant)
export const FinanceAccess: React.FC<{
  children: React.ReactNode;
  fallbackComponent?: React.ReactNode;
  showFallback?: boolean;
}> = ({ children, fallbackComponent, showFallback = false }) => (
  <RoleGuard 
    allowedRoles={['Admin', 'Supervisor', 'Accountant']} 
    fallbackComponent={fallbackComponent}
    showFallback={showFallback}
  >
    {children}
  </RoleGuard>
);

// Convenience wrapper for permission-based content
export const PermissionGuard: React.FC<{
  children: React.ReactNode;
  permissions: string[];
  requireAll?: boolean;
  fallbackComponent?: React.ReactNode;
  showFallback?: boolean;
}> = ({ children, permissions, requireAll = false, fallbackComponent, showFallback = false }) => (
  <RoleGuard 
    requiredPermissions={permissions}
    requireAllPermissions={requireAll}
    fallbackComponent={fallbackComponent}
    showFallback={showFallback}
  >
    {children}
  </RoleGuard>
);

// Hook for checking access programmatically
export const useRoleAccess = () => {
  const { user, isAuthenticated } = useAuth();

  const hasRole = (roles: string | string[]): boolean => {
    if (!isAuthenticated || !user) return false;
    
    const roleArray = Array.isArray(roles) ? roles : [roles];
    return roleArray.some(role => 
      user.role_name?.toLowerCase() === role.toLowerCase()
    );
  };

  const hasPermission = (permissions: string | string[], requireAll = false): boolean => {
    if (!isAuthenticated || !user) return false;
    
    // Admin override
    if (user.role_name?.toLowerCase() === 'admin') return true;
    
    const permissionArray = Array.isArray(permissions) ? permissions : [permissions];
    const userPermissions = user.permissions || [];
    
    if (requireAll) {
      return permissionArray.every(permission =>
        userPermissions.some(p => 
          p.permission_name === permission && p.granted === true
        )
      );
    } else {
      return permissionArray.some(permission =>
        userPermissions.some(p => 
          p.permission_name === permission && p.granted === true
        )
      );
    }
  };

  const isAdmin = (): boolean => {
    return hasRole('Admin');
  };

  const canAccess = (config: {
    roles?: string[];
    permissions?: string[];
    requireAllPermissions?: boolean;
    adminOverride?: boolean;
  }): boolean => {
    if (!isAuthenticated || !user) return false;
    
    const { roles = [], permissions = [], requireAllPermissions = false, adminOverride = true } = config;
    
    // Admin override
    if (adminOverride && user.role_name?.toLowerCase() === 'admin') return true;
    
    // Check roles
    const hasRoleAccess = roles.length === 0 || hasRole(roles);
    
    // Check permissions
    const hasPermissionAccess = permissions.length === 0 || hasPermission(permissions, requireAllPermissions);
    
    return hasRoleAccess && hasPermissionAccess;
  };

  return {
    hasRole,
    hasPermission,
    isAdmin,
    canAccess,
    user,
    isAuthenticated
  };
};

export default RoleGuard;
