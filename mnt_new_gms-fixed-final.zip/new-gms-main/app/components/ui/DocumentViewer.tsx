'use client';

import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/app/components/ui/button';
import { 
  X,
  ZoomIn,
  ZoomOut,
  RotateCw,
  Move,
  Maximize,
  Minimize,
  RotateCcw,
  Download,
  FileText,
  Square
} from 'lucide-react';

interface DocumentViewerProps {
  isOpen: boolean;
  onClose: () => void;
  documentUrl: string;
  filename: string;
  onDownload?: () => void;
}

interface ViewerState {
  zoom: number;
  rotation: number;
  panX: number;
  panY: number;
  isDragging: boolean;
  isFullscreen: boolean;
}

const DocumentViewer: React.FC<DocumentViewerProps> = ({
  isOpen,
  onClose,
  documentUrl,
  filename,
  onDownload
}) => {
  const [viewerState, setViewerState] = useState<ViewerState>({
    zoom: 1,
    rotation: 0,
    panX: 0,
    panY: 0,
    isDragging: false,
    isFullscreen: false
  });
  
  const imageRef = useRef<HTMLImageElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [imageLoaded, setImageLoaded] = useState(false);

  // Calculate zoom to fit image in container - enhanced for better auto-alignment
  const calculateFitToScreenZoom = (): number => {
    if (!imageRef.current || !containerRef.current) return 1;
    
    const container = containerRef.current;
    const image = imageRef.current;
    
    // Get actual container dimensions
    const containerRect = container.getBoundingClientRect();
    const containerWidth = containerRect.width;
    const containerHeight = containerRect.height;
    
    // Get natural image dimensions
    const imageWidth = image.naturalWidth;
    const imageHeight = image.naturalHeight;
    
    if (imageWidth === 0 || imageHeight === 0 || containerWidth === 0 || containerHeight === 0) {
      return 1;
    }
    
    // Account for rotation
    let effectiveWidth = imageWidth;
    let effectiveHeight = imageHeight;
    
    if (viewerState.rotation === 90 || viewerState.rotation === 270) {
      effectiveWidth = imageHeight;
      effectiveHeight = imageWidth;
    }
    
    // Add more generous padding to ensure image doesn't touch edges
    const paddingX = 60; // 30px padding on each side
    const paddingY = 60; // 30px padding on top and bottom
    
    const availableWidth = containerWidth - paddingX;
    const availableHeight = containerHeight - paddingY;
    
    // Calculate zoom to fit both width and height, use the smaller ratio
    const zoomX = availableWidth / effectiveWidth;
    const zoomY = availableHeight / effectiveHeight;
    
    // Use the smaller ratio to ensure the entire image fits
    const fitZoom = Math.min(zoomX, zoomY);
    
    // Ensure zoom is within reasonable bounds and prefer slightly smaller for better visibility
    return Math.max(0.05, Math.min(3, fitZoom * 0.95));
  };

  // Reset viewer state when modal opens/closes
  useEffect(() => {
    if (isOpen) {
      setViewerState({
        zoom: 1,
        rotation: 0,
        panX: 0,
        panY: 0,
        isDragging: false,
        isFullscreen: false
      });
      setImageLoaded(false);
    }
  }, [isOpen]);

  // Auto-fit zoom when image loads - enhanced for better alignment
  useEffect(() => {
    if (imageLoaded && imageRef.current && containerRef.current) {
      // Multiple attempts to ensure proper fitting
      const autoFit = () => {
        const fitZoom = calculateFitToScreenZoom();
        setViewerState(prev => ({ 
          ...prev, 
          zoom: fitZoom,
          panX: 0,
          panY: 0
        }));
      };

      // Immediate attempt
      autoFit();
      
      // Delayed attempts to handle layout settling
      setTimeout(autoFit, 50);
      setTimeout(autoFit, 150);
      setTimeout(autoFit, 300);
    }
  }, [imageLoaded]);

  // Enhanced image load handler
  const handleImageLoad = () => {
    setImageLoaded(true);
    // Additional delay to ensure DOM has updated
    setTimeout(() => {
      if (imageRef.current && containerRef.current) {
        const fitZoom = calculateFitToScreenZoom();
        setViewerState(prev => ({ 
          ...prev, 
          zoom: fitZoom,
          panX: 0,
          panY: 0
        }));
      }
    }, 100);
  };

  // Recalculate fit when window resizes
  useEffect(() => {
    if (!isOpen) return;
    
    const handleResize = () => {
      if (imageLoaded && imageRef.current && containerRef.current) {
        setTimeout(() => {
          const fitZoom = calculateFitToScreenZoom();
          setViewerState(prev => ({ 
            ...prev, 
            zoom: fitZoom,
            panX: 0,
            panY: 0
          }));
        }, 100);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [isOpen, imageLoaded]);

  const handleZoomIn = () => {
    setViewerState(prev => ({ ...prev, zoom: Math.min(prev.zoom * 1.25, 5) }));
  };

  const handleZoomOut = () => {
    setViewerState(prev => ({ ...prev, zoom: Math.max(prev.zoom / 1.25, 0.1) }));
  };

  const handleRotateClockwise = () => {
    setViewerState(prev => ({ ...prev, rotation: (prev.rotation + 90) % 360 }));
  };

  const handleRotateCounterclockwise = () => {
    setViewerState(prev => ({ ...prev, rotation: (prev.rotation - 90 + 360) % 360 }));
  };

  const handleResetView = () => {
    const fitZoom = calculateFitToScreenZoom();
    setViewerState(prev => ({ ...prev, zoom: fitZoom, rotation: 0, panX: 0, panY: 0 }));
  };

  const handleFitToScreen = () => {
    const fitZoom = calculateFitToScreenZoom();
    setViewerState(prev => ({ ...prev, zoom: fitZoom, panX: 0, panY: 0 }));
  };

  const toggleFullscreen = () => {
    setViewerState(prev => ({ ...prev, isFullscreen: !prev.isFullscreen }));
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button === 0) { // Left click only
      setViewerState(prev => ({ ...prev, isDragging: true }));
      setDragStart({ x: e.clientX - viewerState.panX, y: e.clientY - viewerState.panY });
      e.preventDefault();
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (viewerState.isDragging) {
      setViewerState(prev => ({
        ...prev,
        panX: e.clientX - dragStart.x,
        panY: e.clientY - dragStart.y
      }));
    }
  };

  const handleMouseUp = () => {
    setViewerState(prev => ({ ...prev, isDragging: false }));
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const delta = e.deltaY > 0 ? 0.95 : 1.05;
    setViewerState(prev => ({ ...prev, zoom: Math.max(0.1, Math.min(5, prev.zoom * delta)) }));
  };

  const handleDownload = () => {
    if (onDownload) {
      onDownload();
    } else if (documentUrl) {
      const link = document.createElement('a');
      link.href = documentUrl;
      link.download = filename;
      link.target = '_blank';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;
      
      switch (e.key) {
        case '+':
        case '=':
          handleZoomIn();
          break;
        case '-':
          handleZoomOut();
          break;
        case 'r':
          handleRotateClockwise();
          break;
        case 'R':
          handleRotateCounterclockwise();
          break;
        case '0':
          handleResetView();
          break;
        case 'q':
          handleFitToScreen();
          break;
        case 'a':
        case 'A':
          handleFitToScreen(); // Auto-align the image
          break;
        case 'f':
          toggleFullscreen();
          break;
        case 'Escape':
          if (viewerState.isFullscreen) {
            toggleFullscreen();
          } else {
            onClose();
          }
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, viewerState.isFullscreen]);

  if (!isOpen) return null;

  const isPdf = filename.toLowerCase().endsWith('.pdf');

  return (
    <div className={`fixed inset-0 z-50 ${viewerState.isFullscreen ? 'bg-black' : 'bg-black bg-opacity-75'}`}>
      {/* Backdrop */}
      {!viewerState.isFullscreen && (
        <div 
          className="absolute inset-0"
          onClick={onClose}
        ></div>
      )}
      
      {/* Modal Content */}
      <div className={`relative ${viewerState.isFullscreen ? 'h-full w-full' : 'max-w-4xl max-h-[80vh] mx-auto mt-8 bg-white rounded-lg shadow-xl'} flex flex-col`}>
        {/* Header with controls */}
        <div className={`flex items-center justify-between p-4 ${viewerState.isFullscreen ? 'bg-black text-white' : 'bg-white border-b'}`}>
          <div>
            <h3 className="text-lg font-semibold">
              Document Viewer
            </h3>
            <p className={`text-sm ${viewerState.isFullscreen ? 'text-gray-300' : 'text-gray-600'}`}>
              {filename}
            </p>
          </div>
          
          {/* Viewer Controls */}
          <div className="flex items-center space-x-2">
            {!isPdf && (
              <>
                <div className="flex items-center space-x-1 border-r pr-2">
                  <Button
                    onClick={handleZoomOut}
                    variant="outline"
                    size="sm"
                    className={viewerState.isFullscreen ? 'bg-gray-800 text-white border-gray-600 hover:bg-gray-700' : ''}
                    title="Zoom Out (-)"
                  >
                    <ZoomOut className="w-4 h-4" />
                  </Button>
                  <span className={`text-sm px-2 ${viewerState.isFullscreen ? 'text-white' : 'text-gray-600'}`}>
                    {Math.round(viewerState.zoom * 100)}%
                  </span>
                  <Button
                    onClick={handleZoomIn}
                    variant="outline"
                    size="sm"
                    className={viewerState.isFullscreen ? 'bg-gray-800 text-white border-gray-600 hover:bg-gray-700' : ''}
                    title="Zoom In (+)"
                  >
                    <ZoomIn className="w-4 h-4" />
                  </Button>
                </div>
                
                <div className="flex items-center space-x-1 border-r pr-2">
                  <Button
                    onClick={handleRotateCounterclockwise}
                    variant="outline"
                    size="sm"
                    className={viewerState.isFullscreen ? 'bg-gray-800 text-white border-gray-600 hover:bg-gray-700' : ''}
                    title="Rotate Left (Shift+R)"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </Button>
                  <Button
                    onClick={handleRotateClockwise}
                    variant="outline"
                    size="sm"
                    className={viewerState.isFullscreen ? 'bg-gray-800 text-white border-gray-600 hover:bg-gray-700' : ''}
                    title="Rotate Right (R)"
                  >
                    <RotateCw className="w-4 h-4" />
                  </Button>
                </div>
                
                <div className="flex items-center space-x-1 border-r pr-2">
                  <Button
                    onClick={handleResetView}
                    variant="outline"
                    size="sm"
                    className={viewerState.isFullscreen ? 'bg-gray-800 text-white border-gray-600 hover:bg-gray-700' : ''}
                    title="Reset View (0)"
                  >
                    <Move className="w-4 h-4" />
                  </Button>
                  <Button
                    onClick={handleFitToScreen}
                    variant="outline"
                    size="sm"
                    className={viewerState.isFullscreen ? 'bg-gray-800 text-white border-gray-600 hover:bg-gray-700' : ''}
                    title="Fit to Screen"
                  >
                    <Square className="w-4 h-4" />
                  </Button>
                  <Button
                    onClick={toggleFullscreen}
                    variant="outline"
                    size="sm"
                    className={viewerState.isFullscreen ? 'bg-gray-800 text-white border-gray-600 hover:bg-gray-700' : ''}
                    title="Toggle Fullscreen (F)"
                  >
                    {viewerState.isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
                  </Button>
                </div>
              </>
            )}
            
            <div className="flex items-center space-x-1">
              <Button
                onClick={handleDownload}
                variant="outline"
                size="sm"
                className={viewerState.isFullscreen ? 'bg-gray-800 text-white border-gray-600 hover:bg-gray-700' : ''}
                title="Download"
              >
                <Download className="w-4 h-4" />
              </Button>
              <Button
                onClick={onClose}
                variant="outline"
                size="sm"
                className={viewerState.isFullscreen ? 'bg-gray-800 text-white border-gray-600 hover:bg-gray-700' : ''}
                title="Close (Esc)"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
        
        {/* Document Container */}
        <div 
          ref={containerRef}
          className={`flex-1 overflow-hidden relative ${viewerState.isFullscreen ? 'bg-black' : 'bg-gray-50'} ${!isPdf && viewerState.isDragging ? 'cursor-grabbing' : !isPdf ? 'cursor-grab' : ''} flex items-center justify-center`}
          onMouseDown={!isPdf ? handleMouseDown : undefined}
          onMouseMove={!isPdf ? handleMouseMove : undefined}
          onMouseUp={!isPdf ? handleMouseUp : undefined}
          onMouseLeave={!isPdf ? handleMouseUp : undefined}
          onWheel={!isPdf ? handleWheel : undefined}
        >
          {isPdf ? (
            <div className="w-full h-full flex items-center justify-center">
              <div className="text-center">
                <FileText className={`w-16 h-16 mx-auto mb-4 ${viewerState.isFullscreen ? 'text-gray-400' : 'text-gray-400'}`} />
                <p className={`mb-2 ${viewerState.isFullscreen ? 'text-white' : 'text-gray-600'}`}>PDF Preview</p>
                <p className={`text-sm ${viewerState.isFullscreen ? 'text-gray-300' : 'text-gray-500'}`}>Use download to view the full PDF</p>
              </div>
            </div>
          ) : (
            <img
              ref={imageRef}
              src={documentUrl}
              alt={filename}
              className="block transition-transform duration-200 ease-out select-none"
              style={{
                transform: `scale(${viewerState.zoom}) rotate(${viewerState.rotation}deg) translate(${viewerState.panX / viewerState.zoom}px, ${viewerState.panY / viewerState.zoom}px)`,
                transformOrigin: 'center center',
                maxWidth: 'none',
                maxHeight: 'none'
              }}
              onLoad={handleImageLoad}
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                target.style.display = 'none';
                const parent = target.parentElement;
                if (parent) {
                  parent.innerHTML = `
                    <div class="text-center">
                      <div class="w-16 h-16 mx-auto mb-4 bg-gray-200 rounded-lg flex items-center justify-center">
                        <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                        </svg>
                      </div>
                      <p class="${viewerState.isFullscreen ? 'text-white' : 'text-gray-600'} mb-2">Unable to display image</p>
                      <p class="text-sm ${viewerState.isFullscreen ? 'text-gray-300' : 'text-gray-500'}">The image may be in a different format or location. Use download to access the file.</p>
                    </div>
                  `;
                }
              }}
              draggable={false}
            />
          )}
          
          {/* Keyboard shortcuts info */}
          {viewerState.isFullscreen && !isPdf && (
            <div className="absolute bottom-4 left-4 bg-black bg-opacity-50 text-white text-xs p-2 rounded">
              <div>Shortcuts: +/- zoom, R rotate, 0 reset, Q/A fit, F fullscreen, Esc close</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DocumentViewer;
