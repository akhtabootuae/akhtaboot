'use client';

import React from 'react';
import Link from 'next/link';

interface Invoice {
  invoice_id: string;
  invoice_number: string;
  customer: string;
  customer_id: string;
  license_plate: string;
  car_info: string;
  total: number;
  price_before_vat: number;
  vat_amount: number;
  vat_percentage: number;
  is_taxed: boolean;
  total_paid: number;
  remaining_balance: number;
  payment_status: 'PAID' | 'PARTIAL' | 'UNPAID';
  payment_count: number;
  created_at: string;
  invoice_date: string;
  vehicle_id: number;
  work_order_id: string;
}

interface InvoiceRowProps {
  invoice: Invoice;
}

export default function InvoiceRow({ invoice }: InvoiceRowProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-AE', {
      style: 'currency',
      currency: 'AED'
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    try {
      return new Date(dateString).toLocaleDateString('en-AU', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      });
    } catch {
      return 'N/A';
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'PAID':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
            ✅ Paid
          </span>
        );
      case 'PARTIAL':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
            🟡 Partial
          </span>
        );
      case 'UNPAID':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
            ❌ Unpaid
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
            {status}
          </span>
        );
    }
  };

  // Calculate if payment is overdue based on invoice date (using a 30-day term as default)
  const invoiceDate = new Date(invoice.invoice_date);
  const dueDate = new Date(invoiceDate.getTime() + (30 * 24 * 60 * 60 * 1000)); // 30 days from invoice date
  const isOverdue = invoice.payment_status !== 'PAID' && dueDate < new Date();

  return (
    <tr className="hover:bg-gray-50 transition-colors">
      {/* Invoice Number */}
      <td className="px-6 py-4 whitespace-nowrap">
        <div className="flex flex-col">
          <div className="text-sm font-medium text-blue-600">
            {invoice.invoice_number}
          </div>
          <div className="text-xs text-gray-500">
            {formatDate(invoice.created_at)}
          </div>
        </div>
      </td>

      {/* Customer */}
      <td className="px-6 py-4">
        <div className="flex flex-col space-y-1">
          <div className="text-sm font-medium text-gray-900">
            {invoice.customer}
          </div>
          <div className="text-xs text-gray-500 leading-relaxed" style={{ wordBreak: 'break-word', maxWidth: '250px' }}>
            {invoice.car_info}
          </div>
        </div>
      </td>

      {/* License Plate */}
      <td className="px-6 py-4 whitespace-nowrap">
        <div className="text-sm text-gray-900 font-mono bg-gray-100 px-2 py-1 rounded text-center">
          {invoice.license_plate}
        </div>
      </td>

      {/* Amount */}
      <td className="px-6 py-4 whitespace-nowrap">
        <div className="flex flex-col">
          <div className="text-sm font-semibold text-gray-900">
            {formatCurrency(invoice.total)}
          </div>
          {invoice.remaining_balance > 0 && (
            <div className="text-xs text-red-600">
              Balance: {formatCurrency(invoice.remaining_balance)}
            </div>
          )}
        </div>
      </td>

      {/* Payment Status */}
      <td className="px-6 py-4 whitespace-nowrap">
        {getStatusBadge(invoice.payment_status)}
      </td>

      {/* Due Date */}
      <td className="px-6 py-4 whitespace-nowrap">
        <div className={`text-sm ${isOverdue ? 'text-red-600 font-medium' : 'text-gray-900'}`}>
          {formatDate(dueDate.toISOString())}
          {isOverdue && (
            <div className="text-xs text-red-500 font-medium">
              Overdue
            </div>
          )}
        </div>
      </td>

      {/* Actions */}
      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
        <Link
          href={`/Invoices/${invoice.invoice_id}`}
          className="inline-flex items-center px-3 py-1.5 bg-blue-600 text-white text-xs font-medium rounded-md hover:bg-blue-700 transition-colors"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1.5">
            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
            <circle cx="12" cy="12" r="3"></circle>
          </svg>
          View Details
        </Link>
      </td>
    </tr>
  );
}
