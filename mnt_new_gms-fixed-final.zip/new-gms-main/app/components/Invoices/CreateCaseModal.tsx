import React, { useState } from 'react';
import { Case, CreateCaseData, CasePriority } from '@/app/types/case';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Card } from '@/app/components/ui/card';
import { X } from 'lucide-react';
import { caseApi } from '@/services/api';
import toast from 'react-hot-toast';

interface CreateCaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCaseCreated: (newCase: Case) => void;
  invoiceId: string;
  invoiceNumber?: string;
}

export default function CreateCaseModal({ 
  isOpen, 
  onClose, 
  onCaseCreated, 
  invoiceId,
  invoiceNumber 
}: CreateCaseModalProps) {
  const [formData, setFormData] = useState<CreateCaseData>({
    title: '',
    description: '',
    priority: 'medium',
    status: 'open',
    tags: [],
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.title.trim() || !formData.description.trim()) {
      toast.error('Title and description are required');
      return;
    }

    if (formData.title.length < 3 || formData.title.length > 200) {
      toast.error('Title must be between 3 and 200 characters');
      return;
    }

    if (formData.description.length < 10 || formData.description.length > 2000) {
      toast.error('Description must be between 10 and 2000 characters');
      return;
    }

    setIsSubmitting(true);
    try {
      const caseData = {
        title: formData.title.trim(),
        description: formData.description.trim(),
        priority: formData.priority,
        status: formData.status,
        tags: formData.tags || [],
        linkedTo: {
          type: 'invoice',
          id: invoiceId,
          reference: invoiceNumber || invoiceId
        }
      };

      const response = await caseApi.createCase(caseData) as any;

      if (response && response.success && response.data) {
        onCaseCreated(response.data as Case);
        toast.success('Case created successfully');
        
        // Reset form
        setFormData({
          title: '',
          description: '',
          priority: 'medium',
          status: 'open',
          tags: [],
        });
        
        onClose();
      } else {
        throw new Error('Failed to create case');
      }
    } catch (error: any) {
      console.error('Error creating case:', error);
      const errorMessage = error.response?.data?.message || error.message || 'Failed to create case';
      toast.error(errorMessage);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (field: keyof CreateCaseData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          {/* Header */}
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold text-gray-900">
              Create New Case
            </h2>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="h-8 w-8 p-0"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>

          {/* Invoice Reference */}
          <div className="mb-4 p-3 bg-blue-50 rounded-lg">
            <p className="text-sm text-blue-700">
              <strong>Linked to Invoice:</strong> {invoiceNumber || invoiceId}
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Title */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Case Title *
              </label>
              <Input
                type="text"
                value={formData.title}
                onChange={(e) => handleInputChange('title', e.target.value)}
                placeholder="Enter case title..."
                className="w-full"
                maxLength={200}
                required
              />
              <p className="text-xs text-gray-500 mt-1">
                {formData.title.length}/200 characters
              </p>
            </div>

            {/* Description */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Description *
              </label>
              <textarea
                value={formData.description}
                onChange={(e) => handleInputChange('description', e.target.value)}
                placeholder="Describe the issue or request in detail..."
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                rows={4}
                maxLength={2000}
                required
              />
              <p className="text-xs text-gray-500 mt-1">
                {formData.description.length}/2000 characters
              </p>
            </div>

            {/* Priority */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Priority
              </label>
              <select
                value={formData.priority}
                onChange={(e) => handleInputChange('priority', e.target.value as CasePriority)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
                <option value="urgent">Urgent</option>
              </select>
            </div>

            {/* Form Actions */}
            <div className="flex gap-3 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                className="flex-1"
                disabled={isSubmitting}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="flex-1"
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Creating...' : 'Create Case'}
              </Button>
            </div>
          </form>
        </div>
      </Card>
    </div>
  );
}
