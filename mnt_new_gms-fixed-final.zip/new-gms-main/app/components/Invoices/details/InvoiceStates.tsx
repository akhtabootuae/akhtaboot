import React from 'react';

interface LoadingStateProps {}

export const LoadingState: React.FC<LoadingStateProps> = () => {
  return (
    <div className="text-center py-12 bg-white rounded-lg shadow">
      <div className="inline-block h-10 w-10 animate-spin rounded-full border-4 border-solid border-gray-300 border-r-gray-900"></div>
      <p className="mt-3 text-gray-700 font-medium">Loading invoice details...</p>
    </div>
  );
};

interface ErrorStateProps {
  error: string;
}

export const ErrorState: React.FC<ErrorStateProps> = ({ error }) => {
  return (
    <div className="bg-red-50 border-l-4 border-red-500 p-4 rounded-md shadow">
      <div className="flex items-center">
        <div className="flex-shrink-0 text-red-500">
          <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
          </svg>
        </div>
        <div className="ml-3">
          <p className="text-red-700 font-medium">{error}</p>
        </div>
      </div>
    </div>
  );
};
