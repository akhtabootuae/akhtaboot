# Invoice Details Components

This folder contains the refactored components for the Invoice Details page. The large monolithic page has been split into smaller, manageable, and reusable components.

## Component Structure

### Core Components

- **`InvoiceDataProcessor.ts`** - Handles all invoice data processing, normalization, and API calls for fetching related data (customer, vehicle info)
- **`InvoiceUtils.ts`** - Utility functions for formatting currency, dates, status badges, and calculating totals
- **`index.ts`** - Central export file for all components

### UI Components

- **`InvoiceHeader.tsx`** - Header section with navigation, title, and action buttons (Print, Email)
- **`InvoiceStates.tsx`** - Loading and error state components
- **`InvoiceSummary.tsx`** - Main invoice details including status, dates, amounts, and financial summary
- **`InvoiceItemsTable.tsx`** - Table displaying invoice line items with descriptions, quantities, prices
- **`PaymentRecords.tsx`** - Payment history table with add/delete payment functionality
- **`CustomerInfo.tsx`** - Customer information sidebar component with link to customer profile
- **`VehicleInfo.tsx`** - Vehicle information sidebar component
- **`InvoiceImages.tsx`** - Image gallery component with add/remove image functionality

## Benefits of This Structure

1. **Modularity** - Each component has a single responsibility
2. **Reusability** - Components can be used in other parts of the application
3. **Maintainability** - Easier to locate and fix bugs
4. **Testability** - Each component can be tested in isolation
5. **Code Organization** - Related functionality is grouped together
6. **Performance** - Smaller components can be optimized individually

## Usage

```tsx
import {
  InvoiceHeader,
  LoadingState,
  ErrorState,
  InvoiceSummary,
  InvoiceItemsTable,
  PaymentRecords,
  CustomerInfo,
  VehicleInfo,
  InvoiceImages,
  InvoiceDataProcessor,
  calculateInvoiceTotals
} from '@/app/components/Invoices/details';
```

## Data Flow

1. **Main Page** (`page.tsx`) fetches raw invoice data from API
2. **InvoiceDataProcessor** normalizes and enriches the data
3. **Individual Components** receive processed data as props
4. **Event Handlers** in main page handle user interactions and API calls
5. **State Updates** trigger re-renders of affected components

## Component Props

Each component is typed with TypeScript interfaces for better development experience and type safety. The main invoice object and handler functions are passed down as props.

## Future Enhancements

- Add proper TypeScript interfaces for all component props
- Implement error boundaries for better error handling
- Add unit tests for each component
- Consider using React Query or SWR for better data fetching and caching
- Add skeleton loading states for better UX
