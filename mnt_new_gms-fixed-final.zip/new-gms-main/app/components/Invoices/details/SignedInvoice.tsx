'use client';

import React, { useState } from 'react';
import api from '@/services/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import DocumentViewer from '@/app/components/ui/DocumentViewer';
import { 
  FileCheck, 
  Upload, 
  Eye, 
  Download, 
  Trash2, 
  AlertTriangle,
  X,
  CheckCircle
} from 'lucide-react';

interface SignedInvoiceData {
  url: string;
  key: string;
  filename: string;
  size: number;
  upload_date: string;
}

interface SignedInvoiceProps {
  invoiceId: string;
  invoice?: any;
  onSignedInvoiceUpdated?: () => void;
}

const SignedInvoice: React.FC<SignedInvoiceProps> = ({ 
  invoiceId, 
  invoice, 
  onSignedInvoiceUpdated 
}) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [documentViewer, setDocumentViewer] = useState({
    isOpen: false,
    url: '',
    filename: ''
  });

  const signedInvoice: SignedInvoiceData | null = invoice?.signed_invoice || null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validate file type
      const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'application/pdf'];
      if (!allowedTypes.includes(file.type)) {
        console.error('Only JPEG, PNG, and PDF files are allowed');
        return;
      }
      
      // Validate file size (10MB)
      if (file.size > 10 * 1024 * 1024) {
        console.error('File size must be less than 10MB');
        return;
      }
      
      setSelectedFile(file);
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) {
      console.error('Please select a file first');
      return;
    }

    try {
      setUploading(true);
      
      const formData = new FormData();
      formData.append('signedInvoice', selectedFile);

      await api.post(`/api/invoices/${invoiceId}/signed-invoice`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      // Reset form
      setSelectedFile(null);
      
      // Notify parent to refresh invoice data
      if (onSignedInvoiceUpdated) {
        onSignedInvoiceUpdated();
      }
      
    } catch (error: any) {
      console.error('Failed to upload signed invoice:', error);
      console.error(error.response?.data?.message || 'Failed to upload signed invoice');
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async () => {
    try {
      setDeleting(true);
      
      await api.delete(`/api/invoices/${invoiceId}/signed-invoice`);
      
      setShowDeleteModal(false);
      
      // Notify parent to refresh invoice data
      if (onSignedInvoiceUpdated) {
        onSignedInvoiceUpdated();
      }
      
    } catch (error: any) {
      console.error('Failed to delete signed invoice:', error);
      console.error(error.response?.data?.message || 'Failed to delete signed invoice');
    } finally {
      setDeleting(false);
    }
  };

  const handleView = async () => {
    try {
      const response = await api.get(`/api/invoices/${invoiceId}/signed-invoice/view`);
      
      // Handle different response structures
      let signedUrl, filename;
      
      if (response?.data?.data?.signedUrl) {
        // Structure: { data: { data: { signedUrl, filename } } }
        signedUrl = response.data.data.signedUrl;
        filename = response.data.data.filename;
      } else if (response?.data?.signedUrl) {
        // Structure: { data: { signedUrl, filename } }
        signedUrl = response.data.signedUrl;
        filename = response.data.filename;
      } else if (response && typeof response === 'object' && 'signedUrl' in response) {
        // Structure: { signedUrl, filename } (direct response)
        signedUrl = (response as any).signedUrl;
        filename = (response as any).filename;
      }
      
      if (signedUrl) {
        setDocumentViewer({
          isOpen: true,
          url: signedUrl,
          filename: filename || signedInvoice!.filename
        });
      } else {
        console.error('No signed URL found in response structure');
        console.error('Failed to load signed invoice. Please try again.');
      }
    } catch (error: any) {
      console.error('Error fetching signed invoice:', error);
      console.error(error.response?.data?.message || 'Failed to load signed invoice');
    }
  };

  const handleDownload = async () => {
    try {
      const response = await api.get(`/api/invoices/${invoiceId}/signed-invoice/download`);
      
      // Handle different response structures
      let downloadUrl, filename;
      
      if (response?.data?.data?.downloadUrl) {
        // Structure: { data: { data: { downloadUrl, filename } } }
        downloadUrl = response.data.data.downloadUrl;
        filename = response.data.data.filename;
      } else if (response?.data?.downloadUrl) {
        // Structure: { data: { downloadUrl, filename } }
        downloadUrl = response.data.downloadUrl;
        filename = response.data.filename;
      } else if (response && typeof response === 'object' && 'downloadUrl' in response) {
        // Structure: { downloadUrl, filename } (direct response)
        downloadUrl = (response as any).downloadUrl;
        filename = (response as any).filename;
      }
      
      if (downloadUrl) {
        const link = document.createElement('a');
        link.href = downloadUrl;
        link.download = filename || signedInvoice!.filename;
        link.target = '_blank';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      } else {
        console.error('No download URL found in response:', response);
        console.error('Failed to download signed invoice. Please try again.');
      }
    } catch (error: any) {
      console.error('Error downloading signed invoice:', error);
      console.error(error.response?.data?.message || 'Failed to download signed invoice');
    }
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <>
      <Card className="mt-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileCheck className="w-5 h-5" />
            Signed Invoice
            {signedInvoice && (
              <div className="flex items-center gap-1 ml-2">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <span className="text-sm font-normal text-green-600">Uploaded</span>
              </div>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {signedInvoice ? (
            /* Display existing signed invoice */
            <div className="space-y-4">
              <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <FileCheck className="w-5 h-5 text-green-600" />
                      <span className="font-medium text-green-800">
                        {signedInvoice.filename}
                      </span>
                    </div>
                    
                    <div className="text-sm text-green-700 space-y-1">
                      <div>Size: {formatFileSize(signedInvoice.size)}</div>
                      <div>Uploaded: {formatDate(signedInvoice.upload_date)}</div>
                    </div>
                    
                    <div className="flex items-center gap-2 mt-3">
                      <Button
                        onClick={handleView}
                        variant="outline"
                        size="sm"
                        className="text-blue-600 hover:text-blue-800"
                      >
                        <Eye className="w-4 h-4 mr-1" />
                        View
                      </Button>
                      <Button
                        onClick={handleDownload}
                        variant="outline"
                        size="sm"
                        className="text-green-600 hover:text-green-800"
                      >
                        <Download className="w-4 h-4 mr-1" />
                        Download
                      </Button>
                    </div>
                  </div>
                  <div className="ml-4">
                    <Button
                      onClick={() => setShowDeleteModal(true)}
                      variant="outline"
                      size="icon"
                      className="text-red-600 hover:text-red-800"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            /* Upload form for new signed invoice */
            <div className="space-y-4">
              <div className="text-center py-6 text-gray-500">
                <FileCheck className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                <div className="text-lg mb-2">No signed invoice uploaded</div>
                <div className="text-sm">Upload the signed invoice document for this invoice.</div>
              </div>
              
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6">
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Upload Signed Invoice
                    </label>
                    <div className="flex items-center space-x-4">
                      <input
                        type="file"
                        accept="image/*,.pdf"
                        onChange={handleFileChange}
                        className="hidden"
                        id="signed-invoice-file"
                      />
                      <label
                        htmlFor="signed-invoice-file"
                        className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 cursor-pointer"
                      >
                        <Upload className="w-4 h-4 mr-2" />
                        Choose File
                      </label>
                      {selectedFile && (
                        <div className="flex items-center space-x-2">
                          <span className="text-sm text-gray-600">
                            {selectedFile.name} ({formatFileSize(selectedFile.size)})
                          </span>
                          <Button
                            onClick={() => setSelectedFile(null)}
                            variant="outline"
                            size="sm"
                            className="text-red-600 hover:text-red-800"
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </div>
                      )}
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      Supports JPEG, PNG, PDF files up to 10MB
                    </p>
                  </div>
                  
                  {selectedFile && (
                    <div className="flex items-center space-x-2">
                      <Button 
                        onClick={handleUpload} 
                        disabled={uploading}
                        className="bg-green-600 hover:bg-green-700 text-white"
                      >
                        {uploading ? (
                          <>
                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                            Uploading...
                          </>
                        ) : (
                          <>
                            <Upload className="w-4 h-4 mr-2" />
                            Upload Signed Invoice
                          </>
                        )}
                      </Button>
                      <Button
                        onClick={() => setSelectedFile(null)}
                        variant="outline"
                        disabled={uploading}
                      >
                        Cancel
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Delete Confirmation Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 flex items-center justify-center z-50">
          {/* Backdrop */}
          <div 
            className="absolute inset-0 bg-black bg-opacity-50"
            onClick={() => setShowDeleteModal(false)}
          ></div>
          
          {/* Modal Content */}
          <div className="relative bg-white rounded-lg shadow-xl p-6 max-w-md w-full mx-4">
            <div className="flex items-center gap-3 mb-4">
              <div className="flex-shrink-0 w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
                <AlertTriangle className="w-5 h-5 text-red-600" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">
                  Delete Signed Invoice
                </h3>
                <p className="text-sm text-gray-500">
                  This action cannot be undone.
                </p>
              </div>
            </div>
            
            <div className="mb-6">
              <p className="text-gray-700 mb-3">
                Are you sure you want to delete the signed invoice document?
              </p>
              <div className="bg-gray-50 p-3 rounded-lg">
                <div className="text-sm">
                  <div className="font-medium">{signedInvoice?.filename}</div>
                  <div className="text-gray-600 mt-1">
                    Size: {signedInvoice && formatFileSize(signedInvoice.size)}
                  </div>
                  <div className="text-gray-600">
                    Uploaded: {signedInvoice && formatDate(signedInvoice.upload_date)}
                  </div>
                </div>
              </div>
            </div>
            
            <div className="flex justify-end space-x-3">
              <Button
                onClick={() => setShowDeleteModal(false)}
                variant="outline"
                disabled={deleting}
              >
                Cancel
              </Button>
              <Button
                onClick={handleDelete}
                disabled={deleting}
                className="bg-red-600 text-white hover:bg-red-700"
              >
                {deleting ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Deleting...
                  </>
                ) : (
                  <>
                    <Trash2 className="w-4 h-4 mr-2" />
                    Delete
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Document Viewer */}
      <DocumentViewer
        isOpen={documentViewer.isOpen}
        onClose={() => setDocumentViewer({ ...documentViewer, isOpen: false })}
        documentUrl={documentViewer.url}
        filename={documentViewer.filename}
        onDownload={handleDownload}
      />
    </>
  );
};

export default SignedInvoice;
