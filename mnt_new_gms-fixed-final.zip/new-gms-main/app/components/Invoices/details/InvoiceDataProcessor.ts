// Invoice data processing utilities
import api from '@/services/api';
import { PaymentRecord, InvoiceImage, CustomerInfo, VehicleInfo } from '@/app/types/invoice';

export interface ProcessedInvoiceData {
  invoice_date: Date;
  due_date: Date;
  created_at: Date;
  updated_at: Date;
  payment_records: PaymentRecord[];
  images: InvoiceImage[];
  customer_info: CustomerInfo;
  vehicle_info: VehicleInfo;
  items: Array<{
    description: string;
    quantity: number;
    unit_price: number;
    amount: number;
  }>;
  payment_status: string;
  [key: string]: unknown;
}

export class InvoiceDataProcessor {
  static async processInvoiceData(invoiceData: Record<string, unknown>): Promise<ProcessedInvoiceData> {
    // Normalize field names from new API format
    invoiceData = this.normalizeFieldNames(invoiceData);
    
    // Ensure consistent date formats
    if (invoiceData.invoice_date && !(invoiceData.invoice_date instanceof Date)) {
      invoiceData.invoice_date = new Date(invoiceData.invoice_date);
    }
    
    if (invoiceData.due_date && !(invoiceData.due_date instanceof Date)) {
      invoiceData.due_date = new Date(invoiceData.due_date);
    }
    
    if (invoiceData.created_at && !(invoiceData.created_at instanceof Date)) {
      invoiceData.created_at = new Date(invoiceData.created_at);
    }
    
    if (invoiceData.updated_at && !(invoiceData.updated_at instanceof Date)) {
      invoiceData.updated_at = new Date(invoiceData.updated_at);
    }
    
    // Process payment records
    invoiceData = await this.processPaymentRecords(invoiceData);
    
    // Process images
    invoiceData = this.processImages(invoiceData);
    
    // Process customer info
    invoiceData = await this.processCustomerInfo(invoiceData);
    
    // Process vehicle info
    invoiceData = await this.processVehicleInfo(invoiceData);
    
    // Process items
    invoiceData = this.processItems(invoiceData);
    
    // Calculate payment status
    invoiceData = this.calculatePaymentStatus(invoiceData);
    
    return invoiceData;
  }

  private static processPaymentRecords(invoiceData: Record<string, unknown>) {
    if (invoiceData.payment_records && Array.isArray(invoiceData.payment_records)) {
      invoiceData.payment_records = invoiceData.payment_records.map((record: PaymentRecord) => ({
        ...record,
        payment_date: record.payment_date instanceof Date ? 
          record.payment_date : new Date(record.payment_date)
      }));
    } else {
      invoiceData.payment_records = [];
    }
    return invoiceData;
  }

  private static processImages(invoiceData: Record<string, unknown>) {
    if (invoiceData.images && Array.isArray(invoiceData.images)) {
      invoiceData.images = (invoiceData.images as unknown[]).map((image: Record<string, unknown>) => ({
        ...image,
        added_at: image.added_at instanceof Date ? 
          image.added_at : new Date(image.added_at || new Date())
      }));
    } else {
      invoiceData.images = [];
    }
    return invoiceData;
  }

  private static async processCustomerInfo(invoiceData: Record<string, unknown>) {
    // Handle customer info if it's missing or incomplete
    if (!invoiceData.customer_info && invoiceData.customer) {
      invoiceData.customer_info = invoiceData.customer;
    }
    
    // If we have a customer ID, fetch complete customer data
    if (invoiceData.customer_info?._id || invoiceData.customer_id) {
      try {
        const customerId = invoiceData.customer_info?._id || invoiceData.customer_id;

        const customerResponse = await api.get(`/api/customers/${customerId}`);
        
        if (customerResponse && typeof customerResponse === 'object') {
          const customerData = 'data' in customerResponse ? customerResponse.data : customerResponse;
          
          if (customerData && typeof customerData === 'object') {
            const formattedCustomerData = {
              _id: customerId,
              first_name: customerData.first_name || customerData.firstName || '',
              last_name: customerData.last_name || customerData.lastName || '',
              name: customerData.name || 
                    (customerData.first_name && customerData.last_name ? 
                     `${customerData.first_name} ${customerData.last_name}` : 
                     customerData.first_name || customerData.last_name || 'Customer information not available'),
              email: customerData.email || customerData.emailAddress || '',
              phone: customerData.phone || customerData.phoneNumber || customerData.contact || '',
              city: customerData.city || '',
              country: customerData.country || '',
              address: customerData.address || '',
              branch: customerData.branch || {},
              vehicles: customerData.vehicles || []
            };
            
            invoiceData.customer_info = formattedCustomerData;
          }
        }
      } catch (err) {
        console.error('Failed to fetch customer information:', err);
        if (!invoiceData.customer_info) {
          invoiceData.customer_info = {
            name: 'Customer information not available',
            _id: invoiceData.customer_info?._id || invoiceData.customer_id || ''
          };
        }
      }
    }
    
    // If still no customer info, create a placeholder
    if (!invoiceData.customer_info) {
      invoiceData.customer_info = {
        name: 'Customer information not available',
        _id: invoiceData.customer_id || ''
      };
    }
    
    return invoiceData;
  }

  private static async processVehicleInfo(invoiceData: Record<string, unknown>) {
    // Handle vehicle info if it's missing or incomplete
    if (!invoiceData.vehicle_info && invoiceData.vehicle) {
      invoiceData.vehicle_info = invoiceData.vehicle;
    }
    
    // Check for vehicle info in alternative fields
    const possibleVehicleFields = ['vehicle_details', 'vehicleInfo', 'car', 'car_info'];
    for (const field of possibleVehicleFields) {
      if (!invoiceData.vehicle_info && invoiceData[field] && typeof invoiceData[field] === 'object') {
        invoiceData.vehicle_info = invoiceData[field];
        break;
      }
    }
    
    // Try to get vehicle info from customer info if available
    if (!invoiceData.vehicle_info && invoiceData.customer_info?.vehicle) {
      invoiceData.vehicle_info = invoiceData.customer_info.vehicle;
    }
    
    // Check for vehicles array in customer_info
    if (!invoiceData.vehicle_info && 
        invoiceData.customer_info?.vehicles && 
        Array.isArray(invoiceData.customer_info.vehicles) && 
        invoiceData.customer_info.vehicles.length > 0) {
      
      const primaryVehicle = invoiceData.customer_info.vehicles[0];
      invoiceData.vehicle_info = this.formatVehicleData(primaryVehicle);
    }
    
    // If we have a customer ID and no vehicle info, try to fetch from customer record
    if (!invoiceData.vehicle_info && invoiceData.customer_info?._id) {
      try {
        const customerId = invoiceData.customer_info._id;
        const customerResponse = await api.get(`/api/customers/${customerId}`);
        
        if (customerResponse && typeof customerResponse === 'object') {
          const customerData = 'data' in customerResponse ? customerResponse.data : customerResponse;
          
          if (customerData?.vehicle) {
            invoiceData.vehicle_info = customerData.vehicle;
          } else if (customerData?.vehicles && Array.isArray(customerData.vehicles) && customerData.vehicles.length > 0) {
            const primaryVehicle = customerData.vehicles[0];
            invoiceData.vehicle_info = this.formatVehicleData(primaryVehicle);
          }
        }
      } catch (err) {
        console.error('Failed to fetch vehicle info from customer record:', err);
      }
    }
    
    // Create placeholder if still no vehicle info
    if (!invoiceData.vehicle_info) {
      invoiceData.vehicle_info = {
        license_plate: invoiceData.license_plate || invoiceData.plate_number || 'N/A',
        make: invoiceData.make || invoiceData.vehicle_make || '',
        model: invoiceData.model || invoiceData.vehicle_model || '',
        year: invoiceData.year || invoiceData.vehicle_year || '',
        color: invoiceData.color || invoiceData.vehicle_color || '',
        vin: invoiceData.vin || ''
      };
    }
    
    return invoiceData;
  }

  private static formatVehicleData(vehicleData: Record<string, unknown>) {
    return {
      ...vehicleData,
      license_plate: vehicleData.license_plate || vehicleData.plateNumber || vehicleData.plate || 'N/A',
      make: vehicleData.make || vehicleData.manufacturer || '',
      model: vehicleData.model || '',
      year: vehicleData.year || typeof vehicleData.year === 'number' ? vehicleData.year : 
             (vehicleData.yearManufactured || ''),
      color: vehicleData.color || vehicleData.vehicleColor || '',
      vin: vehicleData.vin || vehicleData.vinNumber || vehicleData.vehicleIdentificationNumber || '',
      vehicle_id: vehicleData.vehicle_id || vehicleData._id || vehicleData.id || ''
    };
  }

  private static processItems(invoiceData: Record<string, unknown>) {
    // Normalize the items array
    if (!invoiceData.items && invoiceData.line_items) {
      invoiceData.items = invoiceData.line_items;
    }
    
    // Check for items in alternative fields
    const possibleItemFields = ['services', 'products', 'invoice_items', 'lineItems', 'lines', 'parts'];
    for (const field of possibleItemFields) {
      if ((!invoiceData.items || invoiceData.items.length === 0) && 
          invoiceData[field] && Array.isArray(invoiceData[field])) {
        invoiceData.items = invoiceData[field];
        break;
      }
    }
    
    // If invoice has a single service item, convert it to an array
    if (!invoiceData.items && invoiceData.service && typeof invoiceData.service === 'object') {
      invoiceData.items = [invoiceData.service];
    }
    
    // Standardize each item
    if (invoiceData.items && Array.isArray(invoiceData.items)) {
      invoiceData.items = (invoiceData.items as unknown[]).map((item: Record<string, unknown>) => {
        const description = item.description || item.name || item.item_name || item.service || 'Service item';
        const quantity = Number(item.quantity || item.qty || 1);
        const unitPrice = Number(item.unit_price || item.price || item.rate || 0);
        const amount = Number(item.amount || item.total || (quantity * unitPrice) || 0);
        
        return {
          ...item,
          description,
          quantity,
          unit_price: unitPrice,
          amount
        };
      });
    }
    
    // Create default item if no items but have total
    if ((!invoiceData.items || !Array.isArray(invoiceData.items) || invoiceData.items.length === 0) && 
        (invoiceData.total || invoiceData.price)) {
      const totalAmount = Number(invoiceData.total || invoiceData.price || 0);
      invoiceData.items = [{
        description: 'Service',
        quantity: 1,
        unit_price: totalAmount,
        amount: totalAmount
      }];
      invoiceData.subtotal = totalAmount;
    } else if (!invoiceData.items || !Array.isArray(invoiceData.items)) {
      invoiceData.items = [];
    }
    
    return invoiceData;
  }

  private static calculatePaymentStatus(invoiceData: Record<string, unknown>) {
    if (!invoiceData.payment_status) {
      const totalAmount = Number(invoiceData.total || invoiceData.total_price || invoiceData.price || 0);
      const amountPaid = invoiceData.payment_records.length > 0 ? 
        (invoiceData.payment_records as PaymentRecord[]).reduce((sum: number, record: PaymentRecord) => sum + (Number(record.amount) || 0), 0) : 0;
      
      if (amountPaid <= 0) {
        invoiceData.payment_status = 'Unpaid';
      } else if (amountPaid >= totalAmount) {
        invoiceData.payment_status = 'Paid';
      } else {
        invoiceData.payment_status = 'Partially Paid';
      }
    }
    
    return invoiceData;
  }

  private static normalizeFieldNames(invoiceData: Record<string, unknown>) {
    // Map new API field names to expected format
    const normalized = { ...invoiceData };
    
    // Normalize total field
    if (normalized.total_price && !normalized.total) {
      normalized.total = normalized.total_price;
    }
    
    // Normalize subtotal field
    if (normalized.price_before_vat && !normalized.subtotal) {
      normalized.subtotal = normalized.price_before_vat;
    }
    
    // Normalize VAT fields
    if (normalized.vat_amount && !normalized.tax) {
      normalized.tax = normalized.vat_amount;
    }
    
    // Ensure payment_records is an array
    if (!normalized.payment_records) {
      normalized.payment_records = [];
    }
    
    // Ensure images is an array
    if (!normalized.images) {
      normalized.images = [];
    }
    
    return normalized;
  }
}
