import React from 'react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { formatCurrency } from '../InvoiceUtils';

interface PayInFullFormData {
  payment_method: string;
  notes?: string;
}

const schema = yup.object().shape({
  payment_method: yup
    .string()
    .required('Payment method is required')
    .oneOf(['Cash', 'Card', 'Bank Transfer', 'Check'], 'Please select a valid payment method'),
  notes: yup
    .string()
    .optional()
    .max(200, 'Notes must be less than 200 characters'),
}) as yup.ObjectSchema<PayInFullFormData>;

interface PayInFullModalProps {
  isOpen: boolean;
  isSaving: boolean;
  error: string | null;
  amountDue: number;
  onClose: () => void;
  onSubmit: (data: PayInFullFormData & { amount: number }) => Promise<void>;
}

export const PayInFullModal: React.FC<PayInFullModalProps> = ({
  isOpen,
  isSaving,
  error,
  amountDue,
  onClose,
  onSubmit
}) => {
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm<PayInFullFormData>({
    resolver: yupResolver(schema),
    defaultValues: {
      payment_method: 'Cash',
      notes: '',
    }
  });

  const handleFormSubmit = async (data: PayInFullFormData) => {
    await onSubmit({
      ...data,
      amount: amountDue
    });
    reset();
  };

  const handleClose = () => {
    reset();
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-[500px] max-w-[90%]">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-semibold text-gray-800">Pay in Full</h2>
          <button 
            onClick={handleClose}
            className="text-gray-600 hover:text-gray-800 text-2xl"
          >
            ×
          </button>
        </div>
        
        {error && (
          <div className="bg-red-50 text-red-600 p-3 rounded mb-4">
            {error}
          </div>
        )}

        <div className="bg-blue-50 p-4 rounded-lg mb-6">
          <div className="flex justify-between items-center mb-2">
            <span className="text-gray-700 font-medium">Amount to be paid:</span>
            <span className="text-2xl font-bold text-blue-600">
              {formatCurrency(amountDue)}
            </span>
          </div>
          <p className="text-xs text-gray-600">
            Reference number will be auto-generated for this payment
          </p>
        </div>

        <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-4">
          <div>
            <label className="block text-sm mb-1 text-gray-700 font-medium">
              Payment Method <span className="text-red-500">*</span>
            </label>
            <select
              {...register('payment_method')}
              className="w-full p-3 border rounded-lg focus:border-blue-500 focus:outline-none text-gray-700"
            >
              <option value="Cash">Cash</option>
              <option value="Card">Card</option>
              <option value="Bank Transfer">Bank Transfer</option>
              <option value="Check">Check</option>
            </select>
            {errors.payment_method && (
              <p className="text-red-500 text-xs mt-1">{errors.payment_method.message}</p>
            )}
          </div>

          <div>
            <label className="block text-sm mb-1 text-gray-700 font-medium">
              Notes
            </label>
            <textarea
              {...register('notes')}
              rows={3}
              className="w-full p-3 border rounded-lg focus:border-blue-500 focus:outline-none text-gray-700 resize-none"
              placeholder="Additional payment notes..."
            />
            {errors.notes && (
              <p className="text-red-500 text-xs mt-1">{errors.notes.message}</p>
            )}
          </div>

          <div className="flex justify-end gap-3 mt-6">
            <button
              type="button"
              onClick={handleClose}
              className="px-6 py-2 text-sm bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSaving || amountDue <= 0}
              className="px-6 py-2 text-sm bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSaving ? 'Processing...' : `Pay ${formatCurrency(amountDue)}`}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
