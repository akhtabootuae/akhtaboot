// Invoice utility functions
export const formatCurrency = (amount: number | undefined | null) => {
  if (amount === undefined || amount === null || isNaN(Number(amount))) {
    return 'AED 0.00';
  }
  return `AED ${Number(amount).toFixed(2)}`;
};

export const formatDate = (date: Date | string | undefined) => {
  if (!date) return 'N/A';
  const { format } = require('date-fns');
  return format(new Date(date), 'MMM d, yyyy');
};

export const getStatusBadgeClass = (status: string | undefined) => {
  switch (status) {
    case 'Paid':
      return 'bg-green-100 text-green-800';
    case 'Partially Paid':
      return 'bg-yellow-100 text-yellow-800';
    case 'Unpaid':
      return 'bg-red-100 text-red-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
};

export const calculateInvoiceTotals = (invoice: any) => {
  if (!invoice) return { subtotal: 0, total: 0, amountPaid: 0, amountDue: 0 };
  
  // Calculate subtotal (price before tax/VAT)
  let subtotal = 0;
  
  // First priority: use price_before_vat if available (this is the correct subtotal)
  if (invoice.price_before_vat !== undefined && invoice.price_before_vat !== null) {
    subtotal = Number(invoice.price_before_vat);
  }
  // Second priority: use price field if available
  else if (invoice.price !== undefined && invoice.price !== null) {
    subtotal = Number(invoice.price);
  }
  // Third priority: calculate from items if available
  else if (invoice.items && Array.isArray(invoice.items)) {
    subtotal = invoice.items.reduce((sum: number, item: any) => sum + (Number(item.amount) || 0), 0);
  }
  // Fourth priority: use total_amount if no tax is applied
  else if (invoice.total_amount !== undefined && invoice.total_amount !== null && !invoice.isTaxed) {
    subtotal = Number(invoice.total_amount);
  }
  
  // Calculate total (including tax/VAT)
  let total = 0;
  
  // First priority: use total_price if available (this includes VAT)
  if (invoice.total_price !== undefined && invoice.total_price !== null) {
    total = Number(invoice.total_price);
  }
  // Second priority: use total field if available
  else if (invoice.total !== undefined && invoice.total !== null) {
    total = Number(invoice.total);
  }
  // Third priority: calculate total from subtotal + tax
  else {
    total = subtotal + 
            (invoice.tax || invoice.vat_amount || 0) - 
            (invoice.discount || 0);
  }
  
  // Calculate amount paid from payment records
  const amountPaid = invoice.payment_records && Array.isArray(invoice.payment_records)
    ? invoice.payment_records.reduce((sum: number, record: any) => sum + (Number(record.amount) || 0), 0)
    : 0;
  
  const amountDue = total - amountPaid;
  
  return { subtotal: subtotal || 0, total: total || 0, amountPaid, amountDue };
};
