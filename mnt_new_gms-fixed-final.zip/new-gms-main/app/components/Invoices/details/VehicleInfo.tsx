import React from 'react';

interface VehicleInfoProps {
  invoice: any;
}

export const VehicleInfo: React.FC<VehicleInfoProps> = ({ invoice }) => {
  return (
    <div className="bg-white rounded-lg shadow mt-6 overflow-hidden">
      <div className="p-6 border-b border-gray-200">
        <h2 className="text-xl font-semibold text-gray-800">Vehicle Information</h2>
      </div>
      <div className="p-6">
        {invoice?.vehicle_info || invoice?.car_type || invoice?.license_plate ? (
          <>
            {(invoice.car_type && invoice.car_type !== 'undefined') && (
              <div className="mb-4">
                <h3 className="text-sm font-medium text-gray-500 mb-1">Car Type</h3>
                <p className="text-base font-medium text-gray-900 break-words">
                  {invoice.car_type}
                </p>
              </div>
            )}
            
            {(invoice.vehicle_info?.license_plate || invoice.license_plate) && (
              <div className="mb-4">
                <h3 className="text-sm font-medium text-gray-500 mb-1">License Plate</h3>
                <p className="text-base font-medium text-gray-900">
                  {invoice.vehicle_info?.license_plate || invoice.license_plate}
                </p>
              </div>
            )}
            
            <div className="mb-4">
              <h3 className="text-sm font-medium text-gray-500 mb-1">Make & Model</h3>
              <p className="text-base text-gray-900">
                {invoice.vehicle_info.year ? `${invoice.vehicle_info.year} ` : ''}
                {invoice.vehicle_info.make ? `${invoice.vehicle_info.make} ` : ''}
                {invoice.vehicle_info.model || ''}
                {!invoice.vehicle_info.make && !invoice.vehicle_info.model ? 'N/A' : ''}
              </p>
            </div>
            
            {invoice.vehicle_info.vin && (
              <div className="mb-4">
                <h3 className="text-sm font-medium text-gray-500 mb-1">VIN</h3>
                <p className="text-base text-gray-900">{invoice.vehicle_info.vin}</p>
              </div>
            )}
            
            {invoice.vehicle_info.color && (
              <div className="mb-4">
                <h3 className="text-sm font-medium text-gray-500 mb-1">Color</h3>
                <p className="text-base text-gray-900">{invoice.vehicle_info.color}</p>
              </div>
            )}
            
            {/* Display any additional vehicle fields */}
            {Object.entries(invoice.vehicle_info).map(([key, value]) => {
              // Skip fields we've already handled and vehicle_id
              if (['license_plate', 'make', 'model', 'year', 'vin', 'color', 'vehicle_id'].includes(key)) {
                return null;
              }
              
              // Skip empty values
              if (value === null || value === undefined || value === '') {
                return null;
              }
              
              // Format the key for display
              const formattedKey = key
                .split('_')
                .map(word => word.charAt(0).toUpperCase() + word.slice(1))
                .join(' ');
              
              // Format date values for better readability
              let displayValue = String(value);
              if (key.toLowerCase().includes('created') || key.toLowerCase().includes('updated')) {
                try {
                  const date = new Date(value as string);
                  if (!isNaN(date.getTime())) {
                    displayValue = date.toLocaleDateString('en-US', {
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    });
                  }
                } catch (error) {
                  // If date parsing fails, use original value
                  displayValue = String(value);
                }
              }
              
              return (
                <div className="mb-4" key={key}>
                  <h3 className="text-sm font-medium text-gray-500 mb-1">{formattedKey}</h3>
                  <p className="text-base text-gray-900">{displayValue}</p>
                </div>
              );
            })}
          </>
        ) : (
          <div className="text-center py-4 text-gray-500">
            <p>No vehicle information available</p>
          </div>
        )}
      </div>
    </div>
  );
};
