import React, { useState } from 'react';
import { formatDate, formatCurrency, calculateInvoiceTotals } from './InvoiceUtils';
import { Button } from '@/app/components/ui/button';
import { PayInFullModal, PartialPayModal } from './modals';

interface PaymentRecordsProps {
  invoice: any;
  onAddPayment: (paymentData: any) => Promise<void>;
}

export const PaymentRecords: React.FC<PaymentRecordsProps> = ({
  invoice,
  onAddPayment
}) => {
  const [isPayInFullModalOpen, setIsPayInFullModalOpen] = useState(false);
  const [isPartialPayModalOpen, setIsPartialPayModalOpen] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const { amountDue } = calculateInvoiceTotals(invoice);

  const handlePaymentSubmit = async (paymentData: any) => {
    setIsSaving(true);
    setError(null);
    try {
      await onAddPayment({
        ...paymentData,
        payment_date: new Date()
      });
      setIsPayInFullModalOpen(false);
      setIsPartialPayModalOpen(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to process payment');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow mt-6 overflow-hidden">
      <div className="flex justify-between items-center p-6 border-b border-gray-200">
        <div>
          <h2 className="text-xl font-semibold text-gray-800">Payment Records</h2>
          {amountDue > 0 && (
            <p className="text-sm text-orange-600 mt-1">
              Outstanding Amount: <span className="font-semibold">{formatCurrency(amountDue)}</span>
            </p>
          )}
          {amountDue === 0 && (
            <p className="text-sm text-green-600 mt-1">
              <span className="font-semibold">✓ Fully Paid</span>
            </p>
          )}
        </div>
        <div className="flex gap-2">
          <Button 
            onClick={() => setIsPartialPayModalOpen(true)}
            disabled={amountDue <= 0}
            className="bg-blue-600 text-white hover:bg-blue-700 text-sm flex items-center disabled:opacity-50"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            Partial Pay
          </Button>
          <Button 
            onClick={() => setIsPayInFullModalOpen(true)}
            disabled={amountDue <= 0}
            className="bg-green-600 text-white hover:bg-green-700 text-sm flex items-center disabled:opacity-50"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            Pay in Full
          </Button>
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b border-gray-200">Date</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b border-gray-200">Amount</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b border-gray-200">Method</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b border-gray-200">Reference</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {invoice?.payment_records && Array.isArray(invoice.payment_records) && invoice.payment_records.length > 0 ? (
              invoice.payment_records.map((payment: any, index: number) => {
                return (
                  <tr key={index} className="hover:bg-gray-50">
                    <td className="px-4 py-3 text-sm text-gray-900">
                      {formatDate(payment.payment_date)}
                    </td>
                    <td className="px-4 py-3 text-sm font-medium text-green-600">
                      {formatCurrency(payment.amount)}
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-900">
                      {payment.payment_method || 'N/A'}
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-900">
                      {payment.reference || 'N/A'}
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan={4} className="px-4 py-3 text-sm text-center text-gray-500">
                  No payment records found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      
      {/* Payment Modals */}
      <PayInFullModal
        isOpen={isPayInFullModalOpen}
        isSaving={isSaving}
        error={error}
        amountDue={amountDue}
        onClose={() => {
          setIsPayInFullModalOpen(false);
          setError(null);
        }}
        onSubmit={handlePaymentSubmit}
      />
      
      <PartialPayModal
        isOpen={isPartialPayModalOpen}
        isSaving={isSaving}
        error={error}
        amountDue={amountDue}
        onClose={() => {
          setIsPartialPayModalOpen(false);
          setError(null);
        }}
        onSubmit={handlePaymentSubmit}
      />
    </div>
  );
};
