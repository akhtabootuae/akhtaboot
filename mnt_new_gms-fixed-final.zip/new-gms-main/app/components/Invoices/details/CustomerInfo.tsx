import React from 'react';
import Link from 'next/link';

interface CustomerInfoProps {
  invoice: any;
}

export const CustomerInfo: React.FC<CustomerInfoProps> = ({ invoice }) => {
  return (
    <div className="bg-white rounded-lg shadow overflow-hidden">
      <div className="p-6 border-b border-gray-200">
        <h2 className="text-xl font-semibold text-gray-800">Customer Information</h2>
      </div>
      <div className="p-6">
        {invoice?.customer_info ? (
          <>
            <h3 className="text-base font-medium text-gray-900 mb-2">
              {/* Display customer name with improved fallback handling */}
              {invoice.customer_info.name && invoice.customer_info.name !== 'Customer information not available' ? 
                invoice.customer_info.name : 
                (invoice.customer_info.first_name || invoice.customer_info.last_name) ? 
                  `${invoice.customer_info.first_name || ''} ${invoice.customer_info.last_name || ''}`.trim() : 
                  'N/A'}
            </h3>
            {invoice.customer_info.email && (
              <p className="text-sm text-gray-600 mb-1">Email: {invoice.customer_info.email}</p>
            )}
            {invoice.customer_info.phone && (
              <p className="text-sm text-gray-600 mb-1">Phone: {invoice.customer_info.phone}</p>
            )}
            {invoice.customer_info.city && (
              <p className="text-sm text-gray-600 mb-1">City: {invoice.customer_info.city}</p>
            )}
            {invoice.customer_info.country && (
              <p className="text-sm text-gray-600 mb-1">Country: {invoice.customer_info.country}</p>
            )}
            
            {/* Display branch information if available */}
            {invoice.customer_info.branch && (
              <p className="text-sm text-gray-600 mb-1">
                Branch: {invoice.customer_info.branch.branch_name || 
                        (typeof invoice.customer_info.branch === 'string' ? invoice.customer_info.branch : 'N/A')}
              </p>
            )}
            
            {/* Display any additional customer fields */}
            {Object.entries(invoice.customer_info).map(([key, value]) => {
              // Skip fields we've already handled
              if (['_id', 'name', 'email', 'phone', 'city', 'country', 'first_name', 'last_name', 'branch', 'vehicles', 'created_at', 'updated_at'].includes(key)) {
                return null;
              }
              
              // Skip empty values and objects/arrays 
              if (value === null || value === undefined || value === '' || typeof value === 'object') {
                return null;
              }
              
              // Format the key for display
              const formattedKey = key
                .split('_')
                .map(word => word.charAt(0).toUpperCase() + word.slice(1))
                .join(' ');
              
              return (
                <p className="text-sm text-gray-600 mb-1" key={key}>
                  {formattedKey}: {String(value)}
                </p>
              );
            })}
            
            <div className="mt-4 pt-4 border-t border-gray-200">
              <Link 
                href={`/Customers/${invoice?.customer_id || invoice?.customer_info?._id || ''}`}
                className="text-blue-600 hover:text-blue-800 text-sm font-medium flex items-center"
              >
                View Customer Profile
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  className="h-4 w-4 ml-1" 
                  fill="none" 
                  viewBox="0 0 24 24" 
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </Link>
            </div>
          </>
        ) : (
          <div className="text-center py-4 text-gray-500">
            <p>No customer information available</p>
          </div>
        )}
      </div>
    </div>
  );
};
