'use client';

import React, { useState, useEffect } from 'react';
import api from '@/services/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Badge } from '@/app/components/ui/badge';
import { Button } from '@/app/components/ui/button';
import { ChevronDown, ChevronRight, Clock, CheckCircle, XCircle, Circle, User, Calendar, AlertTriangle, FileImage } from 'lucide-react';

interface Stage {
  stageId: string;
  stageName: string;
  stageDescription: string;
  stageOrder: number;
  status: string;
  assignedTo?: string;
  startedAt?: string;
  completedAt?: string;
}

interface ServiceRoute {
  partName: string;
  partStatus: string;
  assignedTo?: string;
  service: {
    code: string;
    description: string;
    defaultLaborHours: number;
    notes?: string;
    specialRequirements?: string;
  };
  stages: Stage[];
  createdAt: string;
  updatedAt: string;
}

interface CancelledService {
  partName: string;
  partStatus: 'cancelled';
  reason: string;
  cancelledBy: string;
  cancelledAt: string;
  approvalImageUrl?: string;
}

interface ServiceRoutesData {
  invoice: {
    id: string;
    invoiceNumber: string;
    workOrderId: string;
  };
  workOrder: {
    id: string;
    workOrderNumber: string;
    status: string;
    description: string;
  };
  serviceRoutes: ServiceRoute[];
  cancelledServices: CancelledService[];
  summary: {
    totalParts: number;
    totalServices: number;
    totalCancelledParts: number;
    partsByStatus: Record<string, number>;
  };
}

interface ServiceDetailsProps {
  invoiceId: string;
}

const getStatusIcon = (status: string) => {
  switch (status?.toLowerCase()) {
    case 'completed':
      return <CheckCircle className="h-4 w-4 text-green-500" />;
    case 'in_progress':
    case 'in-progress':
      return <Clock className="h-4 w-4 text-yellow-500" />;
    case 'pending':
      return <Circle className="h-4 w-4 text-gray-400" />;
    case 'cancelled':
    case 'failed':
      return <XCircle className="h-4 w-4 text-red-500" />;
    default:
      return <Circle className="h-4 w-4 text-gray-400" />;
  }
};

const getStatusVariant = (status: string): 'default' | 'secondary' | 'destructive' | 'outline' => {
  switch (status?.toLowerCase()) {
    case 'completed':
      return 'default';
    case 'in_progress':
    case 'in-progress':
      return 'secondary';
    case 'pending':
      return 'outline';
    case 'cancelled':
    case 'failed':
      return 'destructive';
    default:
      return 'outline';
  }
};

const formatDate = (dateString: string) => {
  if (!dateString) return 'Not set';
  return new Date(dateString).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
};

export const ServiceDetails: React.FC<ServiceDetailsProps> = ({ invoiceId }) => {
  const [serviceData, setServiceData] = useState<ServiceRoutesData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [expandedParts, setExpandedParts] = useState<Set<string>>(new Set());

  useEffect(() => {
    const fetchServiceRoutes = async () => {
      if (!invoiceId) return;

      try {
        setLoading(true);
        setError(null);
        
        const response = await api.get(`/api/invoices/${invoiceId}/service-routes`);
        
        if (response) {
          setServiceData(response as unknown as ServiceRoutesData);
        } else {
          setError('No service data found');
        }
      } catch (err: any) {
        console.error('Error fetching service routes:', err);
        if (err?.response?.status === 404) {
          setError('No work order or service routes found for this invoice');
        } else {
          setError('Failed to load service details');
        }
      } finally {
        setLoading(false);
      }
    };

    fetchServiceRoutes();
  }, [invoiceId]);

  const togglePartExpansion = (partName: string) => {
    const newExpanded = new Set(expandedParts);
    if (newExpanded.has(partName)) {
      newExpanded.delete(partName);
    } else {
      newExpanded.add(partName);
    }
    setExpandedParts(newExpanded);
  };

  if (loading) {
    return (
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Service Details</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
            <span className="ml-2 text-gray-600">Loading service details...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Service Details</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <XCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">{error}</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!serviceData || !serviceData.serviceRoutes?.length) {
    return (
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Service Details</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <Circle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">No service routes found for this invoice</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          Service Details
          <Badge variant="outline" className="ml-2">
            {serviceData.summary.totalParts} Parts
          </Badge>
        </CardTitle>
        {serviceData.workOrder && (
          <div className="text-sm text-gray-600">
            Work Order: {serviceData.workOrder.workOrderNumber} 
            <Badge variant={getStatusVariant(serviceData.workOrder.status)} className="ml-2">
              {serviceData.workOrder.status}
            </Badge>
          </div>
        )}
      </CardHeader>
      <CardContent>
        {/* Summary Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 p-4 bg-gray-50 rounded-lg">
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">{serviceData.summary.totalParts}</div>
            <div className="text-sm text-gray-600">Total Parts</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">{serviceData.summary.totalServices}</div>
            <div className="text-sm text-gray-600">Services</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-red-600">{serviceData.summary.totalCancelledParts || 0}</div>
            <div className="text-sm text-gray-600">Cancelled</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-orange-600">
              {serviceData.summary.partsByStatus['in_progress'] || 0}
            </div>
            <div className="text-sm text-gray-600">In Progress</div>
          </div>
        </div>

        {/* Service Routes Table */}
        <div className="overflow-x-auto">
          <table className="w-full border border-gray-200 rounded-lg">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-700 border-b border-gray-200">Part Name</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-700 border-b border-gray-200">Service</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-700 border-b border-gray-200">Notes</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-700 border-b border-gray-200">Special Requirements</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {serviceData.serviceRoutes.map((route, index) => (
                <tr key={index} className="hover:bg-gray-50">
                  <td className="px-4 py-3 text-sm text-gray-900 border-r border-gray-200">
                    <div className="flex items-center space-x-2">
                      <span className="font-medium">{route.partName}</span>
                      <div className="flex items-center space-x-1">
                        {getStatusIcon(route.partStatus)}
                        <Badge variant={getStatusVariant(route.partStatus)} className="text-xs">
                          {route.partStatus}
                        </Badge>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-900 border-r border-gray-200">
                    <div>
                      <div className="font-medium">{route.service.code} - {route.service.description}</div>
                      <div className="text-xs text-gray-500 mt-1">
                        <Clock className="w-3 h-3 inline mr-1" />
                        {route.service.defaultLaborHours}h estimated
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-600 border-r border-gray-200">
                    {route.service.notes || '-'}
                  </td>
                  <td className="px-4 py-3 text-sm text-orange-600">
                    {route.service.specialRequirements || '-'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Expandable Stages Section (Optional) */}
        <div className="mt-6">
          <h3 className="text-lg font-semibold mb-4 text-gray-800">Detailed Stages View</h3>
          <div className="space-y-4">
            {serviceData.serviceRoutes.map((route, index) => (
              <div key={index} className="border border-gray-200 rounded-lg overflow-hidden">
                {/* Part Header */}
                <div className="bg-white p-4 border-b border-gray-100">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => togglePartExpansion(route.partName)}
                        className="p-1"
                      >
                        {expandedParts.has(route.partName) ? (
                          <ChevronDown className="h-4 w-4" />
                        ) : (
                          <ChevronRight className="h-4 w-4" />
                        )}
                      </Button>
                      <div>
                        <h3 className="font-semibold text-lg">{route.partName}</h3>
                        <p className="text-sm text-gray-600">
                          Service: {route.service.code} - {route.service.description}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {getStatusIcon(route.partStatus)}
                      <Badge variant={getStatusVariant(route.partStatus)}>
                        {route.partStatus}
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="mt-2 flex items-center space-x-4 text-sm text-gray-600">
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-1" />
                      {route.service.defaultLaborHours}h estimated
                    </div>
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 mr-1" />
                      {formatDate(route.updatedAt)}
                    </div>
                  </div>
                </div>

                {/* Stages (Expanded) */}
                {expandedParts.has(route.partName) && (
                  <div className="bg-gray-50 p-4">
                    <h4 className="font-medium mb-3 text-gray-800">Service Stages</h4>
                    <div className="space-y-3">
                      {route.stages.map((stage, stageIndex) => (
                        <div 
                          key={stage.stageId} 
                          className="bg-white p-3 rounded border border-gray-200 flex items-center justify-between"
                        >
                          <div className="flex items-center space-x-3">
                            <div className="flex items-center justify-center w-8 h-8 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                              {stage.stageOrder}
                            </div>
                            <div>
                              <div className="font-medium">{stage.stageName}</div>
                              <div className="text-sm text-gray-600">{stage.stageDescription}</div>
                            </div>
                          </div>
                          
                          <div className="flex flex-col items-end space-y-1">
                            <div className="flex items-center space-x-1">
                              {getStatusIcon(stage.status)}
                              <Badge variant={getStatusVariant(stage.status)}>
                                {stage.status}
                              </Badge>
                            </div>
                            <div className="text-xs text-gray-500">
                              {stage.completedAt ? (
                                <span>Completed: {formatDate(stage.completedAt)}</span>
                              ) : stage.startedAt ? (
                                <span>Started: {formatDate(stage.startedAt)}</span>
                              ) : (
                                <span>Not started</span>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Cancelled Services Section */}
        {serviceData.cancelledServices && serviceData.cancelledServices.length > 0 && (
          <div className="mt-8">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-red-500" />
              Cancelled Services
            </h3>
            <div className="space-y-4">
              {serviceData.cancelledServices.map((cancelled, index) => (
                <Card key={index} className="border-l-4 border-l-red-500 bg-red-50">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <XCircle className="w-5 h-5 text-red-500" />
                        <h4 className="font-semibold text-lg">{cancelled.partName}</h4>
                        <Badge variant="destructive">
                          {cancelled.partStatus}
                        </Badge>
                      </div>
                      <div className="text-sm text-gray-500">
                        <Calendar className="w-4 h-4 inline mr-1" />
                        {formatDate(cancelled.cancelledAt)}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <div className="text-sm font-medium text-gray-700">Cancellation Reason</div>
                        <div className="text-sm text-gray-600 bg-white p-2 rounded border">
                          {cancelled.reason}
                        </div>
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-700">Cancelled By</div>
                        <div className="text-sm flex items-center gap-1">
                          <User className="w-4 h-4" />
                          {cancelled.cancelledBy}
                        </div>
                      </div>
                    </div>

                    {cancelled.approvalImageUrl && (
                      <div className="mt-3 pt-3 border-t">
                        <div className="text-sm font-medium text-gray-700 mb-2">Approval Documentation</div>
                        <div className="flex items-center gap-2">
                          <FileImage className="w-4 h-4 text-blue-500" />
                          <a 
                            href={cancelled.approvalImageUrl} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:text-blue-800 underline text-sm"
                          >
                            View Approval Image
                          </a>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
