import React from 'react';
import { formatDate, formatCurrency, getStatusBadgeClass } from './InvoiceUtils';

interface InvoiceSummaryProps {
  invoice: any;
  subtotal: number;
  total: number;
  amountPaid: number;
  amountDue: number;
}

export const InvoiceSummary: React.FC<InvoiceSummaryProps> = ({
  invoice,
  subtotal,
  total,
  amountPaid,
  amountDue
}) => {
  return (
    <div className="bg-white rounded-lg shadow overflow-hidden">
      <div className="flex justify-between items-center p-6 border-b border-gray-200">
        <h2 className="text-xl font-semibold text-gray-800">Invoice Details</h2>
        <span 
          className={`inline-flex rounded-full px-3 py-1 text-sm font-medium ${getStatusBadgeClass(invoice?.payment_status)}`}
        >
          {invoice?.payment_status || 'Unknown'}
        </span>
      </div>
      
      <div className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div>
            <h3 className="text-sm font-medium text-gray-500 mb-1">Invoice Number</h3>
            <p className="text-base font-medium text-gray-900">{invoice?.invoice_number || 'N/A'}</p>
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500 mb-1">Invoice Date</h3>
            <p className="text-base text-gray-900">{formatDate(invoice?.invoice_date)}</p>
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500 mb-1">Total Amount</h3>
            <p className="text-lg font-bold text-gray-900">{formatCurrency(total)}</p>
          </div>
        </div>
        
        {/* Invoice Summary */}
        <div className="border-t border-gray-200 pt-4 mt-6">
          <div className="flex justify-between py-1.5">
            <span className="text-sm text-gray-600">Subtotal:</span>
            <span className="text-sm text-gray-900 font-medium">{formatCurrency(subtotal)}</span>
          </div>
          
          {(invoice?.tax !== undefined && invoice.tax !== null) && (
            <div className="flex justify-between py-1.5">
              <span className="text-sm text-gray-600">Tax:</span>
              <span className="text-sm text-gray-900 font-medium">{formatCurrency(invoice.tax)}</span>
            </div>
          )}
          
          {(invoice?.vat !== undefined && invoice.vat !== null) || 
           (invoice?.vat_amount !== undefined && invoice.vat_amount !== null) && (
            <div className="flex justify-between py-1.5">
              <span className="text-sm text-gray-600">VAT ({invoice?.vat || 5}%):</span>
              <span className="text-sm text-gray-900 font-medium">
                {formatCurrency(invoice.vat_amount || invoice.vat)}
              </span>
            </div>
          )}
          
          {invoice?.discount !== undefined && invoice.discount !== null && (
            <div className="flex justify-between py-1.5">
              <span className="text-sm text-gray-600">Discount:</span>
              <span className="text-sm text-gray-900 font-medium">- {formatCurrency(invoice.discount)}</span>
            </div>
          )}
          
          <div className="flex justify-between py-3 border-t border-gray-200 mt-2">
            <span className="text-base font-medium text-gray-900">Total:</span>
            <span className="text-base font-bold text-gray-900">{formatCurrency(total)}</span>
          </div>
          
          {amountPaid > 0 && (
            <div className="flex justify-between py-1.5">
              <span className="text-sm text-gray-600">Amount Paid:</span>
              <span className="text-sm text-green-600 font-medium">{formatCurrency(amountPaid)}</span>
            </div>
          )}
          
          {amountDue > 0 && (
            <div className="flex justify-between py-1.5">
              <span className="text-sm text-gray-600">Balance Due:</span>
              <span className="text-sm text-red-600 font-medium">{formatCurrency(amountDue)}</span>
            </div>
          )}
        </div>
        
        {/* Notes */}
        {invoice?.notes && (
          <div className="mt-6 pt-4 border-t border-gray-200">
            <h3 className="text-sm font-medium text-gray-500 mb-1">Notes</h3>
            <p className="text-sm text-gray-900">{invoice.notes}</p>
          </div>
        )}
      </div>
    </div>
  );
};
