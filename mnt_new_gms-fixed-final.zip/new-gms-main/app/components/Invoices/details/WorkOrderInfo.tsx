'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import api from '@/services/api';
import { Card } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { 
  getCustomerInfo, 
  getVehicleInfo, 
  formatStatus, 
  getStatusBadgeClasses, 
  getPriorityBadgeClasses,
  type FlexibleWorkOrder 
} from '@/lib/workOrderHelpers';

interface WorkOrderInfoProps {
  invoiceId: string;
}

export function WorkOrderInfo({ invoiceId }: WorkOrderInfoProps) {
  const router = useRouter();
  const [workOrder, setWorkOrder] = useState<FlexibleWorkOrder | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchWorkOrder = async () => {
      if (!invoiceId) return;

      try {
        setLoading(true);
        setError(null);
        
        const response = await api.get(`/api/invoices/${invoiceId}/work-order`);
        
        if (response) {
          // Handle case where response is the direct work order object
          const workOrderData = (response && typeof response === 'object' && '_id' in response) ? 
            response : 
            (response && typeof response === 'object' && 'data' in response) ? 
              response.data : null;
          
          if (workOrderData) {
            setWorkOrder(workOrderData as FlexibleWorkOrder);
          } else {
            setError('Invalid work order data format');
          }
        }
      } catch (err: any) {
        console.error('Error fetching work order:', err);
        if (err.response?.status === 404) {
          // Don't set error for 404, just set workOrder to null
          setWorkOrder(null);
        } else {
          setError('Failed to load work order information');
        }
      } finally {
        setLoading(false);
      }
    };

    fetchWorkOrder();
  }, [invoiceId]);

  const handleViewWorkOrder = () => {
    if (workOrder?._id) {
      router.push(`/workOrders/${workOrder._id}`);
    }
  };

  if (loading) {
    return (
      <Card className="p-6 mb-6">
        <h3 className="text-lg font-semibold mb-4 text-gray-800">Work Order Information</h3>
        <div className="animate-pulse">
          <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
          <div className="h-4 bg-gray-200 rounded w-1/2 mb-2"></div>
          <div className="h-4 bg-gray-200 rounded w-2/3"></div>
        </div>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="p-6 mb-6">
        <h3 className="text-lg font-semibold mb-4 text-gray-800">Work Order Information</h3>
        <div className="text-gray-500 text-center py-4">
          <p>{error}</p>
        </div>
      </Card>
    );
  }

  if (!workOrder) {
    return (
      <Card className="p-6 mb-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold text-gray-800">Work Order Information</h3>
        </div>
        <div className="text-gray-500 text-center py-4">
          <p>No work order linked to this invoice</p>
        </div>
      </Card>
    );
  }

  const customerInfo = getCustomerInfo(workOrder);
  const vehicleInfo = getVehicleInfo(workOrder);

  return (
    <Card className="p-6 mb-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold text-gray-800">Work Order Information</h3>
        <Button
          onClick={handleViewWorkOrder}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm"
        >
          View Work Order
        </Button>
      </div>

      <div className="space-y-4">
        {/* Work Order Number */}
        <div className="flex justify-between">
          <span className="text-gray-600">Work Order #:</span>
          <span className="font-medium text-gray-900">
            {workOrder.workOrderNumber || workOrder._id}
          </span>
        </div>

        {/* Status */}
        <div className="flex justify-between items-center">
          <span className="text-gray-600">Status:</span>
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusBadgeClasses(workOrder.status)}`}>
            {formatStatus(workOrder.status)}
          </span>
        </div>

        {/* Priority */}
        {workOrder.priority && (
          <div className="flex justify-between items-center">
            <span className="text-gray-600">Priority:</span>
            <span className={`px-2 py-1 rounded-full text-xs font-medium ${getPriorityBadgeClasses(workOrder.priority)}`}>
              {workOrder.priority.charAt(0).toUpperCase() + workOrder.priority.slice(1)}
            </span>
          </div>
        )}

        {/* Created Date */}
        {workOrder.createdAt && (
          <div className="flex justify-between">
            <span className="text-gray-600">Created:</span>
            <span className="text-gray-900">
              {new Date(workOrder.createdAt).toLocaleDateString()}
            </span>
          </div>
        )}

        {/* Vehicle Information */}
        <div className="border-t pt-4">
          <h4 className="text-sm font-semibold text-gray-700 mb-2">Vehicle</h4>
          <div className="text-sm text-gray-600">
            {vehicleInfo.display()}
          </div>
          {vehicleInfo.licensePlate && (
            <div className="text-sm text-gray-500">
              License: {vehicleInfo.licensePlate}
            </div>
          )}
        </div>

        {/* Estimated vs Actual Hours */}
        {(workOrder.totalEstimatedHours || workOrder.totalActualHours) && (
          <div className="border-t pt-4">
            <h4 className="text-sm font-semibold text-gray-700 mb-2">Time Tracking</h4>
            {workOrder.totalEstimatedHours && (
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Estimated Hours:</span>
                <span className="text-gray-900">{workOrder.totalEstimatedHours}h</span>
              </div>
            )}
            {workOrder.totalActualHours && (
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Actual Hours:</span>
                <span className="text-gray-900">{workOrder.totalActualHours}h</span>
              </div>
            )}
          </div>
        )}

        {/* Supervisor/Assigned To */}
        {(workOrder.supervisor || workOrder.assignedTo) && (
          <div className="border-t pt-4">
            <h4 className="text-sm font-semibold text-gray-700 mb-2">Assignment</h4>
            {workOrder.supervisor && (
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Supervisor:</span>
                <span className="text-gray-900">
                  {typeof workOrder.supervisor === 'object' 
                    ? workOrder.supervisor.name || workOrder.supervisor.fullName || 'Unknown'
                    : workOrder.supervisor
                  }
                </span>
              </div>
            )}
            {workOrder.assignedTo && (
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Assigned To:</span>
                <span className="text-gray-900">
                  {typeof workOrder.assignedTo === 'object' 
                    ? workOrder.assignedTo.name || workOrder.assignedTo.fullName || 'Unknown'
                    : workOrder.assignedTo
                  }
                </span>
              </div>
            )}
          </div>
        )}
      </div>
    </Card>
  );
}
