import React, { useState, useEffect } from 'react';
import { Button } from '@/app/components/ui/button';
import api from '@/services/api';

interface InvoiceImagesProps {
  invoice: any;
  onAddImage: (imageData: { url: string, description?: string }) => Promise<void>;
  onRemoveImage: (imageUrl: string) => Promise<void>;
}

interface InvoiceImage {
  url: string;
  key: string;
  filename: string;
  size: number;
  upload_date: string;
}

interface CachedUrl {
  url: string;
  timestamp: number;
}

export const InvoiceImages: React.FC<InvoiceImagesProps> = ({
  invoice,
  onAddImage,
  onRemoveImage
}) => {
  const [loading, setLoading] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploadDescription, setUploadDescription] = useState('');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [showImages, setShowImages] = useState(false); // Toggle for showing/hiding images - default hidden
  const [signedUrls, setSignedUrls] = useState<Map<number, CachedUrl>>(new Map()); // Cache for signed URLs with timestamps
  const [loadingImages, setLoadingImages] = useState<Set<number>>(new Set()); // Track loading state per image
  
  // Cache duration in milliseconds (55 minutes to be safe with 1-hour signed URLs)
  const CACHE_DURATION = 55 * 60 * 1000;

  // Handle keyboard events for image viewer
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && selectedImage) {
        setSelectedImage(null);
      }
    };

    if (selectedImage) {
      document.addEventListener('keydown', handleKeyDown);
    }

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [selectedImage]);

  // Fetch signed URL for an image
  const fetchSignedUrl = async (imageIndex: number): Promise<string | null> => {
    if (!invoice?._id) return null;
    
    // Check cache first
    const cachedData = signedUrls.get(imageIndex);
    if (cachedData) {
      const now = Date.now();
      const age = now - cachedData.timestamp;
      
      // Return cached URL if it's still valid
      if (age < CACHE_DURATION) {
        return cachedData.url;
      }
    }
    
    // Mark as loading
    setLoadingImages(prev => new Set(prev).add(imageIndex));
    
    try {
      const response = await api.get(`/api/invoices/${invoice._id}/images/${imageIndex}/view`);
      
      if (response && response.data && response.data.signedUrl) {
        // Cache the signed URL with timestamp
        const cachedUrl: CachedUrl = {
          url: response.data.signedUrl,
          timestamp: Date.now()
        };
        setSignedUrls(prev => new Map(prev).set(imageIndex, cachedUrl));
        return response.data.signedUrl;
      } else {
        console.error('Failed to get signed URL for image:', imageIndex);
        return null;
      }
    } catch (error) {
      console.error('Error fetching signed URL:', error);
      return null;
    } finally {
      setLoadingImages(prev => {
        const newSet = new Set(prev);
        newSet.delete(imageIndex);
        return newSet;
      });
    }
  };

  // Handle image click - fetch signed URL and show in modal
  const handleImageClick = async (imageIndex: number) => {
    const signedUrl = await fetchSignedUrl(imageIndex);
    if (signedUrl) {
      setSelectedImage(signedUrl);
    } else {
      console.error('Failed to load image. Please try again.');
    }
  };

  const handleAddImage = () => {
    setShowAddModal(true);
  };

  const handleFileUpload = async () => {
    if (!uploadFile || !invoice?._id) return;
    
    try {
      setLoading(true);
      
      // Create FormData for file upload
      const formData = new FormData();
      formData.append('image', uploadFile);
      if (uploadDescription) {
        formData.append('description', uploadDescription);
      }
      
      // Upload the image
      const response = await api.post(`/api/invoices/${invoice._id}/images`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      
      if (response) {
        // Reset form
        setUploadFile(null);
        setUploadDescription('');
        setShowAddModal(false);
        // Refresh page to get updated invoice data
        window.location.reload();
      }
    } catch (error) {
      console.error('Error uploading image:', error);
      console.error('Failed to upload image. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleRemoveImage = async (imageUrl: string) => {
    const confirmDelete = window.confirm('Are you sure you want to delete this image?');
    
    if (confirmDelete) {
      try {
        setLoading(true);
        await onRemoveImage(imageUrl);
      } catch (error) {
        console.error('Error removing image:', error);
        console.error('Failed to remove image. Please try again.');
      } finally {
        setLoading(false);
      }
    }
  };

  // Get images from invoice object
  const images: InvoiceImage[] = invoice?.images || [];

  // Format file size
  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    else if (bytes < 1048576) return Math.round(bytes / 1024) + ' KB';
    else return (bytes / 1048576).toFixed(1) + ' MB';
  };

  // Format date
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  // Component to display image thumbnail with lazy loading
  const ImageThumbnail: React.FC<{ image: InvoiceImage; index: number }> = ({ image, index }) => {
    const [thumbnailUrl, setThumbnailUrl] = useState<string | null>(null);
    const [hasError, setHasError] = useState(false);
    const [hasLoaded, setHasLoaded] = useState(false);
    const isLoading = loadingImages.has(index);
    const invoiceIdRef = React.useRef(invoice?._id);

    // Load thumbnail on mount
    useEffect(() => {
      let isMounted = true;
      
      const loadThumbnail = async () => {
        // Skip if already loaded or loading
        if (hasLoaded || !invoice?._id) return;
        
        const url = await fetchSignedUrl(index);
        if (isMounted && url) {
          setThumbnailUrl(url);
          setHasLoaded(true);
        }
      };
      
      // Only load if we have images and an invoice ID
      if (invoice?._id && images.length > 0 && !hasLoaded) {
        loadThumbnail();
      }
      
      // Reset hasLoaded if invoice ID changes
      if (invoice?._id !== invoiceIdRef.current) {
        invoiceIdRef.current = invoice?._id;
        setHasLoaded(false);
        setThumbnailUrl(null);
      }
      
      return () => {
        isMounted = false;
      };
    }, [index, hasLoaded, invoice?._id]);

    return (
      <div className="relative group">
        <div 
          className="aspect-square bg-gray-100 rounded-lg overflow-hidden cursor-pointer hover:shadow-lg transition-shadow"
          onClick={() => handleImageClick(index)}
        >
          {isLoading || !thumbnailUrl ? (
            <div className="w-full h-full flex items-center justify-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            </div>
          ) : hasError ? (
            <div className="w-full h-full flex items-center justify-center bg-gray-50">
              <svg className="w-12 h-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
            </div>
          ) : (
            <img
              src={thumbnailUrl}
              alt={image.filename || `Invoice image ${index + 1}`}
              className="w-full h-full object-cover"
              onError={() => setHasError(true)}
            />
          )}
          {/* Overlay with image info */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-200">
            <div className="absolute bottom-0 left-0 right-0 p-3 text-white">
              <p className="text-xs font-medium truncate">{image.filename || `Image ${index + 1}`}</p>
              <p className="text-xs opacity-90">
                {formatFileSize(image.size)} • {formatDate(image.upload_date)}
              </p>
            </div>
          </div>
        </div>
        {/* Delete button */}
        <button 
          onClick={(e) => {
            e.stopPropagation();
            handleRemoveImage(image.url);
          }}
          className="absolute top-2 right-2 bg-red-600 text-white rounded-full p-1.5 opacity-0 group-hover:opacity-100 hover:bg-red-700 transition-all duration-200 shadow-lg"
          title="Delete image"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
          </svg>
        </button>
      </div>
    );
  };

  return (
    <div className="bg-white rounded-lg shadow mt-6 overflow-hidden">
      <div className="flex justify-between items-center p-6 border-b border-gray-200">
        <div className="flex items-center space-x-4">
          <h2 className="text-xl font-semibold text-gray-800">Images</h2>
          {images.length > 0 && (
            <span className="bg-gray-100 text-gray-600 text-sm px-2 py-1 rounded">
              {images.length} {images.length === 1 ? 'image' : 'images'}
            </span>
          )}
        </div>
        <div className="flex items-center space-x-2">
          {images.length > 0 && (
            <Button
              onClick={() => setShowImages(!showImages)}
              variant="outline"
              size="sm"
              className="text-gray-600"
            >
              {showImages ? 'Hide Images' : 'Show Images'}
            </Button>
          )}
          <Button 
            onClick={handleAddImage}
            disabled={loading}
            className="bg-blue-600 text-white hover:bg-blue-700 text-sm flex items-center"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
            Add Image
          </Button>
        </div>
      </div>
      <div className="p-6">
        {loading ? (
          <div className="text-center py-6 text-gray-500">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-2"></div>
            <p>Processing...</p>
          </div>
        ) : images.length > 0 ? (
          showImages ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {images.map((image, index) => (
                <ImageThumbnail key={index} image={image} index={index} />
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <p>Images hidden. Click "Show Images" to view them.</p>
            </div>
          )
        ) : (
          <div className="text-center py-8 text-gray-500">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto text-gray-400 mb-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
            <p>No images available for this invoice</p>
          </div>
        )}
      </div>
      
      {/* Add Image Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-md w-full">
            <div className="p-6 border-b">
              <h3 className="text-lg font-semibold">Add New Image</h3>
            </div>
            <div className="p-6">
              <div className="mb-4">
                <label className="block text-sm font-medium mb-2">Select Image File</label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => setUploadFile(e.target.files?.[0] || null)}
                  className="w-full p-2 border border-gray-300 rounded"
                />
              </div>
              <div className="mb-4">
                <label className="block text-sm font-medium mb-2">Description (Optional)</label>
                <input
                  type="text"
                  value={uploadDescription}
                  onChange={(e) => setUploadDescription(e.target.value)}
                  placeholder="Enter image description..."
                  className="w-full p-2 border border-gray-300 rounded"
                />
              </div>
              {uploadFile && (
                <div className="mb-4">
                  <p className="text-sm text-gray-600">
                    Selected: {uploadFile.name} ({(uploadFile.size / 1024).toFixed(1)} KB)
                  </p>
                </div>
              )}
            </div>
            <div className="p-6 border-t flex justify-end space-x-3">
              <Button
                variant="outline"
                onClick={() => {
                  setShowAddModal(false);
                  setUploadFile(null);
                  setUploadDescription('');
                }}
                disabled={loading}
              >
                Cancel
              </Button>
              <Button
                onClick={handleFileUpload}
                disabled={!uploadFile || loading}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {loading ? 'Uploading...' : 'Upload Image'}
              </Button>
            </div>
          </div>
        </div>
      )}
      
      {/* Image Viewer Modal */}
      {selectedImage && (
        <div className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center z-50">
          {/* Backdrop */}
          <div 
            className="absolute inset-0"
            onClick={() => setSelectedImage(null)}
          />
          
          {/* Image Container */}
          <div className="relative z-10 max-w-[90vw] max-h-[90vh] flex items-center justify-center">
            <img
              src={selectedImage}
              alt="Invoice image"
              className="max-w-full max-h-[90vh] object-contain rounded-lg shadow-2xl"
              onError={(e) => {
                console.error('Large image failed to load:', selectedImage);
                (e.target as HTMLImageElement).src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjMwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICA8cmVjdCB3aWR0aD0iNDAwIiBoZWlnaHQ9IjMwMCIgZmlsbD0iI2Y0ZjRmNCIvPgogIDx0ZXh0IHg9IjUwJSIgeT0iNTAlIiBmb250LWZhbWlseT0iQXJpYWwiIGZvbnQtc2l6ZT0iMjAiIGZpbGw9IiM5OTkiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGR5PSIuM2VtIj5JbWFnZSBub3QgYXZhaWxhYmxlPC90ZXh0Pgo8L3N2Zz4=';
              }}
            />
            
            {/* Close button */}
            <button
              onClick={() => setSelectedImage(null)}
              className="absolute top-4 right-4 text-white bg-black bg-opacity-60 rounded-full p-2 hover:bg-opacity-80 transition-all duration-200"
              title="Close (Esc)"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
            
            {/* Download button */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                if (selectedImage) {
                  // Open in new tab for download
                  window.open(selectedImage, '_blank');
                }
              }}
              className="absolute bottom-4 right-4 text-white bg-black bg-opacity-60 rounded-full p-2 hover:bg-opacity-80 transition-all duration-200"
              title="Download"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
              </svg>
            </button>
          </div>
          
          {/* Instructions */}
          <div className="absolute bottom-4 left-4 text-white text-sm bg-black bg-opacity-60 px-3 py-2 rounded">
            Click outside or press Esc to close
          </div>
        </div>
      )}
    </div>
  );
};