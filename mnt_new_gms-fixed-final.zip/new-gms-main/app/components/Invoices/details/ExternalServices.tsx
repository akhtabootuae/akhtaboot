'use client';

import React, { useState, useRef, useEffect } from 'react';
import api from '@/services/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Badge } from '@/app/components/ui/badge';
import { Button } from '@/app/components/ui/button';
import DocumentViewer from '@/app/components/ui/DocumentViewer';
import { 
  Plus, 
  DollarSign, 
  FileText, 
  Trash2, 
  Eye, 
  Upload, 
  AlertTriangle, 
  Download
} from 'lucide-react';

interface ExternalService {
  cost: number;
  profit: number;
  notes: string;
  created_at: string;
  invoice_image?: {
    url: string;
    key: string;
    filename: string;
    size: number;
    upload_date: string;
  };
}

interface ExternalServicesProps {
  invoiceId: string;
  invoice?: any; // Accept invoice object directly
  onServiceAdded?: () => void;
}

const ExternalServices: React.FC<ExternalServicesProps> = ({ invoiceId, invoice, onServiceAdded }) => {
  const [loading, setLoading] = useState(false);
  const [showAddForm, setShowAddForm] = useState(false);
  const [formData, setFormData] = useState({
    cost: '',
    profit: '',
    notes: ''
  });
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [deleteModal, setDeleteModal] = useState<{
    isOpen: boolean;
    serviceIndex: number | null;
    serviceCost: number;
    serviceProfit: number;
  }>({
    isOpen: false,
    serviceIndex: null,
    serviceCost: 0,
    serviceProfit: 0
  });
  const [deleting, setDeleting] = useState(false);
  const [documentViewer, setDocumentViewer] = useState<{
    isOpen: boolean;
    imageUrl: string;
    filename: string;
  }>({
    isOpen: false,
    imageUrl: '',
    filename: ''
  });

  // Get external services from invoice object
  const externalServices: ExternalService[] = invoice?.external_services || [];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.cost || !formData.profit) {
      console.error('Cost and profit are required');
      return;
    }

    if (!selectedFile) {
      console.error('Invoice image is required');
      return;
    }

    try {
      setSubmitting(true);
      
      const submitData = new FormData();
      submitData.append('cost', formData.cost);
      submitData.append('profit', formData.profit);
      submitData.append('notes', formData.notes);
      
      if (selectedFile) {
        submitData.append('invoiceImage', selectedFile);
      }

      await api.post(`/api/invoices/${invoiceId}/external-services`, submitData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      // Reset form
      setFormData({ cost: '', profit: '', notes: '' });
      setSelectedFile(null);
      setShowAddForm(false);
      
      // Notify parent to refresh invoice data
      if (onServiceAdded) {
        onServiceAdded();
      }
      
    } catch (error: any) {
      console.error('Failed to add external service:', error);
      console.error(error.response?.data?.message || 'Failed to add external service');
    } finally {
      setSubmitting(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validate file type
      const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'application/pdf'];
      if (!allowedTypes.includes(file.type)) {
        console.error('Only JPEG, PNG, and PDF files are allowed');
        return;
      }
      
      // Validate file size (5MB)
      if (file.size > 5 * 1024 * 1024) {
        console.error('File size must be less than 5MB');
        return;
      }
      
      setSelectedFile(file);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-AE', {
      style: 'currency',
      currency: 'AED'
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const totalExternalCost = externalServices.reduce((sum, service) => sum + service.cost, 0);
  const totalExternalProfit = externalServices.reduce((sum, service) => sum + service.profit, 0);

  const handleDeleteService = async () => {
    if (deleteModal.serviceIndex === null) return;

    try {
      setDeleting(true);
      
      await api.delete(`/api/invoices/${invoiceId}/external-services/${deleteModal.serviceIndex}`);
      
      // Close modal
      setDeleteModal({
        isOpen: false,
        serviceIndex: null,
        serviceCost: 0,
        serviceProfit: 0
      });
      
      // Notify parent to refresh invoice data
      if (onServiceAdded) {
        onServiceAdded();
      }
      
    } catch (error: any) {
      console.error('Failed to delete external service:', error);
      console.error(error.response?.data?.message || 'Failed to delete external service');
    } finally {
      setDeleting(false);
    }
  };

  const openDeleteModal = (index: number, cost: number, profit: number) => {
    setDeleteModal({
      isOpen: true,
      serviceIndex: index,
      serviceCost: cost,
      serviceProfit: profit
    });
  };

  const closeDeleteModal = () => {
    setDeleteModal({
      isOpen: false,
      serviceIndex: null,
      serviceCost: 0,
      serviceProfit: 0
    });
  };

  const openImageModal = async (serviceIndex: number, filename: string) => {
    try {
      const response = await api.get(`/api/invoices/${invoiceId}/external-services/${serviceIndex}/image`);

      if (response && response.data && response.data.signedUrl) {
        setDocumentViewer({
          isOpen: true,
          imageUrl: response.data.signedUrl,
          filename: response.data.filename || filename
        });
      } else {
        console.error('Failed to get signed URL:', response);
        console.error('Failed to load image. Please try again.');
      }
    } catch (error: any) {
      console.error('Error fetching image:', error);
      console.error(error.response?.data?.message || 'Failed to load image');
    }
  };

  const closeImageModal = () => {
    setDocumentViewer({
      isOpen: false,
      imageUrl: '',
      filename: ''
    });
  };

  const downloadImage = (imageUrl: string, filename: string) => {
    const link = document.createElement('a');
    link.href = imageUrl;
    link.download = filename;
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <Card className="mt-6">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="w-5 h-5" />
            External Services
            {externalServices.length > 0 && (
              <Badge variant="outline">{externalServices.length}</Badge>
            )}
          </CardTitle>
          <Button
            onClick={() => setShowAddForm(!showAddForm)}
            size="sm"
            variant={showAddForm ? "outline" : "default"}
          >
            <Plus className="w-4 h-4 mr-1" />
            Add Service
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {/* Add Form */}
        {showAddForm && (
          <Card className="mb-6 border-2 border-dashed border-blue-300">
            <CardContent className="p-4">
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Cost *
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      value={formData.cost}
                      onChange={(e) => setFormData({ ...formData, cost: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="0.00"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Profit *
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      value={formData.profit}
                      onChange={(e) => setFormData({ ...formData, profit: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="0.00"
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Notes
                  </label>
                  <textarea
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    rows={3}
                    placeholder="Additional notes about this external service..."
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Invoice Image <span className="text-red-500">*</span>
                  </label>
                  <div className="flex items-center space-x-4">
                    <input
                      type="file"
                      accept="image/*,.pdf"
                      onChange={handleFileChange}
                      className="hidden"
                      id="invoice-file"
                      required
                    />
                    <label
                      htmlFor="invoice-file"
                      className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 cursor-pointer"
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      Choose File
                    </label>
                    {selectedFile && (
                      <span className="text-sm text-gray-600">
                        {selectedFile.name} ({(selectedFile.size / 1024 / 1024).toFixed(2)} MB)
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    Supports JPEG, PNG, PDF files up to 5MB
                  </p>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Button type="submit" disabled={submitting}>
                    {submitting ? 'Adding...' : 'Add Service'}
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setShowAddForm(false);
                      setFormData({ cost: '', profit: '', notes: '' });
                      setSelectedFile(null);
                    }}
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Summary */}
        {externalServices.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 p-4 bg-blue-50 rounded-lg">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">
                {formatCurrency(totalExternalCost)}
              </div>
              <div className="text-sm text-gray-600">Total Cost</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">
                {formatCurrency(totalExternalProfit)}
              </div>
              <div className="text-sm text-gray-600">Total Profit</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">
                {formatCurrency(totalExternalCost + totalExternalProfit)}
              </div>
              <div className="text-sm text-gray-600">Total Value</div>
            </div>
          </div>
        )}

        {/* Services List */}
        {loading ? (
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
          </div>
        ) : externalServices.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <DollarSign className="w-12 h-12 mx-auto mb-3 text-gray-300" />
            <div className="text-lg mb-2">Ready to add external services</div>
            <div className="text-sm">Track external costs and profits for this invoice. Click "Add Service" to get started.</div>
          </div>
        ) : (
          <div className="space-y-4">
            {externalServices.map((service, index) => (
              <Card key={index} className="border-l-4 border-l-green-500">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-4 mb-2">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-blue-600">
                            {formatCurrency(service.cost)}
                          </span>
                          <span className="text-gray-400">+</span>
                          <span className="font-semibold text-green-600">
                            {formatCurrency(service.profit)}
                          </span>
                          <span className="text-gray-400">=</span>
                          <span className="font-bold text-purple-600">
                            {formatCurrency(service.cost + service.profit)}
                          </span>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          {formatDate(service.created_at)}
                        </Badge>
                      </div>
                      
                      {service.notes && (
                        <div className="text-sm text-gray-600 mb-2">
                          <FileText className="w-4 h-4 inline mr-1" />
                          {service.notes}
                        </div>
                      )}
                      
                      {service.invoice_image && (
                        <div className="mt-3">
                          {/* Thumbnail Preview */}
                          <div className="flex items-start gap-3">
                            <div 
                              className="w-20 h-20 bg-gray-100 rounded-lg overflow-hidden cursor-pointer hover:shadow-md transition-shadow flex-shrink-0"
                              onClick={() => {
                                openImageModal(index, service.invoice_image!.filename);
                              }}
                            >
                              {service.invoice_image.filename.toLowerCase().endsWith('.pdf') ? (
                                <div className="w-full h-full flex items-center justify-center bg-gray-50">
                                  <FileText className="w-8 h-8 text-gray-400" />
                                </div>
                              ) : (
                                <div className="w-full h-full flex items-center justify-center bg-gray-50">
                                  <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                  </svg>
                                </div>
                              )}
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <Button
                                  onClick={() => {
                                    openImageModal(index, service.invoice_image!.filename);
                                  }}
                                  variant="outline"
                                  size="sm"
                                  className="text-blue-600 hover:text-blue-800"
                                >
                                  <Eye className="w-4 h-4 mr-1" />
                                  View
                                </Button>
                                <Button
                                  onClick={async () => {
                                    try {
                                      const response = await api.get(`/api/invoices/${invoiceId}/external-services/${index}/image`);
                                      
                                      if (response && response.data && response.data.signedUrl) {
                                        downloadImage(response.data.signedUrl, response.data.filename || service.invoice_image!.filename);
                                      } else {
                                        console.error('Failed to get signed URL for download:', response);
                                        console.error('Failed to download image. Please try again.');
                                      }
                                    } catch (error: any) {
                                      console.error('Error downloading image:', error);
                                      console.error(error.response?.data?.message || 'Failed to download image');
                                    }
                                  }}
                                  variant="outline"
                                  size="sm"
                                  className="text-green-600 hover:text-green-800"
                                >
                                  <Download className="w-4 h-4 mr-1" />
                                  Download
                                </Button>
                              </div>
                              <p className="text-xs text-gray-500">
                                {service.invoice_image.filename}
                              </p>
                              <p className="text-xs text-gray-400">
                                {(service.invoice_image.size / 1024 / 1024).toFixed(2)} MB
                              </p>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                    <div className="ml-4">
                      <Button
                        onClick={() => openDeleteModal(index, service.cost, service.profit)}
                        variant="outline"
                        size="icon"
                        className="text-red-600 hover:text-red-800"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Delete Confirmation Modal */}
        {deleteModal.isOpen && (
          <div className="fixed inset-0 flex items-center justify-center z-50">
            {/* Backdrop */}
            <div 
              className="absolute inset-0 bg-black bg-opacity-50"
              onClick={closeDeleteModal}
            ></div>
            
            {/* Modal Content */}
            <div className="relative bg-white rounded-lg shadow-xl p-6 max-w-md w-full mx-4">
              <div className="flex items-center gap-3 mb-4">
                <div className="flex-shrink-0 w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
                  <AlertTriangle className="w-5 h-5 text-red-600" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">
                    Delete External Service
                  </h3>
                  <p className="text-sm text-gray-500">
                    This action cannot be undone.
                  </p>
                </div>
              </div>
              
              <div className="mb-6">
                <p className="text-gray-700 mb-3">
                  Are you sure you want to delete this external service?
                </p>
                <div className="bg-gray-50 p-3 rounded-lg">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Cost:</span>
                    <span className="font-semibold text-blue-600">
                      {formatCurrency(deleteModal.serviceCost)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm mt-1">
                    <span className="text-gray-600">Profit:</span>
                    <span className="font-semibold text-green-600">
                      {formatCurrency(deleteModal.serviceProfit)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm mt-2 pt-2 border-t border-gray-200">
                    <span className="text-gray-600">Total:</span>
                    <span className="font-bold text-purple-600">
                      {formatCurrency(deleteModal.serviceCost + deleteModal.serviceProfit)}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end space-x-3">
                <Button
                  onClick={closeDeleteModal}
                  variant="outline"
                  disabled={deleting}
                  className="text-gray-700 hover:text-gray-900"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleDeleteService}
                  disabled={deleting}
                  className="bg-red-600 text-white hover:bg-red-700"
                >
                  {deleting ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Deleting...
                    </>
                  ) : (
                    <>
                      <Trash2 className="w-4 h-4 mr-2" />
                      Delete Service
                    </>
                  )}
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Document Viewer */}
        <DocumentViewer
          isOpen={documentViewer.isOpen}
          onClose={closeImageModal}
          documentUrl={documentViewer.imageUrl}
          filename={documentViewer.filename}
          onDownload={() => downloadImage(documentViewer.imageUrl, documentViewer.filename)}
        />
      </CardContent>
    </Card>
  );
};

export default ExternalServices;
