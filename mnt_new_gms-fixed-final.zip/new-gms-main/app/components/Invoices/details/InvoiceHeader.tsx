import React from 'react';

interface InvoiceHeaderProps {
  invoice: any;
  onBack: () => void;
  onPrint: () => void;
  onPrintCarJob: () => void;
  isPrintLoading?: boolean;
  isCarJobPrintLoading?: boolean;
  onAddTax?: () => void;
  onRemoveTax?: () => void;
  isAddTaxLoading?: boolean;
  isRemoveTaxLoading?: boolean;
  onCreateCase?: () => void;
}

export const InvoiceHeader: React.FC<InvoiceHeaderProps> = ({
  invoice,
  onBack,
  onPrint,
  onPrintCarJob,
  isPrintLoading = false,
  isCarJobPrintLoading = false,
  onAddTax,
  onRemoveTax,
  isAddTaxLoading = false,
  isRemoveTaxLoading = false,
  onCreateCase
}) => {
  return (
    <div className="flex justify-between items-center mb-8">
      <div>
        <button 
          onClick={onBack}
          className="flex items-center text-gray-600 hover:text-gray-900 mb-2"
        >
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            className="h-5 w-5 mr-1" 
            fill="none" 
            viewBox="0 0 24 24" 
            stroke="currentColor"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
          </svg>
          Back to Invoices
        </button>
        <h1 className="text-3xl font-bold text-gray-900">
          Invoice {invoice?.invoice_number || 'N/A'}
        </h1>
      </div>

      <div className="flex space-x-3">
        {onCreateCase && (
          <button
            className="bg-purple-600 text-white hover:bg-purple-700 px-4 py-2 rounded-md flex items-center"
            onClick={onCreateCase}
          >
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              className="h-4 w-4 mr-1.5" 
              fill="none" 
              viewBox="0 0 24 24" 
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            Create Case
          </button>
        )}

        <button
          className={`bg-blue-600 text-white hover:bg-blue-700 px-4 py-2 rounded-md flex items-center ${isPrintLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
          onClick={onPrint}
          disabled={isPrintLoading}
        >
          {isPrintLoading ? (
            <>
              <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Preparing Print...
            </>
          ) : (
            <>
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                className="h-4 w-4 mr-1.5" 
                fill="none" 
                viewBox="0 0 24 24" 
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" />
              </svg>
              Print Invoice
            </>
          )}
        </button>

        <button
          className={`bg-green-600 text-white hover:bg-green-700 px-4 py-2 rounded-md flex items-center ${isCarJobPrintLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
          onClick={onPrintCarJob}
          disabled={isCarJobPrintLoading}
        >
          {isCarJobPrintLoading ? (
            <>
              <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Preparing Print...
            </>
          ) : (
            <>
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                className="h-4 w-4 mr-1.5" 
                fill="none" 
                viewBox="0 0 24 24" 
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              Print Car Job
            </>
          )}
        </button>

        {onAddTax && (
          <button
            className={`bg-orange-600 text-white hover:bg-orange-700 px-4 py-2 rounded-md flex items-center ${isAddTaxLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
            onClick={onAddTax}
            disabled={isAddTaxLoading}
          >
            {isAddTaxLoading ? (
              <>
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Adding Tax...
              </>
            ) : (
              <>
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  className="h-4 w-4 mr-1.5" 
                  fill="none" 
                  viewBox="0 0 24 24" 
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
                Add Tax
              </>
            )}
          </button>
        )}

        {onRemoveTax && (
          <button
            className={`bg-red-600 text-white hover:bg-red-700 px-4 py-2 rounded-md flex items-center ${isRemoveTaxLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
            onClick={onRemoveTax}
            disabled={isRemoveTaxLoading}
          >
            {isRemoveTaxLoading ? (
              <>
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Removing Tax...
              </>
            ) : (
              <>
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  className="h-4 w-4 mr-1.5" 
                  fill="none" 
                  viewBox="0 0 24 24" 
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" />
                </svg>
                Remove Tax
              </>
            )}
          </button>
        )}
      </div>
    </div>
  );
};
