'use client';

import React from 'react';

export default function EmptyState() {
  return (
    <tr>
      <td colSpan={8} className="px-6 py-12 text-center bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="flex flex-col items-center space-y-3">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-100 to-indigo-200 rounded-full flex items-center justify-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
          </div>
          <div className="text-center space-y-1">
            <h3 className="text-lg font-semibold text-gray-900">No Invoices Found</h3>
            <p className="text-gray-600 text-sm max-w-md">
              No invoices match your current search criteria. Try adjusting your filters.
            </p>
          </div>
        </div>
      </td>
    </tr>
  );
}
