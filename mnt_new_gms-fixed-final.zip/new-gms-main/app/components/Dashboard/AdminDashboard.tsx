'use client';

import { useEffect, useState } from "react";
import Link from "next/link";
import { 
  Calendar, 
  Clock, 
  Users, 
  TrendingUp,
  TrendingDown, 
  AlertCircle, 
  CheckCircle,
  ArrowUpRight,
  Activity,
  DollarSign,
  FileText,
  Settings,
  BarChart3,
  Folder,
  ChevronLeft,
  ChevronRight
} from "lucide-react";
import { notificationsApi, financeApi, payrollApi, caseApi } from "@/services/api";
import api from "@/services/api";

interface DashboardData {
  notifications: { total: number; unread: number; highPriority: number };
  workOrders: { total: number; pending: number; inProgress: number; completed: number; cancelled: number };
  invoices: { total: number; paid: number; unpaid: number; overdue: number };
  attendance: { totalRecords: number; approved: number; avgHoursPerDay: number };
  revenue: { 
    total_revenue: number; 
    net_profit: number; 
    profit_margin: number;
    total_paid: number;
    outstanding_amount: number;
  };
  recentNotifications: Notification[];
  recentCases: Case[];
  totalCases: number;
  isLoading: boolean;
}

interface Notification {
  _id: string;
  message: string;
  priority: 'high' | 'medium' | 'low';
  createdAt: string;
  workOrderId?: string;
}

interface Case {
  _id: string;
  title: string;
  description: string;
  status: string;
  priority: string;
  createdAt: string;
}

interface User {
  name?: string;
  role_name?: string;
  branch?: {
    branch_name?: string;
  };
}

interface WorkOrder {
  status: string;
}

interface Invoice {
  payment_status?: string;
  paymentStatus?: string;
  status?: string;
}

interface TimeSheet {
  status: string;
  total_hours?: number;
}

export default function AdminDashboard({ user }: { user: User }) {
  const [dashboardData, setDashboardData] = useState<DashboardData>({
    notifications: { total: 0, unread: 0, highPriority: 0 },
    workOrders: { total: 0, pending: 0, inProgress: 0, completed: 0, cancelled: 0 },
    invoices: { total: 0, paid: 0, unpaid: 0, overdue: 0 },
    attendance: { totalRecords: 0, approved: 0, avgHoursPerDay: 0 },
    revenue: { 
      total_revenue: 0, 
      net_profit: 0, 
      profit_margin: 0,
      total_paid: 0,
      outstanding_amount: 0,
    },
    recentNotifications: [],
    recentCases: [],
    totalCases: 0,
    isLoading: true
  });
  
  const [currentCasePage, setCurrentCasePage] = useState(1);
  const casesPerPage = 3;

  // Fetch dashboard data
  useEffect(() => {
    fetchDashboardData();
  }, []);

  // Fetch cases when page changes
  useEffect(() => {
    fetchCasesData();
  }, [currentCasePage]);

  const fetchCasesData = async () => {
    try {
      const response = await caseApi.getCases({ 
        page: currentCasePage, 
        limit: casesPerPage, 
        sortBy: 'createdAt', 
        sortOrder: 'desc' 
      });

      let casesArray: Case[] = [];
      let total = 0;

      // Handle different API response formats
      if (response && typeof response === 'object') {
        // Check if it's an Axios response with data property
        if ('data' in response && response.data) {
          const responseData = response.data;
          if (typeof responseData === 'object' && 'data' in responseData && Array.isArray(responseData.data)) {
            casesArray = responseData.data;
            total = responseData.total || responseData.totalItems || responseData.count || responseData.data.length;
          } else if (Array.isArray(responseData)) {
            casesArray = responseData;
            total = responseData.length === casesPerPage ? responseData.length * 2 : responseData.length;
          }
        } 
        // Check if response itself has data array
        else if ('data' in response && Array.isArray(response.data)) {
          casesArray = response.data;
          total = (response as any)?.total || (response as any)?.totalItems || (response as any)?.count || response.data.length;
        } 
        // Check if response is directly an array
        else if (Array.isArray(response)) {
          casesArray = response;
          total = response.length === casesPerPage ? response.length * 2 : response.length;
        }
      }

      // Ensure we only display the exact number of cases per page
      const limitedCases = casesArray.slice(0, casesPerPage);

      setDashboardData(prev => ({ 
        ...prev, 
        recentCases: limitedCases,
        totalCases: total
      }));
    } catch (error) {
      setDashboardData(prev => ({ 
        ...prev, 
        recentCases: [],
        totalCases: 0
      }));
    }
  };

  const fetchDashboardData = async () => {
    try {
      setDashboardData(prev => ({ ...prev, isLoading: true }));

      // Date filters
      const today = new Date();
      const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
      const endOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      const startOfDay = new Date(today.getFullYear(), today.getMonth(), today.getDate());
      const endOfDay = new Date(today.getFullYear(), today.getMonth(), today.getDate(), 23, 59, 59);

      // Fetch notification stats
      const notificationStats = await notificationsApi.getNotificationStats();

      // Fetch work orders data (today's date)
      const workOrderData = await api.get('/api/work-orders', {
        params: {
          start_date: startOfDay.toISOString(),
          end_date: endOfDay.toISOString()
        }
      });

      // Fetch invoice data (monthly)
      const invoiceData = await api.get('api/invoices/list', {
        params: {
          start_date: startOfMonth.toISOString(),
          end_date: endOfMonth.toISOString()
        }
      });

      // Fetch financial summary data (monthly)
      const financeData = await financeApi.getSummary({
        start_date: startOfMonth.toISOString().split('T')[0],
        end_date: endOfMonth.toISOString().split('T')[0]
      });

      // Fetch attendance data (today's date)
      const attendanceData = await payrollApi.getTimeSheets({
        start_date: startOfDay.toISOString().split('T')[0],
        end_date: endOfDay.toISOString().split('T')[0],
        limit: 100
      });

      // Fetch recent notifications
      const recentNotifications = await notificationsApi.getNotifications({ status: 'unread' }).then((response: unknown) => {
        const data = Array.isArray(response) ? response : ((response as any)?.data || []);
        return data.slice(0, 5);
      });

      // Process work order stats
      const workOrderSummary = {
        total: 0,
        pending: 0,
        inProgress: 0,
        completed: 0,
        cancelled: 0
      };

      // Handle API response formats for work orders
      let workOrdersArray: WorkOrder[] = [];
      if (workOrderData && typeof workOrderData === 'object') {
        if ('data' in workOrderData && Array.isArray(workOrderData.data)) {
          workOrdersArray = workOrderData.data;
        } else if ('workOrders' in workOrderData && Array.isArray(workOrderData.workOrders)) {
          workOrdersArray = workOrderData.workOrders;
        } else if (Array.isArray(workOrderData)) {
          workOrdersArray = workOrderData;
        }
      }

      workOrderSummary.total = workOrdersArray.length;

      workOrdersArray.forEach((workOrder: WorkOrder) => {
        const status = workOrder.status;
        
        switch (status) {
          case 'open':
            workOrderSummary.pending++;
            break;
          case 'in_progress':
            workOrderSummary.inProgress++;
            break;
          case 'completed':
            workOrderSummary.completed++;
            break;
          case 'on_hold':
          case 'closed':
            workOrderSummary.cancelled++;
            break;
          default:
            workOrderSummary.pending++;
            break;
        }
      });

      // Process invoice stats
      const invoiceSummary = {
        total: 0,
        paid: 0,
        unpaid: 0,
        overdue: 0
      };

      // Handle API response formats for invoices (new /invoices/list endpoint)
      let invoicesArray: Invoice[] = [];
      let totalCount = 0;
      
      if (invoiceData && typeof invoiceData === 'object') {
        // Handle Axios response wrapper
        const responseData = invoiceData.data || invoiceData;
        
        // New API format: { invoices: [], pagination: {} }
        if ('invoices' in responseData && Array.isArray(responseData.invoices)) {
          invoicesArray = responseData.invoices;
          totalCount = responseData.pagination?.total || invoicesArray.length;
        }
        // Fallback to direct array response
        else if (Array.isArray(responseData)) {
          invoicesArray = responseData;
          totalCount = invoicesArray.length;
        }
      }

      invoiceSummary.total = totalCount;

      invoicesArray.forEach((invoice: Invoice) => {
        const paymentStatus = invoice.payment_status || invoice.paymentStatus || invoice.status;
        
        switch (paymentStatus) {
          case 'PAID':
            invoiceSummary.paid++;
            break;
          case 'UNPAID':
            invoiceSummary.unpaid++;
            break;
          case 'PARTIAL':
            invoiceSummary.overdue++;
            break;
          default:
            invoiceSummary.unpaid++;
            break;
        }
      });

      // Process attendance stats
      const attendanceSummary = {
        totalRecords: 0,
        approved: 0,
        avgHoursPerDay: 0
      };

      // Handle API response format for timesheets
      let attendanceArray: TimeSheet[] = [];
      if (attendanceData && typeof attendanceData === 'object') {
        if ('timesheets' in attendanceData && Array.isArray(attendanceData.timesheets)) {
          attendanceArray = attendanceData.timesheets;
        } else if ('data' in attendanceData && Array.isArray(attendanceData.data)) {
          attendanceArray = attendanceData.data;
        } else if (Array.isArray(attendanceData)) {
          attendanceArray = attendanceData;
        }
      }

      attendanceSummary.totalRecords = attendanceArray.length;

      if (attendanceArray.length > 0) {
        attendanceSummary.approved = attendanceArray.filter((ts: TimeSheet) => ts.status === 'approved').length;
        
        const totalHours = attendanceArray.reduce((sum: number, ts: TimeSheet) => sum + (ts.total_hours || 0), 0);
        attendanceSummary.avgHoursPerDay = Number((totalHours / attendanceArray.length).toFixed(1));
      }

      // Process finance data
      const revenueSummary = {
        total_revenue: 0,
        net_profit: 0,
        profit_margin: 0,
        total_paid: 0,
        outstanding_amount: 0
      };

      if (financeData?.data) {
        const { key_metrics, revenue_breakdown } = financeData.data;
        revenueSummary.total_revenue = key_metrics?.total_revenue || 0;
        revenueSummary.net_profit = key_metrics?.net_profit || 0;
        revenueSummary.profit_margin = key_metrics?.profit_margin || 0;
        revenueSummary.total_paid = revenue_breakdown?.total_paid || 0;
        revenueSummary.outstanding_amount = revenue_breakdown?.outstanding_amount || 0;
      }

      setDashboardData(prev => ({
        ...prev,
        notifications: (notificationStats as any)?.data || notificationStats,
        workOrders: workOrderSummary,
        invoices: invoiceSummary,
        attendance: attendanceSummary,
        revenue: revenueSummary,
        recentNotifications: Array.isArray(recentNotifications) ? recentNotifications : [],
        isLoading: false
      }));

    } catch (error) {
      setDashboardData(prev => ({ 
        ...prev, 
        isLoading: false
      }));
    }
  };

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInMs = now.getTime() - date.getTime();
    const diffInMinutes = Math.floor(diffInMs / (1000 * 60));
    const diffInHours = Math.floor(diffInMs / (1000 * 60 * 60));
    const diffInDays = Math.floor(diffInMs / (1000 * 60 * 60 * 24));

    if (diffInMinutes < 60) {
      return `${diffInMinutes} minutes ago`;
    } else if (diffInHours < 24) {
      return `${diffInHours} hours ago`;
    } else {
      return `${diffInDays} days ago`;
    }
  };

  const formatCurrency = (amount: number | undefined | null) => {
    const safeAmount = amount || 0;
    return new Intl.NumberFormat('en-AE', {
      style: 'currency',
      currency: 'AED',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(safeAmount);
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent':
        return 'bg-red-100 text-red-700';
      case 'high':
        return 'bg-orange-100 text-orange-700';
      case 'medium':
        return 'bg-yellow-100 text-yellow-700';
      case 'low':
        return 'bg-green-100 text-green-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open':
        return 'bg-blue-100 text-blue-700';
      case 'in-progress':
        return 'bg-purple-100 text-purple-700';
      case 'pending':
        return 'bg-yellow-100 text-yellow-700';
      case 'resolved':
        return 'bg-green-100 text-green-700';
      case 'closed':
        return 'bg-gray-100 text-gray-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  // Pagination calculations
  const totalPages = Math.ceil(dashboardData.totalCases / casesPerPage);
  const hasNextPage = currentCasePage < totalPages;
  const hasPrevPage = currentCasePage > 1;

  const { notifications, workOrders, invoices, attendance, revenue, recentNotifications, recentCases, isLoading: dataLoading } = dashboardData;

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      {/* Modern Header Section */}
      <div className="mb-8">
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <div className="flex items-center mb-3">
                <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-3 rounded-lg mr-4">
                  <BarChart3 className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
                  <div className="flex items-center mt-1">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                    <span className="text-sm text-gray-500">Live Data</span>
                  </div>
                </div>
              </div>
              <p className="text-gray-600 text-lg">
                Welcome back, <span className="font-semibold text-blue-600">{user?.name}</span>
                <span className="text-gray-500"> - </span>
                <span className="text-gray-700">Your comprehensive business overview</span>
              </p>
            </div>
            <div className="text-right">
              <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                <p className="text-sm text-gray-500 mb-1">Today</p>
                <p className="text-lg font-semibold text-gray-900">
                  {new Date().toLocaleDateString('en-US', { 
                    weekday: 'long',
                    month: 'short',
                    day: 'numeric'
                  })}
                </p>
                <p className="text-xs text-gray-500">
                  {user?.role_name} • {user?.branch?.branch_name || 'All Branches'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Enhanced KPI Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {/* Notifications Card */}
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 hover:shadow-lg transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-blue-100 p-3 rounded-lg">
              <AlertCircle className="w-6 h-6 text-blue-600" />
            </div>
            <Link href="/notifications" className="text-blue-600 hover:text-blue-800">
              <ArrowUpRight className="w-5 h-5" />
            </Link>
          </div>
          <div className="space-y-2">
            <h3 className="text-sm font-medium text-gray-500">Notifications</h3>
            <div className="text-2xl font-bold text-gray-900">
              {dataLoading ? (
                <div className="animate-pulse bg-gray-200 h-6 w-16 rounded"></div>
              ) : (
                notifications.total
              )}
            </div>
            <div className="flex items-center text-sm text-gray-600">
              <div className="flex items-center space-x-2">
                <span className="w-2 h-2 bg-red-500 rounded-full"></span>
                <span>{notifications.unread} unread</span>
              </div>
              <span className="mx-2">•</span>
              <div className="flex items-center space-x-2">
                <span className="w-2 h-2 bg-orange-500 rounded-full"></span>
                <span>{notifications.highPriority} urgent</span>
              </div>
            </div>
          </div>
        </div>

        {/* Work Orders Card */}
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 hover:shadow-lg transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-green-100 p-3 rounded-lg">
              <Settings className="w-6 h-6 text-green-600" />
            </div>
            <Link href="/workOrders" className="text-green-600 hover:text-green-800">
              <ArrowUpRight className="w-5 h-5" />
            </Link>
          </div>
          <div className="space-y-2">
            <h3 className="text-sm font-medium text-gray-500">Work Orders Today</h3>
            <div className="text-2xl font-bold text-gray-900">
              {dataLoading ? (
                <div className="animate-pulse bg-gray-200 h-6 w-16 rounded"></div>
              ) : (
                workOrders.total
              )}
            </div>
            <div className="flex items-center text-sm text-gray-600">
              <div className="flex items-center space-x-2">
                <span className="w-2 h-2 bg-yellow-500 rounded-full"></span>
                <span>{workOrders.pending} open</span>
              </div>
              <span className="mx-2">•</span>
              <div className="flex items-center space-x-2">
                <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                <span>{workOrders.inProgress} active</span>
              </div>
            </div>
          </div>
        </div>

        {/* Invoices Card */}
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 hover:shadow-lg transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-purple-100 p-3 rounded-lg">
              <FileText className="w-6 h-6 text-purple-600" />
            </div>
            <Link href="/Invoices" className="text-purple-600 hover:text-purple-800">
              <ArrowUpRight className="w-5 h-5" />
            </Link>
          </div>
          <div className="space-y-2">
            <h3 className="text-sm font-medium text-gray-500">Invoices This Month</h3>
            <div className="text-2xl font-bold text-gray-900">
              {dataLoading ? (
                <div className="animate-pulse bg-gray-200 h-6 w-16 rounded"></div>
              ) : (
                invoices.total
              )}
            </div>
            <div className="flex items-center text-sm text-gray-600">
              <div className="flex items-center space-x-2">
                <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                <span>{invoices.paid} paid</span>
              </div>
              <span className="mx-2">•</span>
              <div className="flex items-center space-x-2">
                <span className="w-2 h-2 bg-red-500 rounded-full"></span>
                <span>{invoices.unpaid} pending</span>
              </div>
            </div>
          </div>
        </div>

        {/* Revenue Card */}
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 hover:shadow-lg transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-emerald-100 p-3 rounded-lg">
              <DollarSign className="w-6 h-6 text-emerald-600" />
            </div>
            <Link href="/finance" className="text-emerald-600 hover:text-emerald-800">
              <ArrowUpRight className="w-5 h-5" />
            </Link>
          </div>
          <div className="space-y-2">
            <h3 className="text-sm font-medium text-gray-500">Revenue This Month</h3>
            <div className="text-2xl font-bold text-gray-900">
              {dataLoading ? (
                <div className="animate-pulse bg-gray-200 h-6 w-24 rounded"></div>
              ) : (
                formatCurrency(revenue?.total_revenue || 0)
              )}
            </div>
            <div className="flex items-center text-sm text-gray-600">
              <div className="flex items-center space-x-2">
                {(revenue?.profit_margin || 0) >= 0 ? (
                  <TrendingUp className="w-4 h-4 text-emerald-500" />
                ) : (
                  <TrendingDown className="w-4 h-4 text-red-500" />
                )}
                <span className={(revenue?.profit_margin || 0) >= 0 ? 'text-emerald-600' : 'text-red-600'}>
                  {(revenue?.profit_margin || 0).toFixed(1)}% margin
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Left Column - Recent Activity and Cases Stacked */}
        <div className="lg:col-span-2 space-y-6">
          {/* Recent Activity Feed */}
          <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-3">
                <div className="bg-gradient-to-r from-blue-500 to-purple-600 p-2 rounded-lg">
                  <Activity className="w-5 h-5 text-white" />
                </div>
                <h2 className="text-xl font-bold text-gray-900">Recent Activity</h2>
              </div>
              <Link href="/notifications" className="text-blue-600 hover:text-blue-800 text-sm font-medium flex items-center space-x-1">
                <span>View All</span>
                <ArrowUpRight className="w-4 h-4" />
              </Link>
            </div>
            
            <div className="space-y-4">
              {recentNotifications.length > 0 ? (
                recentNotifications.map((notification: Notification) => (
                  <div key={notification._id} className="bg-gray-50 rounded-lg p-4 border-l-4 border-blue-400">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h4 className="font-medium text-gray-900 mb-1">{notification.message}</h4>
                        <div className="flex items-center space-x-4 text-sm text-gray-600">
                          <div className="flex items-center space-x-2">
                            <span className="text-gray-500">Priority:</span>
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                              notification.priority === 'high' 
                                ? 'bg-red-100 text-red-700' 
                                : notification.priority === 'medium' 
                                ? 'bg-yellow-100 text-yellow-700' 
                                : 'bg-green-100 text-green-700'
                            }`}>
                              {notification.priority}
                            </span>
                          </div>
                          <span className="text-gray-500">
                            {formatTimeAgo(notification.createdAt)}
                          </span>
                        </div>
                      </div>
                      {notification.workOrderId && (
                        <Link 
                          href={`/workOrders/${notification.workOrderId}`}
                          className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded-md text-sm font-medium transition-colors"
                        >
                          View
                        </Link>
                      )}
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-12">
                  <div className="bg-gray-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                    <Activity className="w-8 h-8 text-gray-400" />
                  </div>
                  <p className="text-gray-500 text-lg">No recent activity to display</p>
                  <p className="text-gray-400 text-sm">Check back later for updates</p>
                </div>
              )}
            </div>
          </div>

          {/* Recent Cases */}
          <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-3">
                <div className="bg-gradient-to-r from-purple-500 to-pink-600 p-2 rounded-lg">
                  <Folder className="w-5 h-5 text-white" />
                </div>
                <h2 className="text-xl font-bold text-gray-900">Recent Cases</h2>
              </div>
              <Link href="/cases" className="text-purple-600 hover:text-purple-800 text-sm font-medium flex items-center space-x-1">
                <span>View All</span>
                <ArrowUpRight className="w-4 h-4" />
              </Link>
            </div>
            
            <div className="space-y-6">
              {/* Cases List - 3 cases per page */}
              <div className="space-y-4">
                {recentCases.length > 0 ? (
                  recentCases.slice(0, 3).map((caseItem: Case) => (
                    <div key={caseItem._id} className="bg-gray-50 rounded-lg p-4 border-l-4 border-purple-400">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="font-medium text-gray-900 mb-1">{caseItem.title}</h4>
                          <p className="text-sm text-gray-600 mb-2 truncate">{caseItem.description}</p>
                          <div className="flex items-center space-x-4 text-sm text-gray-600">
                            <div className="flex items-center space-x-2">
                              <span className="text-gray-500">Status:</span>
                              <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(caseItem.status)}`}>
                                {caseItem.status}
                              </span>
                            </div>
                            <div className="flex items-center space-x-2">
                              <span className="text-gray-500">Priority:</span>
                              <span className={`px-2 py-1 rounded-full text-xs font-medium ${getPriorityColor(caseItem.priority)}`}>
                                {caseItem.priority}
                              </span>
                            </div>
                            <span className="text-gray-500">
                              {formatTimeAgo(caseItem.createdAt)}
                            </span>
                          </div>
                        </div>
                        <Link 
                          href={`/cases/${caseItem._id}`}
                          className="bg-purple-600 hover:bg-purple-700 text-white px-3 py-1 rounded-md text-sm font-medium transition-colors"
                        >
                          View
                        </Link>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8">
                    <div className="bg-gray-100 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
                      <Folder className="w-6 h-6 text-gray-400" />
                    </div>
                    <p className="text-gray-500">No recent cases to display</p>
                    <p className="text-gray-400 text-sm">Cases will appear here when created</p>
                  </div>
                )}
              </div>
              
              {/* Pagination Controls */}
              {recentCases.length > 0 && (
                <div className="pt-4 border-t border-gray-200">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => setCurrentCasePage(prev => Math.max(prev - 1, 1))}
                        disabled={!hasPrevPage}
                        className={`flex items-center space-x-1 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                          hasPrevPage 
                            ? 'text-purple-600 hover:bg-purple-50 border border-purple-200' 
                            : 'text-gray-400 cursor-not-allowed border border-gray-200'
                        }`}
                      >
                        <ChevronLeft className="w-4 h-4" />
                        <span>Previous</span>
                      </button>
                      
                      <button
                        onClick={() => setCurrentCasePage(prev => Math.min(prev + 1, totalPages))}
                        disabled={!hasNextPage}
                        className={`flex items-center space-x-1 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                          hasNextPage 
                            ? 'text-purple-600 hover:bg-purple-50 border border-purple-200' 
                            : 'text-gray-400 cursor-not-allowed border border-gray-200'
                        }`}
                      >
                        <span>Next</span>
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                    
                    <div className="flex items-center space-x-2 text-sm text-gray-600">
                      <span>Page {currentCasePage} of {totalPages || 1}</span>
                      <span>•</span>
                      <span>{dashboardData.totalCases} total cases</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Column - Quick Actions & Attendance */}
        <div className="space-y-6">
          {/* Quick Actions Panel */}
          <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
            <div className="flex items-center space-x-3 mb-6">
              <div className="bg-gradient-to-r from-green-500 to-teal-600 p-2 rounded-lg">
                <CheckCircle className="w-5 h-5 text-white" />
              </div>
              <h3 className="text-lg font-bold text-gray-900">Quick Actions</h3>
            </div>
            <div className="space-y-3">
              <Link href="/Customers" className="block">
                <button className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-medium py-3 px-4 rounded-lg transition-all duration-200 flex items-center justify-center space-x-2">
                  <Users className="w-5 h-5" />
                  <span>View Customer</span>
                </button>
              </Link>
              <Link href="/payroll/employees" className="block">
                <button className="w-full bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white font-medium py-3 px-4 rounded-lg transition-all duration-200 flex items-center justify-center space-x-2">
                  <BarChart3 className="w-5 h-5" />
                  <span>View Employee Rate</span>
                </button>
              </Link>
              <Link href="/staff" className="block">
                <button className="w-full bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white font-medium py-3 px-4 rounded-lg transition-all duration-200 flex items-center justify-center space-x-2">
                  <Users className="w-5 h-5" />
                  <span>Manage Staff</span>
                </button>
              </Link>
              <Link href="/reports" className="block">
                <button className="w-full bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800 text-white font-medium py-3 px-4 rounded-lg transition-all duration-200 flex items-center justify-center space-x-2">
                  <BarChart3 className="w-5 h-5" />
                  <span>View Reports</span>
                </button>
              </Link>
            </div>
          </div>

          {/* Attendance Overview */}
          <div className="bg-white rounded-lg shadow-md border border-gray-200 p-8">
            <div className="flex items-center space-x-3 mb-7">
              <div className="bg-gradient-to-r from-orange-500 to-red-600 p-2 rounded-lg">
                <Clock className="w-5 h-5 text-white" />
              </div>
              <h3 className="text-lg font-bold text-gray-900">Attendance Overview Today</h3>
            </div>
            <div className="space-y-7">
              <div className="grid grid-cols-1 gap-6">
                <div className="bg-blue-50 rounded-lg p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Users className="w-8 h-8 text-blue-600" />
                      <div>
                        <p className="text-sm font-medium text-gray-700">Total Records</p>
                        <p className="text-2xl font-bold text-blue-600">{attendance?.totalRecords || 0}</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-green-50 rounded-lg p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Calendar className="w-8 h-8 text-green-600" />
                      <div>
                        <p className="text-sm font-medium text-gray-700">Approved</p>
                        <p className="text-2xl font-bold text-green-600">{attendance?.approved || 0}</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-orange-50 rounded-lg p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Clock className="w-8 h-8 text-orange-600" />
                      <div>
                        <p className="text-sm font-medium text-gray-700">Avg Hours/Day</p>
                        <p className="text-2xl font-bold text-orange-600">{attendance?.avgHoursPerDay || 0}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="pt-5 border-t border-gray-200">
                <Link href="/payroll/attendance" className="text-blue-600 hover:text-blue-800 text-sm font-medium flex items-center space-x-1">
                  <span>View All Attendance</span>
                  <ArrowUpRight className="w-4 h-4" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
