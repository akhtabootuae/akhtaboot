'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { 
  Settings, 
  AlertCircle, 
  CheckCircle,
  ArrowUpRight,
  Activity,
  Bell,
  Clock,
  Users,
  BarChart3,
  TrendingUp,
  ChevronLeft,
  ChevronRight,
  Calendar,
  Wrench
} from "lucide-react";
import { notificationsApi } from '@/services/api';
import api from '@/services/api';

export default function SupervisorDashboard({ user }: { user: any }) {

  // State for supervisor dashboard data
  const [dashboardData, setDashboardData] = useState<{
    notifications: { total: number; unread: number; highPriority: number };
    workOrders: { 
      total: number; 
      pending: number; 
      inProgress: number; 
      qaReview: number;
      completed: number; 
      cancelled: number;
      urgent: number;
      todayDeadlines: number;
    };
    recentWorkOrders: any[];
    recentNotifications: any[];
    isLoading: boolean;
  }>({
    notifications: { total: 0, unread: 0, highPriority: 0 },
    workOrders: { 
      total: 0, 
      pending: 0, 
      inProgress: 0, 
      qaReview: 0,
      completed: 0, 
      cancelled: 0,
      urgent: 0,
      todayDeadlines: 0
    },
    recentWorkOrders: [],
    recentNotifications: [],
    isLoading: true
  });

  // Pagination state for recent work orders
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 3;
  const [totalWorkOrders, setTotalWorkOrders] = useState(0);
  const [paginationInfo, setPaginationInfo] = useState<any>(null);

  // Modal states for status breakdown details
  const [showStatusModal, setShowStatusModal] = useState(false);
  const [statusWorkOrders, setStatusWorkOrders] = useState<any[]>([]);
  const [selectedStatus, setSelectedStatus] = useState("");
  const [statusModalLoading, setStatusModalLoading] = useState(false);

  // Fetch supervisor-specific dashboard data
  useEffect(() => {
    fetchSupervisorDashboardData();
  }, [currentPage]);

  const fetchSupervisorDashboardData = async () => {
    try {
      setDashboardData(prev => ({ ...prev, isLoading: true }));

      // Validate user ID format
      const userId = user.id;

      // Fetch notification stats
      const notificationStats = await notificationsApi.getNotificationStats();

      // Use the supervisor-specific endpoint to fetch work orders
      const supervisorWorkOrdersResponse = await api.get(`/api/work-orders/supervisor/${userId}`, {
        params: {
          limit: itemsPerPage,
          page: currentPage
        }
      });

      // Fetch recent notifications
      const recentNotifications = await notificationsApi.getNotifications({ status: 'unread' }).then((response: any) => {
        const data = Array.isArray(response) ? response : (response.data || []);
        return data.slice(0, 5);
      });

      // Process work order stats from the supervisor's work orders
      const workOrderSummary = {
        total: 0,
        pending: 0,
        inProgress: 0,
        qaReview: 0,
        completed: 0,
        cancelled: 0,
        urgent: 0,
        todayDeadlines: 0
      };

      // Extract work orders from the response
      const workOrdersArray = supervisorWorkOrdersResponse.data || [];
      const pagination = (supervisorWorkOrdersResponse as any).pagination || null;
      
      // Set pagination info
      setPaginationInfo(pagination);
      setTotalWorkOrders(pagination?.totalItems || 0);

      // For status breakdown, we need to fetch all work orders to get accurate counts
      const allWorkOrdersResponse = await api.get(`/api/work-orders/supervisor/${userId}`, {
        params: {
          limit: 1000, // Get all work orders for status breakdown
          page: 1
        }
      });

      const allWorkOrders = allWorkOrdersResponse.data || [];
      
      // Calculate status breakdown from all work orders
      allWorkOrders.forEach((wo: any) => {
        workOrderSummary.total++;
        const status = wo.status;
        switch (status) {
          case 'open': 
            workOrderSummary.pending++;
            break;
          case 'in_progress':
            workOrderSummary.inProgress++;
            break;
          case 'qa_review':
            workOrderSummary.qaReview++;
            break;
          case 'completed':
            workOrderSummary.completed++;
            break;
          case 'cancelled':
          case 'on_hold':
          case 'closed':
            workOrderSummary.cancelled++;
            break;
          default:
            workOrderSummary.pending++;
            break;
        }

        // Calculate urgent and today's deadlines
        if (wo.priority === 'urgent') {
          workOrderSummary.urgent++;
        }
        
        if (wo.deadline) {
          const today = new Date();
          today.setHours(23, 59, 59, 999);
          if (new Date(wo.deadline) <= today) {
            workOrderSummary.todayDeadlines++;
          }
        }
      });


      // Filter work orders to only show pending, in_progress, qa_review, and completed
      const filteredWorkOrders = workOrdersArray.filter((wo: any) => {
        const status = wo.status;
        return status === 'pending' || status === 'open' || status === 'in_progress' || status === 'qa_review' || status === 'completed';
      });

      setDashboardData({
        notifications: (notificationStats as any).data || notificationStats,
        workOrders: workOrderSummary,
        recentWorkOrders: filteredWorkOrders,
        recentNotifications: Array.isArray(recentNotifications) ? recentNotifications.slice(0, 5) : [],
        isLoading: false
      });

    } catch (error) {
      setDashboardData(prev => ({ ...prev, isLoading: false }));
    }
  };

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInMs = now.getTime() - date.getTime();
    const diffInMinutes = Math.floor(diffInMs / (1000 * 60));
    const diffInHours = Math.floor(diffInMs / (1000 * 60 * 60));
    const diffInDays = Math.floor(diffInMs / (1000 * 60 * 60 * 24));

    if (diffInMinutes < 60) {
      return `${diffInMinutes} minutes ago`;
    } else if (diffInHours < 24) {
      return `${diffInHours} hours ago`;
    } else {
      return `${diffInDays} days ago`;
    }
  };

  const formatDeadline = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInMs = date.getTime() - now.getTime();
    const diffInDays = Math.ceil(diffInMs / (1000 * 60 * 60 * 24));

    if (diffInDays === 0) {
      return 'Today';
    } else if (diffInDays === 1) {
      return 'Tomorrow';
    } else if (diffInDays > 0) {
      return `${diffInDays} days`;
    } else {
      return 'Overdue';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent':
        return 'text-red-600 bg-red-100';
      case 'high':
        return 'text-orange-600 bg-orange-100';
      case 'medium':
        return 'text-yellow-600 bg-yellow-100';
      case 'low':
        return 'text-green-600 bg-green-100';
      default:
        return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'text-yellow-700 bg-yellow-100';
      case 'in_progress':
        return 'text-blue-700 bg-blue-100';
      case 'qa_review':
        return 'text-purple-700 bg-purple-100';
      case 'completed':
        return 'text-green-700 bg-green-100';
      case 'cancelled':
        return 'text-red-700 bg-red-100';
      default:
        return 'text-gray-700 bg-gray-100';
    }
  };

  const { notifications, workOrders, recentWorkOrders, recentNotifications, isLoading: dataLoading } = dashboardData;

  // Calculate pagination using backend pagination info
  const totalPages = paginationInfo?.totalPages || Math.ceil(recentWorkOrders.length / itemsPerPage);
  const startIndex = ((paginationInfo?.currentPage || currentPage) - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentWorkOrders = recentWorkOrders; // Use all work orders from current page

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  // Handle status card click to show work orders for specific status
  const handleStatusClick = async (status: string) => {
    try {
      setSelectedStatus(status);
      setStatusModalLoading(true);
      setShowStatusModal(true);

      const userId = user.id || user._id;
      
      // Map frontend status to API status
      const apiStatus = status === 'pending' ? 'open' : status;
      
      // Fetch work orders for the specific status
      const response = await api.get(`/api/work-orders/supervisor/${userId}`, {
        params: {
          status: apiStatus,
          limit: 100,
          page: 1
        }
      });

      setStatusWorkOrders(response.data || []);
    } catch (error) {
      setStatusWorkOrders([]);
    } finally {
      setStatusModalLoading(false);
    }
  };

  // Format status for display
  const formatStatus = (status: string) => {
    switch (status) {
      case 'open':
        return 'Pending';
      case 'in_progress':
        return 'In Progress';
      case 'qa_review':
        return 'QA Review';
      case 'completed':
        return 'Completed';
      case 'cancelled':
        return 'On Hold / Closed';
      default:
        return status.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase());
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      {/* Modern Header Section */}
      <div className="mb-8">
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <div className="flex items-center mb-3">
                <div className="bg-gradient-to-r from-green-600 to-emerald-600 p-3 rounded-lg mr-4">
                  <Wrench className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h1 className="text-3xl font-bold text-gray-900">Supervisor Dashboard</h1>
                  <div className="flex items-center mt-1">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                    <span className="text-sm text-gray-500">Live Data</span>
                  </div>
                </div>
              </div>
              <p className="text-gray-600 text-lg">
                Welcome back, <span className="font-semibold text-green-600">{user?.name}</span>
                <span className="text-gray-500"> - </span>
                <span className="text-gray-700">Your work management overview</span>
              </p>
            </div>
            <div className="text-right">
              <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                <p className="text-sm text-gray-500 mb-1">Today</p>
                <p className="text-lg font-semibold text-gray-900">
                  {new Date().toLocaleDateString('en-US', { 
                    weekday: 'long',
                    month: 'short',
                    day: 'numeric'
                  })}
                </p>
                <p className="text-xs text-gray-500">
                  {user?.role_name} • {user?.branch?.branch_name || 'No branch assigned'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Work Order Status Breakdown */}
      <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 mb-8">
        <div className="flex items-center space-x-3 mb-6">
          <div className="bg-gradient-to-r from-green-500 to-emerald-600 p-2 rounded-lg">
            <Settings className="w-5 h-5 text-white" />
          </div>
          <h3 className="text-xl font-bold text-gray-900">Work Order Status Breakdown (Today)</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
          <button 
            onClick={() => handleStatusClick('pending')}
            className="bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-lg p-6 text-white hover:from-yellow-500 hover:to-yellow-700 transition-all duration-200 hover:shadow-lg transform hover:scale-105 cursor-pointer"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="bg-white bg-opacity-20 p-2 rounded-lg">
                <Clock className="w-6 h-6" />
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold">
                  {dataLoading ? (
                    <div className="animate-pulse bg-white bg-opacity-20 h-6 w-12 rounded"></div>
                  ) : (
                    workOrders.pending
                  )}
                </div>
                <div className="text-yellow-100">Open</div>
              </div>
            </div>
            <div className="mt-3 bg-white bg-opacity-20 rounded-full h-2">
              <div 
                className="bg-white h-2 rounded-full transition-all duration-300" 
                style={{ width: workOrders.total > 0 ? `${(workOrders.pending / workOrders.total) * 100}%` : '0%' }}
              ></div>
            </div>
          </button>

          <button 
            onClick={() => handleStatusClick('in_progress')}
            className="bg-gradient-to-br from-blue-500 to-blue-700 rounded-lg p-6 text-white hover:from-blue-600 hover:to-blue-800 transition-all duration-200 hover:shadow-lg transform hover:scale-105 cursor-pointer"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="bg-white bg-opacity-20 p-2 rounded-lg">
                <Activity className="w-6 h-6" />
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold">
                  {dataLoading ? (
                    <div className="animate-pulse bg-white bg-opacity-20 h-6 w-12 rounded"></div>
                  ) : (
                    workOrders.inProgress
                  )}
                </div>
                <div className="text-blue-100">In Progress</div>
              </div>
            </div>
            <div className="mt-3 bg-white bg-opacity-20 rounded-full h-2">
              <div 
                className="bg-white h-2 rounded-full transition-all duration-300" 
                style={{ width: workOrders.total > 0 ? `${(workOrders.inProgress / workOrders.total) * 100}%` : '0%' }}
              ></div>
            </div>
          </button>

          <button 
            onClick={() => handleStatusClick('qa_review')}
            className="bg-gradient-to-br from-purple-500 to-purple-700 rounded-lg p-6 text-white hover:from-purple-600 hover:to-purple-800 transition-all duration-200 hover:shadow-lg transform hover:scale-105 cursor-pointer"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="bg-white bg-opacity-20 p-2 rounded-lg">
                <CheckCircle className="w-6 h-6" />
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold">
                  {dataLoading ? (
                    <div className="animate-pulse bg-white bg-opacity-20 h-6 w-12 rounded"></div>
                  ) : (
                    workOrders.qaReview
                  )}
                </div>
                <div className="text-purple-100">QA Review</div>
              </div>
            </div>
            <div className="mt-3 bg-white bg-opacity-20 rounded-full h-2">
              <div 
                className="bg-white h-2 rounded-full transition-all duration-300" 
                style={{ width: workOrders.total > 0 ? `${(workOrders.qaReview / workOrders.total) * 100}%` : '0%' }}
              ></div>
            </div>
          </button>

          <div className="bg-gradient-to-br from-green-500 to-green-700 rounded-lg p-6 text-white">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-white bg-opacity-20 p-2 rounded-lg">
                <CheckCircle className="w-6 h-6" />
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold">
                  {dataLoading ? (
                    <div className="animate-pulse bg-white bg-opacity-20 h-6 w-12 rounded"></div>
                  ) : (
                    workOrders.completed
                  )}
                </div>
                <div className="text-green-100">Completed</div>
              </div>
            </div>
            <div className="mt-3 bg-white bg-opacity-20 rounded-full h-2">
              <div 
                className="bg-white h-2 rounded-full transition-all duration-300" 
                style={{ width: workOrders.total > 0 ? `${(workOrders.completed / workOrders.total) * 100}%` : '0%' }}
              ></div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-red-500 to-red-700 rounded-lg p-6 text-white">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-white bg-opacity-20 p-2 rounded-lg">
                <AlertCircle className="w-6 h-6" />
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold">
                  {dataLoading ? (
                    <div className="animate-pulse bg-white bg-opacity-20 h-6 w-12 rounded"></div>
                  ) : (
                    workOrders.cancelled
                  )}
                </div>
                <div className="text-red-100">On Hold / Closed</div>
              </div>
            </div>
            <div className="mt-3 bg-white bg-opacity-20 rounded-full h-2">
              <div 
                className="bg-white h-2 rounded-full transition-all duration-300" 
                style={{ width: workOrders.total > 0 ? `${(workOrders.cancelled / workOrders.total) * 100}%` : '0%' }}
              ></div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Work Orders (Left Column - 2 spans) */}
        <div className="lg:col-span-2 bg-white rounded-lg shadow-md border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <div className="bg-blue-100 p-2 rounded-lg">
                <Activity className="w-5 h-5 text-blue-600" />
              </div>
              <h2 className="text-xl font-bold text-gray-900">Recent Work Orders</h2>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-sm text-gray-500">
                Showing {startIndex + 1}-{Math.min(endIndex, totalWorkOrders)} of {totalWorkOrders}
              </span>
              <Link href="/WorkOrders" className="text-blue-600 hover:text-blue-800 text-sm font-medium flex items-center space-x-1">
                <span>View All</span>
                <ArrowUpRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
          
          <div className="space-y-4">
            {currentWorkOrders.length > 0 ? (
              currentWorkOrders.map((workOrder: any) => (
                <div key={workOrder._id || workOrder.id} className="bg-gray-50 rounded-lg p-6 border border-gray-200 hover:shadow-lg hover:border-blue-300 transition-all duration-200 hover:bg-white">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-4">
                        <h4 className="font-bold text-gray-900 text-lg">#{workOrder.workOrderNumber}</h4>
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wide ${getStatusColor(workOrder.status)}`}>
                          {workOrder.status.replace('_', ' ')}
                        </span>
                        {workOrder.priority && (
                          <span className={`px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wide ${getPriorityColor(workOrder.priority)}`}>
                            {workOrder.priority}
                          </span>
                        )}
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div className="space-y-2">
                          <div className="flex items-center space-x-2">
                            <Users className="w-4 h-4 text-gray-500" />
                            <p className="text-sm font-medium text-gray-900">
                              {workOrder.customerDetails?.first_name || workOrder.customerDetails?.last_name 
                                ? `${workOrder.customerDetails.first_name || ''} ${workOrder.customerDetails.last_name || ''}`.trim()
                                : workOrder.customerDetails?.name || workOrder.customer_name || 'Unknown Customer'}
                            </p>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Settings className="w-4 h-4 text-gray-500" />
                            <p className="text-sm text-gray-600">
                              {workOrder.vehicleDetails?.make || workOrder.vehicle_id?.make || 'Unknown'} {' '}
                              {workOrder.vehicleDetails?.model || workOrder.vehicle_id?.model || 'Vehicle'} {' '}
                              {workOrder.vehicleDetails?.year || workOrder.vehicle_id?.year || ''}
                            </p>
                          </div>
                        </div>
                        {workOrder.deadline && (
                          <div className="text-right">
                            <div className="flex items-center justify-end space-x-2 mb-1">
                              <Calendar className="w-4 h-4 text-gray-500" />
                              <p className="text-xs text-gray-500">Deadline</p>
                            </div>
                            <p className={`text-sm font-medium ${
                              formatDeadline(workOrder.deadline) === 'Today' || formatDeadline(workOrder.deadline) === 'Overdue' 
                                ? 'text-red-600' 
                                : formatDeadline(workOrder.deadline) === 'Tomorrow'
                                ? 'text-orange-600'
                                : 'text-gray-700'
                            }`}>
                              {formatDeadline(workOrder.deadline)}
                            </p>
                          </div>
                        )}
                      </div>
                      
                      <div className="bg-white rounded-lg p-4 border border-gray-100">
                        <p className="text-sm text-gray-700">{workOrder.description}</p>
                      </div>
                    </div>
                    
                    <div className="ml-6 flex flex-col items-end gap-2">
                      <Link 
                        href={`/WorkOrders/${workOrder._id || workOrder.id}`}
                        className="bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium px-4 py-2 rounded-lg transition-colors shadow-sm hover:shadow-md flex items-center space-x-2"
                      >
                        <span>View Details</span>
                        <ArrowUpRight className="w-4 h-4" />
                      </Link>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-12">
                <div className="bg-gray-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <Activity className="w-8 h-8 text-gray-400" />
                </div>
                <p className="text-lg font-medium text-gray-500">No recent work orders to display</p>
                <p className="text-sm mt-1 text-gray-400">Work orders will appear here once they are created</p>
              </div>
            )}
          </div>

          {/* Pagination Controls */}
          {totalPages > 1 && (
            <div className="pt-6 border-t border-gray-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => handlePageChange(currentPage - 1)}
                    disabled={currentPage === 1}
                    className={`flex items-center space-x-1 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      currentPage > 1 
                        ? 'text-blue-600 hover:bg-blue-50 border border-blue-200' 
                        : 'text-gray-400 cursor-not-allowed border border-gray-200'
                    }`}
                  >
                    <ChevronLeft className="w-4 h-4" />
                    <span>Previous</span>
                  </button>
                  
                  <div className="flex items-center gap-1">
                    {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                      <button
                        key={page}
                        onClick={() => handlePageChange(page)}
                        className={`px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                          currentPage === page
                            ? 'bg-blue-600 text-white'
                            : 'text-gray-700 bg-white border border-gray-300 hover:bg-gray-50'
                        }`}
                      >
                        {page}
                      </button>
                    ))}
                  </div>

                  <button
                    onClick={() => handlePageChange(currentPage + 1)}
                    disabled={currentPage === totalPages}
                    className={`flex items-center space-x-1 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      currentPage < totalPages 
                        ? 'text-blue-600 hover:bg-blue-50 border border-blue-200' 
                        : 'text-gray-400 cursor-not-allowed border border-gray-200'
                    }`}
                  >
                    <span>Next</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
                
                <div className="flex items-center space-x-2 text-sm text-gray-600">
                  <span>Page {currentPage} of {totalPages}</span>
                  <span>•</span>
                  <span>{totalWorkOrders} total orders</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Recent Alerts & Quick Actions (Right Column) */}
        <div className="space-y-6">
          {/* Recent Notifications */}
          <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className="bg-orange-100 p-2 rounded-lg">
                  <Bell className="w-5 h-5 text-orange-600" />
                </div>
                <h3 className="text-lg font-bold text-gray-900">Recent Alerts</h3>
              </div>
              <Link href="/notifications" className="text-orange-600 hover:text-orange-800 text-sm font-medium flex items-center space-x-1">
                <span>View All</span>
                <ArrowUpRight className="w-4 h-4" />
              </Link>
            </div>
            
            <div className="space-y-3">
              {recentNotifications.length > 0 ? (
                recentNotifications.map((notification: any) => (
                  <div key={notification._id} className="bg-gray-50 rounded-lg p-4 border-l-4 border-orange-400">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h4 className="font-medium text-gray-900 text-sm mb-1">{notification.message}</h4>
                        <div className="flex items-center space-x-4 text-xs text-gray-500">
                          <div className="flex items-center space-x-1">
                            <Clock className="w-3 h-3" />
                            <span>{formatTimeAgo(notification.createdAt)}</span>
                          </div>
                          {notification.workOrderId && (
                            <div className="flex items-center space-x-1">
                              <Settings className="w-3 h-3" />
                              <span>Work Order</span>
                            </div>
                          )}
                        </div>
                      </div>
                      {notification.workOrderId && (
                        <Link 
                          href={`/WorkOrders/${notification.workOrderId}`}
                          className="bg-orange-600 hover:bg-orange-700 text-white px-3 py-1 rounded-md text-sm font-medium transition-colors"
                        >
                          View
                        </Link>
                      )}
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8">
                  <div className="bg-gray-100 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
                    <Bell className="w-6 h-6 text-gray-400" />
                  </div>
                  <p className="text-gray-500">No recent alerts</p>
                  <p className="text-gray-400 text-sm">Notifications will appear here when received</p>
                </div>
              )}
            </div>
          </div>

          {/* Supervisor Quick Actions Panel */}
          <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
            <div className="flex items-center space-x-3 mb-6">
              <div className="bg-gradient-to-r from-green-500 to-teal-600 p-2 rounded-lg">
                <CheckCircle className="w-5 h-5 text-white" />
              </div>
              <h3 className="text-lg font-bold text-gray-900">Quick Actions</h3>
            </div>
            <div className="space-y-3">
              <Link href="/workOrders" className="block">
                <button className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-medium py-3 px-4 rounded-lg transition-all duration-200 flex items-center justify-center space-x-2">
                  <Settings className="w-5 h-5" />
                  <span>View Work Orders</span>
                </button>
              </Link>
              <Link href="/Customers" className="block">
                <button className="w-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white font-medium py-3 px-4 rounded-lg transition-all duration-200 flex items-center justify-center space-x-2">
                  <Users className="w-5 h-5" />
                  <span>View Customers</span>
                </button>
              </Link>
              <Link href="/Invoices" className="block">
                <button className="w-full bg-gradient-to-r from-yellow-600 to-yellow-700 hover:from-yellow-700 hover:to-yellow-800 text-white font-medium py-3 px-4 rounded-lg transition-all duration-200 flex items-center justify-center space-x-2">
                  <BarChart3 className="w-5 h-5" />
                  <span>View Invoices</span>
                </button>
              </Link>
              <Link href="/cases" className="block">
                <button className="w-full bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white font-medium py-3 px-4 rounded-lg transition-all duration-200 flex items-center justify-center space-x-2">
                  <AlertCircle className="w-5 h-5" />
                  <span>Cases</span>
                </button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Status Detail Modal */}
      {showStatusModal && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
          <div className="bg-white p-8 rounded-lg shadow-2xl w-full max-w-6xl max-h-[90vh] overflow-hidden">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-gray-900">
                Work Orders - <span className="text-blue-600">{formatStatus(selectedStatus)}</span>
              </h2>
              <button
                onClick={() => setShowStatusModal(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                ✕
              </button>
            </div>

            {statusModalLoading ? (
              <div className="flex items-center justify-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
                <span className="ml-4 text-gray-600">Loading work orders...</span>
              </div>
            ) : statusWorkOrders.length > 0 ? (
              <div className="overflow-y-auto max-h-[70vh]">
                <div className="overflow-x-auto">
                  <table className="min-w-full">
                    <thead className="bg-gray-50 sticky top-0">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">
                          Work Order #
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">
                          Customer
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">
                          Vehicle
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">
                          Invoice
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">
                          Created
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {statusWorkOrders.map((wo, idx) => (
                        <tr
                          key={wo._id || wo.id}
                          onClick={() => {
                            setShowStatusModal(false);
                            window.location.href = `/WorkOrders/${wo._id || wo.id}`;
                          }}
                          className={`cursor-pointer transition-colors ${
                            idx % 2 === 0 ? "bg-white" : "bg-gray-50"
                          } hover:bg-blue-50`}
                        >
                          <td className="px-6 py-4 whitespace-nowrap">
                            <Link 
                              href={`/WorkOrders/${wo._id || wo.id}`}
                              className="text-sm font-medium text-blue-600 hover:text-blue-800 hover:underline"
                              onClick={(e) => e.stopPropagation()}
                            >
                              #{wo.workOrderNumber || wo._id?.slice(-6)}
                            </Link>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium text-gray-900">
                              {wo.customerDetails?.first_name || wo.customerDetails?.last_name 
                                ? `${wo.customerDetails.first_name || ''} ${wo.customerDetails.last_name || ''}`.trim()
                                : wo.customerDetails?.name || wo.customer_name || 'Unknown Customer'}
                            </div>
                            <div className="text-sm text-gray-500">
                              {wo.customerDetails?.phone || 'No phone'}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium text-gray-900">
                              {wo.vehicle_id?.make} {' '}
                              {wo.vehicle_id?.model} {' '}
                              {wo.vehicle_id?.year}
                            </div>
                            <div className="text-sm text-gray-500">
                              {wo.vehicle_id?.license_plate}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {wo.invoice_id ? (
                              <Link 
                                href={`/Invoices/${wo.invoice_id}`}
                                className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800 hover:bg-blue-200 transition-colors"
                                onClick={(e) => e.stopPropagation()}
                              >
                                View Invoice
                              </Link>
                            ) : (
                              <span className="text-sm text-gray-500">No Invoice</span>
                            )}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {wo.createdAt ? new Date(wo.createdAt).toLocaleDateString() : 'N/A'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-500">No work orders found for this status.</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
