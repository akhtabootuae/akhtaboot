'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '../context/AuthContext';
import { useRouteProtection } from '@/services/route-protection';
import { dataApi } from '@/services/api';
import useDebounce from '../hooks/useDebounce';

// Types
interface User {
  _id: string;
  id?: string;
  name: string;
  email: string;
  role: string;
}

interface WorkOrder {
  _id: string;
  work_order_number: string;
  workOrderNumber: string;
  customer_id: string;
  vehicle_id: number;
  status: string;
  description: string;
  createdAt: string;
  updatedAt: string;
  parts: Array<{
    partName: string;
    variationId: string;
    status: string;
    assignedTo: string;
    createdAt: string;
    updatedAt: string;
    stages: Array<{
      stageId: string;
      status: string;
      logs: any[];
      createdAt: string;
      updatedAt: string;
    }>;
  }>;
  vehicle?: {
    make: string;
    model: string;
    license_plate: string;
  };
  customer?: {
    name: string;
  };
}

interface Pagination {
  current_page: number;
  total_pages: number;
  total_count: number;
  per_page: number;
  has_next_page: boolean;
  has_prev_page: boolean;
  next_page: number | null;
  prev_page: number | null;
}

// Types for manner evaluations
interface MannerEvaluation {
  _id: string;
  category: string;
  rating: number;
  work_order_id?: string;
  notes?: string;
  created_at: string;
  updated_at: string;
  evaluator?: {
    name: string;
    role: string;
  };
}

interface EvaluationLog {
  log_id: string;
  action: 'added' | 'updated' | 'deleted';
  category: string;
  rating: number;
  evaluation_id: string;
  evaluator_id: string;
  notes?: string;
  created_at: string;
}

const StaffReportsPage = () => {
  const { user, isAuthenticated } = useAuth();
  const router = useRouter();
  
  // Route protection - only allow admin and supervisor
  const hasAccess = useRouteProtection(
    isAuthenticated,
    user,
    { adminOnly: false, supervisorOnly: true }
  );

  const [staff, setStaff] = useState<User[]>([]);
  const [selectedStaff, setSelectedStaff] = useState<string>('');
  const [currentWorkOrders, setCurrentWorkOrders] = useState<WorkOrder[]>([]);
  const [completedWorkOrders, setCompletedWorkOrders] = useState<WorkOrder[]>([]);
  const [pagination, setPagination] = useState<Pagination | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState('current');

  // State for time statistics
  const [timeStatsData, setTimeStatsData] = useState<WorkOrder[]>([]);
  const [fromDateFilter, setFromDateFilter] = useState<string>('');
  const [toDateFilter, setToDateFilter] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [filteredTimeStatsData, setFilteredTimeStatsData] = useState<WorkOrder[]>([]);

  // State for manner evaluations
  const [mannerEvaluations, setMannerEvaluations] = useState<MannerEvaluation[]>([]);
  const [evaluationLogs, setEvaluationLogs] = useState<EvaluationLog[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showLogsModal, setShowLogsModal] = useState(false);
  const [editingEvaluation, setEditingEvaluation] = useState<MannerEvaluation | null>(null);
  const [evaluatorNames, setEvaluatorNames] = useState<Record<string, string>>({});
  
  // Check if user has permission to manage manner evaluations
  const canManageEvaluations = user?.permissions?.some(
    p => p.permission_name === 'manage_manner_evaluations' && p.granted
  ) || user?.role_name?.toLowerCase() === 'admin';
  
  const canViewEvaluations = user?.permissions?.some(
    p => p.permission_name === 'view_manner_evaluations' && p.granted
  ) || user?.role_name?.toLowerCase() === 'admin';

  // Fetch all staff
  useEffect(() => {
    const fetchStaff = async () => {
      if (hasAccess) {
        try {
          setLoading(true);
          const response = await dataApi.getUsers();
          const users = Array.isArray(response) ? response : 
                       (response.data && Array.isArray(response.data)) ? response.data : [];
          
          // Filter out Admin users since they don't do work orders
          const workingStaff = users.filter((user: User) => 
            user.role && user.role.toLowerCase() !== 'admin' && user.role.toLowerCase() !== 'feedback screen'
          );
          
          setStaff(workingStaff);
          setLoading(false);
        } catch (error) {
          // Error fetching staff data
          setLoading(false);
        }
      }
    };

    fetchStaff();
  }, [hasAccess]);

  // Fetch work orders for selected staff
  useEffect(() => {
    const fetchWorkOrders = async () => {
      if (selectedStaff) {
        try {
          setLoading(true);
          
          // Get selected staff member to check their role
          const selectedStaffMember = staff.find(s => s._id === selectedStaff);
          const isTechnician = selectedStaffMember?.role?.toLowerCase() === 'technician';
          
          // For supervisors, use placeholder logic (part status filtering will be implemented when API is ready)
          if (!isTechnician) {
            // Placeholder for supervisors - will use part status filtering once API is available
            setCurrentWorkOrders([]);
          } else {
            // Fetch current work orders for technicians (based on stage status)
            const currentResponse = await dataApi.getUserWorkOrders(selectedStaff, 1, 10);
            const currentData = currentResponse?.data ? currentResponse.data : currentResponse;
            
            if (currentData && currentData.workorders) {
              let currentOrders = currentData.workorders;
              
              // For technicians, filter based on stage status
              currentOrders = currentData.workorders.filter((workOrder: any) => {
                return workOrder.parts?.some((part: any) => 
                  part.stages?.some((stage: any) => 
                    stage.assignedTo === selectedStaff && stage.status === 'in_progress'
                  )
                );
              });
              
              // Enrich work orders with customer and vehicle names
              const enrichedCurrentOrders = await dataApi.enrichWorkOrdersWithNames(currentOrders);
              setCurrentWorkOrders(enrichedCurrentOrders);
              setPagination(currentData.pagination || null);
            }
          }
          
          // Fetch completed work orders
          // For technicians, we need to fetch ALL work orders to find their completed stages
          // For supervisors, use placeholder logic (part status filtering will be implemented when API is ready)
          let completedResponse;
          if (isTechnician) {
            // Get all work orders to find completed stages by this technician
            completedResponse = await dataApi.getUserWorkOrders(selectedStaff, 1, 100); // Get more records
            
            const completedData = completedResponse?.data ? completedResponse.data : completedResponse;
            
            if (completedData && completedData.workorders) {
              let completedOrders = completedData.workorders;
              
              // For technicians, filter based on stage status
              completedOrders = completedData.workorders.filter((workOrder: any) => {
                return workOrder.parts?.some((part: any) => 
                  part.stages?.some((stage: any) => 
                    stage.assignedTo === selectedStaff && stage.status === 'completed'
                  )
                );
              });
              
              // Enrich work orders with customer and vehicle names
              const enrichedCompletedOrders = await dataApi.enrichWorkOrdersWithNames(completedOrders);
              setCompletedWorkOrders(enrichedCompletedOrders);
            }
          } else {
            // Placeholder for supervisors - will use part status filtering once API is available
            setCompletedWorkOrders([]);
          }

          // Fetch all work orders for time statistics
          const allWorkOrdersForTimeStats = [];
          
          if (isTechnician) {
            // For technicians, we need to fetch all work orders to find their assigned stages
            const allWorkOrdersResponse = await dataApi.getUserWorkOrders(selectedStaff, 1, 100);
            const allWorkOrdersData = allWorkOrdersResponse?.data ? allWorkOrdersResponse.data : allWorkOrdersResponse;
            
            if (allWorkOrdersData && allWorkOrdersData.workorders) {
              // Filter time stats based on their assigned stages
              const timeStatsOrders = allWorkOrdersData.workorders.filter((workOrder: any) => {
                return workOrder.parts?.some((part: any) => 
                  part.stages?.some((stage: any) => 
                    stage.assignedTo === selectedStaff
                  )
                );
              });
              
              // Enrich time statistics data
              const enrichedTimeStats = await dataApi.enrichWorkOrdersWithNames(timeStatsOrders);
              setTimeStatsData(enrichedTimeStats);
            } else {
              setTimeStatsData([]);
            }
          } else {
            // Placeholder for supervisors - will use part status filtering once API is available
            setTimeStatsData([]);
          }
          
          setLoading(false);
        } catch (error) {
          // Error fetching work orders
          setLoading(false);
        }
      }
    };

    fetchWorkOrders();
  }, [selectedStaff, staff]);

  // Filter time stats data based on date range and status filters
  useEffect(() => {
    let filtered = [...timeStatsData];

    // Filter by date range
    if (fromDateFilter || toDateFilter) {
      filtered = filtered.filter(order => {
        const orderDate = new Date(order.createdAt);
        const fromDate = fromDateFilter ? new Date(fromDateFilter) : null;
        const toDate = toDateFilter ? new Date(toDateFilter) : null;

        if (fromDate && toDate) {
          return orderDate >= fromDate && orderDate <= toDate;
        } else if (fromDate) {
          return orderDate >= fromDate;
        } else if (toDate) {
          return orderDate <= toDate;
        }
        return true;
      });
    }

    // Filter by status if specified
    if (statusFilter) {
      filtered = filtered.filter(order => order.status === statusFilter);
    }

    setFilteredTimeStatsData(filtered);
  }, [timeStatsData, fromDateFilter, toDateFilter, statusFilter]);

  // Fetch manner evaluations when staff is selected and manners tab is active
  useEffect(() => {
    const fetchMannerEvaluations = async () => {
      if (selectedStaff && activeTab === 'manners' && canViewEvaluations) {
        try {
          setLoading(true);
          const evaluationsResponse = await dataApi.getMannerEvaluations(selectedStaff);
          let evaluations: MannerEvaluation[] = [];
          if (evaluationsResponse && typeof evaluationsResponse === 'object') {
            if ('manner_evaluations' in evaluationsResponse) {
              evaluations = evaluationsResponse.manner_evaluations as MannerEvaluation[];
            } else if (Array.isArray(evaluationsResponse)) {
              evaluations = evaluationsResponse as MannerEvaluation[];
            }
          }
          setMannerEvaluations(evaluations);
        } catch (error) {
          // Error fetching manner evaluations
        } finally {
          setLoading(false);
        }
      }
    };

    fetchMannerEvaluations();
  }, [selectedStaff, activeTab, canViewEvaluations]);

  // Fetch evaluation logs
  const fetchEvaluationLogs = async () => {
    if (selectedStaff && canViewEvaluations) {
      try {
        const logsResponse = await dataApi.getMannerEvaluationLogs(selectedStaff);
        let logs: EvaluationLog[] = [];
        if (logsResponse && typeof logsResponse === 'object') {
          if ('manner_evaluation_logs' in logsResponse) {
            logs = logsResponse.manner_evaluation_logs as EvaluationLog[];
          } else if ('logs' in logsResponse) {
            logs = logsResponse.logs as EvaluationLog[];
          } else if (Array.isArray(logsResponse)) {
            logs = logsResponse as EvaluationLog[];
          }
        }
        setEvaluationLogs(logs);
        
        // Fetch evaluator names for the logs
        await fetchEvaluatorNames(logs);
      } catch (error) {
        // Error fetching evaluation logs
      }
    }
  };

  // Fetch evaluator names from user IDs
  const fetchEvaluatorNames = async (logs: EvaluationLog[]) => {
    try {
      // Get unique evaluator IDs
      const evaluatorIds = [...new Set(logs.map(log => log.evaluator_id))];
      
      // Fetch users data
      const usersResponse = await dataApi.getUsers();
      const users = Array.isArray(usersResponse) ? usersResponse : 
                   (usersResponse.data && Array.isArray(usersResponse.data)) ? usersResponse.data : [];
      
      // Create mapping of evaluator ID to name
      const nameMapping: Record<string, string> = {};
      evaluatorIds.forEach(id => {
        const user = users.find((u: User) => u._id === id || u.id === id);
        nameMapping[id] = user ? user.name : `Unknown User (${id})`;
      });
      
      setEvaluatorNames(nameMapping);
    } catch (error) {
      // Error fetching evaluator names
      // If fetching names fails, create a fallback mapping with IDs
      const evaluatorIds = [...new Set(logs.map(log => log.evaluator_id))];
      const fallbackMapping: Record<string, string> = {};
      evaluatorIds.forEach(id => {
        fallbackMapping[id] = `User ID: ${id}`;
      });
      setEvaluatorNames(fallbackMapping);
    }
  };

  // Handle adding new evaluation
  const handleAddEvaluation = async (evaluationData: any) => {
    if (!selectedStaff || !canManageEvaluations) return;
    
    try {
      await dataApi.createMannerEvaluation(selectedStaff, evaluationData);
      // Refresh evaluations
      const evaluationsResponse = await dataApi.getMannerEvaluations(selectedStaff);
      let evaluations: MannerEvaluation[] = [];
      if (evaluationsResponse && typeof evaluationsResponse === 'object') {
        if ('manner_evaluations' in evaluationsResponse) {
          evaluations = evaluationsResponse.manner_evaluations as MannerEvaluation[];
        } else if (Array.isArray(evaluationsResponse)) {
          evaluations = evaluationsResponse as MannerEvaluation[];
        }
      }
      setMannerEvaluations(evaluations);
      setShowAddModal(false);
    } catch (error) {
      // Error adding evaluation
    }
  };

  // Handle updating evaluation
  const handleUpdateEvaluation = async (evaluationId: string, evaluationData: any) => {
    if (!selectedStaff || !canManageEvaluations) return;
    
    try {
      await dataApi.updateMannerEvaluation(selectedStaff, evaluationId, evaluationData);
      // Refresh evaluations
      const evaluationsResponse = await dataApi.getMannerEvaluations(selectedStaff);
      let evaluations: MannerEvaluation[] = [];
      if (evaluationsResponse && typeof evaluationsResponse === 'object') {
        if ('manner_evaluations' in evaluationsResponse) {
          evaluations = evaluationsResponse.manner_evaluations as MannerEvaluation[];
        } else if (Array.isArray(evaluationsResponse)) {
          evaluations = evaluationsResponse as MannerEvaluation[];
        }
      }
      setMannerEvaluations(evaluations);
      setEditingEvaluation(null);
    } catch (error) {
      // Error updating evaluation
    }
  };

  // Handle deleting evaluation
  const handleDeleteEvaluation = async (evaluationId: string) => {
    if (!selectedStaff || !canManageEvaluations) return;
    
    if (confirm('Are you sure you want to delete this evaluation?')) {
      try {
        await dataApi.deleteMannerEvaluation(selectedStaff, evaluationId);
        // Refresh evaluations
        const evaluationsResponse = await dataApi.getMannerEvaluations(selectedStaff);
        let evaluations: MannerEvaluation[] = [];
        if (evaluationsResponse && typeof evaluationsResponse === 'object') {
          if ('manner_evaluations' in evaluationsResponse) {
            evaluations = evaluationsResponse.manner_evaluations as MannerEvaluation[];
          } else if (Array.isArray(evaluationsResponse)) {
            evaluations = evaluationsResponse as MannerEvaluation[];
          }
        }
        setMannerEvaluations(evaluations);
      } catch (error) {
        // Error deleting evaluation
      }
    }
  };

  // Handle staff selection change
  const handleStaffChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedStaff(e.target.value);
  };

  // Handle page change for pagination
  const handlePageChange = async (page: number) => {
    if (selectedStaff) {
      try {
        setLoading(true);
        
        // Get selected staff member to check their role
        const selectedStaffMember = staff.find(s => s._id === selectedStaff);
        const isTechnician = selectedStaffMember?.role?.toLowerCase() === 'technician';
        
        if (activeTab === 'current') {
          const response = await dataApi.getUserWorkOrders(selectedStaff, page, 10, 'open');
          const data = response?.data ? response.data : response;
          
          if (data) {
            let currentOrders = data.workorders || [];
            
            // For technicians, filter based on stage status
            if (isTechnician) {
              currentOrders = currentOrders.filter((workOrder: any) => {
                return workOrder.parts?.some((part: any) => 
                  part.stages?.some((stage: any) => 
                    stage.assignedTo === selectedStaff && stage.status === 'in_progress'
                  )
                );
              });
            }
            
            setCurrentWorkOrders(currentOrders);
            setPagination(data.pagination || null);
          }
        } else if (activeTab === 'completed') {
          let response;
          if (isTechnician) {
            // For technicians, get all work orders to find completed stages
            response = await dataApi.getUserWorkOrders(selectedStaff, page, 50); // Get more records
          } else {
            // For supervisors/admins, use the traditional completed filter
            response = await dataApi.getUserWorkOrders(selectedStaff, page, 10, 'completed');
          }
          
          const data = response?.data ? response.data : response;
          
          if (data) {
            let completedOrders = data.workorders || [];
            
            // For technicians, filter based on stage status
            if (isTechnician) {
              completedOrders = completedOrders.filter((workOrder: any) => {
                return workOrder.parts?.some((part: any) => 
                  part.stages?.some((stage: any) => 
                    stage.assignedTo === selectedStaff && stage.status === 'completed'
                  )
                );
              });
            }
            
            setCompletedWorkOrders(completedOrders);
            setPagination(data.pagination || null);
          }
        }
        
        setLoading(false);
      } catch (error) {
        // Error fetching work orders for pagination
        setLoading(false);
      }
    }
  };

  // Handle tab change
  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
  };

  // Helper function to get work order details by ID
  const getWorkOrderById = (workOrderId: string) => {
    const allWorkOrders = [...currentWorkOrders, ...completedWorkOrders];
    return allWorkOrders.find(order => order._id === workOrderId);
  };

  // If not authorized, don't render anything
  if (!hasAccess) {
    return null;
  }

  // Show loading state while checking auth or loading data
  if (loading && !hasAccess) {
    return (
      <div className="p-6 bg-gray-50 min-h-screen flex items-center justify-center">
        <div className="text-xl text-gray-600">Loading...</div>
      </div>
    );
  }

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      {/* Page header */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Staff Reports</h1>
            <p className="text-gray-600">View and analyze staff performance reports</p>
          </div>
        </div>
        
        {/* Staff selection */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 mt-6">
          <label htmlFor="staff-select" className="block text-sm font-semibold text-gray-800 mb-3">
            Select Staff Member
          </label>
          <div className="relative w-full md:w-2/3 lg:w-1/2 xl:w-1/3">
            <select
              id="staff-select"
              className="w-full px-4 py-3 pr-10 text-base border border-gray-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 appearance-none cursor-pointer shadow-sm hover:border-gray-400 disabled:bg-gray-50 disabled:cursor-not-allowed"
              value={selectedStaff}
              onChange={handleStaffChange}
              disabled={loading}
            >
              <option value="" className="text-gray-500">Choose a staff member...</option>
              {staff.map((staffMember) => (
                <option key={staffMember._id} value={staffMember._id} className="text-gray-900">
                  {staffMember.name} • {staffMember.role}
                </option>
              ))}
            </select>
            <div className="absolute inset-y-0 right-0 flex items-center px-3 pointer-events-none">
              <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </div>
          </div>
          {selectedStaff && (
            <p className="mt-2 text-sm text-green-600 flex items-center">
              <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
              </svg>
              Staff member selected
            </p>
          )}
        </div>
      </div>

      {selectedStaff ? (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          {/* Report tabs */}
          <div className="border-b border-gray-200">
            <nav className="flex">
              <button
                onClick={() => handleTabChange('current')}
                className={`py-3 px-6 text-sm font-medium ${
                  activeTab === 'current'
                    ? 'border-b-2 border-blue-500 text-blue-600 bg-blue-50'
                    : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
                }`}
              >
                Current Work Orders
              </button>
              <button
                onClick={() => handleTabChange('completed')}
                className={`py-3 px-6 text-sm font-medium ${
                  activeTab === 'completed'
                    ? 'border-b-2 border-blue-500 text-blue-600 bg-blue-50'
                    : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
                }`}
              >
                Completed Work Orders
              </button>
              <button
                onClick={() => handleTabChange('timestats')}
                className={`py-3 px-6 text-sm font-medium ${
                  activeTab === 'timestats'
                    ? 'border-b-2 border-blue-500 text-blue-600 bg-blue-50'
                    : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
                }`}
              >
                Time Stats
              </button>
              <button
                onClick={() => handleTabChange('manners')}
                className={`py-3 px-6 text-sm font-medium ${
                  activeTab === 'manners'
                    ? 'border-b-2 border-blue-500 text-blue-600 bg-blue-50'
                    : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
                }`}
              >
                Manners
              </button>
            </nav>
          </div>

          {/* Tab content */}
          <div className="p-6">
            {loading ? (
              <div className="flex justify-center items-center h-40">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
              </div>
            ) : (
              <>
                {/* Current Work Orders Tab */}
                {activeTab === 'current' && (
                  <div>
                    <div className="flex items-center justify-between mb-6">
                      <h2 className="text-2xl font-bold text-gray-900">Current Work Orders</h2>
                      <div className="flex items-center text-sm text-gray-500">
                        <span className="mr-2">Total:</span>
                        <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full font-medium">
                          {currentWorkOrders.length}
                        </span>
                      </div>
                    </div>
                    
                    {currentWorkOrders.length === 0 ? (
                      <div className="text-center py-12 bg-gradient-to-br from-gray-50 to-gray-100 rounded-xl border border-gray-200">
                        <div className="mx-auto w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                          <svg className="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                          </svg>
                        </div>
                        <h3 className="text-lg font-semibold text-gray-900 mb-2">
                          {(() => {
                            const selectedStaffMember = staff.find(s => s._id === selectedStaff);
                            const isTechnician = selectedStaffMember?.role?.toLowerCase() === 'technician';
                            return isTechnician ? 'No Current Work Orders' : 'Current Work Orders Coming Soon';
                          })()}
                        </h3>
                        <p className="text-gray-600">
                          {(() => {
                            const selectedStaffMember = staff.find(s => s._id === selectedStaff);
                            const isTechnician = selectedStaffMember?.role?.toLowerCase() === 'technician';
                            return isTechnician 
                              ? 'This staff member has no active work orders at the moment.' 
                              : 'Supervisor work orders will be available once part status filtering API is implemented.';
                          })()}
                        </p>
                      </div>
                    ) : (
                      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                        <div className="overflow-x-auto">
                          <table className="min-w-full divide-y divide-gray-200">
                            <thead className="bg-gradient-to-r from-gray-50 to-gray-100">
                              <tr>
                                <th className="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">
                                  <div className="flex items-center space-x-1">
                                    <span>Order #</span>
                                    <svg className="w-3 h-3 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a.997.997 0 01-1.414 0l-7-7A1.997 1.997 0 013 12V7a4 4 0 014-4z" />
                                    </svg>
                                  </div>
                                </th>
                                <th className="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">
                                  <div className="flex items-center space-x-1">
                                    <span>Description</span>
                                    <svg className="w-3 h-3 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h7" />
                                    </svg>
                                  </div>
                                </th>
                                <th className="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">
                                  <div className="flex items-center space-x-1">
                                    <span>Vehicle</span>
                                    <svg className="w-3 h-3 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17a2 2 0 11-4 0 2 2 0 014 0zM19 17a2 2 0 11-4 0 2 2 0 014 0z" />
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 6h3l2 7H6l2-7h3" />
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 17h14v2a1 1 0 01-1 1H6a1 1 0 01-1-1v-2z" />
                                    </svg>
                                  </div>
                                </th>
                                <th className="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">
                                  <div className="flex items-center space-x-1">
                                    <span>Customer</span>
                                    <svg className="w-3 h-3 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                    </svg>
                                  </div>
                                </th>
                                <th className="px-6 py-4 text-center text-xs font-bold text-gray-700 uppercase tracking-wider">
                                  Actions
                                </th>
                              </tr>
                            </thead>
                            <tbody className="bg-white divide-y divide-gray-100">
                              {currentWorkOrders.map((order, index) => (
                                <tr key={order._id} className={`hover:bg-blue-50 transition-colors duration-200 ${index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}`}>
                                  <td className="px-6 py-4 whitespace-nowrap">
                                    <div className="flex items-center">
                                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mr-3">
                                        <span className="text-xs font-bold text-blue-600">#{index + 1}</span>
                                      </div>
                                      <span className="text-sm font-bold text-gray-900">
                                        {order.workOrderNumber || order.work_order_number}
                                      </span>
                                    </div>
                                  </td>
                                  <td className="px-6 py-4">
                                    <div className="max-w-xs">
                                      <p className="text-sm text-gray-900 truncate font-medium">
                                        {order.description || 'No description'}
                                      </p>
                                      <p className="text-xs text-gray-500 mt-1">Work Order Details</p>
                                    </div>
                                  </td>
                                  <td className="px-6 py-4 whitespace-nowrap">
                                    <div className="flex items-center">
                                      <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mr-3">
                                        <svg className="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17a2 2 0 11-4 0 2 2 0 014 0zM19 17a2 2 0 11-4 0 2 2 0 014 0z" />
                                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 6h3l2 7H6l2-7h3" />
                                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 17h14v2a1 1 0 01-1 1H6a1 1 0 01-1-1v-2z" />
                                        </svg>
                                      </div>
                                      <div>
                                        <p className="text-sm font-medium text-gray-900">
                                          {order.vehicle ? `${order.vehicle.make} ${order.vehicle.model}`.trim() || order.vehicle.license_plate : 
                                           `Vehicle ID: ${order.vehicle_id}`}
                                        </p>
                                      </div>
                                    </div>
                                  </td>
                                  <td className="px-6 py-4 whitespace-nowrap">
                                    <div className="flex items-center">
                                      <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center mr-3">
                                        <svg className="w-4 h-4 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                        </svg>
                                      </div>
                                      <div>
                                        <p className="text-sm font-medium text-gray-900">
                                          {order.customer?.name || `Customer ID: ${order.customer_id}`}
                                        </p>
                                      </div>
                                    </div>
                                  </td>
                                  <td className="px-6 py-4 whitespace-nowrap text-center">
                                    <button
                                      onClick={() => router.push(`/workOrders/${order._id}`)}
                                      className="inline-flex items-center px-4 py-2 border border-blue-300 rounded-lg text-sm font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 hover:border-blue-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200"
                                    >
                                      <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                                      </svg>
                                      View Details
                                    </button>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    )}
                    
                    {/* Pagination */}
                    {pagination && (
                      <div className="py-3 flex items-center justify-between border-t border-gray-200 mt-4">
                        <div className="flex-1 flex justify-between items-center">
                          <button
                            onClick={() => pagination.has_prev_page && handlePageChange(pagination.prev_page!)}
                            disabled={!pagination.has_prev_page}
                            className={`relative px-4 py-2 border border-gray-300 text-sm font-medium rounded-md ${
                              pagination.has_prev_page
                                ? 'bg-white text-gray-700 hover:bg-gray-50'
                                : 'bg-gray-100 text-gray-400'
                            }`}
                          >
                            Previous
                          </button>
                          <span className="text-sm text-gray-700">
                            Page {pagination.current_page} of {pagination.total_pages}
                          </span>
                          <button
                            onClick={() => pagination.has_next_page && handlePageChange(pagination.next_page!)}
                            disabled={!pagination.has_next_page}
                            className={`relative px-4 py-2 border border-gray-300 text-sm font-medium rounded-md ${
                              pagination.has_next_page
                                ? 'bg-white text-gray-700 hover:bg-gray-50'
                                : 'bg-gray-100 text-gray-400'
                            }`}
                          >
                            Next
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Completed Work Orders Tab */}
                {activeTab === 'completed' && (
                  <div>
                    <div className="flex items-center justify-between mb-6">
                      <h2 className="text-2xl font-bold text-gray-900">Completed Work Orders</h2>
                      <div className="flex items-center text-sm text-gray-500">
                        <span className="mr-2">Total:</span>
                        <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full font-medium">
                          {completedWorkOrders.length}
                        </span>
                      </div>
                    </div>

                    {completedWorkOrders.length === 0 ? (
                      <div className="text-center py-12 bg-gradient-to-br from-gray-50 to-gray-100 rounded-xl border border-gray-200">
                        <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
                          <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                        </div>
                        <h3 className="text-lg font-semibold text-gray-900 mb-2">
                          {(() => {
                            const selectedStaffMember = staff.find(s => s._id === selectedStaff);
                            const isTechnician = selectedStaffMember?.role?.toLowerCase() === 'technician';
                            return isTechnician ? 'No Completed Work Orders' : 'Completed Work Orders Coming Soon';
                          })()}
                        </h3>
                        <p className="text-gray-600">
                          {(() => {
                            const selectedStaffMember = staff.find(s => s._id === selectedStaff);
                            const isTechnician = selectedStaffMember?.role?.toLowerCase() === 'technician';
                            return isTechnician 
                              ? 'This staff member has not completed any work orders yet.' 
                              : 'Supervisor work orders will be available once part status filtering API is implemented.';
                          })()}
                        </p>
                      </div>
                    ) : (
                      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                        <div className="overflow-x-auto">
                          <table className="min-w-full divide-y divide-gray-200">
                            <thead className="bg-gradient-to-r from-green-50 to-green-100">
                              <tr>
                                <th className="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">
                                  <div className="flex items-center space-x-1">
                                    <span>Order #</span>
                                    <svg className="w-3 h-3 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a.997.997 0 01-1.414 0l-7-7A1.997 1.997 0 013 12V7a4 4 0 014-4z" />
                                    </svg>
                                  </div>
                                </th>
                                <th className="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">
                                  <div className="flex items-center space-x-1">
                                    <span>Description</span>
                                    <svg className="w-3 h-3 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h7" />
                                    </svg>
                                  </div>
                                </th>
                                <th className="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">
                                  <div className="flex items-center space-x-1">
                                    <span>Vehicle</span>
                                    <svg className="w-3 h-3 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                                    </svg>
                                  </div>
                                </th>
                                <th className="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">
                                  <div className="flex items-center space-x-1">
                                    <span>Customer</span>
                                    <svg className="w-3 h-3 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                    </svg>
                                  </div>
                                </th>
                                <th className="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">
                                  <div className="flex items-center space-x-1">
                                    <span>Completed</span>
                                    <svg className="w-3 h-3 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                    </svg>
                                  </div>
                                </th>
                                <th className="px-6 py-4 text-center text-xs font-bold text-gray-700 uppercase tracking-wider">
                                  Actions
                                </th>
                              </tr>
                            </thead>
                            <tbody className="bg-white divide-y divide-gray-100">
                              {completedWorkOrders.map((order, index) => (
                                <tr key={order._id} className={`hover:bg-green-50 transition-colors duration-200 ${index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}`}>
                                  <td className="px-6 py-4 whitespace-nowrap">
                                    <div className="flex items-center">
                                      <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mr-3">
                                        <span className="text-xs font-bold text-green-600">#{index + 1}</span>
                                      </div>
                                      <span className="text-sm font-bold text-gray-900">
                                        {order.workOrderNumber || order.work_order_number}
                                      </span>
                                    </div>
                                  </td>
                                  <td className="px-6 py-4">
                                    <div className="max-w-xs">
                                      <p className="text-sm text-gray-900 truncate font-medium">
                                        {order.description || 'No description'}
                                      </p>
                                      <p className="text-xs text-gray-500 mt-1">Work Order Details</p>
                                    </div>
                                  </td>
                                  <td className="px-6 py-4 whitespace-nowrap">
                                    <div className="flex items-center">
                                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mr-3">
                                        <svg className="w-4 h-4 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                                        </svg>
                                      </div>
                                      <div>
                                        <p className="text-sm font-medium text-gray-900">
                                          {order.vehicle ? `${order.vehicle.make} ${order.vehicle.model}`.trim() || order.vehicle.license_plate : 
                                           `Vehicle ID: ${order.vehicle_id}`}
                                        </p>
                                      </div>
                                    </div>
                                  </td>
                                  <td className="px-6 py-4 whitespace-nowrap">
                                    <div className="flex items-center">
                                      <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center mr-3">
                                        <svg className="w-4 h-4 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                        </svg>
                                      </div>
                                      <div>
                                        <p className="text-sm font-medium text-gray-900">
                                          {order.customer?.name || `Customer ID: ${order.customer_id}`}
                                        </p>
                                      </div>
                                    </div>
                                  </td>
                                  <td className="px-6 py-4 whitespace-nowrap">
                                    <div className="flex items-center">
                                      <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-800 border border-green-200">
                                        <span className="w-2 h-2 rounded-full mr-2 bg-green-500"></span>
                                        COMPLETED
                                      </span>
                                      <div className="ml-3 text-sm text-gray-500">
                                        <div className="flex items-center">
                                          <svg className="w-4 h-4 text-gray-400 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                          </svg>
                                          {new Date(order.updatedAt).toLocaleDateString()}
                                        </div>
                                      </div>
                                    </div>
                                  </td>
                                  <td className="px-6 py-4 whitespace-nowrap text-center">
                                    <button
                                      onClick={() => router.push(`/workOrders/${order._id}`)}
                                      className="inline-flex items-center px-4 py-2 border border-green-300 rounded-lg text-sm font-medium text-green-700 bg-green-50 hover:bg-green-100 hover:border-green-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-all duration-200"
                                    >
                                      <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                                      </svg>
                                      View Details
                                    </button>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Time Stats Tab */}
                {activeTab === 'timestats' && (
                  <div>
                    <div className="flex items-center justify-between mb-6">
                      <h2 className="text-2xl font-bold text-gray-900">Time Statistics</h2>
                      <div className="flex items-center text-sm text-gray-500">
                        <span className="mr-2">Total Records:</span>
                        <span className="px-2 py-1 bg-orange-100 text-orange-800 rounded-full font-medium">
                          {filteredTimeStatsData.length}
                        </span>
                      </div>
                    </div>

                    {/* Date Range and Status Filters */}
                    <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 mb-6">
                      <div className="flex flex-wrap gap-4 items-center">
                        <div className="flex items-center gap-2">
                          <label htmlFor="from-date-filter" className="text-sm font-semibold text-gray-700">
                            From Date:
                          </label>
                          <input
                            type="date"
                            id="from-date-filter"
                            value={fromDateFilter}
                            onChange={(e) => setFromDateFilter(e.target.value)}
                            className="px-3 py-2 text-sm border border-gray-300 rounded-lg bg-white focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition-colors"
                          />
                        </div>

                        <div className="flex items-center gap-2">
                          <label htmlFor="to-date-filter" className="text-sm font-semibold text-gray-700">
                            To Date:
                          </label>
                          <input
                            type="date"
                            id="to-date-filter"
                            value={toDateFilter}
                            onChange={(e) => setToDateFilter(e.target.value)}
                            className="px-3 py-2 text-sm border border-gray-300 rounded-lg bg-white focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition-colors"
                            min={fromDateFilter || undefined}
                          />
                        </div>

                        <div className="flex items-center gap-2">
                          <label htmlFor="status-filter" className="text-sm font-semibold text-gray-700">
                            Filter by Status:
                          </label>
                          <select
                            id="status-filter"
                            value={statusFilter}
                            onChange={(e) => setStatusFilter(e.target.value)}
                            className="px-3 py-2 text-sm border border-gray-300 rounded-lg bg-white focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition-colors"
                          >
                            <option value="">All Statuses</option>
                            <option value="pending">Pending</option>
                            <option value="in_progress">In Progress</option>
                            <option value="completed">Completed</option>
                            <option value="cancelled">Cancelled</option>
                          </select>
                        </div>
                        
                        {(fromDateFilter || toDateFilter || statusFilter) && (
                          <button
                            onClick={() => {
                              setFromDateFilter('');
                              setToDateFilter('');
                              setStatusFilter('');
                            }}
                            className="px-3 py-1 text-xs bg-gray-100 text-gray-600 rounded-full hover:bg-gray-200 transition-colors"
                          >
                            Clear Filters
                          </button>
                        )}
                      </div>
                    </div>

                    {filteredTimeStatsData.length === 0 ? (
                      <div className="text-center py-12 bg-gradient-to-br from-gray-50 to-gray-100 rounded-xl border border-gray-200">
                        <div className="mx-auto w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mb-4">
                          <svg className="w-8 h-8 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                        </div>
                        <h3 className="text-lg font-semibold text-gray-900 mb-2">
                          {(() => {
                            const selectedStaffMember = staff.find(s => s._id === selectedStaff);
                            const isTechnician = selectedStaffMember?.role?.toLowerCase() === 'technician';
                            
                            if (!isTechnician) {
                              return 'Time Statistics Coming Soon';
                            }
                            
                            return 'No Work Orders Found';
                          })()}
                        </h3>
                        <p className="text-gray-600">
                          {(() => {
                            const selectedStaffMember = staff.find(s => s._id === selectedStaff);
                            const isTechnician = selectedStaffMember?.role?.toLowerCase() === 'technician';
                            
                            if (!isTechnician) {
                              return 'Supervisor time statistics will be available once part status filtering API is implemented.';
                            }
                            
                            return (fromDateFilter || toDateFilter || statusFilter) ? 
                              'No work orders match the selected filters.' :
                              'This staff member has no work orders available.';
                          })()}
                        </p>
                      </div>
                    ) : (
                      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                        <div className="overflow-x-auto">
                          <table className="min-w-full divide-y divide-gray-200">
                            <thead className="bg-gradient-to-r from-orange-50 to-orange-100">
                              <tr>
                                <th className="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">
                                  <div className="flex items-center space-x-1">
                                    <span>Order #</span>
                                    <svg className="w-3 h-3 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a.997.997 0 01-1.414 0l-7-7A1.997 1.997 0 013 12V7a4 4 0 014-4z" />
                                    </svg>
                                  </div>
                                </th>
                                <th className="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">
                                  <div className="flex items-center space-x-1">
                                    <span>Description</span>
                                    <svg className="w-3 h-3 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h7" />
                                    </svg>
                                  </div>
                                </th>
                                <th className="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">
                                  <div className="flex items-center space-x-1">
                                    <span>Vehicle</span>
                                    <svg className="w-3 h-3 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17a2 2 0 11-4 0 2 2 0 014 0zM19 17a2 2 0 11-4 0 2 2 0 014 0z" />
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 6h3l2 7H6l2-7h3" />
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 17h14v2a1 1 0 01-1 1H6a1 1 0 01-1-1v-2z" />
                                    </svg>
                                  </div>
                                </th>
                                <th className="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">
                                  <div className="flex items-center space-x-1">
                                    <span>Work Order Status</span>
                                    <svg className="w-3 h-3 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                    </svg>
                                  </div>
                                </th>
                                <th className="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">
                                  <div className="flex items-center space-x-1">
                                    <span>Created</span>
                                    <svg className="w-3 h-3 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                    </svg>
                                  </div>
                                </th>
                                <th className="px-6 py-4 text-center text-xs font-bold text-gray-700 uppercase tracking-wider">
                                  Actions
                                </th>
                              </tr>
                            </thead>
                            <tbody className="bg-white divide-y divide-gray-100">
                              {filteredTimeStatsData.map((order, index) => (
                                <tr key={order._id} className={`hover:bg-orange-50 transition-colors duration-200 ${index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}`}>
                                  <td className="px-6 py-4 whitespace-nowrap">
                                    <div className="flex items-center">
                                      <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center mr-3">
                                        <span className="text-xs font-bold text-orange-600">#{index + 1}</span>
                                      </div>
                                      <span className="text-sm font-bold text-gray-900">
                                        {order.workOrderNumber || order.work_order_number}
                                      </span>
                                    </div>
                                  </td>
                                  <td className="px-6 py-4">
                                    <div className="max-w-xs">
                                      <p className="text-sm text-gray-900 truncate font-medium">
                                        {order.description || 'No description'}
                                      </p>
                                      <p className="text-xs text-gray-500 mt-1">Work Order Details</p>
                                    </div>
                                  </td>
                                  <td className="px-6 py-4 whitespace-nowrap">
                                    <div className="flex items-center">
                                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mr-3">
                                        <svg className="w-4 h-4 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17a2 2 0 11-4 0 2 2 0 014 0zM19 17a2 2 0 11-4 0 2 2 0 014 0z" />
                                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 6h3l2 7H6l2-7h3" />
                                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 17h14v2a1 1 0 01-1 1H6a1 1 0 01-1-1v-2z" />
                                        </svg>
                                      </div>
                                      <div>
                                        <p className="text-sm font-medium text-gray-900">
                                          {order.vehicle ? `${order.vehicle.make} ${order.vehicle.model}`.trim() || order.vehicle.license_plate : 
                                           `Vehicle ID: ${order.vehicle_id}`}
                                        </p>
                                      </div>
                                    </div>
                                  </td>
                                  <td className="px-6 py-4 whitespace-nowrap">
                                    <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold ${
                                      order.status === 'completed' ? 'bg-green-100 text-green-800 border border-green-200' :
                                      order.status === 'in_progress' ? 'bg-blue-100 text-blue-800 border border-blue-200' :
                                      order.status === 'pending' ? 'bg-yellow-100 text-yellow-800 border border-yellow-200' :
                                      order.status === 'cancelled' ? 'bg-red-100 text-red-800 border border-red-200' :
                                      'bg-gray-100 text-gray-800 border border-gray-200'
                                    }`}>
                                      <span className={`w-2 h-2 rounded-full mr-2 ${
                                        order.status === 'completed' ? 'bg-green-500' :
                                        order.status === 'in_progress' ? 'bg-blue-500' :
                                        order.status === 'pending' ? 'bg-yellow-500' :
                                        order.status === 'cancelled' ? 'bg-red-500' :
                                        'bg-gray-500'
                                      }`}></span>
                                      {order.status.replace('_', ' ').toUpperCase()}
                                    </span>
                                  </td>
                                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                    <div className="flex items-center">
                                      <svg className="w-4 h-4 text-gray-400 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                      </svg>
                                      <div>
                                        <div>{new Date(order.createdAt).toLocaleDateString()}</div>
                                        <div className="text-xs text-gray-400">
                                          {new Date(order.createdAt).toLocaleTimeString()}
                                        </div>
                                      </div>
                                    </div>
                                  </td>
                                  <td className="px-6 py-4 whitespace-nowrap text-center">
                                    <button
                                      onClick={() => router.push(`/workOrders/${order._id}`)}
                                      className="inline-flex items-center px-4 py-2 border border-orange-300 rounded-lg text-sm font-medium text-orange-700 bg-orange-50 hover:bg-orange-100 hover:border-orange-400 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-offset-2 transition-all duration-200"
                                    >
                                      <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                                      </svg>
                                      View Details
                                    </button>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Manners Tab */}
                {activeTab === 'manners' && (
                  <div>
                    <div className="flex items-center justify-between mb-6">
                      <h2 className="text-xl font-semibold">Manner Evaluations</h2>
                      <div className="flex gap-3">
                        {canViewEvaluations && (
                          <button
                            onClick={() => {
                              fetchEvaluationLogs();
                              setShowLogsModal(true);
                            }}
                            className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors duration-200 flex items-center gap-2"
                          >
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                            View History
                          </button>
                        )}
                        {canManageEvaluations && (
                          <button
                            onClick={() => setShowAddModal(true)}
                            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200 flex items-center gap-2"
                          >
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                            </svg>
                            Add Evaluation
                          </button>
                        )}
                      </div>
                    </div>

                    {!canViewEvaluations ? (
                      <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                        <div className="flex">
                          <svg className="w-5 h-5 text-red-400 mr-2" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                          </svg>
                          <p className="text-red-700">You don't have permission to view manner evaluations.</p>
                        </div>
                      </div>
                    ) : mannerEvaluations.length === 0 ? (
                      <div className="text-center py-12">
                        <svg className="w-16 h-16 text-gray-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
                        </svg>
                        <h3 className="text-lg font-medium text-gray-900 mb-2">No evaluations yet</h3>
                        <p className="text-gray-500 mb-4">This staff member hasn't received any manner evaluations.</p>
                        {canManageEvaluations && (
                          <button
                            onClick={() => setShowAddModal(true)}
                            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200"
                          >
                            Add First Evaluation
                          </button>
                        )}
                      </div>
                    ) : (
                      <>
                        {/* Statistics Summary */}
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                          <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-lg p-4">
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="text-sm text-blue-100">Total Evaluations</p>
                                <p className="text-2xl font-bold">{mannerEvaluations.length}</p>
                              </div>
                              <svg className="w-8 h-8 text-blue-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                              </svg>
                            </div>
                          </div>
                          
                          <div className="bg-gradient-to-r from-green-500 to-green-600 text-white rounded-lg p-4">
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="text-sm text-green-100">Average Rating</p>
                                <p className="text-2xl font-bold">
                                  {mannerEvaluations.length > 0 
                                    ? (mannerEvaluations.reduce((sum, evaluation) => sum + evaluation.rating, 0) / mannerEvaluations.length).toFixed(1)
                                    : '0.0'
                                  }
                                </p>
                              </div>
                              <div className="flex">
                                {[...Array(5)].map((_, i) => (
                                  <svg 
                                    key={i} 
                                    className={`w-5 h-5 ${
                                    mannerEvaluations.length > 0 && i < Math.round(mannerEvaluations.reduce((sum, evaluation) => sum + evaluation.rating, 0) / mannerEvaluations.length)
                                        ? 'text-yellow-300' 
                                        : 'text-green-300'
                                    }`} 
                                    fill="currentColor" 
                                    viewBox="0 0 20 20"
                                  >
                                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                  </svg>
                                ))}
                              </div>
                            </div>
                          </div>
                          
                          <div className="bg-gradient-to-r from-purple-500 to-purple-600 text-white rounded-lg p-4">
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="text-sm text-purple-100">Top Category</p>
                                <p className="text-lg font-bold">
                                  {mannerEvaluations.length > 0 ? 
                                    Object.entries(mannerEvaluations.reduce((acc, evaluation) => {
                                      acc[evaluation.category] = (acc[evaluation.category] || 0) + 1;
                                      return acc;
                                    }, {} as Record<string, number>))
                                    .sort(([,a], [,b]) => b - a)[0][0] : 'N/A'
                                  }
                                </p>
                              </div>
                              <svg className="w-8 h-8 text-purple-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
                              </svg>
                            </div>
                          </div>
                          
                          <div className="bg-gradient-to-r from-orange-500 to-orange-600 text-white rounded-lg p-4">
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="text-sm text-orange-100">Recent Rating</p>
                                <p className="text-2xl font-bold">
                                  {mannerEvaluations.length > 0 ? 
                                    mannerEvaluations.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())[0].rating :
                                    'N/A'
                                  }
                                </p>
                              </div>
                              <svg className="w-8 h-8 text-orange-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                              </svg>
                            </div>
                          </div>
                        </div>

                        {/* Evaluations Grid */}
                        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                          {mannerEvaluations.map((evaluation) => (
                            <div key={evaluation._id} className="bg-white border border-gray-200 rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow duration-200">
                              {/* Header */}
                              <div className="flex items-center justify-between mb-4">
                                <h3 className="text-lg font-semibold text-gray-900">{evaluation.category}</h3>
                                {canManageEvaluations && (
                                  <div className="flex gap-2">
                                    <button
                                      onClick={() => setEditingEvaluation(evaluation)}
                                      className="text-blue-600 hover:text-blue-800 p-1"
                                      title="Edit evaluation"
                                    >
                                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                      </svg>
                                    </button>
                                    <button
                                      onClick={() => handleDeleteEvaluation(evaluation._id)}
                                      className="text-red-600 hover:text-red-800 p-1"
                                      title="Delete evaluation"
                                    >
                                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                      </svg>
                                    </button>
                                  </div>
                                )}
                              </div>

                              {/* Rating */}
                              <div className="flex items-center mb-4">
                                <div className="flex">
                                  {[1, 2, 3, 4, 5].map((star) => (
                                    <svg
                                      key={star}
                                      className={`w-5 h-5 ${
                                        star <= evaluation.rating ? 'text-yellow-400' : 'text-gray-300'
                                      }`}
                                      fill="currentColor"
                                      viewBox="0 0 20 20"
                                    >
                                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                    </svg>
                                  ))}
                                </div>
                                <span className="ml-2 text-sm text-gray-600">({evaluation.rating}/5)</span>
                              </div>

                              {/* Notes */}
                              {evaluation.notes && (
                                <div className="mb-4">
                                  <p className="text-gray-700 text-sm leading-relaxed">
                                    "{evaluation.notes}"
                                  </p>
                                </div>
                              )}

                              {/* Metadata */}
                              <div className="text-xs text-gray-500 space-y-1">
                                <div className="flex items-center justify-between">
                                  <span>Evaluated on:</span>
                                  <span>{new Date(evaluation.created_at).toLocaleDateString()}</span>
                                </div>
                                {evaluation.evaluator && (
                                  <div className="flex items-center justify-between">
                                    <span>By:</span>
                                    <span>{evaluation.evaluator.name} ({evaluation.evaluator.role})</span>
                                  </div>
                                )}
                                {evaluation.work_order_id && (
                                  <div className="flex items-center justify-between">
                                    <span>Work Order:</span>
                                    <button
                                      onClick={() => router.push(`/workOrders/${evaluation.work_order_id}`)}
                                      className="text-blue-600 hover:text-blue-800 cursor-pointer font-medium hover:underline"
                                    >
                                      {(() => {
                                        const workOrder = getWorkOrderById(evaluation.work_order_id);
                                        return workOrder ? 
                                          (workOrder.workOrderNumber || workOrder.work_order_number) : 
                                          `#${evaluation.work_order_id.slice(-6)}`;
                                      })()}
                                    </button>
                                  </div>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      </>
                    )}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      ) : (
        <div className="bg-gray-50 p-6 rounded-lg">
          <p className="text-gray-500">Please select a staff member to view their reports.</p>
        </div>
      )}

      {/* Add/Edit Evaluation Modal */}
      {(showAddModal || editingEvaluation) && (
        <EvaluationModal
          isOpen={showAddModal || !!editingEvaluation}
          onClose={() => {
            setShowAddModal(false);
            setEditingEvaluation(null);
          }}
          onSubmit={editingEvaluation ? 
            (data) => handleUpdateEvaluation(editingEvaluation._id, data) : 
            handleAddEvaluation
          }
          evaluation={editingEvaluation}
          workOrders={[...currentWorkOrders, ...completedWorkOrders]}
        />
      )}

      {/* Evaluation Logs Modal */}
      {showLogsModal && (
        <EvaluationLogsModal
          isOpen={showLogsModal}
          onClose={() => setShowLogsModal(false)}
          logs={evaluationLogs}
          evaluatorNames={evaluatorNames}
        />
      )}
    </div>
  );
};

// Evaluation Modal Component
const EvaluationModal = ({ 
  isOpen, 
  onClose, 
  onSubmit, 
  evaluation, 
  workOrders
}: {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: any) => void;
  evaluation?: MannerEvaluation | null;
  workOrders: WorkOrder[];
}) => {
  const [formData, setFormData] = useState({
    category: evaluation?.category || '',
    rating: evaluation?.rating || 5,
    work_order_id: evaluation?.work_order_id || '',
    notes: evaluation?.notes || ''
  });

  const categories = [
    'Customer Service',
    'Punctuality',
    'Teamwork',
    'Technical Skills',
    'Communication',
    'Professional Appearance',
    'Problem Solving',
    'Initiative'
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.category) return;
    
    // Prepare submission data, only include work_order_id if it has a value
    const submissionData: any = {
      category: formData.category,
      rating: formData.rating,
      notes: formData.notes || undefined
    };
    
    // Only include work_order_id if it's not empty
    if (formData.work_order_id && formData.work_order_id.trim() !== '') {
      submissionData.work_order_id = formData.work_order_id;
    }
    
    onSubmit(submissionData);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <h3 className="text-lg font-semibold mb-4">
            {evaluation ? 'Edit Evaluation' : 'Add New Evaluation'}
          </h3>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Category */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Category *
              </label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                required
              >
                <option value="">Select a category</option>
                {categories.map((category) => (
                  <option key={category} value={category}>
                    {category}
                  </option>
                ))}
              </select>
            </div>

            {/* Rating */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Rating *
              </label>
              <div className="flex items-center gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setFormData({ ...formData, rating: star })}
                    className={`w-8 h-8 ${
                      star <= formData.rating ? 'text-yellow-400' : 'text-gray-300'
                    } hover:text-yellow-400 transition-colors`}
                  >
                    <svg fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  </button>
                ))}
                <span className="ml-2 text-sm text-gray-600">
                  ({formData.rating}/5)
                </span>
              </div>
            </div>

            {/* Work Order */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Related Work Order (Optional)
              </label>
              <select
                value={formData.work_order_id}
                onChange={(e) => setFormData({ ...formData, work_order_id: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">No work order</option>
                {workOrders.map((order) => (
                  <option key={order._id} value={order._id}>
                    {order.workOrderNumber || order.work_order_number} - {order.description?.slice(0, 30)}...
                  </option>
                ))}
              </select>
            </div>

            {/* Notes */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Notes (Optional)
              </label>
              <textarea
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="Add any additional notes about this evaluation..."
              />
            </div>

            {/* Form Actions */}
            <div className="flex justify-end gap-3 pt-4">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors duration-200"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200"
              >
                {evaluation ? 'Update' : 'Add'} Evaluation
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

// Evaluation Logs Modal Component
const EvaluationLogsModal = ({ 
  isOpen, 
  onClose, 
  logs,
  evaluatorNames
}: {
  isOpen: boolean;
  onClose: () => void;
  logs: EvaluationLog[];
  evaluatorNames: Record<string, string>;
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [actionFilter, setActionFilter] = useState<string>('all');
  const [fromDateFilter, setFromDateFilter] = useState('');
  const [toDateFilter, setToDateFilter] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');

  // Debounce search term to improve performance
  const debouncedSearchTerm = useDebounce(searchTerm, 300);

  if (!isOpen) return null;

  // Get unique categories and actions for filter options
  const uniqueCategories = [...new Set(logs.map(log => log.category))];
  const uniqueActions = [...new Set(logs.map(log => log.action))];

  // Filter logs based on search and filter criteria
  const filteredLogs = logs.filter(log => {
    const matchesSearch = debouncedSearchTerm === '' || 
      log.category.toLowerCase().includes(debouncedSearchTerm.toLowerCase()) ||
      (log.notes && log.notes.toLowerCase().includes(debouncedSearchTerm.toLowerCase())) ||
      (evaluatorNames[log.evaluator_id] && evaluatorNames[log.evaluator_id].toLowerCase().includes(debouncedSearchTerm.toLowerCase()));
    
    const matchesAction = actionFilter === 'all' || log.action === actionFilter;
    
    const matchesCategory = categoryFilter === 'all' || log.category === categoryFilter;
    
    const matchesDateRange = (() => {
      if (!fromDateFilter && !toDateFilter) return true;
      
      const logDate = new Date(log.created_at);
      const fromDate = fromDateFilter ? new Date(fromDateFilter) : null;
      const toDate = toDateFilter ? new Date(toDateFilter) : null;
      
      if (fromDate && toDate) {
        return logDate >= fromDate && logDate <= toDate;
      } else if (fromDate) {
        return logDate >= fromDate;
      } else if (toDate) {
        return logDate <= toDate;
      }
      return true;
    })();
    
    return matchesSearch && matchesAction && matchesCategory && matchesDateRange;
  });

  // Sort filtered logs by date (newest first)
  const sortedLogs = filteredLogs.sort((a, b) => 
    new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
  );

  const clearFilters = () => {
    setSearchTerm('');
    setActionFilter('all');
    setFromDateFilter('');
    setToDateFilter('');
    setCategoryFilter('all');
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-6xl w-full max-h-[95vh] overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-gray-200 bg-gradient-to-r from-blue-50 to-indigo-50">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xl font-bold text-gray-900">Evaluation History</h3>
              <p className="text-sm text-gray-600 mt-1">
                {sortedLogs.length} of {logs.length} records
                {sortedLogs.length !== logs.length && ' (filtered)'}
              </p>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors p-2 hover:bg-gray-100 rounded-full"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        {/* Search and Filter Controls */}
        <div className="p-6 bg-gray-50 border-b border-gray-200">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
            {/* Search Input */}
            <div className="lg:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Search
                {searchTerm !== debouncedSearchTerm && (
                  <span className="ml-2 text-xs text-blue-500 animate-pulse">searching...</span>
                )}
              </label>
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search categories, notes, evaluators..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 shadow-sm hover:border-gray-400 placeholder-gray-400"
                />
                <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                  {searchTerm !== debouncedSearchTerm ? (
                    <svg className="w-5 h-5 text-blue-400 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                    </svg>
                  ) : (
                    <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                  )}
                </div>
              </div>
            </div>

            {/* Action Filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Action Type
              </label>
              <div className="relative">
                <select
                  value={actionFilter}
                  onChange={(e) => setActionFilter(e.target.value)}
                  className="w-full py-2.5 px-3 pr-10 border border-gray-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 appearance-none cursor-pointer shadow-sm hover:border-gray-400"
                >
                  <option value="all">All Actions</option>
                  {uniqueActions.map(action => (
                    <option key={action} value={action}>
                      {action.charAt(0).toUpperCase() + action.slice(1)}
                    </option>
                  ))}
                </select>
                <div className="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
                  <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </div>
              </div>
            </div>

            {/* Category Filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Category
              </label>
              <div className="relative">
                <select
                  value={categoryFilter}
                  onChange={(e) => setCategoryFilter(e.target.value)}
                  className="w-full py-2.5 px-3 pr-10 border border-gray-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 appearance-none cursor-pointer shadow-sm hover:border-gray-400"
                >
                  <option value="all">All Categories</option>
                  {uniqueCategories.map(category => (
                    <option key={category} value={category}>
                      {category}
                    </option>
                  ))}
                </select>
                <div className="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
                  <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </div>
              </div>
            </div>

            {/* Date Range Filters */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                From Date
              </label>
              <div className="relative">
                <input
                  type="date"
                  value={fromDateFilter}
                  onChange={(e) => setFromDateFilter(e.target.value)}
                  className="w-full py-2.5 px-3 pr-10 border border-gray-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 shadow-sm hover:border-gray-400 cursor-pointer"
                />
                <div className="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
                  <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                To Date
              </label>
              <div className="relative">
                <input
                  type="date"
                  value={toDateFilter}
                  onChange={(e) => setToDateFilter(e.target.value)}
                  className="w-full py-2.5 px-3 pr-10 border border-gray-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 shadow-sm hover:border-gray-400 cursor-pointer"
                  min={fromDateFilter || undefined}
                />
                <div className="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
                  <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                </div>
              </div>
            </div>
          </div>

          {/* Clear Filters Button */}
          <div className="mt-4 flex justify-between items-center">
            <button
              onClick={clearFilters}
              className="text-sm text-blue-600 hover:text-blue-800 font-medium flex items-center gap-1"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
              Clear Filters
            </button>
            <div className="text-sm text-gray-500">
              Showing {sortedLogs.length} records
            </div>
          </div>
        </div>
        
        {/* Content */}
        <div className="flex-1 overflow-y-auto max-h-[50vh]">
          {sortedLogs.length === 0 ? (
            <div className="p-8 text-center">
              <div className="mb-4">
                <svg className="w-16 h-16 text-gray-300 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
              </div>
              <p className="text-gray-500 text-lg">No evaluation history found</p>
              <p className="text-gray-400 text-sm mt-1">
                {logs.length === 0 ? 'No records available' : 'Try adjusting your search or filters'}
              </p>
            </div>
          ) : (
            <div className="p-6 space-y-4">
              {sortedLogs.map((log, index) => (
                <div key={log.log_id} className="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <span className={`px-3 py-1 text-xs font-semibold rounded-full ${
                        log.action === 'added' ? 'bg-green-100 text-green-800' :
                        log.action === 'updated' ? 'bg-blue-100 text-blue-800' :
                        'bg-red-100 text-red-800'
                      }`}>
                        {log.action === 'added' && '+ '}
                        {log.action === 'updated' && '✎ '}
                        {log.action === 'deleted' && '✗ '}
                        {log.action.charAt(0).toUpperCase() + log.action.slice(1)}
                      </span>
                      <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded">
                        #{index + 1}
                      </span>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-medium text-gray-900">
                        {new Date(log.created_at).toLocaleDateString()}
                      </div>
                      <div className="text-xs text-gray-500">
                        {new Date(log.created_at).toLocaleTimeString()}
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <div className="text-sm font-semibold text-gray-700 mb-1">Category & Rating</div>
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-bold text-blue-600">{log.category}</span>
                        <div className="flex items-center gap-1">
                          <span className="text-sm text-gray-500">Rating:</span>
                          <div className="flex items-center">
                            {[...Array(5)].map((_, i) => (
                              <svg
                                key={i}
                                className={`w-4 h-4 ${i < log.rating ? 'text-yellow-400' : 'text-gray-300'}`}
                                fill="currentColor"
                                viewBox="0 0 20 20"
                              >
                                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                              </svg>
                            ))}
                            <span className="text-sm font-medium text-gray-700 ml-1">
                              {log.rating}/5
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div>
                      <div className="text-sm font-semibold text-gray-700 mb-1">Evaluator</div>
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                          <span className="text-white text-xs font-bold">
                            {(evaluatorNames[log.evaluator_id] || 'U').charAt(0).toUpperCase()}
                          </span>
                        </div>
                        <span className="text-sm text-gray-900 font-medium">
                          {evaluatorNames[log.evaluator_id] || `User ID: ${log.evaluator_id}`}
                        </span>
                      </div>
                    </div>
                  </div>

                  {log.notes && (
                    <div className="mt-3 p-3 bg-gray-50 rounded-lg">
                      <div className="text-sm font-semibold text-gray-700 mb-1">Notes</div>
                      <p className="text-sm text-gray-600 leading-relaxed">{log.notes}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-gray-50 border-t border-gray-200">
          <div className="flex justify-between items-center">
            <div className="text-sm text-gray-500">
              Total: {logs.length} evaluation records
            </div>
            <button
              onClick={onClose}
              className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StaffReportsPage;
