"use client";

import React, { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import axios from "axios";
import api, { dataApi } from "@/services/api";
import { toast } from "react-hot-toast";
import StepOne from "./StepOne";
import StepTwo from "./StepTwo";
import { LanguageProvider, useLanguage } from "@/app/context/LanguageContext";
import ProgressLoader from "@/app/components/ui/ProgressLoader";
import useProgressTracker from "@/app/hooks/useProgressTracker";
// import Protected Route from "@/components/ProtectedRoute";

// Define interfaces for our form data
export interface Customer {
  first_name: string;
  last_name: string;
  phone: string;
  email: string;
  city: string;
  country: string;
  branch?: {
    branch_id: string;
    branch_name: string;
  };
}

export interface Vehicle {
  make: string;
  model: string;
  year: string;
  license_plate: string;
  vin: string;
  color: string;
  vehicle_type: string;
}

export interface PartWithService {
  part_id: string;
  part_name: string;
  variation_id: string;
  service_type: string;
}

export interface RepairDetails {
  variation_id: string; // MongoDB ObjectId as string - deprecated, kept for backward compatibility
  service_type: string; // Keep this for display purposes - deprecated
  presented_service_type: string; // The service type to display on the invoice
  notes: string;
  price: string;
  
  // Supervisor fields
  supervisor_ratio: string;
  supervisor_expected_delivery_date: string;
  assigned_technician: string;
  
  down_payment: string;
  payment_status: string;
  payment_method: string;
  selected_parts: string[]; // deprecated - kept for backward compatibility
  parts_with_services: PartWithService[];
  with_tax: boolean; // Tax invoice vs car job flag
}

export interface ExistingCustomer {
  _id: string;
  first_name: string;
  last_name: string;
  email: string;
  phone: string;
  city: string;
  country: string;
  vehicles?: Vehicle[];
  branch?: {
    branch_id: string;
    branch_name: string;
  };
}

export interface Variation {
  _id: string;
  code: string;
  description: string;
  defaultLaborHours: number;
  defaultStages: string[];
  created_at?: string;
  updated_at?: string;
}

export interface Technician {
  _id: string;
  name: string;
  email?: string;
  role?: string;
}

// License Plate Regions by Country
export const plateRegionsByCountry: Record<string, Array<{ name: string; code: string }>> = {
  "UAE": [
    { name: "Abu Dhabi", code: "AD" },
    { name: "Dubai", code: "DXB" },
    { name: "Sharjah", code: "SHJ" },
    { name: "Ajman", code: "AJM" },
    { name: "Umm Al Quwain", code: "UAQ" },
    { name: "Ras Al Khaimah", code: "RAK" },
    { name: "Fujairah", code: "FUJ" }
  ],
  "Saudi Arabia": [
    { name: "Saudi Arabia", code: "KSA" }
  ],
  "Jordan": [],
  "Kuwait": [],
  "Oman": [],
  "Syria": [
    { name: "Damascus", code: "دمشق" },
    { name: "Aleppo", code: "حلب" },
    { name: "Homs", code: "حمص" },
    { name: "Hama", code: "حماة" },
    { name: "Lattakia", code: "اللاذقية" },
    { name: "Deir ez-Zor", code: "دير الزور" },
    { name: "Raqqa", code: "الرقة" },
    { name: "Daraa", code: "درعا" },
    { name: "Sweida", code: "السويداء" },
    { name: "Quneitra", code: "القنيطرة" },
    { name: "Tartus", code: "طرطوس" },
    { name: "Hasaka", code: "الحسكة" },
    { name: "Idlib", code: "إدلب" },
    { name: "Rural Damascus", code: "ريف دمشق" }
  ],
  "Sudan": [
    { name: "Khartoum", code: "KH" },
    { name: "Omdurman", code: "OM" },
    { name: "Khartoum North", code: "KN" },
    { name: "Port Sudan", code: "PS" },
    { name: "Kassala", code: "KS" },
    { name: "Wad Madani", code: "WM" },
    { name: "El Obeid", code: "EO" },
    { name: "Nyala", code: "NY" },
    { name: "Gedaref", code: "GD" },
    { name: "Atbara", code: "AT" }
  ]
};

// For backward compatibility
export const plateRegions = plateRegionsByCountry["UAE"];

// Common car manufacturers
export const carMakes = [
  "Acura", "Alfa Romeo", "Aston Martin", "Audi", "Bentley", "BMW", "Bugatti",
  "Buick", "Cadillac", "Chevrolet", "Chrysler", "Citroën", "Dodge", "Ferrari",
  "Fiat", "Ford", "Genesis", "GMC", "Honda", "Hyundai", "Infiniti", "Jaguar",
  "Jeep", "Kia", "Lamborghini", "Land Rover", "Lexus", "Lincoln", "Lotus",
  "Maserati", "Mazda", "McLaren", "Mercedes-Benz", "Mini", "Mitsubishi",
  "Nissan", "Pagani", "Peugeot", "Porsche", "Ram", "Renault", "Rolls-Royce",
  "Subaru", "Tesla", "Toyota", "Volkswagen", "Volvo"
];

function NewRegistrationContent() {
  const router = useRouter();
  const { t, language, setLanguage, isRTL } = useLanguage();
  
  // Track which step we're on
  const [currentStep, setCurrentStep] = useState<number>(1);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Track registration type (set on first page)
  const [registrationType, setRegistrationType] = useState<'work_order' | 'quotation' | null>(null);

  // Quotation and work order state
  const [isCreatingWorkOrder, setIsCreatingWorkOrder] = useState<boolean>(false);
  const [isPrintingQuotation, setIsPrintingQuotation] = useState<boolean>(false);
  
  // State for variations (service types) and technicians
  const [variations, setVariations] = useState<Variation[]>([]);
  const [technicians, setTechnicians] = useState<Technician[]>([]);
  const [selectedTechnician, setSelectedTechnician] = useState<string>("");
  const [isLoadingVariations, setIsLoadingVariations] = useState<boolean>(false);
  const [isLoadingTechnicians, setIsLoadingTechnicians] = useState<boolean>(false);
  
  // State for form data
  const [customer, setCustomer] = useState<Customer>({
    first_name: "",
    last_name: "",
    phone: "",
    email: "",
    city: "",
    country: "UAE", // Default to UAE
    branch: undefined,
  });
  
  const [vehicle, setVehicle] = useState<Vehicle>({
    make: "",
    model: "",
    year: "",
    license_plate: "",
    vin: "",
    color: "",
    vehicle_type: "",
  });

  const [repair, setRepair] = useState<RepairDetails>({
    variation_id: "",
    service_type: "",
    presented_service_type: "",
    notes: "",
    price: "0",
    
    // Supervisor fields
    supervisor_ratio: "100",
    supervisor_expected_delivery_date: "",
    assigned_technician: "",
    
    down_payment: "0",
    payment_status: "Unpaid",
    payment_method: "cash",
    selected_parts: [],
    parts_with_services: [],
    with_tax: true, // Always include tax
  });
  
  // State for the vehicle images (up to 5)
  const [vehicleImages, setVehicleImages] = useState<File[]>([]);
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);
  
  // State for loading status messages
  const [loadingStatus, setLoadingStatus] = useState<string>("");
  
  // State for error display
  const [errorDetails, setErrorDetails] = useState<{
    message: string;
    details?: any;
    timestamp?: string;
    stage?: string;
  } | null>(null);
  const [showErrorModal, setShowErrorModal] = useState<boolean>(false);
  
  // Selected customer for existing customer flow
  const [selectedCustomer, setSelectedCustomer] = useState<ExistingCustomer | null>(null);

  // Progress tracking for registration process
  const registrationSteps = [
    {
      id: 'validation',
      name: 'Validating Information',
      description: 'Checking form data and requirements...',
      weight: 5,
      estimatedDuration: 1000
    },
    {
      id: 'customer_creation',
      name: 'Creating Customer',
      description: 'Setting up customer profile...',
      weight: 15,
      estimatedDuration: 3000
    },
    {
      id: 'vehicle_setup',
      name: 'Vehicle Setup',
      description: 'Adding vehicle information...',
      weight: 10,
      estimatedDuration: 2000
    },
    {
      id: 'work_order_creation',
      name: 'Creating Work Order',
      description: 'Setting up job tracking...',
      weight: 20,
      estimatedDuration: 4000
    },
    {
      id: 'invoice_preparation',
      name: 'Preparing Invoice',
      description: 'Generating invoice data...',
      weight: 10,
      estimatedDuration: 2000
    },
    {
      id: 'file_upload',
      name: 'Uploading Images',
      description: 'Processing vehicle images...',
      weight: 25,
      estimatedDuration: 8000
    },
    {
      id: 'payment_setup',
      name: 'Payment Processing',
      description: 'Recording payment information...',
      weight: 10,
      estimatedDuration: 2000
    },
    {
      id: 'finalization',
      name: 'Finalizing Registration',
      description: 'Completing registration process...',
      weight: 5,
      estimatedDuration: 1000
    }
  ];

  const registrationTracker = useProgressTracker({
    steps: registrationSteps,
    onComplete: () => {
      console.log('Registration completed');
    },
    onError: (error, step) => {
      console.error(`Registration step ${step.name} failed:`, error);
    }
  });

  // Quotation generation steps
  const quotationSteps = [
    {
      id: 'prepare_data',
      name: 'Preparing Data',
      description: 'Gathering quotation information...',
      weight: 20,
      estimatedDuration: 1000
    },
    {
      id: 'generate_pdf',
      name: 'Generating PDF',
      description: 'Creating quotation document...',
      weight: 50,
      estimatedDuration: 3000
    },
    {
      id: 'finalize',
      name: 'Finalizing',
      description: 'Opening quotation for preview...',
      weight: 30,
      estimatedDuration: 1000
    }
  ];

  const quotationTracker = useProgressTracker({
    steps: quotationSteps,
    onComplete: () => {
      console.log('Quotation generation completed');
      toast.success('Quotation generated successfully!');
    },
    onError: (error, step) => {
      console.error(`Quotation generation step ${step.name} failed:`, error);
      toast.error('Failed to generate quotation. Please try again.');
    }
  });

  // Helper function to handle errors visually (defined early for useEffect)
  const handleError = (error: any, stage: string) => {
    console.error(`Error at stage: ${stage}`, error);
    
    const errorInfo: any = {
      message: "An error occurred",
      stage: stage,
      timestamp: new Date().toISOString(),
      details: {}
    };
    
    // Extract error details based on error type
    if (error?.response) {
      // Axios error with response
      errorInfo.message = error.response.data?.message || 
                         error.response.data?.error || 
                         error.response.data?.errmsg ||
                         `Server error: ${error.response.status}`;
      errorInfo.details = {
        status: error.response.status,
        statusText: error.response.statusText,
        data: error.response.data,
        headers: error.response.headers,
        url: error.config?.url,
        method: error.config?.method,
        requestData: error.config?.data
      };
      
      // Special handling for validation errors
      if (error.response.status === 400 && error.response.data?.details) {
        errorInfo.validationErrors = error.response.data.details;
      }
    } else if (error instanceof Error) {
      errorInfo.message = error.message;
      errorInfo.details = {
        name: error.name,
        stack: error.stack,
        ...error
      };
    } else if (typeof error === 'string') {
      errorInfo.message = error;
    } else {
      errorInfo.message = "An unexpected error occurred";
      errorInfo.details = error;
    }
    
    // Set error state to show in UI
    setErrorDetails(errorInfo);
    setShowErrorModal(true);
    
    // Also show toast for quick notification
    toast.error(errorInfo.message);
    
    return errorInfo;
  };
  
  // Fetch variations and technicians when component mounts
  useEffect(() => {
    const fetchVariations = async () => {
      setIsLoadingVariations(true);
      try {
        const response = await api.get("/api/variations");
        const variationsData = response || [];
        setVariations(Array.isArray(variationsData) ? variationsData : []);
      } catch (error) {
        handleError(error, "Loading Service Types");
        setVariations([]);
      } finally {
        setIsLoadingVariations(false);
      }
    };
    
    const fetchTechnicians = async () => {
      setIsLoadingTechnicians(true);
      try {
        // Fetch supervisors instead of technicians
        const response = await api.get("/api/users?role=Supervisor");
        const supervisorsData = response || [];
        setTechnicians(Array.isArray(supervisorsData) ? supervisorsData : []);
        
        // Set default selected supervisor if available
        if (Array.isArray(supervisorsData) && supervisorsData.length > 0) {
          setSelectedTechnician(supervisorsData[0]._id);
          setRepair(prev => ({
            ...prev,
            assigned_technician: supervisorsData[0]._id
          }));
        }
      } catch (error) {
        console.error("Error fetching supervisors:", error);
        // If users endpoint doesn't work, try a different approach
        try {
          const roleResponse = await api.get("/api/roles");
          const rolesData = roleResponse || [];
          const supervisorRole = Array.isArray(rolesData) ? rolesData.find((role: any) => role.role_name === "Supervisor") : null;
          if (supervisorRole) {
            const userResponse = await api.get(`/api/users?role_id=${supervisorRole._id}`);
            const usersData = userResponse || [];
            setTechnicians(Array.isArray(usersData) ? usersData : []);
            if (Array.isArray(usersData) && usersData.length > 0) {
              setSelectedTechnician(usersData[0]._id);
              setRepair(prev => ({
                ...prev,
                assigned_technician: usersData[0]._id
              }));
            }
          }
        } catch (fallbackError) {
          handleError(fallbackError, "Loading Supervisors (Fallback)");
        }
      } finally {
        setIsLoadingTechnicians(false);
      }
    };
    
    const fetchBranches = async () => {
      try {
        const response = await api.get("/api/branches");
        const branchesData = response.data || response;
        
        if (Array.isArray(branchesData)) {
          // Find Sharjah branch and set as default
          const sharjahBranch = branchesData.find((branch: any) => 
            branch.name?.toLowerCase().includes('sharjah') || 
            branch.branch_name?.toLowerCase().includes('sharjah')
          );
          
          if (sharjahBranch) {
            setCustomer(prev => ({
              ...prev,
              branch: {
                branch_id: sharjahBranch._id,
                branch_name: sharjahBranch.name || sharjahBranch.branch_name || 'Sharjah'
              }
            }));
          }
        }
      } catch (error) {
        console.error("Error fetching branches:", error);
      }
    };

    fetchVariations();
    fetchTechnicians();
    fetchBranches();
  }, []);
  
  // Calculate total amount (always includes 5% VAT)
  const calculateTotal = () => {
    const price = parseFloat(repair.price) || 0;
    const vat = price * 0.05; // Always 5% VAT
    return (price + vat).toFixed(2);
  };
  
  // Handle customer form field changes
  const handleCustomerChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setCustomer((prev) => ({
      ...prev,
      [name]: value,
    }));
  };
  
  // Direct update method for customer data
  const updateCustomerData = (customerData: Partial<Customer>) => {
    setCustomer(prev => ({
      ...prev,
      ...customerData
    }));
  };
  
  // Handle vehicle form field changes
  const handleVehicleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setVehicle((prev) => ({
      ...prev,
      [name]: value,
    }));
  };
  
  // Handle repair form field changes
  const handleRepairChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement> | { target: { name: string; value: string | string[] | PartWithService[] } }) => {
    const { name, value } = e.target;
    
    if (name === "variation_id") {
      // Find the corresponding variation description
      const selectedVariation = variations.find(v => v._id === value);
      
      setRepair((prev) => ({
        ...prev,
        variation_id: value as string,
        service_type: selectedVariation ? selectedVariation.description : "",
      }));
    } else if (name === "selected_parts") {
      // Handle array value for selected parts
      setRepair((prev) => ({
        ...prev,
        selected_parts: value as string[],
      }));
    } else if (name === "parts_with_services") {
      // Handle parts with services array
      setRepair((prev) => ({
        ...prev,
        parts_with_services: value as PartWithService[],
      }));
    } else if (name === "with_tax") {
      // Tax is always true - ignore this change
      return;
    } else if (name === "down_payment" || name === "price") {
      // Handle down payment and price changes with automatic payment status update
      setRepair((prev) => {
        let updatedValue = value as string;
        
        // If it's down payment, ensure it doesn't exceed total amount
        if (name === "down_payment") {
          const price = parseFloat(prev.price) || 0;
          let totalAmount = price;
          if (prev.with_tax) {
            totalAmount = price + (price * 0.05); // Add 5% VAT
          }
          
          const downPaymentValue = parseFloat(value as string) || 0;
          if (downPaymentValue > totalAmount) {
            updatedValue = totalAmount.toFixed(2);
          }
        }
        
        const updatedRepair = {
          ...prev,
          [name]: updatedValue,
        };
        
        // Calculate total amount for comparison (always includes 5% VAT)
        const price = parseFloat(name === "price" ? updatedValue : updatedRepair.price) || 0;
        const downPayment = parseFloat(name === "down_payment" ? updatedValue : updatedRepair.down_payment) || 0;
        
        const totalAmount = price + (price * 0.05); // Always add 5% VAT
        
        // Auto-update payment status based on down payment
        let paymentStatus = updatedRepair.payment_status;
        if (downPayment > 0) {
          if (downPayment >= totalAmount) {
            paymentStatus = "Paid";
          } else {
            paymentStatus = "Partial";
          }
        } else {
          paymentStatus = "Unpaid";
        }
        
        return {
          ...updatedRepair,
          payment_status: paymentStatus,
        };
      });
    } else {
      setRepair((prev) => ({
        ...prev,
        [name]: value,
      }));
    }
  };
  
  // Handle selecting a car make
  const handleMakeSelect = (make: string) => {
    setVehicle((prev) => ({
      ...prev,
      make
    }));
  };
  
  // Select existing customer
  const selectExistingCustomer = (customer: ExistingCustomer, autoFillVehicle: boolean = true) => {
    setSelectedCustomer(customer);
    
    // Fill customer data
    setCustomer({
      first_name: customer.first_name || '',
      last_name: customer.last_name || '',
      phone: customer.phone || '',
      email: customer.email || '', // Ensure it's at least an empty string for the form
      city: customer.city || '',
      country: customer.country || 'UAE',
      branch: customer.branch || undefined
    });
    
    // Only auto-fill vehicle if requested and customer has vehicles
    if (autoFillVehicle && customer.vehicles && customer.vehicles.length > 0) {
      const firstVehicle = customer.vehicles[0];
      setVehicle({
        make: firstVehicle.make || '',
        model: firstVehicle.model || '',
        year: firstVehicle.year?.toString() || '',
        license_plate: firstVehicle.license_plate || '',
        vin: firstVehicle.vin || '',
        color: firstVehicle.color || '',
        vehicle_type: firstVehicle.vehicle_type || '',
      });
    }
  };
  
  // Handle selecting a license plate region
  const handleRegionSelect = (regionCode: string) => {
    setVehicle((prev) => ({
      ...prev,
      license_plate: regionCode + " " + prev.license_plate.replace(/^(AD|DXB|SHJ|AJM|UAQ|RAK|FUJ|KSA)\s*/, "")
    }));
  };
  
  // Handle image selection (supports multiple files up to 5)
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      const maxImages = 5;
      const maxSizeInMB = 5;
      const maxSizeInBytes = maxSizeInMB * 1024 * 1024;
      
      // Check if adding these files would exceed the limit
      if (vehicleImages.length + files.length > maxImages) {
        toast.error(`You can only upload up to ${maxImages} images. You currently have ${vehicleImages.length} image(s).`);
        e.target.value = '';
        return;
      }
      
      const validFiles: File[] = [];
      const newPreviews: string[] = [];
      
      for (const file of files) {
        // Check file size
        if (file.size > maxSizeInBytes) {
          toast.error(`File "${file.name}" exceeds ${maxSizeInMB}MB limit and was skipped.`);
          continue;
        }
        
        // Check file type
        if (!file.type.startsWith('image/')) {
          toast.error(`File "${file.name}" is not an image and was skipped.`);
          continue;
        }
        
        validFiles.push(file);
        
        // Create preview URL
        const reader = new FileReader();
        reader.onload = (event) => {
          if (event.target?.result) {
            newPreviews.push(event.target.result as string);
            
            // Update previews when all files are processed
            if (newPreviews.length === validFiles.length) {
              setImagePreviews(prev => [...prev, ...newPreviews]);
            }
          }
        };
        reader.readAsDataURL(file);
      }
      
      if (validFiles.length > 0) {
        setVehicleImages(prev => [...prev, ...validFiles]);
        toast.success(`${validFiles.length} image(s) added successfully.`);
      }
      
      // Clear the input
      e.target.value = '';
    }
  };
  
  // Handle removing a specific image
  const handleRemoveImage = (index: number) => {
    setVehicleImages(prev => prev.filter((_, i) => i !== index));
    setImagePreviews(prev => prev.filter((_, i) => i !== index));
    toast.success("Image removed successfully.");
  };
  
  // Handle technician selection
  const handleTechnicianChange = (technicianId: string) => {
    setSelectedTechnician(technicianId);
    setRepair(prev => ({
      ...prev,
      assigned_technician: technicianId
    }));
  };
  
  // Validate Step 1 data
  const validateStep1 = () => {
    console.log('=== VALIDATION DEBUG ===');
    console.log('Customer data:', customer);
    console.log('Vehicle data:', vehicle);
    console.log('Vehicle images count:', vehicleImages.length);
    
    // Basic validation for required fields (email is optional)
    if (!customer.first_name || !customer.last_name || !customer.phone) {
      console.log('Customer validation failed:', {
        first_name: customer.first_name,
        last_name: customer.last_name,
        phone: customer.phone
      });
      toast.error("Please fill in all required customer information");
      return false;
    }
    
    // Validate email format only if email is provided
    if (customer.email && customer.email.trim()) {
      const emailRegex = /^.+@.+\..+$/;
      if (!emailRegex.test(customer.email)) {
        toast.error("Please enter a valid email address");
        return false;
      }
    }
    
    if (!vehicle.make || !vehicle.model || !vehicle.license_plate) {
      console.log('Vehicle validation failed:', {
        make: vehicle.make,
        model: vehicle.model,
        license_plate: vehicle.license_plate
      });
      toast.error("Please fill in all required vehicle information");
      return false;
    }
    
    if (vehicleImages.length === 0) {
      console.log('Image validation failed: No images uploaded');
      toast.error("Please upload at least one vehicle image");
      return false;
    }
    
    console.log('Step 1 validation passed!');
    return true;
  };
  
  // Validate Step 2 data
  const validateStep2 = () => {
    if (!repair.supervisor_expected_delivery_date) {
      toast.error("Please provide expected delivery date for supervisor");
      return false;
    }
    
    if (!repair.parts_with_services || repair.parts_with_services.length === 0) {
      toast.error("Please add at least one car part with service type");
      return false;
    }
    
    // Validate each part has a service type
    const invalidParts = repair.parts_with_services.filter(part => !part.variation_id);
    if (invalidParts.length > 0) {
      toast.error("Please select a service type for all parts");
      return false;
    }
    
    if (!repair.assigned_technician) {
      toast.error("Please select a supervisor");
      return false;
    }
    
    // Validate numeric fields
    if (isNaN(parseFloat(repair.price)) || parseFloat(repair.price) < 0) {
      toast.error("Please enter a valid price");
      return false;
    }
    
    if (isNaN(parseFloat(repair.supervisor_ratio)) || parseFloat(repair.supervisor_ratio) < 0 || parseFloat(repair.supervisor_ratio) > 100) {
      toast.error("Supervisor ratio must be between 0 and 100");
      return false;
    }
    
    if (isNaN(parseFloat(repair.down_payment)) || parseFloat(repair.down_payment) < 0) {
      toast.error("Please enter a valid down payment amount");
      return false;
    }
    
    // Validate down payment doesn't exceed total amount
    const totalAmount = parseFloat(calculateTotal());
    if (parseFloat(repair.down_payment) > totalAmount) {
      toast.error("Down payment cannot exceed total amount");
      return false;
    }
    
    return true;
  };
  
  // Navigate to next step
  const handleNextStep = () => {
    console.log('=== HANDLE NEXT STEP CALLED ===');
    console.log('Current step:', currentStep);
    
    if (validateStep1()) {
      console.log('Validation passed, moving to step 2');
      setCurrentStep(2);
    } else {
      console.log('Validation failed, staying on step 1');
    }
  };
  
  // Navigate to previous step
  const handlePreviousStep = () => {
    setCurrentStep(1);
  };
  
  // Basic validation for showing modal (minimal requirements)
  const validateBasicForm = () => {
    console.log('validateBasicForm - repair.price:', repair.price, 'repair.presented_service_type:', repair.presented_service_type);

    // Only check essential fields needed for both quotations and work orders
    if (!repair.price || isNaN(parseFloat(repair.price)) || parseFloat(repair.price) <= 0) {
      toast.error("Please enter a valid price");
      return false;
    }

    if (!repair.presented_service_type || repair.presented_service_type.trim() === '') {
      toast.error("Please enter a service type");
      return false;
    }

    console.log('Basic validation passed');
    return true;
  };

  // Handle form submission based on registration type selected in Step 1
  const handleSubmit = async () => {
    console.log('handleSubmit called, registrationType:', registrationType);

    if (registrationType === 'quotation') {
      // Basic validation passed (only price and service type required), print quotation directly
      console.log('Registration type is quotation, generating quotation PDF');
      handlePrintQuotation();
    } else if (registrationType === 'work_order') {
      // Full validation passed (all fields required), proceed with work order creation
      console.log('Registration type is work order, creating work order');
      proceedWithWorkOrder();
    }
  };


  // Separate function to handle the actual work order creation after full validation
  const proceedWithWorkOrder = async () => {
    setIsCreatingWorkOrder(true);
    setIsSubmitting(true);

    // Start progress tracking
    registrationTracker.start();
    registrationTracker.startStep('validation');

    let customerId: string | undefined;
    let addedVehicle;

    try {
      customerId = selectedCustomer?._id;

      // Simulate validation step
      await new Promise(resolve => setTimeout(resolve, 800));
      registrationTracker.completeStep('validation');

      // Simulate validation step
      await new Promise(resolve => setTimeout(resolve, 800));
      registrationTracker.completeStep('validation');
      
      // DEBUG: Log all form data being submitted
      console.log("=== FORM SUBMISSION DEBUG ===");
      console.log("Customer data:", JSON.stringify(customer, null, 2));
      console.log("Vehicle data:", JSON.stringify(vehicle, null, 2));
      console.log("Selected customer ID:", customerId);
      console.log("Selected customer data:", JSON.stringify(selectedCustomer, null, 2));
      console.log("Vehicle image files:", vehicleImages.map(img => img.name));
      
      // Create or get customer
      if (!customerId) {
        registrationTracker.startStep('customer_creation');
        // Prepare vehicle data with optional integer year
        const vehicleData: any = {
          make: vehicle.make,
          model: vehicle.model,
          license_plate: vehicle.license_plate,
          vin: vehicle.vin || "", // Ensure vin is at least an empty string
          color: vehicle.color,
          vehicle_type: vehicle.vehicle_type
        };
        
        // Only include year if provided and valid
        if (vehicle.year && String(vehicle.year).trim()) {
          vehicleData.year = parseInt(String(vehicle.year));
        }
        // Don't include year field at all if empty
        
        console.log("DEBUG: Prepared vehicle data for new customer:", JSON.stringify(vehicleData, null, 2));
        console.log("DEBUG: Vehicle year field exists in vehicleData?", 'year' in vehicleData);
        console.log("DEBUG: Vehicle year value:", vehicleData.year);
        console.log("DEBUG: All vehicleData keys:", Object.keys(vehicleData));
        
        // Create customer data object - email is optional
        const customerData: any = {
          first_name: customer.first_name,
          last_name: customer.last_name,
          phone: customer.phone,
          city: customer.city,
          country: customer.country,
          vehicles: [vehicleData] // Include vehicle in customer creation
        };
        
        // Only include email if it's provided
        if (customer.email && customer.email.trim()) {
          customerData.email = customer.email.trim();
          console.log("DEBUG: Including email in payload:", customer.email.trim());
        } else {
          console.log("DEBUG: No email provided - field will be omitted");
        }
        
        // Only add branch if it exists and has both required fields
        if (customer.branch && customer.branch.branch_id && customer.branch.branch_name) {
          customerData.branch = {
            branch_id: customer.branch.branch_id,
            branch_name: customer.branch.branch_name
          };
        }
        
        console.log("DEBUG: Raw customer state:", JSON.stringify(customer, null, 2));
        console.log("DEBUG: Processed customerData being sent to API:", JSON.stringify(customerData, null, 2));
        console.log("DEBUG: Email field check - customer.email:", `'${customer.email}'`);
        console.log("DEBUG: Email field check - will include email?", !!(customer.email && customer.email.trim()));
        
        // FINAL CHECK: Verify the payload one more time before sending
        console.log("DEBUG: FINAL PAYLOAD CHECK - about to send this to API:");
        console.log("DEBUG: customerData keys:", Object.keys(customerData));
        console.log("DEBUG: customerData.email exists?", 'email' in customerData);
        console.log("DEBUG: customerData.email value:", customerData.email);
        console.log("DEBUG: FINAL FULL PAYLOAD:", JSON.stringify(customerData, null, 2));
        
        const customerResponse = await api.post("/api/customers", customerData);
        console.log("DEBUG: Customer creation response:", customerResponse);

        // Check if the response has a nested data structure
        const customerResponseData = customerResponse.data || customerResponse;
        if (!customerResponseData || !customerResponseData._id) {
          throw new Error("Invalid response from customer creation");
        }

        customerId = customerResponseData._id;
        registrationTracker.completeStep('customer_creation');
        toast.success("New customer created successfully");
        
        // Get the vehicle that was just created with the customer
        if (customerResponseData.vehicles && customerResponseData.vehicles.length > 0) {
          addedVehicle = customerResponseData.vehicles[0];
        }
      }
      
      // Check if we're using an existing customer with existing vehicle
      if (selectedCustomer && selectedCustomer.vehicles && selectedCustomer.vehicles.length > 0) {
        registrationTracker.startStep('vehicle_setup');
        // Try to find matching vehicle
        const existingVehicle = selectedCustomer.vehicles.find(v => 
          v.license_plate === vehicle.license_plate || 
          (v.vin && v.vin === vehicle.vin)
        );
        
        console.log("DEBUG: Existing customer vehicle search");
        console.log("  - License plate match:", vehicle.license_plate);
        console.log("  - VIN match:", vehicle.vin);
        console.log("  - Found existing vehicle:", existingVehicle);
        
        if (existingVehicle) {
          addedVehicle = existingVehicle;
          toast.success("Using existing vehicle");
        } else {
          // Add new vehicle to existing customer
          try {
            const vehicleData: any = {
              make: vehicle.make,
              model: vehicle.model,
              license_plate: vehicle.license_plate,
              vin: vehicle.vin || "", // Ensure vin is at least an empty string
              color: vehicle.color,
              vehicle_type: vehicle.vehicle_type
            };
            
            // Only include year if provided and valid
            if (vehicle.year && vehicle.year.trim()) {
              vehicleData.year = parseInt(vehicle.year);
            }
            // Don't include year field at all if empty
            
            console.log("DEBUG: Adding new vehicle to existing customer");
            console.log("  - Customer ID:", customerId);
            console.log("  - Vehicle data being sent:", JSON.stringify(vehicleData, null, 2));
            console.log("  - Vehicle VIN:", vehicleData.vin);
            console.log("  - Vehicle make:", vehicleData.make);
            console.log("  - Vehicle model:", vehicleData.model);
            console.log("  - Vehicle year field exists?", 'year' in vehicleData);
            console.log("  - Vehicle year value:", vehicleData.year);
            console.log("  - All vehicle keys:", Object.keys(vehicleData));
            
            setLoadingStatus("Adding vehicle to customer...");
            await api.post(`/api/customers/${customerId}/vehicles`, vehicleData);
            toast.success("Vehicle added successfully");
            
            // Get the updated customer to get the vehicle ID
            const updatedCustomerResponse = await api.get(`/api/customers/${customerId}`);
            console.log("DEBUG: Updated customer response:", updatedCustomerResponse);
            
            // Handle different response structures
            const updatedCustomer = updatedCustomerResponse.data || updatedCustomerResponse;
            console.log("DEBUG: Updated customer data:", updatedCustomer);
            
            if (updatedCustomer && updatedCustomer.vehicles && updatedCustomer.vehicles.length > 0) {
              addedVehicle = updatedCustomer.vehicles[updatedCustomer.vehicles.length - 1];
              console.log("DEBUG: Added vehicle:", addedVehicle);
            } else {
              console.warn("DEBUG: No vehicles found in updated customer data");
              // Fallback: use the vehicle data we just sent
              addedVehicle = { ...vehicleData, vehicle_id: Date.now() };
            }
          } catch (vehicleError) {
            const isAxiosErr = vehicleError && (vehicleError as any).response;
            if (isAxiosErr && (vehicleError as any).response?.data?.message?.includes("already exists")) {
              // Vehicle already exists, try to find it
              const updatedCustomerResponse = await api.get(`/api/customers/${customerId}`);
              console.log("DEBUG: Fallback customer response:", updatedCustomerResponse);
              
              // Handle different response structures
              const updatedCustomer = updatedCustomerResponse.data || updatedCustomerResponse;
              console.log("DEBUG: Fallback customer data:", updatedCustomer);
              
              if (updatedCustomer && updatedCustomer.vehicles) {
                const existingVehicle = updatedCustomer.vehicles.find((v: any) => 
                  v.license_plate === vehicle.license_plate || 
                  (v.vin && v.vin === vehicle.vin)
                );
                if (existingVehicle) {
                  addedVehicle = existingVehicle;
                  toast.success("Using existing vehicle");
                } else {
                  console.warn("DEBUG: Vehicle not found even after creation");
                  const tempVehicle: any = { 
                    make: vehicle.make,
                    model: vehicle.model,
                    license_plate: vehicle.license_plate,
                    vin: vehicle.vin || "",
                    color: vehicle.color,
                    vehicle_type: vehicle.vehicle_type,
                    vehicle_id: Date.now() 
                  };
                  if (vehicle.year && String(vehicle.year).trim()) {
                    tempVehicle.year = parseInt(String(vehicle.year));
                  }
                  // Don't include year field at all if empty
                  addedVehicle = tempVehicle;
                }
              } else {
                throw vehicleError;
              }
            } else {
              throw vehicleError;
            }
          }
        }
      } else if (!addedVehicle) {
        // This shouldn't happen since we now create customers with vehicles
        // But as a fallback, try to add the vehicle
        const vehicleData: any = {
          make: vehicle.make,
          model: vehicle.model,
          license_plate: vehicle.license_plate,
          vin: vehicle.vin || "",
          color: vehicle.color,
          vehicle_type: vehicle.vehicle_type
        };
        
        // Only include year if provided and valid
        if (vehicle.year && String(vehicle.year).trim()) {
          vehicleData.year = parseInt(String(vehicle.year));
        }
        // Don't include year field at all if empty
        
        console.log("DEBUG: Fallback vehicle addition");
        console.log("  - Customer ID:", customerId);
        console.log("  - Vehicle data being sent:", JSON.stringify(vehicleData, null, 2));
        console.log("  - Vehicle VIN:", vehicleData.vin);
        console.log("  - Vehicle make:", vehicleData.make);
        console.log("  - Vehicle model:", vehicleData.model);
        console.log("  - Vehicle year field exists?", 'year' in vehicleData);
        console.log("  - Vehicle year value:", vehicleData.year);
        console.log("  - All vehicle keys:", Object.keys(vehicleData));
        
        await api.post(`/api/customers/${customerId}/vehicles`, vehicleData);
        toast.success("Vehicle added successfully");
        
        // Get the updated customer to get the vehicle ID
        const updatedCustomerResponse = await api.get(`/api/customers/${customerId}`);
        const updatedCustomer = updatedCustomerResponse.data;
        addedVehicle = updatedCustomer.vehicles[updatedCustomer.vehicles.length - 1];
      }
      
      if (!addedVehicle || !addedVehicle.vehicle_id) {
        throw new Error("Failed to get vehicle ID");
      }
      
      // Generate work order number (you might want to get this from the API instead)
      const workOrderNumber = `WO-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
      
      // Create work order first (without invoice_id)
      const workOrderData = {
        work_order_number: workOrderNumber, // Fixed: backend expects work_order_number not workOrderNumber
        customer_id: customerId,
        vehicle_id: addedVehicle.vehicle_id,
        status: "open", // Using valid status value
        description: repair.notes || "General Service",
        createdAt: new Date(),
        // Include parts with proper structure according to MongoDB schema
        parts: repair.parts_with_services.map(part => ({
          partName: part.part_name,
          variationId: part.variation_id, // This should be an ObjectId from variations collection
          status: 'pending',
          assignedTo: repair.assigned_technician || undefined,
          createdAt: new Date()
          // Note: stages will be populated by the API based on the variation's defaultStages
        }))
      };
      
      console.log("Creating work order first:", JSON.stringify(workOrderData, null, 2));
      
      // Log variation IDs to debug
      console.log("Parts with variation IDs:", repair.parts_with_services.map(p => ({
        part: p.part_name,
        variation_id: p.variation_id,
        service_type: p.service_type
      })));
      
      // Debug: Check if variation IDs are valid MongoDB ObjectIds
      console.log("Variation ID validation:");
      repair.parts_with_services.forEach((part, index) => {
        console.log(`Part ${index + 1}: ${part.part_name}`);
        console.log(`  - Variation ID: ${part.variation_id}`);
        console.log(`  - Is valid ObjectId format: ${/^[0-9a-fA-F]{24}$/.test(part.variation_id)}`);
      });
      
      let workOrderId: string;
      try {
        registrationTracker.completeStep('vehicle_setup');
        registrationTracker.startStep('work_order_creation');
        const workOrderResult = await api.post("/api/work-orders", workOrderData);
        console.log("Work order created successfully:", workOrderResult);
        
        // Check if the response has a nested data structure
        const workOrderResponseData = workOrderResult.data || workOrderResult;
        if (!workOrderResponseData || !workOrderResponseData._id) {
          console.error("Invalid work order response:", workOrderResult);
          throw new Error("Invalid response from work order creation - missing _id");
        }
        
        workOrderId = workOrderResponseData._id;
        registrationTracker.completeStep('work_order_creation');
        toast.success("Work order created successfully");
        
        // Send notification to assigned supervisor
        try {
          if (repair.assigned_technician) {
            const notificationData = {
              type: "assignment",
              title: "New Work Order Assignment",
              message: `New work order #${workOrderNumber} has been created and assigned to you for customer ${customer.first_name} ${customer.last_name}`,
              workOrderId: workOrderId,
              recipientId: repair.assigned_technician,
              recipientType: "supervisor",
              priority: "high"
            };
            
            await api.post('/api/notifications', notificationData);
            console.log('Supervisor notification sent successfully');
          }
        } catch (notificationError) {
          console.error('Failed to send supervisor notification:', notificationError);
          // Don't throw - notification failure shouldn't break the registration process
        }
      } catch (workOrderError) {
        handleError(workOrderError, "Creating Work Order");
        throw workOrderError;
      }
      
      // Now create the invoice with work_order_id using FormData for image upload
      registrationTracker.startStep('invoice_preparation');
      console.log('Starting invoice creation process...');
      const formData = new FormData();
      
      // Add all required invoice fields
      formData.append('customer_id', customerId);
      formData.append('branch_id', customer.branch?.branch_id || '');
      formData.append('vehicle_id', addedVehicle.vehicle_id.toString());
      formData.append('invoice_date', new Date().toISOString().split('T')[0]);
      formData.append('price', repair.price);
      formData.append('vat', repair.with_tax ? '5' : '0');
      formData.append('isTaxed', repair.with_tax ? 'true' : 'false');
      formData.append('non_taxable', repair.with_tax ? 'false' : 'true');
      
      // Optional fields
      if (workOrderId) formData.append('work_order_id', workOrderId);
      if (repair.supervisor_expected_delivery_date) formData.append('expected_delivery_date', repair.supervisor_expected_delivery_date);
      if (repair.supervisor_ratio) formData.append('ratio', repair.supervisor_ratio);
      if (repair.presented_service_type) formData.append('presented_service_type', repair.presented_service_type);
      if (repair.notes) formData.append('notes', repair.notes);
      
      // Note: Down payment will be added as a separate payment record after invoice creation
      
      // Add the vehicle images if they exist
      if (vehicleImages.length > 0) {
        vehicleImages.forEach((image) => {
          formData.append('images', image);
        });
        formData.append('image_count', vehicleImages.length.toString());
      }
      
      let invoiceId: string;
      let progressInterval: NodeJS.Timeout | undefined;
      try {
        registrationTracker.completeStep('invoice_preparation');
        registrationTracker.startStep('file_upload');

        // Use axios with FormData - axios will automatically set the correct Content-Type
        console.log('About to send invoice creation request with timeout: 120000ms');
        console.log('FormData keys:', Array.from(formData.keys()));

        // Add progress tracking for long operations
        let progressCounter = 0;
        
        const invoiceResponse = await api.post('/api/invoices', formData, {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
          timeout: 120000, // 2 minutes timeout for file uploads
        });
        
        registrationTracker.completeStep('file_upload');

        console.log("Invoice creation response:", invoiceResponse);

        // With api.ts wrapper, the response data is already extracted
        if (!invoiceResponse || !invoiceResponse._id) {
          console.error("Invalid invoice response:", invoiceResponse);
          throw new Error("Invalid response from invoice creation - missing _id");
        }

        invoiceId = invoiceResponse._id;
        toast.success("Invoice created successfully with image");
      } catch (invoiceError) {
        // Clear the progress interval on error
        if (progressInterval) clearInterval(progressInterval);
        console.error('Invoice creation failed:', invoiceError);
        
        // Check if it's a timeout error
        if (invoiceError.code === 'ECONNABORTED' && invoiceError.message.includes('timeout')) {
          // For timeout errors, provide more specific guidance
          const timeoutError = {
            ...invoiceError,
            message: 'The request timed out while creating the invoice. This might be due to:\n' +
                    '• Large image file taking time to upload\n' +
                    '• Backend server being slow or overloaded\n' +
                    '• Network connectivity issues\n\n' +
                    'Please try again with a smaller image or check with your system administrator.',
            stage: 'Creating Invoice - Timeout'
          };
          handleError(timeoutError, "Creating Invoice - Timeout");
        } else {
          handleError(invoiceError, "Creating Invoice");
        }
        
        // If invoice creation fails, we should probably delete the work order
        // but for now just throw the error
        throw invoiceError;
      }
      
      // Update work order with invoice_id
      try {
        await api.put(`/api/work-orders/${workOrderId}`, {
          invoice_id: invoiceId
        });
        console.log("Work order updated with invoice ID");
      } catch (updateError) {
        console.error("Failed to update work order with invoice ID:", updateError);
        // This is not critical, so we don't throw
      }
      
      // Add down payment as a payment record if there's a down payment amount
      if (parseFloat(repair.down_payment) > 0) {
        registrationTracker.startStep('payment_setup');
        try {
          const paymentData = {
            payment_date: new Date().toISOString().split('T')[0],
            amount: parseFloat(repair.down_payment),
            payment_method: repair.payment_method,
            is_downpayment: true,
            notes: "Initial down payment"
          };
          
          await api.post(`/api/invoices/${invoiceId}/payments`, paymentData);
          console.log("Down payment added successfully:", paymentData);
          toast.success("Down payment recorded successfully");
        } catch (paymentError) {
          handleError(paymentError, "Recording Down Payment");
          // This is not critical enough to fail the entire registration
          toast.warning("Registration created but failed to record down payment. Please add it manually.");
        }
      } else {
        registrationTracker.startStep('payment_setup');
        await new Promise(resolve => setTimeout(resolve, 500));
      }

      registrationTracker.completeStep('payment_setup');
      registrationTracker.startStep('finalization');

      // Success - redirect to work order page
      await new Promise(resolve => setTimeout(resolve, 800));
      registrationTracker.completeStep('finalization');

      toast.success("Registration completed successfully!");
      router.push(`/workOrders/${workOrderId}`);
      
    } catch (error) {
      // Handle progress tracker error
      registrationTracker.failStep(
        registrationTracker.currentStep?.id || 'unknown',
        error instanceof Error ? error.message : 'Registration failed'
      );

      // Use the visual error handler to display error details
      const errorInfo = handleError(error, "Form Submission");

      // Add form data to error details for debugging
      errorInfo.formData = {
        customer: customer,
        vehicle: vehicle,
        repair: repair,
        hasImages: vehicleImages.length
      };

      // Update error details with the additional form data
      setErrorDetails(errorInfo);
    } finally {
      setIsSubmitting(false);
      setIsCreatingWorkOrder(false);
    }
  };

  // Handle printing quotation only
  const handlePrintQuotation = async () => {
    console.log('=== QUOTATION GENERATION STARTED ===');
    console.log('Starting quotation generation with data:', {
      customer: selectedCustomer || customer,
      vehicle: vehicle,
      repair: repair,
      registrationType: registrationType
    });

    setIsPrintingQuotation(true);
    quotationTracker.start();

    try {
      // Step 1: Prepare quotation data
      quotationTracker.startStep('prepare_data');
      console.log('Step 1: Preparing quotation data...');

      // Simulate preparation delay (like invoice does)
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Format customer info with name field
      const customerInfo = selectedCustomer || customer;
      const formattedCustomerInfo = {
        ...customerInfo,
        name: customerInfo.first_name && customerInfo.last_name
          ? `${customerInfo.first_name} ${customerInfo.last_name}`
          : customerInfo.first_name || customerInfo.last_name || ''
      };

      const quotationData = {
        customer_info: formattedCustomerInfo,
        vehicle_info: vehicle,
        price: parseFloat(repair.price),
        with_tax: repair.with_tax,
        presented_service_type: repair.presented_service_type,
        notes: repair.notes,
        expected_delivery_date: repair.supervisor_expected_delivery_date,
        ratio: repair.supervisor_ratio,
        branch_info: selectedCustomer?.branch || null,
        car_type: vehicle.make && vehicle.model ? `${vehicle.make} ${vehicle.model}` : vehicle.make || vehicle.model || '',
        license_plate: vehicle.license_plate,
        parts_with_services: repair.parts_with_services || [],
        external_services: repair.external_services || [] // Include external services if any
      };

      console.log('Quotation data prepared:', JSON.stringify(quotationData, null, 2));
      quotationTracker.completeStep('prepare_data');

      // Step 2: Generate PDF
      quotationTracker.startStep('generate_pdf');
      console.log('Step 2: Generating PDF from API...');

      // Choose the appropriate endpoint based on tax status
      const endpoint = repair.with_tax ? '/api/invoices/quotation-pdf' : '/api/invoices/quotation-carjob-pdf';
      console.log('Using endpoint:', endpoint);

      // For PDF generation, we need to use axios directly (not the api wrapper) to get the blob response
      const response = await axios.post(
        `${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000'}${endpoint}`,
        quotationData,
        {
          responseType: 'blob',
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('authToken')}`,
            'Content-Type': 'application/json',
          }
        }
      );

      console.log('API Response received:', {
        hasData: !!response.data,
        dataType: response.data?.type,
        dataSize: response.data?.size
      });

      quotationTracker.completeStep('generate_pdf');

      if (response.data) {
        // Step 3: Finalize and download PDF
        quotationTracker.startStep('finalize');
        console.log('Step 3: Finalizing and downloading PDF...');

        // Simulate processing delay
        await new Promise(resolve => setTimeout(resolve, 800));

        // Create a blob URL for download
        const blob = new Blob([response.data], { type: 'application/pdf' });
        const url = window.URL.createObjectURL(blob);
        console.log('Blob URL created:', url);

        // Create a download link (like invoice does)
        const link = document.createElement('a');
        link.href = url;
        link.download = `quotation-${Date.now()}.pdf`;
        document.body.appendChild(link);
        link.click();

        console.log('Download triggered for quotation PDF');

        // Clean up
        document.body.removeChild(link);

        // Clean up URL after delay
        setTimeout(() => {
          window.URL.revokeObjectURL(url);
          console.log('Blob URL cleaned up');
        }, 1000);

        // Wait a bit before completing
        await new Promise(resolve => setTimeout(resolve, 500));
        quotationTracker.completeStep('finalize');

        console.log('=== QUOTATION GENERATION COMPLETED SUCCESSFULLY ===');
        toast.success('Quotation PDF downloaded successfully!');

        // Reset after a short delay to show completion
        setTimeout(() => {
          quotationTracker.reset();
          setIsPrintingQuotation(false);
        }, 1500);
      } else {
        throw new Error('No PDF data received from server');
      }
    } catch (error: any) {
      console.error('=== QUOTATION GENERATION FAILED ===');
      console.error('Error details:', error);
      console.error('Error response:', error.response);
      console.error('Error message:', error.message);

      const errorMessage = error.response?.data?.message || error.message || 'Failed to generate quotation';

      if (quotationTracker.currentStep) {
        quotationTracker.failStep(quotationTracker.currentStep.id, errorMessage);
      }

      toast.error(`Failed to generate quotation: ${errorMessage}`);

      // Reset after showing error
      setTimeout(() => {
        quotationTracker.reset();
        setIsPrintingQuotation(false);
      }, 3000);
    }
  };

  return (
      <div className={`p-4 md:p-6 lg:p-8 bg-gray-100 min-h-screen ${isRTL ? 'rtl' : 'ltr'}`}>
        {/* Language Selector */}
        <div className={`flex ${isRTL ? 'justify-start' : 'justify-end'} mb-4`}>
          <div className="flex items-center gap-2 bg-white px-4 py-2 rounded-lg shadow-sm">
            <span className="text-sm font-medium text-gray-700">{t('language')}:</span>
            <button
              onClick={() => setLanguage('en')}
              className={`px-3 py-1 rounded ${language === 'en' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-700'}`}
            >
              English
            </button>
            <button
              onClick={() => setLanguage('ar')}
              className={`px-3 py-1 rounded ${language === 'ar' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-700'}`}
            >
              العربية
            </button>
          </div>
        </div>
        
        {/* Registration Progress Loader */}
        <ProgressLoader
          isVisible={registrationTracker.isActive}
          currentStep={registrationTracker.currentStep}
          steps={registrationTracker.steps}
          totalPercentage={registrationTracker.totalPercentage}
          elapsedTime={registrationTracker.elapsedTime}
          estimatedTimeRemaining={registrationTracker.estimatedTimeRemaining}
          title="Processing Registration"
          subtitle="Creating customer profile and vehicle registration"
          error={registrationTracker.error}
        />

        {/* Quotation Generation Progress Loader */}
        <ProgressLoader
          isVisible={quotationTracker.isActive}
          currentStep={quotationTracker.currentStep}
          steps={quotationTracker.steps}
          totalPercentage={quotationTracker.totalPercentage}
          elapsedTime={quotationTracker.elapsedTime}
          estimatedTimeRemaining={quotationTracker.estimatedTimeRemaining}
          title="Generating Quotation"
          subtitle="Creating your quotation PDF document"
          error={quotationTracker.error}
        />
        
        {/* Error Details Modal */}
        {showErrorModal && errorDetails && (
          <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-[100] p-4">
            <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-hidden">
              {/* Error Header */}
              <div className="bg-red-600 text-white p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <h2 className="text-2xl font-bold mb-2">❌ Error Occurred</h2>
                    <p className="text-red-100">{errorDetails.message}</p>
                    {errorDetails.stage && (
                      <p className="text-sm text-red-200 mt-2">
                        Stage: {errorDetails.stage}
                      </p>
                    )}
                    {errorDetails.timestamp && (
                      <p className="text-xs text-red-200 mt-1">
                        Time: {new Date(errorDetails.timestamp).toLocaleString()}
                      </p>
                    )}
                  </div>
                  <button
                    onClick={() => setShowErrorModal(false)}
                    className="text-white hover:text-red-200 text-2xl leading-none"
                  >
                    ×
                  </button>
                </div>
              </div>
              
              {/* Error Details Body */}
              <div className="p-6 overflow-y-auto max-h-[60vh]">
                {/* Quick Actions */}
                <div className="mb-6 flex gap-3">
                  <button
                    onClick={() => {
                      const errorText = JSON.stringify(errorDetails, null, 2);
                      navigator.clipboard.writeText(errorText);
                      toast.success("Error details copied to clipboard!");
                    }}
                    className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded text-sm"
                  >
                    📋 Copy Error Details
                  </button>
                  <button
                    onClick={() => {
                      setShowErrorModal(false);
                      setErrorDetails(null);
                    }}
                    className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded text-sm"
                  >
                    Clear & Close
                  </button>
                </div>
                
                {/* Validation Errors (if any) */}
                {errorDetails.validationErrors && (
                  <div className="mb-6">
                    <h3 className="font-bold text-red-700 mb-3">Validation Errors:</h3>
                    <div className="bg-red-50 border border-red-200 rounded p-4">
                      <pre className="text-xs overflow-x-auto text-red-800">
                        {JSON.stringify(errorDetails.validationErrors, null, 2)}
                      </pre>
                    </div>
                  </div>
                )}
                
                {/* Error Details */}
                {errorDetails.details && (
                  <div className="mb-6">
                    <h3 className="font-bold text-gray-700 mb-3">Technical Details:</h3>
                    <div className="space-y-3">
                      {errorDetails.details.status && (
                        <div className="bg-gray-50 border border-gray-200 rounded p-3">
                          <span className="font-semibold text-sm">HTTP Status:</span>
                          <span className="ml-2 text-sm">{errorDetails.details.status} - {errorDetails.details.statusText}</span>
                        </div>
                      )}
                      
                      {errorDetails.details.url && (
                        <div className="bg-gray-50 border border-gray-200 rounded p-3">
                          <span className="font-semibold text-sm">API Endpoint:</span>
                          <span className="ml-2 text-sm font-mono">{errorDetails.details.method} {errorDetails.details.url}</span>
                        </div>
                      )}
                      
                      {errorDetails.details.data && (
                        <div className="bg-gray-50 border border-gray-200 rounded p-3">
                          <p className="font-semibold text-sm mb-2">Server Response:</p>
                          <pre className="text-xs overflow-x-auto bg-white p-2 rounded border">
                            {JSON.stringify(errorDetails.details.data, null, 2)}
                          </pre>
                        </div>
                      )}
                      
                      {errorDetails.details.requestData && (
                        <div className="bg-gray-50 border border-gray-200 rounded p-3">
                          <p className="font-semibold text-sm mb-2">Request Data:</p>
                          <pre className="text-xs overflow-x-auto bg-white p-2 rounded border max-h-40">
                            {typeof errorDetails.details.requestData === 'string' 
                              ? errorDetails.details.requestData 
                              : JSON.stringify(errorDetails.details.requestData, null, 2)}
                          </pre>
                        </div>
                      )}
                      
                      {errorDetails.details.stack && (
                        <div className="bg-gray-50 border border-gray-200 rounded p-3">
                          <p className="font-semibold text-sm mb-2">Stack Trace:</p>
                          <pre className="text-xs overflow-x-auto bg-white p-2 rounded border max-h-40 text-red-600">
                            {errorDetails.details.stack}
                          </pre>
                        </div>
                      )}
                    </div>
                  </div>
                )}
                
                {/* Form Data (if available) */}
                {errorDetails.formData && (
                  <div className="mb-6">
                    <h3 className="font-bold text-gray-700 mb-3">Form Data at Error:</h3>
                    <div className="bg-blue-50 border border-blue-200 rounded p-4">
                      <pre className="text-xs overflow-x-auto">
                        {JSON.stringify(errorDetails.formData, null, 2)}
                      </pre>
                    </div>
                  </div>
                )}
                
                {/* Raw Error Object */}
                <details className="mb-6">
                  <summary className="font-bold text-gray-700 cursor-pointer hover:text-gray-900">
                    Full Error Object (Advanced)
                  </summary>
                  <div className="mt-3 bg-gray-50 border border-gray-200 rounded p-4">
                    <pre className="text-xs overflow-x-auto">
                      {JSON.stringify(errorDetails, null, 2)}
                    </pre>
                  </div>
                </details>
              </div>
              
              {/* Error Footer */}
              <div className="bg-gray-100 px-6 py-4 border-t">
                <p className="text-sm text-gray-600">
                  💡 <strong>Tip:</strong> Copy these error details and share them with your developer for faster debugging.
                </p>
              </div>
            </div>
          </div>
        )}
        
        <div className="max-w-7xl mx-auto">
          <h1 className="text-2xl md:text-3xl font-bold mb-6 text-gray-900">Register New Vehicle</h1>
          
          {/* Step indicators - Enhanced for desktop */}
          <div className="flex mb-8">
            <div className={`flex-1 p-3 md:p-4 text-center transition-all duration-200 ${
              currentStep === 1 
                ? "bg-blue-500 text-white shadow-lg" 
                : "bg-gray-200 text-gray-700 hover:bg-gray-300"
            } rounded-l-lg border-r border-gray-300`}>
              <div className="flex items-center justify-center gap-2">
                <span className={`w-6 h-6 rounded-full flex items-center justify-center text-sm font-bold ${
                  currentStep === 1 ? "bg-white text-blue-500" : "bg-gray-400 text-white"
                }`}>1</span>
                <span className="font-medium">Vehicle & Client Information</span>
              </div>
            </div>
            <div className={`flex-1 p-3 md:p-4 text-center transition-all duration-200 ${
              currentStep === 2 
                ? "bg-blue-500 text-white shadow-lg" 
                : "bg-gray-200 text-gray-700 hover:bg-gray-300"
            } rounded-r-lg`}>
              <div className="flex items-center justify-center gap-2">
                <span className={`w-6 h-6 rounded-full flex items-center justify-center text-sm font-bold ${
                  currentStep === 2 ? "bg-white text-blue-500" : "bg-gray-400 text-white"
                }`}>2</span>
                <span className="font-medium">Repair Details</span>
              </div>
            </div>
          </div>
        
          {/* Step 1 Component */}
          {currentStep === 1 && (
            <StepOne
              customer={customer}
              vehicle={vehicle}
              imagePreviews={imagePreviews}
              vehicleImages={vehicleImages}
              registrationType={registrationType}
              handleCustomerChange={handleCustomerChange}
              handleVehicleChange={handleVehicleChange}
              handleMakeSelect={handleMakeSelect}
              handleRegionSelect={handleRegionSelect}
              handleImageChange={handleImageChange}
              handleRemoveImage={handleRemoveImage}
              selectExistingCustomer={selectExistingCustomer}
              handleNextStep={handleNextStep}
              updateCustomerData={updateCustomerData}
              setRegistrationType={setRegistrationType}
            />
          )}
          
          {/* Step 2 Component */}
          {currentStep === 2 && (
            <StepTwo
              repair={repair}
              variations={variations}
              technicians={technicians}
              selectedTechnician={selectedTechnician}
              handleRepairChange={handleRepairChange}
              handleTechnicianChange={handleTechnicianChange}
              calculateTotal={calculateTotal}
              handlePreviousStep={handlePreviousStep}
              handleSubmit={handleSubmit}
              isSubmitting={isSubmitting}
              isLoadingVariations={isLoadingVariations}
              isLoadingTechnicians={isLoadingTechnicians}
              useBasicValidation={registrationType === 'quotation'}
              buttonText={registrationType === 'quotation' ? 'Generate Quotation PDF →' : 'Create Work Order →'}
            />
          )}
        </div>

      </div>
  );
}

export default function NewRegistrationPage() {
  return (
    <LanguageProvider>
      <NewRegistrationContent />
    </LanguageProvider>
  );
}