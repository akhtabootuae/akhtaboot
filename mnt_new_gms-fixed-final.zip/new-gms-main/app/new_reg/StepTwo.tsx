import React, { useState, useEffect } from "react";
import api from "@/services/api";
import { Card } from "@/app/components/ui/card";
import { Button } from "@/app/components/ui/button";
import { Input } from "@/app/components/ui/input";
import { Textarea } from "@/app/components/ui/textarea";
import { PAYMENT_METHODS } from "@/app/types/expense";
import AddServiceTypeModal from "./AddServiceTypeModal";
import ViewServiceTypesModal from "./ViewServiceTypesModal";
import ServiceTypeDetailsModal from "./ServiceTypeDetailsModal";
import type { PartWithService } from "./page";
import { useLanguage } from "@/app/context/LanguageContext";

interface RepairDetails {
  variation_id: string;
  service_type: string;
  presented_service_type: string;
  notes: string;
  price: string;
  supervisor_ratio: string;
  supervisor_expected_delivery_date: string;
  assigned_technician: string;
  down_payment: string;
  payment_status: string;
  payment_method: string;
  selected_parts: string[];
  parts_with_services: PartWithService[];
  with_tax: boolean;
}

interface Variation {
  _id: string;
  code: string;
  description: string;
  defaultLaborHours: number;
  defaultStages: string[];
  created_at?: string;
  updated_at?: string;
}

interface Technician {
  _id: string;
  name: string;
  email?: string;
  role?: string;
}

interface StepTwoProps {
  repair: RepairDetails;
  variations: Variation[];
  technicians: Technician[];
  selectedTechnician: string;
  handleRepairChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement> | { target: { name: string; value: string | string[] | PartWithService[] } }) => void;
  handleTechnicianChange: (technicianId: string) => void;
  calculateTotal: () => string;
  handlePreviousStep: () => void;
  handleSubmit: () => void;
  isSubmitting: boolean;
  isLoadingVariations: boolean;
  isLoadingTechnicians: boolean;
  useBasicValidation?: boolean; // New prop to control validation type
  buttonText?: string; // Custom button text based on registration type
}

// Default car parts list (fallback if API fails)
const defaultCarParts = [
  { id: "front_bumper", name: "Front Bumper", category: "Exterior" },
  { id: "rear_bumper", name: "Rear Bumper", category: "Exterior" },
  { id: "left_front_door", name: "Left Front Door", category: "Exterior" },
  { id: "right_front_door", name: "Right Front Door", category: "Exterior" },
  { id: "left_rear_door", name: "Left Rear Door", category: "Exterior" },
  { id: "right_rear_door", name: "Right Rear Door", category: "Exterior" },
  { id: "hood", name: "Hood", category: "Exterior" },
  { id: "trunk", name: "Trunk", category: "Exterior" },
  { id: "left_front_fender", name: "Left Front Fender", category: "Exterior" },
  { id: "right_front_fender", name: "Right Front Fender", category: "Exterior" },
  { id: "left_rear_fender", name: "Left Rear Fender", category: "Exterior" },
  { id: "right_rear_fender", name: "Right Rear Fender", category: "Exterior" },
  { id: "roof", name: "Roof", category: "Exterior" },
  { id: "windshield", name: "Windshield", category: "Glass" },
  { id: "rear_window", name: "Rear Window", category: "Glass" },
  { id: "left_front_window", name: "Left Front Window", category: "Glass" },
  { id: "right_front_window", name: "Right Front Window", category: "Glass" },
  { id: "left_rear_window", name: "Left Rear Window", category: "Glass" },
  { id: "right_rear_window", name: "Right Rear Window", category: "Glass" },
  { id: "engine", name: "Engine", category: "Mechanical" },
  { id: "transmission", name: "Transmission", category: "Mechanical" },
  { id: "suspension_front", name: "Front Suspension", category: "Mechanical" },
  { id: "suspension_rear", name: "Rear Suspension", category: "Mechanical" },
  { id: "brakes_front", name: "Front Brakes", category: "Mechanical" },
  { id: "brakes_rear", name: "Rear Brakes", category: "Mechanical" },
  { id: "exhaust", name: "Exhaust System", category: "Mechanical" },
  { id: "interior_seats", name: "Seats", category: "Interior" },
  { id: "interior_dashboard", name: "Dashboard", category: "Interior" },
  { id: "interior_carpet", name: "Carpet", category: "Interior" },
  { id: "interior_headliner", name: "Headliner", category: "Interior" },
];

interface CarPart {
  id?: string;
  _id?: string;
  name: string;
  category: string;
}

const StepTwo: React.FC<StepTwoProps> = ({
  repair,
  variations,
  technicians,
  selectedTechnician,
  handleRepairChange,
  handleTechnicianChange,
  calculateTotal,
  handlePreviousStep,
  handleSubmit,
  isSubmitting,
  isLoadingTechnicians,
  useBasicValidation = false,
  buttonText
}) => {
  const { t, isRTL } = useLanguage();
  const [showAddServiceModal, setShowAddServiceModal] = useState(false);
  const [showViewServiceModal, setShowViewServiceModal] = useState(false);
  const [showServiceDetailsModal, setShowServiceDetailsModal] = useState(false);
  const [selectedServiceForView, setSelectedServiceForView] = useState<Variation | null>(null);
  const [localVariations, setLocalVariations] = useState<Variation[]>(variations);
  const [formErrors, setFormErrors] = useState<{[key: string]: string}>({});
  const [attemptedSubmit, setAttemptedSubmit] = useState(false);
  const [partsWithServices, setPartsWithServices] = useState<PartWithService[]>(repair.parts_with_services || []);
  const [isPartsExpanded, setIsPartsExpanded] = useState(true); // Start expanded since it's required
  const [showPartSelector, setShowPartSelector] = useState(false);
  const [carParts, setCarParts] = useState<CarPart[]>(defaultCarParts);
  const [isLoadingCarParts, setIsLoadingCarParts] = useState(false);
  // Tax is always included - no need for state
  
  // Update partsWithServices when repair prop changes
  useEffect(() => {
    setPartsWithServices(repair.parts_with_services || []);
  }, [repair.parts_with_services]);
  
  // Update local variations when props change
  useEffect(() => {
    setLocalVariations(variations);
  }, [variations]);

  // Fetch car parts from API on component mount
  useEffect(() => {
    fetchCarParts();
  }, []);

  const fetchCarParts = async () => {
    try {
      setIsLoadingCarParts(true);
      const response = await api.get('/api/car-parts');
      if (response && Array.isArray(response)) {
        // Transform API response to match the component's expected format
        const transformedParts = response.map((part: any) => ({
          id: part._id || part.id,
          _id: part._id,
          name: part.name,
          category: part.category
        }));
        setCarParts(transformedParts.length > 0 ? transformedParts : defaultCarParts);
      } else {
        // If API fails or returns empty, use default parts
        setCarParts(defaultCarParts);
      }
    } catch (error) {
      console.error('Error fetching car parts:', error);
      // Fallback to default parts if API fails
      setCarParts(defaultCarParts);
    } finally {
      setIsLoadingCarParts(false);
    }
  };

  // Function to refresh variations
  const refreshVariations = async () => {
    try {
      console.log('=== REFRESH VARIATIONS STARTED ===');
      const response = await api.get("/api/variations");
      console.log('Refresh variations API response:', response);
      
      // Handle the API response structure safely
      let variationsData = [];
      if (response && response.success && Array.isArray(response.data)) {
        variationsData = response.data;
      } else if (Array.isArray(response)) {
        variationsData = response;
      } else if (response && Array.isArray(response.data)) {
        variationsData = response.data;
      } else if (response) {
        // Sometimes the response might be the data directly
        variationsData = response;
      }
      
      console.log('Setting local variations to:', variationsData);
      setLocalVariations(variationsData || []);
      console.log('=== REFRESH VARIATIONS COMPLETED ===');
      return variationsData || [];
    } catch (error) {
      console.error("Error refreshing variations:", error);
      console.log('=== REFRESH VARIATIONS FAILED ===');
      setLocalVariations([]); // Ensure we have a clean state
      return [];
    }
  };
  
  // Basic validation for quotations (minimal requirements)
  const validateBasicForm = () => {
    const errors: {[key: string]: string} = {};

    if (!repair.price || parseFloat(repair.price) <= 0) errors.price = "Price is required and must be greater than 0";
    if (!repair.presented_service_type || !repair.presented_service_type.trim()) errors.presented_service_type = "Presented Service Type is required";

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // Full validation for work orders (all fields required)
  const validateForm = () => {
    const errors: {[key: string]: string} = {};

    if (!selectedTechnician || !repair.assigned_technician) errors.assigned_technician = "Assigned supervisor is required";
    if (!repair.supervisor_expected_delivery_date) errors.supervisor_expected_delivery_date = "Supervisor expected delivery date is required";
    if (!repair.supervisor_ratio) errors.supervisor_ratio = "Supervisor quality ratio is required";
    if (!repair.price || parseFloat(repair.price) <= 0) errors.price = "Price is required and must be greater than 0";
    if (!repair.payment_method) errors.payment_method = "Payment method is required";
    if (!repair.presented_service_type || !repair.presented_service_type.trim()) errors.presented_service_type = "Presented Service Type is required";
    if (!repair.notes || !repair.notes.trim()) errors.notes = "Notes are required";
    if (!partsWithServices || partsWithServices.length === 0) errors.parts_with_services = "Please add at least one car part with service type";

    // Validate each part has a service type
    partsWithServices.forEach((part, index) => {
      if (!part.variation_id) {
        errors[`part_service_${index}`] = `Please select a service type for ${part.part_name}`;
      }
    });

    // Validate ratios are between 0 and 100
    if (repair.supervisor_ratio && (parseFloat(repair.supervisor_ratio) < 0 || parseFloat(repair.supervisor_ratio) > 100)) {
      errors.supervisor_ratio = "Supervisor ratio must be between 0 and 100";
    }

    // Validate down payment is not negative and doesn't exceed total
    if (repair.down_payment && parseFloat(repair.down_payment) < 0) {
      errors.down_payment = "Down payment cannot be negative";
    }

    if (repair.down_payment && parseFloat(repair.down_payment) > parseFloat(calculateTotal())) {
      errors.down_payment = "Down payment cannot exceed total amount";
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // Handle form submission with different validation types
  const validateAndSubmit = () => {
    console.log('validateAndSubmit called in StepTwo, useBasicValidation:', useBasicValidation);
    setAttemptedSubmit(true);

    // Use basic validation for quotations, full validation for work orders
    const isValid = useBasicValidation ? validateBasicForm() : validateForm();

    if (isValid) {
      console.log('Validation passed in StepTwo, calling handleSubmit');
      handleSubmit();
    } else {
      console.log('Validation failed in StepTwo');
      // Scroll to the first error
      const firstErrorField = document.querySelector('[data-error="true"]');
      if (firstErrorField) {
        firstErrorField.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }
  };

  return (
    <Card className="p-6 lg:p-8">
      <h2 className="text-xl lg:text-2xl font-bold mb-6 text-gray-900">{t('repairDetails')}</h2>
      
      {attemptedSubmit && Object.keys(formErrors).length > 0 && (
        <div className="mb-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative">
          <strong className="font-bold">Please correct the following errors:</strong>
          <ul className="mt-2 list-disc pl-5">
            {Object.values(formErrors).map((error, index) => (
              <li key={index}>{error}</li>
            ))}
          </ul>
        </div>
      )}
      
      {/* Assigned Technician - Keep at the top */}
      <div className="mb-6">
        <label htmlFor="assigned_technician" className="block text-sm font-medium mb-1 font-bold">Assigned Supervisor *</label>
        {isLoadingTechnicians ? (
          <div className="w-full p-2 border rounded bg-gray-100">Loading supervisors...</div>
        ) : (
          <select
            id="assigned_technician"
            name="assigned_technician"
            value={selectedTechnician || repair.assigned_technician || ""}
            onChange={(e) => {
              handleTechnicianChange(e.target.value);
              handleRepairChange({
                target: {
                  name: "assigned_technician",
                  value: e.target.value
                }
              } as React.ChangeEvent<HTMLSelectElement>);
            }}
            className={`w-full p-3 lg:p-4 border ${formErrors.assigned_technician && attemptedSubmit ? 'border-red-500' : 'border-gray-300'} rounded-lg bg-yellow-50 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all`}
            required
            data-error={!!formErrors.assigned_technician && attemptedSubmit}
          >
            <option value="">Select Supervisor</option>
            {technicians.map(tech => (
              <option key={tech._id} value={tech._id}>
                {tech.name}
              </option>
            ))}
          </select>
        )}
        {formErrors.assigned_technician && attemptedSubmit && (
          <p className="text-red-500 text-xs mt-1">{formErrors.assigned_technician}</p>
        )}
        <p className="text-xs text-gray-500 mt-1">Select the supervisor who will oversee the repair</p>
      </div>
      
      {/* Supervisor Box - Now full width */}
      <div className="mb-6">
        <div className="border rounded-lg p-4 bg-gray-50">
          <h3 className="text-lg font-bold mb-4 text-blue-600">Supervisor Information</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="supervisor_expected_delivery_date" className="block text-sm font-medium mb-1 font-bold">Expected Delivery Date *</label>
              <Input
                id="supervisor_expected_delivery_date"
                name="supervisor_expected_delivery_date"
                type="date"
                value={repair.supervisor_expected_delivery_date}
                onChange={handleRepairChange}
                min={new Date().toISOString().split('T')[0]}
                className={`bg-white border-blue-300 ${formErrors.supervisor_expected_delivery_date && attemptedSubmit ? 'border-red-500' : ''}`}
                required
                data-error={!!formErrors.supervisor_expected_delivery_date && attemptedSubmit}
              />
              {formErrors.supervisor_expected_delivery_date && attemptedSubmit && (
                <p className="text-red-500 text-xs mt-1">{formErrors.supervisor_expected_delivery_date}</p>
              )}
              <p className="text-xs text-blue-500 mt-1">When you expect the repair to be completed</p>
            </div>
            
            <div>
              <label htmlFor="supervisor_ratio" className="block text-sm font-medium mb-1">Quality Ratio (%) *</label>
              <Input
                id="supervisor_ratio"
                name="supervisor_ratio"
                type="number"
                min="0"
                max="100"
                step="1"
                value={repair.supervisor_ratio}
                onChange={(e) => {
                  const value = e.target.value;
                  const numValue = parseFloat(value);
                  
                  // Update the field value
                  handleRepairChange(e);
                  
                  // Check if value is above 100 and show error immediately
                  if (value && !isNaN(numValue) && numValue > 100) {
                    setFormErrors(prev => ({
                      ...prev,
                      supervisor_ratio: "Supervisor ratio cannot exceed 100%"
                    }));
                  } else if (value && !isNaN(numValue) && numValue < 0) {
                    setFormErrors(prev => ({
                      ...prev,
                      supervisor_ratio: "Supervisor ratio cannot be negative"
                    }));
                  } else {
                    // Clear the error if value is valid
                    setFormErrors(prev => {
                      const newErrors = { ...prev };
                      delete newErrors.supervisor_ratio;
                      return newErrors;
                    });
                  }
                }}
                className={`bg-white ${formErrors.supervisor_ratio ? 'border-red-500' : ''}`}
                required
                data-error={!!formErrors.supervisor_ratio}
              />
              {formErrors.supervisor_ratio && (
                <p className="text-red-500 text-xs mt-1">{formErrors.supervisor_ratio}</p>
              )}
              <p className="text-xs text-gray-500 mt-1">Expected level of perfection</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Car Parts and Service Types */}
      <div className="mb-6">
        <div className="border rounded-lg bg-gray-50">
          <div 
            className="p-4 cursor-pointer hover:bg-gray-100 transition-colors"
            onClick={() => setIsPartsExpanded(!isPartsExpanded)}
          >
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <h3 className="text-lg font-bold">Car Parts and Service Types *</h3>
                {partsWithServices.length > 0 && !isPartsExpanded && (
                  <p className="text-sm text-blue-600 mt-1">
                    {partsWithServices.length} part{partsWithServices.length > 1 ? 's' : ''} added
                  </p>
                )}
                {formErrors.parts_with_services && attemptedSubmit && !isPartsExpanded && (
                  <p className="text-red-500 text-sm mt-1">{formErrors.parts_with_services}</p>
                )}
              </div>
              <svg 
                className={`w-5 h-5 transition-transform ${isPartsExpanded ? 'rotate-180' : ''}`} 
                fill="none" 
                stroke="currentColor" 
                viewBox="0 0 24 24"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </div>
          </div>
          
          {isPartsExpanded && (
            <div className="px-4 pb-4 border-t border-gray-200">
              {formErrors.parts_with_services && attemptedSubmit && (
                <p className="text-red-500 text-sm mt-4 mb-2">{formErrors.parts_with_services}</p>
              )}
              <p className="text-sm text-gray-600 mt-4 mb-4">Add car parts and select the service type for each part. Each part will have its own sub-work order.</p>
              
              {/* Parts list */}
              <div className="space-y-2 mb-4">
                {partsWithServices.map((part, index) => (
                  <div key={index} className="flex items-center gap-2 p-2 bg-white rounded border">
                    <div className="flex-1">
                      <span className="font-medium">{part.part_name}</span>
                    </div>
                    <div className="flex-1 flex items-center gap-2">
                      <select
                        value={part.variation_id}
                        onChange={(e) => {
                          const updatedParts = [...partsWithServices];
                          const selectedVariation = localVariations.find(v => v._id === e.target.value);
                          updatedParts[index] = {
                            ...part,
                            variation_id: e.target.value,
                            service_type: selectedVariation ? selectedVariation.description : ''
                          };
                          setPartsWithServices(updatedParts);
                          handleRepairChange({
                            target: {
                              name: "parts_with_services",
                              value: updatedParts
                            }
                          });
                        }}
                        className={`flex-1 p-1 border ${formErrors[`part_service_${index}`] && attemptedSubmit ? 'border-red-500' : 'border-gray-300'} rounded text-sm`}
                        required
                      >
                        <option value="">Select Service Type *</option>
                        {localVariations.map(variation => (
                          <option key={variation._id} value={variation._id}>
                            {variation.code} - {variation.description}
                          </option>
                        ))}
                      </select>
                      {part.variation_id && (
                        <button
                          type="button"
                          onClick={() => {
                            const selectedVariation = localVariations.find(v => v._id === part.variation_id);
                            if (selectedVariation) {
                              setSelectedServiceForView(selectedVariation);
                              setShowServiceDetailsModal(true);
                            }
                          }}
                          className="text-green-600 hover:text-green-800 text-xs flex items-center gap-1 whitespace-nowrap"
                          title="View details for this service type"
                        >
                          <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                          </svg>
                          Info
                        </button>
                      )}
                      {formErrors[`part_service_${index}`] && attemptedSubmit && (
                        <p className="text-red-500 text-xs mt-1">{formErrors[`part_service_${index}`]}</p>
                      )}
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        const updatedParts = partsWithServices.filter((_, i) => i !== index);
                        setPartsWithServices(updatedParts);
                        handleRepairChange({
                          target: {
                            name: "parts_with_services",
                            value: updatedParts
                          }
                        });
                      }}
                      className="p-1 text-red-600 hover:bg-red-50 rounded"
                    >
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                  </div>
                ))}
              </div>
              
              {/* Add part button */}
              <div className="flex justify-between items-center">
                <button
                  type="button"
                  onClick={() => setShowPartSelector(true)}
                  className="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded flex items-center gap-2"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                  </svg>
                  Add Car Part
                </button>
                
                {partsWithServices.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setShowAddServiceModal(true)}
                    className="text-blue-600 hover:text-blue-800 text-sm flex items-center gap-1"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                    </svg>
                    {t('addNewServiceType')}
                  </button>
                )}
              </div>
              
              {partsWithServices.length > 0 && (
                <div className="mt-4">
                  <div className="p-3 bg-blue-50 rounded">
                    <p className="text-sm font-medium text-blue-800">
                      {partsWithServices.length} part{partsWithServices.length > 1 ? 's' : ''} added
                    </p>
                    <p className="text-xs text-blue-600 mt-1">
                      Each part will have its own sub-work order with the selected service type
                    </p>
                  </div>
                  {partsWithServices.some(p => !p.variation_id) && (
                    <div className="mt-2 p-3 bg-yellow-50 border border-yellow-200 rounded">
                      <p className="text-sm font-medium text-yellow-800">
                        ⚠️ Please select a service type for all parts
                      </p>
                      <p className="text-xs text-yellow-600 mt-1">
                        Parts without service types: {partsWithServices.filter(p => !p.variation_id).map(p => p.part_name).join(', ')}
                      </p>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
      
      {/* Part Selector Modal */}
      {showPartSelector && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-3xl w-full max-h-[80vh] overflow-hidden">
            <div className="p-6 border-b">
              <h2 className="text-xl font-bold">Select Car Part</h2>
              <p className="text-gray-600 mt-1">Choose a part to add to the work order</p>
            </div>
            <div className="p-6 overflow-y-auto max-h-[60vh]">
              {isLoadingCarParts ? (
                <div className="flex justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                </div>
              ) : (
                Object.entries(
                  carParts.reduce((acc, part) => {
                    if (!acc[part.category]) acc[part.category] = [];
                    acc[part.category].push(part);
                    return acc;
                  }, {} as Record<string, CarPart[]>)
                ).map(([category, parts]) => (
                <div key={category} className="mb-6">
                  <h4 className="font-medium text-gray-700 mb-3">{category}</h4>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                    {parts.map((part) => {
                      const partId = part.id || part._id || '';
                      const isAlreadyAdded = partsWithServices.some(p => p.part_id === partId);
                      return (
                        <button
                          key={partId}
                          type="button"
                          disabled={isAlreadyAdded}
                          onClick={() => {
                            const newPart: PartWithService = {
                              part_id: partId,
                              part_name: part.name,
                              variation_id: '',
                              service_type: ''
                            };
                            const updatedParts = [...partsWithServices, newPart];
                            setPartsWithServices(updatedParts);
                            handleRepairChange({
                              target: {
                                name: "parts_with_services",
                                value: updatedParts
                              }
                            });
                            setShowPartSelector(false);
                          }}
                          className={`p-3 text-left rounded border transition-colors ${
                            isAlreadyAdded 
                              ? 'bg-gray-100 text-gray-400 cursor-not-allowed' 
                              : 'hover:bg-blue-50 hover:border-blue-300'
                          }`}
                        >
                          {part.name}
                          {isAlreadyAdded && <span className="text-xs block mt-1">Already added</span>}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))
              )}
            </div>
            <div className="p-6 border-t flex justify-end">
              <button
                type="button"
                onClick={() => setShowPartSelector(false)}
                className="px-4 py-2 bg-gray-300 hover:bg-gray-400 text-gray-700 rounded"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Presented Service Type */}
      <div className="mb-6">
        <label htmlFor="presented_service_type" className="block text-sm font-medium mb-1">{t('serviceType')} *</label>
        <Input
          id="presented_service_type"
          name="presented_service_type"
          value={repair.presented_service_type}
          onChange={handleRepairChange}
          placeholder="Enter the service type that will appear on the invoice..."
          required
          className={`${formErrors.presented_service_type && attemptedSubmit ? 'border-red-500' : ''}`}
          data-error={!!formErrors.presented_service_type && attemptedSubmit}
        />
        {formErrors.presented_service_type && attemptedSubmit && (
          <p className="text-red-500 text-xs mt-1">{formErrors.presented_service_type}</p>
        )}
      </div>
      
      {/* Notes section (includes special requests) */}
      <div className="mb-6">
        <label htmlFor="notes" className="block text-sm font-medium mb-1">{t('notes')} *</label>
        <Textarea
          id="notes"
          name="notes"
          value={repair.notes}
          onChange={handleRepairChange}
          rows={4}
          placeholder="Add all notes and special requirements for this service..."
          required
          className={`${formErrors.notes && attemptedSubmit ? 'border-red-500' : ''}`}
          data-error={!!formErrors.notes && attemptedSubmit}
        />
        {formErrors.notes && attemptedSubmit && (
          <p className="text-red-500 text-xs mt-1">{formErrors.notes}</p>
        )}
      </div>
      
      {/* Financial information - MOVED TO BOTTOM */}
      <div className="mt-8 border-t pt-6">
        <h3 className="text-lg font-bold mb-4">Financial Information</h3>
                
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <div>
            <label htmlFor="price" className="block text-sm font-medium mb-1">{t('price')} (AED) *</label>
            <Input
              id="price"
              name="price"
              type="number"
              min="0"
              step="0.01"
              value={repair.price}
              onChange={handleRepairChange}
              required
              className={`${formErrors.price && attemptedSubmit ? 'border-red-500' : ''}`}
              data-error={!!formErrors.price && attemptedSubmit}
            />
            {formErrors.price && attemptedSubmit && (
              <p className="text-red-500 text-xs mt-1">{formErrors.price}</p>
            )}
          </div>
          
          <div>
            <label htmlFor="down_payment" className="block text-sm font-medium mb-1">Down Payment (AED) *</label>
            <Input
              id="down_payment"
              name="down_payment"
              type="number"
              min="0"
              max={calculateTotal()}
              step="0.01"
              value={repair.down_payment}
              onChange={handleRepairChange}
              required
              className={`${formErrors.down_payment && attemptedSubmit ? 'border-red-500' : ''}`}
              data-error={!!formErrors.down_payment && attemptedSubmit}
            />
            {formErrors.down_payment && attemptedSubmit && (
              <p className="text-red-500 text-xs mt-1">{formErrors.down_payment}</p>
            )}
            <p className="text-gray-600 text-xs mt-1">
              {parseFloat(repair.down_payment || "0") === 0 
                ? `Enter amount (max: ${calculateTotal()} AED) to auto-set payment status` 
                : parseFloat(repair.down_payment || "0") >= parseFloat(calculateTotal())
                ? "Full payment - Status: Paid"
                : "Partial payment - Status: Partial"
              }
            </p>
          </div>
          
          <div>
            <label htmlFor="vat_display" className="block text-sm font-medium mb-1">
              VAT (5%)
            </label>
            <Input
              id="vat_display"
              type="number"
              value={(parseFloat(repair.price || "0") * 0.05).toFixed(2)}
              disabled
              className="bg-gray-100"
            />
          </div>
          
          <div>
            <label htmlFor="total_display" className="block text-sm font-medium mb-1">Total Amount (AED)</label>
            <Input
              id="total_display"
              type="number"
              value={calculateTotal()}
              disabled
              className="bg-gray-100 font-bold"
            />
          </div>
          
          <div>
            <label htmlFor="payment_status" className="block text-sm font-medium mb-1">{t('paymentStatus')} *</label>
            <select
              id="payment_status"
              name="payment_status"
              value={repair.payment_status}
              disabled
              className="w-full p-2 border border-gray-300 rounded bg-gray-100 text-gray-700 cursor-not-allowed"
              required
            >
              <option value="">{t('selectPaymentStatus')}</option>
              <option value="Unpaid">{t('unpaid')}</option>
              <option value="Partial">{t('partial')}</option>
              <option value="Paid">{t('paid')}</option>
            </select>
            <p className="text-blue-600 text-xs mt-1 flex items-center">
              <svg className="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
              </svg>
              Auto-calculated based on down payment amount
            </p>
          </div>
          
          <div>
            <label htmlFor="payment_method" className="block text-sm font-medium mb-1">Payment Method *</label>
            <select
              id="payment_method"
              name="payment_method"
              value={repair.payment_method}
              onChange={handleRepairChange}
              className={`w-full p-2 border ${formErrors.payment_method && attemptedSubmit ? 'border-red-500' : 'border-gray-300'} rounded`}
              required
              data-error={!!formErrors.payment_method && attemptedSubmit}
            >
              <option value="">Select Payment Method</option>
              {PAYMENT_METHODS.map((method) => (
                <option key={method.value} value={method.value}>
                  {method.label}
                </option>
              ))}
            </select>
            {formErrors.payment_method && attemptedSubmit && (
              <p className="text-red-500 text-xs mt-1">{formErrors.payment_method}</p>
            )}
          </div>
        </div>
      </div>
      
      {/* Navigation Buttons */}
      <div className="flex flex-col sm:flex-row justify-between gap-4 mt-8 lg:mt-12">
        <Button 
          variant="outline" 
          onClick={handlePreviousStep}
          className="py-3 lg:py-4 px-6 lg:px-8 text-lg font-medium hover:bg-gray-50 transition-all duration-200"
        >
          ← {t('previous')}
        </Button>
        <Button 
          onClick={validateAndSubmit} 
          disabled={isSubmitting}
          className="bg-green-600 hover:bg-green-700 text-white py-3 lg:py-4 px-8 lg:px-12 text-lg font-bold shadow-lg hover:shadow-xl transition-all duration-200 transform hover:-translate-y-0.5"
        >
          {isSubmitting ? (
            <>
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              {t('loading')}
            </>
          ) : (
            buttonText || `${t('continue')} →`
          )}
        </Button>
      </div>

      {/* Add Service Type Modal */}
      {showAddServiceModal && (
        <AddServiceTypeModal 
          isOpen={showAddServiceModal}
          onClose={() => {
            try {
              console.log('=== Closing AddServiceTypeModal ===');
              setShowAddServiceModal(false);
              console.log('=== AddServiceTypeModal closed ===');
            } catch (error) {
              console.error('Error closing AddServiceTypeModal:', error);
              setShowAddServiceModal(false); // Force close
            }
          }}
          refreshVariations={refreshVariations}
          onServiceAdded={(newService) => {
            try {
              console.log('=== onServiceAdded callback started ===', newService);
              
              // Update the form with the selected service if needed
              handleRepairChange({
                target: {
                  name: "variation_id",
                  value: newService._id
                }
              } as React.ChangeEvent<HTMLSelectElement>);
              
              console.log('=== onServiceAdded callback completed ===');
            } catch (error) {
              console.error('Error in onServiceAdded callback:', error);
            }
          }}
        />
      )}

      {/* View Service Types Modal */}
      {showViewServiceModal && (
        <ViewServiceTypesModal 
          isOpen={showViewServiceModal}
          onClose={() => setShowViewServiceModal(false)}
          variations={localVariations}
          onServiceSelected={(selectedService) => {
            // Update the form with the selected service
            handleRepairChange({
              target: {
                name: "variation_id",
                value: selectedService._id
              }
            } as React.ChangeEvent<HTMLSelectElement>);
          }}
        />
      )}

      {/* Service Type Details Modal */}
      {showServiceDetailsModal && (
        <ServiceTypeDetailsModal 
          isOpen={showServiceDetailsModal}
          onClose={() => setShowServiceDetailsModal(false)}
          serviceType={selectedServiceForView}
        />
      )}
    </Card>
  );
};

export default StepTwo;