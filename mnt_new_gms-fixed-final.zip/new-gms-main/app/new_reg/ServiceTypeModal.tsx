import React, { useState, useEffect } from "react";
import api from "@/services/api";

interface ServiceTypeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onServiceAdded: (newService: { _id: string; code: string; description: string }) => void;
  variations?: Variation[];
  refreshVariations?: () => Promise<Variation[]>;
}

interface Stage {
  _id: string;
  name: string;
  description?: string;
  order: number;
  created_at?: string;
  updated_at?: string;
}

interface VariationStage {
  stage_id: string;
  stage_order: number;
  stage_name?: string;
}

interface Variation {
  _id: string;
  code: string;
  description: string;
  defaultLaborHours: number;
  defaultStages: string[];
  stages?: VariationStage[];
  created_at?: string;
  updated_at?: string;
}

type TabType = 'add' | 'view';

const ServiceTypeModal: React.FC<ServiceTypeModalProps> = ({ 
  isOpen, 
  onClose, 
  onServiceAdded,
  variations: propVariations,
  refreshVariations: propRefreshVariations
}) => {
  // Tab state
  const [activeTab, setActiveTab] = useState<TabType>('view');
  
  // Add new service type state
  const [serviceCode, setServiceCode] = useState("");
  const [serviceDescription, setServiceDescription] = useState("");
  const [laborHours, setLaborHours] = useState("1");
  const [selectedStages, setSelectedStages] = useState<string[]>([]);
  const [availableStages, setAvailableStages] = useState<Stage[]>([]);
  
  // View existing service types state
  const [variations, setVariations] = useState<Variation[]>([]);
  const [selectedVariation, setSelectedVariation] = useState<Variation | null>(null);
  
  // Shared state
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  // Fetch data when modal opens
  useEffect(() => {
    if (isOpen) {
      fetchAvailableStages();
      fetchVariations();
    }
  }, [isOpen]);

  // Fetch available stages for creating new service types
  const fetchAvailableStages = async () => {
    try {
      setIsLoading(true);
      setError(""); // Clear any previous errors
      console.log('Fetching available stages...');
      const response = await api.get("/api/stages");
      console.log('Stages API response:', response);
      
      // Handle the API response structure: { success: true, data: [...] }
      let stagesData = [];
      if (response && response.success && Array.isArray(response.data)) {
        stagesData = response.data;
      } else if (Array.isArray(response)) {
        // Fallback for direct array response
        stagesData = response;
      } else if (response && Array.isArray(response.data)) {
        // Handle { data: [...] } structure
        stagesData = response.data;
      }
      
      console.log('Processed stages data:', stagesData);
      setAvailableStages(stagesData);
      
      if (stagesData.length === 0) {
        setError('No stages found. Please configure stages first.');
      }
    } catch (error) {
      console.error("Error fetching stages:", error);
      setError("Failed to load available stages. Please try again.");
      setAvailableStages([]); // Ensure we have a clean state
    } finally {
      setIsLoading(false);
    }
  };

  // Fetch existing variations (service types)
  const fetchVariations = async () => {
    try {
      setIsLoading(true);
      if (propVariations) {
        setVariations(propVariations);
      } else {
        const response = await api.get("/api/variations");
        const variationsData = response || [];
        setVariations(Array.isArray(variationsData) ? variationsData : []);
      }
    } catch (error) {
      console.error("Error fetching variations:", error);
      setError("Failed to load existing service types. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  // Fetch variation details with stages
  const fetchVariationDetails = async (variationId: string) => {
    try {
      setIsLoading(true);
      const response = await api.get(`/api/variations/${variationId}?include=stages`);
      
      // Process the stages for display
      if (response && response.defaultStages) {
        const stageDetails = await Promise.all(
          response.defaultStages.map(async (stageId: string) => {
            try {
              const stageResponse = await api.get(`/api/stages/${stageId}`);
              return {
                stage_id: stageId,
                stage_name: stageResponse.name,
                stage_order: stageResponse.order || 0
              };
            } catch (error) {
              console.error(`Error fetching stage ${stageId}:`, error);
              return {
                stage_id: stageId,
                stage_name: `Stage ${stageId}`,
                stage_order: 0
              };
            }
          })
        );
        
        response.stages = stageDetails.sort((a, b) => a.stage_order - b.stage_order);
      }
      
      setSelectedVariation(response);
    } catch (error) {
      console.error("Error fetching variation details:", error);
      setError("Failed to load service type details. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  // Handler for adding a stage to new service type
  const handleAddStage = () => {
    console.log('handleAddStage called');
    console.log('Available stages:', availableStages);
    console.log('Selected stages:', selectedStages);
    
    if (availableStages.length === 0) {
      console.log('No available stages');
      setError('No stages available. Please ensure stages are properly configured.');
      return;
    }
    
    // Add the first available stage that's not already selected
    const unselectedStage = availableStages.find(stage => !selectedStages.includes(stage._id));
    console.log('Unselected stage found:', unselectedStage);
    
    if (unselectedStage) {
      const newSelectedStages = [...selectedStages, unselectedStage._id];
      console.log('Setting new selected stages:', newSelectedStages);
      setSelectedStages(newSelectedStages);
    } else {
      console.log('All stages already selected');
      setError('All available stages have been added.');
    }
  };

  // Handler for removing a stage from new service type
  const handleRemoveStage = (stageId: string) => {
    setSelectedStages(selectedStages.filter(id => id !== stageId));
  };

  // Handler for changing stage in new service type
  const handleStageChange = (index: number, stageId: string) => {
    const updatedStages = [...selectedStages];
    updatedStages[index] = stageId;
    setSelectedStages(updatedStages);
  };

  // Handler for creating new service type
  const handleSubmit = async () => {
    if (!serviceCode.trim()) {
      setError("Service code is required");
      return;
    }

    if (!serviceDescription.trim()) {
      setError("Service description is required");
      return;
    }

    if (selectedStages.length === 0) {
      setError("At least one stage must be added");
      return;
    }

    if (!laborHours || parseFloat(laborHours) <= 0) {
      setError("Labor hours must be greater than 0");
      return;
    }

    setIsLoading(true);
    setError("");

    try {
      const response = await api.post("/api/variations", {
        code: serviceCode,
        description: serviceDescription,
        defaultLaborHours: parseFloat(laborHours),
        defaultStages: selectedStages
      });

      if (response) {
        onServiceAdded({
          _id: response._id,
          code: serviceCode,
          description: serviceDescription
        });
        
        // Reset form and refresh data
        setServiceCode("");
        setServiceDescription("");
        setLaborHours("1");
        setSelectedStages([]);
        
        if (propRefreshVariations) {
          const refreshedVariations = await propRefreshVariations();
          setVariations(refreshedVariations);
        } else {
          fetchVariations();
        }
        
        setActiveTab('view'); // Switch to view tab to show the newly created service
      }
    } catch (error: any) {
      console.error("Error creating service type:", error);
      setError(error.response?.message || "Failed to create service type. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  // Function to get stage name by ID
  const getStageName = (stageId: string): string => {
    const stage = availableStages.find(s => s._id === stageId);
    return stage ? stage.name : `Stage ${stageId}`;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto relative">
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="text-xl font-bold">Service Types</h2>
          <button 
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
            aria-label="Close"
          >
            <span className="text-2xl">&times;</span>
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b">
          <button
            className={`px-4 py-2 font-medium ${activeTab === 'view' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-600'}`}
            onClick={() => setActiveTab('view')}
          >
            Existing Service Types
          </button>
          <button
            className={`px-4 py-2 font-medium ${activeTab === 'add' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-600'}`}
            onClick={() => setActiveTab('add')}
          >
            Add New Service Type
          </button>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 p-3 mx-4 my-2 rounded">
            {error}
          </div>
        )}

        {/* Add New Service Type Tab */}
        {activeTab === 'add' && (
          <div className="p-4">
            <div className="mb-4">
              <label className="block text-sm font-medium mb-2">Service Code *</label>
              <input
                type="text"
                value={serviceCode}
                onChange={(e) => setServiceCode(e.target.value)}
                placeholder="Enter service code (e.g., OIL_CHANGE)"
                className="w-full p-2 border rounded"
              />
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium mb-2">Service Description *</label>
              <input
                type="text"
                value={serviceDescription}
                onChange={(e) => setServiceDescription(e.target.value)}
                placeholder="Enter service description"
                className="w-full p-2 border rounded"
              />
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium mb-2">Default Labor Hours *</label>
              <input
                type="number"
                min="0.1"
                step="0.1"
                value={laborHours}
                onChange={(e) => setLaborHours(e.target.value)}
                placeholder="Enter expected labor hours"
                className="w-full p-2 border rounded"
              />
            </div>

            <div className="mb-4">
              <div className="flex justify-between items-center mb-2">
                <label className="block text-sm font-medium">Service Stages *</label>
                <div className="flex items-center gap-2">
                  {isLoading && (
                    <div className="text-xs text-gray-500">Loading stages...</div>
                  )}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      console.log('Add Stage button clicked!');
                      console.log('Available stages:', availableStages.length);
                      console.log('Selected stages:', selectedStages.length);
                      console.log('Is disabled?', selectedStages.length >= availableStages.length || isLoading || availableStages.length === 0);
                      handleAddStage();
                    }}
                    disabled={selectedStages.length >= availableStages.length || isLoading || availableStages.length === 0}
                    className={`py-1 px-3 text-sm rounded relative z-10 transition-all ${
                      selectedStages.length >= availableStages.length || isLoading || availableStages.length === 0
                        ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                        : 'bg-blue-500 text-white hover:bg-blue-600 cursor-pointer'
                    }`}
                    title={availableStages.length === 0 ? 'No stages available' : selectedStages.length >= availableStages.length ? 'All stages already added' : 'Add a new stage'}
                  >
                    Add Stage
                  </button>
                </div>
              </div>
              
              {isLoading && !availableStages.length ? (
                <div className="p-4 text-center text-gray-500">Loading stages...</div>
              ) : (
                <>
                  {availableStages.length === 0 && !isLoading ? (
                    <div className="p-4 text-center text-amber-600 bg-amber-50 border border-amber-200 rounded">
                      No stages available. Please configure stages in the system first.
                    </div>
                  ) : (
                    <>
                      {selectedStages.length === 0 ? (
                        <div className="text-sm text-gray-500 mb-2 p-2 bg-gray-50 rounded">
                          No stages added yet. Click "Add Stage" to begin.
                        </div>
                      ) : (
                        <ul className="mb-2 space-y-2">
                          {selectedStages.map((stageId, index) => (
                            <li key={index} className="flex items-center space-x-2 p-2 bg-blue-50 rounded">
                              <span className="text-sm font-medium text-blue-700 min-w-[30px]">{index + 1}.</span>
                              <select
                                value={stageId}
                                onChange={(e) => handleStageChange(index, e.target.value)}
                                className="flex-1 p-2 border rounded focus:ring-2 focus:ring-blue-500"
                              >
                                {availableStages.map(s => (
                                  <option key={s._id} value={s._id}>
                                    {s.name}
                                  </option>
                                ))}
                              </select>
                              <button
                                type="button"
                                onClick={() => handleRemoveStage(stageId)}
                                className="py-1 px-2 bg-red-500 text-white text-sm rounded hover:bg-red-600 transition-colors"
                                title="Remove this stage"
                              >
                                Remove
                              </button>
                            </li>
                          ))}
                        </ul>
                      )}
                    </>
                  )}
                </>
              )}
            </div>
            
            <div className="flex justify-end space-x-3 mt-4">
              <button
                onClick={onClose}
                disabled={isLoading}
                className="px-4 py-2 border border-gray-300 rounded text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleSubmit}
                disabled={isLoading}
                className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
              >
                {isLoading ? "Creating..." : "Create Service Type"}
              </button>
            </div>
          </div>
        )}

        {/* View Existing Service Types Tab */}
        {activeTab === 'view' && (
          <div className="p-4">
            {isLoading && !variations.length ? (
              <div className="p-4 text-center text-gray-500">Loading service types...</div>
            ) : (
              <div className="space-y-4">
                {/* List of variations */}
                <div className="border rounded overflow-hidden">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Code</th>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Labor Hours</th>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {variations.map(variation => (
                        <tr key={variation._id} className="hover:bg-gray-50">
                          <td className="px-4 py-2 whitespace-nowrap font-mono text-sm">{variation.code}</td>
                          <td className="px-4 py-2">{variation.description}</td>
                          <td className="px-4 py-2 whitespace-nowrap">{variation.defaultLaborHours}h</td>
                          <td className="px-4 py-2 whitespace-nowrap space-x-2">
                            <button
                              className="text-blue-600 hover:text-blue-900 text-sm"
                              onClick={() => {
                                fetchVariationDetails(variation._id);
                              }}
                            >
                              View Stages
                            </button>
                            <button
                              className="text-green-600 hover:text-green-900 text-sm font-medium"
                              onClick={() => {
                                onServiceAdded({
                                  _id: variation._id,
                                  code: variation.code,
                                  description: variation.description
                                });
                                onClose();
                              }}
                            >
                              Select
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Selected variation details */}
                {selectedVariation && (
                  <div className="border rounded p-4 mt-4">
                    <h3 className="text-lg font-medium mb-2">{selectedVariation.code} - {selectedVariation.description}</h3>
                    <p className="text-sm text-gray-600 mb-3">Default Labor Hours: {selectedVariation.defaultLaborHours}h</p>
                    
                    <h4 className="font-medium mb-2">Stages:</h4>
                    {isLoading ? (
                      <div className="p-4 text-center text-gray-500">Loading stages...</div>
                    ) : (
                      <>
                        {selectedVariation.stages && selectedVariation.stages.length > 0 ? (
                          <ul className="space-y-2">
                            {selectedVariation.stages.map((stage, index) => (
                              <li key={index} className="flex items-center">
                                <span className="bg-blue-100 text-blue-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded">
                                  {index + 1}
                                </span>
                                <span>
                                  {stage.stage_name || getStageName(stage.stage_id)}
                                </span>
                              </li>
                            ))}
                          </ul>
                        ) : (
                          <p className="text-gray-500">No stages defined for this service type.</p>
                        )}
                      </>
                    )}
                    
                    <div className="mt-4 flex space-x-2">
                      <button 
                        className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
                        onClick={() => {
                          onServiceAdded({
                            _id: selectedVariation._id,
                            code: selectedVariation.code,
                            description: selectedVariation.description
                          });
                          onClose();
                        }}
                      >
                        Select This Service Type
                      </button>
                      <button
                        className="px-4 py-2 bg-gray-300 text-gray-700 rounded hover:bg-gray-400"
                        onClick={() => setSelectedVariation(null)}
                      >
                        Close Details
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default ServiceTypeModal;