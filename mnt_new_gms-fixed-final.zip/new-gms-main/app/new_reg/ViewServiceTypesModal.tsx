import React, { useState, useEffect } from "react";
import api from "@/services/api";
import { toast } from "react-hot-toast";

interface ViewServiceTypesModalProps {
  isOpen: boolean;
  onClose: () => void;
  onServiceSelected: (service: { _id: string; code: string; description: string }) => void;
  variations?: Variation[];
}

interface Stage {
  _id: string;
  name: string;
  description?: string;
  order: number;
  created_at?: string;
  updated_at?: string;
}

interface VariationStage {
  stage_id: string;
  stage_order: number;
  stage_name?: string;
}

interface Variation {
  _id: string;
  code: string;
  description: string;
  defaultLaborHours: number;
  defaultStages: string[];
  stages?: VariationStage[];
  created_at?: string;
  updated_at?: string;
}

const ViewServiceTypesModal: React.FC<ViewServiceTypesModalProps> = ({ 
  isOpen, 
  onClose, 
  onServiceSelected,
  variations: propVariations
}) => {
  // View existing service types state
  const [variations, setVariations] = useState<Variation[]>([]);
  const [selectedVariation, setSelectedVariation] = useState<Variation | null>(null);
  const [availableStages, setAvailableStages] = useState<Stage[]>([]);
  
  // Edit state
  const [editingVariation, setEditingVariation] = useState<Variation | null>(null);
  const [editCode, setEditCode] = useState("");
  const [editDescription, setEditDescription] = useState("");
  const [editLaborHours, setEditLaborHours] = useState("");
  const [editStages, setEditStages] = useState<string[]>([]);
  
  // Delete state
  const [deletingVariation, setDeletingVariation] = useState<Variation | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  
  // Shared state
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  // Fetch data when modal opens
  useEffect(() => {
    if (isOpen) {
      fetchAvailableStages();
      fetchVariations();
    }
  }, [isOpen]);

  // Fetch available stages for display purposes
  const fetchAvailableStages = async () => {
    try {
      const response = await api.get("/api/stages");
      
      let stagesData = [];
      if (response && response.success && Array.isArray(response.data)) {
        stagesData = response.data;
      } else if (Array.isArray(response)) {
        stagesData = response;
      } else if (response && Array.isArray(response.data)) {
        stagesData = response.data;
      }
      
      setAvailableStages(stagesData);
    } catch (error) {
      console.error("Error fetching stages:", error);
      setAvailableStages([]);
    }
  };

  // Fetch existing variations (service types)
  const fetchVariations = async () => {
    try {
      setIsLoading(true);
      if (propVariations) {
        setVariations(propVariations);
      } else {
        const response = await api.get("/api/variations");
        const variationsData = response || [];
        setVariations(Array.isArray(variationsData) ? variationsData : []);
      }
    } catch (error) {
      console.error("Error fetching variations:", error);
      setError("Failed to load existing service types. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  // Fetch variation details with stages
  const fetchVariationDetails = async (variationId: string) => {
    try {
      setIsLoading(true);
      const response = await api.get(`/api/variations/${variationId}?include=stages`);
      
      // Process the stages for display
      if (response && response.defaultStages) {
        const stageDetails = await Promise.all(
          response.defaultStages.map(async (stageId: string) => {
            try {
              const stageResponse = await api.get(`/api/stages/${stageId}`);
              return {
                stage_id: stageId,
                stage_name: stageResponse.name,
                stage_order: stageResponse.order || 0
              };
            } catch (error) {
              console.error(`Error fetching stage ${stageId}:`, error);
              return {
                stage_id: stageId,
                stage_name: `Stage ${stageId}`,
                stage_order: 0
              };
            }
          })
        );
        
        response.stages = stageDetails.sort((a, b) => a.stage_order - b.stage_order);
      }
      
      setSelectedVariation(response);
    } catch (error) {
      console.error("Error fetching variation details:", error);
      setError("Failed to load service type details. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  // Function to get stage name by ID
  const getStageName = (stageId: string): string => {
    const stage = availableStages.find(s => s._id === stageId);
    return stage ? stage.name : `Stage ${stageId}`;
  };

  // Handle edit button click
  const handleEditClick = (variation: Variation) => {
    setEditingVariation(variation);
    setEditCode(variation.code);
    setEditDescription(variation.description);
    setEditLaborHours(variation.defaultLaborHours.toString());
    setEditStages(variation.defaultStages || []);
  };

  // Handle save edit
  const handleSaveEdit = async () => {
    if (!editingVariation) return;
    
    try {
      setIsLoading(true);
      const updateData = {
        code: editCode,
        description: editDescription,
        defaultLaborHours: parseFloat(editLaborHours),
        defaultStages: editStages
      };
      
      const response = await api.put(`/api/variations/${editingVariation._id}`, updateData);
      
      if (response) {
        toast.success('Service type updated successfully');
        setEditingVariation(null);
        fetchVariations();
      }
    } catch (error) {
      console.error('Error updating variation:', error);
      toast.error('Failed to update service type');
    } finally {
      setIsLoading(false);
    }
  };

  // Handle delete button click
  const handleDeleteClick = (variation: Variation) => {
    setDeletingVariation(variation);
    setShowDeleteConfirm(true);
  };

  // Confirm delete
  const handleConfirmDelete = async () => {
    if (!deletingVariation) return;
    
    try {
      setIsLoading(true);
      const response = await api.delete(`/api/variations/${deletingVariation._id}`);
      
      if (response) {
        toast.success('Service type deleted successfully');
        setShowDeleteConfirm(false);
        setDeletingVariation(null);
        fetchVariations();
      }
    } catch (error: any) {
      console.error('Error deleting variation:', error);
      const errorMessage = error?.response?.data?.message || 'Failed to delete service type';
      toast.error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto relative">
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="text-xl font-bold">{t('selectServiceType')}</h2>
          <button 
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
            aria-label="Close"
          >
            <span className="text-2xl">&times;</span>
          </button>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 p-3 mx-4 my-2 rounded">
            {error}
          </div>
        )}

        {/* View Existing Service Types */}
        <div className="p-4">
          {isLoading && !variations.length ? (
            <div className="p-4 text-center text-gray-500">Loading service types...</div>
          ) : (
            <div className="space-y-4">
              {/* List of variations */}
              <div className="border rounded overflow-hidden">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">{t('serviceCode')}</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">{t('description')}</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">{t('laborHours')}</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider" colSpan={2}>Actions</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {variations.map(variation => (
                      <tr key={variation._id} className="hover:bg-gray-50">
                        <td className="px-4 py-2 whitespace-nowrap font-mono text-sm">{variation.code}</td>
                        <td className="px-4 py-2">{variation.description}</td>
                        <td className="px-4 py-2 whitespace-nowrap">{variation.defaultLaborHours}h</td>
                        <td className="px-4 py-2 whitespace-nowrap space-x-2">
                          <button
                            className="text-blue-600 hover:text-blue-900 text-sm"
                            onClick={() => {
                              fetchVariationDetails(variation._id);
                            }}
                          >
                            {t('viewStages')}
                          </button>
                          <button
                            className="text-green-600 hover:text-green-900 text-sm font-medium"
                            onClick={() => {
                              onServiceSelected({
                                _id: variation._id,
                                code: variation.code,
                                description: variation.description
                              });
                              onClose();
                            }}
                          >
                            {t('select')}
                          </button>
                          <button
                            className="text-yellow-600 hover:text-yellow-900 text-sm"
                            onClick={() => handleEditClick(variation)}
                          >
                            {t('edit')}
                          </button>
                          <button
                            className="text-red-600 hover:text-red-900 text-sm"
                            onClick={() => handleDeleteClick(variation)}
                          >
                            {t('delete')}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Selected variation details */}
              {selectedVariation && (
                <div className="border rounded p-4 mt-4">
                  <h3 className="text-lg font-medium mb-2">{selectedVariation.code} - {selectedVariation.description}</h3>
                  <p className="text-sm text-gray-600 mb-3">Default Labor Hours: {selectedVariation.defaultLaborHours}h</p>
                  
                  <h4 className="font-medium mb-2">Stages:</h4>
                  {isLoading ? (
                    <div className="p-4 text-center text-gray-500">Loading stages...</div>
                  ) : (
                    <>
                      {selectedVariation.stages && selectedVariation.stages.length > 0 ? (
                        <ul className="space-y-2">
                          {selectedVariation.stages.map((stage, index) => (
                            <li key={index} className="flex items-center">
                              <span className="bg-blue-100 text-blue-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded">
                                {index + 1}
                              </span>
                              <span>
                                {stage.stage_name || getStageName(stage.stage_id)}
                              </span>
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <p className="text-gray-500">No stages defined for this service type.</p>
                      )}
                    </>
                  )}
                  
                  <div className="mt-4 flex space-x-2">
                    <button 
                      className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
                      onClick={() => {
                        onServiceSelected({
                          _id: selectedVariation._id,
                          code: selectedVariation.code,
                          description: selectedVariation.description
                        });
                        onClose();
                      }}
                    >
                      Select This Service Type
                    </button>
                    <button
                      className="px-4 py-2 bg-gray-300 text-gray-700 rounded hover:bg-gray-400"
                      onClick={() => setSelectedVariation(null)}
                    >
                      Close Details
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
      
      {/* Edit Modal */}
      {editingVariation && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[60] p-4">
          <div className="bg-white rounded-lg shadow-2xl w-full max-w-md">
            <div className="flex justify-between items-center p-4 border-b">
              <h3 className="text-lg font-bold">Edit Service Type</h3>
              <button 
                onClick={() => setEditingVariation(null)}
                className="text-gray-500 hover:text-gray-700"
              >
                <span className="text-2xl">&times;</span>
              </button>
            </div>
            
            <div className="p-4 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Service Code
                </label>
                <input
                  type="text"
                  value={editCode}
                  onChange={(e) => setEditCode(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Description
                </label>
                <input
                  type="text"
                  value={editDescription}
                  onChange={(e) => setEditDescription(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Default Labor Hours
                </label>
                <input
                  type="number"
                  value={editLaborHours}
                  onChange={(e) => setEditLaborHours(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  step="0.5"
                  min="0"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Stages
                </label>
                <div className="space-y-2 max-h-40 overflow-y-auto border rounded p-2">
                  {availableStages.map(stage => (
                    <label key={stage._id} className="flex items-center">
                      <input
                        type="checkbox"
                        checked={editStages.includes(stage._id)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setEditStages([...editStages, stage._id]);
                          } else {
                            setEditStages(editStages.filter(s => s !== stage._id));
                          }
                        }}
                        className="mr-2"
                      />
                      <span className="text-sm">{stage.name}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="flex justify-end gap-2 p-4 border-t">
              <button
                onClick={() => setEditingVariation(null)}
                className="px-4 py-2 bg-gray-300 text-gray-700 rounded hover:bg-gray-400"
                disabled={isLoading}
              >
                Cancel
              </button>
              <button
                onClick={handleSaveEdit}
                className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
                disabled={isLoading}
              >
                {isLoading ? t('loading') : t('save')}
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && deletingVariation && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[60] p-4">
          <div className="bg-white rounded-lg shadow-2xl w-full max-w-md">
            <div className="flex justify-between items-center p-4 border-b">
              <h3 className="text-lg font-bold text-red-600">Confirm Delete</h3>
              <button 
                onClick={() => {
                  setShowDeleteConfirm(false);
                  setDeletingVariation(null);
                }}
                className="text-gray-500 hover:text-gray-700"
              >
                <span className="text-2xl">&times;</span>
              </button>
            </div>
            
            <div className="p-4">
              <p className="text-gray-700 mb-4">
                {t('deleteWarning')}
              </p>
              <div className="bg-gray-100 p-3 rounded mb-4">
                <p className="font-mono text-sm font-bold">{deletingVariation.code}</p>
                <p className="text-sm text-gray-600">{deletingVariation.description}</p>
              </div>
              <p className="text-sm text-red-600">
                {t('deleteWarningNote')}
              </p>
            </div>
            
            <div className="flex justify-end gap-2 p-4 border-t">
              <button
                onClick={() => {
                  setShowDeleteConfirm(false);
                  setDeletingVariation(null);
                }}
                className="px-4 py-2 bg-gray-300 text-gray-700 rounded hover:bg-gray-400"
                disabled={isLoading}
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmDelete}
                className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
                disabled={isLoading}
              >
                {isLoading ? t('loading') : t('delete')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ViewServiceTypesModal;