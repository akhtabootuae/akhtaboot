import React, { useState, useEffect } from "react";
import api from "@/services/api";

interface ServiceTypeDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  serviceType: Variation | null;
}

interface Stage {
  _id: string;
  name: string;
  description?: string;
  order: number;
  created_at?: string;
  updated_at?: string;
}

interface VariationStage {
  stage_id: string;
  stage_order: number;
  stage_name?: string;
}

interface Variation {
  _id: string;
  code: string;
  description: string;
  defaultLaborHours: number;
  defaultStages: string[];
  stages?: VariationStage[];
  created_at?: string;
  updated_at?: string;
}

const ServiceTypeDetailsModal: React.FC<ServiceTypeDetailsModalProps> = ({ 
  isOpen, 
  onClose, 
  serviceType
}) => {
  const [variationDetails, setVariationDetails] = useState<Variation | null>(null);
  const [availableStages, setAvailableStages] = useState<Stage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  // Fetch data when modal opens and serviceType changes
  useEffect(() => {
    if (isOpen && serviceType) {
      fetchAvailableStages();
      fetchVariationDetails(serviceType._id);
    }
  }, [isOpen, serviceType]);

  // Fetch available stages for display purposes
  const fetchAvailableStages = async () => {
    try {
      const response = await api.get("/api/stages");
      
      let stagesData = [];
      if (response && response.success && Array.isArray(response.data)) {
        stagesData = response.data;
      } else if (Array.isArray(response)) {
        stagesData = response;
      } else if (response && Array.isArray(response.data)) {
        stagesData = response.data;
      }
      
      setAvailableStages(stagesData);
    } catch (error) {
      console.error("Error fetching stages:", error);
      setAvailableStages([]);
    }
  };

  // Fetch variation details with stages
  const fetchVariationDetails = async (variationId: string) => {
    try {
      setIsLoading(true);
      const response = await api.get(`/api/variations/${variationId}?include=stages`);
      
      // Process the stages for display
      if (response && response.defaultStages) {
        const stageDetails = await Promise.all(
          response.defaultStages.map(async (stageId: string) => {
            try {
              const stageResponse = await api.get(`/api/stages/${stageId}`);
              return {
                stage_id: stageId,
                stage_name: stageResponse.name,
                stage_order: stageResponse.order || 0
              };
            } catch (error) {
              console.error(`Error fetching stage ${stageId}:`, error);
              return {
                stage_id: stageId,
                stage_name: `Stage ${stageId}`,
                stage_order: 0
              };
            }
          })
        );
        
        response.stages = stageDetails.sort((a, b) => a.stage_order - b.stage_order);
      }
      
      setVariationDetails(response);
    } catch (error) {
      console.error("Error fetching variation details:", error);
      setError("Failed to load service type details. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  // Function to get stage name by ID
  const getStageName = (stageId: string): string => {
    const stage = availableStages.find(s => s._id === stageId);
    return stage ? stage.name : `Stage ${stageId}`;
  };

  if (!isOpen || !serviceType) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto relative">
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="text-xl font-bold">Service Type Details</h2>
          <button 
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
            aria-label="Close"
          >
            <span className="text-2xl">&times;</span>
          </button>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 p-3 mx-4 my-2 rounded">
            {error}
          </div>
        )}

        <div className="p-4">
          {isLoading ? (
            <div className="p-8 text-center text-gray-500">
              <div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4"></div>
              Loading service type details...
            </div>
          ) : variationDetails ? (
            <div className="space-y-4">
              {/* Service Type Info */}
              <div className="bg-blue-50 rounded-lg p-4">
                <h3 className="text-lg font-bold text-blue-900 mb-2">
                  {variationDetails.code}
                </h3>
                <p className="text-blue-800 mb-3">
                  {variationDetails.description}
                </p>
                <div className="flex items-center text-sm text-blue-700">
                  <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Default Labor Hours: {variationDetails.defaultLaborHours}h
                </div>
              </div>

              {/* Stages */}
              <div>
                <h4 className="font-bold text-gray-900 mb-3 flex items-center">
                  <svg className="w-5 h-5 mr-2 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                  </svg>
                  Service Stages
                </h4>
                
                {variationDetails.stages && variationDetails.stages.length > 0 ? (
                  <div className="space-y-2">
                    {variationDetails.stages.map((stage, index) => (
                      <div key={index} className="flex items-center p-3 bg-gray-50 rounded-lg">
                        <span className="bg-blue-500 text-white text-sm font-bold w-8 h-8 rounded-full flex items-center justify-center mr-3">
                          {index + 1}
                        </span>
                        <div className="flex-1">
                          <span className="font-medium text-gray-900">
                            {stage.stage_name || getStageName(stage.stage_id)}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <svg className="w-12 h-12 mx-auto mb-3 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                    </svg>
                    <p>No stages defined for this service type.</p>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <p>Service type details not available.</p>
            </div>
          )}
        </div>

        <div className="p-4 border-t bg-gray-50">
          <button
            onClick={onClose}
            className="w-full px-4 py-2 bg-gray-600 text-white rounded hover:bg-gray-700 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default ServiceTypeDetailsModal;