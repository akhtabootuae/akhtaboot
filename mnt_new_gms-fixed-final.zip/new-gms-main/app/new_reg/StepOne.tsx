import React, { useState, useEffect, useRef } from "react";
import { plateRegionsByCountry, carMakes } from "./page";
import api from "@/services/api";
import { toast } from "react-hot-toast";
import { useLanguage } from "@/app/context/LanguageContext";

// Constants for dropdowns
const carColors = ["White", "Black", "Silver", "Grey", "Red", "Blue", "Green", "Yellow", "Orange", "Brown", "Gold", "Beige", "Purple", "Other"];

// Country code mapping
const countryCodes: Record<string, string> = {
  "UAE": "971",
  "Saudi Arabia": "966",
  "Qatar": "974",
  "Kuwait": "965",
  "Bahrain": "973",
  "Oman": "968",
  "Egypt": "20",
  "Jordan": "962",
  "Lebanon": "961",
  "Syria": "963",
  "Iraq": "964",
  "Turkey": "90",
  "India": "91",
  "Pakistan": "92",
  "Sudan": "249",
  "USA": "1",
  "UK": "44",
  "Germany": "49",
  "France": "33",
  "Canada": "1",
  "Australia": "61",
  "Other": ""
};

// City/State mappings by country
const locationsByCountry: Record<string, string[]> = {
  "UAE": ["Abu Dhabi", "Dubai", "Sharjah", "Ajman", "Umm Al Quwain", "Ras Al Khaimah", "Fujairah", "Al Ain"],
  "Saudi Arabia": ["Riyadh", "Jeddah", "Mecca", "Medina", "Dammam", "Khobar", "Dhahran", "Abha", "Tabuk", "Hail"],
  "Qatar": ["Doha", "Al Rayyan", "Al Wakrah", "Al Khor", "Umm Salal", "Madinat ash Shamal"],
  "Kuwait": ["Kuwait City", "Hawalli", "Salmiya", "Farwaniya", "Ahmadi", "Jahra"],
  "Bahrain": ["Manama", "Riffa", "Muharraq", "Hamad Town", "A'ali", "Isa Town"],
  "Oman": ["Muscat", "Salalah", "Sohar", "Nizwa", "Sur", "Ibri"],
  "Egypt": ["Cairo", "Alexandria", "Giza", "Shubra El Kheima", "Port Said", "Suez", "Luxor", "Aswan"],
  "Sudan": ["Khartoum", "Omdurman", "Khartoum North", "Port Sudan", "Kassala", "Wad Madani", "El Obeid", "Nyala", "Gedaref", "Atbara"],
  "USA": ["Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware", "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey", "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming"],
  "UK": ["London", "Birmingham", "Manchester", "Glasgow", "Liverpool", "Leeds", "Sheffield", "Edinburgh", "Bristol", "Cardiff"],
  "Canada": ["Ontario", "Quebec", "British Columbia", "Alberta", "Manitoba", "Saskatchewan", "Nova Scotia", "New Brunswick", "Newfoundland and Labrador", "Prince Edward Island"],
  "Australia": ["Sydney", "Melbourne", "Brisbane", "Perth", "Adelaide", "Gold Coast", "Newcastle", "Canberra", "Central Coast", "Wollongong"],
  "India": ["Mumbai", "Delhi", "Bangalore", "Hyderabad", "Chennai", "Kolkata", "Ahmedabad", "Pune", "Surat", "Jaipur"],
  "Germany": ["Berlin", "Hamburg", "Munich", "Cologne", "Frankfurt", "Stuttgart", "Düsseldorf", "Dortmund", "Essen", "Leipzig"],
  "France": ["Paris", "Marseille", "Lyon", "Toulouse", "Nice", "Nantes", "Strasbourg", "Montpellier", "Bordeaux", "Lille"],
  "Other": []
};

const countries = Object.keys(countryCodes);

// Car models mapping
const carModels: Record<string, string[]> = {
  "Toyota": ["Camry", "Corolla", "RAV4", "Land Cruiser", "Fortuner", "Prado", "Yaris", "Highlander", "Hilux", "4Runner", "Sequoia", "Tacoma"],
  "Honda": ["Civic", "Accord", "CR-V", "Pilot", "HR-V"],
  "Nissan": ["Altima", "Maxima", "Patrol", "Sunny", "X-Trail", "Armada", "Titan", "Murano", "Tida", "Juke", "Kicks", "Sentra"],
  "BMW": ["3 Series", "5 Series", "7 Series", "X3", "X5", "X7"],
  "Mercedes-Benz": ["C-Class", "E-Class", "S-Class", "GLC", "GLE"],
  "Ford": ["F-150", "Mustang", "Explorer", "Escape", "Edge", "F-250", "F-350", "Focus", "Taurus", "Ranger"],
  "Chevrolet": ["Tahoe", "Malibu", "Camaro", "Silverado", "Suburban"],
  "Hyundai": ["Sonata", "Elantra", "Tucson", "Santa Fe", "Accent"],
  "Kia": ["Optima", "Sorento", "Sportage", "Forte", "Soul", "Carens"],
  "Audi": ["A4", "A6", "Q5", "Q7", "A8"],
  "Lexus": ["IS", "ES", "LS", "RX", "GX", "LX"],
  "Mazda": ["Mazda3", "Mazda6", "CX-5", "CX-9", "MX-5"],
  "Subaru": ["Outback", "Forester", "Impreza", "Legacy", "Crosstrek"],
  "Volkswagen": ["Jetta", "Passat", "Golf", "Tiguan", "Atlas", "Terramont", "Polo"],
  "Jeep": ["Grand Cherokee", "Wrangler", "Cherokee", "Compass", "Renegade"],
  "Dodge": ["Charger", "Challenger", "Durango", "Journey", "Grand Caravan"],
  "Mitsubishi": ["Outlander", "Eclipse Cross", "Mirage", "Pajero", "L200"],
  "Tesla": ["Model S", "Model 3", "Model X", "Model Y"],
  "Volvo": ["XC60", "XC90", "S60", "S90", "V60"],
  "Jaguar": ["XE", "XF", "F-PACE", "E-PACE", "I-PACE"],
  "Land Rover": ["Range Rover", "Discovery", "Defender", "Evoque", "Velar"],
  "Mini": ["Cooper", "Countryman", "Clubman", "Convertible"],
  "Alfa Romeo": ["Giulia", "Stelvio", "4C", "Tonale"],
  "Suzuki": ["Swift", "Vitara", "Jimny", "Ciaz", "Ertiga"],
  "Lamborghini": ["Huracan", "Aventador", "Urus"],
  "Ferrari": ["488 GTB", "Portofino", "Roma", "F8 Tributo"],
  "Porsche": ["911", "Cayenne", "Macan", "Panamera", "Taycan"],
  "Fiat": ["500", "Panda", "Tipo", "Punto", "Doblo"],
  "Renault": ["Clio", "Megane", "Captur", "Kadjar", "Duster"],
  "Peugeot": ["208", "308", "3008", "5008", "2008"],
  "Citroën": ["C3", "C4", "C5 Aircross", "Berlingo", "C1"],
  "Skoda": ["Octavia", "Superb", "Kodiaq", "Karoq", "Fabia"],
  "BYD": ["Tang", "Han", "Song", "Yuan", "Qin"],
  "Geely": ["Emgrand", "Boyue", "Coolray", "Atlas", "Panda"],
  "Chery": ["Tiggo", "Arrizo", "Exeed", "QQ", "Fulwin"],
  "Great Wall": ["Haval H6", "Haval H2", "Wingle", "Pao", "Ora"],
  "SAIC": ["MG ZS", "MG Hector", "Roewe RX5", "Maxus T60", "Wuling Hongguang"],
  "NIO": ["ES8", "ES6", "EC6", "ET7", "ET5"],
  "Xpeng": ["P7", "G3", "P5", "G9", "P2"],
  "Li Auto": ["Li ONE", "Li L9", "Li L8", "Li L7", "Li L6"]
};

// TypeScript interfaces
interface CustomerType {
  first_name: string;
  last_name: string;
  phone: string;
  email: string;
  city: string;
  country: string;
  branch?: {
    branch_id: string;
    branch_name: string;
  };
}

interface VehicleType {
  make: string;
  model: string;
  year: string;
  license_plate: string;
  license_plate_country?: string;
  vin: string;
  color: string;
  vehicle_type: string;
}

interface CustomerSuggestion {
  _id: string;
  first_name: string;
  last_name: string;
  phone: string;
  email: string;
  city: string;
  country: string;
  vehicles?: VehicleType[];
  branch?: {
    branch_id: string;
    branch_name: string;
  };
}

interface StepOneProps {
  customer: CustomerType;
  vehicle: VehicleType;
  imagePreviews: string[];
  vehicleImages: File[];
  registrationType: 'work_order' | 'quotation' | null;
  handleCustomerChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement> | { target: { name: string; value: string } }) => void;
  handleVehicleChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement> | { target: { name: string; value: string } }) => void;
  handleMakeSelect: (make: string) => void;
  handleRegionSelect: (region: string) => void;
  handleImageChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  handleRemoveImage: (index: number) => void;
  selectExistingCustomer: (customer: CustomerSuggestion, autoFillVehicle?: boolean) => void;
  handleNextStep: () => void;
  updateCustomerData: (data: Partial<CustomerType>) => void;
  setRegistrationType: (type: 'work_order' | 'quotation') => void;
}

const StepOne: React.FC<StepOneProps> = ({
  customer,
  vehicle,
  imagePreviews,
  vehicleImages,
  registrationType,
  handleCustomerChange,
  handleVehicleChange,
  handleMakeSelect,
  handleRegionSelect,
  handleImageChange,
  handleRemoveImage,
  selectExistingCustomer,
  handleNextStep,
  updateCustomerData,
  setRegistrationType,
}) => {
  const { t } = useLanguage();
  // State for customer search
  const [suggestions, setSuggestions] = useState<CustomerSuggestion[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);
  const [noResults, setNoResults] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  
  // State for vehicle selection modal
  const [showVehicleModal, setShowVehicleModal] = useState(false);
  const [selectedCustomerVehicles, setSelectedCustomerVehicles] = useState<VehicleType[]>([]);
  const [currentCustomerSelection, setCurrentCustomerSelection] = useState<CustomerSuggestion | null>(null);
  
  // States for make/model search
  const [filteredMakes, setFilteredMakes] = useState<string[]>([]);
  const [availableModels, setAvailableModels] = useState<string[]>(
    vehicle.make ? (carModels[vehicle.make] || []) : []
  );
  const [showMakeDropdown, setShowMakeDropdown] = useState(false);
  const [showModelDropdown, setShowModelDropdown] = useState(false);
  const [isCustomModel, setIsCustomModel] = useState(false);
  const [customModels, setCustomModels] = useState<{[key: string]: Array<{name: string; addedAt: number}>}>({});
  const [isCustomMake, setIsCustomMake] = useState(false);
  const [customMakes, setCustomMakes] = useState<Array<{name: string; addedAt: number}>>([]);
  
  // Validation state
  const [formErrors, setFormErrors] = useState<{[key: string]: string}>({});
  const [attemptedSubmit, setAttemptedSubmit] = useState(false);
  
  // State for color selection
  const [isOtherColor, setIsOtherColor] = useState(false);
  const [customColor, setCustomColor] = useState("");
  
  // State for branches
  const [branches, setBranches] = useState<Array<{_id: string; name?: string; branch_name?: string; location?: string}>>([]);
  const [loadingBranches, setLoadingBranches] = useState(false);
  
  // State for license plate country
  const [licensePlateCountry, setLicensePlateCountry] = useState<string>(vehicle.license_plate_country || "UAE");
  
  // Refs for elements and timing
  const searchTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const hideDropdownTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const firstNameInputRef = useRef<HTMLInputElement>(null);
  const customerDropdownRef = useRef<HTMLDivElement>(null);
  
  // Phone number split into parts
  const [phoneWithoutCode, setPhoneWithoutCode] = useState<string>(() => {
    // If phone has country code already, extract the number part
    if (customer.phone && customer.phone.length > 3) {
      // Extract the country code from the beginning
      for (const [, code] of Object.entries(countryCodes)) {
        if (customer.phone.startsWith(code)) {
          return customer.phone.substring(code.length);
        }
      }
    }
    return "";
  });

  // Load custom models and makes from localStorage
  useEffect(() => {
    const savedCustomModels = localStorage.getItem('customCarModels');
    if (savedCustomModels) {
      try {
        const parsed = JSON.parse(savedCustomModels);
        // Convert old format to new format with timestamps
        const converted: {[key: string]: Array<{name: string; addedAt: number}>} = {};
        for (const [make, models] of Object.entries(parsed)) {
          if (Array.isArray(models)) {
            // Check if it's old format (string array) or new format
            if (models.length > 0 && typeof models[0] === 'string') {
              // Old format - convert to new
              converted[make] = models.map(model => ({ name: model, addedAt: Date.now() }));
            } else {
              // New format - use as is
              converted[make] = models as Array<{name: string; addedAt: number}>;
            }
          }
        }
        setCustomModels(converted);
      } catch (error) {
        console.error('Error parsing custom models from localStorage:', error);
      }
    }
    
    const savedCustomMakes = localStorage.getItem('customCarMakes');
    if (savedCustomMakes) {
      try {
        const parsed = JSON.parse(savedCustomMakes);
        // Convert old format to new format with timestamps
        if (Array.isArray(parsed)) {
          if (parsed.length > 0 && typeof parsed[0] === 'string') {
            // Old format - convert to new
            setCustomMakes(parsed.map(make => ({ name: make, addedAt: Date.now() })));
          } else {
            // New format - use as is
            setCustomMakes(parsed);
          }
        }
      } catch (error) {
        console.error('Error parsing custom makes from localStorage:', error);
      }
    }
  }, []);

  // Save custom model to localStorage and state
  const saveCustomModel = (make: string, model: string) => {
    const updatedCustomModels = { ...customModels };
    if (!updatedCustomModels[make]) {
      updatedCustomModels[make] = [];
    }
    // Check if model doesn't already exist
    if (!updatedCustomModels[make].some(m => m.name.toLowerCase() === model.toLowerCase())) {
      updatedCustomModels[make].push({ name: model, addedAt: Date.now() });
      setCustomModels(updatedCustomModels);
      localStorage.setItem('customCarModels', JSON.stringify(updatedCustomModels));
    }
  };

  // Save custom make to localStorage and state
  const saveCustomMake = (make: string) => {
    if (!customMakes.some(m => m.name.toLowerCase() === make.toLowerCase())) {
      const updatedCustomMakes = [...customMakes, { name: make, addedAt: Date.now() }];
      setCustomMakes(updatedCustomMakes);
      localStorage.setItem('customCarMakes', JSON.stringify(updatedCustomMakes));
    }
  };
  
  // Remove custom make
  const removeCustomMake = (makeName: string) => {
    const updatedCustomMakes = customMakes.filter(m => m.name !== makeName);
    setCustomMakes(updatedCustomMakes);
    localStorage.setItem('customCarMakes', JSON.stringify(updatedCustomMakes));
    
    // Also remove all custom models for this make
    const updatedCustomModels = { ...customModels };
    delete updatedCustomModels[makeName];
    setCustomModels(updatedCustomModels);
    localStorage.setItem('customCarModels', JSON.stringify(updatedCustomModels));
    
    // Update filtered makes
    setFilteredMakes(getAllMakes());
    
    // Clear vehicle make if it was the deleted custom make
    if (vehicle.make === makeName) {
      handleVehicleChange({ target: { name: 'make', value: '' } });
      handleVehicleChange({ target: { name: 'model', value: '' } });
      setAvailableModels([]);
    }
    
    toast.success(`Custom make "${makeName}" removed`);
  };
  
  // Remove custom model
  const removeCustomModel = (make: string, modelName: string) => {
    const updatedCustomModels = { ...customModels };
    if (updatedCustomModels[make]) {
      updatedCustomModels[make] = updatedCustomModels[make].filter(m => m.name !== modelName);
      if (updatedCustomModels[make].length === 0) {
        delete updatedCustomModels[make];
      }
      setCustomModels(updatedCustomModels);
      localStorage.setItem('customCarModels', JSON.stringify(updatedCustomModels));
      
      // Update available models
      setAvailableModels(getAllModelsForMake(vehicle.make));
      
      // Clear vehicle model if it was the deleted custom model
      if (vehicle.model === modelName) {
        handleVehicleChange({ target: { name: 'model', value: '' } });
      }
      
      toast.success(`Custom model "${modelName}" removed`);
    }
  };

  // Get all makes (including custom ones)
  const getAllMakes = (): string[] => {
    const customMakeNames = customMakes.map(m => m.name);
    return [...carMakes, ...customMakeNames];
  };
  
  // Check if a make is recently added (within last 7 days)
  const isRecentlyAdded = (timestamp: number): boolean => {
    const sevenDaysAgo = Date.now() - (7 * 24 * 60 * 60 * 1000);
    return timestamp > sevenDaysAgo;
  };
  
  // Check if a make is custom
  const isCustomMakeEntry = (makeName: string): boolean => {
    return customMakes.some(m => m.name === makeName);
  };
  
  // Get timestamp for custom make
  const getCustomMakeTimestamp = (makeName: string): number | null => {
    const customMake = customMakes.find(m => m.name === makeName);
    return customMake ? customMake.addedAt : null;
  };

  // Get all models for a make (including custom ones)
  const getAllModelsForMake = (make: string): string[] => {
    const standardModels = carModels[make] || [];
    const savedCustomModels = customModels[make] || [];
    const customModelNames = savedCustomModels.map(m => m.name);
    return [...standardModels, ...customModelNames];
  };
  
  // Check if a model is custom
  const isCustomModelEntry = (make: string, modelName: string): boolean => {
    return customModels[make]?.some(m => m.name === modelName) || false;
  };
  
  // Get timestamp for custom model
  const getCustomModelTimestamp = (make: string, modelName: string): number | null => {
    const customModel = customModels[make]?.find(m => m.name === modelName);
    return customModel ? customModel.addedAt : null;
  };
  
  // Handle first name input change with debouncing
  const handleFirstNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    
    // First update the field value
    handleCustomerChange(e);
    
    // Clear any existing timeouts
    if (searchTimeoutRef.current) {
      clearTimeout(searchTimeoutRef.current);
    }
    if (hideDropdownTimeoutRef.current) {
      clearTimeout(hideDropdownTimeoutRef.current);
    }
    
    // Reset states
    setSearchError(null);
    setNoResults(false);
    
    // Don't search if value is too short
    if (!value || value.length < 2) {
      setSuggestions([]);
      setShowDropdown(false);
      return;
    }
    
    // Set a new timeout (debounce)
    searchTimeoutRef.current = setTimeout(() => {
      searchForCustomers(value);
    }, 500);
  };
  
  // Function to search for customers
  const searchForCustomers = async (searchTerm: string) => {
    setIsLoading(true);
    setNoResults(false);
    setSearchError(null);
    
    try {
      // Get all customers and filter client-side since backend doesn't support search
      const response = await api.get("/api/customers");
      
      let customers: CustomerSuggestion[] = [];
      
      // Handle the response properly
      if (Array.isArray(response)) {
        customers = response;
      }
      
      // Filter customers by search term
      if (customers.length > 0) {
        customers = customers.filter((customer: CustomerSuggestion) => 
          customer.first_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          customer.last_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          customer.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          customer.phone?.includes(searchTerm)
        );
      }
      
      if (customers.length > 0) {
        setSuggestions(customers);
        setShowDropdown(true);
        setNoResults(false);
      } else {
        setSuggestions([]);
        setShowDropdown(false);
        setNoResults(true);
        
        // Set timeout to hide "No results" message after 10 seconds
        // hideDropdownTimeoutRef.current = setTimeout(() => {
        //   setNoResults(false);
        // }, 10000);
      }
    } catch (error) {
      console.error("Search error:", error);
      setSearchError(`Error searching: ${error instanceof Error ? error.message : String(error)}`);
      setSuggestions([]);
      setShowDropdown(false);
    } finally {
      setIsLoading(false);
    }
  };
  
  // Function to select a customer from dropdown
  const selectCustomer = (selectedCustomer: CustomerSuggestion) => {
    console.log('Selected customer:', selectedCustomer);
    console.log('Customer vehicles:', selectedCustomer.vehicles);
    
    setShowDropdown(false);
    setSuggestions([]);
    setCurrentCustomerSelection(selectedCustomer);
    
    // Update customer data
    updateCustomerData({
      first_name: selectedCustomer.first_name,
      last_name: selectedCustomer.last_name,
      phone: selectedCustomer.phone,
      email: selectedCustomer.email,
      city: selectedCustomer.city,
      country: selectedCustomer.country,
      branch: selectedCustomer.branch
    });
    
    // Update phone without code
    for (const [, code] of Object.entries(countryCodes)) {
      if (selectedCustomer.phone?.startsWith(code)) {
        setPhoneWithoutCode(selectedCustomer.phone.substring(code.length));
        break;
      }
    }
    
    // Check if customer has vehicles
    if (selectedCustomer.vehicles && selectedCustomer.vehicles.length > 0) {
      console.log('Setting customer vehicles:', selectedCustomer.vehicles);
      setSelectedCustomerVehicles([...selectedCustomer.vehicles]); // Create a copy to avoid reference issues
      setShowVehicleModal(true);
    } else {
      // Only select the customer if they have no vehicles
      selectExistingCustomer(selectedCustomer, true);
    }
  };
  
  // Function to select a vehicle from the modal
  const selectVehicle = (selectedVehicle: VehicleType, vehicleIndex: number) => {
    console.log('=== SELECTING VEHICLE ===');
    console.log('Vehicle index:', vehicleIndex);
    console.log('Selected vehicle data:', selectedVehicle);
    console.log('All available vehicles:', selectedCustomerVehicles);
    
    // Clear the form first to avoid stale data
    handleVehicleChange({ target: { name: "make", value: "" } });
    handleVehicleChange({ target: { name: "model", value: "" } });
    handleVehicleChange({ target: { name: "year", value: "" } });
    handleVehicleChange({ target: { name: "license_plate", value: "" } });
    handleVehicleChange({ target: { name: "vin", value: "" } });
    handleVehicleChange({ target: { name: "color", value: "" } });
    handleVehicleChange({ target: { name: "vehicle_type", value: "" } });
    
    // Use setTimeout to ensure the clear happens before setting new values
    setTimeout(() => {
      console.log('Setting new vehicle data...');
      
      // Update vehicle data with selected vehicle
      handleVehicleChange({
        target: { name: "make", value: selectedVehicle.make || "" }
      });
      handleVehicleChange({
        target: { name: "model", value: selectedVehicle.model || "" }
      });
      handleVehicleChange({
        target: { name: "year", value: selectedVehicle.year || "" }
      });
      handleVehicleChange({
        target: { name: "license_plate", value: selectedVehicle.license_plate || "" }
      });
      handleVehicleChange({
        target: { name: "vin", value: selectedVehicle.vin || "" }
      });
      handleVehicleChange({
        target: { name: "color", value: selectedVehicle.color || "" }
      });
      handleVehicleChange({
        target: { name: "vehicle_type", value: selectedVehicle.vehicle_type || "" }
      });
      
      // Set license plate country based on vehicle
      if (selectedVehicle.license_plate_country) {
        setLicensePlateCountry(selectedVehicle.license_plate_country);
        handleVehicleChange({
          target: { name: "license_plate_country", value: selectedVehicle.license_plate_country }
        });
      }
      
      console.log('Vehicle data set successfully');
    }, 50);
    
    // Select the customer after selecting a vehicle (with auto-fill enabled)
    if (currentCustomerSelection) {
      selectExistingCustomer(currentCustomerSelection, true);
    }
    
    // Close the modal
    setShowVehicleModal(false);
  };
  
  // Handle make selection
  const handleMakeDropdownSelect = (make: string) => {
    if (make === "Other") {
      setIsCustomMake(true);
      handleVehicleChange({
        target: { name: "make", value: "" }
      });
      // Clear model when switching to custom make
      handleVehicleChange({
        target: { name: "model", value: "" }
      });
      setAvailableModels([]);
    } else {
      handleMakeSelect(make);
      handleVehicleChange({
        target: { name: "make", value: make }
      });
      setIsCustomMake(false);
      setAvailableModels(getAllModelsForMake(make));
      // Clear model when make changes
      handleVehicleChange({
        target: { name: "model", value: "" }
      });
    }
    setShowMakeDropdown(false);
  };

  // Handle custom make input
  const handleCustomMakeInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    handleVehicleChange(e);
    // Clear validation error when user types
    if (formErrors.make) {
      setFormErrors(prev => ({ ...prev, make: '' }));
    }
  };

  // Validate custom make/model input
  const validateCustomEntry = (value: string, type: 'make' | 'model'): string | null => {
    const trimmed = value.trim();
    
    if (!trimmed) {
      return `${type === 'make' ? 'Make' : 'Model'} cannot be empty`;
    }
    
    if (trimmed.length < 2) {
      return `${type === 'make' ? 'Make' : 'Model'} must be at least 2 characters`;
    }
    
    if (trimmed.length > 50) {
      return `${type === 'make' ? 'Make' : 'Model'} must be less than 50 characters`;
    }
    
    // Allow letters, numbers, spaces, hyphens, and common special characters in car names
    const validPattern = /^[a-zA-Z0-9\s\-\.&]+$/;
    if (!validPattern.test(trimmed)) {
      return `${type === 'make' ? 'Make' : 'Model'} can only contain letters, numbers, spaces, hyphens, periods, and ampersands`;
    }
    
    // Check for duplicates (case-insensitive)
    if (type === 'make') {
      const allMakes = getAllMakes();
      if (allMakes.some(m => m.toLowerCase() === trimmed.toLowerCase())) {
        return 'This make already exists';
      }
    } else {
      const allModels = getAllModelsForMake(vehicle.make);
      if (allModels.some(m => m.toLowerCase() === trimmed.toLowerCase())) {
        return 'This model already exists';
      }
    }
    
    return null;
  };

  // Handle custom make blur (save custom make)
  const handleCustomMakeBlur = () => {
    if (vehicle.make && isCustomMake) {
      const trimmedMake = vehicle.make.trim();
      const validationError = validateCustomEntry(trimmedMake, 'make');
      
      if (validationError) {
        setFormErrors(prev => ({ ...prev, make: validationError }));
        // Don't save if validation fails
        return;
      }
      
      // Clear any previous validation errors
      setFormErrors(prev => ({ ...prev, make: '' }));
      
      saveCustomMake(trimmedMake);
      setIsCustomMake(false);
      // Update filtered makes to include the new custom make
      setFilteredMakes(getAllMakes());
      // Reset available models for the new custom make
      setAvailableModels([]);
      
      // Show success message
      toast.success(`Custom make "${trimmedMake}" added successfully`);
    }
  };
  
  // Handle model selection
  const handleModelDropdownSelect = (model: string) => {
    if (model === "Other") {
      setIsCustomModel(true);
      handleVehicleChange({
        target: { name: "model", value: "" }
      });
    } else {
      handleVehicleChange({
        target: { name: "model", value: model }
      });
      setIsCustomModel(false);
    }
    setShowModelDropdown(false);
  };

  // Handle custom model input
  const handleCustomModelInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    handleVehicleChange(e);
    // Clear validation error when user types
    if (formErrors.model) {
      setFormErrors(prev => ({ ...prev, model: '' }));
    }
  };

  // Handle custom model blur (save custom model)
  const handleCustomModelBlur = () => {
    if (vehicle.model && vehicle.make && isCustomModel) {
      const trimmedModel = vehicle.model.trim();
      const validationError = validateCustomEntry(trimmedModel, 'model');
      
      if (validationError) {
        setFormErrors(prev => ({ ...prev, model: validationError }));
        // Don't save if validation fails
        return;
      }
      
      // Clear any previous validation errors
      setFormErrors(prev => ({ ...prev, model: '' }));
      
      saveCustomModel(vehicle.make, trimmedModel);
      setIsCustomModel(false);
      // Update available models to include the new custom model
      setAvailableModels(getAllModelsForMake(vehicle.make));
      
      // Show success message
      toast.success(`Custom model "${trimmedModel}" added successfully`);
    }
  };
  
  // Handle phone number changes
  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPhoneWithoutCode(e.target.value);
    
    const countryCode = countryCodes[customer.country] || "971";
    handleCustomerChange({
      target: {
        name: "phone",
        value: countryCode + e.target.value
      }
    });
  };
  
  // Handle country changes and update phone
  const handleCountryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newCountry = e.target.value;
    handleCustomerChange(e as React.ChangeEvent<HTMLInputElement | HTMLSelectElement>);
    
    // Clear city selection when country changes
    handleCustomerChange({
      target: {
        name: "city",
        value: ""
      }
    });
    
    const newCountryCode = countryCodes[newCountry] || "971";
    handleCustomerChange({
      target: {
        name: "phone",
        value: newCountryCode + phoneWithoutCode
      }
    });
  };
  
  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (firstNameInputRef.current && !firstNameInputRef.current.contains(e.target as Node)) {
        // Check if clicking outside the entire first name input area
        const target = e.target as Element;
        const isClickingOnDropdown = target.closest('.customer-search-dropdown');
        
        if (!isClickingOnDropdown) {
          setShowDropdown(false);
          setNoResults(false); // Also hide "No customers found" message
        }
      }
    };
    
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      if (searchTimeoutRef.current) {
        clearTimeout(searchTimeoutRef.current);
      }
      if (hideDropdownTimeoutRef.current) {
        clearTimeout(hideDropdownTimeoutRef.current);
      }
    };
  }, []);
  
  // Initialize filtered makes with all makes including custom ones
  useEffect(() => {
    setFilteredMakes(getAllMakes());
  }, [customMakes]);

  // Update availableModels when vehicle.make changes
  useEffect(() => {
    if (vehicle.make) {
      setAvailableModels(getAllModelsForMake(vehicle.make));
    } else {
      setAvailableModels([]);
    }
  }, [vehicle.make, customModels]);

  // Effect to update phone number when country changes
  useEffect(() => {
    if (phoneWithoutCode && customer.country) {
      const countryCode = countryCodes[customer.country] || "971";
      handleCustomerChange({
        target: {
          name: "phone",
          value: countryCode + phoneWithoutCode
        }
      });
    }
  }, [customer.country]);

  // Effect to fetch branches on component mount
  useEffect(() => {
    const fetchBranches = async () => {
      setLoadingBranches(true);
      try {
        const response = await api.get("/api/branches");
        console.log("Branches API response:", response);
        
        // Handle different response structures
        if (response) {
          // If response has a data property
          const branchesData = response.data || response;
          
          if (Array.isArray(branchesData)) {
            setBranches(branchesData);
            console.log("Set branches:", branchesData);
          } else if (branchesData.branches && Array.isArray(branchesData.branches)) {
            // If branches are nested in a branches property
            setBranches(branchesData.branches);
            console.log("Set branches from nested structure:", branchesData.branches);
          } else {
            console.error("Unexpected branches response structure:", branchesData);
          }
        }
      } catch (error) {
        console.error("Error fetching branches:", error);
      } finally {
        setLoadingBranches(false);
      }
    };

    fetchBranches();
  }, []);

  // Effect to automatically set license plate country based on branch
  useEffect(() => {
    if (customer.branch?.branch_name) {
      const branchName = customer.branch.branch_name.toLowerCase();
      const selectedBranch = branches.find(b => b._id === customer.branch?.branch_id);
      const branchLocation = selectedBranch?.location?.toLowerCase() || branchName;
      
      // Check branch location and set appropriate license plate country
      if (branchLocation.includes('riyadh') || branchLocation.includes('riyad') || 
          branchLocation.includes('dammam') || branchLocation.includes('jeddah') ||
          branchLocation.includes('saudi') || branchLocation.includes('ksa')) {
        setLicensePlateCountry("Saudi Arabia");
        handleVehicleChange({
          target: {
            name: "license_plate_country",
            value: "Saudi Arabia"
          }
        });
      } else if (branchLocation.includes('amman') || branchLocation.includes('jordan') ||
                 branchLocation.includes('zarqa') || branchLocation.includes('irbid')) {
        setLicensePlateCountry("Jordan");
        handleVehicleChange({
          target: {
            name: "license_plate_country",
            value: "Jordan"
          }
        });
      } else if (branchLocation.includes('kuwait') || branchLocation.includes('kw')) {
        setLicensePlateCountry("Kuwait");
        handleVehicleChange({
          target: {
            name: "license_plate_country",
            value: "Kuwait"
          }
        });
      } else if (branchLocation.includes('damascus') || branchLocation.includes('syria') ||
                 branchLocation.includes('aleppo') || branchLocation.includes('homs')) {
        setLicensePlateCountry("Syria");
        handleVehicleChange({
          target: {
            name: "license_plate_country",
            value: "Syria"
          }
        });
      } else if (branchLocation.includes('muscat') || branchLocation.includes('oman') ||
                 branchLocation.includes('salalah') || branchLocation.includes('sohar')) {
        setLicensePlateCountry("Oman");
        handleVehicleChange({
          target: {
            name: "license_plate_country",
            value: "Oman"
          }
        });
      } else if (branchLocation.includes('khartoum') || branchLocation.includes('sudan') ||
                 branchLocation.includes('omdurman') || branchLocation.includes('port sudan')) {
        setLicensePlateCountry("Sudan");
        handleVehicleChange({
          target: {
            name: "license_plate_country",
            value: "Sudan"
          }
        });
      } else {
        // Default to UAE
        setLicensePlateCountry("UAE");
        handleVehicleChange({
          target: {
            name: "license_plate_country",
            value: "UAE"
          }
        });
      }
      
      // Clear license plate when branch changes to avoid format conflicts
      handleVehicleChange({
        target: {
          name: "license_plate",
          value: ""
        }
      });
    }
  }, [customer.branch, branches]);

  // Validate form fields
  const validateForm = () => {
    const errors: {[key: string]: string} = {};

    // Registration type validation
    if (!registrationType) errors.registrationType = "Please select a registration type (Work Order or Quotation)";

    // Customer validation
    if (!customer.first_name) errors.first_name = "First name is required";
    if (!customer.last_name) errors.last_name = "Last name is required";
    if (!customer.phone || phoneWithoutCode === "") errors.phone = "Phone number is required";
    // Email is optional - no validation needed
    if (!customer.city) errors.city = "City is required";
    if (!customer.country) errors.country = "Country is required";
    if (!customer.branch?.branch_id || !customer.branch?.branch_name) errors.branch = "Branch is required";

    // Vehicle validation
    if (!vehicle.make) errors.make = "Make is required";
    if (!vehicle.model) errors.model = "Model is required";
    // Year is now optional - no validation needed
    if (!vehicle.license_plate) errors.license_plate = "License plate is required";
    if (!vehicle.color) errors.color = "Color is required";
    if (!vehicle.vehicle_type) errors.vehicle_type = "Vehicle type is required";
    if (imagePreviews.length === 0) errors.vehicleImage = "At least one vehicle image is required";

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };
  
  // Handle next step with validation
  const validateAndProceed = () => {
    setAttemptedSubmit(true);
    if (validateForm()) {
      handleNextStep();
    } else {
      const firstErrorField = document.querySelector('[data-error="true"]');
      if (firstErrorField) {
        firstErrorField.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }
  };
  
  return (
    <div>
      {searchError && (
        <div className="mb-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative">
          <strong className="font-bold">Error:</strong>
          <span className="block sm:inline"> {searchError}</span>
        </div>
      )}
      
      {attemptedSubmit && Object.keys(formErrors).length > 0 && (
        <div className="mb-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative">
          <strong className="font-bold">Please correct the following errors:</strong>
          <ul className="mt-2 list-disc pl-5">
            {Object.values(formErrors).map((error, index) => (
              <li key={index}>{error}</li>
            ))}
          </ul>
        </div>
      )}

      {/* Registration Type Selection */}
      <div className={`mb-8 bg-gradient-to-r from-blue-50 to-indigo-50 p-6 rounded-lg border ${
        formErrors.registrationType && attemptedSubmit ? 'border-red-500 bg-red-50' : 'border-blue-200'
      }`}>
        <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
          <svg className="w-6 h-6 text-blue-600 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v4a2 2 0 002 2h2m6-6V4a2 2 0 00-2-2H9a2 2 0 00-2 2v1m6 0a2 2 0 012 2v4a2 2 0 01-2 2H9a2 2 0 01-2-2V7a2 2 0 012-2h4z" />
          </svg>
          Registration Type
        </h2>
        <p className="text-gray-600 mb-4">Choose what you want to create:</p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Work Order Option */}
          <button
            type="button"
            onClick={() => setRegistrationType('work_order')}
            className={`p-4 border-2 rounded-lg transition-all text-left ${
              registrationType === 'work_order'
                ? 'border-blue-500 bg-blue-100 text-blue-800'
                : 'border-gray-300 bg-white hover:border-blue-300 hover:bg-blue-50'
            }`}
          >
            <div className="flex items-center mb-2">
              <svg className="w-6 h-6 text-blue-600 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
              <span className="font-semibold">Create Work Order</span>
            </div>
            <p className="text-sm text-gray-600">
              Full registration with work order, job tracking, supervisor assignment, and invoice generation
            </p>
          </button>

          {/* Quotation Option */}
          <button
            type="button"
            onClick={() => setRegistrationType('quotation')}
            className={`p-4 border-2 rounded-lg transition-all text-left ${
              registrationType === 'quotation'
                ? 'border-green-500 bg-green-100 text-green-800'
                : 'border-gray-300 bg-white hover:border-green-300 hover:bg-green-50'
            }`}
          >
            <div className="flex items-center mb-2">
              <svg className="w-6 h-6 text-green-600 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              <span className="font-semibold">Generate Quotation</span>
            </div>
            <p className="text-sm text-gray-600">
              Create a price quote/quotation PDF without full work order setup - perfect for estimates
            </p>
          </button>
        </div>

        {formErrors.registrationType && attemptedSubmit && (
          <div className="mt-4 p-3 bg-red-100 border border-red-400 rounded">
            <div className="flex items-center">
              <svg className="w-5 h-5 text-red-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <span className="text-sm font-medium text-red-700">
                {formErrors.registrationType}
              </span>
            </div>
          </div>
        )}

        {registrationType && !formErrors.registrationType && (
          <div className="mt-4 p-3 bg-white rounded border-l-4 border-blue-500">
            <div className="flex items-center">
              <svg className="w-5 h-5 text-blue-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              <span className="text-sm font-medium text-gray-700">
                Selected: {registrationType === 'work_order' ? 'Work Order Creation' : 'Quotation Generation'}
              </span>
            </div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 lg:gap-8">
        {/* Customer Information */}
        <div className="bg-white p-6 lg:p-8 rounded-lg shadow-md">
          <h2 className="text-xl lg:text-2xl font-semibold mb-6 text-gray-900">{t('customerInformation')}</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-6">
            {/* First Name with Search */}
            <div className="relative">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {t('firstName')} *
              </label>
              <input
                type="text"
                name="first_name"
                value={customer.first_name}
                onChange={handleFirstNameChange}
                onBlur={() => {
                  // Hide "No results" message when input loses focus
                  setTimeout(() => setNoResults(false), 50);
                }}
                className={`w-full p-2 border ${formErrors.first_name && attemptedSubmit ? 'border-red-500' : 'border-gray-300'} rounded`}
                required
                ref={firstNameInputRef}
                data-error={!!formErrors.first_name && attemptedSubmit}
              />
              {formErrors.first_name && attemptedSubmit && (
                <p className="text-red-500 text-xs mt-1">{formErrors.first_name}</p>
              )}
              
              {/* Loading indicator */}
              {isLoading && (
                <div className="absolute z-10 mt-1 w-full bg-white shadow-lg border rounded-md p-3">
                  <div className="flex items-center">
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-blue-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    <span className="text-gray-600">{t('loading')}...</span>
                  </div>
                </div>
              )}
              
              {/* No results message */}
              {noResults && !isLoading && (
                <div className="absolute z-10 mt-1 w-full bg-white shadow-lg border rounded-md customer-search-dropdown">
                  <div className="p-2 text-gray-600">
                    {t('noCustomersFound')}
                  </div>
                </div>
              )}
              
              {/* Search results dropdown */}
              {suggestions.length > 0 && showDropdown && (
                <div 
                  ref={customerDropdownRef}
                  className="absolute z-20 mt-1 w-full min-w-[400px] bg-white shadow-lg border rounded-md overflow-hidden max-h-80 overflow-y-auto customer-search-dropdown"
                >
                  <div className="p-2 bg-gray-50 border-b border-gray-200">
                    <h3 className="text-xs font-medium text-gray-500 uppercase">Search Results</h3>
                  </div>
                  <ul className="divide-y divide-gray-200">
                    {suggestions.map((suggestion, index) => (
                      <li key={index} className="hover:bg-blue-50 transition-colors">
                        <div 
                          className="w-full px-4 py-3 flex items-center cursor-pointer"
                          onClick={() => selectCustomer(suggestion)}
                        >
                          <div className="flex-shrink-0 bg-blue-100 text-blue-600 rounded-full h-10 w-10 flex items-center justify-center font-bold mr-4">
                            {suggestion.first_name?.charAt(0) || "?"}
                          </div>
                          <div className="flex-1">
                            <p className="text-sm font-medium text-gray-900">
                              {suggestion.first_name} {suggestion.last_name}
                            </p>
                            {suggestion.phone && (
                              <p className="text-xs text-gray-500 mt-1">
                                <span className="inline-block w-4">📱</span> {suggestion.phone}
                              </p>
                            )}
                          </div>
                          <button
                            type="button"
                            className="ml-4 bg-green-500 hover:bg-green-600 text-white text-sm py-1 px-3 rounded transition-colors flex-shrink-0"
                          >
                            Select
                          </button>
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
            
            {/* Last Name */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {t('lastName')} *
              </label>
              <input
                type="text"
                name="last_name"
                value={customer.last_name}
                onChange={handleCustomerChange}
                className={`w-full p-2 border ${formErrors.last_name && attemptedSubmit ? 'border-red-500' : 'border-gray-300'} rounded`}
                required
                data-error={!!formErrors.last_name && attemptedSubmit}
              />
              {formErrors.last_name && attemptedSubmit && (
                <p className="text-red-500 text-xs mt-1">{formErrors.last_name}</p>
              )}
            </div>
            
            {/* Phone with Country Code Selector */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {t('phone')} *
              </label>
              <div className="flex space-x-1">
                <div className="w-2/5">
                  <div className="relative">
                    <select 
                      name="country"
                      value={customer.country}
                      onChange={handleCountryChange}
                      className={`w-full p-2 border ${formErrors.country && attemptedSubmit ? 'border-red-500' : 'border-gray-300'} rounded appearance-none pr-8`}
                      required
                      data-error={!!formErrors.country && attemptedSubmit}
                    >
                      <option value="">{t('selectCountry')}</option>
                      {countries.map((country) => (
                        <option key={country} value={country}>
                          +{countryCodes[country]} {country}
                        </option>
                      ))}
                    </select>
                    <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                      <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                        <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
                      </svg>
                    </div>
                  </div>
                </div>
                <div className="w-3/5">
                  <input
                    type="text"
                    name="phoneNumber"
                    value={phoneWithoutCode}
                    onChange={handlePhoneChange}
                    placeholder="Phone number"
                    className={`w-full p-2 border ${formErrors.phone && attemptedSubmit ? 'border-red-500' : 'border-gray-300'} rounded`}
                    required
                    data-error={!!formErrors.phone && attemptedSubmit}
                  />
                </div>
              </div>
              {formErrors.phone && attemptedSubmit && (
                <p className="text-red-500 text-xs mt-1">{formErrors.phone}</p>
              )}
              <p className="text-xs text-gray-500 mt-1">
                Full number: +{countryCodes[customer.country] || "971"} {phoneWithoutCode}
              </p>
            </div>
            
            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {t('email')}
              </label>
              <input
                type="email"
                name="email"
                value={customer.email}
                onChange={handleCustomerChange}
                className="w-full p-2 border border-gray-300 rounded"
                placeholder="Enter email address (optional)"
              />
            </div>
            
            {/* City/State Dropdown or Input */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {t('city')} *
              </label>
              {customer.country === "UAE" ? (
                <select
                  name="city"
                  value={customer.city}
                  onChange={handleCustomerChange}
                  className={`w-full p-2 border ${formErrors.city && attemptedSubmit ? 'border-red-500' : 'border-gray-300'} rounded`}
                  required
                  data-error={!!formErrors.city && attemptedSubmit}
                >
                  <option value="">{t('selectCity')}</option>
                  {(locationsByCountry["UAE"] || []).map((location) => (
                    <option key={location} value={location}>
                      {location}
                    </option>
                  ))}
                </select>
              ) : (
                <input
                  type="text"
                  name="city"
                  value={customer.city}
                  onChange={handleCustomerChange}
                  placeholder={t('city')}
                  className={`w-full p-2 border ${formErrors.city && attemptedSubmit ? 'border-red-500' : 'border-gray-300'} rounded`}
                  required
                  data-error={!!formErrors.city && attemptedSubmit}
                />
              )}
              {formErrors.city && attemptedSubmit && (
                <p className="text-red-500 text-xs mt-1">{formErrors.city}</p>
              )}
            </div>
            
            {/* Country Dropdown */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {t('country')} *
              </label>
              <select
                name="country"
                value={customer.country}
                onChange={handleCountryChange}
                className={`w-full p-2 border ${formErrors.country && attemptedSubmit ? 'border-red-500' : 'border-gray-300'} rounded`}
                required
                data-error={!!formErrors.country && attemptedSubmit}
              >
                <option value="">{t('selectCountry')}</option>
                {countries.map((country) => (
                  <option key={country} value={country}>
                    {country}
                  </option>
                ))}
              </select>
              {formErrors.country && attemptedSubmit && (
                <p className="text-red-500 text-xs mt-1">{formErrors.country}</p>
              )}
            </div>
            
            {/* Branch Selector */}
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {t('branch')} *
              </label>
              {loadingBranches ? (
                <div className="w-full p-2 border border-gray-300 rounded flex items-center justify-center">
                  <svg className="animate-spin h-5 w-5 text-blue-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  <span className="ml-2 text-gray-600">{t('loading')}...</span>
                </div>
              ) : (
                <select
                  value={customer.branch?.branch_id || ""}
                  onChange={(e) => {
                    const selectedBranch = branches.find(b => b._id === e.target.value);
                    if (selectedBranch) {
                      updateCustomerData({
                        branch: {
                          branch_id: selectedBranch._id,
                          branch_name: selectedBranch.name || selectedBranch.branch_name || `Branch ${selectedBranch._id}`
                        }
                      });
                    } else {
                      updateCustomerData({
                        branch: undefined
                      });
                    }
                  }}
                  className={`w-full p-2 border ${formErrors.branch && attemptedSubmit ? 'border-red-500' : 'border-gray-300'} rounded`}
                  required
                  data-error={!!formErrors.branch && attemptedSubmit}
                >
                  <option value="">Select Branch</option>
                  {branches.map((branch) => (
                    <option key={branch._id} value={branch._id}>
                      {branch.name || branch.branch_name || `Branch ${branch._id}`}
                    </option>
                  ))}
                </select>
              )}
              {formErrors.branch && attemptedSubmit && (
                <p className="text-red-500 text-xs mt-1">{formErrors.branch}</p>
              )}
            </div>
          </div>
        </div>

        {/* Vehicle Information */}
        <div className="bg-white p-6 lg:p-8 rounded-lg shadow-md">
          <h2 className="text-xl lg:text-2xl font-semibold mb-6 text-gray-900">{t('vehicleInformation')}</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-6">
            {/* Make with Searchable Dropdown */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {t('make')} *
              </label>
              <div className="relative">
                <input
                  type="text"
                  name="make"
                  value={vehicle.make}
                  onChange={isCustomMake ? handleCustomMakeInput : (e) => {
                    const value = e.target.value;
                    handleVehicleChange(e);
                    setFilteredMakes(
                      getAllMakes().filter(make => 
                        make.toLowerCase().includes(value.toLowerCase())
                      )
                    );
                    setShowMakeDropdown(true);
                  }}
                  onBlur={isCustomMake ? handleCustomMakeBlur : undefined}
                  onFocus={() => {
                    if (!isCustomMake) {
                      setShowMakeDropdown(true);
                      setFilteredMakes(
                        getAllMakes().filter(make => 
                          make.toLowerCase().includes(vehicle.make.toLowerCase())
                        )
                      );
                    }
                  }}
                  className={`w-full p-3 lg:p-4 border ${formErrors.make && attemptedSubmit ? 'border-red-500' : 'border-gray-300'} rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all`}
                  placeholder={isCustomMake ? "Enter custom make name..." : "Search make..."}
                  required
                  data-error={!!formErrors.make && attemptedSubmit}
                />
                {formErrors.make && attemptedSubmit && (
                  <p className="text-red-500 text-xs mt-1">{formErrors.make}</p>
                )}
                {showMakeDropdown && !isCustomMake && (
                  <div className="absolute z-50 mt-1 w-full bg-white shadow-lg border rounded-md max-h-60 overflow-auto">
                    <div className="p-2 bg-gray-50 border-b border-gray-200">
                      <h3 className="text-xs font-medium text-gray-500 uppercase">Select a Make</h3>
                    </div>
                    <ul className="divide-y divide-gray-200">
                      {filteredMakes.map((make, index) => {
                        const isCustom = isCustomMakeEntry(make);
                        const timestamp = getCustomMakeTimestamp(make);
                        const isRecent = timestamp ? isRecentlyAdded(timestamp) : false;
                        
                        return (
                          <li 
                            key={index} 
                            className="hover:bg-blue-50 transition-colors cursor-pointer group" 
                          >
                            <div className="w-full px-4 py-3 flex items-center justify-between">
                              <div 
                                className="flex-1 min-w-0 flex items-center gap-2"
                                onClick={() => handleMakeDropdownSelect(make)}
                              >
                                <p className="text-sm font-medium text-gray-900 truncate">
                                  {make}
                                </p>
                                {isCustom && (
                                  <span className={`text-xs px-2 py-0.5 rounded-full ${
                                    isRecent 
                                      ? 'bg-green-100 text-green-700' 
                                      : 'bg-gray-100 text-gray-600'
                                  }`}>
                                    {isRecent ? 'New' : 'Custom'}
                                  </span>
                                )}
                              </div>
                              {isCustom && (
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    removeCustomMake(make);
                                  }}
                                  className="opacity-0 group-hover:opacity-100 text-red-500 hover:text-red-700 p-1 transition-opacity"
                                  title="Remove custom make"
                                >
                                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                  </svg>
                                </button>
                              )}
                            </div>
                          </li>
                        );
                      })}
                      {/* Always show "Other" option - visible regardless of search */}
                      <li 
                        className="hover:bg-blue-50 transition-colors cursor-pointer border-t-2 border-gray-300"
                        onClick={() => handleMakeDropdownSelect("Other")}
                      >
                        <div className="w-full px-4 py-3 flex items-center">
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-blue-600 truncate">
                              + Add Custom Make
                            </p>
                          </div>
                        </div>
                      </li>
                    </ul>
                  </div>
                )}
              </div>
            </div>
            
            {/* Model with Searchable Dropdown */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {t('model')} *
              </label>
              <div className="relative">
                <input
                  type="text"
                  name="model"
                  value={vehicle.model}
                  onChange={isCustomModel ? handleCustomModelInput : (e) => {
                    handleVehicleChange(e);
                    setShowModelDropdown(true);
                  }}
                  onBlur={isCustomModel ? handleCustomModelBlur : undefined}
                  onFocus={() => {
                    if (vehicle.make && !isCustomModel) {
                      setShowModelDropdown(true);
                    }
                  }}
                  className={`w-full p-2 border ${formErrors.model && attemptedSubmit ? 'border-red-500' : 'border-gray-300'} rounded`}
                  placeholder={
                    isCustomModel 
                      ? "Enter custom model name..." 
                      : vehicle.make 
                        ? "Search model..." 
                        : "Select make first"
                  }
                  disabled={!vehicle.make}
                  required
                  data-error={!!formErrors.model && attemptedSubmit}
                />
                {formErrors.model && attemptedSubmit && (
                  <p className="text-red-500 text-xs mt-1">{formErrors.model}</p>
                )}
                {showModelDropdown && vehicle.make && !isCustomModel && (
                  <div className="absolute z-50 mt-1 w-full bg-white shadow-lg border rounded-md max-h-60 overflow-auto">
                    <div className="p-2 bg-gray-50 border-b border-gray-200">
                      <h3 className="text-xs font-medium text-gray-500 uppercase">Select a Model</h3>
                    </div>
                    <ul className="divide-y divide-gray-200">
                      {availableModels
                        .filter(model => 
                          model.toLowerCase().includes(vehicle.model.toLowerCase())
                        )
                        .map((model, index) => {
                          const isCustom = isCustomModelEntry(vehicle.make, model);
                          const timestamp = getCustomModelTimestamp(vehicle.make, model);
                          const isRecent = timestamp ? isRecentlyAdded(timestamp) : false;
                          
                          return (
                            <li 
                              key={index} 
                              className="hover:bg-blue-50 transition-colors cursor-pointer group"
                            >
                              <div className="w-full px-4 py-3 flex items-center justify-between">
                                <div 
                                  className="flex-1 min-w-0 flex items-center gap-2"
                                  onClick={() => handleModelDropdownSelect(model)}
                                >
                                  <p className="text-sm font-medium text-gray-900 truncate">
                                    {model}
                                  </p>
                                  {isCustom && (
                                    <span className={`text-xs px-2 py-0.5 rounded-full ${
                                      isRecent 
                                        ? 'bg-green-100 text-green-700' 
                                        : 'bg-gray-100 text-gray-600'
                                    }`}>
                                      {isRecent ? 'New' : 'Custom'}
                                    </span>
                                  )}
                                </div>
                                {isCustom && (
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      removeCustomModel(vehicle.make, model);
                                    }}
                                    className="opacity-0 group-hover:opacity-100 text-red-500 hover:text-red-700 p-1 transition-opacity"
                                    title="Remove custom model"
                                  >
                                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                    </svg>
                                  </button>
                                )}
                              </div>
                            </li>
                          );
                        })}
                      {/* Always show "Other" option - visible regardless of search */}
                      <li 
                        className="hover:bg-blue-50 transition-colors cursor-pointer border-t-2 border-gray-300"
                        onClick={() => handleModelDropdownSelect("Other")}
                      >
                        <div className="w-full px-4 py-3 flex items-center">
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-blue-600 truncate">
                              + Add Custom Model
                            </p>
                          </div>
                        </div>
                      </li>
                    </ul>
                  </div>
                )}
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {t('year')}
              </label>
              <input
                type="number"
                name="year"
                value={vehicle.year}
                onChange={handleVehicleChange}
                className="w-full p-2 border border-gray-300 rounded"
                min="1920"
                max={new Date().getFullYear()}
                placeholder="Optional"
              />
            </div>
            
            {/* License Plate with Country and Region Selector - Full Width */}
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {t('licensePlate')} *
              </label>
              
              {/* Country Selector for License Plate */}
              <div className="mb-2">
                <label className="block text-xs font-medium text-gray-600 mb-1">
                  {t('plateCountry')}
                </label>
                <select
                  value={licensePlateCountry}
                  onChange={(e) => {
                    const newCountry = e.target.value;
                    setLicensePlateCountry(newCountry);
                    handleVehicleChange({
                      target: {
                        name: "license_plate_country",
                        value: newCountry
                      }
                    });
                    
                    // Clear the license plate when country changes
                    handleVehicleChange({
                      target: {
                        name: "license_plate",
                        value: ""
                      }
                    });
                  }}
                  className="w-full p-2 border border-gray-300 rounded"
                >
                  <option value="UAE">UAE</option>
                  <option value="Saudi Arabia">Saudi Arabia</option>
                  <option value="Jordan">Jordan</option>
                  <option value="Kuwait">Kuwait</option>
                  <option value="Oman">Oman</option>
                  <option value="Syria">Syria</option>
                  <option value="Sudan">Sudan</option>
                </select>
              </div>
              
              {/* License Plate Input based on Country */}
              <div className="flex space-x-2">
                {licensePlateCountry === "UAE" ? (
                  // UAE: Emirate Code Number (e.g., DXB A 12345)
                  <>
                    <select
                      onChange={(e) => {
                        const region = e.target.value;
                        handleRegionSelect(region);
                        const currentPlate = vehicle.license_plate.split(" ");
                        const newPlate = `${region} ${currentPlate[1] || ""} ${currentPlate[2] || ""}`.trim();
                        handleVehicleChange({
                          target: {
                            name: "license_plate",
                            value: newPlate
                          }
                        });
                      }}
                      className={`p-2 border ${formErrors.license_plate && attemptedSubmit ? 'border-red-500' : 'border-gray-300'} rounded w-1/4 font-mono bg-gray-100 text-center`}
                      required
                      value={vehicle.license_plate.split(" ")[0] || ""}
                    >
                      <option value="">Emirate</option>
                      {(plateRegionsByCountry["UAE"] || []).map((region) => (
                        <option key={region.code} value={region.code}>
                          {region.code}
                        </option>
                      ))}
                    </select>
                    <input
                      type="text"
                      placeholder="Code"
                      className={`w-1/4 p-2 border ${formErrors.license_plate && attemptedSubmit ? 'border-red-500' : 'border-gray-300'} rounded font-mono bg-gray-100 text-center`}
                      value={vehicle.license_plate.split(" ")[1] || ""}
                      onChange={(e) => {
                        const region = vehicle.license_plate.split(" ")[0] || "";
                        const number = vehicle.license_plate.split(" ")[2] || "";
                        const newPlate = `${region} ${e.target.value} ${number}`.trim();
                        handleVehicleChange({
                          target: {
                            name: "license_plate",
                            value: newPlate
                          }
                        });
                      }}
                      required
                    />
                    <input
                      type="text"
                      placeholder="Number"
                      className={`w-1/2 p-2 border ${formErrors.license_plate && attemptedSubmit ? 'border-red-500' : 'border-gray-300'} rounded font-mono bg-gray-100 text-center`}
                      value={vehicle.license_plate.split(" ")[2] || ""}
                      onChange={(e) => {
                        const region = vehicle.license_plate.split(" ")[0] || "";
                        const code = vehicle.license_plate.split(" ")[1] || "";
                        const newPlate = `${region} ${code} ${e.target.value}`.trim();
                        handleVehicleChange({
                          target: {
                            name: "license_plate",
                            value: newPlate
                          }
                        });
                      }}
                      required
                    />
                  </>
                ) : licensePlateCountry === "Saudi Arabia" ? (
                  // Saudi Arabia: KSA Code Number (e.g., KSA ABC 1234)
                  <>
                    <div className="p-2 border border-gray-300 rounded w-1/6 bg-gray-100 flex items-center justify-center font-mono">
                      <span className="text-sm font-medium">KSA</span>
                    </div>
                    <input
                      type="text"
                      placeholder="Code"
                      className={`w-1/3 p-2 border ${formErrors.license_plate && attemptedSubmit ? 'border-red-500' : 'border-gray-300'} rounded font-mono bg-gray-100 text-center`}
                      value={vehicle.license_plate.replace(/^KSA\s*/, "").split(" ")[0] || ""}
                      onChange={(e) => {
                        const currentPlate = vehicle.license_plate.replace(/^KSA\s*/, "");
                        const number = currentPlate.split(" ")[1] || "";
                        const newPlate = `KSA ${e.target.value} ${number}`.trim();
                        handleVehicleChange({
                          target: {
                            name: "license_plate",
                            value: newPlate
                          }
                        });
                      }}
                      required
                    />
                    <input
                      type="text"
                      placeholder="Number"
                      className={`flex-1 p-2 border ${formErrors.license_plate && attemptedSubmit ? 'border-red-500' : 'border-gray-300'} rounded font-mono bg-gray-100 text-center`}
                      value={vehicle.license_plate.replace(/^KSA\s*/, "").split(" ")[1] || ""}
                      onChange={(e) => {
                        const currentPlate = vehicle.license_plate.replace(/^KSA\s*/, "");
                        const code = currentPlate.split(" ")[0] || "";
                        const newPlate = `KSA ${code} ${e.target.value}`.trim();
                        handleVehicleChange({
                          target: {
                            name: "license_plate",
                            value: newPlate
                          }
                        });
                      }}
                      required
                    />
                  </>
                ) : licensePlateCountry === "Jordan" ? (
                  // Jordan: Just Number (e.g., 123456)
                  <>
                    <input
                      type="text"
                      placeholder="License Number"
                      className={`w-full p-2 border ${formErrors.license_plate && attemptedSubmit ? 'border-red-500' : 'border-gray-300'} rounded font-mono bg-gray-100 text-center`}
                      value={vehicle.license_plate}
                      onChange={(e) => {
                        handleVehicleChange({
                          target: {
                            name: "license_plate",
                            value: e.target.value
                          }
                        });
                      }}
                      required
                    />
                  </>
                ) : licensePlateCountry === "Kuwait" ? (
                  // Kuwait: Code Number (e.g., A 123456)
                  <>
                    <input
                      type="text"
                      placeholder="Code"
                      className={`w-1/3 p-2 border ${formErrors.license_plate && attemptedSubmit ? 'border-red-500' : 'border-gray-300'} rounded font-mono bg-gray-100 text-center`}
                      value={vehicle.license_plate.split(" ")[0] || ""}
                      onChange={(e) => {
                        const currentPlate = vehicle.license_plate.split(" ");
                        const newPlate = `${e.target.value} ${currentPlate[1] || ""}`.trim();
                        handleVehicleChange({
                          target: {
                            name: "license_plate",
                            value: newPlate
                          }
                        });
                      }}
                      required
                    />
                    <input
                      type="text"
                      placeholder="Number"
                      className={`flex-1 p-2 border ${formErrors.license_plate && attemptedSubmit ? 'border-red-500' : 'border-gray-300'} rounded font-mono bg-gray-100 text-center`}
                      value={vehicle.license_plate.split(" ")[1] || ""}
                      onChange={(e) => {
                        const code = vehicle.license_plate.split(" ")[0] || "";
                        const newPlate = `${code} ${e.target.value}`.trim();
                        handleVehicleChange({
                          target: {
                            name: "license_plate",
                            value: newPlate
                          }
                        });
                      }}
                      required
                    />
                  </>
                ) : licensePlateCountry === "Oman" ? (
                  // Oman: Code Number (e.g., A 123456)
                  <>
                    <input
                      type="text"
                      placeholder="Code"
                      className={`w-1/3 p-2 border ${formErrors.license_plate && attemptedSubmit ? 'border-red-500' : 'border-gray-300'} rounded font-mono bg-gray-100 text-center`}
                      value={vehicle.license_plate.split(" ")[0] || ""}
                      onChange={(e) => {
                        const currentPlate = vehicle.license_plate.split(" ");
                        const newPlate = `${e.target.value} ${currentPlate[1] || ""}`.trim();
                        handleVehicleChange({
                          target: {
                            name: "license_plate",
                            value: newPlate
                          }
                        });
                      }}
                      required
                    />
                    <input
                      type="text"
                      placeholder="Number"
                      className={`flex-1 p-2 border ${formErrors.license_plate && attemptedSubmit ? 'border-red-500' : 'border-gray-300'} rounded font-mono bg-gray-100 text-center`}
                      value={vehicle.license_plate.split(" ")[1] || ""}
                      onChange={(e) => {
                        const code = vehicle.license_plate.split(" ")[0] || "";
                        const newPlate = `${code} ${e.target.value}`.trim();
                        handleVehicleChange({
                          target: {
                            name: "license_plate",
                            value: newPlate
                          }
                        });
                      }}
                      required
                    />
                  </>
                ) : licensePlateCountry === "Syria" ? (
                  // Syria: Region [text input] Number (e.g., دمشق 123456)
                  <>
                    <input
                      type="text"
                      placeholder="Region"
                      className={`w-1/3 p-2 border ${formErrors.license_plate && attemptedSubmit ? 'border-red-500' : 'border-gray-300'} rounded font-mono bg-gray-100 text-center`}
                      value={vehicle.license_plate.split(" ")[0] || ""}
                      onChange={(e) => {
                        const currentPlate = vehicle.license_plate.split(" ");
                        const newPlate = `${e.target.value} ${currentPlate[1] || ""}`.trim();
                        handleVehicleChange({
                          target: {
                            name: "license_plate",
                            value: newPlate
                          }
                        });
                      }}
                      required
                    />
                    <input
                      type="text"
                      placeholder="Number"
                      className={`flex-1 p-2 border ${formErrors.license_plate && attemptedSubmit ? 'border-red-500' : 'border-gray-300'} rounded font-mono bg-gray-100 text-center`}
                      value={vehicle.license_plate.split(" ")[1] || ""}
                      onChange={(e) => {
                        const region = vehicle.license_plate.split(" ")[0] || "";
                        const newPlate = `${region} ${e.target.value}`.trim();
                        handleVehicleChange({
                          target: {
                            name: "license_plate",
                            value: newPlate
                          }
                        });
                      }}
                      required
                    />
                  </>
                ) : licensePlateCountry === "Sudan" ? (
                  // Sudan: State Code Number (e.g., KH 123456)
                  <>
                    <input
                      type="text"
                      placeholder="State Code"
                      className={`w-1/3 p-2 border ${formErrors.license_plate && attemptedSubmit ? 'border-red-500' : 'border-gray-300'} rounded font-mono bg-gray-100 text-center uppercase`}
                      value={vehicle.license_plate.split(" ")[0] || ""}
                      onChange={(e) => {
                        const currentPlate = vehicle.license_plate.split(" ");
                        const newPlate = `${e.target.value.toUpperCase()} ${currentPlate[1] || ""}`.trim();
                        handleVehicleChange({
                          target: {
                            name: "license_plate",
                            value: newPlate
                          }
                        });
                      }}
                      required
                    />
                    <input
                      type="text"
                      placeholder="Number"
                      className={`flex-1 p-2 border ${formErrors.license_plate && attemptedSubmit ? 'border-red-500' : 'border-gray-300'} rounded font-mono bg-gray-100 text-center`}
                      value={vehicle.license_plate.split(" ")[1] || ""}
                      onChange={(e) => {
                        const stateCode = vehicle.license_plate.split(" ")[0] || "";
                        const newPlate = `${stateCode} ${e.target.value}`.trim();
                        handleVehicleChange({
                          target: {
                            name: "license_plate",
                            value: newPlate
                          }
                        });
                      }}
                      required
                    />
                  </>
                ) : null}
              </div>
              {formErrors.license_plate && attemptedSubmit && (
                <p className="text-red-500 text-xs mt-1">{formErrors.license_plate}</p>
              )}
              <p className="text-xs text-gray-500 mt-1">
                {licensePlateCountry === "UAE" 
                  ? "Format: Emirate Code Number (e.g., DXB A 12345)" 
                  : licensePlateCountry === "Saudi Arabia"
                  ? "Format: KSA Code Number (e.g., KSA ABC 1234)"
                  : licensePlateCountry === "Jordan"
                  ? "Format: Number (e.g., 123456)"
                  : licensePlateCountry === "Kuwait"
                  ? "Format: Code Number (e.g., A 123456)"
                  : licensePlateCountry === "Oman"
                  ? "Format: Code Number (e.g., A 123456)"
                  : licensePlateCountry === "Syria"
                  ? "Format: Region Number (e.g., دمشق 123456)"
                  : licensePlateCountry === "Sudan"
                  ? "Format: State Code Number (e.g., KH 123456)"
                  : "Please select a country first"}
              </p>
              {/* License Plate Preview */}
              {vehicle.license_plate && (
                <div className="mt-3">
                  <p className="text-xs font-medium text-gray-600 mb-1">Preview:</p>
                  <div className="inline-block text-sm text-gray-900 font-mono bg-gray-100 px-3 py-2 rounded border border-gray-300 text-center">
                    {vehicle.license_plate}
                  </div>
                </div>
              )}
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {t('vin')}
              </label>
              <input
                type="text"
                name="vin"
                value={vehicle.vin}
                onChange={handleVehicleChange}
                className="w-full p-2 border border-gray-300 rounded"
                placeholder="Vehicle Identification Number (optional)"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {t('color')} *
              </label>
              {!isOtherColor ? (
                <select
                  name="color"
                  value={vehicle.color}
                  onChange={(e) => {
                    if (e.target.value === "Other") {
                      setIsOtherColor(true);
                      handleVehicleChange({
                        target: { name: "color", value: customColor }
                      });
                    } else {
                      handleVehicleChange(e);
                    }
                  }}
                  className={`w-full p-2 border ${formErrors.color && attemptedSubmit ? 'border-red-500' : 'border-gray-300'} rounded`}
                  required
                  data-error={!!formErrors.color && attemptedSubmit}
                >
                  <option value="">Select Color</option>
                  {carColors.map((color) => (
                    <option key={color} value={color}>
                      {color}
                    </option>
                  ))}
                </select>
              ) : (
                <div className="flex space-x-2">
                  <input
                    type="text"
                    name="color"
                    value={vehicle.color}
                    onChange={(e) => {
                      setCustomColor(e.target.value);
                      handleVehicleChange(e);
                    }}
                    placeholder="Enter custom color"
                    className={`flex-1 p-2 border ${formErrors.color && attemptedSubmit ? 'border-red-500' : 'border-gray-300'} rounded`}
                    required
                    data-error={!!formErrors.color && attemptedSubmit}
                  />
                  <button
                    type="button"
                    onClick={() => {
                      setIsOtherColor(false);
                      handleVehicleChange({
                        target: { name: "color", value: "" }
                      });
                    }}
                    className="px-3 py-2 bg-gray-300 hover:bg-gray-400 text-gray-700 rounded"
                  >
                    Back
                  </button>
                </div>
              )}
              {formErrors.color && attemptedSubmit && (
                <p className="text-red-500 text-xs mt-1">{formErrors.color}</p>
              )}
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {t('vehicleType')} *
              </label>
              <select
                name="vehicle_type"
                value={vehicle.vehicle_type}
                onChange={handleVehicleChange}
                className={`w-full p-2 border ${formErrors.vehicle_type && attemptedSubmit ? 'border-red-500' : 'border-gray-300'} rounded`}
                required
                data-error={!!formErrors.vehicle_type && attemptedSubmit}
              >
                <option value="">{t('selectVehicleType')}</option>
                <option value="Sedan">Sedan</option>
                <option value="SUV">SUV</option>
                <option value="Truck">Truck</option>
                <option value="Van">Van</option>
                <option value="Coupe">Coupe</option>
                <option value="Hatchback">Hatchback</option>
                <option value="Convertible">Convertible</option>
                <option value="Wagon">Wagon</option>
                <option value="Other">Other</option>
              </select>
              {formErrors.vehicle_type && attemptedSubmit && (
                <p className="text-red-500 text-xs mt-1">{formErrors.vehicle_type}</p>
              )}
            </div>
            
            {/* Vehicle Image Upload */}
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Vehicle Image *
              </label>
              <input
                type="file"
                accept="image/*"
                multiple
                onChange={handleImageChange}
                className={`w-full p-2 border ${formErrors.vehicleImage && attemptedSubmit ? 'border-red-500' : 'border-gray-300'} rounded`}
                data-error={!!formErrors.vehicleImage && attemptedSubmit}
              />
              {formErrors.vehicleImage && attemptedSubmit && (
                <p className="text-red-500 text-xs mt-1">{formErrors.vehicleImage}</p>
              )}
              <p className="text-xs text-gray-500 mt-1">
                Upload vehicle images (required) • Up to 5 images • Max file size: 5MB each
                {vehicleImages.length > 0 && (
                  <span className="font-medium text-blue-600">
                    {` • ${vehicleImages.length}/5 uploaded`}
                  </span>
                )}
              </p>
              
              {/* Image Previews */}
              {imagePreviews.length > 0 && (
                <div className="mt-4">
                  <p className="text-sm font-medium text-gray-700 mb-2">Vehicle Images:</p>
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
                    {imagePreviews.map((preview, index) => (
                      <div key={index} className="relative">
                        <img
                          src={preview}
                          alt={`Vehicle preview ${index + 1}`}
                          className="h-24 w-full object-cover rounded-lg border-2 border-gray-200"
                        />
                        <button
                          type="button"
                          onClick={() => handleRemoveImage(index)}
                          className="absolute -top-1 -right-1 bg-red-500 hover:bg-red-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold shadow-lg transition-colors"
                          title="Remove image"
                        >
                          ×
                        </button>
                        <p className="text-xs text-center text-gray-500 mt-1 truncate">
                          {vehicleImages[index]?.name}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Next Button */}
      <div className="mt-8 lg:mt-12 flex justify-end">
        <button
          onClick={validateAndProceed}
          className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-3 lg:py-4 px-8 lg:px-12 rounded-lg text-lg shadow-lg hover:shadow-xl transition-all duration-200 transform hover:-translate-y-0.5"
        >
          Next Step →
        </button>
      </div>
      
      {/* Vehicle Selection Modal */}
      {showVehicleModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-5xl w-full max-h-[85vh] overflow-hidden shadow-2xl">
            <div className="p-6 lg:p-8 border-b border-gray-200 bg-gradient-to-r from-blue-50 to-indigo-50">
              <h2 className="text-xl lg:text-2xl font-bold text-gray-900">Select a Vehicle</h2>
              <p className="text-gray-600 mt-2">Choose a vehicle to autofill the form or skip to enter a new vehicle</p>
            </div>
            <div className="p-6 overflow-y-auto max-h-[60vh]">
              <div className="space-y-3">
                {selectedCustomerVehicles.map((vehicle, index) => (
                  <div 
                    key={`vehicle-${index}-${vehicle.license_plate}-${vehicle.vin}`} 
                    className="border rounded-lg p-4 hover:bg-blue-50 cursor-pointer transition-colors"
                    onClick={() => selectVehicle(vehicle, index)}
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-semibold text-lg">{vehicle.make} {vehicle.model} (Vehicle #{index + 1})</h3>
                        {vehicle.year && <p className="text-gray-600">Year: {vehicle.year}</p>}
                        <p className="text-gray-600">License Plate: {vehicle.license_plate}</p>
                        <p className="text-gray-600">Color: {vehicle.color}</p>
                        <p className="text-gray-600">Type: {vehicle.vehicle_type}</p>
                        {vehicle.vin && <p className="text-gray-600">VIN: {vehicle.vin}</p>}
                      </div>
                      <button 
                        className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded text-sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          selectVehicle(vehicle, index);
                        }}
                      >
                        Select
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="p-6 border-t flex justify-between">
              <button 
                onClick={() => {
                  console.log("=== SKIP BUTTON CLICKED ===");
                  console.log("Current customer selection:", currentCustomerSelection);
                  
                  // Select the customer but keep vehicle form empty for new vehicle entry
                  if (currentCustomerSelection) {
                    console.log("About to clear vehicle form and select customer...");
                    
                    // Properly select the existing customer without auto-filling vehicle data
                    selectExistingCustomer(currentCustomerSelection, false);
                    
                    // Then clear vehicle form completely for new vehicle entry
                    setTimeout(() => {
                      console.log("Clearing vehicle form fields...");
                      handleVehicleChange({ target: { name: "make", value: "" } });
                      handleVehicleChange({ target: { name: "model", value: "" } });
                      handleVehicleChange({ target: { name: "year", value: "" } });
                      handleVehicleChange({ target: { name: "license_plate", value: "" } });
                      handleVehicleChange({ target: { name: "vin", value: "" } });
                      handleVehicleChange({ target: { name: "color", value: "" } });
                      handleVehicleChange({ target: { name: "vehicle_type", value: "" } });
                      handleVehicleChange({ target: { name: "license_plate_country", value: "UAE" } });
                      
                      // Reset license plate country to default
                      setLicensePlateCountry("UAE");
                      
                      console.log("Vehicle form cleared successfully");
                    }, 50);
                  }
                  setShowVehicleModal(false);
                  console.log("=== SKIP BUTTON COMPLETE ===");
                }}
                className="bg-gray-300 hover:bg-gray-400 text-gray-700 font-bold py-2 px-6 rounded"
              >
                Skip - Enter New Vehicle
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default StepOne;