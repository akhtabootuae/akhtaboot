import React from 'react';
import { Button } from '@/app/components/ui/button';
import { X, FileText, Wrench } from 'lucide-react';

interface QuotationDecisionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateWorkOrder: () => void;
  onPrintQuotation: () => void;
  isCreatingWorkOrder: boolean;
  isPrintingQuotation: boolean;
}

export default function QuotationDecisionModal({
  isOpen,
  onClose,
  onCreateWorkOrder,
  onPrintQuotation,
  isCreatingWorkOrder,
  isPrintingQuotation
}: QuotationDecisionModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-lg max-w-md w-full mx-4">
        {/* Header */}
        <div className="flex justify-between items-center p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-800">Choose Action</h2>
          <button
            onClick={onClose}
            disabled={isCreatingWorkOrder || isPrintingQuotation}
            className="text-gray-400 hover:text-gray-600 disabled:cursor-not-allowed"
          >
            <X size={24} />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          <p className="text-gray-600 mb-6">
            What would you like to do with this registration?
          </p>

          <div className="space-y-4">
            {/* Create Work Order Option */}
            <button
              onClick={onCreateWorkOrder}
              disabled={isCreatingWorkOrder || isPrintingQuotation}
              className="w-full p-4 border-2 border-blue-200 rounded-lg hover:border-blue-400 hover:bg-blue-50 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              <div className="flex items-center space-x-3">
                <div className="flex-shrink-0">
                  <Wrench className="h-6 w-6 text-blue-600" />
                </div>
                <div className="text-left">
                  <div className="font-medium text-gray-900">
                    {isCreatingWorkOrder ? 'Creating Work Order...' : 'Create Work Order'}
                  </div>
                  <div className="text-sm text-gray-500">
                    Full registration with work order, invoice, and job tracking
                  </div>
                </div>
              </div>
            </button>

            {/* Print Quotation Option */}
            <button
              onClick={onPrintQuotation}
              disabled={isCreatingWorkOrder || isPrintingQuotation}
              className="w-full p-4 border-2 border-green-200 rounded-lg hover:border-green-400 hover:bg-green-50 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              <div className="flex items-center space-x-3">
                <div className="flex-shrink-0">
                  <FileText className="h-6 w-6 text-green-600" />
                </div>
                <div className="text-left">
                  <div className="font-medium text-gray-900">
                    {isPrintingQuotation ? 'Generating Quotation...' : 'Print Quotation'}
                  </div>
                  <div className="text-sm text-gray-500">
                    Generate quotation PDF without creating work order
                  </div>
                </div>
              </div>
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-gray-50 rounded-b-lg">
          <p className="text-xs text-gray-500">
            Choose "Create Work Order" for actual jobs or "Print Quotation" for price quotes
          </p>
        </div>
      </div>
    </div>
  );
}