'use client';

import { usePathname, useRouter } from 'next/navigation';
import { useEffect } from 'react';
import Navbar from '@/app/components/Navbar/navBar'
import Sidebar from "@/app/components/Sidebar/sideBar"
import { useAuth } from './context/AuthContext';

const DashboardLayout= ({children}: {children: React.ReactNode}) => {
    return (
        <div className="flex h-screen overflow-hidden">
            {/* Sidebar - Hidden on tablet/mobile, shown as overlay when collapsed state changes */}
            <Sidebar />

            {/* Main content area - Takes full width on tablet */}
            <div className="flex-1 flex flex-col min-w-0">
                <Navbar title="Garage Management System" />
                <main className="flex-1 overflow-auto bg-gray-50">
                    {children}
                </main>
            </div>
        </div>
    );
}

// Layout for feedback screen users - no sidebar or navbar
const FeedbackLayout = ({children}: {children: React.ReactNode}) => {
    return (
        <div className="min-h-screen bg-gray-50">
            {children}
        </div>
    );
}

const DashboardWrapper = ({children}: {children: React.ReactNode}) => {
  const { isAuthenticated, isLoading, user } = useAuth();
  const pathname = usePathname();
  const router = useRouter();
  
  // Public routes that should bypass authentication check
  const publicRoutes = ['/login'];
  const isPublicRoute = publicRoutes.includes(pathname);

  // Check if user has feedback screen role
  const isFeedbackUser = user?.role_name?.toLowerCase() === 'feedback screen';

  // Redirect feedback users to customer-review page and restrict access to other pages
  useEffect(() => {
    if (isAuthenticated && isFeedbackUser && !isLoading) {
      // If feedback user tries to access any page other than customer-review, redirect them
      if (pathname !== '/customer-review') {
        router.replace('/customer-review');
        return;
      }
    }
  }, [isAuthenticated, isFeedbackUser, pathname, router, isLoading]);

  // Show loading state
  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  // If it's a public route, show content without any layout
  if (isPublicRoute) {
    return <>{children}</>;
  }

  // If user is authenticated
  if (isAuthenticated) {
    // Special layout for feedback screen users - no sidebar/navbar, only customer-review access
    if (isFeedbackUser) {
      // Only allow access to customer-review page
      if (pathname === '/customer-review') {
        return <FeedbackLayout>{children}</FeedbackLayout>;
      } else {
        // This will be handled by the useEffect redirect, but return null for now
        return null;
      }
    } else {
      // Regular dashboard layout for other authenticated users
      return <DashboardLayout>{children}</DashboardLayout>;
    }
  }

  // This shouldn't be reached due to middleware, but as a fallback
  return null;
}

export default DashboardWrapper