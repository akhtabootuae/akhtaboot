'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../context/AuthContext';
import { useRouteProtection } from '../../services/route-protection';
import { dataApi, customerReviewApi } from '../../services/api';
import CustomerAnalytics from '../components/Kpi/CustomerAnalytics';
import StaffPerformance from '../components/Kpi/StaffPerformance';
import CustomerReviews from '../components/Kpi/CustomerReviews';
import FinancialAnalytics from '../components/Kpi/FinancialAnalytics';
import { Customer, User, WorkOrder } from '@/app/types/api';

interface ChartData {
  labels: string[];
  datasets: Array<{
    label?: string;
    data: number[];
    backgroundColor: string | string[];
    borderColor?: string;
    borderWidth?: number;
  }>;
}

interface BranchStats {
  id: string;
  name: string;
  customerCount: number;
  customers: Customer[];
}

type CustomerData = {
  byBranch: ChartData | null;
  byCity: ChartData | null;
  topBranches: BranchStats[];
  totalCustomers: number;
  customers?: Customer[];
};

interface PerformanceTier {
  tier: string;
  count: number;
  percentage: number;
}

interface RatingRange {
  range: string;
  count: number;
  percentage: number;
}

type StaffData = {
  workOrderPerformance: PerformanceTier[];
  evaluationRatings: RatingRange[];
  totalStaff: number;
  highPerformers: number;
  excellentRatings: number;
  needsAttention: number;
};

interface Review {
  _id: string;
  rating: number;
  phone_number?: string;
  comment?: string;
  created_at: string;
  updated_at: string;
}

interface ReviewStatistics {
  totalReviews: number;
  averageRating: number;
  ratingDistribution: {
    [key: string]: number;
  };
}

type ReviewData = {
  reviews: Review[];
  statistics: ReviewStatistics;
  totalReviews: number;
  averageRating: number;
};

const KPIAnalyticsDashboard = () => {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const [customerData, setCustomerData] = useState<CustomerData>({
    byBranch: null,
    byCity: null,
    topBranches: [],
    totalCustomers: 0,
    customers: [] // Initialize customers array
  });
  const [staffData, setStaffData] = useState<StaffData>({
    workOrderPerformance: [],
    evaluationRatings: [],
    totalStaff: 0,
    highPerformers: 0,
    excellentRatings: 0,
    needsAttention: 0
  });
  const [reviewData, setReviewData] = useState<ReviewData>({
    reviews: [],
    statistics: {
      totalReviews: 0,
      averageRating: 0,
      ratingDistribution: {}
    },
    totalReviews: 0,
    averageRating: 0
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('customers');

  // Admin-only route protection
  const hasAccess = useRouteProtection(isAuthenticated, user, { adminOnly: true });

  // Tab configuration
  const tabs = [
    {
      id: 'customers',
      name: 'Customer Analytics',
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
        </svg>
      ),
      count: customerData.totalCustomers,
      description: 'Customer distribution and growth metrics'
    },
    {
      id: 'workorders',
      name: 'Work Orders',
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
        </svg>
      ),
      count: 0,
      description: 'Work order completion and performance metrics'
    },
    {
      id: 'financial',
      name: 'Financial',
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      ),
      count: 0,
      description: 'Revenue trends and profit analysis'
    },
    {
      id: 'staff',
      name: 'Staff Performance',
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
        </svg>
      ),
      count: staffData.totalStaff,
      description: 'Employee productivity and utilization metrics'
    },
    {
      id: 'reviews',
      name: 'Customer Reviews',
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
        </svg>
      ),
      count: reviewData.totalReviews,
      description: 'Customer feedback, ratings, and satisfaction metrics'
    }
  ];

  // Process customers by branch for bar chart
  const processCustomersByBranch = (customers: Customer[]): ChartData => {
    const branchCounts = customers.reduce((acc: { [key: string]: number }, customer) => {
      const branchName = customer.branch?.branch_name || 'No Branch';
      acc[branchName] = (acc[branchName] || 0) + 1;
      return acc;
    }, {});

    return {
      labels: Object.keys(branchCounts),
      datasets: [{
        label: 'Number of Customers',
        data: Object.values(branchCounts) as number[],
        backgroundColor: '#36A2EB',
        borderColor: '#1f77b4',
        borderWidth: 1
      }]
    };
  };

  // Process customers by city for pie chart
  const processCustomersByCity = (customers: Customer[]): ChartData => {
    const cityCounts = customers.reduce((acc: { [key: string]: number }, customer) => {
      const city = customer.city || 'Unknown City';
      acc[city] = (acc[city] || 0) + 1;
      return acc;
    }, {});

    // Sort by count and take top cities (limit to avoid too many small slices)
    const sortedCities = Object.entries(cityCounts)
      .sort(([,a], [,b]) => (b as number) - (a as number))
      .slice(0, 8); // Top 8 cities

    return {
      labels: sortedCities.map(([city]) => city),
      datasets: [{
        data: sortedCities.map(([, count]) => count as number),
        backgroundColor: [
          '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', 
          '#9966FF', '#FF9F40', '#C9CBCF', '#FF6B6B'
        ],
        borderWidth: 2,
        borderColor: '#fff'
      }]
    };
  };

  // Get top branches by customer count
  const getTopBranches = (customers: Customer[]): BranchStats[] => {
    const branchStats = customers.reduce((acc: { [key: string]: BranchStats }, customer) => {
      const branchId = customer.branch?.branch_id || 'no-branch';
      const branchName = customer.branch?.branch_name || 'No Branch';
      
      if (!acc[branchId]) {
        acc[branchId] = {
          id: branchId,
          name: branchName,
          customerCount: 0,
          customers: []
        };
      }
      
      acc[branchId].customerCount++;
      acc[branchId].customers.push(customer);
      return acc;
    }, {});

    // Sort branches by customer count
    return (Object.values(branchStats) as BranchStats[])
      .sort((a: BranchStats, b: BranchStats) => b.customerCount - a.customerCount);
  };

  // Process work order performance for staff
  const processWorkOrderPerformance = async (technicians: User[]): Promise<PerformanceTier[]> => {
    // Count work orders per technician using individual endpoints
    const technicianWorkCounts: { [key: string]: number } = {};
    const technicianWorkOrders: { [key: string]: string[] } = {};
    
    // Fetch work orders for each technician individually
    for (const tech of technicians) {
      try {
        // Use the dataApi method to get user work orders (all statuses)
        const workOrdersResponse = await dataApi.getUserWorkOrders(tech._id, 1, 100, 'all');
        
        // Handle different possible response structures
        const workOrders = (workOrdersResponse as any)?.workorders || 
                          (workOrdersResponse as any)?.data?.workorders || 
                          (Array.isArray(workOrdersResponse) ? workOrdersResponse : []);
        
        if (Array.isArray(workOrders) && workOrders.length > 0) {
          // Count active work orders (open, pending, in_progress, In Progress, Active)
          const activeWorkOrders = workOrders.filter((wo: any) => 
            wo.status === 'open' || wo.status === 'pending' || wo.status === 'in_progress' || 
            wo.status === 'In Progress' || wo.status === 'Active'
          );
          
          technicianWorkCounts[tech._id] = activeWorkOrders.length;
          technicianWorkOrders[tech._id] = activeWorkOrders.map((wo: any) => wo._id);
        } else {
          technicianWorkCounts[tech._id] = 0;
          technicianWorkOrders[tech._id] = [];
        }
      } catch (error) {
        technicianWorkCounts[tech._id] = 0;
        technicianWorkOrders[tech._id] = [];
      }
    }
    
    // Categorize performance levels
    const performanceTiers = {
      '5+ orders': 0,
      '3-4 orders': 0,
      '1-2 orders': 0,
      '0 orders': 0
    };
    
    technicians.forEach(tech => {
      const count = technicianWorkCounts[tech._id] || 0;
      
      if (count >= 5) {
        performanceTiers['5+ orders']++;
      } else if (count >= 3) {
        performanceTiers['3-4 orders']++;
      } else if (count >= 1) {
        performanceTiers['1-2 orders']++;
      } else {
        performanceTiers['0 orders']++;
      }
    });
    
    // Calculate percentages
    const totalTechnicians = technicians.length;
    const percentages = Object.keys(performanceTiers).map(tier => ({
      tier,
      count: performanceTiers[tier as keyof typeof performanceTiers],
      percentage: totalTechnicians > 0 ? Math.round((performanceTiers[tier as keyof typeof performanceTiers] / totalTechnicians) * 100) : 0
    }));
    
    return percentages;
  };

  // Process staff evaluation ratings
  const processStaffEvaluationRatings = async (technicians: User[]): Promise<RatingRange[]> => {
    const ratingDistribution = {
      '4-5 (Excellent)': 0,
      '3-4 (Good)': 0,
      '2-3 (Average)': 0,
      '1-2 (Below Average)': 0,
      '0-1 (Poor)': 0,
      'No Evaluations': 0
    };
    
    for (const tech of technicians) {
      try {
        // Use the API wrapper instead of direct fetch
        const evaluationResponse = await dataApi.getMannerEvaluations(tech._id);
        // The API wrapper returns response.data directly due to the interceptor
        // Handle different possible response structures
        const evaluations = (evaluationResponse as any)?.manner_evaluations || 
                           (evaluationResponse as any)?.data?.manner_evaluations || 
                           (Array.isArray(evaluationResponse) ? evaluationResponse : []);
        
        if (!Array.isArray(evaluations) || evaluations.length === 0) {
          ratingDistribution['No Evaluations']++;
        } else {
          // Calculate average rating by summing all ratings and dividing by count
          const totalRating = evaluations.reduce((sum: number, evaluation: { rating?: number }) => sum + (evaluation.rating || 0), 0);
          const avgRating = totalRating / evaluations.length;
          
          // Categorize based on average rating ranges
          if (avgRating >= 4) {
            ratingDistribution['4-5 (Excellent)']++;
          } else if (avgRating >= 3) {
            ratingDistribution['3-4 (Good)']++;
          } else if (avgRating >= 2) {
            ratingDistribution['2-3 (Average)']++;
          } else if (avgRating >= 1) {
            ratingDistribution['1-2 (Below Average)']++;
          } else {
            ratingDistribution['0-1 (Poor)']++;
          }
        }
      } catch (error) {
        ratingDistribution['No Evaluations']++;
      }
    }
    
    // Calculate percentages
    const totalStaff = technicians.length;
    const percentages = Object.keys(ratingDistribution).map(range => ({
      range,
      count: ratingDistribution[range as keyof typeof ratingDistribution],
      percentage: totalStaff > 0 ? Math.round((ratingDistribution[range as keyof typeof ratingDistribution] / totalStaff) * 100) : 0
    }));
    
    return percentages;
  };

  // Fetch customer data for analytics
  const fetchCustomerData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await dataApi.getCustomers();
      
      // Handle the API response properly - extract the actual data
      const customers = Array.isArray(response) ? response : response?.data || [];
      
      if (!customers || !Array.isArray(customers)) {
        throw new Error('Invalid customer data received');
      }
      
      const branchData = processCustomersByBranch(customers);
      const cityData = processCustomersByCity(customers);
      const topBranches = getTopBranches(customers);

      setCustomerData({
        byBranch: branchData,
        byCity: cityData,
        topBranches: topBranches,
        totalCustomers: customers.length,
        customers: customers // Store raw customer data for lookup
      });
    } catch (error: Error | unknown) {
      setError((error as Error)?.message || 'Failed to load customer analytics data');
    } finally {
      setLoading(false);
    }
  }, []);

  // Fetch staff data for analytics
  const fetchStaffData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Fetch technicians using API wrapper
      const technicians = await dataApi.getTechnicians();
      
      if (!Array.isArray(technicians) || technicians.length === 0) {
        setStaffData({
          workOrderPerformance: [],
          evaluationRatings: [],
          totalStaff: 0,
          highPerformers: 0,
          excellentRatings: 0,
          needsAttention: 0
        });
        setLoading(false);
        return;
      }
      
      // Process work order performance using individual endpoints
      const workOrderPerformance = await processWorkOrderPerformance(technicians);
      
      // Process staff evaluation ratings
      const evaluationRatings = await processStaffEvaluationRatings(technicians);
      
      // Calculate summary metrics
      const highPerformers = workOrderPerformance.find(item => item.tier === '5+ orders')?.count || 0;
      const excellentRatings = evaluationRatings.find(item => item.range.includes('4-5'))?.count || 0;
      const needsAttention = workOrderPerformance.find(item => item.tier === '0 orders')?.count || 0;
      
      setStaffData({
        workOrderPerformance,
        evaluationRatings,
        totalStaff: technicians.length,
        highPerformers,
        excellentRatings,
        needsAttention
      });
    } catch (error: Error | unknown) {
      setError((error as Error)?.message || 'Failed to load staff analytics data');
    } finally {
      setLoading(false);
    }
  }, []);

  // Fetch review data for analytics
  const fetchReviewData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Fetch reviews from API
      const response = await customerReviewApi.getReviews();
      
      // Handle the API response properly - the API returns { success: true, data: { reviews: [...], pagination: {...} } }
      const reviews = response?.data?.reviews || [];
      
      if (!Array.isArray(reviews)) {
        throw new Error('Invalid review data received');
      }
      
      // Sort reviews by created_at in descending order (newest first)
      const sortedReviews = reviews.sort((a: Review, b: Review) => 
        new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
      );
      
      // Calculate statistics
      const totalReviews = sortedReviews.length;
      const averageRating = totalReviews > 0 
        ? sortedReviews.reduce((sum: number, review: Review) => sum + (review.rating || 0), 0) / totalReviews 
        : 0;
      
      // Calculate rating distribution
      const ratingDistribution: { [key: string]: number } = {
        '5': 0,
        '4': 0,
        '3': 0,
        '2': 0,
        '1': 0
      };
      
      sortedReviews.forEach((review: Review) => {
        const rating = Math.floor(review.rating || 0);
        if (rating >= 1 && rating <= 5) {
          ratingDistribution[rating.toString()]++;
        }
      });
      
      const statistics: ReviewStatistics = {
        totalReviews,
        averageRating: Math.round(averageRating * 100) / 100, // Round to 2 decimal places
        ratingDistribution
      };
      
      setReviewData({
        reviews: sortedReviews,
        statistics,
        totalReviews,
        averageRating: statistics.averageRating
      });
    } catch (error: Error | unknown) {
      console.error('Error fetching review data:', error);
      setError((error as Error)?.message || 'Failed to load review analytics data');
    } finally {
      setLoading(false);
    }
  }, []);



  // Placeholder component for other tabs
  const PlaceholderTab = ({ tabName, description }: { tabName: string; description: string }) => (
    <div className="bg-white rounded-lg shadow-md p-12 text-center">
      <div className="bg-gray-100 rounded-full w-24 h-24 mx-auto mb-6 flex items-center justify-center">
        <svg className="w-12 h-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
        </svg>
      </div>
      <h3 className="text-2xl font-bold text-gray-800 mb-4">{tabName} KPIs</h3>
      <p className="text-gray-600 mb-8 max-w-md mx-auto">{description}</p>
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-6 border border-blue-200">
        <h4 className="text-lg font-semibold text-gray-800 mb-2">Coming Soon</h4>
        <p className="text-gray-600">This analytics section is currently under development and will be available in the next update.</p>
      </div>
    </div>
  );

  useEffect(() => {
    // Fetch data based on active tab
    if (isAuthenticated && user?.role_name === 'Admin' && hasAccess) {
      if (activeTab === 'customers') {
        fetchCustomerData();
      } else if (activeTab === 'staff') {
        // For staff tab, we need both customer data (for lookups) and staff data
        const fetchStaffTabData = async () => {
          try {
            // Fetch customer data first if not already loaded
            if (!customerData.customers || customerData.customers.length === 0) {
              await fetchCustomerData();
            }
            // Then fetch staff data
            await fetchStaffData();
          } catch (error) {
            console.error('Error fetching staff tab data:', error);
          }
        };
        fetchStaffTabData();
      } else if (activeTab === 'reviews') {
        fetchReviewData();
      }
    }
  }, [isAuthenticated, user, hasAccess, activeTab, fetchCustomerData, fetchStaffData, fetchReviewData]);

  // Show loading state during auth check
  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  // Don't render anything if access check is still in progress
  if (!hasAccess) {
    return null;
  }

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      {/* Header Section - Card Style */}
      <div className="mb-8">
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <div className="flex items-center mb-3">
                <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-3 rounded-lg mr-4">
                  <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                  </svg>
                </div>
                <div>
                  <h1 className="text-3xl font-bold text-gray-900">KPI Analytics Dashboard</h1>
                  <div className="flex items-center mt-1">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                    <span className="text-sm text-gray-500">Live Data</span>
                  </div>
                </div>
              </div>
              <p className="text-gray-600 text-lg">
                Welcome back, <span className="font-semibold text-blue-600">{user?.name}</span> 
                <span className="text-gray-500"> - </span>
                <span className="text-gray-700">Comprehensive business insights and performance metrics</span>
              </p>
            </div>
            <div className="bg-gray-50 rounded-lg p-4 border border-gray-200 min-w-[200px]">
              <div className="text-right">
                <div className="flex items-center justify-end mb-2">
                  <div className="w-3 h-3 bg-blue-500 rounded-full mr-2"></div>
                  <div className="text-sm text-gray-500">Logged in as</div>
                </div>
                <div className="font-bold text-lg text-gray-900 mb-1">{user?.role_name}</div>
                <div className="text-sm text-gray-600 flex items-center justify-end">
                  <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                  </svg>
                  {user?.branch?.branch_name || 'No Branch'}
                </div>
                <div className="mt-3 pt-3 border-t border-gray-200">
                  <div className="text-xs text-gray-500">Last Updated</div>
                  <div className="text-sm font-medium text-gray-700">
                    {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Error State */}
      {error && (activeTab === 'customers' || activeTab === 'staff' || activeTab === 'reviews') && (
        <div className="mb-6 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
          <div className="flex items-center">
            <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
            </svg>
            Error: {error}
            <button 
              onClick={activeTab === 'customers' ? fetchCustomerData : activeTab === 'staff' ? fetchStaffData : fetchReviewData}
              className="ml-4 text-sm underline hover:no-underline"
            >
              Retry
            </button>
          </div>
        </div>
      )}

      {/* Tab Navigation */}
      <div className="bg-white rounded-lg shadow-md border border-gray-200 mb-8">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6" aria-label="Tabs">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-600 bg-blue-50'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                } whitespace-nowrap py-4 px-6 border-b-2 font-medium text-sm flex items-center space-x-2 transition-all duration-200 rounded-t-lg`}
              >
                <span className={`${activeTab === tab.id ? 'text-blue-600' : 'text-gray-400'}`}>
                  {tab.icon}
                </span>
                <span>{tab.name}</span>
                {tab.count > 0 && (
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    activeTab === tab.id 
                      ? 'bg-blue-100 text-blue-800' 
                      : 'bg-gray-100 text-gray-800'
                  }`}>
                    {tab.count}
                  </span>
                )}
              </button>
            ))}
          </nav>
        </div>

        {/* Tab Description */}
        <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <p className="text-sm text-gray-600">
              {tabs.find(tab => tab.id === activeTab)?.description}
            </p>
            <div className="flex items-center text-xs text-gray-500">
              <div className="w-2 h-2 bg-green-400 rounded-full mr-2"></div>
              <span>Real-time data</span>
            </div>
          </div>
        </div>
      </div>

      {/* Tab Content */}
      {loading && (activeTab === 'customers' || activeTab === 'staff' || activeTab === 'reviews') ? (
        <div className="flex items-center justify-center py-12">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <div className="text-gray-600">
              Loading {activeTab === 'customers' ? 'customer' : activeTab === 'staff' ? 'staff' : 'review'} analytics...
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-8">
          {activeTab === 'customers' && <CustomerAnalytics customerData={customerData} />}
          {activeTab === 'workorders' && (
            <PlaceholderTab 
              tabName="Work Order" 
              description="Track work order completion rates, average processing time, technician performance, and service quality metrics across all branches."
            />
          )}
          {activeTab === 'financial' && (
            <FinancialAnalytics />
          )}
          {activeTab === 'staff' && <StaffPerformance staffData={staffData} customerData={customerData} />}
          {activeTab === 'reviews' && <CustomerReviews reviewData={reviewData} />}
          {activeTab === 'operations' && (
            <PlaceholderTab 
              tabName="Operations" 
              description="Monitor branch operations, system health, equipment utilization, and operational efficiency across your garage network."
            />
          )}
        </div>
      )}
    </div>
  );
};

export default KPIAnalyticsDashboard;