'use client';

import { useState, useCallback, useRef, useEffect } from 'react';
import { ProgressStep } from '../components/ui/ProgressLoader';

interface ProgressTrackerOptions {
  steps: Omit<ProgressStep, 'status'>[];
  onComplete?: () => void;
  onError?: (error: string, step: ProgressStep) => void;
  onStepChange?: (step: ProgressStep) => void;
}

export const useProgressTracker = (options: ProgressTrackerOptions) => {
  const { steps: initialSteps, onComplete, onError, onStepChange } = options;

  const [steps, setSteps] = useState<ProgressStep[]>(
    initialSteps.map(step => ({ ...step, status: 'pending' as const }))
  );

  const [currentStepIndex, setCurrentStepIndex] = useState<number>(-1);
  const [isActive, setIsActive] = useState(false);
  const [startTime, setStartTime] = useState<number>(0);
  const [elapsedTime, setElapsedTime] = useState<number>(0);
  const [stepStartTimes, setStepStartTimes] = useState<Map<string, number>>(new Map());
  const [stepDurations, setStepDurations] = useState<Map<string, number>>(new Map());
  const [error, setError] = useState<string | null>(null);

  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  // Update elapsed time every second when active
  useEffect(() => {
    if (isActive && startTime > 0) {
      intervalRef.current = setInterval(() => {
        setElapsedTime(Date.now() - startTime);
      }, 1000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isActive, startTime]);

  // Calculate total percentage completed
  const totalPercentage = steps.reduce((acc, step) => {
    if (step.status === 'completed') {
      return acc + step.weight;
    } else if (step.status === 'in_progress') {
      // Assume 50% completion for current step
      return acc + (step.weight * 0.5);
    }
    return acc;
  }, 0);

  // Get current step
  const currentStep = currentStepIndex >= 0 && currentStepIndex < steps.length
    ? steps[currentStepIndex]
    : null;

  // Calculate estimated time remaining
  const estimatedTimeRemaining = (() => {
    if (currentStepIndex < 0 || steps.length === 0) return 0;

    const completedSteps = steps.slice(0, currentStepIndex);
    const remainingSteps = steps.slice(currentStepIndex);

    // Calculate average duration per weight unit from completed steps
    let totalCompletedWeight = 0;
    let totalCompletedDuration = 0;

    completedSteps.forEach(step => {
      const duration = stepDurations.get(step.id);
      if (duration !== undefined) {
        totalCompletedWeight += step.weight;
        totalCompletedDuration += duration;
      }
    });

    // Use estimated durations if no completed steps yet
    if (totalCompletedWeight === 0) {
      const remainingWeight = remainingSteps.reduce((acc, step) => acc + step.weight, 0);
      const estimatedTotal = remainingSteps.reduce((acc, step) => acc + step.estimatedDuration, 0);
      return estimatedTotal;
    }

    // Calculate time per weight unit from completed steps
    const timePerWeightUnit = totalCompletedDuration / totalCompletedWeight;

    // Estimate remaining time for current step (assume 50% completion)
    const currentStepRemainingTime = currentStep
      ? (currentStep.weight * timePerWeightUnit * 0.5)
      : 0;

    // Estimate time for remaining steps
    const futureSteps = steps.slice(currentStepIndex + 1);
    const futureStepsTime = futureSteps.reduce((acc, step) => acc + (step.weight * timePerWeightUnit), 0);

    return Math.max(0, currentStepRemainingTime + futureStepsTime);
  })();

  // Start the progress tracking
  const start = useCallback(() => {
    const now = Date.now();
    setStartTime(now);
    setElapsedTime(0);
    setIsActive(true);
    setCurrentStepIndex(-1);
    setError(null);
    setStepStartTimes(new Map());
    setStepDurations(new Map());

    // Reset all steps to pending
    setSteps(prev => prev.map(step => ({ ...step, status: 'pending' as const })));
  }, []);

  // Start a specific step
  const startStep = useCallback((stepId: string) => {
    const stepIndex = steps.findIndex(step => step.id === stepId);
    if (stepIndex === -1) return false;

    const now = Date.now();

    setSteps(prev => prev.map((step, index) => {
      if (step.id === stepId) {
        return { ...step, status: 'in_progress' as const };
      } else if (index < stepIndex) {
        return { ...step, status: 'completed' as const };
      }
      return step;
    }));

    setCurrentStepIndex(stepIndex);
    setStepStartTimes(prev => new Map(prev).set(stepId, now));

    const updatedStep = { ...steps[stepIndex], status: 'in_progress' as const };
    onStepChange?.(updatedStep);

    return true;
  }, [steps, onStepChange]);

  // Complete a specific step
  const completeStep = useCallback((stepId: string) => {
    const stepIndex = steps.findIndex(step => step.id === stepId);
    if (stepIndex === -1) return false;

    const now = Date.now();
    const startTime = stepStartTimes.get(stepId);

    if (startTime) {
      const duration = now - startTime;
      setStepDurations(prev => new Map(prev).set(stepId, duration));
    }

    setSteps(prev => prev.map(step =>
      step.id === stepId
        ? { ...step, status: 'completed' as const }
        : step
    ));

    const updatedStep = { ...steps[stepIndex], status: 'completed' as const };
    onStepChange?.(updatedStep);

    // Check if all steps are completed
    const allCompleted = steps.every((step, index) =>
      index <= stepIndex || step.status === 'completed'
    );

    if (stepIndex === steps.length - 1) {
      // This was the last step
      setIsActive(false);
      setCurrentStepIndex(-1);
      onComplete?.();
    }

    return true;
  }, [steps, stepStartTimes, onComplete, onStepChange]);

  // Mark a step as failed
  const failStep = useCallback((stepId: string, errorMessage: string) => {
    const stepIndex = steps.findIndex(step => step.id === stepId);
    if (stepIndex === -1) return false;

    setSteps(prev => prev.map(step =>
      step.id === stepId
        ? { ...step, status: 'error' as const }
        : step
    ));

    setError(errorMessage);
    setIsActive(false);

    const failedStep = { ...steps[stepIndex], status: 'error' as const };
    onError?.(errorMessage, failedStep);

    return true;
  }, [steps, onError]);

  // Reset the progress tracker
  const reset = useCallback(() => {
    setSteps(prev => prev.map(step => ({ ...step, status: 'pending' as const })));
    setCurrentStepIndex(-1);
    setIsActive(false);
    setStartTime(0);
    setElapsedTime(0);
    setStepStartTimes(new Map());
    setStepDurations(new Map());
    setError(null);

    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  }, []);

  // Auto-advance to next step
  const nextStep = useCallback(() => {
    if (currentStepIndex >= 0 && currentStepIndex < steps.length) {
      const currentStepId = steps[currentStepIndex].id;
      completeStep(currentStepId);
    }

    const nextIndex = currentStepIndex + 1;
    if (nextIndex < steps.length) {
      const nextStepId = steps[nextIndex].id;
      startStep(nextStepId);
    }
  }, [currentStepIndex, steps, completeStep, startStep]);

  return {
    // State
    steps,
    currentStep,
    currentStepIndex,
    totalPercentage,
    elapsedTime,
    estimatedTimeRemaining,
    isActive,
    error,

    // Actions
    start,
    startStep,
    completeStep,
    failStep,
    nextStep,
    reset,
  };
};

export default useProgressTracker;