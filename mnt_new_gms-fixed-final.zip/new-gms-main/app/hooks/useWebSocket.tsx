"use client";

import { useEffect, useState, useRef, useCallback } from 'react';
import { io, Socket } from 'socket.io-client';
import { useAuth } from '@/app/context/AuthContext';

interface UseWebSocketReturn {
  socket: Socket | null;
  isConnected: boolean;
  error: string | null;
  joinConversation: (conversationId: string) => void;
  leaveConversation: (conversationId: string) => void;
}

export const useWebSocket = (): UseWebSocketReturn => {
  const [socket, setSocket] = useState<Socket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { user, token } = useAuth();
  const socketRef = useRef<Socket | null>(null);

  useEffect(() => {
    // Don't connect if no token or user
    if (!token || !user) {
      return;
    }

    // Clean up existing socket
    if (socketRef.current) {
      socketRef.current.disconnect();
    }

    // Create new socket connection
    const newSocket = io(process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000', {
      auth: {
        token: token
      },
      transports: ['websocket', 'polling'],
      timeout: 10000,
      reconnection: true,
      reconnectionAttempts: 5,
      reconnectionDelay: 1000,
    });

    // Connection events
    newSocket.on('connect', () => {
      setIsConnected(true);
      setError(null);
    });

    newSocket.on('disconnect', (reason) => {
      setIsConnected(false);
      
      if (reason === 'io server disconnect') {
        // Server disconnected the socket, reconnect manually
        newSocket.connect();
      }
    });

    newSocket.on('connect_error', (error) => {
      setError(error.message);
      setIsConnected(false);
      
      // Auto-retry with exponential backoff for specific errors
      if (error.message.includes('401') || error.message.includes('403')) {
        setError('Authentication failed. Please refresh the page.');
      }
    });

    newSocket.on('reconnect', (attemptNumber) => {
      setError(null);
    });

    newSocket.on('reconnect_error', (error) => {
      setError(`Reconnection failed: ${error.message}`);
    });

    newSocket.on('reconnect_failed', () => {
      setError('Connection failed permanently. Please refresh the page.');
    });

    socketRef.current = newSocket;
    setSocket(newSocket);

    // Cleanup on unmount
    return () => {
      if (socketRef.current) {
        socketRef.current.removeAllListeners();
        socketRef.current.disconnect();
      }
    };
  }, [token, user?.id]);

  // Join conversation for real-time updates
  const joinConversation = useCallback((conversationId: string) => {
    if (socket) {
      socket.emit('join_conversation', conversationId); // Send just the string, not an object
    }
  }, [socket]);

  // Leave conversation
  const leaveConversation = useCallback((conversationId: string) => {
    if (socket) {
      socket.emit('leave_conversation', conversationId); // Send just the string, not an object
    }
  }, [socket]);

  return { socket, isConnected, error, joinConversation, leaveConversation };
};
