"use client";

import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/app/context/AuthContext';
import { useRouteProtection } from '@/services/route-protection';
import { useWebSocket } from '@/app/hooks/useWebSocket';
import { messagingApi } from '@/services/api';
import { 
  Conversation, 
  Message, 
  ConversationResponse, 
  MessagesResponse,
  UserSearchResult,
  ConversationType 
} from '@/app/types/messaging';
import ConversationList from '../components/Messaging/ConversationList';
import MessageThread from '../components/Messaging/MessageThread';
import MessageComposer from '../components/Messaging/MessageComposer';
import NewConversationModal from '../components/Messaging/NewConversationModal';
import GroupManagementModal from '../components/Messaging/GroupManagementModal';
import NewAnnouncementModal from '@/app/components/Messaging/NewAnnouncementModal';
import AnnouncementDetail from '../components/Messaging/AnnouncementDetail';
import { 
  MessageSquare, 
  Plus, 
  Users, 
  Megaphone,
  Search,
  Loader2,
  Settings
} from 'lucide-react';
import { toast } from 'react-hot-toast';

export default function MessagingPage() {
  const { user, isAuthenticated } = useAuth();
  const canAccess = useRouteProtection(isAuthenticated, user);
  const { socket, isConnected, error: wsError, joinConversation, leaveConversation } = useWebSocket();
  
  // State management
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const [messagesLoading, setMessagesLoading] = useState(false);
  const [showNewConversation, setShowNewConversation] = useState(false);
  const [showGroupManagement, setShowGroupManagement] = useState(false);
  const [showNewAnnouncement, setShowNewAnnouncement] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'chats' | 'announcements'>('chats');

  // Debug messages state changes
  useEffect(() => {
    // Messages state tracking for debugging if needed
  }, [messages]);

  // WebSocket event listeners for real-time updates
  useEffect(() => {
    if (!socket || !isConnected) return;

    // Listen for new messages
    const handleNewMessage = (data: any) => {
      // Handle different possible data structures from backend
      const conversationId = data.conversationId || data.conversation_id || data.conversation;
      const message = data.message || data;
      const newMessageId = message._id || message.id;
      const messageType = message.message_type || message.type || 'text';
      const messageContent = message.content || message.text || '';
      const createdAt = message.created_at || message.createdAt || new Date().toISOString();
      
      // Check if this is a system message
      const isSystemMessage = (content: string) => {
        const lowerContent = content.toLowerCase();
        const patterns = [
          /was added to the group/, /was removed from the group/, /has joined the group/,
          /has left the group/, /created the group/, /changed the group name/,
          /changed the group description/, /promoted .* to admin/, /removed admin privileges from/
        ];
        return patterns.some(pattern => pattern.test(lowerContent));
      };
      
      // Skip messages sent by the current user to avoid duplicates
      // BUT allow system messages to pass through
      const senderId = message.sender_id || message.senderId || message.user_id;
      const isSystem = isSystemMessage(messageContent);
      
      if (!isSystem && senderId && user?.id && senderId.toString() === user.id.toString()) {
        return; // Don't process our own non-system messages from WebSocket
      }
      
      // Update messages if this is the currently selected conversation
      if (selectedConversation && selectedConversation._id === conversationId) {
        const newMessage = {
          _id: message._id || message.id,
          conversation_id: message.conversation_id || conversationId,
          sender_id: senderId,
          sender_name: message.sender_name || message.sender?.name || message.senderName || 'Unknown',
          sender_role: message.sender_role || message.sender?.role_name || message.senderRole || '',
          content: message.content || message.text || '',
          message_type: messageType,
          created_at: createdAt,
          updated_at: message.updated_at || message.updatedAt || new Date().toISOString(),
          // Media message fields
          file_id: message.file_id,
          original_name: message.original_name,
          mime_type: message.mime_type,
          file_size: message.file_size,
          s3_key: message.s3_key,
          signed_url: message.signed_url,
          // Chrome sometimes sends duration as 0 or undefined, so fallback to undefined if 0 or NaN
          duration: (typeof message.duration === 'string' ? parseFloat(message.duration) : (typeof message.duration === 'number' ? message.duration : undefined)) || undefined
        };
        // Check for duplicate messages before adding
        setMessages(prev => {
          const isMedia = ['voice_note', 'image', 'video', 'file'].includes(newMessage.message_type);
          let isDuplicate = false;
          if (isMedia) {
            // Media: deduplicate only by _id
            const existingMsg = prev.find(m => m._id === newMessage._id);
            if (existingMsg) {
              // Always update media fields if new signed_url is non-empty and different, or previous was empty/undefined
              if (
                newMessage.signed_url && newMessage.signed_url !== '' &&
                (existingMsg.signed_url !== newMessage.signed_url || !existingMsg.signed_url)
              ) {
                // Merge all media fields, but preserve text fields
                return prev.map(m =>
                  m._id === newMessage._id
                    ? { ...m, ...newMessage, content: m.content || newMessage.content }
                    : m
                );
              }
              // If signed_url is empty or unchanged, do not update
              return prev;
            }
          } else {
            // Non-media: deduplicate by _id or (content+sender+created_at within 10s)
            isDuplicate = prev.some(existingMsg => {
              if (existingMsg._id === newMessage._id) return true;
              const timeDiff = Math.abs(new Date(existingMsg.created_at).getTime() - new Date(newMessage.created_at).getTime());
              return (
                existingMsg.content === newMessage.content &&
                existingMsg.sender_id === newMessage.sender_id &&
                timeDiff < 10000
              );
            });
            if (isDuplicate) return prev;
          }
          // Always return a new array to force re-render
          return [...prev, newMessage];
        });
        setTimeout(scrollToBottom, 100);
      }
      
      // Update conversation last message without full reload
      const conversationMessageContent = message.content || message.text || '';
      const isSystemForConversation = isSystemMessage(conversationMessageContent);
      
      setConversations(prev => prev.map(conv => 
        conv._id === conversationId 
          ? {
              ...conv,
              last_message: {
                content: message.message_type === 'image' ? '📷 Image' : 
                        message.message_type === 'voice_note' ? '🎤 Voice message' : 
                        isSystemForConversation ? `📢 ${conversationMessageContent}` : conversationMessageContent,
                sender_name: isSystemForConversation ? 'System' : 
                           message.sender_name || message.sender?.name || message.senderName || 'Unknown',
                created_at: message.created_at || message.createdAt || new Date().toISOString()
              },
              updated_at: message.created_at || message.createdAt || new Date().toISOString()
            }
          : conv
      ));
    };

    // Listen for new conversations (when added to group or announcement)
    const handleNewConversation = (conversation: any) => {
      loadConversations(); // Only reload for new conversations
    };

    // Listen for user removal from groups
    const handleUserRemovedFromGroup = (data: any) => {
      const { conversationId, groupTitle, message } = data;
      
      // If the current user was removed, handle it
      if (selectedConversation && selectedConversation._id === conversationId) {
        setSelectedConversation(null);
        setMessages([]);
      }
      
      // Reload conversations to update the list
      loadConversations();
      
      // Show notification
      if (message) {
        toast.error(message);
      }
    };

    // Listen for connection status changes
    const handleConnectionStatus = (data: any) => {
      // Connection status update handling
    };

    // Handle system notifications/messages specifically
    const handleSystemMessage = (data: any) => {
      // Force handle system messages even if they're from current user
      const conversationId = data.conversationId || data.conversation_id || data.conversation;
      const message = data.message || data;
      
      // Ensure we process system messages
      if (selectedConversation && selectedConversation._id === conversationId) {
        const systemMessage = {
          _id: message._id || message.id || `system_${Date.now()}`,
          conversation_id: message.conversation_id || conversationId,
          sender_id: message.sender_id || 'system',
          sender_name: message.sender_name || 'System',
          sender_role: message.sender_role || '',
          content: message.content || message.text || '',
          message_type: message.message_type || 'text',
          created_at: message.created_at || message.createdAt || new Date().toISOString(),
          updated_at: message.updated_at || message.updatedAt || new Date().toISOString()
        };
        
        setMessages(prev => {
          // Check for duplicates
          const isDuplicate = prev.some(existingMsg => 
            existingMsg._id === systemMessage._id || 
            (existingMsg.content === systemMessage.content && 
             Math.abs(new Date(existingMsg.created_at).getTime() - new Date(systemMessage.created_at).getTime()) < 5000)
          );
          
          if (isDuplicate) return prev;
          return [...prev, systemMessage];
        });
        
        setTimeout(scrollToBottom, 100);
      }
      
      // Update conversation list
      const systemMessageContent = message.content || message.text || '';
      setConversations(prev => prev.map(conv => 
        conv._id === conversationId 
          ? {
              ...conv,
              last_message: {
                content: `📢 ${systemMessageContent}`,
                sender_name: 'System',
                created_at: message.created_at || message.createdAt || new Date().toISOString()
              },
              updated_at: message.created_at || message.createdAt || new Date().toISOString()
            }
          : conv
      ));
    };

    // Set up event listeners - try multiple event names that backend might use
    socket.on('new_message', handleNewMessage);
    socket.on('message', handleNewMessage);
    socket.on('system_message', handleSystemMessage);
    socket.on('group_update', handleSystemMessage);
    socket.on('new_conversation', handleNewConversation);
    socket.on('conversation_updated', handleNewConversation);
    socket.on('user_removed_from_group', handleUserRemovedFromGroup);
    socket.on('user_status', handleConnectionStatus);

    // Cleanup listeners on unmount or when socket changes
    return () => {
      socket.off('new_message', handleNewMessage);
      socket.off('message', handleNewMessage);
      socket.off('system_message', handleSystemMessage);
      socket.off('group_update', handleSystemMessage);
      socket.off('new_conversation', handleNewConversation);
      socket.off('conversation_updated', handleNewConversation);
      socket.off('user_removed_from_group', handleUserRemovedFromGroup);
      socket.off('user_status', handleConnectionStatus);
      socket.offAny();
    };
  }, [socket, isConnected, selectedConversation]);
  
  // Auto-join selected conversation when WebSocket connects (except announcements)
  useEffect(() => {
    if (isConnected && selectedConversation && socket && selectedConversation.type !== 'announcement') {
      joinConversation(selectedConversation._id);
    }
  }, [isConnected, selectedConversation, joinConversation, socket]);

  // Refs
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Helper function to check if user has specific permission
  const hasPermission = (permissionName: string) => {
    if (user?.role_name?.toLowerCase() === 'admin') return true; // Admins have all permissions
    return user?.permissions?.some(p => p.permission_name === permissionName && p.granted) || false;
  };

  // Check permissions
  const canSendMessages = hasPermission('send_messages');
  const canViewHistory = hasPermission('view_conversation_history');
  const canCreateGroups = hasPermission('create_group_conversations');
  const canSendAnnouncements = hasPermission('send_announcements');
  const canManageGroups = hasPermission('manage_group_conversations') || user?.role_name?.toLowerCase() === 'admin';
  
  // Scroll to bottom of messages
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  // Load conversations
  const loadConversations = async () => {
    if (!canViewHistory) {
      toast.error('You do not have permission to view conversations');
      return;
    }

    try {
      setLoading(true);
      const response = await messagingApi.getConversations() as any;
      
      if (response && response.success) {
        // Handle both 'conversations' and 'data' field names from API
        const conversationsData = response.conversations || response.data || [];
        
        // Map the backend response to frontend structure
        const mappedConversations = conversationsData.map((conv: any) => {
          return {
            _id: conv._id,
            type: conv.conversation_type || conv.type, // Map conversation_type to type
            title: conv.title || (conv.conversation_type === 'private' ? 
              conv.participants?.find((p: any) => p.user_id !== user?.id)?.name || 'Private Chat' : 
              'Untitled Conversation'),
            description: conv.description,
            participants: (conv.participants || []).map((p: any) => ({
              _id: p.user_id, // Map user_id to _id for consistency
              user_id: p.user_id,
              name: p.name,
              email: p.email,
              role_name: p.role_name, // Keep role_name for GroupManagementModal
              branch_name: p.branch_name, // Keep branch_name for GroupManagementModal
              joined_at: p.joined_at,
              is_admin: p.is_admin, // Include is_admin for permission checks
              show_previous_messages: p.show_previous_messages // Include for message visibility
            })),
            created_by: conv.created_by,
            created_at: conv.created_at,
            updated_at: conv.updated_at,
            last_message: conv.last_message ? {
              content: conv.last_message.content_preview || conv.last_message.content || '',
              sender_name: conv.last_message.sender_name || 'Unknown',
              created_at: conv.last_message.sent_at || conv.last_message.created_at || new Date().toISOString()
            } : undefined,
            unread_count: (conv.unread_count && conv.unread_count > 0) ? conv.unread_count : undefined,
            expiresAt: conv.expiresAt || undefined 
          };
        });
        setConversations(mappedConversations);
      } else {
        throw new Error('Failed to load conversations');
      }
    } catch (error: any) {
      toast.error(error.message || 'Failed to load conversations');
    } finally {
      setLoading(false);
    }
  };

  // Load messages for selected conversation
  const loadMessages = async (conversationId: string) => {
    try {
      setMessagesLoading(true);
      const response = await messagingApi.getConversationMessages(conversationId, {
        page: 1,
        limit: 50
      }) as any;
      
      if (response && response.success) {
        // Handle both 'messages' and 'data' field names from API
        const messagesData = response.messages || response.data || [];
        setMessages(messagesData);
        // Don't override selectedConversation here if it's already set
        if (response.conversation) {
          setSelectedConversation(response.conversation);
        }
        setTimeout(scrollToBottom, 100);
      } else {
        // Don't throw error for messages, just keep the conversation selected with empty messages
        setMessages([]);
      }
    } catch (error: any) {
      // Don't show error toast for messages loading failure, just set empty messages
      setMessages([]);
    } finally {
      setMessagesLoading(false);
    }
  };

  // Handle conversation selection
  const handleConversationSelect = (conversation: Conversation) => {
    // For announcements, don't treat them as regular conversations
    if (conversation.type === 'announcement') {
      // Leave previous conversation if any
      if (selectedConversation) {
        leaveConversation(selectedConversation._id);
      }
      
      setSelectedConversation(conversation);
      setMessages([]); // Clear messages for announcements
      return;
    }

    // For regular conversations (private/group chats)
    // Leave previous conversation if any
    if (selectedConversation) {
      leaveConversation(selectedConversation._id);
    }
    
    setSelectedConversation(conversation);
    
    // Join new conversation for real-time updates
    // Add a small delay to ensure WebSocket is ready
    if (isConnected) {
      joinConversation(conversation._id);
    } else {
      // Try again after a short delay
      setTimeout(() => {
        if (isConnected) {
          joinConversation(conversation._id);
        }
      }, 1000);
    }
    
    loadMessages(conversation._id);
  };

  // Handle media sent - refresh messages and update conversation list
  const handleMediaSent = async (messageType: 'image' | 'voice_note') => {
    // Refresh messages to show the new media immediately
    await loadMessages(selectedConversation._id);
    
    // Update conversation last message in the list
    const currentTime = new Date().toISOString();
    setConversations(prev => prev.map(conv => 
      conv._id === selectedConversation._id 
        ? {
            ...conv,
            last_message: {
              content: messageType === 'image' ? '📷 Image' : '🎤 Voice message',
              sender_name: user?.name || 'You',
              created_at: currentTime
            },
            updated_at: currentTime
          }
        : conv
    ));
  };

  // Handle message send
  const handleMessageSend = async (content: string, messageType: 'text' | 'announcement' = 'text') => {
    if (!selectedConversation || !canSendMessages) {
      toast.error('Cannot send message');
      return;
    }

    // Check if user can send announcement messages
    if (messageType === 'announcement' && !canSendAnnouncements) {
      toast.error('You do not have permission to send announcement messages');
      return;
    }

    try {
      const response = await messagingApi.sendMessage(selectedConversation._id, {
        content,
        message_type: messageType
      }) as any;

      if (response && response.success) {
        toast.success('Message sent successfully');
        
        // Always add the message to the UI immediately (this ensures real-time feel)
        const sentMessage = response.data || {};
        const newMessage = {
          _id: sentMessage._id || sentMessage.id || Date.now().toString(),
          conversation_id: selectedConversation._id,
          sender_id: user?.id || '',
          sender_name: user?.name || 'You',
          sender_role: user?.role_name || '',
          content: sentMessage.content || content,
          message_type: sentMessage.message_type || messageType,
          created_at: sentMessage.created_at || new Date().toISOString(),
          updated_at: sentMessage.updated_at || new Date().toISOString()
        };
        
        setMessages(prev => [...prev, newMessage]);
        setTimeout(scrollToBottom, 100);
        
        // Update conversation last message
        setConversations(prev => prev.map(conv => 
          conv._id === selectedConversation._id 
            ? {
                ...conv,
                last_message: {
                  content: newMessage.message_type === 'image' ? '📷 Image' : 
                          newMessage.message_type === 'voice_note' ? '🎤 Voice message' : 
                          newMessage.content,
                  sender_name: newMessage.sender_name,
                  created_at: newMessage.created_at
                },
                updated_at: newMessage.created_at
              }
            : conv
        ));
        
        // Note: WebSocket events will also update the UI if working properly
      } else {
        throw new Error('Failed to send message');
      }
    } catch (error: any) {
      toast.error(error.message || 'Failed to send message');
    }
  };

  // Handle new conversation creation
  const handleConversationCreated = async () => {
    setShowNewConversation(false);
    await loadConversations();
  };

  // Handle new announcement creation
  const handleAnnouncementCreated = async () => {
    setShowNewAnnouncement(false);
    await loadConversations();
  };

  // Handle announcement deletion
  const handleAnnouncementDeleted = async () => {
    setSelectedConversation(null);
    setMessages([]);
    await loadConversations();
  };

  // Handle conversation updates (for group management)
  const handleConversationUpdated = async () => {
    await loadConversations();
    // Refresh the selected conversation if it exists
    if (selectedConversation) {
      // Find the updated conversation in the new list
      const response = await messagingApi.getConversations() as any;
      if (response && response.success) {
        const conversationsData = response.conversations || response.data || [];
        const updatedConversation = conversationsData.find((conv: any) => conv._id === selectedConversation._id);
        if (updatedConversation) {
          // Map the updated conversation structure
          const mappedConversation = {
            _id: updatedConversation._id,
            type: updatedConversation.conversation_type || updatedConversation.type,
            title: updatedConversation.title || 'Untitled Conversation',
            description: updatedConversation.description,
            participants: (updatedConversation.participants || []).map((p: any) => ({
              user_id: p.user_id,
              name: p.name,
              email: p.email,
              role_name: p.role_name,
              branch_name: p.branch_name,
              joined_at: p.joined_at,
              is_admin: p.is_admin,
              show_previous_messages: p.show_previous_messages
            })),
            created_by: updatedConversation.created_by,
            created_at: updatedConversation.created_at,
            updated_at: updatedConversation.updated_at,
            last_message: updatedConversation.last_message
          };
          setSelectedConversation(mappedConversation);
        }
      }
    }
  };

  // Filter conversations based on search and active tab
  const filteredConversations = conversations.filter(conversation => {
    const matchesSearch = conversation.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      conversation.participants.some(p => 
        p.name.toLowerCase().includes(searchQuery.toLowerCase())
      );
    
    const matchesTab = activeTab === 'chats' 
      ? conversation.type !== 'announcement'
      : conversation.type === 'announcement';
    
    return matchesSearch && matchesTab;
  });

  // Load conversations on component mount
  useEffect(() => {
    if (isAuthenticated && canViewHistory) {
      loadConversations();
    }
  }, [isAuthenticated, canViewHistory]);

  // Cleanup: leave conversation when component unmounts or conversation changes
  useEffect(() => {
    return () => {
      if (selectedConversation) {
        leaveConversation(selectedConversation._id);
      }
    };
  }, [selectedConversation, leaveConversation]);

  // Check route protection
  if (!canAccess) {
    return null;
  }

  if (!isAuthenticated) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Authentication Required</h2>
          <p className="text-gray-600">Please log in to access messaging.</p>
        </div>
      </div>
    );
  }

  if (!canViewHistory) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Access Denied</h2>
          <p className="text-gray-600">You do not have permission to view conversations.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full h-screen bg-white flex flex-col">
      {/* Modern Header with Glass Effect */}
      <div className="backdrop-blur-xl bg-white/80 border-b border-gray-200/50 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            {/* Left Section - Logo & Title */}
            <div className="flex items-center space-x-4">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl blur opacity-20"></div>
                <div className="relative bg-gradient-to-r from-blue-600 to-indigo-600 p-3 rounded-xl">
                  <MessageSquare className="h-7 w-7 text-white" />
                </div>
              </div>
              <div>
                <div className="flex items-center space-x-3">
                  <h1 className="text-2xl font-bold bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent">
                    Messaging Hub
                  </h1>
                  {/* Enhanced Connection Status */}
                  <div className="flex items-center space-x-2 px-3 py-1 rounded-full bg-gray-100/50 border border-gray-200/50">
                    <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-emerald-500 animate-pulse' : 'bg-red-500'}`}></div>
                    <span className={`text-xs font-medium ${isConnected ? 'text-emerald-700' : 'text-red-700'}`}>
                      {isConnected ? 'Live' : 'Offline'}
                    </span>
                  </div>
                </div>
                <p className="text-sm text-gray-600 mt-1">
                  Real-time communication hub for your team
                  {wsError && <span className="text-red-500 ml-1">• {wsError}</span>}
                </p>
              </div>
            </div>

            {/* Right Section - User Info & Actions */}
            <div className="flex items-center space-x-4">
              {/* User Profile Card */}
              <div className="hidden md:flex items-center space-x-3 bg-white/70 backdrop-blur-sm rounded-xl px-4 py-2 border border-gray-200/50">
                <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full flex items-center justify-center">
                  <span className="text-white text-sm font-medium">
                    {user?.name?.charAt(0)?.toUpperCase() || 'U'}
                  </span>
                </div>
                <div className="text-right">
                  <div className="text-sm font-medium text-gray-900">{user?.name}</div>
                  <div className="text-xs text-gray-500">{user?.role_name}</div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center space-x-2">
                {canCreateGroups && (
                  <button
                    onClick={() => setShowNewConversation(true)}
                    className="group relative flex items-center space-x-2 px-4 py-2.5 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white rounded-xl transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-105"
                  >
                    <Plus className="h-4 w-4 transition-transform group-hover:rotate-90" />
                    <span className="font-medium">New Chat</span>
                  </button>
                )}
                {canSendAnnouncements && (
                  <button
                    onClick={() => setShowNewAnnouncement(true)}
                    className="group relative flex items-center space-x-2 px-4 py-2.5 bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white rounded-xl transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-105"
                  >
                    <Megaphone className="h-4 w-4 transition-transform group-hover:scale-110" />
                    <span className="font-medium">Announce</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Container - now fullscreen */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <div className="w-96 border-r border-gray-200/50 flex flex-col bg-gradient-to-b from-gray-50/50 to-white/50">
          
          {/* Modern Tab Navigation */}
          <div className="p-4 border-b border-gray-200/50">
            <div className="flex bg-gray-100/50 rounded-xl p-1 backdrop-blur-sm">
              <button
                onClick={() => setActiveTab('chats')}
                className={`flex-1 flex items-center justify-center space-x-2 px-4 py-3 rounded-lg text-sm font-medium transition-all duration-200 ${
                  activeTab === 'chats'
                    ? 'bg-white text-blue-600 shadow-sm transform scale-105'
                    : 'text-gray-600 hover:text-gray-800 hover:bg-white/50'
                }`}
              >
                <MessageSquare className={`h-4 w-4 ${activeTab === 'chats' ? 'text-blue-600' : 'text-gray-500'}`} />
                <span>Chats</span>
                {conversations.filter(c => c.type !== 'announcement').length > 0 && (
                  <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                    activeTab === 'chats' 
                      ? 'bg-blue-100 text-blue-700' 
                      : 'bg-gray-200 text-gray-600'
                  }`}>
                    {conversations.filter(c => c.type !== 'announcement').length}
                  </span>
                )}
              </button>
              <button
                onClick={() => setActiveTab('announcements')}
                className={`flex-1 flex items-center justify-center space-x-2 px-4 py-3 rounded-lg text-sm font-medium transition-all duration-200 ${
                  activeTab === 'announcements'
                    ? 'bg-white text-orange-600 shadow-sm transform scale-105'
                    : 'text-gray-600 hover:text-gray-800 hover:bg-white/50'
                }`}
              >
                <Megaphone className={`h-4 w-4 ${activeTab === 'announcements' ? 'text-orange-600' : 'text-gray-500'}`} />
                <span>Announcements</span>
                {conversations.filter(c => c.type === 'announcement').length > 0 && (
                  <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                    activeTab === 'announcements' 
                      ? 'bg-orange-100 text-orange-700' 
                      : 'bg-gray-200 text-gray-600'
                  }`}>
                    {conversations.filter(c => c.type === 'announcement').length}
                  </span>
                )}
              </button>
            </div>
          </div>

          {/* Enhanced Search */}
          <div className="p-4 border-b border-gray-200/50">
            <div className="relative group">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400 group-focus-within:text-blue-500 transition-colors" />
              <input
                type="text"
                placeholder={`Search ${activeTab}...`}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-3 bg-gray-50/50 border border-gray-200/50 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500/50 focus:bg-white transition-all duration-200 text-sm placeholder-gray-400"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              )}
            </div>
          </div>

          {/* Quick Stats */}
          <div className="px-4 py-3 border-b border-gray-200/50">
            <div className="flex items-center justify-between text-xs text-gray-500">
              <span className="flex items-center space-x-1">
                <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-emerald-400' : 'bg-red-400'}`}></div>
                <span>{filteredConversations.length} {activeTab}</span>
              </span>
              <span>{isConnected ? 'Real-time sync' : 'Offline mode'}</span>
            </div>
          </div>

          {/* Conversations List */}
          <div className="flex-1 overflow-y-auto">
            {loading ? (
              <div className="flex flex-col items-center justify-center h-48 space-y-4">
                <div className="relative">
                  <div className="w-12 h-12 border-4 border-blue-200 rounded-full animate-spin"></div>
                  <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin absolute top-0 left-0"></div>
                </div>
                <div className="text-center">
                  <p className="text-sm font-medium text-gray-700">Loading {activeTab}...</p>
                  <p className="text-xs text-gray-500 mt-1">Please wait a moment</p>
                </div>
              </div>
            ) : filteredConversations.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-48 px-6 text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-gray-100 to-gray-200 rounded-2xl flex items-center justify-center mb-4">
                  {activeTab === 'chats' ? (
                    <MessageSquare className="w-8 h-8 text-gray-400" />
                  ) : (
                    <Megaphone className="w-8 h-8 text-gray-400" />
                  )}
                </div>
                <h3 className="text-sm font-medium text-gray-700 mb-1">
                  {searchQuery ? `No ${activeTab} found` : `No ${activeTab} yet`}
                </h3>
                <p className="text-xs text-gray-500">
                  {searchQuery 
                    ? `Try adjusting your search terms`
                    : activeTab === 'chats' 
                      ? 'Start a conversation with your team'
                      : 'Create your first announcement'
                  }
                </p>
              </div>
            ) : (
              <div className="py-2">
                <ConversationList
                  conversations={filteredConversations}
                  selectedConversation={selectedConversation}
                  onConversationSelect={handleConversationSelect}
                  currentUserId={user?.id || ''}
                />
              </div>
            )}
          </div>
        </div>

        {/* Message Area */}
        <div className="flex-1 flex flex-col bg-white/30 backdrop-blur-sm">
          {selectedConversation ? (
            <>
              {/* Modern Message Header */}
              <div className="px-6 py-4 border-b border-gray-200/50 bg-gradient-to-r from-white/80 to-gray-50/50 backdrop-blur-sm">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    {/* Conversation Icon */}
                    <div className={`p-3 rounded-xl ${
                      selectedConversation.type === 'announcement' 
                        ? 'bg-gradient-to-r from-orange-100 to-orange-200 text-orange-600' 
                        : selectedConversation.type === 'group' 
                          ? 'bg-gradient-to-r from-blue-100 to-blue-200 text-blue-600' 
                          : 'bg-gradient-to-r from-emerald-100 to-emerald-200 text-emerald-600'
                    }`}>
                      {selectedConversation.type === 'group' && <Users className="h-5 w-5" />}
                      {selectedConversation.type === 'announcement' && <Megaphone className="h-5 w-5" />}
                      {selectedConversation.type === 'private' && <MessageSquare className="h-5 w-5" />}
                    </div>
                    
                    <div>
                      <h2 className="text-xl font-bold text-gray-900">
                        {selectedConversation.title}
                      </h2>
                      <div className="flex items-center space-x-3 text-sm text-gray-600 mt-1">
                        {selectedConversation.type !== 'private' && (
                          <span className="flex items-center space-x-1">
                            <Users className="h-4 w-4" />
                            <span>
                              {selectedConversation.participants.length} member
                              {selectedConversation.participants.length !== 1 ? 's' : ''}
                            </span>
                          </span>
                        )}
                        <div className="flex items-center space-x-1">
                          <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-emerald-500 animate-pulse' : 'bg-red-500'}`}></div>
                          <span className={isConnected ? 'text-emerald-600' : 'text-red-600'}>
                            {isConnected ? 'Active now' : 'Disconnected'}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Actions */}
                  <div className="flex items-center space-x-2">
                    {selectedConversation.type === 'group' && canManageGroups && (
                      <button
                        onClick={() => setShowGroupManagement(true)}
                        className="flex items-center space-x-2 px-4 py-2 text-sm bg-white/70 text-gray-700 border border-gray-200/50 rounded-xl hover:bg-white hover:border-gray-300 transition-all duration-200 backdrop-blur-sm"
                        title="Manage group members"
                      >
                        <Settings className="h-4 w-4" />
                        <span className="hidden sm:inline">Manage</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Messages Content */}
              <div className="flex-1 overflow-y-auto">
                {selectedConversation.type === 'announcement' ? (
                  <AnnouncementDetail
                    announcement={selectedConversation}
                    currentUser={user}
                    onAnnouncementDeletedAction={handleAnnouncementDeleted}
                  />
                ) : (
                  <div className="p-6">
                    {messagesLoading ? (
                      <div className="flex flex-col items-center justify-center h-48 space-y-4">
                        <div className="relative">
                          <div className="w-12 h-12 border-4 border-blue-200 rounded-full animate-spin"></div>
                          <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin absolute top-0 left-0"></div>
                        </div>
                        <div className="text-center">
                          <p className="text-sm font-medium text-gray-700">Loading messages...</p>
                          <p className="text-xs text-gray-500 mt-1">Fetching conversation history</p>
                        </div>
                      </div>
                    ) : (
                      <MessageThread 
                        key={`messages-${messages.length}-${selectedConversation._id}`}
                        messages={messages}
                        currentUserId={user?.id || ''}
                        selectedConversation={selectedConversation}
                      />
                    )}
                    <div ref={messagesEndRef} />
                  </div>
                )}
              </div>

              {/* Enhanced Message Composer */}
              {canSendMessages && selectedConversation.type !== 'announcement' && (
                <div className="border-t border-gray-200/50 bg-white/80 backdrop-blur-sm">
                  <MessageComposer
                    onSendMessage={handleMessageSend}
                    onMediaSent={handleMediaSent}
                    conversationType={selectedConversation.type}
                    canSendAnnouncements={canSendAnnouncements}
                    selectedConversation={selectedConversation}
                  />
                </div>
              )}
            </>
          ) : (
            /* Enhanced Empty State */
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center max-w-md">
                <div className="relative mb-8">
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-400 to-indigo-400 rounded-full blur-2xl opacity-20"></div>
                  <div className="relative w-24 h-24 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full mx-auto flex items-center justify-center">
                    <MessageSquare className="h-12 w-12 text-white" />
                  </div>
                </div>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-4">
                  Welcome to Messaging Hub
                </h2>
                <p className="text-gray-600 mb-8 leading-relaxed">
                  {activeTab === 'chats' 
                    ? 'Select a conversation from the sidebar to start collaborating with your team members in real-time.'
                    : 'Choose an announcement to view its details, recipients, and engagement metrics.'
                  }
                </p>
                
                {/* Feature highlights */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-left">
                  <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-gray-200/50">
                    <div className="flex items-center space-x-3 mb-2">
                      <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                        <MessageSquare className="h-4 w-4 text-blue-600" />
                      </div>
                      <h4 className="font-semibold text-gray-900">Real-time Chat</h4>
                    </div>
                    <p className="text-sm text-gray-600">Instant messaging with live status updates</p>
                  </div>
                  <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-gray-200/50">
                    <div className="flex items-center space-x-3 mb-2">
                      <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center">
                        <Megaphone className="h-4 w-4 text-orange-600" />
                      </div>
                      <h4 className="font-semibold text-gray-900">Announcements</h4>
                    </div>
                    <p className="text-sm text-gray-600">Broadcast important updates to your team</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* New conversation modal */}
      {showNewConversation && (
        <NewConversationModal
          isOpen={showNewConversation}
          onClose={() => setShowNewConversation(false)}
          onConversationCreated={handleConversationCreated}
          canCreateGroups={canCreateGroups}
          currentUser={user}
        />
      )}

      {/* New announcement modal */}
      {showNewAnnouncement && (
        <NewAnnouncementModal
          isOpen={showNewAnnouncement}
          onCloseAction={() => setShowNewAnnouncement(false)}
          onAnnouncementCreatedAction={handleAnnouncementCreated}
          currentUser={user}
        />
      )}

      {/* Group management modal */}
      {showGroupManagement && selectedConversation && (
        <GroupManagementModal
          isOpen={showGroupManagement}
          onCloseAction={() => setShowGroupManagement(false)}
          conversation={selectedConversation}
          currentUserId={user?.id || ''}
          onConversationUpdatedAction={handleConversationUpdated}
        />
      )}
    </div>
  );
}