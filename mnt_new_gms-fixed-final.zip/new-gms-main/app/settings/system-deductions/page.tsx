"use client";

import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import Link from "next/link";
import { ArrowLeft, Plus, Edit, Trash2, Shield, AlertCircle, Check, X, Settings } from "lucide-react";
import { payrollApi } from "../../../services/api";
import { useAuth } from "../../context/AuthContext";
import { useRouteProtection } from "../../../services/route-protection";

interface SystemDeduction {
  _id: string;
  name: string;
  description: string;
  type: 'fixed' | 'percentage';
  default_amount: number;
  frequency: 'daily' | 'weekly' | 'monthly' | 'per_pay_period' | 'one_time';
  max_percentage_of_pay?: number;
  is_mandatory: boolean;
  legal_required: boolean;
  active: boolean;
  created_at: string;
  updated_at: string;
}

export default function SystemDeductionsPage() {
  const { user, isAuthenticated } = useAuth();
  
  // Admin only - strict access control
  const hasAccess = useRouteProtection(isAuthenticated, user, { adminOnly: true });
  
  const [deductions, setDeductions] = useState<SystemDeduction[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingDeduction, setEditingDeduction] = useState<SystemDeduction | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    type: 'fixed' as 'fixed' | 'percentage',
    default_amount: 0,
    frequency: 'monthly' as 'daily' | 'weekly' | 'monthly' | 'per_pay_period' | 'one_time',
    max_percentage_of_pay: 0,
    is_mandatory: false,
    legal_required: false,
    active: true
  });

  const isAdmin = user?.role_name?.toLowerCase() === 'admin';

  useEffect(() => {
    if (isAdmin) {
      fetchSystemDeductions();
    }
  }, [isAdmin]);

  const fetchSystemDeductions = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await payrollApi.getDeductionTypes({ include_inactive: true });
      setDeductions(response.deduction_types || []);
    } catch (err: any) {
      console.error('Error fetching system deductions:', err);
      setError(err.response?.data?.message || 'Failed to fetch system deductions');
    } finally {
      setLoading(false);
    }
  };

  const handleAddDeduction = () => {
    setFormData({
      name: '',
      description: '',
      type: 'fixed',
      default_amount: 0,
      frequency: 'monthly',
      max_percentage_of_pay: 0,
      is_mandatory: false,
      legal_required: false,
      active: true
    });
    setEditingDeduction(null);
    setShowAddModal(true);
  };

  const handleEditDeduction = (deduction: SystemDeduction) => {
    setFormData({
      name: deduction.name,
      description: deduction.description,
      type: deduction.type,
      default_amount: deduction.default_amount,
      frequency: deduction.frequency,
      max_percentage_of_pay: deduction.max_percentage_of_pay || 0,
      is_mandatory: deduction.is_mandatory,
      legal_required: deduction.legal_required,
      active: deduction.active
    });
    setEditingDeduction(deduction);
    setShowAddModal(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim()) {
      setError('Deduction name is required');
      return;
    }

    if (formData.default_amount <= 0) {
      setError('Default amount must be greater than 0');
      return;
    }

    try {
      setError(null);
      
      if (editingDeduction) {
        await payrollApi.updateDeductionType(editingDeduction._id, formData);
      } else {
        await payrollApi.createDeductionType(formData);
      }
      
      await fetchSystemDeductions();
      setShowAddModal(false);
      setEditingDeduction(null);
    } catch (err: any) {
      console.error('Error saving deduction:', err);
      setError(err.response?.data?.message || 'Failed to save deduction');
    }
  };

  const handleToggleStatus = async (deduction: SystemDeduction) => {
    try {
      await payrollApi.updateDeductionType(deduction._id, {
        ...deduction,
        active: !deduction.active
      });
      await fetchSystemDeductions();
    } catch (err: any) {
      console.error('Error updating deduction status:', err);
      setError(err.response?.data?.message || 'Failed to update deduction status');
    }
  };

  const handleDeleteDeduction = async (deduction: SystemDeduction) => {
    if (!confirm(`Are you sure you want to delete "${deduction.name}"? This action cannot be undone.`)) {
      return;
    }

    try {
      await payrollApi.deleteDeductionType(deduction._id);
      await fetchSystemDeductions();
    } catch (err: any) {
      console.error('Error deleting deduction:', err);
      setError(err.response?.data?.message || 'Failed to delete deduction');
    }
  };

  const formatAmount = (amount: number, type: string) => {
    if (type === 'percentage') {
      return `${amount}%`;
    }
    return new Intl.NumberFormat('en-AE', {
      style: 'currency',
      currency: 'AED',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const getFrequencyLabel = (frequency: string) => {
    const labels = {
      daily: 'Daily',
      weekly: 'Weekly',
      monthly: 'Monthly',
      per_pay_period: 'Per Pay Period',
      one_time: 'One Time'
    };
    return labels[frequency as keyof typeof labels] || frequency;
  };

  if (!isAdmin) {
    return (
      <div className="p-6">
        <Card className="border-red-200">
          <CardContent className="p-6">
            <div className="flex items-center gap-3 text-red-600">
              <Shield className="w-5 h-5" />
              <span className="font-medium">Access Denied</span>
            </div>
            <p className="text-red-600 mt-2">Only administrators can access system deductions settings.</p>
            <Link href="/settings">
              <Button className="mt-4" variant="outline">
                Back to Settings
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          <span className="ml-3 text-gray-600">Loading system deductions...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/settings">
            <Button variant="outline" size="sm" className="flex items-center gap-2">
              <ArrowLeft className="w-4 h-4" />
              Back to Settings
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">System Deductions</h1>
            <p className="text-gray-600 mt-2">
              Manage default deduction types available for all employees
            </p>
          </div>
        </div>
        <Button onClick={handleAddDeduction} className="flex items-center gap-2">
          <Plus className="w-4 h-4" />
          Add Deduction Type
        </Button>
      </div>

      {/* Error Display */}
      {error && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3 text-red-600">
              <AlertCircle className="w-5 h-5" />
              <span className="font-medium">{error}</span>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Settings className="w-8 h-8 text-blue-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-500">Total Types</p>
                <p className="text-2xl font-semibold text-gray-900">{deductions.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Check className="w-8 h-8 text-green-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-500">Active</p>
                <p className="text-2xl font-semibold text-gray-900">
                  {deductions.filter(d => d.active).length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Shield className="w-8 h-8 text-red-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-500">Legal Required</p>
                <p className="text-2xl font-semibold text-gray-900">
                  {deductions.filter(d => d.legal_required).length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <AlertCircle className="w-8 h-8 text-orange-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-500">Mandatory</p>
                <p className="text-2xl font-semibold text-gray-900">
                  {deductions.filter(d => d.is_mandatory).length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Deductions List */}
      <Card>
        <CardHeader>
          <CardTitle>Deduction Types</CardTitle>
        </CardHeader>
        <CardContent>
          {deductions.length === 0 ? (
            <div className="text-center py-8">
              <Settings className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 mb-4">No system deductions configured yet.</p>
              <Button onClick={handleAddDeduction} className="flex items-center gap-2">
                <Plus className="w-4 h-4" />
                Add First Deduction Type
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {deductions.map((deduction) => (
                <div key={deduction._id} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="font-medium text-gray-900">{deduction.name}</h3>
                        <div className="flex items-center gap-2">
                          {deduction.active ? (
                            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                              <Check className="w-3 h-3 mr-1" />
                              Active
                            </span>
                          ) : (
                            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                              <X className="w-3 h-3 mr-1" />
                              Inactive
                            </span>
                          )}
                          {deduction.legal_required && (
                            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800">
                              <Shield className="w-3 h-3 mr-1" />
                              Legal Required
                            </span>
                          )}
                          {deduction.is_mandatory && (
                            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                              <AlertCircle className="w-3 h-3 mr-1" />
                              Mandatory
                            </span>
                          )}
                        </div>
                      </div>
                      
                      <p className="text-gray-600 text-sm mb-3">{deduction.description}</p>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                        <div>
                          <span className="font-medium">Default Amount:</span> {formatAmount(deduction.default_amount, deduction.type)}
                        </div>
                        <div>
                          <span className="font-medium">Type:</span> {deduction.type === 'percentage' ? 'Percentage' : 'Fixed Amount'}
                        </div>
                        <div>
                          <span className="font-medium">Frequency:</span> {getFrequencyLabel(deduction.frequency)}
                        </div>
                      </div>

                      {deduction.max_percentage_of_pay && (
                        <div className="mt-2 text-sm">
                          <span className="font-medium">Max % of Pay:</span> {deduction.max_percentage_of_pay}%
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-2 ml-4">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleToggleStatus(deduction)}
                        className="flex items-center gap-1"
                      >
                        {deduction.active ? (
                          <>
                            <X className="w-3 h-3" />
                            Deactivate
                          </>
                        ) : (
                          <>
                            <Check className="w-3 h-3" />
                            Activate
                          </>
                        )}
                      </Button>
                      
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleEditDeduction(deduction)}
                        className="flex items-center gap-1"
                      >
                        <Edit className="w-3 h-3" />
                        Edit
                      </Button>

                      {!deduction.legal_required && !deduction.is_mandatory && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDeleteDeduction(deduction)}
                          className="flex items-center gap-1 text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="w-3 h-3" />
                          Delete
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add/Edit Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
              <CardTitle className="flex items-center gap-2">
                <Plus className="w-5 h-5" />
                {editingDeduction ? 'Edit' : 'Add'} System Deduction
              </CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowAddModal(false)}
                className="h-6 w-6 p-0"
              >
                <X className="w-4 h-4" />
              </Button>
            </CardHeader>
            
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Deduction Name *
                  </label>
                  <Input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g., Health Insurance, Loan Repayment"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Description
                  </label>
                  <textarea
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Describe this deduction type..."
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none"
                    rows={3}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Type *
                    </label>
                    <select
                      value={formData.type}
                      onChange={(e) => setFormData({ ...formData, type: e.target.value as 'fixed' | 'percentage' })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      required
                    >
                      <option value="fixed">Fixed Amount</option>
                      <option value="percentage">Percentage</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {formData.type === 'percentage' ? 'Default Percentage (%)' : 'Default Amount (AED)'} *
                    </label>
                    <Input
                      type="number"
                      min="0"
                      step={formData.type === 'percentage' ? '0.01' : '1'}
                      value={formData.default_amount}
                      onChange={(e) => setFormData({ ...formData, default_amount: parseFloat(e.target.value) || 0 })}
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Frequency *
                    </label>
                    <select
                      value={formData.frequency}
                      onChange={(e) => setFormData({ ...formData, frequency: e.target.value as any })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      required
                    >
                      <option value="daily">Daily</option>
                      <option value="weekly">Weekly</option>
                      <option value="monthly">Monthly</option>
                      <option value="per_pay_period">Per Pay Period</option>
                      <option value="one_time">One Time</option>
                    </select>
                  </div>

                  {formData.type === 'percentage' && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Max % of Pay (Optional)
                      </label>
                      <Input
                        type="number"
                        min="0"
                        max="100"
                        step="0.01"
                        value={formData.max_percentage_of_pay}
                        onChange={(e) => setFormData({ ...formData, max_percentage_of_pay: parseFloat(e.target.value) || 0 })}
                      />
                    </div>
                  )}
                </div>

                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <input
                      type="checkbox"
                      id="is_mandatory"
                      checked={formData.is_mandatory}
                      onChange={(e) => setFormData({ ...formData, is_mandatory: e.target.checked })}
                      className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    />
                    <label htmlFor="is_mandatory" className="text-sm text-gray-700">
                      This deduction is mandatory for all employees
                    </label>
                  </div>

                  <div className="flex items-center gap-3">
                    <input
                      type="checkbox"
                      id="legal_required"
                      checked={formData.legal_required}
                      onChange={(e) => setFormData({ ...formData, legal_required: e.target.checked })}
                      className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    />
                    <label htmlFor="legal_required" className="text-sm text-gray-700">
                      This is a legally required deduction (e.g., tax, court order)
                    </label>
                  </div>

                  <div className="flex items-center gap-3">
                    <input
                      type="checkbox"
                      id="active"
                      checked={formData.active}
                      onChange={(e) => setFormData({ ...formData, active: e.target.checked })}
                      className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    />
                    <label htmlFor="active" className="text-sm text-gray-700">
                      Active (available for selection)
                    </label>
                  </div>
                </div>

                <div className="flex gap-3 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setShowAddModal(false)}
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    className="flex-1 flex items-center gap-2"
                  >
                    <Plus className="w-4 h-4" />
                    {editingDeduction ? 'Update' : 'Create'} Deduction
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}