'use client';

import React, { useState, useEffect } from 'react';
import ServiceTypeModal from '../new_reg/ServiceTypeModal';
import CarPartsModal from './CarPartsModal';
import api from '@/services/api';

interface Variation {
  _id: string;
  code: string;
  description: string;
  defaultLaborHours: number;
  defaultStages: string[];
  created_at?: string;
  updated_at?: string;
}

const SettingsPage: React.FC = () => {
  const [isServiceTypeModalOpen, setIsServiceTypeModalOpen] = useState(false);
  const [isCarPartsModalOpen, setIsCarPartsModalOpen] = useState(false);
  const [variations, setVariations] = useState<Variation[]>([]);
  const [carPartsCount, setCarPartsCount] = useState(0);
  const [isLoadingVariations, setIsLoadingVariations] = useState(false);
  const [isLoadingCarParts, setIsLoadingCarParts] = useState(false);

  // Fetch variations and car parts count when component mounts
  useEffect(() => {
    fetchVariations();
    fetchCarPartsCount();
  }, []);

  // Fetch existing variations (service types)
  const fetchVariations = async () => {
    try {
      setIsLoadingVariations(true);
      const response = await api.get("/api/variations");
      const variationsData = response || [];
      setVariations(Array.isArray(variationsData) ? variationsData : []);
    } catch (error) {
      console.error("Error fetching variations:", error);
    } finally {
      setIsLoadingVariations(false);
    }
  };

  // Refresh variations after creating a new one
  const refreshVariations = async (): Promise<Variation[]> => {
    await fetchVariations();
    return variations;
  };

  // Fetch car parts count
  const fetchCarPartsCount = async () => {
    try {
      setIsLoadingCarParts(true);
      const response = await api.get("/api/car-parts");
      const carPartsData = response || [];
      setCarPartsCount(Array.isArray(carPartsData) ? carPartsData.length : 0);
    } catch (error) {
      console.error("Error fetching car parts:", error);
      setCarPartsCount(0);
    } finally {
      setIsLoadingCarParts(false);
    }
  };

  // Handle service type added (close modal and refresh)
  const handleServiceAdded = (newService: { _id: string; code: string; description: string }) => {
    console.log('New service added:', newService);
    setIsServiceTypeModalOpen(false);
    fetchVariations(); // Refresh the list
  };

  // Handle car parts modal close
  const handleCarPartsModalClose = () => {
    setIsCarPartsModalOpen(false);
    fetchCarPartsCount(); // Refresh the count
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Settings</h1>
          <p className="text-gray-600 mt-2">
            Manage your application settings and preferences
          </p>
        </div>

        {/* Settings Sections */}
        <div className="space-y-6">
          
          {/* Service Types Management Section */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <div>
                  <h2 className="text-xl font-semibold text-gray-900">Service Types</h2>
                  <p className="text-gray-600 mt-1">
                    Manage service types and their associated stages
                  </p>
                </div>
                <button
                  onClick={() => setIsServiceTypeModalOpen(true)}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                  </svg>
                  Manage Service Types
                </button>
              </div>

              {/* Service Types List */}
              {isLoadingVariations ? (
                <div className="flex justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                </div>
              ) : (
                <div className="overflow-hidden rounded-lg border border-gray-200">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Code
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Description
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Labor Hours
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Stages
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {variations.length > 0 ? (
                        variations.map((variation) => (
                          <tr key={variation._id} className="hover:bg-gray-50">
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className="font-mono text-sm font-medium text-gray-900">
                                {variation.code}
                              </span>
                            </td>
                            <td className="px-6 py-4">
                              <span className="text-sm text-gray-900">{variation.description}</span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className="text-sm text-gray-900">{variation.defaultLaborHours}h</span>
                            </td>
                            <td className="px-6 py-4">
                              <span className="text-sm text-gray-600">
                                {variation.defaultStages.length} stage{variation.defaultStages.length !== 1 ? 's' : ''}
                              </span>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={4} className="px-6 py-12 text-center">
                            <div className="text-gray-500">
                              <svg className="w-12 h-12 mx-auto mb-4 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                              </svg>
                              <p className="text-lg font-medium">No service types found</p>
                              <p className="text-sm mt-1">Create your first service type to get started</p>
                            </div>
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>

          {/* Car Parts Management Section */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <div>
                  <h2 className="text-xl font-semibold text-gray-900">Car Parts</h2>
                  <p className="text-gray-600 mt-1">
                    Manage available car parts for selection in registrations
                  </p>
                </div>
                <button
                  onClick={() => setIsCarPartsModalOpen(true)}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                  </svg>
                  Manage Car Parts
                </button>
              </div>

              {/* Car Parts Summary */}
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Total Car Parts Configured</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {isLoadingCarParts ? (
                        <span className="inline-block animate-pulse">...</span>
                      ) : (
                        carPartsCount
                      )}
                    </p>
                  </div>
                  <div className="text-gray-400">
                    <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} 
                        d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
                    </svg>
                  </div>
                </div>
                <p className="text-sm text-gray-500 mt-3">
                  Car parts are organized by categories: Exterior, Glass, Mechanical, and Interior
                </p>
              </div>
            </div>
          </div>

          {/* Future Settings Sections */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="p-6">
              <div className="text-center py-8">
                <div className="w-16 h-16 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
                  <svg 
                    className="w-8 h-8 text-gray-400" 
                    fill="none" 
                    stroke="currentColor" 
                    viewBox="0 0 24 24"
                  >
                    <path 
                      strokeLinecap="round" 
                      strokeLinejoin="round" 
                      strokeWidth={2} 
                      d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" 
                    />
                    <path 
                      strokeLinecap="round" 
                      strokeLinejoin="round" 
                      strokeWidth={2} 
                      d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" 
                    />
                  </svg>
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  Additional Settings
                </h3>
                <p className="text-gray-500 max-w-sm mx-auto">
                  More configuration options will be added here in future updates.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Service Type Modal */}
      <ServiceTypeModal
        isOpen={isServiceTypeModalOpen}
        onClose={() => setIsServiceTypeModalOpen(false)}
        onServiceAdded={handleServiceAdded}
        variations={variations}
        refreshVariations={refreshVariations}
      />

      {/* Car Parts Modal */}
      <CarPartsModal
        isOpen={isCarPartsModalOpen}
        onClose={handleCarPartsModalClose}
      />
    </div>
  );
};

export default SettingsPage;