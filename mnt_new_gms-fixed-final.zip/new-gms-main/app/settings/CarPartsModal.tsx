'use client';

import React, { useState, useEffect } from 'react';
import api from '@/services/api';
import { toast } from 'react-hot-toast';

interface CarPart {
  _id: string;
  name: string;
  category: string;
  createdAt?: string;
  updatedAt?: string;
}

interface CarPartsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPartAdded?: (part: CarPart) => void;
  onPartUpdated?: (part: CarPart) => void;
  onPartDeleted?: (partId: string) => void;
}

type TabType = 'view' | 'add';

const CATEGORIES = ['Exterior', 'Glass', 'Mechanical', 'Interior'];

const CarPartsModal: React.FC<CarPartsModalProps> = ({
  isOpen,
  onClose,
  onPartAdded,
  onPartUpdated,
  onPartDeleted
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('view');
  const [carParts, setCarParts] = useState<CarPart[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  
  // Add new part state
  const [newPartName, setNewPartName] = useState('');
  const [newPartCategory, setNewPartCategory] = useState('Exterior');
  
  // Edit part state
  const [editingPart, setEditingPart] = useState<CarPart | null>(null);
  const [editName, setEditName] = useState('');
  const [editCategory, setEditCategory] = useState('');
  
  // Delete confirmation state
  const [deletingPart, setDeletingPart] = useState<CarPart | null>(null);

  // Fetch car parts when modal opens
  useEffect(() => {
    if (isOpen) {
      fetchCarParts();
    }
  }, [isOpen]);

  const fetchCarParts = async () => {
    try {
      setIsLoading(true);
      setError('');
      const response = await api.get('/api/car-parts');
      setCarParts(response || []);
    } catch (error) {
      console.error('Error fetching car parts:', error);
      setError('Failed to load car parts');
      toast.error('Failed to load car parts');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddPart = async () => {
    if (!newPartName.trim()) {
      toast.error('Part name is required');
      return;
    }

    try {
      setIsLoading(true);
      const response = await api.post('/api/car-parts', {
        name: newPartName.trim(),
        category: newPartCategory
      });
      
      setCarParts([...carParts, response]);
      setNewPartName('');
      setNewPartCategory('Exterior');
      setActiveTab('view');
      toast.success('Car part added successfully');
      
      if (onPartAdded) {
        onPartAdded(response);
      }
    } catch (error: any) {
      console.error('Error adding car part:', error);
      toast.error(error.response?.data?.error || 'Failed to add car part');
    } finally {
      setIsLoading(false);
    }
  };

  const handleEditPart = (part: CarPart) => {
    setEditingPart(part);
    setEditName(part.name);
    setEditCategory(part.category);
  };

  const handleSaveEdit = async () => {
    if (!editingPart) return;
    
    if (!editName.trim()) {
      toast.error('Part name is required');
      return;
    }

    try {
      setIsLoading(true);
      const response = await api.put(`/api/car-parts/${editingPart._id}`, {
        name: editName.trim(),
        category: editCategory
      });
      
      setCarParts(carParts.map(p => p._id === editingPart._id ? response : p));
      setEditingPart(null);
      toast.success('Car part updated successfully');
      
      if (onPartUpdated) {
        onPartUpdated(response);
      }
    } catch (error: any) {
      console.error('Error updating car part:', error);
      toast.error(error.response?.data?.error || 'Failed to update car part');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeletePart = async () => {
    if (!deletingPart) return;

    try {
      setIsLoading(true);
      await api.delete(`/api/car-parts/${deletingPart._id}`);
      
      setCarParts(carParts.filter(p => p._id !== deletingPart._id));
      setDeletingPart(null);
      toast.success('Car part deleted successfully');
      
      if (onPartDeleted) {
        onPartDeleted(deletingPart._id);
      }
    } catch (error: any) {
      console.error('Error deleting car part:', error);
      toast.error(error.response?.data?.error || 'Failed to delete car part');
    } finally {
      setIsLoading(false);
    }
  };

  const groupPartsByCategory = () => {
    const grouped: { [key: string]: CarPart[] } = {};
    carParts.forEach(part => {
      if (!grouped[part.category]) {
        grouped[part.category] = [];
      }
      grouped[part.category].push(part);
    });
    return grouped;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg w-full max-w-4xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="bg-gray-100 px-6 py-4 border-b flex justify-between items-center">
          <h2 className="text-xl font-semibold text-gray-800">Manage Car Parts</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Tabs */}
        <div className="border-b">
          <div className="flex">
            <button
              onClick={() => setActiveTab('view')}
              className={`px-6 py-3 font-medium ${
                activeTab === 'view'
                  ? 'text-blue-600 border-b-2 border-blue-600'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              View Parts ({carParts.length})
            </button>
            <button
              onClick={() => setActiveTab('add')}
              className={`px-6 py-3 font-medium ${
                activeTab === 'add'
                  ? 'text-blue-600 border-b-2 border-blue-600'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              Add New Part
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto" style={{ maxHeight: 'calc(90vh - 200px)' }}>
          {isLoading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            </div>
          ) : error ? (
            <div className="text-red-600 text-center py-4">{error}</div>
          ) : (
            <>
              {/* View Tab */}
              {activeTab === 'view' && (
                <div className="space-y-6">
                  {Object.entries(groupPartsByCategory()).map(([category, parts]) => (
                    <div key={category}>
                      <h3 className="text-lg font-semibold text-gray-800 mb-3">{category}</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                        {parts.map(part => (
                          <div
                            key={part._id}
                            className="border rounded-lg p-3 hover:bg-gray-50 transition-colors"
                          >
                            {editingPart?._id === part._id ? (
                              <div className="space-y-2">
                                <input
                                  type="text"
                                  value={editName}
                                  onChange={(e) => setEditName(e.target.value)}
                                  className="w-full px-2 py-1 border rounded"
                                  placeholder="Part name"
                                />
                                <select
                                  value={editCategory}
                                  onChange={(e) => setEditCategory(e.target.value)}
                                  className="w-full px-2 py-1 border rounded"
                                >
                                  {CATEGORIES.map(cat => (
                                    <option key={cat} value={cat}>{cat}</option>
                                  ))}
                                </select>
                                <div className="flex gap-2">
                                  <button
                                    onClick={handleSaveEdit}
                                    disabled={isLoading}
                                    className="px-3 py-1 bg-green-600 text-white rounded hover:bg-green-700 text-sm"
                                  >
                                    Save
                                  </button>
                                  <button
                                    onClick={() => setEditingPart(null)}
                                    className="px-3 py-1 bg-gray-500 text-white rounded hover:bg-gray-600 text-sm"
                                  >
                                    Cancel
                                  </button>
                                </div>
                              </div>
                            ) : (
                              <div className="flex justify-between items-center">
                                <span className="font-medium">{part.name}</span>
                                <div className="flex gap-2">
                                  <button
                                    onClick={() => handleEditPart(part)}
                                    className="text-blue-600 hover:text-blue-800"
                                    title="Edit"
                                  >
                                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                                    </svg>
                                  </button>
                                  <button
                                    onClick={() => setDeletingPart(part)}
                                    className="text-red-600 hover:text-red-800"
                                    title="Delete"
                                  >
                                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                    </svg>
                                  </button>
                                </div>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                  
                  {carParts.length === 0 && (
                    <div className="text-center py-8 text-gray-500">
                      No car parts configured yet. Add your first part using the "Add New Part" tab.
                    </div>
                  )}
                </div>
              )}

              {/* Add Tab */}
              {activeTab === 'add' && (
                <div className="max-w-md mx-auto">
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Part Name
                      </label>
                      <input
                        type="text"
                        value={newPartName}
                        onChange={(e) => setNewPartName(e.target.value)}
                        className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="e.g., Front Bumper"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Category
                      </label>
                      <select
                        value={newPartCategory}
                        onChange={(e) => setNewPartCategory(e.target.value)}
                        className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        {CATEGORIES.map(category => (
                          <option key={category} value={category}>{category}</option>
                        ))}
                      </select>
                    </div>
                    
                    <div className="flex gap-3 pt-4">
                      <button
                        onClick={handleAddPart}
                        disabled={isLoading || !newPartName.trim()}
                        className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400"
                      >
                        Add Part
                      </button>
                      <button
                        onClick={() => {
                          setNewPartName('');
                          setNewPartCategory('Exterior');
                        }}
                        className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                      >
                        Clear
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Delete Confirmation Modal */}
        {deletingPart && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-60">
            <div className="bg-white rounded-lg p-6 max-w-sm w-full mx-4">
              <h3 className="text-lg font-semibold mb-4">Confirm Delete</h3>
              <p className="text-gray-600 mb-6">
                Are you sure you want to delete "{deletingPart.name}"? This action cannot be undone.
              </p>
              <div className="flex gap-3">
                <button
                  onClick={handleDeletePart}
                  disabled={isLoading}
                  className="flex-1 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                >
                  Delete
                </button>
                <button
                  onClick={() => setDeletingPart(null)}
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CarPartsModal;