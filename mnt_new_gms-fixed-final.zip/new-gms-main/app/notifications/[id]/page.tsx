"use client";

import React, { useState, useEffect } from "react";
import { useParams, useRouter } from "next/navigation";
import { useAuth } from '@/app/context/AuthContext';
import { useRouteProtection } from '@/services/route-protection';
import Link from "next/link";
import { 
  Bell, 
  ArrowLeft, 
  Calendar, 
  Clock, 
  AlertTriangle,
  RefreshCw,
  UserPlus,
  CheckCircle,
  Archive,
  ExternalLink,
  User,
  Tag
} from "lucide-react";
import { Notification } from "@/app/types/notification";
import { notificationsApi } from "@/services/api";


const typeIcons = {
  time_alert: <Clock className="w-6 h-6" />,
  deadline_warning: <AlertTriangle className="w-6 h-6" />,
  status_change: <RefreshCw className="w-6 h-6" />,
  assignment: <UserPlus className="w-6 h-6" />,
  general: <Bell className="w-6 h-6" />
};

const typeColors = {
  time_alert: "bg-blue-100 text-blue-600",
  deadline_warning: "bg-orange-100 text-orange-600",
  status_change: "bg-green-100 text-green-600",
  assignment: "bg-purple-100 text-purple-600",
  general: "bg-gray-100 text-gray-600"
};

const priorityColors = {
  low: "bg-gray-100 text-gray-600",
  medium: "bg-blue-100 text-blue-600",
  high: "bg-orange-100 text-orange-600",
  urgent: "bg-red-100 text-red-600"
};

export default function NotificationDetailPage() {
  const params = useParams();
  const router = useRouter();
  const { isAuthenticated, user } = useAuth();
  useRouteProtection(isAuthenticated, user);
  
  const [notification, setNotification] = useState<Notification | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchNotification = async () => {
      const id = params.id as string;
      
      setIsLoading(true);
      setError(null);

      // Load from database ONLY
      try {
        const data = await notificationsApi.getNotificationById(id);
        setNotification(data);
        
        // Mark as done if undone
        if (data && data.status === "undone") {
          await notificationsApi.markAsDone(id);
          setNotification({
            ...data,
            status: "done",
            readAt: new Date().toISOString()
          });
        }
      } catch (err) {
        console.error('Error fetching notification:', err);
        const error = err as { response?: { status?: number; data?: { message?: string } } };
        if (error.response?.status === 404) {
          setError("Notification not found in database");
        } else {
          setError(error.response?.data?.message || "Failed to load notification from database");
        }
      } finally {
        setIsLoading(false);
      }
    };

    fetchNotification();
  }, [params.id]);

  const handleMarkAsDone = async () => {
    if (!notification) return;
    
    try {
      await notificationsApi.markAsDone(notification._id);
      setNotification({
        ...notification,
        status: "done",
        readAt: new Date().toISOString()
      });
    } catch (err) {
      console.error('Error marking as done:', err);
    }
  };

  const handleArchive = async () => {
    if (!notification) return;
    
    try {
      await notificationsApi.archiveNotification(notification._id);
      setNotification({
        ...notification,
        status: "archived"
      });
      
      // Redirect back to notifications list after a short delay
      setTimeout(() => router.push('/notifications'), 1000);
    } catch (err) {
      console.error('Error archiving:', err);
    }
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getTypeLabel = (type: string) => {
    const labels: { [key: string]: string } = {
      time_alert: 'Time Alert',
      deadline_warning: 'Deadline Warning',
      status_change: 'Status Change',
      assignment: 'New Assignment',
      general: 'General'
    };
    return labels[type] || type;
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="flex items-center justify-center py-16">
          <RefreshCw className="w-8 h-8 text-blue-600 animate-spin" />
          <span className="ml-2 text-gray-600">Loading notification...</span>
        </div>
      </div>
    );
  }

  if (error || !notification) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="text-center py-16">
          <AlertTriangle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Notification Not Found</h2>
          <p className="text-gray-600 mb-6">{error || "The notification you're looking for doesn't exist."}</p>
          <Link href="/notifications" className="text-blue-600 hover:text-blue-800 font-medium">
            ← Back to Notifications
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      {/* Header */}
      <div className="mb-6">
        <Link 
          href="/notifications" 
          className="inline-flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-4"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Notifications
        </Link>
        
        <div className="flex items-start justify-between">
          <h1 className="text-2xl font-bold text-gray-900">Notification Details</h1>
          <div className="flex items-center gap-2">
            {notification.status === "undone" && (
              <button
                onClick={handleMarkAsDone}
                className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700"
              >
                Mark as Done
              </button>
            )}
            {notification.status !== "archived" && (
              <button
                onClick={handleArchive}
                className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                <Archive className="w-4 h-4" />
                Archive
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Main Content Card */}
      <div className="bg-white rounded-lg shadow-sm border">
        {/* Type and Priority Header */}
        <div className="p-6 border-b">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className={`p-3 rounded-full ${typeColors[notification.type as keyof typeof typeColors]}`}>
                {typeIcons[notification.type as keyof typeof typeIcons]}
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-900">{notification.title}</h2>
                <p className="text-sm text-gray-600 mt-1">{getTypeLabel(notification.type)}</p>
              </div>
            </div>
            <span className={`px-3 py-1 text-sm font-medium rounded-full ${priorityColors[notification.priority]}`}>
              {notification.priority.toUpperCase()}
            </span>
          </div>

          {/* Status and Time Info */}
          <div className="flex flex-wrap gap-6 text-sm text-gray-600">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              <span>Created: {formatDate(notification.createdAt)}</span>
            </div>
            {notification.readAt && (
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <span>Marked Done: {formatDate(notification.readAt)}</span>
              </div>
            )}
            {notification.recipientType && (
              <div className="flex items-center gap-2">
                <User className="w-4 h-4" />
                <span>Recipient: {notification.recipientType}</span>
              </div>
            )}
          </div>
        </div>

        {/* Message Content */}
        <div className="p-6">
          <h3 className="font-semibold text-gray-900 mb-3">Message</h3>
          <p className="text-gray-700 whitespace-pre-wrap">{notification.message}</p>

          {/* Progress Bar for Time Alerts */}
          {notification.type === "time_alert" && notification.percentComplete !== undefined && (
            <div className="mt-6">
              <h4 className="font-semibold text-gray-900 mb-2">Progress</h4>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div
                  className="bg-blue-600 h-3 rounded-full transition-all duration-300"
                  style={{ width: `${notification.percentComplete}%` }}
                />
              </div>
              <span className="text-sm text-gray-600 mt-1">
                {notification.percentComplete}% complete
              </span>
            </div>
          )}

          {/* Related Work Order */}
          {notification.workOrderId && (
            <div className="mt-6">
              <h4 className="font-semibold text-gray-900 mb-2">Related Work Order</h4>
              <Link
                href={`/workOrders/${notification.workOrderId}`}
                className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-blue-600 bg-blue-50 rounded-lg hover:bg-blue-100"
              >
                <ExternalLink className="w-4 h-4" />
                View Work Order #{notification.workOrderId}
              </Link>
            </div>
          )}

          {/* Related Employee */}
          {notification.employeeId && !notification.deductionId && !notification.timesheetId && (
            <div className="mt-6">
              <h4 className="font-semibold text-gray-900 mb-2">Related Employee</h4>
              <Link
                href="/payroll/employees"
                className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-green-600 bg-green-50 rounded-lg hover:bg-green-100"
              >
                <ExternalLink className="w-4 h-4" />
                View Employee Management
              </Link>
            </div>
          )}

          {/* Related Timesheet */}
          {notification.timesheetId && (
            <div className="mt-6">
              <h4 className="font-semibold text-gray-900 mb-2">Related Timesheet</h4>
              <Link
                href={`/payroll/attendance/${notification.timesheetId}`}
                className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-purple-600 bg-purple-50 rounded-lg hover:bg-purple-100"
              >
                <ExternalLink className="w-4 h-4" />
                View Timesheet #{notification.timesheetId}
              </Link>
            </div>
          )}

          {/* Related Deduction */}
          {notification.deductionId && notification.employeeId && (
            <div className="mt-6">
              <h4 className="font-semibold text-gray-900 mb-2">Related Deduction</h4>
              <Link
                href={`/payroll/employees/${notification.employeeId}/deductions`}
                className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-orange-600 bg-orange-50 rounded-lg hover:bg-orange-100"
              >
                <ExternalLink className="w-4 h-4" />
                View Employee Deductions
              </Link>
            </div>
          )}

          {/* Additional Metadata */}
          {notification.metadata && Object.keys(notification.metadata).length > 0 && (
            <div className="mt-6">
              <h4 className="font-semibold text-gray-900 mb-3">Additional Information</h4>
              <div className="bg-gray-50 rounded-lg p-4">
                <dl className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {Object.entries(notification.metadata).map(([key, value]) => (
                    <div key={key}>
                      <dt className="text-sm font-medium text-gray-600">
                        {key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}
                      </dt>
                      <dd className="text-sm text-gray-900 mt-1">
                        {typeof value === 'string' && value.includes('T') && value.includes('Z') 
                          ? formatDate(value)
                          : String(value)}
                      </dd>
                    </div>
                  ))}
                </dl>
              </div>
            </div>
          )}

          {/* Stage Information */}
          {notification.stageId && (
            <div className="mt-6">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Tag className="w-4 h-4" />
                <span>Stage ID: {notification.stageId}</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}