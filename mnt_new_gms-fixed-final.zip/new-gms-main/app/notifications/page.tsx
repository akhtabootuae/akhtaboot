"use client";

import React, { useState, useMemo, useEffect } from "react";
import { useAuth } from '../context/AuthContext';
import { useRouteProtection } from '@/services/route-protection';
import { Notification, NotificationType, NotificationPriority, NotificationStatus } from "@/app/types/notification";
import NotificationCard from "./components/NotificationCard";
import NotificationFilters from "./components/NotificationFilters";
import { Bell, BellOff, RefreshCw, AlertCircle } from "lucide-react";
import { notificationsApi } from "@/services/api";

interface FilterState {
  type: NotificationType | "all";
  priority: NotificationPriority | "all";
  status: NotificationStatus | "all";
}


export default function NotificationsPage() {
  const { isAuthenticated, user } = useAuth();
  useRouteProtection(isAuthenticated, user);
  
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  const [filters, setFilters] = useState<FilterState>({
    type: "all",
    priority: "all",
    status: "all"
  });

  // Fetch notifications from database on component mount and filter changes
  useEffect(() => {
    const fetchNotifications = async () => {
      setIsLoading(true);
      setError(null);
      
      try {
        const filterParams: {
          type?: string;
          priority?: string;
          status?: string;
        } = {};
        if (filters.type !== "all") filterParams.type = filters.type;
        if (filters.priority !== "all") filterParams.priority = filters.priority;
        if (filters.status !== "all") filterParams.status = filters.status;
        
        const response = await notificationsApi.getNotifications(filterParams);
        
        // Handle both array response and object with data property
        const notificationData = Array.isArray(response) ? response : (response.data || []);
        setNotifications(notificationData);
      } catch (err) {
        console.error('Error fetching notifications:', err);
        const error = err as { response?: { status?: number; data?: { message?: string } } };
        setError(error.response?.data?.message || "Failed to load notifications from database.");
        setNotifications([]);
      } finally {
        setIsLoading(false);
      }
    };

    fetchNotifications();
  }, [filters]);

  // Filter notifications
  const filteredNotifications = useMemo(() => {
    return notifications.filter(notification => {
      if (filters.type !== "all" && notification.type !== filters.type) return false;
      if (filters.priority !== "all" && notification.priority !== filters.priority) return false;
      if (filters.status !== "all" && notification.status !== filters.status) return false;
      return true;
    });
  }, [notifications, filters]);

  // Calculate counts
  const notificationCounts = useMemo(() => {
    return {
      total: notifications.length,
      undone: notifications.filter(n => n.status === "undone").length
    };
  }, [notifications]);

  const handleMarkAsDone = async (id: string) => {
    setNotifications(prev => 
      prev.map(n => 
        n._id === id 
          ? { ...n, status: "done" as NotificationStatus, readAt: new Date().toISOString() }
          : n
      )
    );
    
    // Try API call but don't block UI
    try {
      await notificationsApi.markAsDone(id);
    } catch (err) {
      console.error('Error marking notification as done:', err);
    }
  };

  const handleMarkAllAsDone = () => {
    setNotifications(prev => 
      prev.map(n => 
        n.status === "undone"
          ? { ...n, status: "done" as NotificationStatus, readAt: new Date().toISOString() }
          : n
      )
    );
  };

  const handleRefresh = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const filterParams: {
        type?: string;
        priority?: string;
        status?: string;
      } = {};
      if (filters.type !== "all") filterParams.type = filters.type;
      if (filters.priority !== "all") filterParams.priority = filters.priority;
      if (filters.status !== "all") filterParams.status = filters.status;
      
      const response = await notificationsApi.getNotifications(filterParams);
      const notificationData = Array.isArray(response) ? response : (response.data || []);
      
      if (notificationData.length > 0) {
        setNotifications(notificationData);
      }
    } catch (err) {
      console.error('Error fetching notifications:', err);
      setError("Unable to refresh notifications");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <Bell className="w-8 h-8 text-blue-600" />
            Notifications
          </h1>
          <div className="flex items-center gap-2">
            {notificationCounts.undone > 0 && (
              <button
                onClick={handleMarkAllAsDone}
                className="px-4 py-2 text-sm font-medium text-blue-600 bg-blue-50 rounded-lg hover:bg-blue-100"
              >
                Mark all as done
              </button>
            )}
            <button
              onClick={handleRefresh}
              disabled={isLoading}
              className="p-2 text-gray-600 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50"
            >
              <RefreshCw className={`w-5 h-5 ${isLoading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>
        <p className="text-gray-600">
          Stay updated with work orders, assignments, and system alerts
        </p>
      </div>

      {/* Error Message */}
      {error && (
        <div className="mb-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-yellow-800 text-sm">{error}</p>
          </div>
        </div>
      )}

      {/* Filters */}
      <NotificationFilters
        filters={filters}
        onFilterChange={setFilters}
        notificationCounts={notificationCounts}
      />

      {/* Notifications List */}
      <div className="space-y-2">
        {filteredNotifications.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <BellOff className="w-16 h-16 text-gray-300 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              No notifications found
            </h3>
            <p className="text-gray-600">
              {filters.type !== "all" || filters.priority !== "all" || filters.status !== "all"
                ? "Try adjusting your filters to see more notifications"
                : "You're all caught up! Check back later for new updates."}
            </p>
          </div>
        ) : (
          filteredNotifications.map(notification => (
            <NotificationCard
              key={notification._id}
              notification={notification}
              onMarkAsDone={handleMarkAsDone}
            />
          ))
        )}
      </div>
    </div>
  );
}