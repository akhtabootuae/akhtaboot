"use client";

import React from "react";
import { Notification, NotificationType, NotificationPriority } from "@/app/types/notification";
import { 
  Clock, 
  AlertTriangle, 
  RefreshCw, 
  UserPlus, 
  Bell,
  Circle,
  ChevronRight,
  Calendar,
  ExternalLink
} from "lucide-react";

interface NotificationCardProps {
  notification: Notification;
  onMarkAsDone?: (id: string) => void;
}

const typeIcons: Record<NotificationType, React.ReactNode> = {
  time_alert: <Clock className="w-5 h-5" />,
  deadline_warning: <AlertTriangle className="w-5 h-5" />,
  status_change: <RefreshCw className="w-5 h-5" />,
  assignment: <UserPlus className="w-5 h-5" />,
  general: <Bell className="w-5 h-5" />
};

const typeColors: Record<NotificationType, string> = {
  time_alert: "bg-blue-100 text-blue-600",
  deadline_warning: "bg-orange-100 text-orange-600",
  status_change: "bg-green-100 text-green-600",
  assignment: "bg-purple-100 text-purple-600",
  general: "bg-gray-100 text-gray-600"
};

const priorityColors: Record<NotificationPriority, string> = {
  low: "border-gray-200",
  medium: "border-blue-200",
  high: "border-orange-300",
  urgent: "border-red-400 animate-pulse"
};

const priorityBadgeColors: Record<NotificationPriority, string> = {
  low: "bg-gray-100 text-gray-600",
  medium: "bg-blue-100 text-blue-600",
  high: "bg-orange-100 text-orange-600",
  urgent: "bg-red-100 text-red-600"
};

function formatTimeAgo(date: string): string {
  const now = new Date();
  const notificationDate = new Date(date);
  const diffInMinutes = Math.floor((now.getTime() - notificationDate.getTime()) / (1000 * 60));

  if (diffInMinutes < 1) return "Just now";
  if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
  
  const diffInHours = Math.floor(diffInMinutes / 60);
  if (diffInHours < 24) return `${diffInHours}h ago`;
  
  const diffInDays = Math.floor(diffInHours / 24);
  if (diffInDays < 7) return `${diffInDays}d ago`;
  
  return notificationDate.toLocaleDateString();
}

export default function NotificationCard({ 
  notification, 
  onMarkAsDone 
}: NotificationCardProps) {
  const isUndone = notification.status === "undone";
  
  
  const handleClick = (e: React.MouseEvent) => {
    // Navigate to notification detail page
    window.location.href = `/notifications/${notification._id}`;
    
    if (isUndone && onMarkAsDone) {
      onMarkAsDone(notification._id);
    }
  };

  const handleWorkOrderClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    window.location.href = `/workOrders/${notification.workOrderId}`;
  };

  const handleEmployeeClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    window.location.href = `/payroll/employees`;
  };

  const handleTimesheetClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    window.location.href = `/payroll/attendance/${notification.timesheetId}`;
  };

  const handleDeductionClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    window.location.href = `/payroll/employees/${notification.employeeId}/deductions`;
  };

  return (
    <div
      onClick={handleClick}
      className={`
        relative p-4 mb-3 bg-white rounded-lg border-2 cursor-pointer
        transition-all duration-200 hover:shadow-md hover:scale-[1.01]
        ${priorityColors[notification.priority]}
        ${isUndone ? 'bg-blue-50/30' : ''}
      `}
    >
      <div className="flex items-start gap-3">
        {/* Type Icon */}
        <div className={`p-2 rounded-full ${typeColors[notification.type]}`}>
          {typeIcons[notification.type]}
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div className="flex-1">
              <h3 className={`font-semibold text-gray-900 ${isUndone ? 'font-bold' : ''}`}>
                {notification.title}
              </h3>
              <p className="mt-1 text-sm text-gray-600 line-clamp-2">
                {notification.message}
              </p>
              
              {/* Metadata */}
              <div className="flex items-center gap-4 mt-2 text-xs text-gray-500">
                <span className="flex items-center gap-1">
                  <Calendar className="w-3 h-3" />
                  {formatTimeAgo(notification.createdAt)}
                </span>
                
                {notification.workOrderId && (
                  <button
                    onClick={handleWorkOrderClick}
                    className="flex items-center gap-1 text-blue-600 hover:text-blue-800"
                  >
                    <ExternalLink className="w-3 h-3" />
                    View Work Order
                  </button>
                )}
                
                {notification.employeeId && !notification.deductionId && !notification.timesheetId && (
                  <button
                    onClick={handleEmployeeClick}
                    className="flex items-center gap-1 text-green-600 hover:text-green-800"
                  >
                    <ExternalLink className="w-3 h-3" />
                    View Employee
                  </button>
                )}
                
                {notification.timesheetId && (
                  <button
                    onClick={handleTimesheetClick}
                    className="flex items-center gap-1 text-purple-600 hover:text-purple-800"
                  >
                    <ExternalLink className="w-3 h-3" />
                    View Timesheet
                  </button>
                )}
                
                {notification.deductionId && notification.employeeId && (
                  <button
                    onClick={handleDeductionClick}
                    className="flex items-center gap-1 text-orange-600 hover:text-orange-800"
                  >
                    <ExternalLink className="w-3 h-3" />
                    View Deductions
                  </button>
                )}
              </div>

              {/* Progress bar for time alerts */}
              {notification.type === "time_alert" && notification.percentComplete !== undefined && (
                <div className="mt-2">
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${notification.percentComplete}%` }}
                    />
                  </div>
                  <span className="text-xs text-gray-500 mt-1">
                    {notification.percentComplete}% complete
                  </span>
                </div>
              )}
            </div>

            {/* Right side indicators */}
            <div className="flex flex-col items-end gap-2">
              {/* Priority badge */}
              <span className={`
                px-2 py-1 text-xs font-medium rounded-full
                ${priorityBadgeColors[notification.priority]}
              `}>
                {notification.priority.toUpperCase()}
              </span>

              {/* Undone indicator */}
              {isUndone && (
                <Circle className="w-2 h-2 fill-blue-600 text-blue-600" />
              )}
            </div>
          </div>
        </div>

        {/* Chevron */}
        <ChevronRight className="w-5 h-5 text-gray-400 flex-shrink-0" />
      </div>
    </div>
  );
}