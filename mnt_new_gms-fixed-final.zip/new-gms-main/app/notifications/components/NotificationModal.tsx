"use client";

import React from "react";
import { Notification } from "@/app/types/notification";
import { X, Clock, Calendar, ExternalLink, Archive, CheckCircle } from "lucide-react";
import Link from "next/link";

interface NotificationModalProps {
  notification: Notification | null;
  isOpen: boolean;
  onClose: () => void;
  onMarkAsRead: (id: string) => void;
  onArchive: (id: string) => void;
}

export default function NotificationModal({
  notification,
  isOpen,
  onClose,
  onMarkAsRead,
  onArchive
}: NotificationModalProps) {
  if (!isOpen || !notification) return null;

  const formatDate = (date: string) => {
    return new Date(date).toLocaleString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'text-red-600 bg-red-100';
      case 'high': return 'text-orange-600 bg-orange-100';
      case 'medium': return 'text-blue-600 bg-blue-100';
      case 'low': return 'text-gray-600 bg-gray-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'time_alert': return 'Time Alert';
      case 'deadline_warning': return 'Deadline Warning';
      case 'status_change': return 'Status Change';
      case 'assignment': return 'New Assignment';
      case 'general': return 'General';
      default: return type;
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
        {/* Background overlay */}
        <div 
          className="fixed inset-0 transition-opacity bg-gray-500 bg-opacity-75"
          onClick={onClose}
        />

        {/* Modal panel */}
        <div className="inline-block w-full max-w-2xl my-8 overflow-hidden text-left align-middle transition-all transform bg-white shadow-xl rounded-xl">
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b">
            <h3 className="text-lg font-semibold text-gray-900">
              Notification Details
            </h3>
            <button
              onClick={onClose}
              className="p-1 rounded-full hover:bg-gray-100"
            >
              <X className="w-5 h-5 text-gray-500" />
            </button>
          </div>

          {/* Content */}
          <div className="px-6 py-4">
            {/* Title and Priority */}
            <div className="flex items-start justify-between mb-4">
              <h2 className="text-xl font-bold text-gray-900 flex-1">
                {notification.title}
              </h2>
              <span className={`px-3 py-1 text-sm font-medium rounded-full ${getPriorityColor(notification.priority)}`}>
                {notification.priority.toUpperCase()}
              </span>
            </div>

            {/* Type and Date */}
            <div className="flex flex-wrap gap-4 mb-6 text-sm text-gray-600">
              <div className="flex items-center gap-2">
                <span className="font-medium">Type:</span>
                <span className="px-2 py-1 bg-gray-100 rounded">
                  {getTypeLabel(notification.type)}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                <span>{formatDate(notification.createdAt)}</span>
              </div>
              {notification.readAt && (
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  <span>Read at {formatDate(notification.readAt)}</span>
                </div>
              )}
            </div>

            {/* Message */}
            <div className="mb-6">
              <h4 className="font-medium text-gray-900 mb-2">Message</h4>
              <p className="text-gray-700 whitespace-pre-wrap">
                {notification.message}
              </p>
            </div>

            {/* Progress for time alerts */}
            {notification.type === "time_alert" && notification.percentComplete !== undefined && (
              <div className="mb-6">
                <h4 className="font-medium text-gray-900 mb-2">Progress</h4>
                <div className="w-full bg-gray-200 rounded-full h-3">
                  <div
                    className="bg-blue-600 h-3 rounded-full transition-all duration-300"
                    style={{ width: `${notification.percentComplete}%` }}
                  />
                </div>
                <span className="text-sm text-gray-600 mt-1">
                  {notification.percentComplete}% complete
                </span>
              </div>
            )}

            {/* Work Order Link */}
            {notification.workOrderId && (
              <div className="mb-6">
                <Link
                  href={`/workOrders/${notification.workOrderId}`}
                  className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-blue-600 bg-blue-50 rounded-lg hover:bg-blue-100"
                >
                  <ExternalLink className="w-4 h-4" />
                  View Related Work Order
                </Link>
              </div>
            )}

            {/* Metadata */}
            {notification.metadata && Object.keys(notification.metadata).length > 0 && (
              <div className="mb-6">
                <h4 className="font-medium text-gray-900 mb-2">Additional Information</h4>
                <div className="p-3 bg-gray-50 rounded-lg">
                  <pre className="text-sm text-gray-700 whitespace-pre-wrap">
                    {JSON.stringify(notification.metadata, null, 2)}
                  </pre>
                </div>
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 px-6 py-4 bg-gray-50 border-t">
            {notification.status === "unread" && (
              <button
                onClick={() => {
                  onMarkAsRead(notification._id);
                  onClose();
                }}
                className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700"
              >
                Mark as Read
              </button>
            )}
            {notification.status !== "archived" && (
              <button
                onClick={() => {
                  onArchive(notification._id);
                  onClose();
                }}
                className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                <Archive className="w-4 h-4" />
                Archive
              </button>
            )}
            <button
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}