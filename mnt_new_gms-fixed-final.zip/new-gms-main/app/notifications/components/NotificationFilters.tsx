"use client";

import React from "react";
import { NotificationType, NotificationPriority, NotificationStatus } from "@/app/types/notification";
import { Filter, X } from "lucide-react";

interface FilterState {
  type: NotificationType | "all";
  priority: NotificationPriority | "all";
  status: NotificationStatus | "all";
}

interface NotificationFiltersProps {
  filters: FilterState;
  onFilterChange: (filters: FilterState) => void;
  notificationCounts: {
    undone: number;
    total: number;
  };
}

export default function NotificationFilters({ 
  filters, 
  onFilterChange,
  notificationCounts 
}: NotificationFiltersProps) {
  const handleFilterChange = (key: keyof FilterState, value: string) => {
    onFilterChange({
      ...filters,
      [key]: value
    });
  };

  const clearFilters = () => {
    onFilterChange({
      type: "all",
      priority: "all",
      status: "all"
    });
  };

  const hasActiveFilters = filters.type !== "all" || filters.priority !== "all" || filters.status !== "all";

  return (
    <div className="bg-white rounded-lg shadow-sm border p-4 mb-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Filter className="w-5 h-5 text-gray-600" />
          <h3 className="font-semibold text-gray-900">Filters</h3>
          <span className="text-sm text-gray-500">
            ({notificationCounts.undone} undone / {notificationCounts.total} total)
          </span>
        </div>
        
        {hasActiveFilters && (
          <button
            onClick={clearFilters}
            className="flex items-center gap-1 text-sm text-gray-600 hover:text-gray-900"
          >
            <X className="w-4 h-4" />
            Clear filters
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Type Filter */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Type
          </label>
          <select
            value={filters.type}
            onChange={(e) => handleFilterChange("type", e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="all">All Types</option>
            <option value="time_alert">Time Alerts</option>
            <option value="deadline_warning">Deadline Warnings</option>
            <option value="status_change">Status Changes</option>
            <option value="assignment">Assignments</option>
            <option value="general">General</option>
          </select>
        </div>

        {/* Priority Filter */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Priority
          </label>
          <select
            value={filters.priority}
            onChange={(e) => handleFilterChange("priority", e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="all">All Priorities</option>
            <option value="urgent">Urgent</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
        </div>

        {/* Status Filter */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Status
          </label>
          <select
            value={filters.status}
            onChange={(e) => handleFilterChange("status", e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="all">All Status</option>
            <option value="undone">Undone</option>
            <option value="done">Done</option>
            <option value="archived">Archived</option>
          </select>
        </div>
      </div>
    </div>
  );
}