'use client';

import React, { useState, useEffect, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/app/context/AuthContext';
import { useRouteProtection } from '@/services/route-protection';
import { dataApi } from '@/services/api';
import useDebounce from '@/app/hooks/useDebounce';
import { Search, Eye, Users, Shield, Plus, Download } from 'lucide-react';
import Link from 'next/link';

// Define staff/user type based on API response
type Staff = {
  _id: string;
  name?: string;
  first_name?: string;
  last_name?: string;
  email: string;
  role: string;
  role_id: string;
  role_description?: string;
  branch?: {
    branch_id: string;
    branch_name: string;
    branch_code: string;
    location?: string;
  };
  created_at?: string;
  status?: string;
};

const PAGE_SIZE = 8;

export default function StaffPage() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const router = useRouter();
  
  // Admin and accountant only - prevent supervisor access
  const hasAccess = useRouteProtection(isAuthenticated, user, { adminAndAccountantOnly: true });
  
  // State management
  const [staff, setStaff] = useState<Staff[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  
  // Debounced search term
  const debouncedSearchTerm = useDebounce(searchTerm, 300);
  
  // Fetch staff data
  const fetchStaff = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await dataApi.getUsers();
      setStaff(Array.isArray(response) ? response : []);
    } catch (err: any) {
      setError(err.response?.data?.message || err.message || 'Failed to fetch staff data');
    } finally {
      setLoading(false);
    }
  };

  // Initial data fetch
  useEffect(() => {
    if (hasAccess && isAuthenticated && !authLoading) {
      fetchStaff();
    }
  }, [hasAccess, isAuthenticated, authLoading]);

  // Reset to first page when search changes
  useEffect(() => {
    setCurrentPage(1);
  }, [debouncedSearchTerm]);

  // Filter and sort staff based on search term and role priority
  const filteredStaff = useMemo(() => {
    // Define role priority order
    const getRolePriority = (role: string) => {
      const roleLower = role.toLowerCase();
      if (roleLower === 'admin') return 1;
      if (roleLower === 'supervisor') return 2;
      if (roleLower === 'accountant') return 3 
      if (roleLower === 'technician') return 4;
      return 5; // All other roles
    };

    let filteredData = staff;
    
    // Apply search filter if search term exists
    if (debouncedSearchTerm) {
      const searchLower = debouncedSearchTerm.toLowerCase();
      filteredData = staff.filter((member) => {
        const name = member.name || `${member.first_name || ''} ${member.last_name || ''}`.trim();
        const email = member.email || '';
        const role = member.role || '';
        const branch = member.branch?.branch_name || '';
        
        return (
          name.toLowerCase().includes(searchLower) ||
          email.toLowerCase().includes(searchLower) ||
          role.toLowerCase().includes(searchLower) ||
          branch.toLowerCase().includes(searchLower)
        );
      });
    }
    
    // Sort by role priority, then by name
    return filteredData.sort((a, b) => {
      const priorityA = getRolePriority(a.role || '');
      const priorityB = getRolePriority(b.role || '');
      
      if (priorityA !== priorityB) {
        return priorityA - priorityB;
      }
      
      // If same priority, sort by name
      const nameA = a.name || `${a.first_name || ''} ${a.last_name || ''}`.trim();
      const nameB = b.name || `${b.first_name || ''} ${b.last_name || ''}`.trim();
      return nameA.localeCompare(nameB);
    });
  }, [staff, debouncedSearchTerm]);

  // Pagination calculations
  const totalPages = Math.max(1, Math.ceil(filteredStaff.length / PAGE_SIZE));
  const startIdx = (currentPage - 1) * PAGE_SIZE;
  const visibleStaff = filteredStaff.slice(startIdx, startIdx + PAGE_SIZE);

  // Handle search
  const handleSearch = () => {
    // Search is already handled by the debounced search term
    // This function could be used for additional search actions if needed
  };

  // Handle view details
  const handleViewDetails = (staffId: string) => {
    router.push(`/staff/${staffId}`);
  };

  // Handle export users
  const handleExportUsers = async () => {
    try {
      const response = await dataApi.exportUsers();
      
      // The response should be the CSV string directly
      // Handle different possible response formats
      let csvData;
      if (typeof response === 'string') {
        csvData = response;
      } else if (response && typeof response === 'object' && response.data) {
        csvData = response.data;
      } else {
        csvData = String(response);
      }
      
      // Create blob and download
      const blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `users_export_${Date.now()}.csv`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);  
      window.URL.revokeObjectURL(url);
    } catch (error) {
      setError('Failed to export users data');
    }
  };

  // Show loading state during auth check
  if (authLoading || !hasAccess) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Page Header */}
      <div className="flex items-center gap-3 mb-6">
        <div className="bg-blue-100 p-3 rounded-lg">
          <Users className="h-6 w-6 text-blue-600" />
        </div>
        <div className="flex-1">
          <h1 className="text-2xl font-bold text-gray-900">Staff Management</h1>
          <p className="text-gray-600">Manage and view staff members</p>
        </div>
        
        {/* Register User Button */}
        <Link
          href="/register"
          className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-all font-medium"
        >
          <Plus className="h-4 w-4" />
          Register New User
        </Link>

        {/* Export Users Button */}
        <button
          onClick={handleExportUsers}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all font-medium"
        >
          <Download className="h-4 w-4" />
          Export CSV
        </button>
        
        <div className="flex items-center gap-2 bg-blue-50 px-3 py-1 rounded-full">
          <Shield className="h-4 w-4 text-blue-600" />
          <span className="text-sm font-medium text-blue-600">Admin & Accountant</span>
        </div>
      </div>

      {/* Search Card */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex items-center gap-3 mb-4">
          <Search className="h-5 w-5 text-gray-500" />
          <h2 className="text-lg font-semibold text-gray-900">Search Staff</h2>
        </div>
        
        <div className="flex gap-3">
          <div className="flex-1">
            <input
              type="text"
              placeholder="Search by name, email, role, or branch..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
            />
          </div>
          <button
            onClick={handleSearch}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all flex items-center gap-2"
          >
            <Search className="h-4 w-4" />
            Search
          </button>
        </div>
        
        {debouncedSearchTerm && (
          <div className="mt-3 text-sm text-gray-600">
            {filteredStaff.length === 0 
              ? `No results found for "${debouncedSearchTerm}"`
              : `Found ${filteredStaff.length} result${filteredStaff.length !== 1 ? 's' : ''} for "${debouncedSearchTerm}"`
            }
          </div>
        )}
      </div>

      {/* Staff Table Card */}
      <div className="bg-white rounded-lg shadow-md">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-900">Staff Members</h2>
            <span className="text-sm text-gray-500">
              {filteredStaff.length} member{filteredStaff.length !== 1 ? 's' : ''}
            </span>
          </div>
        </div>

        <div className="overflow-x-auto">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
              <span className="ml-3 text-gray-600">Loading staff...</span>
            </div>
          ) : error ? (
            <div className="flex items-center justify-center py-12">
              <div className="text-center">
                <div className="text-red-500 mb-2">⚠️</div>
                <p className="text-red-600 font-medium">Error loading staff</p>
                <p className="text-gray-500 text-sm mt-1">{error}</p>
                <button
                  onClick={fetchStaff}
                  className="mt-3 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all"
                >
                  Try Again
                </button>
              </div>
            </div>
          ) : filteredStaff.length === 0 ? (
            <div className="flex items-center justify-center py-12">
              <div className="text-center">
                <Users className="h-12 w-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500 font-medium">
                  {debouncedSearchTerm ? 'No staff found matching your search' : 'No staff members found'}
                </p>
                <p className="text-gray-400 text-sm mt-1">
                  {debouncedSearchTerm ? 'Try adjusting your search terms' : 'Staff members will appear here when added'}
                </p>
              </div>
            </div>
          ) : (
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Staff Name
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Email
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Role
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Branch
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {visibleStaff.map((member) => {
                  const displayName = member.name || `${member.first_name || ''} ${member.last_name || ''}`.trim() || 'N/A';
                  
                  return (
                    <tr key={member._id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="h-10 w-10 bg-blue-100 rounded-full flex items-center justify-center">
                            <span className="text-blue-600 font-medium text-sm">
                              {displayName.charAt(0).toUpperCase()}
                            </span>
                          </div>
                          <div className="ml-3">
                            <div className="text-sm font-medium text-gray-900">
                              {displayName}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{member.email}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                          {member.role || 'N/A'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">
                          {member.branch?.branch_name || 'N/A'}
                        </div>
                        {member.branch?.branch_code && (
                          <div className="text-xs text-gray-500">
                            Code: {member.branch.branch_code}
                          </div>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <button
                          onClick={() => handleViewDetails(member._id)}
                          className="inline-flex items-center gap-1 text-blue-600 hover:text-blue-900 transition-colors"
                        >
                          <Eye className="h-4 w-4" />
                          View Details
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>

        {/* Pagination footer */}
        {filteredStaff.length > 0 && (
          <div className="px-6 py-3 bg-gray-50 border-t border-gray-200 flex items-center justify-between">
            <div className="text-sm text-gray-500">
              Showing {startIdx + 1}–{Math.min(startIdx + PAGE_SIZE, filteredStaff.length)} of {filteredStaff.length}
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="px-3 py-1 bg-white border border-gray-200 rounded text-gray-600 text-sm hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Previous
              </button>
              <span className="text-sm text-gray-600">
                Page {currentPage} of {totalPages}
              </span>
              <button
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="px-3 py-1 bg-white border border-gray-200 rounded text-gray-600 text-sm hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Next
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}