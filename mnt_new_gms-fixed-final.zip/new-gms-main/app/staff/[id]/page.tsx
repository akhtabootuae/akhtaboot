'use client';

import React, { useEffect, useState } from 'react';
import { useAuth } from '@/app/context/AuthContext';
import { useRouter } from 'next/navigation';
import { useRouteProtection } from '@/services/route-protection';
import api from '@/services/api';
import Link from 'next/link';
import { ArrowLeft, Edit, UserCheck, Mail, Phone, MapPin, Calendar, Activity, ChevronDown, ChevronRight } from 'lucide-react';
import StaffEditModal from '@/app/components/Staff/Modals/StaffEditModal';
import PasswordResetModal from '@/app/components/Staff/Modals/PasswordResetModal';

// Define staff member type based on MongoDB schema validation
interface Staff {
  _id: string;
  first_name: string;
  last_name: string;
  email: string;
  phone?: string;
  password_hash: string;
  is_active?: boolean;
  staff_code?: string;
  speciality?: string;
  branch?: {
    branch_id: string;
    branch_name: string;
    branch_code?: string;
    location?: string;
  };
  role_id: string;
  role: string;
  role_description?: string;
  permissions?: {
    permission_id: number;
    permission_name: string;
    description?: string;
    category?: string;
    granted: boolean;
  }[];
  permission_logs?: {
    log_id: number;
    target_type: 'user' | 'role';
    target_id: string;
    permission_id: number;
    action: 'grant' | 'revoke';
    created_at: string;
    details?: string;
  }[];
  created_at: string;
  updated_at: string;
  status?: string; // UI-friendly status derived from is_active
}

// Work summary interface (for future API integration)
interface WorkSummary {
  tasksCompleted: number;
  totalTime: string;
  totalWorkOrders?: number;
  inProgressTasks?: number;
}

// Work order response interface
interface WorkOrdersResponse {
  workorders: any[];
  pagination: {
    current_page: number;
    total_pages: number;
    total_count: number;
    per_page: number;
    has_next_page: boolean;
    has_prev_page: boolean;
    next_page: number | null;
    prev_page: number | null;
  };
  user: {
    id: string;
    name: string;
    email: string;
  };
}

export default function StaffDetailPage({ params }: { params: { id: string } }) {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const router = useRouter();
  
  // Admin and accountant only - prevent supervisor access
  const hasAccess = useRouteProtection(isAuthenticated, user, { adminAndAccountantOnly: true });
  
  // Convert params.id to string and store it in state for consistent access
  const [staffId] = useState(() => params.id.toString());
  const [staffMember, setStaffMember] = useState<Staff | null>(null);
  const [workSummary, setWorkSummary] = useState<WorkSummary>({
    tasksCompleted: 0,
    totalTime: '0h 0m',
    totalWorkOrders: 0,
    inProgressTasks: 0,
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [workOrdersLoading, setWorkOrdersLoading] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [activationLoading, setActivationLoading] = useState(false);
  const [collapsedCategories, setCollapsedCategories] = useState<Record<string, boolean>>({});
  const [permissionsCardCollapsed, setPermissionsCardCollapsed] = useState(false);
  const [showPasswordResetModal, setShowPasswordResetModal] = useState(false);
  
  // Check if user can edit staff (Admin or Accountant or has update_user permission)
  const canEditStaff = () => {
    if (!user) return false;
    if (user.role_name === 'Admin' || user.role_name === 'Accountant') return true;
    return user.permissions?.some(perm => 
      perm.permission_name === 'update_user' && perm.granted
    );
  };
  
  // Toggle category collapse state
  const toggleCategoryCollapse = (categoryKey: string) => {
    setCollapsedCategories(prev => ({
      ...prev,
      [categoryKey]: !prev[categoryKey]
    }));
  };
  
  // Toggle permissions card collapse state
  const togglePermissionsCard = () => {
    setPermissionsCardCollapsed(prev => !prev);
  };
  
  // Initialize all categories as collapsed
  const initializeCollapsedState = (categories: string[]) => {
    const initialState: Record<string, boolean> = {};
    categories.forEach(category => {
      initialState[category] = true; // true means collapsed
    });
    setCollapsedCategories(initialState);
  };
  
  // Fetch staff member data
  const fetchStaffMember = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Call the API to get staff member by ID using the staffId from state
      const userResponse = await api.get(`/api/users/${staffId}`);
      
      // Load all available permissions to get categories
      const allPermsResponse = await api.get('/api/users/permissions/all');
      
      // Call the API to get permissions for the staff member
      const permissionsResponse = await api.get(`/api/users/${staffId}/granted-permissions`);
      
      // Process the data and map is_active boolean to a user-friendly status string
      const staffData = userResponse.data || userResponse;
      const permissionsData = permissionsResponse.data || permissionsResponse;
      const allPermissions = (allPermsResponse as any).permissions_by_category || {};
      
      // Create a map of permission names to their categories
      const permissionCategoryMap: Record<string, string> = {};
      Object.entries(allPermissions).forEach(([categoryKey, categoryPerms]: [string, any]) => {
        categoryPerms.forEach((perm: any) => {
          permissionCategoryMap[perm.name] = categoryKey;
        });
      });
      
      // Map the permissions from the correct endpoint to the expected format with proper categories
      const formattedPermissions = permissionsData.granted_permissions?.map((perm: any) => ({
        permission_id: perm.permission_id,
        permission_name: perm.permission_name,
        description: perm.description,
        category: permissionCategoryMap[perm.permission_name] || 'OTHER', // Use actual category from all permissions
        granted: true // All permissions from this endpoint are granted
      })) || [];
      
      // Map is_active (true/false) to a user-friendly status string
      const formattedStaffData = {
        ...staffData,
        permissions: formattedPermissions,
        status: staffData.is_active === true ? 'Active' : 'Inactive'
      } as Staff;
      
      // Set the staff member data with the correct status and permissions
      setStaffMember(formattedStaffData);
      
      // Initialize collapsed state for permission categories
      const grantedPermissions = formattedPermissions.filter((perm: any) => perm.granted);
      const categories = [...new Set(grantedPermissions.map((perm: any) => perm.category))] as string[];
      initializeCollapsedState(categories);
      
      // Check access after we have staff data - if non-admin trying to access admin profile, redirect
      if (formattedStaffData.role === 'Admin' && user?.role_name !== 'Admin') {
        setError('Access denied. Only administrators can view administrator profiles.');
        return;
      }
      
      // Only fetch work orders for non-admin staff members
      if (formattedStaffData.role !== 'Admin') {
        await fetchWorkSummary(formattedStaffData);
      }
      
    } catch (err: any) {
      setError(err.response?.data?.message || err.message || 'Failed to fetch staff member data');
    } finally {
      setLoading(false);
    }
  };

  // Fetch work orders and calculate summary based on role (supervisor: part-level, technician: stage-level)
  const fetchWorkSummary = async (staffData?: Staff) => {
    try {
      setWorkOrdersLoading(true);
      
      // Use passed staffData or fallback to state
      const currentStaff = staffData || staffMember;
      
      // Fetch work orders for this staff member using the staffId from state
      const workOrdersData = await api.get(`/api/users/${staffId}/workorders`) as WorkOrdersResponse;
      
      if (workOrdersData && workOrdersData.workorders) {
        const workOrders = workOrdersData.workorders;
        
        let completedTasks = 0;
        let inProgressTasks = 0;
        const workOrdersWithAssignments = new Set();
        
        // Determine if this is a supervisor (part-level) or technician (stage-level)
        const isSupervisor = currentStaff?.role?.toLowerCase().includes('supervisor');
        
        workOrders.forEach((workOrder: any) => {
          let hasAssignmentInThisWorkOrder = false;
          
          if (workOrder.parts && Array.isArray(workOrder.parts)) {
            if (isSupervisor) {
              // Supervisor logic: check if any part is assigned to this supervisor
              const supervisorParts = workOrder.parts.filter((part: any) => part.assignedTo === staffId);
              if (supervisorParts.length > 0) {
                hasAssignmentInThisWorkOrder = true;
                // Count supervisor's parts by status
                supervisorParts.forEach((part: any) => {
                  if (part.status === 'completed') {
                    completedTasks++;
                  } else if (part.status === 'in_progress') {
                    inProgressTasks++;
                  }
                });
              }
            } else {
              // Technician logic: check stage-level assignments across all parts
              workOrder.parts.forEach((part: any) => {
                if (part.stages && Array.isArray(part.stages)) {
                  part.stages.forEach((stage: any) => {
                    if (stage.assignedTo === staffId) {
                      hasAssignmentInThisWorkOrder = true;
                      if (stage.status === 'completed') {
                        completedTasks++;
                      } else if (stage.status === 'in_progress') {
                        inProgressTasks++;
                      }
                    }
                  });
                }
              });
            }
          }
          
          if (hasAssignmentInThisWorkOrder) {
            workOrdersWithAssignments.add(workOrder._id || workOrder.id);
          }
        });
        
        setWorkSummary({
          tasksCompleted: completedTasks,
          totalTime: '0h 0m',
          totalWorkOrders: workOrdersWithAssignments.size,
          inProgressTasks: inProgressTasks,
        });
      } else {
        setWorkSummary({
          tasksCompleted: 0,
          totalTime: '0h 0m',
          totalWorkOrders: 0,
          inProgressTasks: 0,
        });
      }
    } catch (err: any) {
      setWorkSummary({
        tasksCompleted: 0,
        totalTime: '0h 0m',
        totalWorkOrders: 0,
        inProgressTasks: 0,
      });
    } finally {
      setWorkOrdersLoading(false);
    }
  };

  // Toggle user activation status
  const toggleUserActivation = async () => {
    if (!staffMember) return;
    
    try {
      setActivationLoading(true);
      setError(null);
      
      // In the database, it's a boolean field is_active: true/false
      // In the UI we display it as a string status: 'Active'/'Inactive'
      
      // Get current is_active state (true if status is 'Active', false otherwise)
      const isCurrentlyActive = staffMember.status === 'Active';
      
      // Toggle the value for the API request
      const newIsActiveValue = !isCurrentlyActive;
      
      // Call the activation/deactivation endpoint with the boolean is_active field
      // using the staffId from state
      const response = await api.put(`/api/users/${staffId}/activate`, {
        is_active: newIsActiveValue
      });
      
      // Update the staff member status in local state using the string representation
      setStaffMember(prev => prev ? {
        ...prev,
        status: newIsActiveValue ? 'Active' : 'Inactive'
      } : null);
      
    } catch (err: any) {
      setError(err.response?.data?.message || err.message || 'Failed to update user status');
    } finally {
      setActivationLoading(false);
    }
  };

  // Check access and fetch data on component mount
  useEffect(() => {
    if (authLoading) {
      return;
    }
    
    if (!isAuthenticated) {
      router.push('/login');
      return;
    }
    
    // Route protection handles access control
    if (!hasAccess) {
      return;
    }
    
    fetchStaffMember();
  }, [isAuthenticated, authLoading, router, user, staffId, hasAccess]);

  // Handle error state
  if (error) {
    return (
      <div className="p-6 bg-gray-50 min-h-screen">
        <div className="max-w-6xl mx-auto">
          <div className="bg-white p-8 rounded-lg shadow-sm flex flex-col items-center">
            <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-red-600">
                <circle cx="12" cy="12" r="10"></circle>
                <line x1="12" y1="8" x2="12" y2="12"></line>
                <line x1="12" y1="16" x2="12.01" y2="16"></line>
              </svg>
            </div>
            <div className="text-lg font-medium text-red-600">{error}</div>
            <button 
              onClick={() => router.push('/staff')}
              className="mt-4 px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 text-sm font-medium"
            >
              Back to Staff List
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Handle loading state
  if (loading) {
    return (
      <div className="p-6 bg-gray-50 min-h-screen">
        <div className="max-w-6xl mx-auto">
          <div className="bg-white p-8 rounded-lg shadow-sm flex flex-col items-center">
            <div className="w-12 h-12 border-4 border-t-blue-600 border-gray-200 rounded-full animate-spin mb-4"></div>
            <div className="text-lg font-medium text-gray-700">Loading staff details...</div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      <div className="max-w-6xl mx-auto">
        {/* Header with back button and staff info */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <Link 
              href="/staff" 
              className="p-2 mr-3 bg-white rounded-md hover:bg-gray-100 transition-colors border border-gray-200"
            >
              <ArrowLeft size={20} className="text-gray-600" />
            </Link>
            <div className="flex items-center">
              <div className="bg-blue-100 p-1 rounded-full mr-3">
                <UserCheck size={24} className="text-blue-600" />
              </div>
              <div>
                <h1 className="text-2xl font-semibold text-gray-800">
                  {staffMember ? `${staffMember.first_name} ${staffMember.last_name}` : ''}
                </h1>
                <p className="text-sm text-gray-500">
                  Staff since {staffMember?.created_at 
                  ? new Date(staffMember.created_at).toLocaleDateString()
                  : 'Unknown'}
                </p>
              </div>
            </div>
          </div>
          {canEditStaff() && staffMember?.role !== 'Feedback Screen' && (
            <div className="flex items-center gap-2">
              <button 
                onClick={() => setShowEditModal(true)} 
                className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded text-sm flex items-center"
              >
                <Edit size={16} className="mr-2" />
                Edit
              </button>
              {user?.role_name === 'Admin' && (
                <button 
                  onClick={() => setShowPasswordResetModal(true)} 
                  className="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded text-sm flex items-center"
                >
                  <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />
                  </svg>
                  Reset Password
                </button>
              )}
            </div>
          )}
        </div>

        <div className="flex flex-col gap-6">
          {/* Staff Information Card */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden w-full">
            <div className="p-6 relative">
              <div className="absolute left-0 top-0 bottom-0 w-1 bg-blue-500"></div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold">Personal Information</h2>
                {(user?.role_name === 'Admin' || user?.role_name === 'Accountant') && (
                  <button
                    onClick={toggleUserActivation}
                    disabled={activationLoading}
                    className={`px-4 py-2 rounded text-sm font-medium ${
                      staffMember?.status === 'Active' 
                        ? 'bg-red-50 text-red-600 hover:bg-red-100' 
                        : 'bg-green-50 text-green-600 hover:bg-green-100'
                    } transition-colors disabled:opacity-50 disabled:cursor-not-allowed`}
                  >
                    {activationLoading 
                      ? 'Updating...' 
                      : staffMember?.status === 'Active' 
                        ? 'Deactivate Account' 
                        : 'Activate Account'
                    }
                  </button>
                )}
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <div className="mb-4">
                    <p className="text-sm text-gray-500 uppercase">Name</p>
                    <p className="font-medium text-gray-900">
                      {staffMember ? `${staffMember.first_name} ${staffMember.last_name}` : ''}
                    </p>
                  </div>
                  <div className="mb-4">
                    <p className="text-sm text-gray-500 uppercase">Email</p>
                    <p className="font-medium text-gray-900">
                      {staffMember?.email}
                    </p>
                  </div>
                  <div className="mb-4">
                    <p className="text-sm text-gray-500 uppercase">Phone</p>
                    <p className="font-medium text-gray-900">
                      {staffMember?.phone || 'Not provided'}
                    </p>
                  </div>
                </div>
                <div>
                  <div className="mb-4">
                    <p className="text-sm text-gray-500 uppercase">Role</p>
                    <p className="font-medium text-gray-900">
                      {staffMember?.role}
                    </p>
                  </div>
                  <div className="mb-4">
                    <p className="text-sm text-gray-500 uppercase">Branch</p>
                    <p className="font-medium text-gray-900">
                      {staffMember?.branch?.branch_name || 'Not assigned'}
                    </p>
                  </div>
                  <div className="mb-4">
                    <p className="text-sm text-gray-500 uppercase">Status</p>
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                      staffMember?.status === 'Active' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {staffMember?.status || 'Active'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Permissions Card */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden w-full">
            <div className="p-6 relative">
              <div className="absolute left-0 top-0 bottom-0 w-1 bg-purple-500"></div>
              <button
                onClick={togglePermissionsCard}
                className="w-full flex items-center justify-between mb-4 text-left hover:bg-gray-50 -m-2 p-2 rounded transition-colors"
              >
                <h2 className="text-xl font-semibold">Granted Permissions</h2>
                <div className="flex items-center space-x-2">
                  {(() => {
                    const grantedPermissions = staffMember?.permissions?.filter(permission => permission.granted) || [];
                    return grantedPermissions.length > 0 && (
                      <span className="text-sm text-gray-500 bg-purple-100 px-2 py-1 rounded-full">
                        {grantedPermissions.length} permission{grantedPermissions.length !== 1 ? 's' : ''}
                      </span>
                    );
                  })()}
                  {permissionsCardCollapsed ? (
                    <ChevronRight className="w-5 h-5 text-gray-500" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-gray-500" />
                  )}
                </div>
              </button>
              
              {!permissionsCardCollapsed && (() => {
                // Filter to only show granted permissions
                const grantedPermissions = staffMember?.permissions?.filter(permission => permission.granted) || [];
                
                if (grantedPermissions.length > 0) {
                  // Group permissions by category
                  const permissionsByCategory = grantedPermissions.reduce((acc, permission) => {
                    const category = permission.category || 'OTHER';
                    if (!acc[category]) {
                      acc[category] = [];
                    }
                    acc[category].push(permission);
                    return acc;
                  }, {} as Record<string, typeof grantedPermissions>);

                  return (
                    <div className="space-y-4">
                      {/* Permissions Summary */}
                      <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                        <div className="flex items-center space-x-3">
                          <div className="bg-purple-100 p-2 rounded-lg">
                            <svg className="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                            </svg>
                          </div>
                          <div>
                            <h4 className="font-semibold text-purple-900">
                              {grantedPermissions.length} Permission{grantedPermissions.length !== 1 ? 's' : ''} Granted
                            </h4>
                            <p className="text-sm text-purple-700">
                              Across {Object.keys(permissionsByCategory).length} categor{Object.keys(permissionsByCategory).length !== 1 ? 'ies' : 'y'}
                            </p>
                          </div>
                        </div>
                      </div>

                      {/* Permissions by Category */}
                      <div className="space-y-3">
                        {Object.entries(permissionsByCategory).map(([categoryKey, categoryPerms]) => {
                          const categoryName = categoryKey.replace(/_/g, ' ').toLowerCase();
                          const totalCount = categoryPerms.length;
                          const isCollapsed = collapsedCategories[categoryKey] ?? true;

                          return (
                            <div key={categoryKey} className="border border-gray-200 rounded-lg overflow-hidden">
                              <button
                                onClick={() => toggleCategoryCollapse(categoryKey)}
                                className="w-full bg-gray-50 hover:bg-gray-100 p-4 text-left transition-colors"
                              >
                                <div className="flex items-center space-x-2">
                                  {isCollapsed ? (
                                    <ChevronRight className="w-4 h-4 text-gray-500" />
                                  ) : (
                                    <ChevronDown className="w-4 h-4 text-gray-500" />
                                  )}
                                  <div>
                                    <h3 className="font-medium text-gray-900 capitalize">
                                      {categoryName}
                                    </h3>
                                    <span className="text-sm text-gray-500">
                                      {totalCount} permission{totalCount !== 1 ? 's' : ''}
                                    </span>
                                  </div>
                                </div>
                              </button>

                              {!isCollapsed && (
                                <div className="p-4 space-y-2 bg-white border-t border-gray-200">
                                  {categoryPerms.map((perm) => (
                                    <div key={perm.permission_id} className="flex items-start space-x-3">
                                      <div className="h-2 w-2 rounded-full bg-green-500 mt-2 flex-shrink-0"></div>
                                      <div className="flex-1">
                                        <h4 className="font-medium text-gray-900">
                                          {perm.permission_name.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                                        </h4>
                                        {perm.description && (
                                          <p className="text-sm text-gray-600 mt-1">
                                            {perm.description}
                                          </p>
                                        )}
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                } else {
                  return (
                    <div className="bg-gray-50 rounded-lg p-8 text-center">
                      <div className="text-gray-400 mb-3">
                        <svg className="w-12 h-12 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                        </svg>
                      </div>
                      <h3 className="font-medium text-gray-900 mb-1">No Permissions Granted</h3>
                      <p className="text-gray-500">This staff member has no permissions assigned.</p>
                    </div>
                  );
                }
              })()}
            </div>
          </div>
          
          {/* Work Summary Card - Only show for non-admin staff members */}
          {staffMember?.role !== 'Admin' && (
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden w-full">
              <div className="p-6 relative">
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-green-500"></div>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-semibold">Work Summary</h2>
                  {workOrdersLoading && (
                    <div className="animate-spin rounded-full h-5 w-5 border-t-2 border-b-2 border-blue-500"></div>
                  )}
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {/* Total Work Orders */}
                  <div className="border border-gray-200 rounded-lg p-3">
                    <div className="flex items-center mb-1">
                      <Activity size={16} className="mr-2 text-blue-500" />
                      <p className="text-sm text-gray-500 uppercase">Total Work Orders</p>
                    </div>
                    <p className="font-medium text-xl text-gray-900">{workSummary.totalWorkOrders || 0}</p>
                  </div>
                  
                  {/* Completed Tasks - Dynamic label based on role */}
                  <div className="border border-gray-200 rounded-lg p-3">
                    <div className="flex items-center mb-1">
                      <Activity size={16} className="mr-2 text-green-500" />
                      <p className="text-sm text-gray-500 uppercase">
                        {staffMember?.role?.toLowerCase().includes('supervisor') ? 'Parts Completed' : 'Stages Completed'}
                      </p>
                    </div>
                    <p className="font-medium text-xl text-gray-900">{workSummary.tasksCompleted}</p>
                  </div>
                  
                  {/* In Progress Tasks - Dynamic label based on role */}
                  <div className="border border-gray-200 rounded-lg p-3">
                    <div className="flex items-center mb-1">
                      <Activity size={16} className="mr-2 text-orange-500" />
                      <p className="text-sm text-gray-500 uppercase">
                        {staffMember?.role?.toLowerCase().includes('supervisor') ? 'Parts In Progress' : 'Stages In Progress'}
                      </p>
                    </div>
                    <p className="font-medium text-xl text-gray-900">{workSummary.inProgressTasks || 0}</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
        
        {/* Staff Edit Modal - Don't show for Feedback Screen role */}
        {staffMember?.role !== 'Feedback Screen' && (
          <StaffEditModal 
            staff={staffMember}
            isOpen={showEditModal}
            onCloseAction={() => setShowEditModal(false)}
            onUpdateAction={fetchStaffMember}
          />
        )}
        
        {/* Password Reset Modal - Admin only */}
        {user?.role_name === 'Admin' && (
          <PasswordResetModal 
            staff={staffMember}
            isOpen={showPasswordResetModal}
            onCloseAction={() => setShowPasswordResetModal(false)}
            onUpdateAction={fetchStaffMember}
          />
        )}
      </div>
    </div>
  );
}
