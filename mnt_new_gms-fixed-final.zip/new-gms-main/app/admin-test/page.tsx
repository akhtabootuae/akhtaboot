'use client';

import React, { useState } from 'react';
import { useAuth } from '@/app/context/AuthContext';
import Link from 'next/link';

export default function AdminTest() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const [message, setMessage] = useState('');

  // Helper function for case-insensitive admin check
  const isAdmin = user?.role_name?.toLowerCase() === 'admin';

  const forceAdminRole = () => {
    try {
      // Get current user from localStorage
      const userStr = localStorage.getItem('user');
      if (!userStr) {
        setMessage('No user found in localStorage. Please login first.');
        return;
      }
      
      const currentUser = JSON.parse(userStr);
      console.log('Current user before update:', currentUser);
      
      // Update role to admin
      currentUser.role_name = 'admin';
      
      // Save back to localStorage
      localStorage.setItem('user', JSON.stringify(currentUser));
      
      setMessage('User role updated to admin! Refreshing page...');
      
      // Refresh the page after a short delay
      setTimeout(() => {
        window.location.reload();
      }, 1000);
    } catch (error) {
      console.error('Error setting admin role:', error);
      setMessage('Error setting admin role: ' + error);
    }
  };

  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-8">Admin Authentication Test</h1>
      
      <div className="bg-white p-6 rounded-lg shadow-md mb-6">
        <h2 className="text-2xl font-semibold mb-4">Authentication Status</h2>
        <p className="text-lg mb-2">
          <strong>Is Authenticated:</strong> {isAuthenticated ? 'Yes ✅' : 'No ❌'}
        </p>
        
        {isAuthenticated && user ? (
          <div>
            <h3 className="text-xl font-semibold mt-4 mb-2">User Details:</h3>
            <div className="bg-gray-100 p-4 rounded mb-4">
              <p><strong>Name:</strong> {user.name}</p>
              <p><strong>Email:</strong> {user.email}</p>
              <p><strong>Role:</strong> {user.role_name}</p>
              <p><strong>Branch:</strong> {user.branch?.branch_name} ({user.branch?.branch_code})</p>
            </div>
            
            <p className="text-lg my-4">
              <strong>Is Admin:</strong> {isAdmin ? 'Yes ✅' : 'No ❌'}
            </p>
            
            <details className="mt-4">
              <summary className="cursor-pointer text-blue-600 hover:text-blue-800">View Full User Object</summary>
              <pre className="bg-gray-100 p-4 rounded overflow-auto mt-2 text-sm">
                {JSON.stringify(user, null, 2)}
              </pre>
            </details>
          </div>
        ) : (
          <p className="text-red-500">User is not authenticated</p>
        )}
      </div>
      
      {isAuthenticated && !isAdmin && (
        <div className="bg-yellow-50 border border-yellow-200 p-4 rounded mb-6">
          <h3 className="text-lg font-semibold text-yellow-800 mb-2">Force Admin Role (Testing Only)</h3>
          <p className="text-yellow-700 mb-4">
            You&apos;re not currently set as an admin. Click the button below to temporarily set your role to admin for testing purposes.
          </p>
          <button 
            onClick={forceAdminRole}
            className="px-4 py-2 bg-yellow-600 text-white rounded hover:bg-yellow-700"
          >
            Force Admin Role
          </button>
          {message && (
            <p className="mt-2 text-sm text-yellow-800">{message}</p>
          )}
        </div>
      )}
      
      <div className="flex gap-4 flex-wrap">
        <Link href="/" className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
          Go to Dashboard
        </Link>
        
        <Link href="/register" className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700">
          Go to Register Page
        </Link>
        
        <button 
          onClick={() => window.location.reload()} 
          className="px-4 py-2 bg-gray-600 text-white rounded hover:bg-gray-700"
        >
          Refresh Page
        </button>
      </div>
      
      <div className="mt-8 bg-blue-50 border border-blue-200 p-4 rounded">
        <h3 className="text-lg font-semibold text-blue-800 mb-2">Instructions</h3>
        <ol className="list-decimal list-inside text-blue-700 space-y-1">
          <li>If you&apos;re authenticated but not an admin, click &quot;Force Admin Role&quot;</li>
          <li>After the page refreshes, you should see &quot;Is Admin: Yes ✅&quot;</li>
          <li>Then try clicking &quot;Go to Register Page&quot; to test admin access</li>
          <li>The register page should now be accessible</li>
        </ol>
      </div>
    </div>
  );
}
