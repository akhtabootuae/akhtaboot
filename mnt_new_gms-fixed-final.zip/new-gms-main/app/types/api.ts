// API Response Types - Common structures used across the application

// Base API Response Structure
export interface ApiResponse<T = unknown> {
  success?: boolean;
  message: string;
  data: T;
  error?: string;
  errors?: Record<string, string[]>;
}

// Paginated API Response
export interface PaginatedApiResponse<T = unknown> extends ApiResponse<T[]> {
  pagination: {
    currentPage: number;
    totalPages: number;
    totalItems: number;
    totalCount?: number; // Alternative naming
    hasPrevPage: boolean;
    hasNextPage: boolean;
    limit?: number;
    page?: number;
    // Support for different pagination formats
    current_page?: number;
    total_pages?: number;
    total_count?: number;
    has_next?: boolean;
    has_prev?: boolean;
  };
}

// User/Staff Types
export interface User {
  _id: string;
  id?: string; // Alternative ID field
  first_name: string;
  last_name: string;
  full_name?: string;
  email: string;
  phone?: string;
  role: string;
  speciality?: string;
  staff_code?: string;
  employee_number?: string;
  employee_id?: string;
  active?: boolean;
  branch?: {
    _id?: string;
    branch_id?: string;
    branch_name: string;
    branch_code?: string;
    location?: string;
  };
  permissions?: UserPermission[];
  created_at?: string | Date;
  updated_at?: string | Date;
}

export interface UserPermission {
  resource: string;
  actions: string[];
}

export interface AuthResponse {
  success: boolean;
  message: string;
  token?: string;
  user?: User;
  data?: {
    user: User;
    token: string;
  };
}

// Customer Types
export interface Customer {
  _id: string;
  customer_id?: string;
  name?: string;
  first_name?: string;
  last_name?: string;
  full_name?: string;
  email?: string;
  phone?: string;
  city?: string;
  country?: string;
  address?: string;
  status?: string;
  branch?: {
    _id?: string;
    branch_id?: string;
    branch_name: string;
    branch_code?: string;
    location?: string;
  };
  vehicles?: Vehicle[];
  created_at?: string | Date;
  updated_at?: string | Date;
}

// Vehicle Types
export interface Vehicle {
  _id?: string;
  vehicle_id?: string | number;
  make?: string;
  model?: string;
  year?: number;
  license_plate?: string;
  vin?: string;
  color?: string;
  vehicle_type?: string;
  owner_id?: string;
  customer_id?: string;
  created_at?: string | Date;
  updated_at?: string | Date;
}

// Work Order Types
export interface WorkOrder {
  _id: string;
  work_order_id?: string;
  work_order_number?: string;
  customer_id: string;
  customer?: Customer;
  vehicle_id: string;
  vehicle?: Vehicle;
  title?: string;
  description?: string;
  status: 'pending' | 'in_progress' | 'completed' | 'cancelled' | 'on_hold';
  priority?: 'low' | 'medium' | 'high' | 'urgent';
  assigned_to?: string[];
  technician_id?: string;
  technicians?: User[];
  estimated_hours?: number;
  actual_hours?: number;
  estimated_cost?: number;
  actual_cost?: number;
  parts?: WorkOrderPart[];
  services?: WorkOrderService[];
  stages?: WorkOrderStage[];
  notes?: string;
  internal_notes?: string;
  attachments?: Attachment[];
  created_by?: string;
  created_at: string | Date;
  updated_at?: string | Date;
  completed_at?: string | Date;
}

export interface WorkOrderStage {
  _id: string;
  stage_id?: string;
  name: string;
  description?: string;
  status: 'pending' | 'in_progress' | 'completed' | 'skipped';
  order?: number;
  estimated_hours?: number;
  actual_hours?: number;
  assigned_to?: string;
  technician?: User;
  started_at?: string | Date;
  completed_at?: string | Date;
  notes?: string;
  qa_required?: boolean;
  qa_passed?: boolean;
  qa_notes?: string;
}

export interface WorkOrderPart {
  _id?: string;
  part_id?: string;
  name: string;
  part_number?: string;
  quantity: number;
  unit_price: number;
  total_price: number;
  supplier?: string;
  notes?: string;
}

export interface WorkOrderService {
  _id?: string;
  service_id?: string;
  name: string;
  description?: string;
  quantity: number;
  unit_price: number;
  total_price: number;
  estimated_hours?: number;
  actual_hours?: number;
}

// Expense Types
export interface Expense {
  _id: string;
  expense_id?: string;
  title: string;
  description?: string;
  amount: number;
  category: string;
  subcategory?: string;
  expense_date: string | Date;
  created_by: string;
  created_by_user?: User;
  approved_by?: string;
  approved_by_user?: User;
  status: 'pending' | 'approved' | 'rejected' | 'paid';
  receipt_url?: string;
  receipt_filename?: string;
  notes?: string;
  reference_number?: string;
  vendor?: string;
  payment_method?: string;
  reimbursable?: boolean;
  created_at: string | Date;
  updated_at?: string | Date;
  approved_at?: string | Date;
}

// Attachment Types
export interface Attachment {
  _id?: string;
  filename: string;
  original_filename?: string;
  url: string;
  file_path?: string;
  file_size?: number;
  mime_type?: string;
  uploaded_by?: string;
  uploaded_at: string | Date;
  description?: string;
}

// Dashboard/Analytics Types
export interface DashboardStats {
  total_customers?: number;
  total_invoices?: number;
  total_work_orders?: number;
  pending_work_orders?: number;
  completed_work_orders?: number;
  monthly_revenue?: number;
  pending_payments?: number;
  overdue_invoices?: number;
  active_technicians?: number;
  // Additional stats can be added here
}

export interface ChartData {
  labels: string[];
  datasets: Array<{
    label: string;
    data: number[];
    backgroundColor?: string | string[];
    borderColor?: string | string[];
    borderWidth?: number;
  }>;
}

export interface RevenueData {
  period: string;
  revenue: number;
  expenses?: number;
  profit?: number;
}

export interface CustomerAnalytics {
  customer_id: string;
  customer_name: string;
  total_spent: number;
  total_invoices: number;
  average_invoice_value: number;
  last_service_date?: string | Date;
  lifetime_value: number;
}

// Filter Types
export interface BaseFilters {
  page?: number;
  limit?: number;
  search?: string;
  sort_by?: string;
  sort_order?: 'asc' | 'desc';
  date_from?: string;
  date_to?: string;
}

export interface WorkOrderFilters extends BaseFilters {
  status?: string;
  priority?: string;
  customer_id?: string;
  technician_id?: string;
  assigned_to?: string;
}

export interface ExpenseFilters extends BaseFilters {
  category?: string;
  status?: string;
  created_by?: string;
  amount_min?: number;
  amount_max?: number;
}

export interface CustomerFilters extends BaseFilters {
  status?: string;
  city?: string;
  country?: string;
  branch_id?: string;
}

// Form Data Types for API Requests
export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterData {
  first_name: string;
  last_name: string;
  email: string;
  password: string;
  phone?: string;
  role?: string;
  speciality?: string;
}

export interface CreateCustomerData {
  first_name: string;
  last_name: string;
  email?: string;
  phone?: string;
  city?: string;
  country?: string;
  address?: string;
}

export interface CreateWorkOrderData {
  customer_id: string;
  vehicle_id: string;
  title: string;
  description?: string;
  priority?: 'low' | 'medium' | 'high' | 'urgent';
  estimated_hours?: number;
  estimated_cost?: number;
  assigned_to?: string[];
  services?: Omit<WorkOrderService, '_id'>[];
  parts?: Omit<WorkOrderPart, '_id'>[];
}

export interface CreateExpenseData {
  title: string;
  description?: string;
  amount: number;
  category: string;
  subcategory?: string;
  expense_date: string;
  vendor?: string;
  payment_method?: string;
  reimbursable?: boolean;
  notes?: string;
}

// Error Types
export interface ApiError {
  message: string;
  code?: string | number;
  field?: string;
  details?: Record<string, unknown>;
}

export interface ValidationError {
  field: string;
  message: string;
  code?: string;
}

// Generic Types for Form Handling
export interface FormField {
  name: string;
  label: string;
  type: 'text' | 'email' | 'password' | 'number' | 'date' | 'select' | 'textarea' | 'checkbox';
  required?: boolean;
  placeholder?: string;
  options?: Array<{ value: string | number; label: string }>;
  validation?: {
    min?: number;
    max?: number;
    pattern?: string;
    custom?: (value: unknown) => boolean | string;
  };
}

export interface SelectOption {
  value: string | number;
  label: string;
  disabled?: boolean;
}

// Notification Types
export interface SystemNotification {
  _id: string;
  type: 'info' | 'success' | 'warning' | 'error';
  title: string;
  message: string;
  read: boolean;
  user_id: string;
  created_at: string | Date;
  expires_at?: string | Date;
  action_url?: string;
  action_label?: string;
}

// File Upload Types
export interface FileUploadResponse {
  success: boolean;
  message: string;
  file?: {
    filename: string;
    original_filename: string;
    url: string;
    file_size: number;
    mime_type: string;
  };
  files?: Array<{
    filename: string;
    original_filename: string;
    url: string;
    file_size: number;
    mime_type: string;
  }>;
}

// Search Results
export interface SearchResult {
  _id: string;
  type: 'customer' | 'vehicle' | 'work_order' | 'invoice' | 'expense';
  title: string;
  subtitle?: string;
  description?: string;
  url?: string;
  relevance_score?: number;
}

export interface SearchResponse {
  success: boolean;
  message: string;
  results: SearchResult[];
  total_results: number;
  query: string;
  categories: Record<string, number>;
}