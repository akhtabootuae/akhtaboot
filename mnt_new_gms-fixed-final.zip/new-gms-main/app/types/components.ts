// Component Types - Props and component-specific type definitions

import { ReactNode, MouseEvent, ChangeEvent, FormEvent } from 'react';
import { User, Customer, Vehicle, WorkOrder, Expense, Attachment } from './api';
import { SelectOption } from './forms';

// Base Component Props
export interface BaseComponentProps {
  className?: string;
  children?: ReactNode;
  id?: string;
  'data-testid'?: string;
}

// Button Component Props
export interface ButtonProps extends BaseComponentProps {
  variant?: 'primary' | 'secondary' | 'success' | 'danger' | 'warning' | 'info' | 'light' | 'dark';
  size?: 'sm' | 'md' | 'lg';
  type?: 'button' | 'submit' | 'reset';
  disabled?: boolean;
  loading?: boolean;
  onClick?: (event: MouseEvent<HTMLButtonElement>) => void;
  icon?: ReactNode;
  iconPosition?: 'left' | 'right';
  fullWidth?: boolean;
}

// Input Component Props
export interface InputProps extends BaseComponentProps {
  type?: 'text' | 'email' | 'password' | 'number' | 'date' | 'datetime-local' | 'time' | 'tel' | 'url';
  value?: string | number;
  defaultValue?: string | number;
  placeholder?: string;
  disabled?: boolean;
  readonly?: boolean;
  required?: boolean;
  onChange?: (event: ChangeEvent<HTMLInputElement>) => void;
  onBlur?: (event: ChangeEvent<HTMLInputElement>) => void;
  onFocus?: (event: ChangeEvent<HTMLInputElement>) => void;
  error?: string;
  label?: string;
  description?: string;
  prefix?: ReactNode;
  suffix?: ReactNode;
  min?: number;
  max?: number;
  step?: number;
  pattern?: string;
  autoComplete?: string;
  autoFocus?: boolean;
}

// Select Component Props
export interface SelectProps extends BaseComponentProps {
  value?: string | number;
  defaultValue?: string | number;
  placeholder?: string;
  disabled?: boolean;
  required?: boolean;
  multiple?: boolean;
  onChange?: (value: string | number | string[] | number[]) => void;
  onBlur?: () => void;
  options: SelectOption[];
  error?: string;
  label?: string;
  description?: string;
  searchable?: boolean;
  clearable?: boolean;
  loading?: boolean;
}

// Textarea Component Props
export interface TextareaProps extends BaseComponentProps {
  value?: string;
  defaultValue?: string;
  placeholder?: string;
  disabled?: boolean;
  readonly?: boolean;
  required?: boolean;
  rows?: number;
  cols?: number;
  maxLength?: number;
  onChange?: (event: ChangeEvent<HTMLTextAreaElement>) => void;
  onBlur?: (event: ChangeEvent<HTMLTextAreaElement>) => void;
  error?: string;
  label?: string;
  description?: string;
  resize?: 'none' | 'both' | 'horizontal' | 'vertical';
}

// Checkbox Component Props
export interface CheckboxProps extends BaseComponentProps {
  checked?: boolean;
  defaultChecked?: boolean;
  disabled?: boolean;
  required?: boolean;
  onChange?: (checked: boolean) => void;
  label?: string;
  description?: string;
  error?: string;
  indeterminate?: boolean;
}

// Modal Component Props
export interface ModalProps extends BaseComponentProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  subtitle?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl' | 'full';
  closeOnBackdrop?: boolean;
  closeOnEscape?: boolean;
  showCloseButton?: boolean;
  footer?: ReactNode;
  loading?: boolean;
}

// Table Component Props
export interface TableColumn<T = Record<string, unknown>> {
  key: string;
  title: string;
  dataIndex?: string;
  width?: string | number;
  sortable?: boolean;
  filterable?: boolean;
  render?: (value: unknown, record: T, index: number) => ReactNode;
  align?: 'left' | 'center' | 'right';
  fixed?: 'left' | 'right';
  ellipsis?: boolean;
}

export interface TableProps<T = Record<string, unknown>> extends BaseComponentProps {
  columns: TableColumn<T>[];
  data: T[];
  loading?: boolean;
  pagination?: {
    current: number;
    total: number;
    pageSize: number;
    onChange: (page: number, pageSize: number) => void;
  };
  rowKey?: string | ((record: T) => string);
  rowSelection?: {
    selectedRowKeys: string[];
    onChange: (selectedRowKeys: string[], selectedRows: T[]) => void;
    type?: 'checkbox' | 'radio';
  };
  expandable?: {
    expandedRowRender: (record: T) => ReactNode;
    rowExpandable?: (record: T) => boolean;
  };
  onRow?: (record: T, index: number) => Record<string, unknown>;
  scroll?: { x?: number; y?: number };
  size?: 'small' | 'middle' | 'large';
  bordered?: boolean;
  striped?: boolean;
  sticky?: boolean;
}

// Card Component Props
export interface CardProps extends BaseComponentProps {
  title?: string;
  subtitle?: string;
  extra?: ReactNode;
  cover?: ReactNode;
  actions?: ReactNode[];
  loading?: boolean;
  hoverable?: boolean;
  bordered?: boolean;
  size?: 'small' | 'default' | 'large';
}

// Form Component Props
export interface FormProps extends BaseComponentProps {
  initialValues?: Record<string, unknown>;
  onSubmit: (values: Record<string, unknown>) => void | Promise<void>;
  onCancel?: () => void;
  onValuesChange?: (changedValues: Record<string, unknown>, allValues: Record<string, unknown>) => void;
  loading?: boolean;
  disabled?: boolean;
  layout?: 'horizontal' | 'vertical' | 'inline';
  labelCol?: { span?: number; offset?: number };
  wrapperCol?: { span?: number; offset?: number };
  size?: 'small' | 'middle' | 'large';
  validateOnChange?: boolean;
  submitButtonText?: string;
  cancelButtonText?: string;
  showCancelButton?: boolean;
}

// Navigation Component Props
export interface NavItemProps {
  label: string;
  href?: string;
  icon?: ReactNode;
  active?: boolean;
  disabled?: boolean;
  onClick?: () => void;
  children?: NavItemProps[];
  badge?: string | number;
  external?: boolean;
}

export interface NavbarProps extends BaseComponentProps {
  brand?: {
    name: string;
    logo?: string;
    href?: string;
  };
  items: NavItemProps[];
  user?: User;
  onUserMenuClick?: (action: string) => void;
  fixed?: boolean;
  variant?: 'light' | 'dark';
}

export interface SidebarProps extends BaseComponentProps {
  collapsed?: boolean;
  onCollapse?: (collapsed: boolean) => void;
  items: NavItemProps[];
  user?: User;
  logo?: string;
  footer?: ReactNode;
}

// Dashboard Component Props
export interface StatCardProps extends BaseComponentProps {
  title: string;
  value: string | number;
  icon?: ReactNode;
  trend?: {
    value: number;
    type: 'up' | 'down' | 'neutral';
    period?: string;
  };
  color?: 'primary' | 'success' | 'warning' | 'danger' | 'info';
  loading?: boolean;
  onClick?: () => void;
}

export interface ChartProps extends BaseComponentProps {
  type: 'line' | 'bar' | 'pie' | 'doughnut' | 'area';
  data: {
    labels: string[];
    datasets: Array<{
      label: string;
      data: number[];
      backgroundColor?: string | string[];
      borderColor?: string | string[];
      borderWidth?: number;
      fill?: boolean;
    }>;
  };
  options?: Record<string, unknown>;
  height?: number;
  loading?: boolean;
}

// Customer Component Props
export interface CustomerRowProps {
  customer: Customer;
  onEdit?: (customer: Customer) => void;
  onDelete?: (customerId: string) => void;
  onView?: (customerId: string) => void;
  actions?: Array<{
    label: string;
    onClick: (customer: Customer) => void;
    icon?: ReactNode;
  }>;
}

export interface CustomerFormProps {
  initialData?: Partial<Customer>;
  onSubmit: (data: Customer) => void | Promise<void>;
  onCancel?: () => void;
  loading?: boolean;
  mode?: 'create' | 'edit';
}

export interface CustomerListProps {
  customers: Customer[];
  loading?: boolean;
  pagination?: {
    current: number;
    total: number;
    pageSize: number;
    onChange: (page: number) => void;
  };
  filters?: Record<string, unknown>;
  onFiltersChange?: (filters: Record<string, unknown>) => void;
  onCustomerSelect?: (customer: Customer) => void;
  selectedCustomers?: string[];
  onSelectionChange?: (selectedIds: string[]) => void;
}

// Vehicle Component Props
export interface VehicleCardProps {
  vehicle: Vehicle;
  customer?: Customer;
  onEdit?: (vehicle: Vehicle) => void;
  onDelete?: (vehicleId: string) => void;
  onView?: (vehicleId: string) => void;
  showCustomer?: boolean;
}

export interface VehicleFormProps {
  initialData?: Partial<Vehicle>;
  customerId?: string;
  onSubmit: (data: Vehicle) => void | Promise<void>;
  onCancel?: () => void;
  loading?: boolean;
  mode?: 'create' | 'edit';
}

// Work Order Component Props
export interface WorkOrderCardProps {
  workOrder: WorkOrder;
  onEdit?: (workOrder: WorkOrder) => void;
  onDelete?: (workOrderId: string) => void;
  onView?: (workOrderId: string) => void;
  onStatusChange?: (workOrderId: string, status: string) => void;
  compact?: boolean;
}

export interface WorkOrderFormProps {
  initialData?: Partial<WorkOrder>;
  onSubmit: (data: WorkOrder) => void | Promise<void>;
  onCancel?: () => void;
  loading?: boolean;
  mode?: 'create' | 'edit';
  customers?: Customer[];
  vehicles?: Vehicle[];
  technicians?: User[];
}

export interface WorkOrderStageProps {
  stage: WorkOrder['stages'][0];
  workOrderId: string;
  onStageUpdate?: (stageId: string, updates: Partial<WorkOrder['stages'][0]>) => void;
  canEdit?: boolean;
  technicians?: User[];
}

// Invoice Component Props
export interface InvoiceItemProps {
  item: {
    description: string;
    quantity: number;
    unit_price: number;
    amount: number;
  };
  onEdit?: (item: InvoiceItemProps['item']) => void;
  onDelete?: () => void;
  readonly?: boolean;
}

export interface PaymentRecordProps {
  payment: {
    payment_date: Date;
    amount: number;
    payment_method: string;
    reference_number?: string;
    notes?: string;
  };
  onEdit?: (payment: PaymentRecordProps['payment']) => void;
  onDelete?: () => void;
  readonly?: boolean;
}

// Expense Component Props
export interface ExpenseCardProps {
  expense: Expense;
  onEdit?: (expense: Expense) => void;
  onDelete?: (expenseId: string) => void;
  onView?: (expenseId: string) => void;
  onApprove?: (expenseId: string) => void;
  onReject?: (expenseId: string) => void;
  canApprove?: boolean;
  compact?: boolean;
}

export interface ExpenseFormProps {
  initialData?: Partial<Expense>;
  onSubmit: (data: Expense) => void | Promise<void>;
  onCancel?: () => void;
  loading?: boolean;
  mode?: 'create' | 'edit';
  categories?: string[];
}

// File Upload Component Props
export interface FileUploadProps extends BaseComponentProps {
  accept?: string;
  multiple?: boolean;
  maxSize?: number; // in bytes
  maxFiles?: number;
  onUpload: (files: File[]) => void | Promise<void>;
  onError?: (error: string) => void;
  loading?: boolean;
  disabled?: boolean;
  showPreview?: boolean;
  dragAndDrop?: boolean;
  existingFiles?: Attachment[];
  onFileRemove?: (fileId: string) => void;
}

export interface ImageUploadProps extends BaseComponentProps {
  value?: string;
  onChange: (url: string) => void;
  onUpload: (file: File) => Promise<string>;
  maxSize?: number;
  aspectRatio?: number;
  cropEnabled?: boolean;
  placeholder?: string;
  loading?: boolean;
  disabled?: boolean;
}

// Search Component Props
export interface SearchBarProps extends BaseComponentProps {
  value?: string;
  placeholder?: string;
  onSearch: (query: string) => void;
  onClear?: () => void;
  loading?: boolean;
  suggestions?: Array<{
    label: string;
    value: string;
    type?: string;
  }>;
  onSuggestionSelect?: (suggestion: SearchBarProps['suggestions'][0]) => void;
  showSuggestions?: boolean;
  debounceMs?: number;
}

export interface FilterBarProps extends BaseComponentProps {
  filters: Array<{
    key: string;
    label: string;
    type: 'select' | 'date' | 'text' | 'number';
    options?: SelectOption[];
    value?: unknown;
  }>;
  values: Record<string, unknown>;
  onChange: (key: string, value: unknown) => void;
  onReset?: () => void;
  onApply?: () => void;
  showApplyButton?: boolean;
}

// Pagination Component Props
export interface PaginationProps extends BaseComponentProps {
  current: number;
  total: number;
  pageSize: number;
  onChange: (page: number, pageSize?: number) => void;
  showSizeChanger?: boolean;
  showQuickJumper?: boolean;
  showTotal?: boolean;
  pageSizeOptions?: number[];
  size?: 'small' | 'default' | 'large';
  simple?: boolean;
  disabled?: boolean;
}

// Loading Component Props
export interface LoadingProps extends BaseComponentProps {
  size?: 'small' | 'default' | 'large';
  spinning?: boolean;
  tip?: string;
  delay?: number;
}

export interface SkeletonProps extends BaseComponentProps {
  active?: boolean;
  avatar?: boolean | { size?: 'small' | 'default' | 'large'; shape?: 'circle' | 'square' };
  loading?: boolean;
  paragraph?: boolean | { rows?: number; width?: string | number | Array<string | number> };
  title?: boolean | { width?: string | number };
}

// Notification Component Props
export interface NotificationProps {
  type: 'success' | 'info' | 'warning' | 'error';
  title: string;
  message?: string;
  duration?: number;
  closable?: boolean;
  onClose?: () => void;
  placement?: 'topLeft' | 'topRight' | 'bottomLeft' | 'bottomRight';
  icon?: ReactNode;
}

export interface AlertProps extends BaseComponentProps {
  type: 'success' | 'info' | 'warning' | 'error';
  message: string;
  description?: string;
  closable?: boolean;
  onClose?: () => void;
  showIcon?: boolean;
  icon?: ReactNode;
  banner?: boolean;
}

// Date/Time Component Props
export interface DatePickerProps extends BaseComponentProps {
  value?: string | Date;
  defaultValue?: string | Date;
  onChange: (date: string | Date | null) => void;
  format?: string;
  placeholder?: string;
  disabled?: boolean;
  readonly?: boolean;
  showTime?: boolean;
  showToday?: boolean;
  disabledDate?: (date: Date) => boolean;
  error?: string;
  label?: string;
  required?: boolean;
  clearable?: boolean;
}

export interface TimePickerProps extends BaseComponentProps {
  value?: string;
  defaultValue?: string;
  onChange: (time: string | null) => void;
  format?: string;
  placeholder?: string;
  disabled?: boolean;
  readonly?: boolean;
  hourStep?: number;
  minuteStep?: number;
  secondStep?: number;
  error?: string;
  label?: string;
  required?: boolean;
  clearable?: boolean;
}

// Layout Component Props
export interface LayoutProps extends BaseComponentProps {
  sidebar?: ReactNode;
  header?: ReactNode;
  footer?: ReactNode;
  breadcrumb?: Array<{
    title: string;
    href?: string;
  }>;
  title?: string;
  subtitle?: string;
  actions?: ReactNode;
  loading?: boolean;
}

export interface PageHeaderProps extends BaseComponentProps {
  title: string;
  subtitle?: string;
  breadcrumb?: Array<{
    title: string;
    href?: string;
  }>;
  actions?: ReactNode;
  extra?: ReactNode;
  back?: boolean | (() => void);
  avatar?: {
    src?: string;
    icon?: ReactNode;
    size?: 'small' | 'default' | 'large';
  };
  tags?: Array<{
    color?: string;
    children: ReactNode;
  }>;
}

// Generic Component Props
export interface ListItemProps<T = Record<string, unknown>> extends BaseComponentProps {
  item: T;
  onEdit?: (item: T) => void;
  onDelete?: (id: string) => void;
  onView?: (id: string) => void;
  selected?: boolean;
  onSelect?: (item: T) => void;
  actions?: Array<{
    label: string;
    onClick: (item: T) => void;
    icon?: ReactNode;
    disabled?: boolean;
  }>;
}

export interface EmptyStateProps extends BaseComponentProps {
  title: string;
  description?: string;
  icon?: ReactNode;
  actions?: ReactNode;
  image?: string;
}

export interface ErrorBoundaryProps extends BaseComponentProps {
  fallback?: ReactNode;
  onError?: (error: Error, errorInfo: Record<string, unknown>) => void;
}

// Hook Return Types
export interface UseTableReturn<T = Record<string, unknown>> {
  data: T[];
  loading: boolean;
  pagination: {
    current: number;
    total: number;
    pageSize: number;
  };
  filters: Record<string, unknown>;
  sorter: {
    field?: string;
    order?: 'asc' | 'desc';
  };
  selectedRows: T[];
  selectedRowKeys: string[];
  handleTableChange: (pagination: unknown, filters: unknown, sorter: unknown) => void;
  handleSelectionChange: (selectedRowKeys: string[], selectedRows: T[]) => void;
  handleFiltersChange: (filters: Record<string, unknown>) => void;
  refresh: () => void;
}

export interface UseFormReturn {
  values: Record<string, unknown>;
  errors: Record<string, string>;
  touched: Record<string, boolean>;
  isSubmitting: boolean;
  isValid: boolean;
  handleChange: (field: string, value: unknown) => void;
  handleBlur: (field: string) => void;
  handleSubmit: (onSubmit: (values: Record<string, unknown>) => void | Promise<void>) => (event: FormEvent) => void;
  setFieldValue: (field: string, value: unknown) => void;
  setFieldError: (field: string, error: string) => void;
  resetForm: () => void;
  validateField: (field: string) => void;
  validateForm: () => void;
}