// Form Types - Form data structures and validation types

import { ReactNode } from 'react';

// Base Form Types
export interface FormField {
  name: string;
  label: string;
  type: 'text' | 'email' | 'password' | 'number' | 'date' | 'datetime-local' | 'time' | 'select' | 'textarea' | 'checkbox' | 'radio' | 'file' | 'hidden';
  required?: boolean;
  placeholder?: string;
  defaultValue?: string | number | boolean;
  value?: string | number | boolean;
  disabled?: boolean;
  readonly?: boolean;
  options?: SelectOption[];
  validation?: FieldValidation;
  className?: string;
  description?: string;
  prefix?: string;
  suffix?: string;
}

export interface SelectOption {
  value: string | number;
  label: string;
  disabled?: boolean;
  group?: string;
}

export interface FieldValidation {
  min?: number;
  max?: number;
  minLength?: number;
  maxLength?: number;
  pattern?: string | RegExp;
  required?: boolean;
  email?: boolean;
  custom?: (value: unknown) => boolean | string;
  message?: string;
}

export interface FormError {
  field: string;
  message: string;
  type?: 'required' | 'pattern' | 'min' | 'max' | 'custom';
}

export interface FormState {
  values: Record<string, unknown>;
  errors: Record<string, string>;
  touched: Record<string, boolean>;
  isSubmitting: boolean;
  isValid: boolean;
}

// Authentication Forms
export interface LoginFormData {
  email: string;
  password: string;
  remember_me?: boolean;
}

export interface RegisterFormData {
  first_name: string;
  last_name: string;
  email: string;
  password: string;
  confirm_password: string;
  phone?: string;
  role?: string;
  speciality?: string;
  terms_accepted: boolean;
}

export interface ResetPasswordFormData {
  email: string;
}

export interface ChangePasswordFormData {
  current_password: string;
  new_password: string;
  confirm_password: string;
}

// Customer Forms
export interface CustomerFormData {
  first_name: string;
  last_name: string;
  email?: string;
  phone?: string;
  city?: string;
  country?: string;
  address?: string;
  notes?: string;
  branch_id?: string;
}

export interface VehicleFormData {
  make: string;
  model: string;
  year: number;
  license_plate: string;
  vin?: string;
  color?: string;
  vehicle_type?: string;
  customer_id?: string;
  notes?: string;
}

// Work Order Forms
export interface WorkOrderFormData {
  customer_id: string;
  vehicle_id: string;
  title: string;
  description?: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  estimated_hours?: number;
  estimated_cost?: number;
  assigned_to?: string[];
  services: WorkOrderServiceFormData[];
  parts: WorkOrderPartFormData[];
  notes?: string;
  internal_notes?: string;
  due_date?: string;
}

export interface WorkOrderServiceFormData {
  name: string;
  description?: string;
  quantity: number;
  unit_price: number;
  estimated_hours?: number;
}

export interface WorkOrderPartFormData {
  name: string;
  part_number?: string;
  quantity: number;
  unit_price: number;
  supplier?: string;
  notes?: string;
}

export interface WorkOrderStageFormData {
  name: string;
  description?: string;
  estimated_hours?: number;
  assigned_to?: string;
  qa_required?: boolean;
  order?: number;
}

// Invoice Forms
export interface InvoiceFormData {
  customer_id: string;
  vehicle_id?: string;
  work_order_id?: string;
  invoice_date: string;
  due_date?: string;
  items: InvoiceItemFormData[];
  subtotal: number;
  tax?: number;
  vat?: number;
  discount?: number;
  total: number;
  notes?: string;
  special_requests?: string;
  payment_terms?: string;
}

export interface InvoiceItemFormData {
  description: string;
  quantity: number;
  unit_price: number;
  amount: number;
}

export interface PaymentFormData {
  invoice_id: string;
  amount: number;
  payment_method: 'cash' | 'card' | 'bank_transfer' | 'check' | 'other';
  payment_date: string;
  reference_number?: string;
  notes?: string;
}

// Expense Forms
export interface ExpenseFormData {
  title: string;
  description?: string;
  amount: number;
  category: string;
  subcategory?: string;
  expense_date: string;
  vendor?: string;
  payment_method?: 'cash' | 'card' | 'bank_transfer' | 'check' | 'other';
  reimbursable?: boolean;
  notes?: string;
  receipt?: File;
  reference_number?: string;
}

export interface ExpenseCategoryFormData {
  name: string;
  description?: string;
  code?: string;
  parent_category?: string;
  active?: boolean;
}

// Staff/User Forms
export interface StaffFormData {
  first_name: string;
  last_name: string;
  email: string;
  phone?: string;
  role: string;
  speciality?: string;
  employee_number?: string;
  branch_id?: string;
  active?: boolean;
  permissions?: string[];
  hire_date?: string;
  hourly_rate?: number;
  daily_rate?: number;
}

export interface PermissionFormData {
  user_id: string;
  permissions: Array<{
    resource: string;
    actions: string[];
  }>;
}

// Case Management Forms
export interface CaseFormData {
  title: string;
  description: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  status?: 'open' | 'in_progress' | 'pending' | 'resolved' | 'closed';
  assigned_to?: string;
  due_date?: string;
  tags?: string[];
  linked_to?: {
    type: string;
    reference: string;
  };
}

export interface CaseNoteFormData {
  case_id: string;
  content: string;
  internal?: boolean;
}

// Payroll Forms
export interface TimesheetFormData {
  employee_id: string;
  work_date: string;
  time_in?: string;
  time_out?: string;
  break_duration?: number;
  total_hours: number;
  overtime_hours?: number;
  notes?: string;
  work_order_ids?: string[];
}

export interface PayrollDeductionFormData {
  employee_id: string;
  deduction_type_id: string;
  amount: number;
  frequency: 'daily' | 'weekly' | 'monthly' | 'per_pay_period' | 'one_time';
  start_date: string;
  end_date?: string;
  max_total_amount?: number;
  notes?: string;
  reference_number?: string;
  legal_required?: boolean;
}

export interface PayPeriodFormData {
  period_name: string;
  description?: string;
  start_date: string;
  end_date: string;
  pay_date: string;
  frequency: 'weekly' | 'bi-weekly' | 'monthly' | 'semi-monthly';
}

// Filter Forms
export interface FilterFormData {
  search?: string;
  date_from?: string;
  date_to?: string;
  status?: string;
  category?: string;
  assigned_to?: string;
  created_by?: string;
  priority?: string;
  [key: string]: string | number | boolean | undefined;
}

// Settings Forms
export interface ProfileFormData {
  first_name: string;
  last_name: string;
  email: string;
  phone?: string;
  avatar?: File;
  timezone?: string;
  language?: string;
  notifications?: {
    email_notifications: boolean;
    sms_notifications: boolean;
    push_notifications: boolean;
  };
}

export interface CompanySettingsFormData {
  company_name: string;
  company_email?: string;
  company_phone?: string;
  company_address?: string;
  tax_number?: string;
  registration_number?: string;
  logo?: File;
  currency?: string;
  timezone?: string;
  date_format?: string;
  time_format?: string;
}

export interface BranchFormData {
  branch_name: string;
  branch_code?: string;
  location: string;
  address?: string;
  phone?: string;
  email?: string;
  manager_id?: string;
  active?: boolean;
}

// File Upload Forms
export interface FileUploadFormData {
  files: File[];
  description?: string;
  category?: string;
  tags?: string[];
}

export interface ImageUploadFormData {
  image: File;
  alt_text?: string;
  caption?: string;
  category?: string;
}

// Search Forms
export interface SearchFormData {
  query: string;
  category?: 'all' | 'customers' | 'vehicles' | 'work_orders' | 'invoices' | 'expenses';
  filters?: Record<string, unknown>;
}

export interface AdvancedSearchFormData {
  query?: string;
  customer_id?: string;
  vehicle_id?: string;
  date_from?: string;
  date_to?: string;
  amount_min?: number;
  amount_max?: number;
  status?: string[];
  category?: string[];
  tags?: string[];
}

// Report Forms
export interface ReportFormData {
  report_type: 'revenue' | 'expenses' | 'customer_analytics' | 'staff_performance' | 'invoice_summary';
  date_from: string;
  date_to: string;
  format: 'pdf' | 'excel' | 'csv';
  filters?: {
    customer_ids?: string[];
    staff_ids?: string[];
    categories?: string[];
    branches?: string[];
  };
  grouping?: 'daily' | 'weekly' | 'monthly';
  include_charts?: boolean;
}

// Dynamic Form Types
export interface DynamicFormConfig {
  title: string;
  description?: string;
  sections: FormSection[];
  submit_button_text?: string;
  cancel_button_text?: string;
  validation_mode?: 'onChange' | 'onBlur' | 'onSubmit';
}

export interface FormSection {
  title?: string;
  description?: string;
  fields: FormField[];
  collapsible?: boolean;
  default_expanded?: boolean;
  conditional?: {
    field: string;
    value: unknown;
    operator?: 'equals' | 'not_equals' | 'greater_than' | 'less_than' | 'contains';
  };
}

// Form Component Props
export interface FormComponentProps {
  initialValues?: Record<string, unknown>;
  onSubmit: (values: Record<string, unknown>) => void | Promise<void>;
  onCancel?: () => void;
  loading?: boolean;
  disabled?: boolean;
  className?: string;
  children?: ReactNode;
}

export interface FieldComponentProps {
  field: FormField;
  value?: unknown;
  error?: string;
  touched?: boolean;
  onChange: (value: unknown) => void;
  onBlur?: () => void;
  className?: string;
}

// Modal Form Types
export interface ModalFormProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  initialData?: Record<string, unknown>;
  onSubmit: (data: Record<string, unknown>) => void | Promise<void>;
  loading?: boolean;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

// Wizard Form Types
export interface WizardStep {
  id: string;
  title: string;
  description?: string;
  fields: FormField[];
  validation?: (values: Record<string, unknown>) => Record<string, string>;
  optional?: boolean;
}

export interface WizardFormData {
  steps: WizardStep[];
  current_step: number;
  values: Record<string, unknown>;
  errors: Record<string, Record<string, string>>;
  completed_steps: string[];
}

// Form Validation Types
export interface ValidationRule {
  type: 'required' | 'email' | 'min' | 'max' | 'pattern' | 'custom';
  value?: string | number | RegExp;
  message: string;
  validator?: (value: unknown, formValues?: Record<string, unknown>) => boolean;
}

export interface ValidationSchema {
  [fieldName: string]: ValidationRule[];
}

export interface ValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
  warnings?: Record<string, string>;
}