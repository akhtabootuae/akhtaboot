export interface ReceiptImage {
  url: string;
  title?: string;
  description?: string;
}

export interface ExpenseRequest {
  description: string;
  amount: number;
  category: string;
  date?: string;
  vendor?: string;
  invoice_number?: string;
  payment_method?: PaymentMethod;
  phone_number?: string;
  tags?: string[];
  notes?: string;
  receipt_images?: ReceiptImage[];
  invoice_image?: File; // Required for new expenses, optional for edits
}

export interface ExpenseResponse {
  _id: string;
  expense_number: string;
  title: string;
  description: string;
  amount: number;
  expense_type: string;
  date: string;
  status: ExpenseStatus;
  approval_status: ApprovalStatus;
  created_by: string;
  branch_id: string;
  vendor?: string;
  invoice_number?: string;
  payment_method?: PaymentMethod;
  phone_number?: string;
  tags?: string[];
  notes?: string;
  receipt_images?: ReceiptImage[];
  invoice_image?: {
    s3Key: string;
    url: string;
    filename: string;
    mimetype: string;
    size: number;
    uploadedAt: string;
    signedUrl?: string;
  };
  approval_notes?: string;
  approved_by?: string;
  approved_at?: string;
  created_at: string;
  updated_at: string;
}

export interface ExpenseDisplayModel {
  id: string;
  expenseNumber: string;
  description: string;
  amount: number;
  category: string;
  categoryLabel: string;
  date: Date;
  status: ExpenseStatus;
  statusLabel: string;
  vendor?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface ExpenseStatistics {
  totalExpenses: number;
  totalAmount: number;
  pendingApproval: number;
  pendingAmount: number;
  approvedExpenses: number;
  approvedAmount: number;
  rejectedExpenses: number;
  rejectedAmount: number;
  byCategory: {
    [key: string]: {
      count: number;
      amount: number;
    };
  };
  byStatus: {
    [key: string]: {
      count: number;
      amount: number;
    };
  };
  monthlyTrend: {
    month: string;
    amount: number;
    count: number;
  }[];
}

export type ExpenseStatus = 'draft' | 'submitted' | 'approved' | 'rejected' | 'paid';

export type ApprovalStatus = 'pending' | 'approved' | 'rejected';

export type PaymentMethod = 'cash' | 'card' | 'bank_transfer' | 'check' | 'petty_cash' | 'digital_wallet' | 'other';

export type ExpenseType = 
  | 'office_supplies' 
  | 'equipment' 
  | 'utilities' 
  | 'rent' 
  | 'maintenance' 
  | 'fuel' 
  | 'travel' 
  | 'meals' 
  | 'marketing' 
  | 'insurance' 
  | 'professional_services' 
  | 'software_licenses' 
  | 'telecommunications' 
  | 'training' 
  | 'repairs' 
  | 'inventory' 
  | 'external_service'
  | 'miscellaneous';

export const EXPENSE_TYPES: { value: ExpenseType; label: string; icon: string }[] = [
  { value: 'office_supplies', label: 'Office Supplies', icon: '📎' },
  { value: 'equipment', label: 'Equipment', icon: '🖥️' },
  { value: 'utilities', label: 'Utilities', icon: '⚡' },
  { value: 'rent', label: 'Rent', icon: '🏢' },
  { value: 'maintenance', label: 'Maintenance', icon: '🔧' },
  { value: 'fuel', label: 'Fuel', icon: '⛽' },
  { value: 'travel', label: 'Travel', icon: '✈️' },
  { value: 'meals', label: 'Meals', icon: '🍽️' },
  { value: 'marketing', label: 'Marketing', icon: '📢' },
  { value: 'insurance', label: 'Insurance', icon: '🛡️' },
  { value: 'professional_services', label: 'Professional Services', icon: '👔' },
  { value: 'software_licenses', label: 'Software Licenses', icon: '💻' },
  { value: 'telecommunications', label: 'Telecommunications', icon: '📞' },
  { value: 'training', label: 'Training', icon: '📚' },
  { value: 'repairs', label: 'Repairs', icon: '🔨' },
  { value: 'inventory', label: 'Inventory', icon: '📦' },
  { value: 'external_service', label: 'External Service', icon: '🔗' },
  { value: 'miscellaneous', label: 'Miscellaneous', icon: '📋' },
];

export const EXPENSE_STATUSES: { value: ExpenseStatus; label: string; color: string; icon: string }[] = [
  { value: 'draft', label: 'Draft', color: 'gray', icon: '📝' },
  { value: 'submitted', label: 'Submitted', color: 'blue', icon: '📤' },
  { value: 'approved', label: 'Approved', color: 'green', icon: '✅' },
  { value: 'rejected', label: 'Rejected', color: 'red', icon: '❌' },
  { value: 'paid', label: 'Paid', color: 'purple', icon: '💰' },
];

export const APPROVAL_STATUSES: { value: ApprovalStatus; label: string; color: string; icon: string }[] = [
  { value: 'pending', label: 'Pending', color: 'yellow', icon: '⏳' },
  { value: 'approved', label: 'Approved', color: 'green', icon: '✅' },
  { value: 'rejected', label: 'Rejected', color: 'red', icon: '❌' },
];

export const PAYMENT_METHODS: { value: PaymentMethod; label: string }[] = [
  { value: 'cash', label: 'Cash' },
  { value: 'card', label: 'Card/Debit' },
];

// Keep the full list for other parts of the app that might need it
export const ALL_PAYMENT_METHODS: { value: PaymentMethod; label: string }[] = [
  { value: 'cash', label: 'Cash' },
  { value: 'card', label: 'Card' },
  { value: 'bank_transfer', label: 'Bank Transfer' },
  { value: 'check', label: 'Check' },
  { value: 'petty_cash', label: 'Petty Cash' },
  { value: 'digital_wallet', label: 'Digital Wallet' },
  { value: 'other', label: 'Other' },
];

// Helper functions
export const getStatusDisplay = (status: ExpenseStatus) => {
  return EXPENSE_STATUSES.find(s => s.value === status) || { 
    value: status, 
    label: status, 
    color: 'gray', 
    icon: '❓' 
  };
};

export const getApprovalStatusDisplay = (status: ApprovalStatus) => {
  return APPROVAL_STATUSES.find(s => s.value === status) || { 
    value: status, 
    label: status, 
    color: 'gray', 
    icon: '❓' 
  };
};

export const getCategoryDisplay = (category: string) => {
  return EXPENSE_TYPES.find(t => t.value === category) || { 
    value: category, 
    label: category, 
    icon: '📋' 
  };
};

export const getPaymentMethodDisplay = (paymentMethod: string) => {
  const method = PAYMENT_METHODS.find(m => m.value === paymentMethod);
  return method ? method.label : paymentMethod.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
};

export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('en-AE', {
    style: 'currency',
    currency: 'AED',
  }).format(amount);
};

export const formatDate = (date: string | Date): string => {
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  }).format(new Date(date));
};
