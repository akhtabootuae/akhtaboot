export type NotificationType = 
  | "time_alert" 
  | "deadline_warning" 
  | "status_change" 
  | "assignment" 
  | "general";

export type NotificationPriority = "low" | "medium" | "high" | "urgent";

export type NotificationStatus = "undone" | "done" | "archived";

export type RecipientType = "supervisor" | "technician" | "owner" | "admin" | "all";

export interface Notification {
  _id: string;
  type: NotificationType;
  title: string;
  message: string;
  workOrderId?: string;
  stageId?: string;
  employeeId?: string;
  timesheetId?: string;
  deductionId?: string;
  recipientType?: RecipientType;
  recipientId?: string;
  priority: NotificationPriority;
  status: NotificationStatus;
  percentComplete?: number;
  metadata?: Record<string, unknown>;
  createdAt: string;
  readAt?: string;
  expiresAt?: string;
}

export interface NotificationStats {
  total: number;
  undone: number;
  highPriority: number;
}