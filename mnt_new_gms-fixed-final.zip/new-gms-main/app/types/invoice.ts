export interface PaymentRecord {
  payment_date: Date;
  amount: number;
  payment_method: string;
  reference_number?: string;
  notes?: string;
}

export interface InvoiceImage {
  url: string;
  added_at: Date;
  description?: string;
}

export interface VehicleInfo {
  make?: string;
  model?: string;
  year?: number;
  license_plate?: string;
  vin?: string;
  color?: string;
  vehicle_type?: string;
  vehicle_id?: number | string;
  created_at?: Date | string;
  updated_at?: Date | string;
  [key: string]: unknown; // Allow additional fields from API
}

export interface CustomerInfo {
  _id: string;
  name?: string;  // Full name or business name
  first_name?: string;
  last_name?: string;
  phone?: string;
  email?: string;
  city?: string;
  country?: string;
  status?: string;
  branch?: {
    branch_id?: string;
    branch_name?: string;
    branch_code?: string;
    location?: string;
  };
  vehicles?: VehicleInfo[];
  [key: string]: unknown; // Allow additional fields from API
}

export interface Invoice {
  _id: string;
  invoice_number: string;
  customer_id: string;
  customer_info: CustomerInfo;
  vehicle_info: VehicleInfo;
  work_order_id?: string;  // Added work order ID field
  invoice_date: Date;
  due_date?: Date;
  items: Array<{
    description: string;
    quantity: number;
    unit_price: number;
    amount: number;
  }>;
  subtotal: number;
  tax?: number;
  vat?: number;  // Added VAT field
  discount?: number;
  total: number;
  price?: number;  // Added price field
  payment_records?: PaymentRecord[];
  payment_status: 'Paid' | 'Partially Paid' | 'Unpaid';
  notes?: string;
  special_requests?: string;  // Added special requests field
  images?: InvoiceImage[];
  created_at: Date;
  updated_at: Date;
  
  // Additional fields for compatibility with API response
  [key: string]: unknown;  // Allow additional fields from the API
}

export interface InvoiceFilters {
  search?: string;
  payment_status?: string;
  date_from?: string;
  date_to?: string;
  customer_id?: string;
}
