export type ConversationType = 'private' | 'group' | 'announcement';
export type MessageType = 'text' | 'announcement' | 'image' | 'voice_note';

export interface Participant {
  _id: string;
  user_id: string;
  name: string;
  email: string;
  role?: string;
  branch?: {
    branch_id: string;
    branch_name: string;
  };
  joined_at: string;
}

export interface Message {
  _id: string;
  conversation_id: string;
  sender_id: string;
  sender_name: string;
  sender_role?: string;
  content: string;
  message_type: MessageType;
  created_at: string;
  updated_at: string;
  
  // Media message fields
  file_id?: string;
  original_name?: string;
  mime_type?: string;
  file_size?: number;
  s3_key?: string;
  signed_url?: string;
  duration?: number; // For voice notes (seconds)
}

export interface Conversation {
  _id: string;
  type: ConversationType;
  title: string;
  description?: string;
  participants: Participant[];
  created_by: string;
  created_at: string;
  updated_at: string;
  last_message?: {
    content: string;
    sender_name: string;
    created_at: string;
  };
  unread_count?: number;
  expiresAt?: string; // ISO string, optional, for announcements
}

export interface ConversationResponse {
  success: boolean;
  conversations: Conversation[];
  total_count: number;
  current_page: number;
  total_pages: number;
}

export interface MessagesResponse {
  success: boolean;
  messages: Message[];
  conversation: Conversation;
  total_count: number;
  current_page: number;
  total_pages: number;
}

export interface UserSearchResult {
  _id: string;
  name: string;
  email: string;
  role_name: string;
  branch?: {
    branch_id: string;
    branch_name: string;
  };
}

export interface UserSearchResponse {
  success: boolean;
  users: UserSearchResult[];
  total_count: number;
}

export interface CreateConversationRequest {
  recipient_id?: string; // For private conversations
  title?: string; // For group conversations
  participant_ids?: string[]; // For group conversations
  description?: string; // For announcements
}

export interface SendMessageRequest {
  content: string;
  message_type?: MessageType;
}

export interface MessageFormData {
  content: string;
  message_type: MessageType;
}

export interface ConversationFormData {
  type: ConversationType;
  title: string;
  description?: string;
  selectedUsers: UserSearchResult[];
}
