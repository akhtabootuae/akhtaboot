// Finance API Types
export interface FinanceFilters {
  start_date?: string;
  end_date?: string;
  branch_id?: string;
  expense_type?: string;
}

export interface RevenueData {
  total_invoices: number;
  total_revenue: number;
  total_revenue_before_vat: number;
  total_vat_amount: number;
  average_invoice_value: number;
  total_paid: number;
  outstanding_amount: number;
}

export interface ExpenseData {
  summary: {
    total_expenses: number;
    total_amount: number;
    average_expense: number;
  };
  by_category: Array<{
    _id: string;
    total_amount: number;
    count: number;
    average_amount: number;
  }>;
}

export interface PayrollData {
  employee_count: number;
  total_gross_pay: number;
  total_deductions: number;
  total_net_pay: number;
  total_regular_pay: number;
  total_overtime_pay: number;
  total_hours: number;
  total_overtime_hours: number;
  average_gross_pay: number;
  average_net_pay: number;
}

export interface ProfitLossData {
  period_summary: {
    total_revenue: number;
    total_paid: number;
    outstanding_amount: number;
    total_expenses: number;
    total_payroll_costs: number;
    total_costs: number;
    gross_profit: number;
    net_profit: number;
    profit_margin: number;
    net_profit_margin: number;
  };
  revenue_breakdown: {
    total_invoices: number;
    total_revenue: number;
    average_invoice_value: number;
  };
  expense_breakdown: {
    summary: {
      total_expenses: number;
      total_amount: number;
    };
    by_category: Array<{
      _id: string;
      total_amount: number;
      count: number;
    }>;
  };
  payroll_breakdown: {
    employee_count: number;
    total_gross_pay: number;
  };
}

export interface CashFlowData {
  cash_inflows: {
    total: number;
    from_invoices: number;
    pending_receivables: number;
  };
  cash_outflows: {
    total: number;
    expenses: number;
    payroll: number;
  };
  net_cash_flow: number;
  cash_flow_ratio: number;
}

export interface FinancialSummary {
  period: {
    start_date: string;
    end_date: string;
    branch_id: string;
  };
  key_metrics: {
    total_revenue: number;
    total_expenses: number;
    total_payroll: number;
    gross_profit: number;
    net_profit: number;
    profit_margin: number;
    cash_flow: number;
  };
  revenue_breakdown: RevenueData;
  expense_breakdown: ExpenseData['by_category'];
  payroll_summary: {
    employee_count: number;
    total_gross_pay: number;
    total_net_pay: number;
    average_salary: number;
  };
  cash_flow_summary: CashFlowData;
}

export interface BranchMetrics {
  branch: {
    id: string;
    name: string;
    code: string;
  };
  metrics: {
    revenue: number;
    expenses: number;
    profit: number;
    profit_margin: number;
    invoice_count: number;
    expense_count: number;
  };
}

export interface BranchComparison {
  comparison_period: {
    start_date: string;
    end_date: string;
  };
  branches: BranchMetrics[];
  totals: {
    total_revenue: number;
    total_expenses: number;
    total_profit: number;
    branch_count: number;
  };
}

export interface FinanceDashboard {
  current_period: {
    period_summary: {
      total_revenue: number;
      gross_profit: number;
      profit_margin: number;
    };
  };
  previous_period: {
    period_summary: {
      total_revenue: number;
      gross_profit: number;
      profit_margin: number;
    };
  };
  growth_metrics: {
    revenue_growth: number;
    profit_growth: number;
    expense_growth: number;
  };
}

export interface FinanceApiResponse<T> {
  success: boolean;
  data: T;
  filters?: FinanceFilters;
  message?: string;
  error?: string;
}
