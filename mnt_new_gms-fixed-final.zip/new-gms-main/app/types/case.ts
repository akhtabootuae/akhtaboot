// Case Management Types

export type CaseStatus = 'open' | 'in-progress' | 'pending' | 'resolved' | 'closed';
export type CasePriority = 'low' | 'medium' | 'high' | 'urgent';

export interface LinkedEntity {
  type: string;
  reference?: string;
}

export interface CaseNote {
  content: string;
  addedAt: Date;
}

export interface CaseAttachment {
  filename: string;
  uploadedAt: Date;
}

export interface Case {
  _id: string;
  title: string;
  description: string;
  status: CaseStatus;
  priority: CasePriority;
  linkedTo?: LinkedEntity;
  createdBy: string;
  assignedTo?: string;
  resolvedBy?: string;
  notes: CaseNote[];
  attachments: CaseAttachment[];
  tags: string[];
  dueDate?: Date;
  resolvedAt?: Date;
  closedAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface CaseFilters {
  page?: number;
  limit?: number;
  status?: CaseStatus;
  priority?: CasePriority;
  createdBy?: string;
  assignedTo?: string;
  linkedType?: string;
  linkedId?: string;
  tags?: string[];
  search?: string;
  dateFrom?: string;
  dateTo?: string;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
  overdue?: boolean;
  dueToday?: boolean;
}

export interface CreateCaseData {
  title: string;
  description: string;
  priority?: CasePriority;
  status?: CaseStatus;
  linkedTo?: LinkedEntity;
  assignedTo?: string;
  tags?: string[];
  dueDate?: string;
}

export interface UpdateCaseData {
  title?: string;
  description?: string;
  priority?: CasePriority;
  status?: CaseStatus;
  linkedTo?: LinkedEntity;
  assignedTo?: string;
  tags?: string[];
  dueDate?: string;
}

export interface CaseStats {
  total: number;
  open: number;
  inProgress: number;
  pending: number;
  resolved: number;
  closed: number;
  urgent: number;
  high: number;
  medium: number;
  low: number;
  overdue: number;
  dueToday: number;
}

export interface CaseListResponse {
  success: boolean;
  message: string;
  data: Case[];
  pagination: {
    currentPage: number;
    totalPages: number;
    totalItems: number;
    hasPrevPage: boolean;
    hasNextPage: boolean;
  };
}

export interface CaseDetailResponse {
  success: boolean;
  message: string;
  data: Case;
}

export interface CaseStatsResponse {
  success: boolean;
  message: string;
  data: CaseStats;
}
