export interface ExpenseLog {
  _id: string;
  user_id: string;
  user_email: string;
  action: string;
  entity_type: string;
  entity_id?: string;
  ip_address: string;
  user_agent?: string;
  timestamp: string;
  details: Record<string, any>;
  severity: 'low' | 'medium' | 'high';
  category: string;
  branch_id?: string;
}

export interface ExpenseLogStatistics {
  total_logs: number;
  unique_users: number;
  action_breakdown: Array<{ action: string; count: number }>;
  severity_breakdown: Array<{ severity: string; count: number }>;
  category_breakdown: Array<{ category: string; count: number }>;
  average_logs_per_day: number;
  peak_activity_hour: number;
  most_active_user: {
    user_id: string;
    user_email: string;
    log_count: number;
  };
}

export interface ExpenseLogFilters {
  user_id?: string;
  action?: string;
  entity_id?: string;
  start_date?: string;
  end_date?: string;
  severity?: string;
  category?: string;
  branch_id?: string;
}

export interface ExpenseLogPagination {
  current_page: number;
  total_pages: number;
  total_logs: number;
  per_page: number;
  has_next_page: boolean;
  has_prev_page: boolean;
}

export interface RecentActivityResponse {
  period_hours: number;
  activity_count: number;
  recent_activity: ExpenseLog[];
}

export interface UserLogsResponse {
  user_id: string;
  logs: ExpenseLog[];
  pagination: ExpenseLogPagination;
}

export interface DashboardResponse {
  period: {
    start_date: string;
    end_date: string;
    days: number;
  };
  recent_activity: ExpenseLog[];
  statistics: ExpenseLogStatistics;
  breakdowns: {
    by_action: Array<{ _id: string; count: number }>;
    by_severity: Array<{ _id: string; count: number }>;
    daily_trend: Array<{ _id: string; count: number }>;
  };
}

export interface ActiveUsersResponse {
  period_days: number;
  active_users: Array<{
    user_id: string;
    user_email: string;
    activity_count: number;
    last_activity: string;
  }>;
}

export interface TimelineResponse {
  expense_id: string;
  expense_number: string;
  timeline: ExpenseLog[];
}

export interface TrendsResponse {
  daily_activity: Array<{ date: string; count: number }>;
  action_trends: Array<{ action: string; trend: 'increasing' | 'decreasing' | 'stable' }>;
  severity_distribution: Array<{ severity: string; count: number }>;
  category_growth: Array<{ category: string; growth_rate: number }>;
}

export interface UserSummaryResponse {
  user_id: string;
  period_days: number;
  total_actions: number;
  actions_by_type: Array<{ action: string; count: number }>;
  activity_by_day: Array<{ date: string; count: number }>;
  most_active_hours: Array<{ hour: number; count: number }>;
  severity_breakdown: Array<{ severity: string; count: number }>;
}

export interface ExportResponse {
  export_info: {
    total_records: number;
    export_date: string;
    filters: ExpenseLogFilters;
  };
  logs: ExpenseLog[];
}

export interface CleanupResponse {
  message: string;
  deleted_count: number;
  cutoff_date: string;
  days_kept: number;
}

export interface SearchResponse {
  search_term: string;
  filters: ExpenseLogFilters;
  results: ExpenseLog[];
  pagination: {
    current_page: number;
    per_page: number;
    result_count: number;
  };
}
