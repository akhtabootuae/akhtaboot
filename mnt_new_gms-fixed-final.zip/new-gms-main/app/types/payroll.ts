// Payroll system type definitions

export interface PayrollEmployee {
  employee_id: string;
  _id?: string; // Keep for backward compatibility
  first_name: string;
  last_name: string;
  email: string;
  speciality?: string;
  employee_number?: string; // From the API docs, this might be at the top level
  branch: {
    branch_id: string;
    branch_name: string;
    branch_code: string;
  };
  payroll_info: {
    payroll_eligible: boolean;
    monthly_salary?: number; // NEW - optional for backward compatibility
    current_daily_rate?: number; // OLD - keep for backward compatibility
    employee_number: string;
    hire_date: string | null;
    employment_type?: string;
    last_pay_date: string | null;
    last_rate_update?: string | null;
    updated_by?: string;
  };
  // Keep old fields for backward compatibility
  current_rate?: number;
  rate_effective_date?: string;
}

// PayrollRate interface removed - no longer used in monthly salary system

// PayrollRateHistory interface removed - no longer used in monthly salary system

export interface PayrollAuditLog {
  _id: string;
  user_id: string;
  user_email: string;
  action: string;
  entity_type: string;
  entity_id: string | null;
  timestamp: string;
  ip_address: string;
  user_agent: string;
  details: Record<string, unknown>;
  severity: string;
  category: string;
}

export interface UpdateSalaryData {
  monthly_salary: number;
  reason?: string;
}

// NEW: Overtime Expense Integration
export interface OvertimeExpense {
  _id: string;
  title: string;
  description: string;
  amount: number;
  expense_type: 'overtime_compensation';
  date: string;
  vendor: string;
  notes: string;
  timesheet_id: string;
  target_employee_id: string;
  status: 'pending' | 'approved' | 'paid' | 'rejected';
  created_at: string;
  updated_at: string;
}

export interface PayrollApiResponse<T> {
  message: string;
  data: T;
  total_count?: number;
  pagination?: {
    current_page: number;
    total_pages: number;
    total_count: number;
    has_next: boolean;
    has_prev: boolean;
  };
}

// Phase 2: Variable Deductions System Types

export interface PayrollDeductionType {
  _id: string;
  name: string;
  description?: string;
  type: 'fixed_amount' | 'percentage' | 'conditional';
  default_amount?: number | null;
  default_percentage?: number | null;
  frequency: 'daily' | 'weekly' | 'monthly' | 'per_pay_period' | 'one_time';
  max_percentage_of_pay?: number | null;
  requires_approval: boolean;
  is_system_type: boolean;
  active: boolean;
  created_at: string;
  updated_at: string;
}

export interface PayrollEmployeeDeduction {
  _id: string;
  employee_id: string;
  deduction_type_id: string;
  deduction_type?: PayrollDeductionType;
  employee?: {
    _id: string;
    first_name: string;
    last_name: string;
    email: string;
  };
  amount: number;
  frequency: 'daily' | 'weekly' | 'monthly' | 'per_pay_period' | 'one_time';
  start_date: string;
  end_date?: string | null;
  status: 'active' | 'paused' | 'completed' | 'cancelled' | 'pending_approval';
  priority?: number;
  max_total_amount?: number | null;
  total_deducted: number;
  remaining_balance?: number | null;
  notes?: string;
  reference_number?: string;
  legal_required?: boolean;
  created_by: string;
  created_by_user?: {
    _id: string;
    first_name: string;
    last_name: string;
  };
  approved_by?: string | null;
  approved_at?: string | null;
  created_at: string;
  updated_at: string;
}

export interface PayrollDeductionHistory {
  _id: string;
  employee_deduction_id: string;
  employee_id: string;
  pay_period_start: string;
  pay_period_end: string;
  gross_pay_amount?: number;
  amount_deducted: number;
  reason_for_variance?: string;
  remaining_balance_after?: number | null;
  processed_by?: string;
  processed_at: string;
  deduction?: PayrollEmployeeDeduction;
  deduction_type?: PayrollDeductionType;
  employee?: {
    _id: string;
    full_name: string;
    email: string;
    staff_code: string;
  };
  processed_by_user?: {
    _id: string;
    full_name: string;
    email: string;
  };
}

export interface DeductionHistoryResponse {
  message: string;
  history: PayrollDeductionHistory[];
  pagination: {
    current_page: number;
    total_pages: number;
    total_records: number;
    limit: number;
  };
  filters: {
    start_date?: string;
    end_date?: string;
    employee_id?: string;
    deduction_type_id?: string;
  };
}

export interface CreateDeductionData {
  deduction_type_id: string;
  amount: number;
  frequency: 'daily' | 'weekly' | 'monthly' | 'per_pay_period' | 'one_time';
  start_date: string;
  end_date?: string;
  priority?: number;
  max_total_amount?: number;
  notes?: string;
  reference_number?: string;
  legal_required?: boolean;
}

export interface UpdateDeductionData {
  amount?: number;
  frequency?: 'daily' | 'weekly' | 'monthly' | 'per_pay_period' | 'one_time';
  start_date?: string;
  end_date?: string;
  priority?: number;
  max_total_amount?: number;
  notes?: string;
  reference_number?: string;
  legal_required?: boolean;
}

export interface DeductionSummary {
  _id: string;
  total_deducted: number;
  deduction_count: number;
  deduction_type: PayrollDeductionType;
}

// Phase 3: Attendance & Pay Calculation Types

export interface PayrollTimeSheet {
  _id: string;
  employee_id?: string;
  employee?: {
    first_name: string;
    last_name: string;
    email: string;
    speciality?: string;
    branch?: {
      branch_name: string;
    };
  };
  work_date: string;
  date?: string; // Keep for backward compatibility
  time_in?: string;
  time_out?: string;
  break_duration?: number; // in minutes
  status: 'draft' | 'submitted' | 'approved' | 'rejected';
  check_in_time?: string; // Keep for backward compatibility
  check_out_time?: string; // Keep for backward compatibility
  break_start_time?: string; // Keep for backward compatibility
  break_end_time?: string; // Keep for backward compatibility
  total_hours: number; // Only field for hours - no pay calculations
  work_order_ids?: string[];
  notes?: string;
  approved_by?: string;
  approved_at?: string;
  created_by?: string;
  created_at?: string;
  updated_at?: string;
}

export interface PayrollPayPeriod {
  _id: string;
  name?: string; // Keep for backward compatibility
  period_name: string; // Primary field from backend
  description?: string;
  start_date: string;
  end_date: string;
  pay_date: string;
  frequency: 'weekly' | 'bi-weekly' | 'monthly' | 'semi-monthly';
  year: number;
  period_number?: number;
  status: 'draft' | 'open' | 'processing' | 'calculated' | 'approved' | 'paid' | 'closed';
  total_employees?: number;
  total_gross_pay?: number;
  total_deductions?: number;
  total_net_pay?: number;
  calculated_by?: string;
  calculated_at?: string;
  approved_by?: string;
  approved_at?: string;
  created_by: string;
  created_at: string;
  updated_at?: string;
  updated_by?: string;
}

export interface PayrollCalculation {
  _id: string;
  employee_id: string;
  employee?: {
    first_name: string;
    last_name: string;
    email: string;
    speciality: string;
  };
  pay_period_id: string;
  pay_period?: {
    name: string;
    start_date: string;
    end_date: string;
  };
  status: 'calculating' | 'calculated' | 'approved' | 'paid' | 'error';
  monthly_salary: number; // NEW
  days_worked: number; // Attendance tracking
  gross_pay: number; // Equal to monthly_salary
  total_deductions?: number;
  net_pay?: number;
  deductions_breakdown?: Array<{
    deduction_id: string;
    deduction_name: string;
    amount: number;
    remaining_balance?: number;
  }>;
  attendance_summary?: Array<{
    date: string;
    status: string;
    hours_worked?: number;
  }>;
  calculation_notes?: string;
  error_message?: string;
  calculated_by?: string;
  calculated_at?: string;
  approved_by?: string;
  approved_at?: string;
  created_by: string;
  created_at: string;
  updated_at?: string;
}

export interface CreateTimeSheetData {
  employee_id: string;
  date: string;
  status: 'present' | 'absent' | 'half_day' | 'sick_leave' | 'vacation' | 'unpaid_leave' | 'holiday';
  check_in_time?: string;
  check_out_time?: string;
  break_start_time?: string;
  break_end_time?: string;
  notes?: string;
}

export interface UpdateTimeSheetData {
  status?: 'present' | 'absent' | 'half_day' | 'sick_leave' | 'vacation' | 'unpaid_leave' | 'holiday';
  check_in_time?: string;
  check_out_time?: string;
  break_start_time?: string;
  break_end_time?: string;
  notes?: string;
}

export interface CreatePayPeriodData {
  name: string;
  description?: string;
  start_date: string;
  end_date: string;
  pay_date?: string;
}

export interface AttendanceSummary {
  total_days: number;
  present_days: number;
  absent_days: number;
  sick_leave_days: number;
  vacation_days: number;
  attendance_rate: number;
  total_hours: number;
  overtime_hours: number;
  by_employee?: Array<{
    employee_id: string;
    employee_name: string;
    present_days: number;
    total_hours: number;
  }>;
}

// Phase 4: Reporting & Paystubs Types

export interface PayStub {
  _id: string;
  employee_id: string;
  employee?: {
    first_name: string;
    last_name: string;
    email: string;
    employee_number?: string;
  };
  pay_period_id: string;
  pay_period?: {
    name: string;
    start_date: string;
    end_date: string;
    pay_date: string;
  };
  calculation_id: string;
  gross_pay: number;
  total_deductions: number;
  net_pay: number;
  earnings_breakdown: Array<{
    type: 'base_pay' | 'overtime_pay' | 'bonus' | 'allowance';
    description: string;
    amount: number;
  }>;
  deductions_breakdown: Array<{
    type: string;
    description: string;
    amount: number;
  }>;
  year_to_date_totals: {
    gross_pay: number;
    total_deductions: number;
    net_pay: number;
  };
  status: 'generated' | 'sent' | 'viewed' | 'downloaded';
  generated_at: string;
  sent_at?: string;
  viewed_at?: string;
  downloaded_at?: string;
  created_by: string;
  created_at: string;
}

export interface PayrollReport {
  _id: string;
  name: string;
  type: 'payroll_summary' | 'employee_earnings' | 'deductions_summary' | 'attendance_report' | 'tax_report';
  period_type: 'weekly' | 'bi_weekly' | 'monthly' | 'quarterly' | 'yearly' | 'custom';
  start_date: string;
  end_date: string;
  filters?: {
    employee_ids?: string[];
    departments?: string[];
    branches?: string[];
  };
  data: Record<string, unknown>; // Report-specific data structure
  status: 'generating' | 'completed' | 'error';
  file_path?: string;
  generated_by: string;
  generated_at: string;
  expires_at?: string;
}

// Phase 5: Advanced Features Types

export interface PayrollAlert {
  _id: string;
  type: 'missing_timesheet' | 'calculation_error' | 'approval_required' | 'payment_due' | 'compliance_issue';
  severity: 'low' | 'medium' | 'high' | 'critical';
  title: string;
  message: string;
  related_entity_type: 'employee' | 'pay_period' | 'calculation' | 'deduction';
  related_entity_id: string;
  actions?: Array<{
    label: string;
    action: string;
    url?: string;
  }>;
  acknowledged: boolean;
  acknowledged_by?: string;
  acknowledged_at?: string;
  resolved: boolean;
  resolved_by?: string;
  resolved_at?: string;
  created_at: string;
  expires_at?: string;
}

export interface PayrollBudget {
  _id: string;
  name: string;
  period_type: 'monthly' | 'quarterly' | 'yearly';
  start_date: string;
  end_date: string;
  total_budget: number;
  allocated_amounts: {
    base_salaries: number;
    overtime: number;
    bonuses: number;
    benefits: number;
    taxes: number;
  };
  actual_spending: {
    base_salaries: number;
    overtime: number;
    bonuses: number;
    benefits: number;
    taxes: number;
  };
  variance: {
    amount: number;
    percentage: number;
  };
  status: 'active' | 'completed' | 'exceeded';
  created_by: string;
  created_at: string;
  updated_at?: string;
}

export interface PayrollIntegration {
  _id: string;
  name: string;
  type: 'accounting' | 'banking' | 'hr_system' | 'time_tracking' | 'benefits';
  provider: string;
  status: 'active' | 'inactive' | 'error' | 'syncing';
  configuration: {
    api_endpoint?: string;
    authentication_type: 'api_key' | 'oauth' | 'basic_auth';
    sync_frequency: 'real_time' | 'hourly' | 'daily' | 'weekly';
    last_sync?: string;
    next_sync?: string;
  };
  mapping: {
    field_mappings: Array<{
      local_field: string;
      external_field: string;
      data_type: string;
    }>;
  };
  created_by: string;
  created_at: string;
  updated_at?: string;
}