'use client';

import Image from "next/image";
import { useAuth } from "./context/AuthContext";
import { useEffect } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import AdminDashboard from "./components/Dashboard/AdminDashboard";
import SupervisorDashboard from "./components/Dashboard/SupervisorDashboard";

export default function Home() {
  const { isAuthenticated, user, isLoading } = useAuth();
  const router = useRouter();

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.push('/login');
    }
  }, [isAuthenticated, isLoading, router]);

  // Show loading state while checking auth
  if (isLoading) {
    return (
      <div className="flex h-full items-center justify-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  // Show appropriate dashboard for authenticated users based on role
  if (isAuthenticated && user) {
    // Check user role and render appropriate dashboard
    const userRole = user.role_name?.toLowerCase();
    
    if (userRole === 'admin') {
      return <AdminDashboard user={user} />;
    } else if (userRole === 'supervisor') {
      return <SupervisorDashboard user={user} />;
    } else {
      // For other roles (staff, etc.), show a default view or redirect
      return (
        <div className="p-6 max-w-7xl mx-auto space-y-6">
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="text-center">
              <h1 className="text-3xl font-bold text-gray-900 mb-4">Welcome to GMS</h1>
              <p className="text-gray-600 mb-2">Welcome back, {user.name}</p>
              <p className="text-sm text-gray-500 mb-6">
                {user.role_name} • {user.branch?.branch_name || 'No branch assigned'}
              </p>
              <div className="space-y-4">
                <p className="text-gray-600">Your dashboard is being prepared.</p>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  <Link href="/workOrders" className="block">
                    <div className="bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg p-4 transition-colors">
                      <div className="text-blue-600 text-2xl mb-2">🔧</div>
                      <h3 className="font-semibold text-blue-900">Work Orders</h3>
                      <p className="text-sm text-blue-700">View and manage work orders</p>
                    </div>
                  </Link>
                  <Link href="/notifications" className="block">
                    <div className="bg-yellow-50 hover:bg-yellow-100 border border-yellow-200 rounded-lg p-4 transition-colors">
                      <div className="text-yellow-600 text-2xl mb-2">🔔</div>
                      <h3 className="font-semibold text-yellow-900">Notifications</h3>
                      <p className="text-sm text-yellow-700">Check your notifications</p>
                    </div>
                  </Link>
                  <Link href="/Invoices" className="block">
                    <div className="bg-green-50 hover:bg-green-100 border border-green-200 rounded-lg p-4 transition-colors">
                      <div className="text-green-600 text-2xl mb-2">📄</div>
                      <h3 className="font-semibold text-green-900">Invoices</h3>
                      <p className="text-sm text-green-700">View invoices</p>
                    </div>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      );
    }
  }

  // For unauthenticated users
  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-8">
      <div className="text-center max-w-md">
        <Image
          src="/Final-logo.webp"
          alt="GMS Logo"
          width={180}
          height={180}
          priority
          className="mx-auto mb-8"
        />
        
        <h1 className="text-3xl font-bold mb-6">Garage Management System</h1>
        
        <div className="bg-blue-50 border border-blue-200 text-blue-700 px-6 py-4 rounded-md mb-8">
          <p className="mb-4">
            Please <Link href="/login" className="text-blue-600 font-semibold hover:underline">sign in</Link> to access the dashboard.
          </p>
          <p>
            Contact your administrator if you need an account.
          </p>
        </div>
        
        <Link 
          href="/login"
          className="inline-block bg-blue-600 text-white font-medium px-6 py-3 rounded-md hover:bg-blue-700 transition-colors"
        >
          Go to Login
        </Link>
      </div>
    </div>
  );
}
