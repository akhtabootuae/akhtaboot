'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import ProtectedRoute from '@/components/ProtectedRoute';
import { Card } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Badge } from '@/app/components/ui/badge';
import { 
  Shield,
  Clock,
  User,
  FileText,
  Download,
  Search,
  Filter,
  Calendar,
  AlertTriangle,
  Info,
  CheckCircle,
  XCircle,
  Activity,
  TrendingUp,
  Users,
  Database
} from 'lucide-react';
import { caseApi } from '@/services/api';
import { useAuth } from '@/app/context/AuthContext';
import toast from 'react-hot-toast';

interface CaseLog {
  _id: string;
  user_id: string;
  user_email: string;
  action: string;
  entity_type: string;
  entity_id: string;
  details: any;
  timestamp: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  category: string;
  success: boolean;
  ip_address?: string;
  user_agent?: string;
}

interface DashboardData {
  period: {
    start_date: string;
    end_date: string;
    days: number;
  };
  overview: {
    total_actions: number;
    unique_users: number;
    error_rate_percent: number;
    total_errors: number;
  };
  recent_activity: CaseLog[];
  daily_activity: Array<{
    date: string;
    count: number;
  }>;
  top_users: Array<{
    user_email: string;
    action_count: number;
  }>;
  action_distribution: Array<{
    action: string;
    count: number;
  }>;
  severity_distribution: {
    low: number;
    medium: number;
    high: number;
    critical: number;
  };
}

export default function CaseLogsPage() {
  const { user } = useAuth();
  const [logs, setLogs] = useState<CaseLog[]>([]);
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState({
    search: '',
    action_group: '',
    severity_levels: '',
    date_range: '7d',
    user_email: '',
    page: 1,
    limit: 20
  });
  const [totalPages, setTotalPages] = useState(1);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'logs'>('dashboard');

  // Check if user has admin permissions
  const isAdmin = user?.role_name === 'Admin';

  const fetchDashboard = async () => {
    if (!isAdmin) return;
    
    try {
      const data = await caseApi.getCaseLogsDashboard({ days: 30 }) as any;
      
      if (data?.success) {
        setDashboardData(data.data);
      } else {
        setError('Failed to fetch dashboard data');
      }
    } catch (err: any) {
      console.error('Error fetching dashboard:', err);
      if (err.response?.status === 404 || err.code === 'ECONNREFUSED') {
        setError('Backend API not implemented - endpoints needed: /api/cases/logs/dashboard');
      } else {
        setError(err.response?.data?.message || 'Failed to fetch dashboard data');
      }
    }
  };

  const fetchLogs = async () => {
    if (!isAdmin) return;
    
    try {
      setLoading(true);
      setError(null);
      
      const data = await caseApi.getCaseLogsList(filter) as any;
      
      if (data?.success) {
        setLogs(data.data?.logs || []);
        setTotalPages(data.pagination?.total_pages || 1);
      } else {
        setError('Failed to fetch case logs');
      }
    } catch (err: any) {
      console.error('Error fetching case logs:', err);
      if (err.response?.status === 404 || err.code === 'ECONNREFUSED') {
        setError('Backend API not implemented - endpoints needed: /api/cases/logs/list');
      } else {
        setError(err.response?.data?.message || 'Failed to fetch case logs');
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isAdmin) {
      if (activeTab === 'dashboard') {
        fetchDashboard();
      } else {
        fetchLogs();
      }
    }
  }, [isAdmin, activeTab, filter]);

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-100 text-red-800 border-red-200';
      case 'high': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getActionIcon = (action: string) => {
    if (action.includes('create')) return <FileText className="h-4 w-4" />;
    if (action.includes('update') || action.includes('edit')) return <FileText className="h-4 w-4" />;
    if (action.includes('delete')) return <XCircle className="h-4 w-4" />;
    if (action.includes('view') || action.includes('read')) return <FileText className="h-4 w-4" />;
    if (action.includes('assign')) return <User className="h-4 w-4" />;
    return <Info className="h-4 w-4" />;
  };

  const formatTimestamp = (timestamp: string) => {
    return new Date(timestamp).toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const handleExport = async () => {
    try {
      const response = await caseApi.exportCaseLogs({
        format: 'csv',
        ...filter
      });
      
      // Handle the response - it should be a string (CSV data) or an object with data property
      let csvData: string = '';
      
      if (typeof response === 'string') {
        csvData = response;
      } else if (response && typeof (response as any).data === 'string') {
        csvData = (response as any).data;
      } else {
        toast.error('Export data format not recognized');
        return;
      }
      
      // Create and download the CSV file
      const blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      
      link.setAttribute('href', url);
      link.setAttribute('download', `case_logs_${new Date().toISOString().slice(0, 10)}.csv`);
      link.style.visibility = 'hidden';
      
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      URL.revokeObjectURL(url);
      toast.success('Case logs exported successfully');
    } catch (err: any) {
      console.error('Export error:', err);
      toast.error('Failed to export case logs');
    }
  };

  if (!isAdmin) {
    return (
      <ProtectedRoute>
        <div className="p-6 bg-gray-50 min-h-screen">
          <div className="max-w-7xl mx-auto">
            <Card className="p-8 text-center">
              <Shield className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h2 className="text-xl font-semibold text-gray-900 mb-2">Access Denied</h2>
              <p className="text-gray-600">This page is only accessible to administrators.</p>
            </Card>
          </div>
        </div>
      </ProtectedRoute>
    );
  }

  return (
    <ProtectedRoute>
      <div className="p-6 bg-gray-50 min-h-screen">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Case Audit Logs</h1>
              <p className="text-gray-600 mt-1">Monitor and analyze case-related activities</p>
              {error && error.includes('404') && (
                <div className="mt-2 p-3 bg-yellow-50 border border-yellow-200 rounded-md">
                  <p className="text-sm text-yellow-800">
                    <strong>Note:</strong> Backend API endpoints need to be implemented. 
                    Currently showing placeholder data.
                  </p>
                </div>
              )}
            </div>
            <Button
              onClick={handleExport}
              className="flex items-center gap-2"
            >
              <Download className="h-4 w-4" />
              Export Logs
            </Button>
          </div>

          {/* Tab Navigation */}
          <div className="flex space-x-1 mb-6">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                activeTab === 'dashboard'
                  ? 'bg-blue-100 text-blue-700'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Dashboard
            </button>
            <button
              onClick={() => setActiveTab('logs')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                activeTab === 'logs'
                  ? 'bg-blue-100 text-blue-700'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Detailed Logs
            </button>
          </div>

          {/* Dashboard Tab */}
          {activeTab === 'dashboard' && dashboardData && (
            <div className="space-y-6">
              {/* Overview Stats */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <Card className="p-6">
                  <div className="flex items-center">
                    <div className="p-2 bg-blue-100 rounded-lg">
                      <Activity className="h-6 w-6 text-blue-600" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Total Actions</p>
                      <p className="text-2xl font-bold text-gray-900">
                        {dashboardData.overview.total_actions.toLocaleString()}
                      </p>
                    </div>
                  </div>
                </Card>

                <Card className="p-6">
                  <div className="flex items-center">
                    <div className="p-2 bg-green-100 rounded-lg">
                      <Users className="h-6 w-6 text-green-600" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Active Users</p>
                      <p className="text-2xl font-bold text-gray-900">
                        {dashboardData.overview.unique_users}
                      </p>
                    </div>
                  </div>
                </Card>

                <Card className="p-6">
                  <div className="flex items-center">
                    <div className="p-2 bg-red-100 rounded-lg">
                      <AlertTriangle className="h-6 w-6 text-red-600" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Error Rate</p>
                      <p className="text-2xl font-bold text-gray-900">
                        {dashboardData.overview.error_rate_percent}%
                      </p>
                    </div>
                  </div>
                </Card>

                <Card className="p-6">
                  <div className="flex items-center">
                    <div className="p-2 bg-orange-100 rounded-lg">
                      <Database className="h-6 w-6 text-orange-600" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Total Errors</p>
                      <p className="text-2xl font-bold text-gray-900">
                        {dashboardData.overview.total_errors}
                      </p>
                    </div>
                  </div>
                </Card>
              </div>

              {/* Recent Activity */}
              <Card className="p-6">
                <h3 className="text-lg font-semibold mb-4">Recent Activity</h3>
                <div className="space-y-3">
                  {dashboardData.recent_activity && Array.isArray(dashboardData.recent_activity) ? 
                    dashboardData.recent_activity.slice(0, 10).map((log, index) => (
                      <div key={log._id || `recent-log-${index}`} className="flex items-center space-x-4 p-3 bg-gray-50 rounded-lg">
                        <div className={`p-2 rounded-lg ${log.success ? 'bg-green-100' : 'bg-red-100'}`}>
                          {log.success ? (
                            <CheckCircle className="h-4 w-4 text-green-600" />
                          ) : (
                            <XCircle className="h-4 w-4 text-red-600" />
                          )}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <span className="font-medium text-gray-900">
                              {log.action ? log.action.replace(/_/g, ' ').toUpperCase() : 'Unknown Action'}
                            </span>
                            <span className="text-sm text-gray-500">
                              {log.timestamp ? formatTimestamp(log.timestamp) : 'Unknown Time'}
                            </span>
                          </div>
                          <div className="flex items-center justify-between">
                            <p className="text-sm text-gray-600">{log.user_email}</p>
                            {log.entity_type === 'case' && log.entity_id && (
                              <Link 
                                href={`/cases/${log.entity_id}`}
                                className="text-xs text-blue-600 hover:text-blue-800 hover:underline"
                              >
                                View Case
                              </Link>
                            )}
                          </div>
                        </div>
                        <Badge className={getSeverityColor(log.severity || 'low')}>
                          {log.severity || 'low'}
                        </Badge>
                      </div>
                    )) : (
                      <p className="text-gray-500 text-center py-4">No recent activity</p>
                    )
                  }
                </div>
              </Card>

              {/* Action Distribution */}
              <Card className="p-6">
                <h3 className="text-lg font-semibold mb-4">Action Distribution</h3>
                <div className="space-y-3">
                  {dashboardData.action_distribution && Array.isArray(dashboardData.action_distribution) ? 
                    dashboardData.action_distribution.slice(0, 5).map((actionStat, index) => (
                      <div key={`action-${actionStat.action || 'unknown'}-${index}`} className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">
                          {actionStat.action ? actionStat.action.replace(/_/g, ' ').toUpperCase() : 'Unknown Action'}
                        </span>
                        <span className="font-medium">{actionStat.count || 0}</span>
                      </div>
                    )) : (
                      <p className="text-gray-500 text-center py-4">No action data</p>
                    )
                  }
                </div>
              </Card>
            </div>
          )}

          {/* Detailed Logs Tab */}
          {activeTab === 'logs' && (
            <div className="space-y-6">
              {/* Filters */}
              <Card className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Search
                    </label>
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                      <input
                        type="text"
                        placeholder="Search..."
                        value={filter.search}
                        onChange={(e) => setFilter({ ...filter, search: e.target.value, page: 1 })}
                        className="pl-10 pr-4 py-2 border rounded-md w-full text-sm"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Action Group
                    </label>
                    <select
                      value={filter.action_group}
                      onChange={(e) => setFilter({ ...filter, action_group: e.target.value, page: 1 })}
                      className="w-full px-3 py-2 border rounded-md text-sm"
                    >
                      <option value="">All Actions</option>
                      <option value="case_management">Case Management</option>
                      <option value="case_notes">Case Notes</option>
                      <option value="case_attachments">Case Attachments</option>
                      <option value="case_assignment">Case Assignment</option>
                      <option value="case_status">Case Status</option>
                      <option value="case_priority">Case Priority</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Severity
                    </label>
                    <select
                      value={filter.severity_levels}
                      onChange={(e) => setFilter({ ...filter, severity_levels: e.target.value, page: 1 })}
                      className="w-full px-3 py-2 border rounded-md text-sm"
                    >
                      <option value="">All Severities</option>
                      <option value="low">Low</option>
                      <option value="medium">Medium</option>
                      <option value="high">High</option>
                      <option value="critical">Critical</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Date Range
                    </label>
                    <select
                      value={filter.date_range}
                      onChange={(e) => setFilter({ ...filter, date_range: e.target.value, page: 1 })}
                      className="w-full px-3 py-2 border rounded-md text-sm"
                    >
                      <option value="1d">Last 24 Hours</option>
                      <option value="7d">Last 7 Days</option>
                      <option value="30d">Last 30 Days</option>
                      <option value="90d">Last 90 Days</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      User Email
                    </label>
                    <input
                      type="text"
                      placeholder="Filter by user..."
                      value={filter.user_email}
                      onChange={(e) => setFilter({ ...filter, user_email: e.target.value, page: 1 })}
                      className="w-full px-3 py-2 border rounded-md text-sm"
                    />
                  </div>
                </div>
              </Card>

              {/* Logs List */}
              <Card className="p-6">
                {loading ? (
                  <div className="flex items-center justify-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                    <span className="ml-2">Loading logs...</span>
                  </div>
                ) : error ? (
                  <div className="flex items-center justify-center py-8 text-red-600">
                    <AlertTriangle className="h-5 w-5 mr-2" />
                    <span>{error}</span>
                  </div>
                ) : logs.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <Shield className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                    <p>No audit logs found</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {Array.isArray(logs) ? logs.map((log) => (
                      <div
                        key={log._id || `log-${Math.random()}`}
                        className="flex items-start space-x-4 p-4 bg-gray-50 rounded-lg border"
                      >
                        <div className={`flex-shrink-0 p-2 rounded-lg ${log.success ? 'bg-green-100' : 'bg-red-100'}`}>
                          {log.success ? (
                            <CheckCircle className="h-4 w-4 text-green-600" />
                          ) : (
                            <XCircle className="h-4 w-4 text-red-600" />
                          )}
                        </div>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center space-x-2">
                              {getActionIcon(log.action || '')}
                              <span className="font-medium text-gray-900">
                                {log.action ? log.action.replace(/_/g, ' ').toUpperCase() : 'Unknown Action'}
                              </span>
                              <Badge className={getSeverityColor(log.severity || 'low')}>
                                {log.severity || 'low'}
                              </Badge>
                            </div>
                            <span className="text-sm text-gray-500">
                              {log.timestamp ? formatTimestamp(log.timestamp) : 'Unknown Time'}
                            </span>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                            <div>
                              <span className="text-gray-500">User:</span>
                              <span className="ml-2 font-medium">{log.user_email}</span>
                            </div>
                            <div>
                              <span className="text-gray-500">Entity:</span>
                              {log.entity_type === 'case' && log.entity_id ? (
                                <Link 
                                  href={`/cases/${log.entity_id}`}
                                  className="ml-2 text-blue-600 hover:text-blue-800 hover:underline font-medium"
                                >
                                  {log.entity_type} ({log.entity_id})
                                </Link>
                              ) : (
                                <span className="ml-2">
                                  {log.entity_type || 'unknown'} 
                                  {log.entity_id ? ` (${log.entity_id})` : ''}
                                </span>
                              )}
                            </div>
                            <div>
                              <span className="text-gray-500">Category:</span>
                              <span className="ml-2">
                                {log.category ? log.category.replace(/_/g, ' ') : 'uncategorized'}
                              </span>
                            </div>
                          </div>

                          {log.details && typeof log.details === 'object' && Object.keys(log.details).length > 0 && (
                            <div className="mt-3 p-3 bg-white rounded border">
                              <span className="text-xs font-medium text-gray-500 uppercase tracking-wide">Details:</span>
                              <pre className="text-xs text-gray-700 mt-1 whitespace-pre-wrap max-h-32 overflow-y-auto">
                                {JSON.stringify(log.details, null, 2)}
                              </pre>
                            </div>
                          )}

                          {log.ip_address && (
                            <div className="mt-2 text-xs text-gray-500">
                              IP: {log.ip_address}
                            </div>
                          )}
                        </div>
                      </div>
                    )) : (
                      <p className="text-gray-500 text-center py-4">Invalid logs data</p>
                    )}
                  </div>
                )}

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="flex items-center justify-between mt-6">
                    <Button
                      variant="outline"
                      disabled={filter.page === 1}
                      onClick={() => setFilter({ ...filter, page: filter.page - 1 })}
                    >
                      Previous
                    </Button>
                    <span className="text-sm text-gray-600">
                      Page {filter.page} of {totalPages}
                    </span>
                    <Button
                      variant="outline"
                      disabled={filter.page === totalPages}
                      onClick={() => setFilter({ ...filter, page: filter.page + 1 })}
                    >
                      Next
                    </Button>
                  </div>
                )}
              </Card>
            </div>
          )}
        </div>
      </div>
    </ProtectedRoute>
  );
}
