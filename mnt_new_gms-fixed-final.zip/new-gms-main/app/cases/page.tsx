'use client';

import React, { useState, useEffect } from 'react';
import ProtectedRoute from '@/components/ProtectedRoute';
import { caseApi } from '@/services/api';
import { Case, CaseFilters as CaseFiltersType, CaseStats as CaseStatsType } from '@/app/types/case';
import CaseStatsComponent from './components/CaseStats';
import CaseFiltersComponent from './components/CaseFilters';
import CaseList from './components/CaseList';
import TestCaseFormModal from './components/TestCaseFormModal';
import LoadingSpinner from './components/LoadingSpinner';
import ErrorMessage from './components/ErrorMessage';
import { Button } from '@/app/components/ui/button';
import { Plus, RefreshCw } from 'lucide-react';
import toast from 'react-hot-toast';

export default function CasesPage() {
  const [cases, setCases] = useState<Case[]>([]);
  const [stats, setStats] = useState<CaseStatsType | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filters, setFilters] = useState<CaseFiltersType>({
    page: 1,
    limit: 10,
    sortBy: 'createdAt',
    sortOrder: 'desc'
  });
  const [pagination, setPagination] = useState({
    currentPage: 1,
    totalPages: 1,
    totalItems: 0,
    hasPrevPage: false,
    hasNextPage: false
  });
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [autoRefreshEnabled, setAutoRefreshEnabled] = useState(true);
  const [lastRefreshTime, setLastRefreshTime] = useState<Date | null>(null);

  // Fetch cases
  const fetchCases = async (newFilters?: CaseFiltersType) => {
    try {
      setLoading(true);
      setError(null);
      
      const filtersToUse = newFilters || filters;
      
      const response = await caseApi.getCases(filtersToUse) as any;
      
      // The response interceptor in api.ts returns response.data directly
      // So response IS the backend response structure: { success: true, data: [...], pagination: {...} }
      if (response && response.success) {
        // Backend response structure: { success: true, message: "...", data: [...], pagination: {...} }
        // The cases array is directly in response.data
        if (response.data && Array.isArray(response.data)) {
          // Map backend case data to frontend format
          const mappedCases = response.data.map((caseItem: any) => ({
            ...caseItem,
            // Normalize comments to notes if they exist
            notes: caseItem.notes || caseItem.comments || [],
            // Ensure consistent status format (replace underscores with hyphens)
            status: caseItem.status?.replace(/_/g, '-') || caseItem.status
          }));
          
          setCases(mappedCases);
        } else {
          console.error('Cases data is not an array:', response.data);
          setCases([]);
        }
        
        if (response.pagination) {
          // Map the backend pagination format to frontend format
          const paginationData = {
            currentPage: response.pagination.currentPage,
            totalPages: response.pagination.totalPages,
            totalItems: response.pagination.totalCount || response.pagination.totalItems, // Handle both formats
            hasPrevPage: response.pagination.hasPrevPage,
            hasNextPage: response.pagination.hasNextPage
          };
          setPagination(paginationData);
        } else {
          console.error('Pagination data missing:', response.pagination);
        }
      } else {
        setError(response?.message || 'Failed to fetch cases');
      }
    } catch (err: any) {
      console.error('Error fetching cases:', err.message);
      
      let errorMessage = 'Failed to fetch cases';
      if (err.code === 'ECONNREFUSED') {
        errorMessage = 'Cannot connect to backend server. Is it running on port 3000?';
      } else if (err.response?.status === 404) {
        errorMessage = 'API endpoint not found. Check if case routes are mounted.';
      } else if (err.response?.status === 401) {
        errorMessage = 'Authentication required. Please log in.';
      } else if (err.response?.data?.message) {
        errorMessage = err.response.data.message;
      }
      
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  // Fetch statistics
  const fetchStats = async () => {
    try {
      const response = await caseApi.getStats() as any;
      if (response && response.success) {
        // Map backend property names to frontend expected names
        const mappedStats = {
          total: response.data.totalCases || 0,
          open: response.data.openCases || 0,
          inProgress: response.data.inProgressCases || 0,
          pending: response.data.pendingCases || 0,
          resolved: response.data.resolvedCases || 0,
          closed: response.data.closedCases || 0,
          urgent: response.data.urgentCases || 0,
          high: response.data.highCases || 0,
          medium: response.data.mediumCases || 0,
          low: response.data.lowCases || 0,
          overdue: response.data.overdueCases || 0,
          dueToday: response.data.dueTodayCases || 0
        };
        
        setStats(mappedStats);
      } else {
        console.error('Stats response missing success property:', response);
      }
    } catch (err) {
      console.error('Error fetching stats:', err);
    }
  };

  // Handle filter changes
  const handleFilterChange = (newFilters: Partial<CaseFiltersType>) => {
    const updatedFilters = { ...filters, ...newFilters, page: 1 };
    setFilters(updatedFilters);
    fetchCases(updatedFilters);
  };

  // Handle stats card clicks for filtering
  const handleStatsCardClick = (filter: Partial<CaseFiltersType>) => {
    // Clear current filters except pagination settings
    const baseFilters: CaseFiltersType = {
      page: 1,
      limit: filters.limit || 10,
      sortBy: filters.sortBy || 'createdAt',
      sortOrder: filters.sortOrder || 'desc'
    };

    // If it's the "Total Cases" card (empty filter), just use base filters
    if (Object.keys(filter).length === 0) {
      setFilters(baseFilters);
      fetchCases(baseFilters);
      return;
    }

    // For special filters like overdue and dueToday, handle them specially
    let specialFilters: Partial<CaseFiltersType> = {};
    
    if (filter.overdue) {
      // For overdue, we need to set a date filter for past due dates
      // and exclude resolved/closed cases
      const today = new Date().toISOString().split('T')[0];
      specialFilters = {
        dateTo: today,
        // We'll handle the overdue logic in the backend or filter client-side
        overdue: true
      };
    } else if (filter.dueToday) {
      // For due today, set date filters for today
      const today = new Date().toISOString().split('T')[0];
      specialFilters = {
        dateFrom: today,
        dateTo: today,
        dueToday: true
      };
    } else {
      // For normal status/priority filters
      specialFilters = filter;
    }

    const updatedFilters = { ...baseFilters, ...specialFilters };
    setFilters(updatedFilters);
    fetchCases(updatedFilters);
  };

  // Handle page changes
  const handlePageChange = (page: number) => {
    const updatedFilters = { ...filters, page };
    setFilters(updatedFilters);
    fetchCases(updatedFilters);
  };

  // Handle refresh
  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      await Promise.all([fetchCases(), fetchStats()]);
      setLastRefreshTime(new Date());
      toast.success('Cases refreshed');
    } catch (error) {
      toast.error('Failed to refresh cases');
    } finally {
      setRefreshing(false);
    }
  };

  // Auto-refresh logic
  useEffect(() => {
    if (!autoRefreshEnabled) return;

    // Check if there are active cases (not resolved or closed)
    const hasActiveCases = cases.some(caseItem => 
      caseItem.status !== 'resolved' && caseItem.status !== 'closed'
    );

    if (!hasActiveCases) return;

    // Set up auto-refresh every 30 seconds
    const interval = setInterval(() => {
      handleRefresh();
    }, 30000); // 30 seconds

    return () => clearInterval(interval);
  }, [autoRefreshEnabled, cases]);

  // Window focus refresh
  useEffect(() => {
    const handleWindowFocus = () => {
      // Only refresh if it's been more than 10 seconds since last refresh
      if (!lastRefreshTime || (Date.now() - lastRefreshTime.getTime()) > 10000) {
        handleRefresh();
      }
    };

    window.addEventListener('focus', handleWindowFocus);
    return () => window.removeEventListener('focus', handleWindowFocus);
  }, [lastRefreshTime]);

  // Handle case creation
  const handleCaseCreated = (newCase: Case) => {
    setCases(prev => [newCase, ...prev]);
    setShowCreateModal(false);
    
    // Update stats optimistically
    if (stats) {
      setStats(prev => prev ? {
        ...prev,
        total: prev.total + 1,
        [newCase.status]: (prev as any)[newCase.status] + 1,
        [newCase.priority]: (prev as any)[newCase.priority] + 1
      } : null);
    }
    
    // Fetch updated stats in background
    fetchStats();
    toast.success('Case created successfully');
  };

  // Handle case update
  const handleCaseUpdated = (updatedCase: Case) => {
    setCases(prev => prev.map(c => c._id === updatedCase._id ? updatedCase : c));
    // Refresh stats to ensure accuracy
    fetchStats();
    
    // Auto-refresh if case status changed to resolved or closed
    if (updatedCase.status === 'resolved' || updatedCase.status === 'closed') {
      setTimeout(() => {
        handleRefresh();
      }, 1000); // Small delay to allow for any backend processing
    }
  };

  // Handle case deletion
  const handleCaseDeleted = (caseId: string) => {
    const deletedCase = cases.find(c => c._id === caseId);
    setCases(prev => prev.filter(c => c._id !== caseId));
    
    // Update stats optimistically
    if (stats && deletedCase) {
      setStats(prev => prev ? {
        ...prev,
        total: Math.max(0, prev.total - 1),
        [deletedCase.status]: Math.max(0, (prev as any)[deletedCase.status] - 1),
        [deletedCase.priority]: Math.max(0, (prev as any)[deletedCase.priority] - 1)
      } : null);
    }
    
    // Fetch updated stats in background
    fetchStats();
    toast.success('Case deleted successfully');
  };

  // Initial load
  useEffect(() => {
    Promise.all([fetchCases(), fetchStats()]).then(() => {
      setLastRefreshTime(new Date());
    });
  }, []);

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Case Management</h1>
              <div className="flex items-center gap-4 mt-1">
                <p className="text-gray-600">Track and manage support cases and issues</p>
                {lastRefreshTime && (
                  <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded-full">
                    Last updated: {lastRefreshTime.toLocaleTimeString()}
                  </span>
                )}
              </div>
            </div>
            <div className="flex gap-3 items-center">
              <div className="flex items-center gap-2">
                <input
                  id="auto-refresh"
                  type="checkbox"
                  checked={autoRefreshEnabled}
                  onChange={(e) => setAutoRefreshEnabled(e.target.checked)}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <label htmlFor="auto-refresh" className="text-sm text-gray-600">
                  Auto-refresh
                </label>
              </div>
              <Button
                variant="outline"
                onClick={handleRefresh}
                disabled={refreshing}
                className="flex items-center gap-2 hover:bg-gray-50"
              >
                <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
                {refreshing ? 'Refreshing...' : 'Refresh'}
              </Button>
              <Button
                onClick={() => setShowCreateModal(true)}
                className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white shadow-sm"
              >
                <Plus className="h-4 w-4" />
                New Case
              </Button>
            </div>
          </div>

          {/* Statistics */}
          {stats && (
            <div className="mb-8">
              {autoRefreshEnabled && cases.some(c => c.status !== 'resolved' && c.status !== 'closed') && (
                <div className="mb-4 bg-green-50 border border-green-200 rounded-lg p-3">
                  <div className="flex items-center gap-2 text-green-700">
                    <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                    <span className="text-sm font-medium">
                      Auto-refresh enabled - Cases will update every 30 seconds
                    </span>
                  </div>
                </div>
              )}
              <CaseStatsComponent 
                stats={stats} 
                onFilterClick={handleStatsCardClick}
                activeFilters={filters}
              />
            </div>
          )}

          {/* Filters */}
          <div className="mb-8">
            <CaseFiltersComponent
              filters={filters}
              onFilterChange={handleFilterChange}
              onClearFilters={() => {
                const defaultFilters: CaseFiltersType = {
                  page: 1,
                  limit: 10,
                  sortBy: 'createdAt',
                  sortOrder: 'desc'
                };
                setFilters(defaultFilters);
                fetchCases(defaultFilters);
              }}
            />
          </div>

          {/* Content */}
          {loading ? (
            <div className="flex justify-center items-center py-12">
              <LoadingSpinner />
            </div>
          ) : error ? (
            <div className="flex justify-center items-center py-12">
              <ErrorMessage 
                message={error} 
                onRetry={() => fetchCases()}
              />
            </div>
          ) : (
            <div className="space-y-6">
              <CaseList
                cases={cases}
                pagination={pagination}
                onPageChange={handlePageChange}
                onCaseUpdate={handleCaseUpdated}
                onCaseDelete={handleCaseDeleted}
                hasFilters={Boolean(
                  filters.status || 
                  filters.priority || 
                  filters.search || 
                  filters.assignedTo || 
                  filters.createdBy ||
                  filters.dateFrom ||
                  filters.dateTo ||
                  filters.tags?.length
                )}
                onCreateCase={() => setShowCreateModal(true)}
                onClearFilters={() => {
                  const defaultFilters: CaseFiltersType = {
                    page: 1,
                    limit: 10,
                    sortBy: 'createdAt',
                    sortOrder: 'desc'
                  };
                  setFilters(defaultFilters);
                  fetchCases(defaultFilters);
                }}
              />
            </div>
          )}

          {/* Create Case Modal */}
          {showCreateModal && (
            <TestCaseFormModal
              isOpen={showCreateModal}
              onClose={() => setShowCreateModal(false)}
              onCaseCreated={handleCaseCreated}
            />
          )}
        </div>
      </div>
    </ProtectedRoute>
  );
}
