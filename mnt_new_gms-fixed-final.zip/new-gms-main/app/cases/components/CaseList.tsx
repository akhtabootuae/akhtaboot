import React from 'react';
import { Case } from '@/app/types/case';
import CaseItem from './CaseItem';
import CasePagination from './CasePagination';
import EmptyState from './EmptyState';

interface CaseListProps {
  cases: Case[];
  pagination: {
    currentPage: number;
    totalPages: number;
    totalItems: number;
    hasPrevPage: boolean;
    hasNextPage: boolean;
  };
  onPageChange: (page: number) => void;
  onCaseUpdate: (updatedCase: Case) => void;
  onCaseDelete: (caseId: string) => void;
  hasFilters?: boolean;
  onCreateCase?: () => void;
  onClearFilters?: () => void;
}

export default function CaseList({
  cases,
  pagination,
  onPageChange,
  onCaseUpdate,
  onCaseDelete,
  hasFilters = false,
  onCreateCase,
  onClearFilters
}: CaseListProps) {
  if (cases.length === 0) {
    return (
      <EmptyState
        hasFilters={hasFilters}
        onCreateCase={onCreateCase}
        onClearFilters={onClearFilters}
      />
    );
  }

  return (
    <div className="space-y-4">
      {/* Cases List */}
      <div className="space-y-3">
        {cases.map((case_) => (
          <CaseItem
            key={case_._id}
            case={case_}
            onUpdate={onCaseUpdate}
            onDelete={onCaseDelete}
          />
        ))}
      </div>

      {/* Pagination */}
      {pagination.totalPages > 1 && (
        <CasePagination
          currentPage={pagination.currentPage}
          totalPages={pagination.totalPages}
          totalItems={pagination.totalItems}
          hasPrevPage={pagination.hasPrevPage}
          hasNextPage={pagination.hasNextPage}
          onPageChange={onPageChange}
        />
      )}
    </div>
  );
}
