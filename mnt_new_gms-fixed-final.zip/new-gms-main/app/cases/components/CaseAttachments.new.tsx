'use client';

import React, { useState, useRef } from 'react';
import { Case, CaseAttachment } from '@/app/types/case';
import { Button } from '@/app/components/ui/button';
import DocumentViewer from '@/app/components/ui/DocumentViewer';
import api from '@/services/api';
import { 
  Paperclip, 
  Trash2, 
  File,
  X,
  Plus,
  Download,
  Eye,
  Upload
} from 'lucide-react';

interface CaseAttachmentsProps {
  case: Case;
  attachments?: CaseAttachment[];
  onUploadFile?: (file: File) => Promise<void>;
  onDeleteFile?: (filename: string) => Promise<void>;
  onDownloadFile?: (filename: string) => Promise<void>; // Optional fallback
  onViewFile?: (filename: string) => Promise<void>; // Optional fallback
}

export default function CaseAttachments({ 
  case: caseData,
  attachments = [], 
  onUploadFile,
  onDeleteFile,
  onDownloadFile,
  onViewFile
}: CaseAttachmentsProps) {
  const [isUploading, setIsUploading] = useState(false);
  const [showUploadForm, setShowUploadForm] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [documentViewer, setDocumentViewer] = useState<{
    isOpen: boolean;
    documentUrl: string;
    filename: string;
  }>({
    isOpen: false,
    documentUrl: '',
    filename: ''
  });

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  const handleUpload = async () => {
    if (!selectedFile || !onUploadFile) return;
    
    setIsUploading(true);
    try {
      await onUploadFile(selectedFile);
      setShowUploadForm(false);
      setSelectedFile(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (error) {
      console.error('Failed to upload file:', error);
    } finally {
      setIsUploading(false);
    }
  };

  const handleCancelUpload = () => {
    setShowUploadForm(false);
    setSelectedFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleDelete = async (filename: string) => {
    if (!onDeleteFile) return;
    
    if (confirm('Are you sure you want to delete this attachment?')) {
      try {
        await onDeleteFile(filename);
      } catch (error) {
        console.error('Failed to delete attachment:', error);
      }
    }
  };

  const handleDownload = async (filename: string) => {
    try {
      // Find the attachment index for this filename
      const attachmentIndex = attachments.findIndex(att => 
        att.filename === filename
      );

      if (attachmentIndex === -1) {
        console.error('Attachment not found:', filename);
        console.error('Attachment not found');
        return;
      }

      // Use the backend API endpoint that returns signed download URLs
      const response = await api.get(`/api/cases/${caseData._id}/attachments/${attachmentIndex}/download`);
      
      if (response && response.data && response.data.downloadUrl) {
        // Create a temporary link element and trigger download
        const link = document.createElement('a');
        link.href = response.data.downloadUrl;
        link.download = response.data.filename || filename;
        link.target = '_blank';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      } else {
        console.error('Failed to get download URL:', response);
        // Fallback to original download method
        if (onDownloadFile) {
          await onDownloadFile(filename);
        } else {
          console.error('Failed to download attachment. Please try again.');
        }
      }
    } catch (error: any) {
      console.error('Error fetching download URL for attachment:', error);
      // Fallback to original download method
      if (onDownloadFile) {
        try {
          await onDownloadFile(filename);
        } catch (fallbackError) {
          console.error('Fallback download also failed:', fallbackError);
          console.error('Failed to download attachment. Please try again.');
        }
      } else {
        console.error('Failed to download attachment. Please try again.');
      }
    }
  };

  const handleView = async (filename: string) => {
    try {
      // Find the attachment index for this filename
      const attachmentIndex = attachments.findIndex(att => 
        att.filename === filename
      );

      if (attachmentIndex === -1) {
        console.error('Attachment not found:', filename);
        console.error('Attachment not found');
        return;
      }

      // Use the backend API endpoint that returns signed URLs (matching the backend implementation)
      const response = await api.get(`/api/cases/${caseData._id}/attachments/${attachmentIndex}/view`);
      
      if (response && response.data && response.data.signedUrl) {
        setDocumentViewer({
          isOpen: true,
          documentUrl: response.data.signedUrl,
          filename: response.data.filename || filename
        });
      } else {
        console.error('Failed to get signed URL:', response);
        // Fallback to legacy endpoint
        try {
          const legacyResponse = await api.get(`/api/cases/${caseData._id}/attachments/${encodeURIComponent(filename)}`);
          if (legacyResponse && legacyResponse.data && legacyResponse.data.signedUrl) {
            setDocumentViewer({
              isOpen: true,
              documentUrl: legacyResponse.data.signedUrl,
              filename: legacyResponse.data.filename || filename
            });
          } else {
            throw new Error('No signed URL in legacy response');
          }
        } catch (legacyError) {
          console.error('Legacy endpoint also failed:', legacyError);
          // Final fallback to original view method
          if (onViewFile) {
            await onViewFile(filename);
          } else {
            console.error('Failed to load attachment. Please try again.');
          }
        }
      }
    } catch (error: any) {
      console.error('Error fetching signed URL for attachment:', error);
      // Fallback to original view method
      if (onViewFile) {
        try {
          await onViewFile(filename);
        } catch (fallbackError) {
          console.error('Fallback view also failed:', fallbackError);
          console.error('Failed to view attachment. Please try again.');
        }
      } else {
        console.error('Failed to view attachment. Please try again.');
      }
    }
  };

  const closeDocumentViewer = () => {
    setDocumentViewer({
      isOpen: false,
      documentUrl: '',
      filename: ''
    });
  };

  const downloadFromViewer = (documentUrl: string, filename: string) => {
    const link = document.createElement('a');
    link.href = documentUrl;
    link.download = filename;
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Header Section */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="flex items-center justify-center w-12 h-12 bg-gradient-to-r from-blue-100 to-indigo-100 rounded-xl">
            <Paperclip className="h-6 w-6 text-blue-600" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-gray-900">Attachments</h3>
            <div className="flex items-center space-x-4 mt-1">
              <p className="text-sm text-gray-600">
                {attachments.length} {attachments.length === 1 ? 'file' : 'files'} attached
              </p>
              {attachments.length > 0 && (
                <div className="flex items-center space-x-1">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-xs text-green-600 font-medium">Active</span>
                </div>
              )}
            </div>
          </div>
        </div>
        
        {onUploadFile && (
          <Button
            onClick={() => setShowUploadForm(true)}
            disabled={showUploadForm}
            className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-lg hover:shadow-xl transition-all duration-200 border-0"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Attachment
          </Button>
        )}
      </div>

        {/* Upload Form */}
        {showUploadForm && (
          <div className="mb-8 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-xl p-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className="flex items-center justify-center w-10 h-10 bg-blue-100 rounded-lg">
                <Upload className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <h4 className="text-lg font-semibold text-gray-900">Upload New Attachment</h4>
                <p className="text-sm text-gray-600">Select a file to attach to this case</p>
              </div>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Choose File
                </label>
                <div className="relative">
                  <input
                    ref={fileInputRef}
                    type="file"
                    onChange={handleFileSelect}
                    className="w-full p-6 border-2 border-dashed border-blue-300 rounded-xl bg-white/50 hover:border-blue-400 focus:border-blue-500 focus:outline-none transition-colors duration-200 file:mr-4 file:py-3 file:px-6 file:rounded-lg file:border-0 file:bg-blue-100 file:text-blue-700 file:font-medium hover:file:bg-blue-200 cursor-pointer"
                    disabled={isUploading}
                  />
                  {!selectedFile && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                      <Upload className="h-8 w-8 text-blue-400 mb-2" />
                      <p className="text-sm font-medium text-gray-600">Click to select a file</p>
                      <p className="text-xs text-gray-500 mt-1">or drag and drop here</p>
                    </div>
                  )}
                  <div className="mt-3 text-xs text-gray-500 text-center">
                    Supported formats: PDF, DOC, DOCX, JPG, PNG, TXT, CSV, XLS, XLSX (Max: 25MB)
                  </div>
                </div>
              </div>

              {/* Selected File Preview */}
              {selectedFile && (
                <div className="bg-white border border-blue-200 rounded-lg p-4">
                  <div className="flex items-center space-x-3">
                    <div className="flex-shrink-0">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <File className="h-5 w-5 text-blue-600" />
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 truncate">
                        {selectedFile.name}
                      </p>
                      <p className="text-xs text-gray-500">
                        {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                      </p>
                    </div>
                    <div className="flex-shrink-0">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                        Ready to upload
                      </span>
                    </div>
                  </div>
                </div>
              )}
              
              <div className="flex justify-end space-x-3 pt-4 border-t border-blue-200">
                <Button
                  onClick={handleCancelUpload}
                  variant="outline"
                  disabled={isUploading}
                  className="border-gray-300 text-gray-700 hover:bg-gray-50"
                >
                  <X className="h-4 w-4 mr-2" />
                  Cancel
                </Button>
                {selectedFile && (
                  <Button
                    onClick={handleUpload}
                    disabled={isUploading}
                    className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-lg hover:shadow-xl transition-all duration-200"
                  >
                    {isUploading ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Uploading...
                      </>
                    ) : (
                      <>
                        <Upload className="h-4 w-4 mr-2" />
                        Upload File
                      </>
                    )}
                  </Button>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Attachments List */}
        <div className="space-y-4">
          {attachments.length === 0 ? (
            <div className="text-center py-16 bg-gradient-to-br from-gray-50 to-gray-100 rounded-xl border-2 border-dashed border-gray-300">
              <div className="flex items-center justify-center w-20 h-20 bg-white rounded-full shadow-sm mx-auto mb-6">
                <Paperclip className="h-10 w-10 text-gray-400" />
              </div>
              <h4 className="text-xl font-semibold text-gray-900 mb-3">No attachments yet</h4>
              <p className="text-gray-600 mb-6 max-w-sm mx-auto">
                Keep your case organized by uploading relevant documents, images, and files
              </p>
              {onUploadFile && (
                <Button
                  onClick={() => setShowUploadForm(true)}
                  className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-lg hover:shadow-xl transition-all duration-200"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Upload your first file
                </Button>
              )}
            </div>
          ) : (
            <div className="grid gap-3">
              {attachments.map((attachment, index) => (
                <div 
                  key={`${attachment.filename}-${index}`} 
                  className="group relative flex items-center justify-between p-5 bg-gradient-to-r from-white to-gray-50 border border-gray-200 rounded-xl hover:shadow-md hover:border-blue-200 transition-all duration-200"
                >
                  <div className="flex items-center space-x-4 flex-1 min-w-0">
                    <div className="flex-shrink-0">
                      <div className="w-12 h-12 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl border border-blue-200 flex items-center justify-center">
                        <File className="h-6 w-6 text-blue-600" />
                      </div>
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-3 mb-1">
                        <p className="text-base font-semibold text-gray-900 truncate">
                          {attachment.filename}
                        </p>
                        <div className="flex-shrink-0">
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                            Active
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4 text-sm text-gray-500">
                        <span>Uploaded {formatDate(attachment.uploadedAt)}</span>
                        <span className="w-1 h-1 bg-gray-300 rounded-full"></span>
                        <span>Ready for viewing</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    {/* View Button */}
                    <button
                      onClick={() => handleView(attachment.filename)}
                      className="group/btn opacity-0 group-hover:opacity-100 p-3 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all duration-200 hover:scale-105"
                      title="View attachment"
                    >
                      <Eye className="h-5 w-5" />
                    </button>
                    
                    {/* Download Button */}
                    <button
                      onClick={() => handleDownload(attachment.filename)}
                      className="group/btn opacity-0 group-hover:opacity-100 p-3 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded-xl transition-all duration-200 hover:scale-105"
                      title="Download attachment"
                    >
                      <Download className="h-5 w-5" />
                    </button>
                    
                    {/* Delete Button */}
                    {onDeleteFile && (
                      <button
                        onClick={() => handleDelete(attachment.filename)}
                        className="group/btn opacity-0 group-hover:opacity-100 p-3 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all duration-200 hover:scale-105"
                        title="Delete attachment"
                      >
                        <Trash2 className="h-5 w-5" />
                      </button>
                    )}
                  </div>
                  
                  {/* Hover Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-500/5 to-indigo-500/5 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none"></div>
                </div>
              ))}
            </div>
          )}
        </div>
        
        {/* Footer Info */}
        {attachments.length > 0 && (
          <div className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-xl p-4 mt-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-sm font-medium text-green-800">Secure Storage</span>
                </div>
                <div className="w-1 h-1 bg-green-400 rounded-full"></div>
                <span className="text-sm text-green-700">
                  {attachments.length} {attachments.length === 1 ? 'file' : 'files'} encrypted and protected
                </span>
              </div>
              <div className="text-xs text-green-600 font-medium">
                ✓ Authorized Access Only
              </div>
            </div>
          </div>
        )}

        {/* Document Viewer */}
        <DocumentViewer
          isOpen={documentViewer.isOpen}
          onClose={closeDocumentViewer}
          documentUrl={documentViewer.documentUrl}
          filename={documentViewer.filename}
          onDownload={() => downloadFromViewer(documentViewer.documentUrl, documentViewer.filename)}
        />
      </div>
  );
}
