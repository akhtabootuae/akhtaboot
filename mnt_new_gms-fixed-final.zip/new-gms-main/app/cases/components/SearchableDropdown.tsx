import React, { useState, useRef, useEffect } from 'react';
import { ChevronDown, X, Loader2 } from 'lucide-react';
import useDebounce from '@/app/hooks/useDebounce';
import { Option } from '../types/dropdown';

interface SearchableDropdownProps {
  placeholder: string;
  value?: Option | null;
  onSelect: (option: Option | null) => void;
  searchFunction: (searchTerm: string) => Promise<Option[]>;
  disabled?: boolean;
  allowClear?: boolean;
  className?: string;
  label?: string;
  required?: boolean;
  isLoading?: boolean;
}

export default function SearchableDropdown({
  placeholder,
  value,
  onSelect,
  searchFunction,
  disabled = false,
  allowClear = true,
  className = '',
  label,
  required = false,
  isLoading: externalLoading = false
}: SearchableDropdownProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [options, setOptions] = useState<Option[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const dropdownRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  
  const debouncedSearchTerm = useDebounce(searchTerm, 300);

  // Search for options when debounced search term changes
  useEffect(() => {
    if (debouncedSearchTerm && isOpen) {
      searchOptions(debouncedSearchTerm);
    } else {
      setOptions([]);
    }
  }, [debouncedSearchTerm, isOpen]);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
        setSearchTerm('');
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const searchOptions = async (term: string) => {
    if (!term.trim()) {
      setOptions([]);
      return;
    }

    setLoading(true);
    setError(null);
    
    try {
      const results = await searchFunction(term);
      setOptions(results);
    } catch (err) {
      console.error('SearchableDropdown: Search error:', err);
      setError('Failed to search');
      setOptions([]);
    } finally {
      setLoading(false);
    }
  };

  const handleInputFocus = () => {
    setIsOpen(true);
    if (value) {
      setSearchTerm(value.label);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
    if (!isOpen) {
      setIsOpen(true);
    }
  };

  const handleOptionSelect = (option: Option) => {
    onSelect(option);
    setIsOpen(false);
    setSearchTerm('');
  };

  const handleClear = () => {
    onSelect(null);
    setSearchTerm('');
  };

  const displayValue = externalLoading ? 'Loading user...' : (value ? value.label : '');

  return (
    <div className={`relative ${className}`} ref={dropdownRef}>
      {label && (
        <label className="block text-sm font-medium text-gray-700 mb-2">
          {label} {required && <span className="text-red-500">*</span>}
        </label>
      )}
      
      <div className="relative">
        <input
          ref={inputRef}
          type="text"
          value={isOpen ? searchTerm : displayValue}
          onChange={handleInputChange}
          onFocus={handleInputFocus}
          placeholder={placeholder}
          disabled={disabled}
          className="w-full border border-gray-300 rounded-md px-3 py-2 pr-10 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-gray-100 disabled:cursor-not-allowed"
        />
        
        <div className="absolute inset-y-0 right-0 flex items-center pr-2">
          {(loading || externalLoading) && (
            <Loader2 className="h-4 w-4 animate-spin text-blue-500 mr-1" />
          )}
          {value && allowClear && !disabled && (
            <button
              type="button"
              onClick={handleClear}
              className="p-1 hover:bg-gray-100 rounded mr-1"
            >
              <X className="h-4 w-4 text-gray-400" />
            </button>
          )}
          <ChevronDown
            className={`h-4 w-4 text-gray-400 transition-transform ${
              isOpen ? 'transform rotate-180' : ''
            }`}
          />
        </div>
      </div>

      {/* Dropdown */}
      {isOpen && (
        <div className="absolute z-50 w-full mt-1 bg-white border border-gray-300 rounded-md shadow-lg max-h-60 overflow-auto">
          {loading && (
            <div className="flex items-center justify-center py-3">
              <Loader2 className="h-4 w-4 animate-spin mr-2" />
              <span className="text-sm text-gray-500">Searching...</span>
            </div>
          )}
          
          {error && (
            <div className="px-3 py-2 text-sm text-red-600">
              {error}
            </div>
          )}
          
          {!loading && !error && searchTerm && options.length === 0 && (
            <div className="px-3 py-2 text-sm text-gray-500">
              No results found for "{searchTerm}"
            </div>
          )}
          
          {!loading && !error && !searchTerm && (
            <div className="px-3 py-2 text-sm text-gray-500">
              Start typing to search...
            </div>
          )}
          
          {!loading && !error && options.map((option) => (
            <button
              key={option.id}
              type="button"
              onClick={() => handleOptionSelect(option)}
              className="w-full px-3 py-2 text-left hover:bg-gray-100 focus:bg-gray-100 focus:outline-none"
            >
              <div className="font-medium text-gray-900">{option.label}</div>
              {option.subtitle && (
                <div className="text-sm text-gray-500">{option.subtitle}</div>
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
