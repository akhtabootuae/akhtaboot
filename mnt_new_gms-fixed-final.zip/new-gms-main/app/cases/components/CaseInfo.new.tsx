'use client';

import React from 'react';
import { Case } from '@/app/types/case';
import { Badge } from '@/app/components/ui/badge';
import { Calendar, Clock, User, Building, Tag, AlertTriangle, Info } from 'lucide-react';

interface CaseInfoProps {
  case: Case;
}

export default function CaseInfo({ case: caseData }: CaseInfoProps) {
  const formatDate = (date: Date | string) => {
    const dateObj = date instanceof Date ? date : new Date(date);
    return dateObj.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getPriorityColor = (priority: string) => {
    switch (priority.toLowerCase()) {
      case 'urgent':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'high':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low':
        return 'bg-green-100 text-green-800 border-green-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'open':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'in-progress':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'pending':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'resolved':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'closed':
        return 'bg-gray-100 text-gray-800 border-gray-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="p-6">
      {/* Header Section - Horizontal Layout */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-blue-50 rounded-lg">
            <Info className="h-5 w-5 text-blue-600" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Case Information</h3>
            <p className="text-sm text-gray-500">Details and status overview</p>
          </div>
        </div>
        
        {/* Status Badges - Horizontal */}
        <div className="flex gap-2">
          <Badge className={`${getPriorityColor(caseData.priority)} px-3 py-1 text-xs font-medium rounded-full border`}>
            <AlertTriangle className="h-3 w-3 mr-1" />
            {caseData.priority}
          </Badge>
          <Badge className={`${getStatusColor(caseData.status)} px-3 py-1 text-xs font-medium rounded-full border`}>
            {caseData.status.replace('-', ' ')}
          </Badge>
        </div>
      </div>

      <div className="space-y-6">
        {/* Description */}
        <div className="p-4 bg-gray-50 rounded-lg">
          <label className="text-sm font-medium text-gray-700 mb-2 block">Description</label>
          <p className="text-sm text-gray-900 leading-relaxed">{caseData.description}</p>
        </div>

        {/* Case Details - Horizontal Layout */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center text-sm">
              <div className="p-1.5 bg-white rounded-md mr-3">
                <User className="h-4 w-4 text-gray-600" />
              </div>
              <span className="text-gray-600">Created by</span>
            </div>
            <span className="text-sm font-medium text-gray-900">{caseData.createdBy}</span>
          </div>

          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center text-sm">
              <div className="p-1.5 bg-white rounded-md mr-3">
                <User className="h-4 w-4 text-gray-600" />
              </div>
              <span className="text-gray-600">Assigned to</span>
            </div>
            <span className="text-sm font-medium text-gray-900">
              {caseData.assignedTo || (
                <span className="text-gray-400 italic">Unassigned</span>
              )}
            </span>
          </div>

          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center text-sm">
              <div className="p-1.5 bg-white rounded-md mr-3">
                <Calendar className="h-4 w-4 text-gray-600" />
              </div>
              <span className="text-gray-600">Created</span>
            </div>
            <span className="text-sm font-medium text-gray-900">{formatDate(caseData.createdAt)}</span>
          </div>

          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center text-sm">
              <div className="p-1.5 bg-white rounded-md mr-3">
                <Clock className="h-4 w-4 text-gray-600" />
              </div>
              <span className="text-gray-600">Last updated</span>
            </div>
            <span className="text-sm font-medium text-gray-900">{formatDate(caseData.updatedAt)}</span>
          </div>

          {caseData.linkedTo && (
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg sm:col-span-2">
              <div className="flex items-center text-sm">
                <div className="p-1.5 bg-white rounded-md mr-3">
                  <Building className="h-4 w-4 text-gray-600" />
                </div>
                <span className="text-gray-600">Linked to</span>
              </div>
              <span className="text-sm font-medium text-gray-900">
                {caseData.linkedTo.type}
                {caseData.linkedTo.reference && ` - ${caseData.linkedTo.reference}`}
              </span>
            </div>
          )}

          {caseData.dueDate && (
            <div className="flex items-center justify-between p-3 bg-orange-50 rounded-lg border border-orange-200 sm:col-span-2">
              <div className="flex items-center text-sm">
                <div className="p-1.5 bg-white rounded-md mr-3">
                  <Calendar className="h-4 w-4 text-orange-600" />
                </div>
                <span className="text-orange-700 font-medium">Due date</span>
              </div>
              <span className="text-sm font-medium text-orange-900">{formatDate(caseData.dueDate)}</span>
            </div>
          )}
        </div>

        {/* Resolution Info - Horizontal Layout */}
        {(caseData.resolvedBy || caseData.resolvedAt || caseData.closedAt) && (
          <div className="p-4 bg-green-50 rounded-lg border border-green-200">
            <h4 className="text-sm font-medium text-green-900 mb-3 flex items-center">
              <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
              Resolution Details
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {caseData.resolvedBy && (
                <div className="flex items-center justify-between text-sm">
                  <span className="text-green-700">Resolved by:</span>
                  <span className="font-medium text-green-900">{caseData.resolvedBy}</span>
                </div>
              )}
              {caseData.resolvedAt && (
                <div className="flex items-center justify-between text-sm">
                  <span className="text-green-700">Resolved at:</span>
                  <span className="font-medium text-green-900">{formatDate(caseData.resolvedAt)}</span>
                </div>
              )}
              {caseData.closedAt && (
                <div className="flex items-center justify-between text-sm">
                  <span className="text-green-700">Closed at:</span>
                  <span className="font-medium text-green-900">{formatDate(caseData.closedAt)}</span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tags */}
        {caseData.tags && caseData.tags.length > 0 && (
          <div className="p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center mb-3">
              <Tag className="h-4 w-4 text-gray-500 mr-2" />
              <label className="text-sm font-medium text-gray-700">Tags</label>
            </div>
            <div className="flex flex-wrap gap-2">
              {caseData.tags.map((tag, index) => (
                <span
                  key={index}
                  className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800 border border-blue-200"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Summary Stats - Horizontal Layout */}
        <div className="border-t border-gray-200 pt-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-blue-700">Notes</span>
                <div className="text-2xl font-bold text-blue-900">{caseData.notes?.length || 0}</div>
              </div>
              <div className="text-xs text-blue-600 mt-1">Total case notes</div>
            </div>
            <div className="p-4 bg-green-50 rounded-lg border border-green-200">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-green-700">Attachments</span>
                <div className="text-2xl font-bold text-green-900">{caseData.attachments?.length || 0}</div>
              </div>
              <div className="text-xs text-green-600 mt-1">Total attachments</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
