import React, { useState, useEffect } from 'react';
import { Case, CreateCaseData, CaseStatus, CasePriority } from '@/app/types/case';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Card } from '@/app/components/ui/card';
import { X, Plus, Tag as TagIcon } from 'lucide-react';
import { caseApi, dataApi } from '@/services/api';
import SearchableDropdown from './SearchableDropdown';
import { Option } from '../types/dropdown';
import toast from 'react-hot-toast';

interface TestCaseFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCaseCreated: (newCase: Case) => void;
  editCase?: Case;
}

export default function TestCaseFormModal({ 
  isOpen, 
  onClose, 
  onCaseCreated, 
  editCase 
}: TestCaseFormModalProps) {
  const [formData, setFormData] = useState<CreateCaseData>({
    title: '',
    description: '',
    priority: 'medium',
    status: 'open',
    tags: [],
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [tagInput, setTagInput] = useState('');
  const [selectedUser, setSelectedUser] = useState<Option | null>(null);
  const [selectedEntity, setSelectedEntity] = useState<Option | null>(null);
  const [entityType, setEntityType] = useState<string>('');

  // Initialize form data when editing
  useEffect(() => {
    if (editCase) {
      setFormData({
        title: editCase.title,
        description: editCase.description,
        priority: editCase.priority,
        status: editCase.status,
        assignedTo: editCase.assignedTo,
        tags: editCase.tags || [],
        dueDate: editCase.dueDate ? new Date(editCase.dueDate).toISOString().split('T')[0] : undefined,
        linkedTo: editCase.linkedTo,
      });
      
      // Set selected user if exists
      if (editCase.assignedTo) {
        // Check if assignedTo is populated with user data (object) or just ObjectId (string)
        const assignedUser = editCase.assignedTo as any;
        if (typeof assignedUser === 'object' && assignedUser.name) {
          setSelectedUser({
            id: assignedUser._id || assignedUser.id,
            label: assignedUser.name || `${assignedUser.first_name || ''} ${assignedUser.last_name || ''}`.trim(),
            subtitle: `${assignedUser.email || ''} • ${assignedUser.role || 'User'}`
          });
        } else {
          // If assignedTo is just an ObjectId string, display placeholder
          setSelectedUser({
            id: assignedUser,
            label: 'User ID: ' + assignedUser.substring(0, 8) + '...',
            subtitle: 'Please re-select to see user name'
          });
        }
      } else {
        setSelectedUser(null);
      }
      
      // Set selected entity if exists
      if (editCase.linkedTo) {
        setEntityType(editCase.linkedTo.type);
        setSelectedEntity({
          id: editCase.linkedTo.reference || '',
          label: editCase.linkedTo.reference || '',
          subtitle: editCase.linkedTo.type
        });
      } else {
        setEntityType('');
        setSelectedEntity(null);
      }
    } else {
      // Reset for new case
      setFormData({
        title: '',
        description: '',
        priority: 'medium',
        status: 'open',
        tags: [],
      });
      setSelectedUser(null);
      setSelectedEntity(null);
      setEntityType('');
    }
  }, [editCase, isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.title.trim() || !formData.description.trim()) {
      toast.error('Title and description are required');
      return;
    }

    if (formData.title.length < 3 || formData.title.length > 200) {
      toast.error('Title must be between 3 and 200 characters');
      return;
    }

    if (formData.description.length < 10 || formData.description.length > 2000) {
      toast.error('Description must be between 10 and 2000 characters');
      return;
    }

    setIsSubmitting(true);
    try {
      // Create the base data object
      const baseData: any = {
        title: formData.title.trim(),
        description: formData.description.trim(),
        priority: formData.priority,
        status: formData.status,
        tags: formData.tags || [],
      };

      // Only include assignedTo if a user is selected
      if (selectedUser?.id) {
        baseData.assignedTo = selectedUser.id;
      }

      // Only include dueDate if provided and convert to proper format
      if (formData.dueDate) {
        baseData.dueDate = new Date(formData.dueDate).toISOString();
      }

      // Only include linkedTo if both entity and type are selected
      if (selectedEntity && entityType) {
        baseData.linkedTo = {
          type: entityType,
          id: selectedEntity.id,
          reference: selectedEntity.label
        };
      }

      let response;
      if (editCase) {
        response = await caseApi.updateCase(editCase._id, baseData) as any;
        
        if (response && response.success) {
          onCaseCreated(response.data as Case);
          toast.success('Case updated successfully');
        } else {
          throw new Error('Failed to update case');
        }
      } else {
        response = await caseApi.createCase(baseData) as any;
        
        if (response && response.success) {
          onCaseCreated(response.data as Case);
          toast.success('Case created successfully');
        } else {
          throw new Error('Failed to create case');
        }
      }
      
      onClose();
    } catch (error: any) {
      console.error('Case submission error:', error);
      const errorMessage = error.response?.data?.message || error.message || `Failed to ${editCase ? 'update' : 'create'} case`;
      toast.error(errorMessage);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Search functions for dropdowns
  const searchUsers = async (searchTerm: string) => {
    try {
      const results = await dataApi.searchUsers(searchTerm);
      return results;
    } catch (error) {
      console.error('TestCaseFormModal: Error searching users:', error);
      return [];
    }
  };

  const searchEntities = async (searchTerm: string) => {
    if (!entityType) return [];
    
    try {
      switch (entityType) {
        case 'customer':
          return await dataApi.searchCustomers(searchTerm);
        case 'workorder':
          return await dataApi.searchWorkOrders(searchTerm);
        case 'invoice':
          return await dataApi.searchInvoices(searchTerm);
        case 'user':
          return await dataApi.searchUsers(searchTerm);
        default:
          return [];
      }
    } catch (error) {
      console.error('Error searching entities:', error);
      return [];
    }
  };

  const handleUserSelect = (user: Option | null) => {
    setSelectedUser(user);
  };

  const handleEntityTypeChange = (type: string) => {
    setEntityType(type);
    setSelectedEntity(null);
  };

  const handleEntitySelect = (entity: Option | null) => {
    setSelectedEntity(entity);
  };

  const addTag = () => {
    if (tagInput.trim() && !formData.tags?.includes(tagInput.trim())) {
      setFormData(prev => ({
        ...prev,
        tags: [...(prev.tags || []), tagInput.trim()]
      }));
      setTagInput('');
    }
  };

  const removeTag = (tagToRemove: string) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags?.filter(tag => tag !== tagToRemove) || []
    }));
  };

  const handleTagInputKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      addTag();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          {/* Header */}
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-900">
              {editCase ? 'Edit Case' : 'Create New Case'}
            </h2>
            <Button
              variant="outline"
              size="sm"
              onClick={onClose}
              className="h-8 w-8 p-0"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Title */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Title *
              </label>
              <Input
                type="text"
                placeholder="Enter case title (3-200 characters)..."
                value={formData.title}
                onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                className="w-full"
                required
                minLength={3}
                maxLength={200}
              />
              <p className="text-xs text-gray-500 mt-1">
                {formData.title.length}/200 characters
              </p>
            </div>

            {/* Description */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Description *
              </label>
              <textarea
                placeholder="Describe the issue in detail (10-2000 characters)..."
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                className="w-full border border-gray-300 rounded-md px-3 py-2 min-h-24 focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
                minLength={10}
                maxLength={2000}
              />
              <p className="text-xs text-gray-500 mt-1">
                {formData.description.length}/2000 characters
              </p>
            </div>

            {/* Priority, Status, and Assigned To */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Priority *
                </label>
                <select
                  value={formData.priority}
                  onChange={(e) => setFormData(prev => ({ 
                    ...prev, 
                    priority: e.target.value as CasePriority 
                  }))}
                  className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                >
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                  <option value="urgent">Urgent</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Status *
                </label>
                <select
                  value={formData.status}
                  onChange={(e) => setFormData(prev => ({ 
                    ...prev, 
                    status: e.target.value as CaseStatus 
                  }))}
                  className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                >
                  <option value="open">Open</option>
                  <option value="in-progress">In Progress</option>
                  <option value="pending">Pending</option>
                  <option value="resolved">Resolved</option>
                  <option value="closed">Closed</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Assigned To (Optional)
                </label>
                <SearchableDropdown
                  placeholder="Search and select a user..."
                  searchFunction={searchUsers}
                  onSelect={handleUserSelect}
                  value={selectedUser}
                />
              </div>
            </div>

            {/* Link to Entity */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Link to Entity (Optional)
              </label>
              <div className="space-y-4">
                <select
                  value={entityType}
                  onChange={(e) => handleEntityTypeChange(e.target.value)}
                  className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Select Entity Type</option>
                  <option value="customer">Customer</option>
                  <option value="workorder">Work Order</option>
                  <option value="invoice">Invoice</option>
                  <option value="user">User</option>
                </select>
                
                {entityType && (
                  <SearchableDropdown
                    placeholder={`Search and select a ${entityType}...`}
                    searchFunction={searchEntities}
                    onSelect={handleEntitySelect}
                    value={selectedEntity}
                  />
                )}
              </div>
            </div>

            {/* Tags */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Tags (Optional)
              </label>
              <div className="space-y-3">
                {/* Tag Input */}
                <div className="flex gap-2">
                  <Input
                    type="text"
                    placeholder="Add a tag..."
                    value={tagInput}
                    onChange={(e) => setTagInput(e.target.value)}
                    onKeyPress={handleTagInputKeyPress}
                    className="flex-1"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    onClick={addTag}
                    className="flex items-center gap-1"
                  >
                    <Plus className="h-4 w-4" />
                    Add
                  </Button>
                </div>

                {/* Current Tags */}
                {formData.tags && formData.tags.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {formData.tags.map((tag, index) => (
                      <span
                        key={index}
                        className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-blue-100 text-blue-800 text-sm"
                      >
                        <TagIcon className="h-3 w-3" />
                        {tag}
                        <button
                          type="button"
                          onClick={() => removeTag(tag)}
                          className="hover:text-blue-600"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Due Date */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Due Date (Optional)
              </label>
              <Input
                type="date"
                value={formData.dueDate || ''}
                onChange={(e) => setFormData(prev => ({ 
                  ...prev, 
                  dueDate: e.target.value || undefined 
                }))}
              />
            </div>

            {/* Form Actions */}
            <div className="flex justify-end gap-3 pt-4 border-t">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                disabled={isSubmitting}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={isSubmitting}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {isSubmitting 
                  ? (editCase ? 'Updating...' : 'Creating...') 
                  : (editCase ? 'Update Case' : 'Create Case')
                }
              </Button>
            </div>
          </form>
        </div>
      </Card>
    </div>
  );
}
