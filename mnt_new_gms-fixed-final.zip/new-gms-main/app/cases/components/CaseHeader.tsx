import React, { useState, useEffect } from 'react';
import { Case } from '@/app/types/case';
import { Button } from '@/app/components/ui/button';
import { Badge } from '@/app/components/ui/badge';
import { 
  ArrowLeft, 
  Trash2, 
  CheckCircle, 
  XCircle, 
  MoreHorizontal,
  Calendar,
  Clock,
  User,
  Building,
  AlertTriangle,
  Tag
} from 'lucide-react';
// import { formatDistanceToNow } from 'date-fns';
import Link from 'next/link';
import { caseApi, dataApi } from '@/services/api';
import toast from 'react-hot-toast';

interface CaseHeaderProps {
  case: Case;
  onStatusUpdate?: (newStatus: string) => Promise<void>;
  onUpdate: (updatedCase: Case) => void;
  onDelete: () => void;
}

export default function CaseHeader({ case: caseData, onStatusUpdate, onUpdate, onDelete }: CaseHeaderProps) {
  const [showActions, setShowActions] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [creatorName, setCreatorName] = useState<string>('');
  const [isLoadingCreator, setIsLoadingCreator] = useState(true);

  // Fetch creator name when component mounts or caseData.createdBy changes
  useEffect(() => {
    const fetchCreatorName = async () => {
      try {
        setIsLoadingCreator(true);
        const response = await dataApi.getUserById(caseData.createdBy);
        
        // Handle different response structures based on the API implementation
        let userData = null;
        
        if (response && typeof response === 'object') {
          // Check if it's an Axios response with .data property
          if ('data' in response && response.data) {
            userData = response.data;
          }
          // Check if it's a structured error response
          else if ('success' in response && 'data' in response) {
            userData = response.data;
          }
          // Check if it's direct user data
          else if ('first_name' in response || 'name' in response) {
            userData = response;
          }
        }
        
        if (userData && typeof userData === 'object') {
          // Format the name: use first_name + last_name if available, otherwise use name field
          const formattedName = (userData as any).first_name && (userData as any).last_name 
            ? `${(userData as any).first_name} ${(userData as any).last_name}`
            : (userData as any).name || 'Unknown User';
          setCreatorName(formattedName);
        } else {
          setCreatorName('Unknown User');
        }
      } catch (error) {
        console.error('Error fetching creator data:', error);
        setCreatorName('Unknown User');
      } finally {
        setIsLoadingCreator(false);
      }
    };

    if (caseData.createdBy) {
      fetchCreatorName();
    } else {
      setCreatorName('Unknown User');
      setIsLoadingCreator(false);
    }
  }, [caseData.createdBy]);

  const formatDate = (date: Date | string) => {
    const dateObj = date instanceof Date ? date : new Date(date);
    return dateObj.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getPriorityColor = (priority: string) => {
    switch (priority.toLowerCase()) {
      case 'urgent':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'high':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low':
        return 'bg-green-100 text-green-800 border-green-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'in-progress': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'pending': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'resolved': return 'bg-green-100 text-green-800 border-green-200';
      case 'closed': return 'bg-gray-100 text-gray-800 border-gray-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const handleDelete = async () => {
    if (!confirm('Are you sure you want to delete this case? This action cannot be undone.')) {
      return;
    }

    setIsDeleting(true);
    try {
      // Call the parent's delete handler instead of doing the API call here
      await onDelete();
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to delete case');
    } finally {
      setIsDeleting(false);
    }
  };

  const handleQuickStatusUpdate = async (newStatus: string) => {
    try {
      // If onStatusUpdate callback is provided (from parent), use it
      if (onStatusUpdate) {
        await onStatusUpdate(newStatus);
      } else {
        // Fallback to direct API call
        await caseApi.updateCase(caseData._id, { status: newStatus as any });
        const updatedCase = await caseApi.getCaseById(caseData._id);
        if (updatedCase.data.success) {
          onUpdate(updatedCase.data.data);
          
          // Auto-refresh page when case is resolved or closed
          if (newStatus === 'resolved' || newStatus === 'closed') {
            toast.success(`Case ${newStatus} successfully. Page will refresh to show updates.`);
            
            // Trigger page refresh after a short delay to show the success message
            setTimeout(() => {
              window.location.reload();
            }, 2000);
          } else {
            toast.success('Case status updated successfully');
          }
        }
      }
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to update case status');
    }
  };

  const isOverdue = caseData.dueDate && new Date(caseData.dueDate) < new Date() && 
                   !['resolved', 'closed'].includes(caseData.status);

  return (
    <>
      <div className="mb-6">
        {/* Breadcrumb */}
        <div className="mb-4">
          <Link 
            href="/cases"
            className="flex items-center gap-2 text-blue-600 hover:text-blue-700 transition-colors"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Cases
          </Link>
        </div>

        {/* Header */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-start justify-between mb-6">
            <div className="flex-1">
              {/* Status and Title */}
              <div className="flex items-center gap-3 mb-2">
                <div className={`flex items-center gap-1 px-3 py-1 rounded-full border text-sm font-medium ${getStatusColor(caseData.status)}`}>
                  {caseData.status === 'resolved' && <CheckCircle className="h-4 w-4" />}
                  {caseData.status === 'closed' && <XCircle className="h-4 w-4" />}
                  {!['resolved', 'closed'].includes(caseData.status) && <Clock className="h-4 w-4" />}
                  {caseData.status.replace('-', ' ')}
                </div>
                
                {caseData.priority && (
                  <Badge className={`${getPriorityColor(caseData.priority)} px-3 py-1 text-xs font-medium rounded-full border`}>
                    <AlertTriangle className="h-3 w-3 mr-1" />
                    {caseData.priority}
                  </Badge>
                )}
                
                {isOverdue && (
                  <div className="flex items-center gap-1 px-3 py-1 rounded-full bg-red-100 text-red-800 text-sm font-medium">
                    ⚠️ Overdue
                  </div>
                )}
              </div>

              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                {caseData.title}
              </h1>

              <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600 mb-4">
                <span>
                  Created by {isLoadingCreator ? 'Loading...' : creatorName} • {new Date(caseData.createdAt).toLocaleDateString()}
                </span>
                
                {caseData.dueDate && (
                  <span className={`flex items-center gap-1 ${isOverdue ? 'text-red-600' : ''}`}>
                    <Calendar className="h-4 w-4" />
                    Due {new Date(caseData.dueDate).toLocaleDateString()}
                  </span>
                )}
              </div>

              {/* Description */}
              {caseData.description && (
                <div className="mb-4">
                  <p className="text-gray-700 text-sm leading-relaxed">{caseData.description}</p>
                </div>
              )}
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2">
              {/* Quick Actions */}
              {caseData.status !== 'resolved' && (
                <Button
                  variant="outline"
                  onClick={() => handleQuickStatusUpdate('resolved')}
                  className="flex items-center gap-2 text-green-600 border-green-200 hover:bg-green-50"
                >
                  <CheckCircle className="h-4 w-4" />
                  Mark Resolved
                </Button>
              )}

              {caseData.status !== 'closed' && (
                <Button
                  variant="outline"
                  onClick={() => handleQuickStatusUpdate('closed')}
                  className="flex items-center gap-2 text-gray-600 border-gray-200 hover:bg-gray-50"
                >
                  <XCircle className="h-4 w-4" />
                  Close Case
                </Button>
              )}

              {/* More Actions */}
              <div className="relative">
                <Button
                  variant="outline"
                  onClick={() => setShowActions(!showActions)}
                  className="h-10 w-10 p-0"
                >
                  <MoreHorizontal className="h-4 w-4" />
                </Button>

                {showActions && (
                  <div className="absolute right-0 mt-2 w-48 bg-white border border-gray-200 rounded-md shadow-lg z-10">
                    <div className="py-1">
                      <button 
                        onClick={handleDelete}
                        disabled={isDeleting}
                        className="flex items-center gap-2 w-full px-4 py-2 text-sm text-red-600 hover:bg-red-50"
                      >
                        <Trash2 className="h-4 w-4" />
                        {isDeleting ? 'Deleting...' : 'Delete Case'}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Case Information - Horizontal Layout */}
          <div className="border-t border-gray-200 pt-6">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {/* Assigned to - Only show if actually assigned */}
              {caseData.assignedTo && (
                <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                  <div className="p-1.5 bg-white rounded-md mr-3">
                    <User className="h-4 w-4 text-gray-600" />
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">Assigned to</div>
                    <div className="text-sm font-medium text-gray-900">
                      {caseData.assignedTo}
                    </div>
                  </div>
                </div>
              )}

              {/* Last updated */}
              <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                <div className="p-1.5 bg-white rounded-md mr-3">
                  <Clock className="h-4 w-4 text-gray-600" />
                </div>
                <div>
                  <div className="text-xs text-gray-500">Last updated</div>
                  <div className="text-sm font-medium text-gray-900">{formatDate(caseData.updatedAt)}</div>
                </div>
              </div>

              {/* Notes count */}
              <div className="flex items-center p-3 bg-blue-50 rounded-lg border border-blue-200">
                <div className="p-1.5 bg-white rounded-md mr-3">
                  <Tag className="h-4 w-4 text-blue-600" />
                </div>
                <div>
                  <div className="text-xs text-blue-600">Notes</div>
                  <div className="text-lg font-bold text-blue-900">{caseData.notes?.length || 0}</div>
                </div>
              </div>

              {/* Attachments count */}
              <div className="flex items-center p-3 bg-green-50 rounded-lg border border-green-200">
                <div className="p-1.5 bg-white rounded-md mr-3">
                  <Building className="h-4 w-4 text-green-600" />
                </div>
                <div>
                  <div className="text-xs text-green-600">Attachments</div>
                  <div className="text-lg font-bold text-green-900">{caseData.attachments?.length || 0}</div>
                </div>
              </div>
            </div>

            {/* Additional Info Row */}
            <div className="mt-4 flex flex-wrap gap-4">
              {/* Linked to */}
              {caseData.linkedTo && (
                <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                  <div className="p-1.5 bg-white rounded-md mr-3">
                    <Building className="h-4 w-4 text-gray-600" />
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">Linked to</div>
                    <div className="text-sm font-medium text-gray-900">
                      {caseData.linkedTo.type}
                      {caseData.linkedTo.reference && ` - ${caseData.linkedTo.reference}`}
                    </div>
                  </div>
                </div>
              )}

              {/* Due date */}
              {caseData.dueDate && (
                <div className="flex items-center p-3 bg-orange-50 rounded-lg border border-orange-200">
                  <div className="p-1.5 bg-white rounded-md mr-3">
                    <Calendar className="h-4 w-4 text-orange-600" />
                  </div>
                  <div>
                    <div className="text-xs text-orange-600">Due date</div>
                    <div className="text-sm font-medium text-orange-900">{formatDate(caseData.dueDate)}</div>
                  </div>
                </div>
              )}

              {/* Tags */}
              {caseData.tags && caseData.tags.length > 0 && (
                <div className="flex items-center gap-2">
                  <Tag className="h-4 w-4 text-gray-500" />
                  <div className="flex flex-wrap gap-1">
                    {caseData.tags.map((tag, index) => (
                      <span
                        key={index}
                        className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800 border border-blue-200"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

    </>
  );
}
