// filepath: /app/cases/components/CaseTimeline.tsx
'use client';

import React from 'react';
import { Case } from '@/app/types/case';
import { Card } from '@/app/components/ui/card';
import { Badge } from '@/app/components/ui/badge';
import { 
  Clock, 
  User, 
  MessageSquare, 
  FileText, 
  Settings, 
  CheckCircle,
  ArrowRight
} from 'lucide-react';

interface CaseTimelineProps {
  case: Case;
  activities?: any[]; // Can be refined later if needed
}

const CaseTimeline: React.FC<CaseTimelineProps> = ({ case: caseData, activities = [] }) => {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return {
      date: date.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric'
      }),
      time: date.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit'
      })
    };
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'status_change':
        return <Settings className="h-4 w-4" />;
      case 'note_added':
        return <MessageSquare className="h-4 w-4" />;
      case 'file_attached':
        return <FileText className="h-4 w-4" />;
      case 'case_created':
        return <CheckCircle className="h-4 w-4" />;
      case 'assignment_changed':
        return <User className="h-4 w-4" />;
      default:
        return <Clock className="h-4 w-4" />;
    }
  };

  const getActivityColor = (type: string) => {
    switch (type) {
      case 'status_change':
        return 'text-blue-600 bg-blue-100';
      case 'note_added':
        return 'text-green-600 bg-green-100';
      case 'file_attached':
        return 'text-purple-600 bg-purple-100';
      case 'case_created':
        return 'text-gray-600 bg-gray-100';
      case 'assignment_changed':
        return 'text-orange-600 bg-orange-100';
      default:
        return 'text-gray-600 bg-gray-100';
    }
  };

  // Create a default timeline with case creation
  const defaultActivities: CaseActivity[] = [
    {
      id: 'created',
      type: 'case_created',
      description: 'Case was created',
      timestamp: caseData.createdAt,
      user: {
        id: 'system',
        name: 'System',
        email: 'system@garage.com'
      }
    }
  ];

  const allActivities = [...defaultActivities, ...activities].sort(
    (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold">Case Timeline</h3>
        <Badge variant="outline" className="text-xs">
          {allActivities.length} activities
        </Badge>
      </div>

      <div className="space-y-4">
        {allActivities.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <Clock className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p>No activities recorded yet</p>
          </div>
        ) : (
          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-gray-200"></div>
            
            {allActivities.map((activity, index) => {
              const { date, time } = formatDate(activity.timestamp);
              
              return (
                <div key={activity.id} className="relative flex items-start space-x-4 pb-6">
                  {/* Timeline dot */}
                  <div className={`
                    relative z-10 flex items-center justify-center w-12 h-12 rounded-full border-2 border-white shadow-sm
                    ${getActivityColor(activity.type)}
                  `}>
                    {getActivityIcon(activity.type)}
                  </div>
                  
                  {/* Activity content */}
                  <div className="flex-1 min-w-0 pb-2">
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm font-medium text-gray-900">
                        {activity.description}
                      </p>
                      <div className="text-xs text-gray-500 flex items-center space-x-2">
                        <span>{date}</span>
                        <span>•</span>
                        <span>{time}</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2 text-xs text-gray-500">
                      <User className="h-3 w-3" />
                      <span>{activity.user.name}</span>
                    </div>
                    
                    {activity.details && (
                      <div className="mt-2 text-sm text-gray-600 bg-gray-50 rounded-md p-2">
                        {activity.details}
                      </div>
                    )}
                    
                    {activity.oldValue && activity.newValue && (
                      <div className="mt-2 flex items-center space-x-2 text-xs">
                        <Badge variant="outline" className="bg-red-50 text-red-700">
                          {activity.oldValue}
                        </Badge>
                        <ArrowRight className="h-3 w-3 text-gray-400" />
                        <Badge variant="outline" className="bg-green-50 text-green-700">
                          {activity.newValue}
                        </Badge>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
      
      {/* Add activity button */}
      <div className="border-t pt-4 mt-6">
        <button className="text-sm text-blue-600 hover:text-blue-800 font-medium">
          + Add Timeline Entry
        </button>
      </div>
    </Card>
  );
};

export default CaseTimeline;
