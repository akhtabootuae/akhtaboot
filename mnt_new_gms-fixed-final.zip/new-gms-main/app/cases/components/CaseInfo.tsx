// filepath: /app/cases/components/CaseInfo.tsx
'use client';

import React from 'react';
import { Case } from '@/app/types/case';
import { Card } from '@/app/components/ui/card';
import { Badge } from '@/app/components/ui/badge';
import { Calendar, Clock, User, Building, Tag, AlertTriangle } from 'lucide-react';

interface CaseInfoProps {
  case: Case;
}

const CaseInfo: React.FC<CaseInfoProps> = ({ case: caseData }) => {
  const formatDate = (date: Date | string) => {
    const dateObj = date instanceof Date ? date : new Date(date);
    return dateObj.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getPriorityColor = (priority: string) => {
    switch (priority.toLowerCase()) {
      case 'urgent':
        return 'bg-red-100 text-red-800';
      case 'high':
        return 'bg-orange-100 text-orange-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'low':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'open':
        return 'bg-blue-100 text-blue-800';
      case 'in-progress':
        return 'bg-yellow-100 text-yellow-800';
      case 'pending':
        return 'bg-orange-100 text-orange-800';
      case 'resolved':
        return 'bg-green-100 text-green-800';
      case 'closed':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold">Case Information</h3>
        <div className="flex gap-2">
          <Badge className={getPriorityColor(caseData.priority)}>
            <AlertTriangle className="h-3 w-3 mr-1" />
            {caseData.priority}
          </Badge>
          <Badge className={getStatusColor(caseData.status)}>
            {caseData.status.replace('-', ' ')}
          </Badge>
        </div>
      </div>

      <div className="space-y-4">
        {/* Description */}
        <div>
          <label className="text-sm font-medium text-gray-500">Description</label>
          <p className="mt-1 text-sm text-gray-900">{caseData.description}</p>
        </div>

        {/* Case Details Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-3">
            <div className="flex items-center text-sm">
              <User className="h-4 w-4 text-gray-400 mr-2" />
              <span className="text-gray-500">Created by:</span>
              <span className="ml-2 font-medium">{caseData.createdBy}</span>
            </div>

            <div className="flex items-center text-sm">
              <User className="h-4 w-4 text-gray-400 mr-2" />
              <span className="text-gray-500">Assigned to:</span>
              <span className="ml-2 font-medium">
                {caseData.assignedTo || 'Unassigned'}
              </span>
            </div>

            {caseData.linkedTo && (
              <div className="flex items-center text-sm">
                <Building className="h-4 w-4 text-gray-400 mr-2" />
                <span className="text-gray-500">Linked to:</span>
                <span className="ml-2 font-medium">
                  {caseData.linkedTo.type}
                  {caseData.linkedTo.reference && ` (${caseData.linkedTo.reference})`}
                </span>
              </div>
            )}
          </div>

          <div className="space-y-3">
            <div className="flex items-center text-sm">
              <Calendar className="h-4 w-4 text-gray-400 mr-2" />
              <span className="text-gray-500">Created:</span>
              <span className="ml-2 font-medium">{formatDate(caseData.createdAt)}</span>
            </div>

            <div className="flex items-center text-sm">
              <Clock className="h-4 w-4 text-gray-400 mr-2" />
              <span className="text-gray-500">Last Updated:</span>
              <span className="ml-2 font-medium">{formatDate(caseData.updatedAt)}</span>
            </div>

            {caseData.dueDate && (
              <div className="flex items-center text-sm">
                <AlertTriangle className="h-4 w-4 text-gray-400 mr-2" />
                <span className="text-gray-500">Due Date:</span>
                <span className="ml-2 font-medium">{formatDate(caseData.dueDate)}</span>
              </div>
            )}
          </div>
        </div>

        {/* Resolution Info */}
        {(caseData.resolvedBy || caseData.resolvedAt || caseData.closedAt) && (
          <div className="border-t pt-4">
            <h4 className="text-sm font-medium text-gray-900 mb-3">Resolution</h4>
            <div className="space-y-2">
              {caseData.resolvedBy && (
                <div className="flex items-center text-sm">
                  <span className="text-gray-500">Resolved by:</span>
                  <span className="ml-2 font-medium">{caseData.resolvedBy}</span>
                </div>
              )}
              {caseData.resolvedAt && (
                <div className="flex items-center text-sm">
                  <span className="text-gray-500">Resolved at:</span>
                  <span className="ml-2 font-medium">{formatDate(caseData.resolvedAt)}</span>
                </div>
              )}
              {caseData.closedAt && (
                <div className="flex items-center text-sm">
                  <span className="text-gray-500">Closed at:</span>
                  <span className="ml-2 font-medium">{formatDate(caseData.closedAt)}</span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tags */}
        {caseData.tags && caseData.tags.length > 0 && (
          <div className="border-t pt-4">
            <h4 className="text-sm font-medium text-gray-900 mb-3">Tags</h4>
            <div className="flex flex-wrap gap-2">
              {caseData.tags.map((tag, index) => (
                <Badge key={index} variant="outline" className="text-xs">
                  <Tag className="h-3 w-3 mr-1" />
                  {tag}
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Counts */}
        <div className="border-t pt-4">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="flex items-center justify-between">
              <span className="text-gray-500">Notes:</span>
              <span className="font-medium">{caseData.notes?.length || 0}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-500">Attachments:</span>
              <span className="font-medium">{caseData.attachments?.length || 0}</span>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default CaseInfo;
