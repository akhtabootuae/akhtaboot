import React, { useState, useEffect } from 'react';
import { User } from 'lucide-react';
import { dataApi } from '@/services/api';

interface UserDisplayProps {
  assignedTo: string | any;
  className?: string;
}

export default function UserDisplay({ assignedTo, className = '' }: UserDisplayProps) {
  const [userInfo, setUserInfo] = useState<{
    name: string;
    loading: boolean;
  }>({ name: '', loading: false });

  useEffect(() => {
    if (!assignedTo) return;

    // If assignedTo is already a user object with name
    if (typeof assignedTo === 'object' && assignedTo.name) {
      setUserInfo({
        name: assignedTo.name || `${assignedTo.first_name || ''} ${assignedTo.last_name || ''}`.trim() || 'Unknown User',
        loading: false
      });
      return;
    }

    // If assignedTo is just an ObjectId string, fetch user data
    if (typeof assignedTo === 'string') {
      const fetchUserData = async () => {
        try {
          setUserInfo(prev => ({ ...prev, loading: true }));
          
          const response = await dataApi.getUserById(assignedTo) as any;
          
          if (response && response.success === false && response.status === 404) {
            // Handle user not found from structured response
            setUserInfo({
              name: 'Deleted User',
              loading: false
            });
          } else if (response) {
            // For successful responses, data is directly in response
            setUserInfo({
              name: response.name || `${response.first_name || ''} ${response.last_name || ''}`.trim() || 'Unknown User',
              loading: false
            });
          } else {
            // Fallback to showing truncated ID
            setUserInfo({
              name: `User (${assignedTo.substring(0, 8)}...)`,
              loading: false
            });
          }
        } catch (error: any) {
          console.error('Error fetching user data:', error);
          
          // Handle specific error cases
          let fallbackName = `User (${assignedTo.substring(0, 8)}...)`;
          
          if (error.status === 404 || error.response?.status === 404) {
            fallbackName = 'Deleted User';
          } else if (error.status === 401 || error.response?.status === 401) {
            fallbackName = 'Access Denied';
          }
          
          setUserInfo({
            name: fallbackName,
            loading: false
          });
        }
      };

      fetchUserData();
    }
  }, [assignedTo]);

  if (!assignedTo) return null;

  return (
    <div className={`flex items-center gap-1 ${className}`}>
      <User className="h-3 w-3" />
      Assigned to: {userInfo.loading ? 'Loading...' : userInfo.name}
    </div>
  );
}
