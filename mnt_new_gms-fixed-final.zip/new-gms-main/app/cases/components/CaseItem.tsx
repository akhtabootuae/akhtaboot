import React, { useState, useEffect, useRef } from 'react';
import { Case, CaseStatus, CasePriority } from '@/app/types/case';
import { Card } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { 
  Calendar, 
  User, 
  Tag, 
  Clock, 
  AlertTriangle,
  CheckCircle,
  XCircle,
  MoreHorizontal,
  Trash2,
  Eye,
  MessageSquare,
  Paperclip,
  Link as LinkIcon
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import Link from 'next/link';
import { caseApi } from '@/services/api';
import toast from 'react-hot-toast';

interface CaseItemProps {
  case: Case;
  onUpdate: (updatedCase: Case) => void;
  onDelete: (caseId: string) => void;
}

export default function CaseItem({ case: caseData, onUpdate, onDelete }: CaseItemProps) {
  const [showActions, setShowActions] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const actionsRef = useRef<HTMLDivElement>(null);

  // Close actions menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (actionsRef.current && !actionsRef.current.contains(event.target as Node)) {
        setShowActions(false);
      }
    };

    if (showActions) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showActions]);

  const getStatusColor = (status: CaseStatus) => {
    switch (status) {
      case 'open': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'in-progress': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'pending': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'resolved': return 'bg-green-100 text-green-800 border-green-200';
      case 'closed': return 'bg-gray-100 text-gray-800 border-gray-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getPriorityColor = (priority: CasePriority) => {
    switch (priority) {
      case 'low': return 'text-gray-600';
      case 'medium': return 'text-yellow-600';
      case 'high': return 'text-orange-600';
      case 'urgent': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const getPriorityIcon = (priority: CasePriority) => {
    switch (priority) {
      case 'urgent': return <AlertTriangle className="h-4 w-4" />;
      case 'high': return <AlertTriangle className="h-4 w-4" />;
      default: return <Clock className="h-4 w-4" />;
    }
  };

  const getStatusIcon = (status: CaseStatus) => {
    switch (status) {
      case 'resolved': return <CheckCircle className="h-4 w-4" />;
      case 'closed': return <XCircle className="h-4 w-4" />;
      default: return <Clock className="h-4 w-4" />;
    }
  };

  const handleDelete = async () => {
    if (!confirm('Are you sure you want to delete this case? This action cannot be undone.')) {
      return;
    }

    setIsDeleting(true);
    try {
      await caseApi.deleteCase(caseData._id);
      onDelete(caseData._id);
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to delete case');
    } finally {
      setIsDeleting(false);
    }
  };

  const isOverdue = caseData.dueDate && new Date(caseData.dueDate) < new Date() && 
                   !['resolved', 'closed'].includes(caseData.status);

  return (
    <>
      <Card className={`p-6 hover:shadow-lg transition-all duration-200 border border-gray-200 hover:border-gray-300 ${isOverdue ? 'border-l-4 border-l-red-500' : ''}`}>
        <div className="flex items-start justify-between">
          <div className="flex-1">
            {/* Header */}
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className={`flex items-center gap-1 px-2 py-1 rounded-full border text-xs font-medium ${getStatusColor(caseData.status)}`}>
                  {getStatusIcon(caseData.status)}
                  {caseData.status.replace('-', ' ')}
                </div>
                <div className={`flex items-center gap-1 text-xs font-medium ${getPriorityColor(caseData.priority)}`}>
                  {getPriorityIcon(caseData.priority)}
                  {caseData.priority}
                </div>
                {isOverdue && (
                  <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-red-100 text-red-800 text-xs font-medium">
                    <AlertTriangle className="h-3 w-3" />
                    Overdue
                  </div>
                )}
              </div>
              
              <div className="relative" ref={actionsRef}>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowActions(!showActions)}
                  className="h-8 w-8 p-0"
                >
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
                
                {showActions && (
                  <div className="absolute right-0 mt-2 w-48 bg-white border border-gray-200 rounded-md shadow-lg z-10">
                    <div className="py-1">
                      <Link href={`/cases/${caseData._id}`}>
                        <button className="flex items-center gap-2 w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                          <Eye className="h-4 w-4" />
                          View Details
                        </button>
                      </Link>
                      <button 
                        onClick={handleDelete}
                        disabled={isDeleting}
                        className="flex items-center gap-2 w-full px-4 py-2 text-sm text-red-600 hover:bg-red-50"
                      >
                        <Trash2 className="h-4 w-4" />
                        {isDeleting ? 'Deleting...' : 'Delete Case'}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Title and Description */}
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              <Link 
                href={`/cases/${caseData._id}`}
                className="hover:text-blue-600 transition-colors"
              >
                {caseData.title}
              </Link>
            </h3>
            
            <p className="text-gray-600 text-sm mb-3 line-clamp-2">
              {caseData.description}
            </p>

            {/* Metadata */}
            <div className="flex flex-wrap items-center gap-4 text-xs text-gray-500">
              <div className="flex items-center gap-1">
                <Clock className="h-3 w-3" />
                Created {formatDistanceToNow(new Date(caseData.createdAt), { addSuffix: true })}
              </div>
              
              {caseData.dueDate && (
                <div className={`flex items-center gap-1 ${isOverdue ? 'text-red-600' : ''}`}>
                  <Calendar className="h-3 w-3" />
                  Due {formatDistanceToNow(new Date(caseData.dueDate), { addSuffix: true })}
                </div>
              )}
              
              {caseData.assignedTo && (
                <div className="flex items-center gap-1">
                  <User className="h-3 w-3" />
                  Assigned to: {
                    typeof caseData.assignedTo === 'object' && (caseData.assignedTo as any).name
                      ? (caseData.assignedTo as any).name
                      : typeof caseData.assignedTo === 'string'
                      ? `User (${(caseData.assignedTo as string).substring(0, 8)}...)`
                      : 'Unknown User'
                  }
                </div>
              )}

              {caseData.linkedTo && (
                <div className="flex items-center gap-1">
                  <LinkIcon className="h-3 w-3" />
                  Linked to: {caseData.linkedTo.type} {caseData.linkedTo.reference && `(${caseData.linkedTo.reference})`}
                </div>
              )}

              {caseData.notes && caseData.notes.length > 0 && (
                <div className="flex items-center gap-1">
                  <MessageSquare className="h-3 w-3" />
                  {caseData.notes.length} notes
                </div>
              )}

              {caseData.attachments && caseData.attachments.length > 0 && (
                <div className="flex items-center gap-1">
                  <Paperclip className="h-3 w-3" />
                  {caseData.attachments.length} attachments
                </div>
              )}
            </div>

            {/* Tags */}
            {caseData.tags && caseData.tags.length > 0 && (
              <div className="flex flex-wrap gap-1 mt-3">
                {caseData.tags.map((tag, index) => (
                  <span 
                    key={index}
                    className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-gray-100 text-gray-700 text-xs"
                  >
                    <Tag className="h-3 w-3" />
                    {tag}
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>
      </Card>
    </>
  );
}
