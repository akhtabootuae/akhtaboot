import React, { useState, useEffect } from 'react';
import { dataApi } from '@/services/api';
import api from '@/services/api';
import { Button } from '@/app/components/ui/button';
import { X, DollarSign, Calendar, Plus, Minus } from 'lucide-react';
import toast from 'react-hot-toast';

interface EditInvoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  invoice: any;
  onUpdate: () => void;
}

export default function EditInvoiceModal({ isOpen, onClose, invoice, onUpdate }: EditInvoiceModalProps) {
  const [formData, setFormData] = useState({
    price: '',
    vat: '',
    invoice_date: '',
    expected_delivery_date: '',
    notes: '',
    real_value: '',
    ratio: ''
  });
  const [loading, setLoading] = useState(false);
  const [isAddTaxLoading, setIsAddTaxLoading] = useState(false);
  const [isRemoveTaxLoading, setIsRemoveTaxLoading] = useState(false);

  useEffect(() => {
    if (invoice && isOpen) {
      // Combine notes and special_requests when loading
      let combinedNotes = invoice.notes || '';
      if (invoice.special_requests && invoice.special_requests.trim() !== '') {
        if (combinedNotes) {
          combinedNotes += '\n\n' + invoice.special_requests;
        } else {
          combinedNotes = invoice.special_requests;
        }
      }

      setFormData({
        price: invoice.price?.toString() || '',
        vat: invoice.vat?.toString() || '',
        invoice_date: invoice.invoice_date ? new Date(invoice.invoice_date).toISOString().split('T')[0] : '',
        expected_delivery_date: invoice.expected_delivery_date ? new Date(invoice.expected_delivery_date).toISOString().split('T')[0] : '',
        notes: combinedNotes,
        real_value: invoice.real_value?.toString() || '',
        ratio: invoice.ratio?.toString() || ''
      });
    }
  }, [invoice, isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      setLoading(true);
      
      // Prepare update data - only include changed fields
      const updateData: any = {};
      
      // Check for changes in string fields
      const currentNotes = formData.notes.trim();
      // Check against the combined value we created on load
      let originalCombinedNotes = invoice.notes || '';
      if (invoice.special_requests && invoice.special_requests.trim() !== '') {
        if (originalCombinedNotes) {
          originalCombinedNotes += '\n\n' + invoice.special_requests;
        } else {
          originalCombinedNotes = invoice.special_requests;
        }
      }

      if (currentNotes !== originalCombinedNotes) {
        updateData.notes = currentNotes;
        // Clear special_requests as it's now part of notes
        updateData.special_requests = '';
      }
      
      // Check for changes in numeric fields
      if (formData.price !== '' && !isNaN(parseFloat(formData.price))) {
        const priceValue = parseFloat(formData.price);
        const originalPrice = parseFloat(invoice.price || 0);
        if (priceValue >= 0 && priceValue !== originalPrice) {
          updateData.price = priceValue;
        }
      }
      
      if (formData.vat !== '' && !isNaN(parseFloat(formData.vat))) {
        const vatValue = parseFloat(formData.vat);
        const originalVat = parseFloat(invoice.vat || 0);
        if (vatValue >= 0 && vatValue <= 100 && vatValue !== originalVat) {
          updateData.vat = vatValue;
        }
      }
      
      if (formData.real_value !== '' && !isNaN(parseFloat(formData.real_value))) {
        const realValueValue = parseFloat(formData.real_value);
        const originalRealValue = parseFloat(invoice.real_value || 0);
        if (realValueValue >= 0 && realValueValue !== originalRealValue) {
          updateData.real_value = realValueValue;
        }
      }
      
      if (formData.ratio !== '' && !isNaN(parseFloat(formData.ratio))) {
        const ratioValue = parseFloat(formData.ratio);
        const originalRatio = parseFloat(invoice.ratio || 0);
        if (ratioValue !== originalRatio) {
          updateData.ratio = ratioValue;
        }
      }
      
      // Check for changes in date fields
      const originalInvoiceDate = invoice.invoice_date ? new Date(invoice.invoice_date).toISOString().split('T')[0] : '';
      if (formData.invoice_date && formData.invoice_date !== originalInvoiceDate) {
        updateData.invoice_date = formData.invoice_date;
      }
      
      const originalExpectedDeliveryDate = invoice.expected_delivery_date ? new Date(invoice.expected_delivery_date).toISOString().split('T')[0] : '';
      if (formData.expected_delivery_date && formData.expected_delivery_date !== originalExpectedDeliveryDate) {
        updateData.expected_delivery_date = formData.expected_delivery_date;
      }

      // Check if there are any changes to update
      if (Object.keys(updateData).length === 0) {
        toast('No changes detected', { icon: 'ℹ️' });
        return;
      }

      // Use the new endpoint
      await dataApi.updateInvoiceInformation(invoice._id, updateData);
      onUpdate();
      onClose();
      toast.success('Invoice updated successfully');
    } catch (error: any) {
      console.error('Error updating invoice:', error.message);

      let errorMessage = 'Failed to update invoice';
      if (error.response?.data?.message) {
        errorMessage = error.response.data.message;
      } else if (error.response?.data?.error) {
        errorMessage = error.response.data.error;
      } else if (error.message) {
        errorMessage = error.message;
      }
      
      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const handleAddTax = async () => {
    try {
      if (!invoice._id) return;
      
      setIsAddTaxLoading(true);

      const result = await api.put(`/api/invoices/${invoice._id}/add-tax`);

      if (result) {
        onUpdate(); // Refresh the parent component data
        toast.success('Tax added successfully');
      }
    } catch (error) {
      console.error('Error adding tax:', error);
      toast.error('Failed to add tax. Please try again.');
    } finally {
      setIsAddTaxLoading(false);
    }
  };

  const handleRemoveTax = async () => {
    try {
      if (!invoice._id) return;
      
      const confirmRemove = window.confirm('Are you sure you want to remove tax from this invoice?');
      
      if (confirmRemove) {
        setIsRemoveTaxLoading(true);

        const result = await api.put(`/api/invoices/${invoice._id}/remove-tax`);

        if (result) {
          onUpdate(); // Refresh the parent component data
          toast.success('Tax removed successfully');
        }
      }
    } catch (error) {
      console.error('Error removing tax:', error);
      toast.error('Failed to remove tax. Please try again.');
    } finally {
      setIsRemoveTaxLoading(false);
    }
  };

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-blue-100 rounded-lg">
              <DollarSign className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Edit Invoice</h2>
              <p className="text-sm text-gray-600">Update invoice amounts and details</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Invoice Info */}
          <div className="bg-blue-50 rounded-lg p-4">
            <h3 className="text-sm font-medium text-blue-900 mb-2">Invoice Information</h3>
            <div className="text-sm">
              <span className="text-blue-700">Invoice Number:</span>
              <span className="ml-2 font-medium text-blue-900">{invoice.invoice_number}</span>
            </div>
          </div>

          {/* Financial Details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Price */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Price ($)
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                value={formData.price}
                onChange={(e) => handleInputChange('price', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="0.00"
              />
            </div>

            {/* VAT Percentage */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                VAT (%)
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                max="100"
                value={formData.vat}
                onChange={(e) => handleInputChange('vat', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="0.00"
              />
            </div>

            {/* Real Value */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Real Value ($)
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                value={formData.real_value}
                onChange={(e) => handleInputChange('real_value', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="0.00"
              />
            </div>

            {/* Ratio */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Ratio
              </label>
              <input
                type="number"
                step="0.01"
                value={formData.ratio}
                onChange={(e) => handleInputChange('ratio', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="1.0"
              />
            </div>
          </div>

          {/* Tax Actions */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h3 className="text-sm font-medium text-gray-700 mb-3">Tax Management</h3>
            <div className="flex gap-3">
              <button
                type="button"
                className={`bg-orange-600 text-white hover:bg-orange-700 px-4 py-2 rounded-md flex items-center ${isAddTaxLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
                onClick={handleAddTax}
                disabled={isAddTaxLoading}
              >
                {isAddTaxLoading ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Adding Tax...
                  </>
                ) : (
                  <>
                    <Plus className="h-4 w-4 mr-1.5" />
                    Add Tax
                  </>
                )}
              </button>
              
              <button
                type="button"
                className={`bg-red-600 text-white hover:bg-red-700 px-4 py-2 rounded-md flex items-center ${isRemoveTaxLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
                onClick={handleRemoveTax}
                disabled={isRemoveTaxLoading}
              >
                {isRemoveTaxLoading ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Removing Tax...
                  </>
                ) : (
                  <>
                    <Minus className="h-4 w-4 mr-1.5" />
                    Remove Tax
                  </>
                )}
              </button>
            </div>
            <p className="text-xs text-gray-500 mt-2">
              Current status: {invoice?.isTaxed ? 'Taxed' : 'Not Taxed'}
            </p>
          </div>

          {/* Dates */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Invoice Date */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Invoice Date
              </label>
              <div className="relative">
                <input
                  type="date"
                  value={formData.invoice_date}
                  onChange={(e) => handleInputChange('invoice_date', e.target.value)}
                  className="w-full px-3 py-2 pl-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
                <Calendar className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
              </div>
            </div>

            {/* Expected Delivery Date */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Expected Delivery Date
              </label>
              <div className="relative">
                <input
                  type="date"
                  value={formData.expected_delivery_date}
                  onChange={(e) => handleInputChange('expected_delivery_date', e.target.value)}
                  className="w-full px-3 py-2 pl-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
                <Calendar className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
              </div>
            </div>
          </div>

          {/* Notes (includes special requests) */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Notes
            </label>
            <textarea
              value={formData.notes}
              onChange={(e) => handleInputChange('notes', e.target.value)}
              rows={4}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Add any notes, comments, or special requirements..."
            />
          </div>

          {/* Actions */}
          <div className="flex justify-end space-x-3 pt-4 border-t border-gray-200">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={loading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={loading}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Updating...
                </>
              ) : (
                'Update Invoice'
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
