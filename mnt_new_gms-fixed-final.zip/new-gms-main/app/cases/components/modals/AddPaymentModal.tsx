import React, { useState } from 'react';
import { dataApi } from '@/services/api';
import { Button } from '@/app/components/ui/button';
import { X, CreditCard, DollarSign, Calendar } from 'lucide-react';
import toast from 'react-hot-toast';

interface AddPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  invoice: any;
  amountDue: number;
  onPaymentAdded: () => void;
}

export default function AddPaymentModal({ 
  isOpen, 
  onClose, 
  invoice, 
  amountDue, 
  onPaymentAdded 
}: AddPaymentModalProps) {
  const [formData, setFormData] = useState({
    amount: '',
    payment_method: '',
    payment_date: new Date().toISOString().split('T')[0],
    notes: ''
  });
  const [loading, setLoading] = useState(false);

  const paymentMethods = [
    'Cash',
    'Credit Card',
    'Debit Card',
    'Bank Transfer',
    'Check',
    'PayPal',
    'Stripe',
    'Other'
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.amount || !formData.payment_method) {
      toast.error('Please fill in all required fields');
      return;
    }

    const amount = parseFloat(formData.amount);
    if (amount === 0 || isNaN(amount)) {
      toast.error('Payment amount cannot be zero or invalid');
      return;
    }

    // Allow negative payments (refunds/adjustments) but warn for positive payments exceeding amount due
    if (amount > 0 && amount > amountDue) {
      toast.error(`Payment amount cannot exceed amount due (${formatCurrency(amountDue)})`);
      return;
    }

    try {
      setLoading(true);
      
      const paymentData = {
        amount: amount,
        payment_method: formData.payment_method,
        payment_date: formData.payment_date,
        notes: formData.notes.trim() || null
      };

      await dataApi.addPaymentRecord(invoice._id, paymentData);
      onPaymentAdded();
      onClose();
      
      // Reset form
      setFormData({
        amount: '',
        payment_method: '',
        payment_date: new Date().toISOString().split('T')[0],
        notes: ''
      });
      
      toast.success('Payment added successfully');
    } catch (error: any) {
      console.error('Error adding payment:', error);
      toast.error(error.response?.data?.message || 'Failed to add payment');
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-AE', {
      style: 'currency',
      currency: 'AED'
    }).format(amount || 0);
  };

  const setFullAmount = () => {
    setFormData(prev => ({
      ...prev,
      amount: amountDue.toFixed(2)
    }));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-green-100 rounded-lg">
              <CreditCard className="h-6 w-6 text-green-600" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Add Payment</h2>
              <p className="text-sm text-gray-600">Record a new payment for this invoice</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Invoice Info */}
          <div className="bg-blue-50 rounded-lg p-4">
            <h3 className="text-sm font-medium text-blue-900 mb-2">Invoice Details</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-blue-700">Invoice Number:</span>
                <span className="font-medium text-blue-900">{invoice.invoice_number}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-blue-700">Total Amount:</span>
                <span className="font-medium text-blue-900">{formatCurrency(invoice.total)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-blue-700">Amount Due:</span>
                <span className="font-bold text-red-600">{formatCurrency(amountDue)}</span>
              </div>
            </div>
          </div>

          {/* Payment Amount */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Payment Amount (AED) *
            </label>
            <div className="relative">
              <input
                type="number"
                step="0.01"
                value={formData.amount}
                onChange={(e) => handleInputChange('amount', e.target.value)}
                className="w-full px-3 py-2 pl-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 font-semibold"
                placeholder="0.00"
                required
              />
              <DollarSign className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>
            <div className="mt-2 flex justify-between text-sm">
              <span className="text-gray-500">
                Amount due: {formatCurrency(amountDue)} • Negative values allowed for refunds
              </span>
              <button
                type="button"
                onClick={setFullAmount}
                className="text-green-600 hover:text-green-700 font-medium"
              >
                Pay in full
              </button>
            </div>
          </div>

          {/* Payment Method */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Payment Method *
            </label>
            <select
              value={formData.payment_method}
              onChange={(e) => handleInputChange('payment_method', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
              required
            >
              <option value="">Select payment method</option>
              {paymentMethods.map((method) => (
                <option key={method} value={method}>
                  {method}
                </option>
              ))}
            </select>
          </div>

          {/* Payment Date */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Payment Date
            </label>
            <div className="relative">
              <input
                type="date"
                value={formData.payment_date}
                onChange={(e) => handleInputChange('payment_date', e.target.value)}
                className="w-full px-3 py-2 pl-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                required
              />
              <Calendar className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Notes
            </label>
            <textarea
              value={formData.notes}
              onChange={(e) => handleInputChange('notes', e.target.value)}
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
              placeholder="Add any payment notes or reference numbers..."
            />
          </div>

          {/* Summary */}
          <div className="bg-green-50 rounded-lg p-4">
            <h4 className="text-sm font-medium text-green-900 mb-2">Payment Summary</h4>
            <div className="space-y-1 text-sm">
              <div className="flex justify-between">
                <span className="text-green-700">Payment Amount:</span>
                <span className="font-bold text-green-900">
                  {formData.amount ? formatCurrency(parseFloat(formData.amount)) : 'AED 0.00'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-green-700">Remaining Balance:</span>
                <span className="font-medium text-green-900">
                  {formData.amount 
                    ? formatCurrency(amountDue - parseFloat(formData.amount || '0'))
                    : formatCurrency(amountDue)
                  }
                </span>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex justify-end space-x-3 pt-4 border-t border-gray-200">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={loading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={loading}
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Adding Payment...
                </>
              ) : (
                'Add Payment'
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
