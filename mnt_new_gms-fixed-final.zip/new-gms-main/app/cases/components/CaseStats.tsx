import React from 'react';
import { CaseStats, CaseFilters } from '@/app/types/case';
import { Card } from '@/app/components/ui/card';
import { 
  FileText, 
  Clock, 
  XCircle, 
  AlertTriangle 
} from 'lucide-react';

interface CaseStatsProps {
  stats: CaseStats;
  onFilterClick?: (filter: Partial<CaseFilters>) => void;
  activeFilters?: CaseFilters;
}

export default function CaseStatsComponent({ stats, onFilterClick, activeFilters }: CaseStatsProps) {
  const statCards = [
    {
      title: 'Total Cases',
      value: stats.total,
      icon: <FileText className="h-6 w-6" />,
      color: 'bg-blue-500',
      textColor: 'text-blue-600',
      filter: {}, // Clear all filters to show all cases
      isActive: !activeFilters?.status && !activeFilters?.priority && !activeFilters?.overdue
    },
    {
      title: 'Open',
      value: stats.open,
      icon: <Clock className="h-6 w-6" />,
      color: 'bg-yellow-500',
      textColor: 'text-yellow-600',
      filter: { status: 'open' as const },
      isActive: activeFilters?.status === 'open'
    },
    {
      title: 'Urgent',
      value: stats.urgent,
      icon: <AlertTriangle className="h-6 w-6" />,
      color: 'bg-red-500',
      textColor: 'text-red-600',
      filter: { priority: 'urgent' as const },
      isActive: activeFilters?.priority === 'urgent'
    },
    {
      title: 'Overdue',
      value: stats.overdue,
      icon: <XCircle className="h-6 w-6" />,
      color: 'bg-red-600',
      textColor: 'text-red-700',
      filter: { 
        // For overdue, we need a custom filter - we'll handle this in the parent component
        overdue: true 
      },
      isActive: activeFilters?.overdue === true
    }
  ];

  const handleCardClick = (filter: any) => {
    if (onFilterClick) {
      onFilterClick(filter);
    }
  };

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      {statCards.map((stat, index) => (
        <Card 
          key={index} 
          className={`p-4 transition-all duration-200 cursor-pointer transform hover:scale-105 border-l-4 ${
            stat.isActive 
              ? `border-l-blue-500 shadow-lg bg-blue-50 ${stat.color.replace('bg-', 'border-')}` 
              : 'border-l-gray-200 hover:border-l-blue-500 hover:shadow-lg'
          }`}
          onClick={() => handleCardClick(stat.filter)}
        >
          <div className="flex flex-col space-y-2">
            <div className="flex items-center justify-between">
              <div className={`p-2 rounded-lg ${stat.color} text-white shadow-sm`}>
                {stat.icon}
              </div>
              <div className="text-right">
                <p className={`text-2xl font-bold ${stat.textColor} ${stat.isActive ? 'text-blue-700' : ''}`}>
                  {stat.value || 0}
                </p>
              </div>
            </div>
            <div>
              <p className={`text-sm font-medium truncate ${stat.isActive ? 'text-blue-700' : 'text-gray-600'}`} title={stat.title}>
                {stat.title}
              </p>
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
}
