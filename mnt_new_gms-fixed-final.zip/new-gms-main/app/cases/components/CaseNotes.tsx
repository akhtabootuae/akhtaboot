// filepath: /app/cases/components/CaseNotes.tsx
'use client';

import React, { useState } from 'react';
import { Case, CaseNote } from '@/app/types/case';
import { Card } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Badge } from '@/app/components/ui/badge';
import { notificationsApi } from '@/services/api';
import { 
  MessageSquare, 
  Plus, 
  Clock,
  Save,
  X
} from 'lucide-react';

interface CaseNotesProps {
  case: Case;
  notes?: CaseNote[];
  onAddNote?: (content: string, isInternal: boolean) => Promise<void>;
}

const CaseNotes: React.FC<CaseNotesProps> = ({ 
  case: caseData, 
  notes = caseData.notes || [], 
  onAddNote
}) => {
  const [isAddingNote, setIsAddingNote] = useState(false);
  const [newNoteContent, setNewNoteContent] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const formatDate = (date: Date | string) => {
    const dateObj = date instanceof Date ? date : new Date(date);
    return {
      date: dateObj.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric'
      }),
      time: dateObj.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit'
      })
    };
  };

  const handleAddNote = async () => {
    if (!newNoteContent.trim() || !onAddNote) return;
    
    setIsSubmitting(true);
    try {
      await onAddNote(newNoteContent, false);
      
      // Create notification for case note added
      try {
        await notificationsApi.createCaseNoteNotification(caseData._id, newNoteContent);
      } catch (notificationError) {
        console.error('Failed to create notification for case note:', notificationError);
        // Don't fail the entire operation if notification creation fails
      }
      
      setNewNoteContent('');
      setIsAddingNote(false);
    } catch (error) {
      console.error('Failed to add note:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const sortedNotes = [...notes].sort(
    (a, b) => new Date(b.addedAt).getTime() - new Date(a.addedAt).getTime()
  );

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-2">
          <h3 className="text-lg font-semibold">Notes</h3>
          <Badge variant="outline" className="text-xs">
            {notes.length}
          </Badge>
        </div>
        
        {onAddNote && (
          <Button
            onClick={() => setIsAddingNote(true)}
            disabled={isAddingNote}
            size="sm"
            className="text-sm"
          >
            <Plus className="h-4 w-4 mr-1" />
            Add Note
          </Button>
        )}
      </div>

      {/* Add Note Form */}
      {isAddingNote && (
        <div className="mb-6 p-4 border rounded-lg bg-gray-50">
          <div className="space-y-3">
            <textarea
              value={newNoteContent}
              onChange={(e) => setNewNoteContent(e.target.value)}
              placeholder="Enter your note..."
              className="w-full p-3 border rounded-md resize-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              rows={4}
            />
            
            <div className="flex justify-end space-x-2">
              <Button
                onClick={() => {
                  setIsAddingNote(false);
                  setNewNoteContent('');
                }}
                variant="outline"
                size="sm"
                disabled={isSubmitting}
              >
                <X className="h-4 w-4 mr-1" />
                Cancel
              </Button>
              <Button
                onClick={handleAddNote}
                size="sm"
                disabled={!newNoteContent.trim() || isSubmitting}
              >
                <Save className="h-4 w-4 mr-1" />
                {isSubmitting ? 'Adding...' : 'Add Note'}
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Notes List */}
      <div className="space-y-4">
        {sortedNotes.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <MessageSquare className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p>No notes added yet</p>
            <p className="text-sm">Add a note to track case progress</p>
          </div>
        ) : (
          sortedNotes.map((note, index) => {
            const { date, time } = formatDate(note.addedAt);
            
            return (
              <div key={index} className="border rounded-lg p-4 bg-white">
                <div className="flex items-start justify-between mb-2">
                  <div className="text-xs text-gray-500 flex items-center space-x-1">
                    <Clock className="h-3 w-3" />
                    <span>{date} at {time}</span>
                  </div>
                </div>
                
                <p className="text-sm text-gray-700 whitespace-pre-wrap">
                  {note.content}
                </p>
              </div>
            );
          })
        )}
      </div>
    </Card>
  );
};

export default CaseNotes;
