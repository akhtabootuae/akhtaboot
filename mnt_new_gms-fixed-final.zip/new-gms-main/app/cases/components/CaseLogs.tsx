'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { Case } from '@/app/types/case';
import { Card } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Badge } from '@/app/components/ui/badge';
import { 
  Shield,
  Clock,
  User,
  FileText,
  Download,
  Search,
  Filter,
  Calendar,
  AlertTriangle,
  Info,
  CheckCircle,
  XCircle
} from 'lucide-react';
import { caseApi } from '@/services/api';
import toast from 'react-hot-toast';

interface CaseLogsProps {
  case: Case;
  userRole?: string;
}

interface CaseLog {
  _id: string;
  user_id: string;
  user_email: string;
  action: string;
  entity_type: string;
  entity_id: string;
  details: any;
  timestamp: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  category: string;
  success: boolean;
  ip_address?: string;
  user_agent?: string;
}

export default function CaseLogs({ case: caseData, userRole }: CaseLogsProps) {
  const [logs, setLogs] = useState<CaseLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState({
    action: '',
    severity: '',
    category: '',
    dateRange: '7d'
  });
  const [searchTerm, setSearchTerm] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  // Check if user has admin permissions
  const isAdmin = userRole === 'Admin' || userRole === 'admin';

  const fetchLogs = async () => {
    if (!isAdmin) return;
    
    try {
      setLoading(true);
      setError(null);
      
      const params = {
        entity_id: caseData._id,
        entity_type: 'case',
        page,
        limit: 20,
        ...filter,
        search: searchTerm
      };

      const data = await caseApi.getSpecificCaseLogs(caseData._id, params) as any;
      
      if (data?.success) {
        setLogs(data.data || []);
        setTotalPages(data.pagination?.total_pages || 1);
      } else {
        setError('Failed to fetch case logs');
      }
    } catch (err: any) {
      console.error('Error fetching case logs:', err);
      setError(err.response?.data?.message || 'Failed to fetch case logs');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isAdmin) {
      fetchLogs();
    }
  }, [isAdmin, caseData._id, filter, searchTerm, page]);

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-100 text-red-800 border-red-200';
      case 'high': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getActionIcon = (action: string) => {
    if (action.includes('create')) return <FileText className="h-4 w-4" />;
    if (action.includes('update') || action.includes('edit')) return <FileText className="h-4 w-4" />;
    if (action.includes('delete')) return <XCircle className="h-4 w-4" />;
    if (action.includes('view') || action.includes('read')) return <FileText className="h-4 w-4" />;
    if (action.includes('assign')) return <User className="h-4 w-4" />;
    return <Info className="h-4 w-4" />;
  };

  const formatTimestamp = (timestamp: string) => {
    return new Date(timestamp).toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  const handleExport = async () => {
    try {
      const params = {
        entity_id: caseData._id,
        format: 'csv',
        ...filter
      };

      const response = await caseApi.exportCaseLogs(params);
      
      // Handle the response - it should be a string (CSV data) or an object with data property
      let csvData: string = '';
      
      if (typeof response === 'string') {
        csvData = response;
      } else if (response && typeof (response as any).data === 'string') {
        csvData = (response as any).data;
      } else {
        toast.error('Export data format not recognized');
        return;
      }
      
      // Create and download the CSV file
      const blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      
      link.setAttribute('href', url);
      link.setAttribute('download', `case_${caseData._id}_logs_${new Date().toISOString().slice(0, 10)}.csv`);
      link.style.visibility = 'hidden';
      
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      URL.revokeObjectURL(url);
      toast.success('Case logs exported successfully');
    } catch (err: any) {
      console.error('Export error:', err);
      toast.error('Failed to export case logs');
    }
  };

  if (!isAdmin) {
    return null; // Don't render for non-admin users
  }

  if (loading) {
    return (
      <Card className="p-6">
        <div className="flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          <span className="ml-2">Loading case logs...</span>
        </div>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="p-6">
        <div className="flex items-center text-red-600">
          <AlertTriangle className="h-5 w-5 mr-2" />
          <span>{error}</span>
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <Shield className="h-5 w-5 text-blue-600 mr-2" />
          <h3 className="text-lg font-semibold">Case Audit Logs</h3>
          <Badge variant="outline" className="ml-2">
            Admin Only
          </Badge>
        </div>
        <Button
          variant="outline"
          onClick={handleExport}
          className="flex items-center gap-2"
        >
          <Download className="h-4 w-4" />
          Export
        </Button>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Search
          </label>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <input
              type="text"
              placeholder="Search actions, users..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 border rounded-md w-full text-sm"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Severity
          </label>
          <select
            value={filter.severity}
            onChange={(e) => setFilter({ ...filter, severity: e.target.value })}
            className="w-full px-3 py-2 border rounded-md text-sm"
          >
            <option value="">All Severities</option>
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
            <option value="critical">Critical</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Category
          </label>
          <select
            value={filter.category}
            onChange={(e) => setFilter({ ...filter, category: e.target.value })}
            className="w-full px-3 py-2 border rounded-md text-sm"
          >
            <option value="">All Categories</option>
            <option value="data_access">Data Access</option>
            <option value="data_modification">Data Modification</option>
            <option value="case_management">Case Management</option>
            <option value="user_action">User Action</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Date Range
          </label>
          <select
            value={filter.dateRange}
            onChange={(e) => setFilter({ ...filter, dateRange: e.target.value })}
            className="w-full px-3 py-2 border rounded-md text-sm"
          >
            <option value="1d">Last 24 Hours</option>
            <option value="7d">Last 7 Days</option>
            <option value="30d">Last 30 Days</option>
            <option value="90d">Last 90 Days</option>
          </select>
        </div>
      </div>

      {/* Logs List */}
      <div className="space-y-3">
        {logs.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <Shield className="h-12 w-12 text-gray-300 mx-auto mb-4" />
            <p>No audit logs found for this case</p>
          </div>
        ) : (
          logs.map((log) => (
            <div
              key={log._id}
              className="flex items-start space-x-4 p-4 bg-gray-50 rounded-lg border"
            >
              <div className={`flex-shrink-0 p-2 rounded-lg ${log.success ? 'bg-green-100' : 'bg-red-100'}`}>
                {log.success ? (
                  <CheckCircle className="h-4 w-4 text-green-600" />
                ) : (
                  <XCircle className="h-4 w-4 text-red-600" />
                )}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    {getActionIcon(log.action)}
                    <span className="font-medium text-gray-900">{log.action.replace(/_/g, ' ').toUpperCase()}</span>
                    <Badge className={getSeverityColor(log.severity)}>
                      {log.severity}
                    </Badge>
                  </div>
                  <span className="text-sm text-gray-500">
                    {formatTimestamp(log.timestamp)}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-500">User:</span>
                    <span className="ml-2 font-medium">{log.user_email}</span>
                  </div>
                  <div>
                    <span className="text-gray-500">Category:</span>
                    <span className="ml-2">{log.category.replace(/_/g, ' ')}</span>
                  </div>
                </div>

                {log.details && Object.keys(log.details).length > 0 && (
                  <div className="mt-3 p-3 bg-white rounded border">
                    <span className="text-xs font-medium text-gray-500 uppercase tracking-wide">Details:</span>
                    <pre className="text-xs text-gray-700 mt-1 whitespace-pre-wrap">
                      {JSON.stringify(log.details, null, 2)}
                    </pre>
                  </div>
                )}

                {log.ip_address && (
                  <div className="mt-2 text-xs text-gray-500">
                    IP: {log.ip_address}
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between mt-6">
          <Button
            variant="outline"
            disabled={page === 1}
            onClick={() => setPage(page - 1)}
          >
            Previous
          </Button>
          <span className="text-sm text-gray-600">
            Page {page} of {totalPages}
          </span>
          <Button
            variant="outline"
            disabled={page === totalPages}
            onClick={() => setPage(page + 1)}
          >
            Next
          </Button>
        </div>
      )}
    </Card>
  );
}
