import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Case } from '@/app/types/case';
import { dataApi } from '@/services/api';
import { Button } from '@/app/components/ui/button';
import { 
  CreditCard, 
  Edit, 
  FileText,
  Plus,
  ExternalLink
} from 'lucide-react';
import Link from 'next/link';
import toast from 'react-hot-toast';
import EditInvoiceModal from './modals/EditInvoiceModal';
import AddPaymentModal from './modals/AddPaymentModal';

interface InvoiceActionsProps {
  case: Case;
  onInvoiceUpdate?: () => void;
}

export default function InvoiceActions({ case: caseData, onInvoiceUpdate }: InvoiceActionsProps) {
  const [invoice, setInvoice] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [isPrintLoading, setIsPrintLoading] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);

  // Only show this component if the case is linked to an invoice
  if (!caseData.linkedTo || caseData.linkedTo.type !== 'invoice') {
    return null;
  }

  const fetchInvoice = async () => {
    if (!caseData.linkedTo?.reference) return;
    
    try {
      setLoading(true);
      const response = await dataApi.getInvoiceByNumber(caseData.linkedTo.reference);
      setInvoice(response);
    } catch (error: any) {
      console.error('Error fetching invoice:', error);
      toast.error('Failed to load invoice details');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchInvoice();
  }, [caseData.linkedTo?.reference]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-AE', {
      style: 'currency',
      currency: 'AED'
    }).format(amount || 0);
  };

  const getStatusColor = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'paid':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'partial':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'unpaid':
      case 'pending':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const handleInvoiceUpdate = () => {
    fetchInvoice();
    if (onInvoiceUpdate) {
      onInvoiceUpdate();
    }
    toast.success('Invoice updated successfully');
  };

  const handlePrint = async () => {
    try {
      if (!invoice?._id) return;
      
      setIsPrintLoading(true);

      // Use axios directly to get the blob response for PDF download
      const response = await axios.get(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000'}/api/invoices/${invoice._id}/pdf`, {
        responseType: 'blob',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('authToken')}`,
        }
      });
      
      if (response.data) {
        // Create a blob URL and trigger download
        const blob = new Blob([response.data], { type: 'application/pdf' });
        const url = window.URL.createObjectURL(blob);
        
        // Create a temporary link to trigger download
        const link = document.createElement('a');
        link.href = url;
        link.download = `invoice-${invoice.invoice_number || invoice._id}.pdf`;
        document.body.appendChild(link);
        link.click();
        
        // Clean up
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
        
        toast.success('Invoice PDF downloaded successfully');
      }
    } catch (error) {
      console.error('Error generating PDF:', error);
      toast.error('Failed to generate PDF. Please try again.');
    } finally {
      setIsPrintLoading(false);
    }
  };

  const handlePaymentAdded = () => {
    fetchInvoice();
    if (onInvoiceUpdate) {
      onInvoiceUpdate();
    }
    toast.success('Payment added successfully');
  };

  if (loading) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      </div>
    );
  }

  if (!invoice) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="text-center py-8">
          <FileText className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-sm font-medium text-gray-900">Invoice not found</h3>
          <p className="mt-1 text-sm text-gray-500">
            The linked invoice could not be loaded.
          </p>
        </div>
      </div>
    );
  }

  const amountPaid = invoice.payment_records?.reduce((sum: number, payment: any) => sum + (payment.amount || 0), 0) || 0;
  const amountDue = (invoice.total || 0) - amountPaid;

  return (
    <>
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-200 bg-blue-50">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <FileText className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Linked Invoice</h3>
                <p className="text-sm text-gray-600">Manage invoice details and payments</p>
              </div>
            </div>
            <Link 
              href={`/Invoices/${invoice._id}`}
              className="flex items-center gap-2 text-blue-600 hover:text-blue-700 text-sm font-medium transition-colors"
            >
              <ExternalLink className="h-4 w-4" />
              View Full Invoice
            </Link>
          </div>
        </div>

        {/* Invoice Summary */}
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            {/* Invoice Basic Info */}
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-500">Invoice Number</label>
                <p className="text-lg font-semibold text-gray-900">{invoice.invoice_number}</p>
              </div>
              
              <div>
                <label className="text-sm font-medium text-gray-500">Status</label>
                <div className="mt-1">
                  <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium border ${getStatusColor(invoice.payment_status)}`}>
                    {invoice.payment_status || 'Pending'}
                  </span>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-500">Customer</label>
                <p className="text-base text-gray-900">
                  {invoice.customer_info?.name || 'Unknown Customer'}
                </p>
              </div>
            </div>

            {/* Financial Summary */}
            <div className="space-y-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Total Amount:</span>
                    <span className="text-lg font-bold text-gray-900">{formatCurrency(invoice.total)}</span>
                  </div>
                  
                  {amountPaid > 0 && (
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Amount Paid:</span>
                      <span className="text-sm font-medium text-green-600">{formatCurrency(amountPaid)}</span>
                    </div>
                  )}
                  
                  {amountDue > 0 && (
                    <div className="flex justify-between pt-2 border-t border-gray-200">
                      <span className="text-sm font-medium text-gray-900">Balance Due:</span>
                      <span className="text-lg font-bold text-red-600">{formatCurrency(amountDue)}</span>
                    </div>
                  )}
                  
                  {amountDue <= 0 && amountPaid > 0 && (
                    <div className="flex justify-between pt-2 border-t border-gray-200">
                      <span className="text-sm font-medium text-gray-900">Status:</span>
                      <span className="text-sm font-bold text-green-600">Fully Paid</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Dates */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-500">Invoice Date</label>
                  <p className="text-sm text-gray-900">
                    {invoice.invoice_date ? new Date(invoice.invoice_date).toLocaleDateString() : 'N/A'}
                  </p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Due Date</label>
                  <p className="text-sm text-gray-900">
                    {invoice.due_date ? new Date(invoice.due_date).toLocaleDateString() : 'N/A'}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap gap-3 pt-4 border-t border-gray-200">
            <Button
              onClick={() => setShowEditModal(true)}
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white"
            >
              <Edit className="h-4 w-4" />
              Edit Invoice
            </Button>

            {amountDue > 0 && (
              <Button
                onClick={() => setShowPaymentModal(true)}
                className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white"
              >
                <Plus className="h-4 w-4" />
                Add Payment
              </Button>
            )}

            <Button
              variant="outline"
              className="flex items-center gap-2"
              onClick={handlePrint}
              disabled={isPrintLoading}
            >
              {isPrintLoading ? (
                <>
                  <svg className="animate-spin h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Generating PDF...
                </>
              ) : (
                <>
                  <FileText className="h-4 w-4" />
                  Print Invoice
                </>
              )}
            </Button>
          </div>

          {/* Recent Payments */}
          {invoice.payment_records && invoice.payment_records.length > 0 && (
            <div className="mt-6 pt-4 border-t border-gray-200">
              <h4 className="text-sm font-medium text-gray-900 mb-3">Recent Payments</h4>
              <div className="space-y-2">
                {invoice.payment_records.slice(-3).map((payment: any, index: number) => (
                  <div key={index} className="flex justify-between items-center py-2 px-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <CreditCard className="h-4 w-4 text-gray-500" />
                      <div>
                        <span className="text-sm font-medium text-gray-900">
                          {formatCurrency(payment.amount)}
                        </span>
                        <span className="text-sm text-gray-500 ml-2">
                          via {payment.payment_method}
                        </span>
                      </div>
                    </div>
                    <span className="text-xs text-gray-500">
                      {payment.payment_date ? new Date(payment.payment_date).toLocaleDateString() : 'Recent'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Edit Invoice Modal */}
      {showEditModal && (
        <EditInvoiceModal
          isOpen={showEditModal}
          onClose={() => setShowEditModal(false)}
          invoice={invoice}
          onUpdate={handleInvoiceUpdate}
        />
      )}

      {/* Add Payment Modal */}
      {showPaymentModal && (
        <AddPaymentModal
          isOpen={showPaymentModal}
          onClose={() => setShowPaymentModal(false)}
          invoice={invoice}
          amountDue={amountDue}
          onPaymentAdded={handlePaymentAdded}
        />
      )}
    </>
  );
}
