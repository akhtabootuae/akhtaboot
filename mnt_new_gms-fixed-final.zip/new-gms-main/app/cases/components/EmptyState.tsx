import React from 'react';
import { Button } from '@/app/components/ui/button';
import { Card } from '@/app/components/ui/card';
import { FileText, Plus, Search } from 'lucide-react';

interface EmptyStateProps {
  hasFilters?: boolean;
  onCreateCase?: () => void;
  onClearFilters?: () => void;
}

export default function EmptyState({ 
  hasFilters = false, 
  onCreateCase, 
  onClearFilters 
}: EmptyStateProps) {
  if (hasFilters) {
    return (
      <Card className="p-12 text-center">
        <Search className="h-16 w-16 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-gray-900 mb-2">
          No cases match your filters
        </h3>
        <p className="text-gray-600 mb-6">
          Try adjusting your search criteria or filters to find cases.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          {onClearFilters && (
            <Button
              variant="outline"
              onClick={onClearFilters}
              className="flex items-center gap-2"
            >
              Clear Filters
            </Button>
          )}
          {onCreateCase && (
            <Button
              onClick={onCreateCase}
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700"
            >
              <Plus className="h-4 w-4" />
              Create New Case
            </Button>
          )}
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-12 text-center">
      <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
      <h3 className="text-lg font-semibold text-gray-900 mb-2">
        No cases yet
      </h3>
      <p className="text-gray-600 mb-6">
        Get started by creating your first case to track issues and support requests.
      </p>
      {onCreateCase && (
        <Button
          onClick={onCreateCase}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 mx-auto"
        >
          <Plus className="h-4 w-4" />
          Create Your First Case
        </Button>
      )}
    </Card>
  );
}
