// Shared types for dropdown components
export interface Option {
  id: string;
  label: string;
  subtitle?: string;
}
