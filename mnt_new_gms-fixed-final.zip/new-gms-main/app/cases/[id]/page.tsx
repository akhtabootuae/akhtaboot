'use client';

import React, { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import ProtectedRoute from '@/components/ProtectedRoute';
import { Case } from '@/app/types/case';
import { caseApi } from '@/services/api';
import CaseHeader from '../components/CaseHeader';
import CaseNotes from '../components/CaseNotes';
import CaseAttachments from '../components/CaseAttachments.new';
import CaseLogs from '../components/CaseLogs';
import InvoiceActions from '../components/InvoiceActions';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorMessage from '../components/ErrorMessage';
import { useAuth } from '@/app/context/AuthContext';
import toast from 'react-hot-toast';
import { 
  FileText, 
  Paperclip, 
  MessageSquare, 
  Activity, 
  DollarSign,
  Eye,
  Clock,
  User,
  Calendar
} from 'lucide-react';

export default function CaseDetailPage() {
  const params = useParams();
  const router = useRouter();
  const { user } = useAuth();
  const caseId = params.id as string;
  
  const [caseData, setCaseData] = useState<Case | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('overview');

  // Fetch case data
  const fetchCase = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await caseApi.getCaseById(caseId) as any;

      if (response && response.success) {
        setCaseData(response.data);
      } else {
        setError('Failed to load case data');
        console.error('Case response missing success property:', response);
      }
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to fetch case');
      console.error('Error fetching case:', err);
    } finally {
      setLoading(false);
    }
  };

  // Handle case update with auto-refresh for resolved/closed status
  const handleCaseUpdate = async (updatedCase: Case) => {
    if (!caseData) return;
    
    try {
      setCaseData(updatedCase);
      
      // Auto-refresh page if status changed to resolved or closed
      if ((updatedCase.status === 'resolved' || updatedCase.status === 'closed') && 
          caseData.status !== updatedCase.status) {
        toast.success(`Case ${updatedCase.status} successfully. Page will refresh to show updates.`);
        
        // Trigger page refresh after a short delay to show the success message
        setTimeout(() => {
          window.location.reload();
        }, 2000);
      } else {
        toast.success('Case updated successfully');
      }
    } catch (err: any) {
      toast.error('Failed to update case');
    }
  };

  // Handle case status update with auto-refresh
  const handleStatusUpdate = async (newStatus: string) => {
    if (!caseData) return;
    
    try {
      const response = await caseApi.updateCase(caseData._id, { status: newStatus as any });
      const updatedCase = response.data;
      setCaseData(updatedCase);
      
      // Auto-refresh page if status changed to resolved or closed
      if (newStatus === 'resolved' || newStatus === 'closed') {
        toast.success(`Case ${newStatus} successfully. Page will refresh to show updates.`);
        
        // Trigger page refresh after a short delay to show the success message
        setTimeout(() => {
          window.location.reload();
        }, 2000);
      } else {
        toast.success('Case status updated successfully');
      }
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Failed to update case status');
    }
  };

  // Handle case deletion
  const handleCaseDelete = async () => {
    if (!caseData) return;
    
    try {
      await caseApi.deleteCase(caseData._id);
      toast.success('Case deleted successfully. Redirecting to cases list...');
      
      // Small delay to show the success message before navigating
      setTimeout(() => {
        router.push('/cases');
      }, 1000);
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Failed to delete case');
      throw err; // Re-throw so CaseHeader can handle the error state
    }
  };

  // Handle note addition (simplified for existing API)
  const handleAddNote = async (content: string, isInternal: boolean) => {
    if (!caseData) return;
    
    try {
      await caseApi.addNote(caseData._id, content);
      await fetchCase(); // Refresh to get updated notes
      toast.success('Note added successfully');
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Failed to add note');
      throw err;
    }
  };

  // Handle file upload (using existing API)
  const handleUploadFile = async (file: File, description?: string) => {
    if (!caseData) return;
    
    try {
      await caseApi.uploadAttachment(caseData._id, file);
      await fetchCase(); // Refresh to get updated attachments
      toast.success('File uploaded successfully');
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Failed to upload file');
      throw err;
    }
  };

  // Handle file download - now handled internally by CaseAttachments component

  // Handle file view - now handled internally by CaseAttachments component

  // Initial load
  useEffect(() => {
    if (caseId) {
      fetchCase();
    }
  }, [caseId]);

  if (loading) {
    return (
      <ProtectedRoute>
        <div className="p-6 bg-gray-50 min-h-screen">
          <div className="max-w-7xl mx-auto">
            <LoadingSpinner />
          </div>
        </div>
      </ProtectedRoute>
    );
  }

  if (error || !caseData) {
    return (
      <ProtectedRoute>
        <div className="p-6 bg-gray-50 min-h-screen">
          <div className="max-w-7xl mx-auto">
            <ErrorMessage 
              message={error || 'Case not found'} 
              onRetry={() => fetchCase()}
            />
          </div>
        </div>
      </ProtectedRoute>
    );
  }

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
        {/* Header Section */}
        <div className="bg-white border-b border-gray-200 shadow-sm">
          <div className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
            <CaseHeader
              case={caseData}
              onStatusUpdate={handleStatusUpdate}
              onUpdate={handleCaseUpdate}
              onDelete={handleCaseDelete}
            />
          </div>
        </div>

        {/* Main Content */}
        <div className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
          {/* Navigation Tabs */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div className="border-b border-gray-200">
              <nav className="flex space-x-8 px-6" aria-label="Tabs">
                {[
                  { id: 'overview', name: 'Overview', icon: Eye, count: null },
                  { id: 'notes', name: 'Notes', icon: MessageSquare, count: caseData.notes?.length || 0 },
                  { id: 'attachments', name: 'Attachments', icon: Paperclip, count: caseData.attachments?.length || 0 },
                  ...(caseData.linkedTo?.type === 'invoice' ? [{ id: 'invoice', name: 'Invoice Actions', icon: DollarSign, count: null }] : []),
                  ...(user?.role_name === 'Admin' ? [{ id: 'logs', name: 'Activity Logs', icon: Activity, count: null }] : [])
                ].map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`${
                      activeTab === tab.id
                        ? 'border-blue-500 text-blue-600 bg-blue-50'
                        : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    } flex items-center whitespace-nowrap py-4 px-3 border-b-2 font-medium text-sm transition-colors duration-200 rounded-t-lg`}
                  >
                    <tab.icon className="h-5 w-5 mr-2" />
                    {tab.name}
                    {tab.count !== null && (
                      <span className={`ml-2 px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        activeTab === tab.id ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-600'
                      }`}>
                        {tab.count}
                      </span>
                    )}
                  </button>
                ))}
              </nav>
            </div>

            {/* Tab Content */}
            <div className="p-6">
              {activeTab === 'overview' && (
                <div className="space-y-6">
                  {/* Case Information */}
                  <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-6 border border-blue-200">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                      <FileText className="h-5 w-5 mr-2 text-blue-600" />
                      Case Information
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      <div>
                        <p className="text-sm font-medium text-gray-600 mb-1">Title</p>
                        <p className="text-gray-900 font-medium">{caseData.title}</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-600 mb-1">Description</p>
                        <p className="text-gray-900">{caseData.description}</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-600 mb-1">Created</p>
                        <p className="text-gray-900">{new Date(caseData.createdAt).toLocaleDateString()}</p>
                      </div>
                      {caseData.assignedTo && (
                        <div>
                          <p className="text-sm font-medium text-gray-600 mb-1">Assigned To</p>
                          <div className="flex items-center">
                            <User className="h-4 w-4 mr-1 text-gray-500" />
                            <p className="text-gray-900">{caseData.assignedTo}</p>
                          </div>
                        </div>
                      )}
                      {caseData.dueDate && (
                        <div>
                          <p className="text-sm font-medium text-gray-600 mb-1">Due Date</p>
                          <div className="flex items-center">
                            <Calendar className="h-4 w-4 mr-1 text-gray-500" />
                            <p className="text-gray-900">{new Date(caseData.dueDate).toLocaleDateString()}</p>
                          </div>
                        </div>
                      )}
                      {caseData.tags && caseData.tags.length > 0 && (
                        <div className="md:col-span-2 lg:col-span-3">
                          <p className="text-sm font-medium text-gray-600 mb-2">Tags</p>
                          <div className="flex flex-wrap gap-2">
                            {caseData.tags.map((tag, index) => (
                              <span
                                key={index}
                                className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
                              >
                                {tag}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Quick Actions */}
                  <div className="bg-white rounded-xl border border-gray-200 p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <button
                        onClick={() => setActiveTab('notes')}
                        className="flex items-center justify-center p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border border-blue-200 hover:from-blue-100 hover:to-indigo-100 transition-colors duration-200"
                      >
                        <MessageSquare className="h-5 w-5 mr-2 text-blue-600" />
                        <span className="font-medium text-blue-700">Add Note</span>
                      </button>
                      <button
                        onClick={() => setActiveTab('attachments')}
                        className="flex items-center justify-center p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg border border-green-200 hover:from-green-100 hover:to-emerald-100 transition-colors duration-200"
                      >
                        <Paperclip className="h-5 w-5 mr-2 text-green-600" />
                        <span className="font-medium text-green-700">Add Attachment</span>
                      </button>
                      {user?.role_name === 'Admin' && (
                        <button
                          onClick={() => setActiveTab('logs')}
                          className="flex items-center justify-center p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg border border-purple-200 hover:from-purple-100 hover:to-pink-100 transition-colors duration-200"
                        >
                          <Activity className="h-5 w-5 mr-2 text-purple-600" />
                          <span className="font-medium text-purple-700">View Logs</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'notes' && (
                <CaseNotes
                  case={caseData}
                  notes={caseData.notes || []}
                  onAddNote={handleAddNote}
                />
              )}

              {activeTab === 'attachments' && (
                <CaseAttachments
                  case={caseData}
                  attachments={caseData.attachments || []}
                  onUploadFile={handleUploadFile}
                />
              )}

              {activeTab === 'invoice' && caseData.linkedTo?.type === 'invoice' && (
                <InvoiceActions 
                  case={caseData}
                  onInvoiceUpdate={() => fetchCase()}
                />
              )}

              {activeTab === 'logs' && user?.role_name === 'Admin' && (
                <CaseLogs
                  case={caseData}
                  userRole={user?.role_name}
                />
              )}
            </div>
          </div>
        </div>
      </div>
    </ProtectedRoute>
  );
}
