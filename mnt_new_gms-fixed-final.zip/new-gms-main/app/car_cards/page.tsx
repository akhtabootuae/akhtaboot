"use client";

import React, { useState, useEffect, useRef, useMemo, useCallback } from "react";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { useRouter } from "next/navigation";
import api, { dataApi } from '../../services/api';
import { 
  getStatusBadgeClasses, 
  getPriorityBadgeClasses,
  formatStatus
} from '../../lib/workOrderHelpers';
import { 
  Car, 
  User, 
  Calendar, 
  Clock, 
  Wrench, 
  ChevronRight,
  Play,
  Pause,
  Circle,
  ChevronLeft,
  ChevronDown,
  ChevronUp,
  Wifi,
  WifiOff
} from 'lucide-react';
import { useAutoPlay } from '../context/AutoPlayContext';
import { useWebSocket } from '../hooks/useWebSocket';
import { toast } from 'react-hot-toast';

// Types for the work order data structure
interface Vehicle {
  make: string;
  model: string;
  year: number;
  license_plate: string;
  color: string;
  vehicle_type: string;
  vin?: string;
}

interface Customer {
  name: string;
  email: string;
  phone: string;
}

interface WorkOrderPart {
  partName: string;
  status: string;
  stages: Array<{
    status: 'pending' | 'in_progress' | 'completed' | 'paused';
    stageId: string;
    started_at?: string;
    completed_at?: string;
    updated_at?: string;
    stage_name?: string;
    stage_description?: string;
    stage_order?: number;
    assigned_to?: string;
    assignedTo?: string;
    notes?: string;
    logs?: any[];
  }>;
}

interface PartInfo {
  partName: string;
  stageName: string;
  status: 'pending' | 'in_progress' | 'completed' | 'paused';
}

interface StageInfo {
  display: string;
  parts: PartInfo[];
}

interface WorkOrder {
  _id: string;
  workOrderNumber: string;
  work_order_number: string;
  customer_id: string;
  vehicle_id: Vehicle;
  vehicleDetails?: Vehicle;
  status: string;
  description: string;
  parts: WorkOrderPart[];
  createdAt: string;
  updatedAt: string;
  customerDetails: Customer;
  priority?: string;
}

const CarCardsPage: React.FC = () => {
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>([]);
  const [filteredWorkOrders, setFilteredWorkOrders] = useState<WorkOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [stageMapping, setStageMapping] = useState<Map<string, { name: string; order: number }>>(new Map());
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(8);
  const [expandedCards, setExpandedCards] = useState<Set<string>>(new Set());
  const [newWorkOrderIds, setNewWorkOrderIds] = useState<Set<string>>(new Set());
  const timersRef = useRef<Map<string, NodeJS.Timeout>>(new Map());
  const newWorkOrderTimersRef = useRef<Map<string, NodeJS.Timeout>>(new Map());
  
  const router = useRouter();
  const { autoPlay, toggleAutoPlay } = useAutoPlay();
  const { socket, isConnected, error: wsError } = useWebSocket();

  const fetchWorkOrders = useCallback(async () => {
    setLoading(true);
    try {
      const result = await api.get('/api/work-orders', {
        params: {
          page: '1',
          limit: '100',
          sortBy: 'createdAt',
          sortOrder: 'desc'
        }
      });

      if (result && Array.isArray(result)) {
        // Filter out closed and completed work orders
        const activeWorkOrders = result.filter(wo => 
          wo.status?.toLowerCase() !== 'closed' && wo.status?.toLowerCase() !== 'completed'
        );
        setWorkOrders(activeWorkOrders);
        setFilteredWorkOrders(activeWorkOrders);
      } else if (result?.data && Array.isArray(result.data)) {
        // Filter out closed and completed work orders
        const activeWorkOrders = result.data.filter(wo => 
          wo.status?.toLowerCase() !== 'closed' && wo.status?.toLowerCase() !== 'completed'
        );
        setWorkOrders(activeWorkOrders);
        setFilteredWorkOrders(activeWorkOrders);
      } else {
        setWorkOrders([]);
        setFilteredWorkOrders([]);
      }
    } catch (error) {
      setWorkOrders([]);
      setFilteredWorkOrders([]);
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchStages = useCallback(async () => {
    try {
      const response = await dataApi.getStages();
      let stagesData: any[] = [];
      
      if (response && typeof response === 'object' && 'success' in response && 'data' in response && Array.isArray((response as any).data)) {
        stagesData = (response as any).data;
      } else if (Array.isArray(response)) {
        stagesData = response;
      } else if (response && typeof response === 'object' && 'data' in response && Array.isArray((response as any).data)) {
        stagesData = (response as any).data;
      }
      
      if (stagesData.length > 0) {
        const mapping = new Map();
        stagesData.forEach((stage: any) => {
          if (stage._id && stage.name) {
            mapping.set(stage._id, {
              name: stage.name,
              order: stage.order || 0
            });
          }
        });
        setStageMapping(mapping);
      }
    } catch (error) {
      // Silent error handling for production
    }
  }, []);

  const getStageName = useCallback((stageId: string, stageIndex: number): string => {
    if (stageId && stageMapping.has(stageId)) {
      return stageMapping.get(stageId)?.name || `Stage ${stageIndex + 1}`;
    }
    return stageId ? `Stage ${stageIndex + 1}` : 'Unknown Stage';
  }, [stageMapping]);

  useEffect(() => {
    Promise.all([fetchStages(), fetchWorkOrders()]).catch(() => {
      // Silent error handling for production
    });
  }, [fetchStages, fetchWorkOrders]);

  // Utility functions for data extraction
  const extractVehicleData = (rawWorkOrder: any) => {
    return rawWorkOrder.vehicle_id && typeof rawWorkOrder.vehicle_id === 'object' 
      ? rawWorkOrder.vehicle_id
      : rawWorkOrder.vehicleDetails 
      ? rawWorkOrder.vehicleDetails
      : rawWorkOrder.vehicle 
      ? rawWorkOrder.vehicle
      : rawWorkOrder.vehicle_info 
      ? rawWorkOrder.vehicle_info
      : {
          make: 'Unknown',
          model: 'Vehicle', 
          year: 0,
          license_plate: 'N/A',
          color: 'Unknown',
          vehicle_type: 'Unknown'
        };
  };

  const extractCustomerData = (rawWorkOrder: any) => {
    return rawWorkOrder.customerDetails 
      ? rawWorkOrder.customerDetails
      : rawWorkOrder.customer 
      ? rawWorkOrder.customer
      : rawWorkOrder.customer_details 
      ? rawWorkOrder.customer_details
      : rawWorkOrder.customer_info 
      ? rawWorkOrder.customer_info
      : {
          name: 'Unknown Customer',
          email: '',
          phone: ''
        };
  };

  // Optimized helper function to normalize work order data from WebSocket
  const normalizeWorkOrderData = useCallback((rawWorkOrder: any): WorkOrder => {
    const vehicleData = extractVehicleData(rawWorkOrder);
    const customerData = extractCustomerData(rawWorkOrder);
    
    const partsData = Array.isArray(rawWorkOrder.parts) 
      ? rawWorkOrder.parts.map((part: any) => ({
          partName: part.partName ?? part.name ?? 'Unknown Part',
          status: part.status ?? 'pending',
          stages: part.stages ?? []
        }))
      : [];

    const createdAt = rawWorkOrder.createdAt ?? rawWorkOrder.created_at ?? new Date().toISOString();
    const updatedAt = rawWorkOrder.updatedAt ?? rawWorkOrder.updated_at ?? createdAt;
    const workOrderNumber = rawWorkOrder.workOrderNumber ?? 'PENDING';

    return {
      _id: rawWorkOrder._id ?? rawWorkOrder.id,
      workOrderNumber,
      work_order_number: workOrderNumber,
      customer_id: rawWorkOrder.customer_id ?? '',
      vehicle_id: vehicleData as Vehicle,
      vehicleDetails: vehicleData as Vehicle,
      status: rawWorkOrder.status ?? 'open',
      description: rawWorkOrder.description ?? '',
      parts: partsData,
      createdAt,
      updatedAt,
      customerDetails: customerData as Customer,
      priority: rawWorkOrder.priority
    };
  }, []);

  // WebSocket real-time updates
  useEffect(() => {
    if (!socket || !isConnected) return;

    const handleWorkOrderCreated = (data: any) => {
      if (data.workOrder) {
        const normalizedWorkOrder = normalizeWorkOrderData(data.workOrder);
        const vehicle = normalizedWorkOrder.vehicle_id;
        const vehicleDisplay = `${vehicle.year ?? ''} ${vehicle.make ?? ''} ${vehicle.model ?? ''}`.trim() || 'Vehicle';
        
        toast.success(`New work order created for ${vehicleDisplay}`, {
          duration: 5000,
          position: 'top-right',
        });
      }
      
      if (data.workOrder) {
        const normalizedWorkOrder = normalizeWorkOrderData(data.workOrder);
        setWorkOrders(prev => [normalizedWorkOrder, ...prev]);
        
        const workOrderId = data.workOrder._id;
        setNewWorkOrderIds(prev => new Set([...prev, workOrderId]));
        
        const timer = setTimeout(() => {
          setNewWorkOrderIds(prev => {
            const updated = new Set(prev);
            updated.delete(workOrderId);
            return updated;
          });
          newWorkOrderTimersRef.current.delete(workOrderId);
        }, 30000);
        
        newWorkOrderTimersRef.current.set(workOrderId, timer);
      }
    };

    const handleWorkOrderUpdated = (data: any) => {
      if (data.workOrder) {
        const normalizedWorkOrder = normalizeWorkOrderData(data.workOrder);
        
        // If the work order is closed or completed, remove it from the list
        if (normalizedWorkOrder.status?.toLowerCase() === 'closed' || normalizedWorkOrder.status?.toLowerCase() === 'completed') {
          setWorkOrders(prev => prev.filter(wo => wo._id !== normalizedWorkOrder._id));
          
          const vehicle = normalizedWorkOrder.vehicle_id;
          const vehicleDisplay = `${vehicle.year ?? ''} ${vehicle.make ?? ''} ${vehicle.model ?? ''}`.trim() || 'Vehicle';
          
          const statusMessage = normalizedWorkOrder.status?.toLowerCase() === 'closed' ? 'completed and closed' : 'completed';
          toast.success(`${vehicleDisplay} work order ${statusMessage}`, {
            duration: 4000,
            position: 'top-right',
          });
          return;
        }
        
        setWorkOrders(prev => 
          prev.map(wo => 
            wo._id === normalizedWorkOrder._id ? { ...wo, ...normalizedWorkOrder } : wo
          )
        );
        
        if (data.updateType === 'status_change') {
          const vehicle = normalizedWorkOrder.vehicle_id;
          const vehicleDisplay = `${vehicle.year ?? ''} ${vehicle.make ?? ''} ${vehicle.model ?? ''}`.trim() || 'Vehicle';
          
          toast(`${vehicleDisplay} status updated to ${formatStatus(normalizedWorkOrder.status)}`, {
            duration: 4000,
            position: 'top-right',
          });
        }
      }
    };

    const handleWorkOrderDeleted = (data: any) => {
      if (data.workOrderId) {
        setWorkOrders(prev => prev.filter(wo => wo._id !== data.workOrderId));
        
        toast.error('Work order removed', {
          duration: 3000,
          position: 'top-right',
        });
      }
    };

    const handleStageUpdated = (data: any) => {
      if (!data.workOrderId) return;

      setWorkOrders(prev => 
        prev.map(wo => {
          if (wo._id === data.workOrderId) {
            const updatedWorkOrder = { ...wo };
            
            if (data.partIndex !== undefined && data.stageIndex !== undefined && data.stage) {
              const newParts = [...(updatedWorkOrder.parts ?? [])];
              
              if (newParts[data.partIndex]) {
                newParts[data.partIndex] = {
                  ...newParts[data.partIndex],
                  partName: data.partName,
                  stages: [...(newParts[data.partIndex].stages ?? [])]
                };
                
                if (newParts[data.partIndex].stages[data.stageIndex]) {
                  newParts[data.partIndex].stages[data.stageIndex] = {
                    ...newParts[data.partIndex].stages[data.stageIndex],
                    status: data.stage.status,
                    stageId: data.stage.stage_id,
                    started_at: data.stage.started_at,
                    completed_at: data.stage.completed_at,
                    updated_at: data.stage.updated_at,
                    stage_name: data.stage.stage_name,
                    stage_description: data.stage.stage_description,
                    stage_order: data.stage.stage_order,
                    assigned_to: data.stage.assigned_to ?? data.stage.assignedTo,
                    notes: data.stage.notes,
                    logs: data.stage.logs
                  };
                }
                
                // Update part status
                if (data.progress) {
                  newParts[data.partIndex].status = data.progress.percentage >= 100 
                    ? 'completed' 
                    : data.progress.percentage > 0 
                    ? 'in_progress' 
                    : 'pending';
                } else {
                  const partStages = newParts[data.partIndex].stages;
                  const hasInProgress = partStages.some(s => s.status === 'in_progress');
                  const allCompleted = partStages.every(s => s.status === 'completed');
                  
                  newParts[data.partIndex].status = hasInProgress 
                    ? 'in_progress'
                    : allCompleted 
                    ? 'completed' 
                    : 'pending';
                }
              }
              
              updatedWorkOrder.parts = newParts;
              
              const hasAnyInProgress = newParts.some(part => part.status === 'in_progress');
              const allPartsCompleted = newParts.every(part => part.status === 'completed');
              
              updatedWorkOrder.status = hasAnyInProgress 
                ? 'in_progress'
                : allPartsCompleted 
                ? 'completed'
                : updatedWorkOrder.status;
              
              updatedWorkOrder.updatedAt = new Date().toISOString();
            }
            
            return updatedWorkOrder;
          }
          
          return wo;
        })
      );

      if (data.stage && data.partName) {
        const targetWorkOrder = workOrders.find(wo => wo._id === data.workOrderId);
        let vehicleDisplay = 'Vehicle';
        
        if (targetWorkOrder) {
          const vehicle = targetWorkOrder.vehicle_id ?? targetWorkOrder.vehicleDetails ?? {};
          vehicleDisplay = `${(vehicle as any).year ?? ''} ${(vehicle as any).make ?? ''} ${(vehicle as any).model ?? ''}`.trim() || 'Vehicle';
        }
        
        const stageName = data.stage.stage_name ?? 'Stage';
        const progressInfo = data.progress ? ` (${data.progress.stage_position})` : '';
        
        let message = '';
        let toastType = 'default';
        
        switch (data.stage.status) {
          case 'in_progress':
            message = `${vehicleDisplay} - ${stageName} started on ${data.partName}${progressInfo}`;
            toastType = 'success';
            break;
          case 'completed':
            message = `${vehicleDisplay} - ${stageName} completed on ${data.partName}${progressInfo}`;
            toastType = 'success';
            break;
          case 'paused':
            message = `${vehicleDisplay} - ${stageName} paused on ${data.partName}${progressInfo}`;
            break;
          default:
            message = `${vehicleDisplay} - ${stageName} updated on ${data.partName}${progressInfo}`;
        }

        if (toastType === 'success') {
          toast.success(message, { duration: 5000, position: 'top-right' });
        } else {
          toast(message, { duration: 4000, position: 'top-right' });
        }
      }
    };

    // Listen for work order events
    socket.on('work_order_created', handleWorkOrderCreated);
    socket.on('work_order_updated', handleWorkOrderUpdated);
    socket.on('work_order_deleted', handleWorkOrderDeleted);
    socket.on('stage_updated', handleStageUpdated);
    socket.on('work_order_stage_updated', handleStageUpdated); // Alternative event name

    // Cleanup listeners
    return () => {
      socket.off('work_order_created', handleWorkOrderCreated);
      socket.off('work_order_updated', handleWorkOrderUpdated);
      socket.off('work_order_deleted', handleWorkOrderDeleted);
      socket.off('stage_updated', handleStageUpdated);
      socket.off('work_order_stage_updated', handleStageUpdated);
    };
  }, [socket, isConnected]);

  // Auto-pagination effect
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (autoPlay && filteredWorkOrders.length > 0) {
      const totalPages = Math.ceil(filteredWorkOrders.length / itemsPerPage);
      
      if (totalPages > 1) {
        interval = setInterval(() => {
          setCurrentPage(prevPage => {
            const nextPage = prevPage >= totalPages ? 1 : prevPage + 1;
            return nextPage;
          });
        }, 30000);
      }
    }
    
    return () => {
      if (interval) {
        clearInterval(interval);
      }
    };
  }, [autoPlay, filteredWorkOrders.length, itemsPerPage]);

  // Auto-filter to latest work orders and exclude closed and completed ones
  useEffect(() => {
    // Filter out closed and completed work orders
    const activeWorkOrders = workOrders.filter(workOrder => 
      workOrder.status?.toLowerCase() !== 'closed' && workOrder.status?.toLowerCase() !== 'completed'
    );
    
    const sortedWorkOrders = [...activeWorkOrders].sort((a, b) => {
      const dateA = new Date(a.updatedAt || a.createdAt);
      const dateB = new Date(b.updatedAt || b.createdAt);
      return dateB.getTime() - dateA.getTime();
    });

    setFilteredWorkOrders(sortedWorkOrders);
    setCurrentPage(1);
  }, [workOrders]);



  const getCurrentStageInfo = useCallback((workOrder: WorkOrder): StageInfo => {
    if (!workOrder.parts || workOrder.parts.length === 0) {
      return { display: 'No parts assigned', parts: [] };
    }
    
    const partsInfo = workOrder.parts.map(part => {
      if (!part.stages || part.stages.length === 0) {
        return {
          partName: part.partName,
          stageName: 'No stages',
          status: 'pending' as const
        };
      }
      
      const currentStage = part.stages.find(stage => stage.status === 'in_progress') ||
                        part.stages.find(stage => stage.status === 'paused') ||
                        part.stages.find(stage => stage.status === 'pending');
      
      if (!currentStage) {
        const allCompleted = part.stages.every(stage => stage.status === 'completed');
        return {
          partName: part.partName,
          stageName: allCompleted ? 'All Stages Completed' : 'No Active Stage',
          status: allCompleted ? 'completed' as const : 'pending' as const
        };
      }
      
      let stageName = 'Unknown Stage';
      if (currentStage.stageId && stageMapping.has(currentStage.stageId)) {
        stageName = stageMapping.get(currentStage.stageId)?.name || 'Unknown Stage';
      } else if (currentStage.stageId) {
        const stageIndex = part.stages.indexOf(currentStage);
        stageName = getStageName(currentStage.stageId, stageIndex);
      } else {
        stageName = `Stage (${currentStage.status})`;
      }
      
      return {
        partName: part.partName,
        stageName,
        status: currentStage.status as 'pending' | 'in_progress' | 'completed' | 'paused'
      };
    });
    
    return {
      display: partsInfo.length === 1 ? 
        `${partsInfo[0].partName}: ${partsInfo[0].stageName}` : 
        `${partsInfo.length} parts in work order`,
      parts: partsInfo
    };
  }, [stageMapping, getStageName]);

  const getProgressPercentage = useCallback((workOrder: WorkOrder): number => {
    if (!workOrder.parts?.length) return 0;
    
    const { totalStages, completedStages } = workOrder.parts.reduce(
      (acc, part) => {
        if (part.stages?.length) {
          acc.totalStages += part.stages.length;
          acc.completedStages += part.stages.filter(stage => stage.status === 'completed').length;
        }
        return acc;
      },
      { totalStages: 0, completedStages: 0 }
    );
    
    return totalStages > 0 ? Math.round((completedStages / totalStages) * 100) : 0;
  }, []);

  // Check if work order is new (recently created or in our new set)
  const isNewWorkOrder = useCallback((workOrder: WorkOrder): boolean => {
    if (newWorkOrderIds.has(workOrder._id)) return true;
    
    // Check if recently created (last 2 minutes) as fallback
    const createdAt = new Date(workOrder.createdAt);
    const now = new Date();
    const diffInMinutes = (now.getTime() - createdAt.getTime()) / (1000 * 60);
    return diffInMinutes <= 2;
  }, [newWorkOrderIds]);

  const getVehicleDisplay = useCallback((vehicle: Vehicle): string => {
    if (!vehicle) return 'Unknown Vehicle';
    const { year = '', make = '', model = '' } = vehicle;
    return `${year} ${make} ${model}`.trim() || 'Unknown Vehicle';
  }, []);

  const handleCardClick = useCallback((workOrderId: string) => {
    router.push(`/workOrders/${workOrderId}`);
  }, [router]);

  // Toggle stages section with auto-collapse timer
  const toggleStagesSection = useCallback((workOrderId: string, event: React.MouseEvent) => {
    event.stopPropagation(); // Prevent card click navigation
    
    if (expandedCards.has(workOrderId)) {
      // Collapse the section
      setExpandedCards(prev => {
        const updated = new Set(prev);
        updated.delete(workOrderId);
        return updated;
      });
      
      // Clear existing timer for this specific card
      const existingTimer = timersRef.current.get(workOrderId);
      if (existingTimer) {
        clearTimeout(existingTimer);
        timersRef.current.delete(workOrderId);
      }
    } else {
      // Expand the section
      setExpandedCards(prev => {
        const updated = new Set(prev);
        updated.add(workOrderId);
        return updated;
      });
      
      // Clear any existing timer for this card
      const existingTimer = timersRef.current.get(workOrderId);
      if (existingTimer) {
        clearTimeout(existingTimer);
        timersRef.current.delete(workOrderId);
      }
      
      // Set auto-collapse timer for this specific card
      const timer = setTimeout(() => {
        setExpandedCards(prevExpanded => {
          const updatedExpanded = new Set(prevExpanded);
          updatedExpanded.delete(workOrderId);
          return updatedExpanded;
        });
        timersRef.current.delete(workOrderId);
      }, 1000000000);
      
      // Store timer in ref
      timersRef.current.set(workOrderId, timer);
    }
  }, [expandedCards]);

  // Cleanup timers on component unmount
  useEffect(() => {
    return () => {
      timersRef.current.forEach(timer => clearTimeout(timer));
      timersRef.current.clear();
      newWorkOrderTimersRef.current.forEach(timer => clearTimeout(timer));
      newWorkOrderTimersRef.current.clear();
    };
  }, []);

  // Memoized pagination calculations
  const paginationData = useMemo(() => {
    const totalPages = Math.ceil(filteredWorkOrders.length / itemsPerPage);
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const currentWorkOrders = filteredWorkOrders.slice(startIndex, endIndex);
    const currentWorkOrderIds = new Set(currentWorkOrders.map(wo => wo._id));
    
    return {
      totalPages,
      startIndex,
      endIndex,
      currentWorkOrders,
      currentWorkOrderIds
    };
  }, [filteredWorkOrders, currentPage, itemsPerPage]);

  const { totalPages, startIndex, endIndex, currentWorkOrders, currentWorkOrderIds } = paginationData;

  // Clear timers for cards not on current page
  useEffect(() => {
    timersRef.current.forEach((timer, workOrderId) => {
      if (!currentWorkOrderIds.has(workOrderId)) {
        clearTimeout(timer);
        timersRef.current.delete(workOrderId);
      }
    });

    setExpandedCards(prev => {
      const updated = new Set<string>();
      prev.forEach(workOrderId => {
        if (currentWorkOrderIds.has(workOrderId)) {
          updated.add(workOrderId);
        }
      });
      return updated;
    });
  }, [currentWorkOrderIds]);

  const goToNextPage = useCallback(() => {
    setCurrentPage(prev => prev < totalPages ? prev + 1 : 1);
  }, [totalPages]);

  const goToPrevPage = useCallback(() => {
    setCurrentPage(prev => prev > 1 ? prev - 1 : totalPages);
  }, [totalPages]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading vehicles...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
              <Car className="h-8 w-8 text-blue-600" />
              Vehicle Work Orders
            </h1>
            <p className="text-gray-600 mt-2">
              {totalPages > 1 ? (
                <>
                  Showing {startIndex + 1}-{Math.min(endIndex, filteredWorkOrders.length)} of {filteredWorkOrders.length} vehicles 
                  (Page {currentPage} of {totalPages})
                  {autoPlay && <span className="ml-2 text-blue-600 font-medium">• Auto-cycling every 30s</span>}
                </>
              ) : (
                `Showing ${filteredWorkOrders.length} vehicles with active work orders`
              )}
            </p>
          </div>
          
          <div className="flex items-center gap-3">
            {/* WebSocket connection status */}
            <div className="flex items-center gap-2 px-3 py-1 rounded-lg bg-white shadow-sm border">
              {isConnected ? (
                <>
                  <Wifi className="h-4 w-4 text-green-600" />
                  <span className="text-sm text-green-700 font-medium">Live</span>
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                </>
              ) : (
                <>
                  <WifiOff className="h-4 w-4 text-red-600" />
                  <span className="text-sm text-red-700 font-medium">Offline</span>
                  <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                </>
              )}
            </div>
            
            {/* Auto-play controls */}
            {totalPages > 1 && (
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={toggleAutoPlay}
                  className={`${autoPlay ? 'bg-blue-50 border-blue-300 text-blue-700' : ''}`}
                >
                  {autoPlay ? (
                    <>
                      <Pause className="h-4 w-4 mr-1" />
                      Stop Auto-cycle
                    </>
                  ) : (
                    <>
                      <Play className="h-4 w-4 mr-1" />
                      Auto-cycle
                    </>
                  )}
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Work Orders Grid */}
      {filteredWorkOrders.length === 0 ? (
        <div className="text-center py-12">
          <Car className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No vehicles found</h3>
          <p className="text-gray-600">
            {workOrders.length === 0 
              ? "No work orders available." 
              : "No vehicles match current criteria."
            }
          </p>
        </div>
      ) : (
        <>
          {/* Pagination Controls */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between mb-6 bg-white rounded-lg shadow-sm p-4">
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={goToPrevPage}
                  disabled={currentPage === 1}
                  className="flex items-center gap-1"
                >
                  <ChevronLeft className="h-4 w-4" />
                  Previous
                </Button>
                
                <div className="flex items-center gap-1">
                  {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                    let pageNum;
                    if (totalPages <= 5) {
                      pageNum = i + 1;
                    } else if (currentPage <= 3) {
                      pageNum = i + 1;
                    } else if (currentPage > totalPages - 3) {
                      pageNum = totalPages - 4 + i;
                    } else {
                      pageNum = currentPage - 2 + i;
                    }
                    
                    return (
                      <Button
                        key={pageNum}
                        variant={currentPage === pageNum ? "default" : "outline"}
                        size="sm"
                        onClick={() => setCurrentPage(pageNum)}
                        className={`w-8 h-8 p-0 ${currentPage === pageNum ? 'bg-blue-600' : ''}`}
                      >
                        {pageNum}
                      </Button>
                    );
                  })}
                </div>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={goToNextPage}
                  disabled={currentPage === totalPages}
                  className="flex items-center gap-1"
                >
                  Next
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
              
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <span>Page {currentPage} of {totalPages}</span>
                {autoPlay && (
                  <div className="flex items-center gap-1 text-blue-600">
                    <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
                    <span>Auto-cycling</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {currentWorkOrders.map((workOrder) => {
            const vehicle = (workOrder.vehicle_id ?? workOrder.vehicleDetails ?? {}) as Vehicle;
            const customer = (workOrder.customerDetails ?? {}) as Customer;
            const progress = getProgressPercentage(workOrder);
            const stageInfo = getCurrentStageInfo(workOrder);

            return (
              <div
                key={workOrder._id}
                className="bg-white rounded-xl shadow-lg border border-gray-200 hover:shadow-xl transition-all duration-200 group overflow-hidden transform hover:scale-105"
              >
                {/* Vehicle Header */}
                <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <Car className="h-6 w-6" />
                      {isNewWorkOrder(workOrder) && (
                        <Badge className="bg-orange-500 text-white text-xs px-2 py-1 font-bold animate-pulse border border-orange-300">
                          NEW
                        </Badge>
                      )}
                    </div>
                    <Badge className={`${workOrder.status === 'in_progress' ? 'bg-green-100 text-green-800' : getStatusBadgeClasses(workOrder.status)} text-sm px-4 py-2 font-semibold shadow-lg border-2 border-white/30`}>
                      {formatStatus(workOrder.status)}
                    </Badge>
                  </div>
                  
                  <h3 className="font-bold text-lg mb-3">
                    {getVehicleDisplay(vehicle)}
                  </h3>
                  
                  <div className="flex items-center justify-between">
                    <div className="bg-white backdrop-blur-sm rounded-lg px-3 py-2 border border-white/30">
                      <span className="text-gray-800 font-bold text-sm tracking-widest uppercase">
                        {vehicle.license_plate ?? 'NO PLATE'}
                      </span>
                    </div>
                    
                    <div className="flex items-center gap-2 text-sm">
                      <span className="bg-white px-3 py-1 rounded-lg font-medium text-gray-800">
                        {vehicle.color ?? 'N/A'}
                      </span>
                      <span className="bg-white px-3 py-1 rounded-lg font-medium text-gray-800">
                        {vehicle.vehicle_type ?? 'N/A'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Card Content */}
                <div className="p-5 space-y-4">
                  {/* Work Order & Customer Info Combined */}
                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex-1">
                        <div className="text-base font-semibold text-gray-900 mb-2">
                          {workOrder.workOrderNumber}
                        </div>
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <User className="h-4 w-4" />
                          <span className="truncate">{customer.name ?? 'Unknown Customer'}</span>
                        </div>
                      </div>
                      {workOrder.priority && (
                        <Badge className={`${getPriorityBadgeClasses(workOrder.priority)} text-xs`}>
                          {workOrder.priority.toUpperCase()}
                        </Badge>
                      )}
                    </div>
                  </div>

                  {/* Current Stage */}
                  <div>
                    <div 
                      className="flex items-center justify-between mb-3 cursor-pointer hover:bg-gray-50 rounded-lg p-2 -m-2 transition-colors"
                      onClick={(e) => toggleStagesSection(workOrder._id, e)}
                    >
                      <div className="flex items-center gap-2">
                        <Wrench className="h-4 w-4 text-gray-500" />
                        <span className="text-sm font-medium text-gray-700">
                          {stageInfo.parts.length === 1 ? 'Current Stage' : `Parts & Stages (${stageInfo.parts.length})`}
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        {expandedCards.has(workOrder._id) ? (
                          <ChevronUp className="h-4 w-4 text-gray-500" />
                        ) : (
                          <ChevronDown className="h-4 w-4 text-gray-500" />
                        )}
                      </div>
                    </div>
                    
                    <div className={`transition-all duration-300 ease-in-out overflow-hidden ${
                      expandedCards.has(workOrder._id) 
                        ? 'max-h-96 opacity-100' 
                        : 'max-h-0 opacity-0'
                    }`}>
                      <div className="space-y-3">
                        {stageInfo.parts.map((partInfo, index) => (
                          <div key={index} className="bg-gray-50 px-3 py-3 rounded-lg border border-gray-100">
                            <div className="flex items-center justify-between">
                              <div className="flex-1 min-w-0">
                                <div className="text-sm text-gray-900">
                                  <span className="font-medium text-gray-800 block mb-1">
                                    {partInfo.partName}
                                  </span>
                                  <span className="text-gray-600">
                                    Stage: {partInfo.stageName}
                                  </span>
                                </div>
                              </div>
                              <div className="flex items-center gap-2 ml-3">
                                {partInfo.status === 'in_progress' && (
                                  <div className="flex items-center gap-2 bg-green-50 border border-green-200 rounded-lg px-3 py-2" title="In Progress">
                                    <Play className="w-6 h-6 text-green-600 fill-current" />
                                    <span className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></span>
                                    <span className="text-xs font-medium text-green-700">Active</span>
                                  </div>
                                )}
                                {partInfo.status === 'paused' && (
                                  <div className="flex items-center gap-2 bg-yellow-50 border border-yellow-200 rounded-lg px-3 py-2" title="Paused">
                                    <Pause className="w-6 h-6 text-yellow-600 fill-current" />
                                    <span className="w-3 h-3 bg-yellow-500 rounded-full"></span>
                                    <span className="text-xs font-medium text-yellow-700">Paused</span>
                                  </div>
                                )}
                                {partInfo.status === 'pending' && (
                                  <div className="flex items-center gap-2 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2" title="Pending">
                                    <Circle className="w-6 h-6 text-gray-500" />
                                    <span className="w-3 h-3 bg-gray-400 rounded-full"></span>
                                    <span className="text-xs font-medium text-gray-600">Pending</span>
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    {/* Collapsed preview */}
                    {!expandedCards.has(workOrder._id) && stageInfo.parts.length > 0 && (
                      <div className="text-xs text-gray-500 mt-1">
                        Click to view {stageInfo.parts.length} part{stageInfo.parts.length !== 1 ? 's' : ''} details
                      </div>
                    )}
                  </div>

                  {/* Progress */}
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium text-gray-700">Progress</span>
                      <span className="text-sm text-gray-900">{progress}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-gradient-to-r from-blue-500 to-blue-600 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${progress}%` }}
                      />
                    </div>
                  </div>

                  {/* Metadata */}
                  <div className="space-y-3 pt-3 border-t border-gray-100">
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        <span>Created: {new Date(workOrder.createdAt).toLocaleDateString()}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        <span>Updated: {new Date(workOrder.updatedAt).toLocaleDateString()}</span>
                      </div>
                    </div>

                    <div className="text-sm text-gray-600">
                      <span className="font-medium">{workOrder.parts?.length ?? 0}</span> part(s) in work order
                    </div>

                    <div className="flex items-center justify-between pt-2">
                      <button
                        onClick={() => handleCardClick(workOrder._id)}
                        className="text-sm text-blue-600 font-medium hover:text-blue-700 transition-colors flex items-center gap-2 group/button"
                      >
                        View Details
                        <ChevronRight className="h-4 w-4 text-blue-600 group-hover/button:translate-x-1 transition-transform" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </>
      )}
    </div>
  );
};

export default CarCardsPage;