"use client";

import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { notificationsApi } from "@/services/api";
import { useAuth } from "./AuthContext";

interface NotificationStats {
  total: number;
  unread: number;
  undone?: number;
  highPriority: number;
}

interface NotificationContextType {
  notificationStats: NotificationStats;
  refreshStats: () => Promise<void>;
  isLoading: boolean;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const NotificationProvider = ({ children }: { children: ReactNode }) => {
  const { user, isAuthenticated } = useAuth();
  const [notificationStats, setNotificationStats] = useState<NotificationStats>({
    total: 0,
    unread: 0,
    undone: 0,
    highPriority: 0,
  });
  const [isLoading, setIsLoading] = useState(true);

  const fetchNotificationStats = async () => {
    // Skip notifications for feedback screen users
    if (user?.role_name?.toLowerCase() === 'feedback screen') {
      setIsLoading(false);
      return;
    }

    try {
      const response = await notificationsApi.getNotificationStats();
      const stats = response?.data || response;
      
      // Handle different response formats
      setNotificationStats({
        total: stats.total || 0,
        unread: stats.unread || stats.undone || 0,
        undone: stats.undone || stats.unread || 0,
        highPriority: stats.highPriority || 0,
      });
    } catch (error) {
      console.error("Error fetching notification stats:", error);
      // Keep previous stats on error
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    // Skip notifications for feedback screen users
    if (user?.role_name?.toLowerCase() === 'feedback screen') {
      setIsLoading(false);
      return;
    }

    // Initial fetch
    fetchNotificationStats();

    // Set up polling every 30 seconds
    const interval = setInterval(fetchNotificationStats, 30000);

    return () => clearInterval(interval);
  }, [isAuthenticated, user]);

  const refreshStats = async () => {
    await fetchNotificationStats();
  };

  return (
    <NotificationContext.Provider value={{ notificationStats, refreshStats, isLoading }}>
      {children}
    </NotificationContext.Provider>
  );
};

export const useNotifications = () => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error("useNotifications must be used within a NotificationProvider");
  }
  return context;
};