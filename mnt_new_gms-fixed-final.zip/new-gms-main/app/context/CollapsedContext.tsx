"use client";

import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";

type CollapsedContextType = {
  collapsed: boolean;
  isMobile: boolean;
  toggle: () => void;
  closeMobile: () => void;
};

const CollapsedContext = createContext<CollapsedContextType>({
  collapsed: false,
  isMobile: false,
  toggle: () => {},
  closeMobile: () => {},
});

export function CollapsedProvider({ children }: { children: ReactNode }) {
  const [collapsed, setCollapsed] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  // Check if we're on mobile/tablet (1280px and below for Galaxy Tab Active 2)
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth <= 1280);
      // On mobile, sidebar should be closed by default
      if (window.innerWidth <= 1280) {
        setCollapsed(true);
      }
    };

    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const toggle = () => setCollapsed((c) => !c);
  const closeMobile = () => {
    if (isMobile) {
      setCollapsed(true);
    }
  };

  return (
    <CollapsedContext.Provider value={{ collapsed, isMobile, toggle, closeMobile }}>
      {children}
    </CollapsedContext.Provider>
  );
}

export function useCollapsed() {
  return useContext(CollapsedContext);
}