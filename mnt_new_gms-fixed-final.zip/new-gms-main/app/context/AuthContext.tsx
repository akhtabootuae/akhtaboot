'use client';

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useRouter } from 'next/navigation';
import api from '@/services/api';

// Define user type based on the API response
type User = {
  id: string;
  name: string;
  email: string;
  role_name: string;
  role_id: string;
  role_description: string;
  branch: {
    branch_id: string;
    branch_name: string;
    branch_code: string;
    location?: string;
  };
  permissions?: {
    permission_id: string;
    permission_name: string;
    category?: string;
    granted: boolean;
  }[];
};

type AuthContextType = {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  clearAuth: () => void; // Add this for manual cleanup
  error: string | null;
};

// Create the context with default values
const AuthContext = createContext<AuthContextType>({
  user: null,
  token: null,
  isAuthenticated: false,
  isLoading: true,
  login: async () => {},
  logout: () => {},
  clearAuth: () => {},
  error: null,
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  // Clear all auth data
  const clearAuth = () => {
    localStorage.removeItem('authToken');
    localStorage.removeItem('user');
    document.cookie = 'authToken=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT; SameSite=Lax; Secure';
    setUser(null);
    setToken(null);
    setError(null);
  };

  // Validate token by making a test API request
  const validateToken = async (storedToken: string): Promise<boolean> => {
    const maxRetries = 3;

    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        // Use the dedicated token validation endpoint
        const response = await api.post('/api/users/validate',
          { token: storedToken },
          {
            headers: {
              'Content-Type': 'application/json'
            }
          }
        ) as any;

        // The api interceptor returns response.data directly, so response should contain { valid: true, decoded: ... }
        return response?.valid === true;
      } catch (error: any) {
        // Check if it's an authentication error (401, 400 for invalid token)
        // Don't treat 403 as token validation failure - it's a permission issue
        if (error.response?.status === 401 || error.response?.status === 400) {
          return false;
        }

        // For network/server errors, retry up to maxRetries times
        if (attempt === maxRetries) {
          console.error('Token validation failed after all retries:', error);
          return false;
        }

        // Wait before retrying (exponential backoff)
        await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
      }
    }

    return false;
  };

  // Check if user is logged in on initial load
  useEffect(() => {
    const checkAuth = async () => {
      try {
        // Get the token from localStorage
        const storedToken = localStorage.getItem('authToken');
        if (!storedToken) {
          setIsLoading(false);
          return;
        }

        // Validate the token before proceeding
        const isTokenValid = await validateToken(storedToken);
        if (!isTokenValid) {
          clearAuth();
          setIsLoading(false);
          return;
        }

        // Get the user from localStorage
        const storedUser = localStorage.getItem('user');
        if (!storedUser) {
          clearAuth();
          setIsLoading(false);
          return;
        }

        try {
          const parsedUser = JSON.parse(storedUser);

          // Validate user data structure
          if (!parsedUser.id || !parsedUser.email || !parsedUser.name) {
            clearAuth();
            setIsLoading(false);
            return;
          }

          // If permissions are missing and we have a token, fetch them
          if (!parsedUser.permissions && storedToken && parsedUser.id) {
            try {
              const permissionsData = await api.get(`/api/users/${parsedUser.id}/granted-permissions`) as any;
              if (permissionsData && permissionsData.granted_permissions) {
                // Convert the granted permissions to the format expected by the User type
                parsedUser.permissions = permissionsData.granted_permissions.map((perm: any) => ({
                  permission_id: perm.permission_id,
                  permission_name: perm.permission_name,
                  category: perm.category || 'Uncategorized',
                  granted: true // All permissions from this endpoint are granted
                }));
                // Update localStorage with the complete user data
                localStorage.setItem('user', JSON.stringify(parsedUser));
              }
            } catch (permError: any) {
              console.error('Failed to fetch missing permissions:', permError);

              // If it's an auth error, clear everything
              if (permError.response?.status === 401 || permError.response?.status === 403) {
                clearAuth();
                setIsLoading(false);
                return;
              }
            }
          }

          setUser(parsedUser);
          setToken(storedToken);

        } catch (parseError) {
          console.error('Error parsing user JSON:', parseError);
          clearAuth();
        }
      } catch (error) {
        console.error('Auth initialization error:', error);
        clearAuth();
      } finally {
        setIsLoading(false);
      }
    };

    checkAuth();
  }, []);

  // Add API interceptor to handle auth errors globally
  useEffect(() => {
    const interceptor = api.interceptors.response.use(
      (response) => response,
      (error) => {
        // Only treat 401 as auth error, not 403
        // 401 = Invalid/expired token (authentication issue)
        // 403 = Valid token but insufficient permissions (authorization issue)
        if (error.response?.status === 401) {
          clearAuth();
          router.push('/login');
        }
        return Promise.reject(error);
      }
    );

    // Cleanup interceptor on unmount
    return () => {
      api.interceptors.response.eject(interceptor);
    };
  }, [router]);

  // Login function
  const login = async (email: string, password: string) => {
    setError(null);
    try {
      setIsLoading(true);
      
      try {
        // Call the login API endpoint
        const response = await api.post('/api/users/login', { email, password });

        // Check if response exists
        if (!response) {
          throw new Error('Invalid response from server');
        }

        // Extract token and user based on response structure
        let authToken: string | null = null;
        let userData: User | null = null;

        // Try to extract token and user based on different possible response structures
        if (typeof response === 'object') {
          if ('token' in response && 'user' in response) {
            authToken = response.token as string;
            userData = response.user as User;
          } else if ('data' in response && typeof response.data === 'object') {
            const data = response.data as any;
            if (data && 'token' in data && 'user' in data) {
              authToken = data.token;
              userData = data.user;
            }
          }
        }

        // Validate extracted data
        if (!authToken || !userData) {
          throw new Error('Authentication failed: Missing token or user data');
        }

        // Validate user data structure
        if (!userData.id || !userData.email || !userData.name) {
          throw new Error('Authentication failed: Invalid user data');
        }

        // Check if user data includes permissions, if not fetch them separately
        if (!userData.permissions && authToken) {
          try {
            // Fetch granted permissions using the dedicated endpoint
            const permissionsData = await api.get(`/api/users/${userData.id}/granted-permissions`) as any;

            if (permissionsData && permissionsData.granted_permissions) {
              // Convert the granted permissions to the format expected by the User type
              userData.permissions = permissionsData.granted_permissions.map((perm: any) => ({
                permission_id: perm.permission_id,
                permission_name: perm.permission_name,
                category: perm.category || 'Uncategorized',
                granted: true // All permissions from this endpoint are granted
              }));
            }
          } catch (permError) {
            console.error('Failed to fetch user permissions:', permError);
            // Continue with login even if permissions fetch fails
          }
        }

        // Store the token and user in local storage
        localStorage.setItem('authToken', authToken);
        localStorage.setItem('user', JSON.stringify(userData));

        // Also set the cookie for middleware authentication
        document.cookie = `authToken=${authToken}; path=/; max-age=86400; SameSite=Lax; Secure`;

        // Update state
        setToken(authToken);
        setUser(userData);

        // Redirect to dashboard
        router.push('/');

      } catch (apiError) {
        throw apiError;
      }
    } catch (err: any) {
      console.error('Login error:', err);

      // Handle both axios error format and regular errors
      let errorMessage = 'Failed to login. Please try again.';

      if (err.response?.data?.message) {
        errorMessage = err.response.data.message;
      } else if (err.message) {
        errorMessage = err.message;
      }

      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  // Logout function
  const logout = () => {
    clearAuth();
    router.push('/login');
  };

  // Calculate authentication status
  const isAuthenticated = !!user && !!token;

  const value = {
    user,
    token,
    isAuthenticated,
    isLoading,
    login,
    logout,
    clearAuth,
    error,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

// Custom hook to use the auth context
export function useAuth() {
  return useContext(AuthContext);
}
