"use client";

import React, { createContext, useContext, useState, ReactNode } from 'react';

interface AutoPlayContextType {
  autoPlay: boolean;
  setAutoPlay: (value: boolean) => void;
  toggleAutoPlay: () => void;
}

const AutoPlayContext = createContext<AutoPlayContextType | undefined>(undefined);

export const useAutoPlay = () => {
  const context = useContext(AutoPlayContext);
  if (context === undefined) {
    throw new Error('useAutoPlay must be used within an AutoPlayProvider');
  }
  return context;
};

interface AutoPlayProviderProps {
  children: ReactNode;
}

export const AutoPlayProvider: React.FC<AutoPlayProviderProps> = ({ children }) => {
  const [autoPlay, setAutoPlay] = useState(false);

  const toggleAutoPlay = () => {
    setAutoPlay(prev => !prev);
  };

  const value: AutoPlayContextType = {
    autoPlay,
    setAutoPlay,
    toggleAutoPlay,
  };

  return (
    <AutoPlayContext.Provider value={value}>
      {children}
    </AutoPlayContext.Provider>
  );
};
