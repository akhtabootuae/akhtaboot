'use client';

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

type Language = 'en' | 'ar';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  isRTL: boolean;
}

interface LanguageProviderProps {
  children: ReactNode;
}

// Translation keys for the registration form
const translations = {
  en: {
    // General
    language: 'Language',
    english: 'English',
    arabic: 'العربية',
    next: 'Next',
    previous: 'Previous',
    submit: 'Submit',
    cancel: 'Cancel',
    save: 'Save',
    delete: 'Delete',
    edit: 'Edit',
    add: 'Add',
    select: 'Select',
    search: 'Search',
    loading: 'Loading...',
    
    // Registration Form - Step 1
    customerInformation: 'Customer Information',
    customerType: 'Customer Type',
    newCustomer: 'New Customer',
    existingCustomer: 'Existing Customer',
    firstName: 'First Name',
    lastName: 'Last Name',
    email: 'Email',
    phone: 'Phone',
    city: 'City',
    country: 'Country',
    selectCountry: 'Select a country',
    selectCity: 'Select a city',
    searchCustomers: 'Search customers...',
    noCustomersFound: 'No customers found',
    branch: 'Branch',
    selectBranch: 'Select a branch',
    
    // Vehicle Information
    vehicleInformation: 'Vehicle Information',
    make: 'Make',
    model: 'Model',
    year: 'Year',
    licensePlate: 'License Plate',
    vin: 'VIN',
    color: 'Color',
    vehicleType: 'Vehicle Type',
    selectVehicleType: 'Select vehicle type',
    plateRegion: 'Plate Region',
    selectPlateRegion: 'Select plate region',
    plateCountry: 'Plate Country',
    
    // Registration Form - Step 2
    repairDetails: 'Repair Details',
    serviceType: 'Service Type',
    selectServiceType: 'Select Service Type',
    addNewServiceType: 'Add New Service Type',
    viewServiceTypes: 'View Service Types',
    specialRequests: 'Special Requests',
    notes: 'Notes',
    price: 'Price',
    supervisorInformation: 'Supervisor Information',
    supervisorRatio: 'Supervisor Ratio',
    expectedDeliveryDate: 'Expected Delivery Date',
    assignedTechnician: 'Assigned Technician',
    selectTechnician: 'Select a technician',
    paymentInformation: 'Payment Information',
    downPayment: 'Down Payment',
    paymentStatus: 'Payment Status',
    paymentMethod: 'Payment Method',
    selectPaymentStatus: 'Select payment status',
    selectPaymentMethod: 'Select payment method',
    paid: 'Paid',
    unpaid: 'Unpaid',
    partial: 'Partial',
    cash: 'Cash',
    card: 'Card',
    bankTransfer: 'Bank Transfer',
    withTax: 'With Tax (Tax Invoice)',
    withoutTax: 'Without Tax (Car Job)',
    
    // Service Type Modal
    serviceTypes: 'Service Types',
    serviceCode: 'Service Code',
    description: 'Description',
    laborHours: 'Labor Hours',
    stages: 'Stages',
    actions: 'Actions',
    viewStages: 'View Stages',
    editServiceType: 'Edit Service Type',
    deleteServiceType: 'Delete Service Type',
    confirmDelete: 'Confirm Delete',
    deleteWarning: 'Are you sure you want to delete this service type?',
    deleteWarningNote: 'Warning: This action cannot be undone. The service type will be permanently deleted.',
    
    // Success/Error Messages
    registrationSuccess: 'Registration completed successfully!',
    registrationError: 'Registration failed. Please try again.',
    serviceTypeAdded: 'Service type added successfully',
    serviceTypeUpdated: 'Service type updated successfully',
    serviceTypeDeleted: 'Service type deleted successfully',
    fillRequiredFields: 'Please fill in all required fields',
  },
  ar: {
    // General
    language: 'اللغة',
    english: 'English',
    arabic: 'العربية',
    next: 'التالي',
    previous: 'السابق',
    submit: 'إرسال',
    cancel: 'إلغاء',
    save: 'حفظ',
    delete: 'حذف',
    edit: 'تعديل',
    add: 'إضافة',
    select: 'اختر',
    search: 'بحث',
    loading: 'جاري التحميل...',
    
    // Registration Form - Step 1
    customerInformation: 'معلومات العميل',
    customerType: 'نوع العميل',
    newCustomer: 'عميل جديد',
    existingCustomer: 'عميل حالي',
    firstName: 'الاسم الأول',
    lastName: 'اسم العائلة',
    email: 'البريد الإلكتروني',
    phone: 'الهاتف',
    city: 'المدينة',
    country: 'الدولة',
    selectCountry: 'اختر الدولة',
    selectCity: 'اختر المدينة',
    searchCustomers: 'البحث عن العملاء...',
    noCustomersFound: 'لم يتم العثور على عملاء',
    branch: 'الفرع',
    selectBranch: 'اختر الفرع',
    
    // Vehicle Information
    vehicleInformation: 'معلومات المركبة',
    make: 'الصانع',
    model: 'الموديل',
    year: 'السنة',
    licensePlate: 'رقم اللوحة',
    vin: 'رقم الهيكل',
    color: 'اللون',
    vehicleType: 'نوع المركبة',
    selectVehicleType: 'اختر نوع المركبة',
    plateRegion: 'منطقة اللوحة',
    selectPlateRegion: 'اختر منطقة اللوحة',
    plateCountry: 'بلد اللوحة',
    
    // Registration Form - Step 2
    repairDetails: 'تفاصيل الإصلاح',
    serviceType: 'نوع الخدمة',
    selectServiceType: 'اختر نوع الخدمة',
    addNewServiceType: 'إضافة نوع خدمة جديد',
    viewServiceTypes: 'عرض أنواع الخدمات',
    specialRequests: 'طلبات خاصة',
    notes: 'ملاحظات',
    price: 'السعر',
    supervisorInformation: 'معلومات المشرف',
    supervisorRatio: 'نسبة المشرف',
    expectedDeliveryDate: 'تاريخ التسليم المتوقع',
    assignedTechnician: 'الفني المخصص',
    selectTechnician: 'اختر الفني',
    paymentInformation: 'معلومات الدفع',
    downPayment: 'الدفعة المقدمة',
    paymentStatus: 'حالة الدفع',
    paymentMethod: 'طريقة الدفع',
    selectPaymentStatus: 'اختر حالة الدفع',
    selectPaymentMethod: 'اختر طريقة الدفع',
    paid: 'مدفوع',
    unpaid: 'غير مدفوع',
    partial: 'جزئي',
    cash: 'نقداً',
    card: 'بطاقة',
    bankTransfer: 'تحويل بنكي',
    withTax: 'مع الضريبة (فاتورة ضريبية)',
    withoutTax: 'بدون ضريبة (أمر عمل)',
    
    // Service Type Modal
    serviceTypes: 'أنواع الخدمات',
    serviceCode: 'رمز الخدمة',
    description: 'الوصف',
    laborHours: 'ساعات العمل',
    stages: 'المراحل',
    actions: 'الإجراءات',
    viewStages: 'عرض المراحل',
    editServiceType: 'تعديل نوع الخدمة',
    deleteServiceType: 'حذف نوع الخدمة',
    confirmDelete: 'تأكيد الحذف',
    deleteWarning: 'هل أنت متأكد من حذف نوع الخدمة هذا؟',
    deleteWarningNote: 'تحذير: لا يمكن التراجع عن هذا الإجراء. سيتم حذف نوع الخدمة نهائياً.',
    
    // Success/Error Messages
    registrationSuccess: 'تم التسجيل بنجاح!',
    registrationError: 'فشل التسجيل. يرجى المحاولة مرة أخرى.',
    serviceTypeAdded: 'تمت إضافة نوع الخدمة بنجاح',
    serviceTypeUpdated: 'تم تحديث نوع الخدمة بنجاح',
    serviceTypeDeleted: 'تم حذف نوع الخدمة بنجاح',
    fillRequiredFields: 'يرجى ملء جميع الحقول المطلوبة',
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<LanguageProviderProps> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>('en');

  // Load language preference from localStorage on mount
  useEffect(() => {
    const savedLanguage = localStorage.getItem('appLanguage') as Language;
    if (savedLanguage && (savedLanguage === 'en' || savedLanguage === 'ar')) {
      setLanguageState(savedLanguage);
      // Apply RTL if Arabic
      if (savedLanguage === 'ar') {
        document.documentElement.dir = 'rtl';
      }
    }
  }, []);

  // Save language preference and apply RTL/LTR
  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('appLanguage', lang);
    
    // Apply RTL for Arabic, LTR for English
    if (lang === 'ar') {
      document.documentElement.dir = 'rtl';
    } else {
      document.documentElement.dir = 'ltr';
    }
  };

  // Translation function
  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations['en']] || key;
  };

  const value: LanguageContextType = {
    language,
    setLanguage,
    t,
    isRTL: language === 'ar'
  };

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};