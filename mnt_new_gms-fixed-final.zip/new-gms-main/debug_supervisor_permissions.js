/**
 * Debug script to check supervisor permissions for registration endpoints
 */

const { MongoClient } = require('mongodb');

// Database configuration - Use remote MongoDB
const MONGO_URI = 'mongodb+srv://root:sSZba4as0uM25d0x@gmsdb.ilit0p8.mongodb.net/?retryWrites=true&w=majority&appName=gmsDB';
const DATABASE_NAME = 'GMS_DB';

// Registration permissions that should be checked
const REQUIRED_PERMISSIONS = {
  'create_customer': 'Customer creation endpoint',
  'create_work_order': 'Work order creation endpoint',
  'create_invoice': 'Invoice creation endpoint',
  'manage_vehicles': 'Vehicle management endpoint',
  'manage_invoice_images': 'Invoice image upload endpoint'
};

async function debugSupervisorPermissions() {
  const client = new MongoClient(MONGO_URI);
  
  try {
    await client.connect();
    console.log('Connected to MongoDB');
    
    const db = client.db(DATABASE_NAME);
    
    // Find the specific supervisor Ali Qadri
    const supervisor = await db.collection('users').findOne({
      email: "ali@akhtaboot.com"
    });
    
    if (!supervisor) {
      console.log('❌ Supervisor Ali Qadri not found');
      return;
    }
    
    console.log(`\n👤 User: ${supervisor.first_name} ${supervisor.last_name}`);
    console.log(`📧 Email: ${supervisor.email}`);
    console.log(`🔑 Role: ${supervisor.role_name}`);
    console.log(`✅ Active: ${supervisor.is_active}`);
    console.log(`📁 Permissions array length: ${supervisor.permissions?.length || 0}`);
    
    console.log('\n🔍 DEBUGGING PERMISSION STRUCTURE:');
    console.log('Sample permission object:');
    if (supervisor.permissions && supervisor.permissions[0]) {
      console.log(JSON.stringify(supervisor.permissions[0], null, 2));
    }
    
    console.log('\n🎯 REGISTRATION PERMISSION CHECK:');
    console.log('Required permissions for registration endpoints:');
    
    for (const [permissionName, description] of Object.entries(REQUIRED_PERMISSIONS)) {
      console.log(`\n--- ${permissionName} (${description}) ---`);
      
      // Check if permission exists and is granted
      const userPerm = supervisor.permissions?.find(p => 
        p.permission_name === permissionName && p.granted === true
      );
      
      if (userPerm) {
        console.log(`✅ GRANTED - Found: ${userPerm.permission_name} = ${userPerm.granted}`);
      } else {
        console.log(`❌ NOT FOUND or NOT GRANTED`);
        
        // Look for similar permission names
        const similarPerms = supervisor.permissions?.filter(p => 
          p.permission_name.includes(permissionName.split('_')[1]) // Look for keywords
        );
        
        if (similarPerms && similarPerms.length > 0) {
          console.log(`🔍 Similar permissions found:`);
          similarPerms.forEach(p => {
            console.log(`   - ${p.permission_name}: ${p.granted}`);
          });
        }
      }
    }
    
    console.log('\n📋 ALL GRANTED PERMISSIONS:');
    const grantedPermissions = supervisor.permissions?.filter(p => p.granted === true) || [];
    grantedPermissions.forEach(p => {
      console.log(`✅ ${p.permission_name}`);
    });
    
    console.log('\n🚫 ALL DENIED PERMISSIONS:');
    const deniedPermissions = supervisor.permissions?.filter(p => p.granted === false) || [];
    deniedPermissions.forEach(p => {
      console.log(`❌ ${p.permission_name}`);
    });
    
    // Simulate the middleware permission check
    console.log('\n🔧 SIMULATING MIDDLEWARE PERMISSION CHECK:');
    
    function simulatePermissionCheck(requiredPermission) {
      console.log(`\nChecking for: "${requiredPermission}"`);
      
      // This is exactly what the middleware does
      const userPerm = supervisor.permissions?.find(p => 
        p.permission_name === requiredPermission && p.granted === true
      );
      
      const result = !!userPerm;
      console.log(`Result: ${result ? '✅ PASS' : '❌ FAIL'}`);
      
      if (!result) {
        console.log('Middleware would return 403 Forbidden');
      }
      
      return result;
    }
    
    // Test each required permission
    for (const permissionName of Object.keys(REQUIRED_PERMISSIONS)) {
      simulatePermissionCheck(permissionName);
    }
    
  } catch (error) {
    console.error('❌ Error debugging permissions:', error);
    throw error;
  } finally {
    await client.close();
    console.log('\nDatabase connection closed');
  }
}

// Run the script
if (require.main === module) {
  debugSupervisorPermissions()
    .then(() => {
      console.log('\n🎯 Debug completed!');
      process.exit(0);
    })
    .catch((error) => {
      console.error('Debug failed:', error);
      process.exit(1);
    });
}

module.exports = { debugSupervisorPermissions };