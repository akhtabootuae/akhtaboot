/**
 * Script to grant registration-related permissions to existing supervisor and accountant users
 * This fixes the issue where existing users don't have the new registration permissions
 * that allow them to create customers, vehicles, work orders, and invoices.
 */

const { MongoClient } = require('mongodb');

// Database configuration - Use remote MongoDB
const MONGO_URI = process.env.MONGO_URI || 'mongodb+srv://root:sSZba4as0uM25d0x@gmsdb.ilit0p8.mongodb.net/?retryWrites=true&w=majority&appName=gmsDB';
const DATABASE_NAME = process.env.DATABASE_NAME || 'GMS_DB';

// Registration-related permissions that need to be granted
const REGISTRATION_PERMISSIONS = [
  // Customer Management - Required for creating customers and vehicles
  {
    permission_id: "create_customer",
    permission_name: "create_customer",
    permission_description: "Create new customer records",
    category: "CUSTOMER_MANAGEMENT"
  },
  {
    permission_id: "manage_vehicles",
    permission_name: "manage_vehicles",
    permission_description: "Add/update/remove customer vehicles",
    category: "CUSTOMER_MANAGEMENT"
  },
  
  // Work Order Management - Required for creating work orders
  {
    permission_id: "create_work_order",
    permission_name: "create_work_order",
    permission_description: "Create new work order records",
    category: "WORK_ORDER_MANAGEMENT"
  },
  
  // Invoice Management - Required for creating invoices with images
  {
    permission_id: "create_invoice",
    permission_name: "create_invoice",
    permission_description: "Create new invoice records",
    category: "INVOICE_MANAGEMENT"
  },
  {
    permission_id: "manage_invoice_images",
    permission_name: "manage_invoice_images",
    permission_description: "Add/remove images related to invoices",
    category: "INVOICE_MANAGEMENT"
  },
  
  // Additional permissions that both roles should have for registration
  {
    permission_id: "view_all_customers",
    permission_name: "view_all_customers",
    permission_description: "View all customers in the system",
    category: "CUSTOMER_MANAGEMENT"
  },
  {
    permission_id: "view_customer",
    permission_name: "view_customer",
    permission_description: "View specific customer details",
    category: "CUSTOMER_MANAGEMENT"
  },
  {
    permission_id: "update_customer",
    permission_name: "update_customer",
    permission_description: "Update customer information",
    category: "CUSTOMER_MANAGEMENT"
  }
];

async function fixRegistrationPermissions() {
  const client = new MongoClient(MONGO_URI);
  
  try {
    await client.connect();
    console.log('Connected to MongoDB');
    
    const db = client.db(DATABASE_NAME);
    
    // Get all supervisor and accountant users that need permission updates
    const usersToUpdate = await db.collection('users').find({
      role_name: { $in: ["Supervisor", "Accountant"] }
    }).toArray();
    
    console.log(`Found ${usersToUpdate.length} users (Supervisors and Accountants) to check for registration permissions`);
    
    let updatedCount = 0;
    
    for (const user of usersToUpdate) {
      console.log(`\nProcessing user: ${user.first_name} ${user.last_name} (${user.role_name})`);
      
      let hasUpdates = false;
      const newPermissions = [];
      
      // Check which registration permissions the user doesn't already have
      for (const permission of REGISTRATION_PERMISSIONS) {
        const hasPermission = user.permissions?.some(p => 
          (p.permission_id === permission.permission_id || p.permission_name === permission.permission_name)
        );
        
        if (!hasPermission) {
          console.log(`  ✓ Adding permission: ${permission.permission_name}`);
          newPermissions.push({
            permission_id: permission.permission_id,
            permission_name: permission.permission_name,
            permission_description: permission.permission_description,
            category: permission.category,
            granted: true
          });
          hasUpdates = true;
        } else {
          console.log(`  - Already has: ${permission.permission_name}`);
        }
      }
      
      // Update user if they need new permissions
      if (hasUpdates) {
        await db.collection('users').updateOne(
          { _id: user._id },
          {
            $push: {
              permissions: { $each: newPermissions }
            },
            $set: {
              updated_at: new Date()
            }
          }
        );
        
        console.log(`  ✅ Updated ${user.first_name} ${user.last_name} with ${newPermissions.length} new registration permissions`);
        updatedCount++;
      } else {
        console.log(`  ✅ ${user.first_name} ${user.last_name} already has all required registration permissions`);
      }
    }
    
    console.log(`\n🎉 Registration permission update completed!`);
    console.log(`📊 Total users processed: ${usersToUpdate.length}`);
    console.log(`🔄 Users updated: ${updatedCount}`);
    console.log(`✅ Users already up-to-date: ${usersToUpdate.length - updatedCount}`);
    
    // Verify the updates by checking a sample user
    if (updatedCount > 0) {
      console.log('\n📋 Verification - checking updated permissions...');
      const sampleUser = await db.collection('users').findOne({
        role_name: { $in: ["Supervisor", "Accountant"] }
      });
      
      if (sampleUser) {
        console.log(`Sample user: ${sampleUser.first_name} ${sampleUser.last_name}`);
        console.log('Registration permissions:');
        REGISTRATION_PERMISSIONS.forEach(perm => {
          const hasIt = sampleUser.permissions?.some(p => 
            p.permission_name === perm.permission_name && p.granted === true
          );
          console.log(`  ${hasIt ? '✅' : '❌'} ${perm.permission_name}`);
        });
      }
    }
    
  } catch (error) {
    console.error('❌ Error fixing registration permissions:', error);
    throw error;
  } finally {
    await client.close();
    console.log('Database connection closed');
  }
}

// Run the script
if (require.main === module) {
  fixRegistrationPermissions()
    .then(() => {
      console.log('\n🎯 Script completed successfully!');
      console.log('Existing supervisor and accountant users should now be able to access new registration.');
      process.exit(0);
    })
    .catch((error) => {
      console.error('Script failed:', error);
      process.exit(1);
    });
}

module.exports = { fixRegistrationPermissions };