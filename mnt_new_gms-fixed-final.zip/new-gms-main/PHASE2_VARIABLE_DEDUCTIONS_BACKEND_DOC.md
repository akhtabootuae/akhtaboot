# Phase 2: Variable Deductions System - Backend Implementation Guide

## Overview
This document provides the complete backend implementation guide for the Variable Deductions System (Phase 2 of the payroll system). This system allows managing employee-specific deductions such as salary advances, equipment purchases, loans, and other custom deductions.

## Prerequisites
1. Phase 1 (Employee Rate Management) must be completed
2. MongoDB collections created via `phase2_variable_deductions_mongodb_setup.js`
3. Required permissions added to the system

## Database Schema

### Collections Overview
- `payroll_deduction_types` - Types of deductions available
- `payroll_employee_deductions` - Active deductions for employees
- `payroll_deduction_history` - Historical record of deductions processed

### Collection Details

#### payroll_deduction_types
```javascript
{
  _id: ObjectId,
  name: String,              // "Employee Advance", "Equipment Purchase"
  description: String,       // Detailed description
  type: String,             // "fixed_amount", "percentage", "conditional"
  default_amount: Number,    // Default amount for fixed deductions
  default_percentage: Number, // Default percentage for percentage deductions
  frequency: String,         // "daily", "weekly", "monthly", "per_pay_period", "one_time"
  max_percentage_of_pay: Number, // Legal limit (e.g., 25% for garnishments)
  requires_approval: Boolean,    // Whether this type needs approval
  is_system_type: Boolean,       // System types cannot be deleted
  active: Boolean,              // Whether this type is available for use
  created_at: Date,
  updated_at: Date
}
```

#### payroll_employee_deductions
```javascript
{
  _id: ObjectId,
  employee_id: ObjectId,        // Reference to users collection
  deduction_type_id: ObjectId,  // Reference to payroll_deduction_types
  amount: Number,               // Deduction amount (fixed or percentage)
  frequency: String,            // How often to apply this deduction
  start_date: Date,            // When deduction starts
  end_date: Date,              // When deduction ends (null for ongoing)
  status: String,              // "active", "paused", "completed", "cancelled"
  priority: Number,            // 1-10, processing order (1 = highest)
  max_total_amount: Number,    // Total amount to deduct (for loans/advances)
  total_deducted: Number,      // Amount deducted so far
  remaining_balance: Number,   // Remaining balance (for loans/advances)
  notes: String,               // Additional notes
  reference_number: String,    // External reference (court order, etc.)
  legal_required: Boolean,     // Legal requirement (garnishments)
  created_by: ObjectId,        // User who created this deduction
  approved_by: ObjectId,       // User who approved (if required)
  approved_at: Date,           // When approved
  created_at: Date,
  updated_at: Date
}
```

#### payroll_deduction_history
```javascript
{
  _id: ObjectId,
  employee_deduction_id: ObjectId, // Reference to payroll_employee_deductions
  employee_id: ObjectId,           // Reference to users collection
  pay_period_start: Date,          // Start of pay period
  pay_period_end: Date,            // End of pay period
  gross_pay_amount: Number,        // Employee's gross pay for period
  amount_deducted: Number,         // Amount actually deducted
  reason_for_variance: String,     // If amount differs from configured
  remaining_balance_after: Number, // Balance after this deduction
  processed_by: ObjectId,          // User who processed payroll
  processed_at: Date               // When processed
}
```

## Models Implementation

### 1. PayrollDeductionType Model
Create `/models/PayrollDeductionType.js`:

```javascript
const { ObjectId } = require('mongodb');

class PayrollDeductionType {
  static getSchema() {
    return {
      validator: {
        $jsonSchema: {
          bsonType: "object",
          required: ["name", "type", "created_at"],
          properties: {
            name: {
              bsonType: "string",
              minLength: 1,
              maxLength: 100
            },
            description: {
              bsonType: "string",
              maxLength: 500
            },
            type: {
              bsonType: "string",
              enum: ["fixed_amount", "percentage", "conditional"]
            },
            default_amount: {
              bsonType: ["number", "null"],
              minimum: 0
            },
            default_percentage: {
              bsonType: ["number", "null"],
              minimum: 0,
              maximum: 100
            },
            frequency: {
              bsonType: "string",
              enum: ["daily", "weekly", "monthly", "per_pay_period", "one_time"]
            },
            max_percentage_of_pay: {
              bsonType: ["number", "null"],
              minimum: 0,
              maximum: 100
            },
            requires_approval: { bsonType: "bool" },
            is_system_type: { bsonType: "bool" },
            active: { bsonType: "bool" },
            created_at: { bsonType: "date" },
            updated_at: { bsonType: "date" }
          }
        }
      }
    };
  }

  static async findAll(db, filters = {}) {
    const query = {};
    if (filters.active !== undefined) query.active = filters.active;
    if (filters.type) query.type = filters.type;
    
    return await db.collection('payroll_deduction_types')
      .find(query)
      .sort({ name: 1 })
      .toArray();
  }

  static async findById(db, id) {
    return await db.collection('payroll_deduction_types')
      .findOne({ _id: new ObjectId(id) });
  }

  static async create(db, deductionTypeData) {
    const deductionType = {
      ...deductionTypeData,
      _id: new ObjectId(),
      created_at: new Date(),
      updated_at: new Date()
    };

    const result = await db.collection('payroll_deduction_types').insertOne(deductionType);
    return { ...deductionType, _id: result.insertedId };
  }

  static async update(db, id, updateData) {
    const updatedData = {
      ...updateData,
      updated_at: new Date()
    };

    const result = await db.collection('payroll_deduction_types').updateOne(
      { _id: new ObjectId(id) },
      { $set: updatedData }
    );

    return result.modifiedCount > 0;
  }

  static async delete(db, id) {
    // Check if it's a system type
    const deductionType = await this.findById(db, id);
    if (deductionType?.is_system_type) {
      throw new Error('Cannot delete system deduction types');
    }

    // Check if any active deductions use this type
    const activeDeductions = await db.collection('payroll_employee_deductions')
      .countDocuments({
        deduction_type_id: new ObjectId(id),
        status: 'active'
      });

    if (activeDeductions > 0) {
      throw new Error('Cannot delete deduction type with active deductions');
    }

    const result = await db.collection('payroll_deduction_types').deleteOne({
      _id: new ObjectId(id)
    });

    return result.deletedCount > 0;
  }

  static validateDeductionType(data) {
    const errors = [];

    if (!data.name || data.name.trim().length === 0) {
      errors.push('Name is required');
    }

    if (!data.type || !['fixed_amount', 'percentage', 'conditional'].includes(data.type)) {
      errors.push('Valid type is required');
    }

    if (data.type === 'fixed_amount' && data.default_amount !== null && data.default_amount < 0) {
      errors.push('Default amount must be positive');
    }

    if (data.type === 'percentage' && data.default_percentage !== null && 
        (data.default_percentage < 0 || data.default_percentage > 100)) {
      errors.push('Default percentage must be between 0 and 100');
    }

    return errors;
  }
}

module.exports = PayrollDeductionType;
```

### 2. PayrollEmployeeDeduction Model
Create `/models/PayrollEmployeeDeduction.js`:

```javascript
const { ObjectId } = require('mongodb');

class PayrollEmployeeDeduction {
  static getSchema() {
    return {
      validator: {
        $jsonSchema: {
          bsonType: "object",
          required: ["employee_id", "deduction_type_id", "amount", "frequency", "start_date", "status", "created_by", "created_at"],
          properties: {
            employee_id: { bsonType: "objectId" },
            deduction_type_id: { bsonType: "objectId" },
            amount: { bsonType: "number", minimum: 0 },
            frequency: {
              bsonType: "string",
              enum: ["daily", "weekly", "monthly", "per_pay_period", "one_time"]
            },
            start_date: { bsonType: "date" },
            end_date: { bsonType: ["date", "null"] },
            status: {
              bsonType: "string",
              enum: ["active", "paused", "completed", "cancelled"]
            },
            priority: { bsonType: "int", minimum: 1, maximum: 10 },
            max_total_amount: { bsonType: ["number", "null"], minimum: 0 },
            total_deducted: { bsonType: "number", minimum: 0 },
            remaining_balance: { bsonType: ["number", "null"], minimum: 0 },
            notes: { bsonType: "string", maxLength: 1000 },
            reference_number: { bsonType: "string", maxLength: 50 },
            legal_required: { bsonType: "bool" },
            created_by: { bsonType: "objectId" },
            approved_by: { bsonType: ["objectId", "null"] },
            approved_at: { bsonType: ["date", "null"] },
            created_at: { bsonType: "date" },
            updated_at: { bsonType: "date" }
          }
        }
      }
    };
  }

  static async findByEmployee(db, employeeId, filters = {}) {
    const query = { employee_id: new ObjectId(employeeId) };
    
    if (filters.status) query.status = filters.status;
    if (filters.active_only) query.status = 'active';
    
    return await db.collection('payroll_employee_deductions')
      .aggregate([
        { $match: query },
        {
          $lookup: {
            from: 'payroll_deduction_types',
            localField: 'deduction_type_id',
            foreignField: '_id',
            as: 'deduction_type'
          }
        },
        { $unwind: '$deduction_type' },
        {
          $lookup: {
            from: 'users',
            localField: 'created_by',
            foreignField: '_id',
            as: 'created_by_user'
          }
        },
        { $unwind: { path: '$created_by_user', preserveNullAndEmptyArrays: true } },
        { $sort: { priority: 1, created_at: -1 } }
      ])
      .toArray();
  }

  static async findById(db, id) {
    const result = await db.collection('payroll_employee_deductions')
      .aggregate([
        { $match: { _id: new ObjectId(id) } },
        {
          $lookup: {
            from: 'payroll_deduction_types',
            localField: 'deduction_type_id',
            foreignField: '_id',
            as: 'deduction_type'
          }
        },
        { $unwind: '$deduction_type' },
        {
          $lookup: {
            from: 'users',
            localField: 'employee_id',
            foreignField: '_id',
            as: 'employee'
          }
        },
        { $unwind: '$employee' }
      ])
      .toArray();

    return result[0] || null;
  }

  static async create(db, deductionData) {
    // Validate business rules
    await this.validateBusinessRules(db, deductionData);

    const deduction = {
      ...deductionData,
      _id: new ObjectId(),
      employee_id: new ObjectId(deductionData.employee_id),
      deduction_type_id: new ObjectId(deductionData.deduction_type_id),
      created_by: new ObjectId(deductionData.created_by),
      total_deducted: 0,
      remaining_balance: deductionData.max_total_amount || null,
      status: deductionData.requires_approval ? 'pending_approval' : 'active',
      created_at: new Date(),
      updated_at: new Date()
    };

    const result = await db.collection('payroll_employee_deductions').insertOne(deduction);
    return { ...deduction, _id: result.insertedId };
  }

  static async update(db, id, updateData) {
    const updatedData = {
      ...updateData,
      updated_at: new Date()
    };

    // Remove fields that shouldn't be updated directly
    delete updatedData._id;
    delete updatedData.total_deducted;

    const result = await db.collection('payroll_employee_deductions').updateOne(
      { _id: new ObjectId(id) },
      { $set: updatedData }
    );

    return result.modifiedCount > 0;
  }

  static async approve(db, id, approvedBy) {
    const result = await db.collection('payroll_employee_deductions').updateOne(
      { _id: new ObjectId(id), status: 'pending_approval' },
      {
        $set: {
          status: 'active',
          approved_by: new ObjectId(approvedBy),
          approved_at: new Date(),
          updated_at: new Date()
        }
      }
    );

    return result.modifiedCount > 0;
  }

  static async updateBalance(db, id, amountDeducted) {
    const deduction = await db.collection('payroll_employee_deductions')
      .findOne({ _id: new ObjectId(id) });

    if (!deduction) {
      throw new Error('Deduction not found');
    }

    const newTotalDeducted = deduction.total_deducted + amountDeducted;
    const newRemainingBalance = deduction.max_total_amount ? 
      deduction.max_total_amount - newTotalDeducted : null;

    const updateData = {
      total_deducted: newTotalDeducted,
      remaining_balance: newRemainingBalance,
      updated_at: new Date()
    };

    // Mark as completed if balance reaches zero
    if (newRemainingBalance !== null && newRemainingBalance <= 0) {
      updateData.status = 'completed';
      updateData.end_date = new Date();
    }

    const result = await db.collection('payroll_employee_deductions').updateOne(
      { _id: new ObjectId(id) },
      { $set: updateData }
    );

    return result.modifiedCount > 0;
  }

  static async validateBusinessRules(db, deductionData) {
    const errors = [];

    // Check if employee exists and is payroll eligible
    const employee = await db.collection('users').findOne({
      _id: new ObjectId(deductionData.employee_id),
      'payroll_info.payroll_eligible': true
    });

    if (!employee) {
      errors.push('Employee not found or not payroll eligible');
    }

    // Check if deduction type exists and is active
    const deductionType = await db.collection('payroll_deduction_types').findOne({
      _id: new ObjectId(deductionData.deduction_type_id),
      active: true
    });

    if (!deductionType) {
      errors.push('Deduction type not found or inactive');
    }

    // Validate amount and percentage limits
    if (deductionType && deductionType.max_percentage_of_pay) {
      // This validation will be enhanced in Phase 3 when we have pay calculation
      // For now, just validate that the percentage limit exists
      if (deductionType.type === 'percentage' && 
          deductionData.amount > deductionType.max_percentage_of_pay) {
        errors.push(`Deduction percentage cannot exceed ${deductionType.max_percentage_of_pay}%`);
      }
    }

    // Validate date range
    if (deductionData.end_date && new Date(deductionData.end_date) <= new Date(deductionData.start_date)) {
      errors.push('End date must be after start date');
    }

    if (errors.length > 0) {
      throw new Error(errors.join(', '));
    }
  }

  static async getActiveDeductionsForPayroll(db, employeeId, payPeriodStart, payPeriodEnd) {
    return await db.collection('payroll_employee_deductions')
      .find({
        employee_id: new ObjectId(employeeId),
        status: 'active',
        start_date: { $lte: new Date(payPeriodEnd) },
        $or: [
          { end_date: null },
          { end_date: { $gte: new Date(payPeriodStart) } }
        ]
      })
      .sort({ priority: 1 })
      .toArray();
  }
}

module.exports = PayrollEmployeeDeduction;
```

### 3. PayrollDeductionHistory Model
Create `/models/PayrollDeductionHistory.js`:

```javascript
const { ObjectId } = require('mongodb');

class PayrollDeductionHistory {
  static async create(db, historyData) {
    const history = {
      ...historyData,
      _id: new ObjectId(),
      employee_deduction_id: new ObjectId(historyData.employee_deduction_id),
      employee_id: new ObjectId(historyData.employee_id),
      processed_by: historyData.processed_by ? new ObjectId(historyData.processed_by) : null,
      processed_at: new Date()
    };

    const result = await db.collection('payroll_deduction_history').insertOne(history);
    return { ...history, _id: result.insertedId };
  }

  static async findByEmployee(db, employeeId, options = {}) {
    const { limit = 50, skip = 0, startDate, endDate } = options;
    
    const query = { employee_id: new ObjectId(employeeId) };
    
    if (startDate || endDate) {
      query.pay_period_start = {};
      if (startDate) query.pay_period_start.$gte = new Date(startDate);
      if (endDate) query.pay_period_start.$lte = new Date(endDate);
    }

    return await db.collection('payroll_deduction_history')
      .aggregate([
        { $match: query },
        {
          $lookup: {
            from: 'payroll_employee_deductions',
            localField: 'employee_deduction_id',
            foreignField: '_id',
            as: 'deduction'
          }
        },
        { $unwind: '$deduction' },
        {
          $lookup: {
            from: 'payroll_deduction_types',
            localField: 'deduction.deduction_type_id',
            foreignField: '_id',
            as: 'deduction_type'
          }
        },
        { $unwind: '$deduction_type' },
        { $sort: { processed_at: -1 } },
        { $skip: skip },
        { $limit: limit }
      ])
      .toArray();
  }

  static async findByDeduction(db, deductionId) {
    return await db.collection('payroll_deduction_history')
      .find({ employee_deduction_id: new ObjectId(deductionId) })
      .sort({ processed_at: -1 })
      .toArray();
  }

  static async getDeductionSummary(db, employeeId, options = {}) {
    const { startDate, endDate } = options;
    
    const matchQuery = { employee_id: new ObjectId(employeeId) };
    
    if (startDate || endDate) {
      matchQuery.pay_period_start = {};
      if (startDate) matchQuery.pay_period_start.$gte = new Date(startDate);
      if (endDate) matchQuery.pay_period_start.$lte = new Date(endDate);
    }

    return await db.collection('payroll_deduction_history')
      .aggregate([
        { $match: matchQuery },
        {
          $lookup: {
            from: 'payroll_employee_deductions',
            localField: 'employee_deduction_id',
            foreignField: '_id',
            as: 'deduction'
          }
        },
        { $unwind: '$deduction' },
        {
          $lookup: {
            from: 'payroll_deduction_types',
            localField: 'deduction.deduction_type_id',
            foreignField: '_id',
            as: 'deduction_type'
          }
        },
        { $unwind: '$deduction_type' },
        {
          $group: {
            _id: '$deduction_type.name',
            total_deducted: { $sum: '$amount_deducted' },
            deduction_count: { $sum: 1 },
            deduction_type: { $first: '$deduction_type' }
          }
        },
        { $sort: { total_deducted: -1 } }
      ])
      .toArray();
  }
}

module.exports = PayrollDeductionHistory;
```

## API Routes Implementation

### 1. Deduction Types Routes
Create `/routes/payroll/deductionTypes.js`:

```javascript
const express = require('express');
const router = express.Router();
const PayrollDeductionType = require('../../models/PayrollDeductionType');
const permissionAuth = require('../../middleware/permissionAuth');
const { getDb } = require('../../config/database');

// GET /api/payroll/deduction-types - Get all deduction types
router.get('/', 
  permissionAuth(['payroll_manage_deductions', 'payroll_view_deductions']),
  async (req, res) => {
    try {
      const db = getDb();
      const { active } = req.query;
      
      const filters = {};
      if (active !== undefined) filters.active = active === 'true';
      
      const deductionTypes = await PayrollDeductionType.findAll(db, filters);
      
      res.json({
        message: 'Deduction types retrieved successfully',
        deduction_types: deductionTypes
      });
    } catch (error) {
      console.error('Error fetching deduction types:', error);
      res.status(500).json({
        message: 'Failed to retrieve deduction types',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/deduction-types/:id - Get specific deduction type
router.get('/:id',
  permissionAuth(['payroll_manage_deductions', 'payroll_view_deductions']),
  async (req, res) => {
    try {
      const db = getDb();
      const deductionType = await PayrollDeductionType.findById(db, req.params.id);
      
      if (!deductionType) {
        return res.status(404).json({
          message: 'Deduction type not found'
        });
      }
      
      res.json({
        message: 'Deduction type retrieved successfully',
        deduction_type: deductionType
      });
    } catch (error) {
      console.error('Error fetching deduction type:', error);
      res.status(500).json({
        message: 'Failed to retrieve deduction type',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/deduction-types - Create new deduction type
router.post('/',
  permissionAuth('payroll_manage_deduction_types'),
  async (req, res) => {
    try {
      const db = getDb();
      
      // Validate input
      const errors = PayrollDeductionType.validateDeductionType(req.body);
      if (errors.length > 0) {
        return res.status(400).json({
          message: 'Validation failed',
          errors: errors
        });
      }
      
      const deductionTypeData = {
        ...req.body,
        is_system_type: false, // User-created types are not system types
        active: true
      };
      
      const deductionType = await PayrollDeductionType.create(db, deductionTypeData);
      
      res.status(201).json({
        message: 'Deduction type created successfully',
        deduction_type: deductionType
      });
    } catch (error) {
      console.error('Error creating deduction type:', error);
      res.status(500).json({
        message: 'Failed to create deduction type',
        error: error.message
      });
    }
  }
);

// PUT /api/payroll/deduction-types/:id - Update deduction type
router.put('/:id',
  permissionAuth('payroll_manage_deduction_types'),
  async (req, res) => {
    try {
      const db = getDb();
      
      // Check if deduction type exists
      const existingType = await PayrollDeductionType.findById(db, req.params.id);
      if (!existingType) {
        return res.status(404).json({
          message: 'Deduction type not found'
        });
      }
      
      // Validate input
      const errors = PayrollDeductionType.validateDeductionType(req.body);
      if (errors.length > 0) {
        return res.status(400).json({
          message: 'Validation failed',
          errors: errors
        });
      }
      
      const success = await PayrollDeductionType.update(db, req.params.id, req.body);
      
      if (!success) {
        return res.status(404).json({
          message: 'Deduction type not found or no changes made'
        });
      }
      
      const updatedType = await PayrollDeductionType.findById(db, req.params.id);
      
      res.json({
        message: 'Deduction type updated successfully',
        deduction_type: updatedType
      });
    } catch (error) {
      console.error('Error updating deduction type:', error);
      res.status(500).json({
        message: 'Failed to update deduction type',
        error: error.message
      });
    }
  }
);

// DELETE /api/payroll/deduction-types/:id - Delete deduction type
router.delete('/:id',
  permissionAuth('payroll_manage_deduction_types'),
  async (req, res) => {
    try {
      const db = getDb();
      
      const success = await PayrollDeductionType.delete(db, req.params.id);
      
      if (!success) {
        return res.status(404).json({
          message: 'Deduction type not found'
        });
      }
      
      res.json({
        message: 'Deduction type deleted successfully'
      });
    } catch (error) {
      console.error('Error deleting deduction type:', error);
      if (error.message.includes('Cannot delete')) {
        return res.status(400).json({
          message: error.message
        });
      }
      res.status(500).json({
        message: 'Failed to delete deduction type',
        error: error.message
      });
    }
  }
);

module.exports = router;
```

### 2. Employee Deductions Routes
Create `/routes/payroll/employeeDeductions.js`:

```javascript
const express = require('express');
const router = express.Router();
const PayrollEmployeeDeduction = require('../../models/PayrollEmployeeDeduction');
const PayrollAuditLog = require('../../models/PayrollAuditLog');
const permissionAuth = require('../../middleware/permissionAuth');
const { getDb } = require('../../config/database');

// GET /api/payroll/employees/:employeeId/deductions - Get employee's deductions
router.get('/:employeeId/deductions',
  permissionAuth(['payroll_manage_deductions', 'payroll_view_deductions']),
  async (req, res) => {
    try {
      const db = getDb();
      const { status, active_only } = req.query;
      
      const filters = {};
      if (status) filters.status = status;
      if (active_only === 'true') filters.active_only = true;
      
      const deductions = await PayrollEmployeeDeduction.findByEmployee(db, req.params.employeeId, filters);
      
      res.json({
        message: 'Employee deductions retrieved successfully',
        deductions: deductions
      });
    } catch (error) {
      console.error('Error fetching employee deductions:', error);
      res.status(500).json({
        message: 'Failed to retrieve employee deductions',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/deductions/:id - Get specific deduction
router.get('/deductions/:id',
  permissionAuth(['payroll_manage_deductions', 'payroll_view_deductions']),
  async (req, res) => {
    try {
      const db = getDb();
      const deduction = await PayrollEmployeeDeduction.findById(db, req.params.id);
      
      if (!deduction) {
        return res.status(404).json({
          message: 'Deduction not found'
        });
      }
      
      res.json({
        message: 'Deduction retrieved successfully',
        deduction: deduction
      });
    } catch (error) {
      console.error('Error fetching deduction:', error);
      res.status(500).json({
        message: 'Failed to retrieve deduction',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/employees/:employeeId/deductions - Create new deduction
router.post('/:employeeId/deductions',
  permissionAuth('payroll_manage_deductions'),
  async (req, res) => {
    try {
      const db = getDb();
      
      const deductionData = {
        ...req.body,
        employee_id: req.params.employeeId,
        created_by: req.user._id
      };
      
      const deduction = await PayrollEmployeeDeduction.create(db, deductionData);
      
      // Log the audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'create_deduction',
        entity_type: 'employee_deduction',
        entity_id: deduction._id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          employee_id: req.params.employeeId,
          deduction_type_id: deductionData.deduction_type_id,
          amount: deductionData.amount,
          frequency: deductionData.frequency
        },
        severity: 'medium',
        category: 'data_modification'
      });
      
      res.status(201).json({
        message: 'Employee deduction created successfully',
        deduction: deduction
      });
    } catch (error) {
      console.error('Error creating employee deduction:', error);
      res.status(400).json({
        message: 'Failed to create employee deduction',
        error: error.message
      });
    }
  }
);

// PUT /api/payroll/deductions/:id - Update deduction
router.put('/deductions/:id',
  permissionAuth('payroll_manage_deductions'),
  async (req, res) => {
    try {
      const db = getDb();
      
      // Get existing deduction for audit
      const existingDeduction = await PayrollEmployeeDeduction.findById(db, req.params.id);
      if (!existingDeduction) {
        return res.status(404).json({
          message: 'Deduction not found'
        });
      }
      
      const success = await PayrollEmployeeDeduction.update(db, req.params.id, req.body);
      
      if (!success) {
        return res.status(404).json({
          message: 'Deduction not found or no changes made'
        });
      }
      
      // Log the audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'update_deduction',
        entity_type: 'employee_deduction',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          old_values: existingDeduction,
          new_values: req.body
        },
        severity: 'medium',
        category: 'data_modification'
      });
      
      const updatedDeduction = await PayrollEmployeeDeduction.findById(db, req.params.id);
      
      res.json({
        message: 'Deduction updated successfully',
        deduction: updatedDeduction
      });
    } catch (error) {
      console.error('Error updating deduction:', error);
      res.status(500).json({
        message: 'Failed to update deduction',
        error: error.message
      });
    }
  }
);

// POST /api/payroll/deductions/:id/approve - Approve deduction
router.post('/deductions/:id/approve',
  permissionAuth('payroll_approve_deductions'),
  async (req, res) => {
    try {
      const db = getDb();
      
      const success = await PayrollEmployeeDeduction.approve(db, req.params.id, req.user._id);
      
      if (!success) {
        return res.status(404).json({
          message: 'Deduction not found or not pending approval'
        });
      }
      
      // Log the audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'approve_deduction',
        entity_type: 'employee_deduction',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          approval_notes: req.body.notes
        },
        severity: 'high',
        category: 'authorization'
      });
      
      const approvedDeduction = await PayrollEmployeeDeduction.findById(db, req.params.id);
      
      res.json({
        message: 'Deduction approved successfully',
        deduction: approvedDeduction
      });
    } catch (error) {
      console.error('Error approving deduction:', error);
      res.status(500).json({
        message: 'Failed to approve deduction',
        error: error.message
      });
    }
  }
);

// PUT /api/payroll/deductions/:id/status - Update deduction status
router.put('/deductions/:id/status',
  permissionAuth('payroll_manage_deductions'),
  async (req, res) => {
    try {
      const db = getDb();
      const { status, reason } = req.body;
      
      if (!['active', 'paused', 'cancelled'].includes(status)) {
        return res.status(400).json({
          message: 'Invalid status. Must be active, paused, or cancelled'
        });
      }
      
      const updateData = { status };
      if (status === 'cancelled') {
        updateData.end_date = new Date();
      }
      
      const success = await PayrollEmployeeDeduction.update(db, req.params.id, updateData);
      
      if (!success) {
        return res.status(404).json({
          message: 'Deduction not found'
        });
      }
      
      // Log the audit trail
      await PayrollAuditLog.createAuditEntry(db, {
        user_id: req.user._id,
        user_email: req.user.email,
        action: 'update_deduction_status',
        entity_type: 'employee_deduction',
        entity_id: req.params.id,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        details: {
          new_status: status,
          reason: reason
        },
        severity: 'medium',
        category: 'data_modification'
      });
      
      const updatedDeduction = await PayrollEmployeeDeduction.findById(db, req.params.id);
      
      res.json({
        message: 'Deduction status updated successfully',
        deduction: updatedDeduction
      });
    } catch (error) {
      console.error('Error updating deduction status:', error);
      res.status(500).json({
        message: 'Failed to update deduction status',
        error: error.message
      });
    }
  }
);

module.exports = router;
```

### 3. Deduction History Routes
Create `/routes/payroll/deductionHistory.js`:

```javascript
const express = require('express');
const router = express.Router();
const PayrollDeductionHistory = require('../../models/PayrollDeductionHistory');
const permissionAuth = require('../../middleware/permissionAuth');
const { getDb } = require('../../config/database');

// GET /api/payroll/employees/:employeeId/deduction-history - Get employee's deduction history
router.get('/:employeeId/deduction-history',
  permissionAuth(['payroll_view_deduction_history', 'payroll_manage_deductions']),
  async (req, res) => {
    try {
      const db = getDb();
      const { page = 1, limit = 50, start_date, end_date } = req.query;
      
      const options = {
        limit: parseInt(limit),
        skip: (parseInt(page) - 1) * parseInt(limit),
        startDate: start_date,
        endDate: end_date
      };
      
      const history = await PayrollDeductionHistory.findByEmployee(db, req.params.employeeId, options);
      
      res.json({
        message: 'Employee deduction history retrieved successfully',
        history: history,
        pagination: {
          current_page: parseInt(page),
          limit: parseInt(limit)
        }
      });
    } catch (error) {
      console.error('Error fetching deduction history:', error);
      res.status(500).json({
        message: 'Failed to retrieve deduction history',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/deductions/:deductionId/history - Get history for specific deduction
router.get('/deductions/:deductionId/history',
  permissionAuth(['payroll_view_deduction_history', 'payroll_manage_deductions']),
  async (req, res) => {
    try {
      const db = getDb();
      const history = await PayrollDeductionHistory.findByDeduction(db, req.params.deductionId);
      
      res.json({
        message: 'Deduction history retrieved successfully',
        history: history
      });
    } catch (error) {
      console.error('Error fetching deduction history:', error);
      res.status(500).json({
        message: 'Failed to retrieve deduction history',
        error: error.message
      });
    }
  }
);

// GET /api/payroll/employees/:employeeId/deduction-summary - Get deduction summary
router.get('/:employeeId/deduction-summary',
  permissionAuth(['payroll_view_deduction_history', 'payroll_manage_deductions']),
  async (req, res) => {
    try {
      const db = getDb();
      const { start_date, end_date } = req.query;
      
      const options = {
        startDate: start_date,
        endDate: end_date
      };
      
      const summary = await PayrollDeductionHistory.getDeductionSummary(db, req.params.employeeId, options);
      
      res.json({
        message: 'Deduction summary retrieved successfully',
        summary: summary
      });
    } catch (error) {
      console.error('Error fetching deduction summary:', error);
      res.status(500).json({
        message: 'Failed to retrieve deduction summary',
        error: error.message
      });
    }
  }
);

module.exports = router;
```

## Main Route Integration

Update your main payroll routes file (`/routes/payroll/index.js` or similar):

```javascript
const express = require('express');
const router = express.Router();

// Import route modules
const employeeRoutes = require('./employees');
const deductionTypeRoutes = require('./deductionTypes');
const employeeDeductionRoutes = require('./employeeDeductions');
const deductionHistoryRoutes = require('./deductionHistory');
const auditRoutes = require('./audit');

// Mount routes
router.use('/employees', employeeRoutes);
router.use('/deduction-types', deductionTypeRoutes);
router.use('/employees', employeeDeductionRoutes);
router.use('/employees', deductionHistoryRoutes);
router.use('/audit-log', auditRoutes);

module.exports = router;
```

## Business Logic & Validation

### Key Business Rules Implemented

1. **Legal Compliance**: Maximum percentage limits for deductions
2. **Priority Processing**: Deductions processed in priority order (1 = highest)
3. **Balance Tracking**: Automatic completion when loan/advance balances reach zero
4. **Approval Workflow**: Some deduction types require approval before activation
5. **Audit Trail**: All deduction changes are logged for compliance

### Validation Rules

1. **Employee Validation**: Must be payroll-eligible
2. **Deduction Type Validation**: Must be active and valid
3. **Amount Validation**: Must respect percentage limits
4. **Date Validation**: Start date must be before end date
5. **Status Validation**: Proper status transitions

## Security Considerations

1. **Permission-Based Access**: All routes protected by appropriate permissions
2. **Audit Logging**: Complete audit trail for compliance
3. **Input Validation**: Comprehensive validation at model level
4. **Business Rule Enforcement**: Prevents invalid deduction setups

## Testing Recommendations

### Unit Tests
- Test all model methods with various scenarios
- Test validation logic thoroughly
- Test edge cases (zero balances, date boundaries)

### Integration Tests
- Test complete deduction lifecycle
- Test approval workflows
- Test balance calculations
- Test audit logging

### API Tests
- Test all endpoints with valid and invalid data
- Test permission enforcement
- Test error handling

## Performance Considerations

1. **Database Indexes**: Created for optimal query performance
2. **Aggregation Pipelines**: Used for efficient data joining
3. **Pagination**: Implemented for large datasets
4. **Query Optimization**: Efficient queries for common operations

## Next Steps

1. **Implement all models and routes** as documented
2. **Add comprehensive error handling**
3. **Write unit and integration tests**
4. **Test with sample data**
5. **Deploy and test API endpoints**
6. **Ready for frontend implementation**

Once the backend is implemented and tested, the frontend development can begin to provide the user interface for managing variable deductions.