export interface Vehicle {
  vehicle_id: number;
  make: string;
  model: string;
  license_plate: string;
  vin: string;
  year: number;
  color: string;
  vehicle_type: string;
  created_at: string;
  updated_at: string;
}

export interface Branch {
  branch_id: string;
  branch_name: string;
  branch_code: string;
  location: string;
}

export interface Customer {
  _id: string;
  first_name: string;
  last_name: string;
  email: string;
  phone?: string;
  city?: string;
  country?: string;
  branch: Branch;
  vehicles: Vehicle[];
  created_at: string;
  updated_at: string;
}

export interface WorkOrderPart {
  partName: string;
  status: 'pending' | 'in_progress' | 'completed';
  createdAt: string;
  updatedAt?: string;
}

export interface WorkOrder {
  _id: string;
  workOrderNumber: string;
  customer_id: string;
  vehicle_id: number;
  status: 'open' | 'in_progress' | 'on_hold' | 'completed' | 'closed';
  description?: string;
  createdAt: string;
  updatedAt?: string;
  parts: WorkOrderPart[];
}
