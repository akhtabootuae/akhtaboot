# Complete Payroll System Backend Implementation Guide

## Overview
This comprehensive guide covers all backend implementation requirements for the complete 5-phase payroll system. This guide consolidates all phases and provides step-by-step instructions for the backend team.

## Prerequisites Completed
✅ MongoDB setup scripts have been executed for all phases
✅ Database collections and indexes are created
✅ Permissions have been added to the system
✅ Frontend UI is fully implemented and ready to connect

## Phase Summary

### Phase 1: Rate Management ✅ IMPLEMENTED
- Employee daily rate management
- Rate history tracking
- Audit logging

### Phase 2: Deductions System ✅ IMPLEMENTED
- Variable deductions management
- Priority-based deduction processing
- Balance tracking for loans/advances

### Phase 3: Attendance & Pay Calculation 🟡 NEEDS IMPLEMENTATION
- Time sheet management
- Pay period creation
- Payroll calculations with deductions integration

### Phase 4: Reporting & Paystubs 🟡 NEEDS IMPLEMENTATION
- Comprehensive reporting system
- Paystub generation and distribution
- PDF generation capabilities

### Phase 5: Advanced Features 🟡 NEEDS IMPLEMENTATION
- Alert management system
- Budget tracking
- Integration management

## Required Node.js Dependencies

Add these packages to your backend `package.json`:

```json
{
  "dependencies": {
    "mongoose": "^8.0.0",
    "express": "^4.18.0",
    "pdfkit": "^0.13.0",
    "nodemailer": "^6.9.0",
    "node-cron": "^3.0.0",
    "moment": "^2.29.0",
    "lodash": "^4.17.0",
    "multer": "^1.4.0",
    "csv-writer": "^1.6.0",
    "excel4node": "^1.8.0"
  }
}
```

## API Routes Structure

Create the following route files in your routes directory:

```
routes/
├── payroll/
│   ├── employees.js          ✅ EXISTS
│   ├── rates.js             ✅ EXISTS  
│   ├── audit.js             ✅ EXISTS
│   ├── deductions.js        ✅ EXISTS
│   ├── timeSheets.js        🆕 NEEDED
│   ├── payPeriods.js        🆕 NEEDED
│   ├── calculations.js      🆕 NEEDED
│   ├── reports.js           🆕 NEEDED
│   ├── paystubs.js          🆕 NEEDED
│   ├── alerts.js            🆕 NEEDED
│   ├── budgets.js           🆕 NEEDED
│   └── integrations.js      🆕 NEEDED
```

## Phase 3 Implementation: Attendance & Pay Calculation

### 1. Time Sheets Routes (`routes/payroll/timeSheets.js`)

```javascript
const express = require('express');
const router = express.Router();
const TimeSheet = require('../../models/payroll/TimeSheet');
const { requirePermission } = require('../../middleware/permissions');
const { auditLog } = require('../../utils/auditLogger');

// GET /api/payroll/time-sheets
router.get('/', requirePermission('payroll_view_all_attendance'), async (req, res) => {
  try {
    const { employee_id, start_date, end_date, status, page = 1, limit = 50 } = req.query;
    
    const filter = {};
    if (employee_id) filter.employee_id = employee_id;
    if (start_date && end_date) {
      filter.date = {
        $gte: new Date(start_date),
        $lte: new Date(end_date)
      };
    }
    if (status) filter.status = status;

    const timeSheets = await TimeSheet.find(filter)
      .populate('employee_id', 'first_name last_name email speciality branch')
      .sort({ date: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await TimeSheet.countDocuments(filter);

    res.json({
      success: true,
      time_sheets: timeSheets,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('Error fetching time sheets:', error);
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

// POST /api/payroll/time-sheets
router.post('/', requirePermission('payroll_manage_attendance'), async (req, res) => {
  try {
    const { employee_id, date, status, check_in_time, check_out_time, break_start_time, break_end_time, notes } = req.body;

    // Check for existing time sheet
    const existing = await TimeSheet.findOne({ employee_id, date: new Date(date) });
    if (existing) {
      return res.status(400).json({ success: false, message: 'Time sheet already exists for this date' });
    }

    // Calculate hours worked
    let total_hours_worked = 0;
    let overtime_hours = 0;
    let daily_pay_amount = 0;
    let overtime_pay_amount = 0;

    if (status === 'present' && check_in_time && check_out_time) {
      const checkIn = new Date(check_in_time);
      const checkOut = new Date(check_out_time);
      let workMinutes = (checkOut - checkIn) / (1000 * 60);

      // Subtract break time
      if (break_start_time && break_end_time) {
        const breakStart = new Date(break_start_time);
        const breakEnd = new Date(break_end_time);
        const breakMinutes = (breakEnd - breakStart) / (1000 * 60);
        workMinutes -= breakMinutes;
      }

      total_hours_worked = workMinutes / 60;
      
      // Calculate overtime (more than 8 hours)
      if (total_hours_worked > 8) {
        overtime_hours = total_hours_worked - 8;
        total_hours_worked = 8;
      }

      // Get employee's daily rate for pay calculation
      const Employee = require('../../models/User');
      const employee = await Employee.findById(employee_id);
      if (employee && employee.payroll_info) {
        const dailyRate = employee.payroll_info.current_daily_rate;
        daily_pay_amount = (total_hours_worked / 8) * dailyRate;
        overtime_pay_amount = overtime_hours * (dailyRate / 8) * 1.5; // 1.5x overtime multiplier
      }
    } else if (status === 'half_day') {
      const Employee = require('../../models/User');
      const employee = await Employee.findById(employee_id);
      if (employee && employee.payroll_info) {
        daily_pay_amount = employee.payroll_info.current_daily_rate * 0.5;
      }
      total_hours_worked = 4;
    }

    const timeSheet = new TimeSheet({
      employee_id,
      date: new Date(date),
      status,
      check_in_time: check_in_time ? new Date(check_in_time) : undefined,
      check_out_time: check_out_time ? new Date(check_out_time) : undefined,
      break_start_time: break_start_time ? new Date(break_start_time) : undefined,
      break_end_time: break_end_time ? new Date(break_end_time) : undefined,
      total_hours_worked,
      overtime_hours,
      daily_pay_amount,
      overtime_pay_amount,
      notes,
      created_by: req.user._id
    });

    await timeSheet.save();

    // Audit log
    await auditLog(req.user._id, 'CREATE', 'timesheet', timeSheet._id, req.ip, req.get('User-Agent'), {
      employee_id,
      date,
      status
    });

    const populatedTimeSheet = await TimeSheet.findById(timeSheet._id)
      .populate('employee_id', 'first_name last_name email speciality branch');

    res.status(201).json({
      success: true,
      message: 'Time sheet created successfully',
      time_sheet: populatedTimeSheet
    });
  } catch (error) {
    console.error('Error creating time sheet:', error);
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

// PUT /api/payroll/time-sheets/:id
router.put('/:id', requirePermission('payroll_manage_attendance'), async (req, res) => {
  try {
    const timeSheet = await TimeSheet.findById(req.params.id);
    if (!timeSheet) {
      return res.status(404).json({ success: false, message: 'Time sheet not found' });
    }

    // Update fields and recalculate if necessary
    Object.assign(timeSheet, req.body);
    
    // Recalculate hours if time fields changed
    if (req.body.check_in_time || req.body.check_out_time || req.body.break_start_time || req.body.break_end_time) {
      // Recalculation logic here (same as POST)
    }

    await timeSheet.save();

    await auditLog(req.user._id, 'UPDATE', 'timesheet', timeSheet._id, req.ip, req.get('User-Agent'), req.body);

    const populatedTimeSheet = await TimeSheet.findById(timeSheet._id)
      .populate('employee_id', 'first_name last_name email speciality branch');

    res.json({
      success: true,
      message: 'Time sheet updated successfully',
      time_sheet: populatedTimeSheet
    });
  } catch (error) {
    console.error('Error updating time sheet:', error);
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

// POST /api/payroll/time-sheets/:id/approve
router.post('/:id/approve', requirePermission('payroll_approve_attendance'), async (req, res) => {
  try {
    const timeSheet = await TimeSheet.findById(req.params.id);
    if (!timeSheet) {
      return res.status(404).json({ success: false, message: 'Time sheet not found' });
    }

    timeSheet.approved_by = req.user._id;
    timeSheet.approved_at = new Date();
    await timeSheet.save();

    await auditLog(req.user._id, 'APPROVE', 'timesheet', timeSheet._id, req.ip, req.get('User-Agent'), {});

    res.json({ success: true, message: 'Time sheet approved successfully' });
  } catch (error) {
    console.error('Error approving time sheet:', error);
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

// DELETE /api/payroll/time-sheets/:id
router.delete('/:id', requirePermission('payroll_manage_attendance'), async (req, res) => {
  try {
    const timeSheet = await TimeSheet.findByIdAndDelete(req.params.id);
    if (!timeSheet) {
      return res.status(404).json({ success: false, message: 'Time sheet not found' });
    }

    await auditLog(req.user._id, 'DELETE', 'timesheet', timeSheet._id, req.ip, req.get('User-Agent'), {});

    res.json({ success: true, message: 'Time sheet deleted successfully' });
  } catch (error) {
    console.error('Error deleting time sheet:', error);
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

module.exports = router;
```

### 2. Pay Periods Routes (`routes/payroll/payPeriods.js`)

```javascript
const express = require('express');
const router = express.Router();
const PayPeriod = require('../../models/payroll/PayPeriod');
const PayrollCalculation = require('../../models/payroll/PayrollCalculation');
const { requirePermission } = require('../../middleware/permissions');
const { calculatePayrollForPeriod } = require('../../utils/payrollCalculator');

// GET /api/payroll/pay-periods
router.get('/', async (req, res) => {
  try {
    const { status, page = 1, limit = 20 } = req.query;
    
    const filter = {};
    if (status) filter.status = status;

    const payPeriods = await PayPeriod.find(filter)
      .sort({ created_at: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    res.json({ success: true, pay_periods: payPeriods });
  } catch (error) {
    console.error('Error fetching pay periods:', error);
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

// POST /api/payroll/pay-periods
router.post('/', requirePermission('payroll_calculate_pay'), async (req, res) => {
  try {
    const { name, description, start_date, end_date, pay_date } = req.body;

    // Check for overlapping periods
    const overlapping = await PayPeriod.findOne({
      $or: [
        { start_date: { $lte: new Date(end_date) }, end_date: { $gte: new Date(start_date) } }
      ]
    });

    if (overlapping) {
      return res.status(400).json({ success: false, message: 'Pay period overlaps with existing period' });
    }

    const payPeriod = new PayPeriod({
      name,
      description,
      start_date: new Date(start_date),
      end_date: new Date(end_date),
      pay_date: pay_date ? new Date(pay_date) : undefined,
      created_by: req.user._id
    });

    await payPeriod.save();

    res.status(201).json({
      success: true,
      message: 'Pay period created successfully',
      pay_period: payPeriod
    });
  } catch (error) {
    console.error('Error creating pay period:', error);
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

// POST /api/payroll/pay-periods/:id/calculate
router.post('/:id/calculate', requirePermission('payroll_calculate_pay'), async (req, res) => {
  try {
    const payPeriod = await PayPeriod.findById(req.params.id);
    if (!payPeriod) {
      return res.status(404).json({ success: false, message: 'Pay period not found' });
    }

    if (payPeriod.status !== 'open') {
      return res.status(400).json({ success: false, message: 'Pay period is not open for calculation' });
    }

    payPeriod.status = 'calculating';
    payPeriod.calculated_by = req.user._id;
    payPeriod.calculated_at = new Date();
    await payPeriod.save();

    // Start payroll calculation process
    const calculationResult = await calculatePayrollForPeriod(payPeriod._id, req.user._id);

    // Update pay period with totals
    payPeriod.status = 'calculated';
    payPeriod.total_employees = calculationResult.total_employees;
    payPeriod.total_gross_pay = calculationResult.total_gross_pay;
    payPeriod.total_deductions = calculationResult.total_deductions;
    payPeriod.total_net_pay = calculationResult.total_net_pay;
    await payPeriod.save();

    res.json({
      success: true,
      message: 'Payroll calculation completed',
      summary: calculationResult
    });
  } catch (error) {
    console.error('Error calculating payroll:', error);
    
    // Reset pay period status on error
    const payPeriod = await PayPeriod.findById(req.params.id);
    if (payPeriod) {
      payPeriod.status = 'open';
      await payPeriod.save();
    }
    
    res.status(500).json({ success: false, message: 'Payroll calculation failed' });
  }
});

module.exports = router;
```

### 3. Payroll Calculator Utility (`utils/payrollCalculator.js`)

```javascript
const TimeSheet = require('../models/payroll/TimeSheet');
const PayrollCalculation = require('../models/payroll/PayrollCalculation');
const PayrollEmployeeDeduction = require('../models/payroll/PayrollEmployeeDeduction');
const PayrollDeductionHistory = require('../models/payroll/PayrollDeductionHistory');
const User = require('../models/User');

async function calculatePayrollForPeriod(payPeriodId, calculatedBy) {
  try {
    // Get all payroll-eligible employees
    const employees = await User.find({ 'payroll_info.payroll_eligible': true });
    
    let totalEmployees = 0;
    let totalGrossPay = 0;
    let totalDeductions = 0;
    let totalNetPay = 0;
    const errors = [];

    for (const employee of employees) {
      try {
        const calculation = await calculateEmployeePayroll(employee._id, payPeriodId, calculatedBy);
        
        totalEmployees++;
        totalGrossPay += calculation.gross_pay;
        totalDeductions += calculation.total_deductions;
        totalNetPay += calculation.net_pay;
        
      } catch (error) {
        console.error(`Error calculating payroll for employee ${employee._id}:`, error);
        errors.push({
          employee_id: employee._id,
          error: error.message
        });

        // Create error calculation record
        await PayrollCalculation.create({
          employee_id: employee._id,
          pay_period_id: payPeriodId,
          status: 'error',
          error_message: error.message,
          created_by: calculatedBy
        });
      }
    }

    return {
      total_employees: totalEmployees,
      employees_calculated: totalEmployees - errors.length,
      employees_with_errors: errors.length,
      total_gross_pay: totalGrossPay,
      total_deductions: totalDeductions,
      total_net_pay: totalNetPay,
      errors
    };

  } catch (error) {
    console.error('Error in calculatePayrollForPeriod:', error);
    throw error;
  }
}

async function calculateEmployeePayroll(employeeId, payPeriodId, calculatedBy) {
  // Get pay period details
  const PayPeriod = require('../models/payroll/PayPeriod');
  const payPeriod = await PayPeriod.findById(payPeriodId);
  
  // Get employee time sheets for the period
  const timeSheets = await TimeSheet.find({
    employee_id: employeeId,
    date: {
      $gte: payPeriod.start_date,
      $lte: payPeriod.end_date
    }
  }).sort({ date: 1 });

  // Get employee details
  const employee = await User.findById(employeeId);
  const dailyRate = employee.payroll_info.current_daily_rate;

  // Calculate base pay and overtime
  let daysWorked = 0;
  let totalHours = 0;
  let overtimeHours = 0;
  let basePay = 0;
  let overtimePay = 0;

  const attendanceSummary = timeSheets.map(ts => {
    if (ts.status === 'present' || ts.status === 'half_day') {
      daysWorked += ts.status === 'half_day' ? 0.5 : 1;
      totalHours += ts.total_hours_worked || 0;
      overtimeHours += ts.overtime_hours || 0;
      basePay += ts.daily_pay_amount || 0;
      overtimePay += ts.overtime_pay_amount || 0;
    }

    return {
      date: ts.date,
      status: ts.status,
      hours_worked: ts.total_hours_worked,
      overtime_hours: ts.overtime_hours
    };
  });

  const grossPay = basePay + overtimePay;

  // Get active deductions for the employee
  const activeDeductions = await PayrollEmployeeDeduction.find({
    employee_id: employeeId,
    status: 'active',
    start_date: { $lte: payPeriod.end_date },
    $or: [
      { end_date: null },
      { end_date: { $gte: payPeriod.start_date } }
    ]
  }).populate('deduction_type_id').sort({ priority: 1 });

  // Process deductions
  let totalDeductions = 0;
  const deductionsBreakdown = [];

  for (const deduction of activeDeductions) {
    let deductionAmount = 0;

    if (deduction.deduction_type_id.type === 'fixed_amount') {
      deductionAmount = deduction.amount;
    } else if (deduction.deduction_type_id.type === 'percentage') {
      deductionAmount = (grossPay * deduction.amount) / 100;
    }

    // Check if deduction would exceed remaining balance for loans/advances
    if (deduction.max_total_amount) {
      const remainingBalance = deduction.max_total_amount - deduction.total_deducted;
      deductionAmount = Math.min(deductionAmount, remainingBalance);
    }

    // Check if deduction would exceed available net pay
    const availableForDeduction = grossPay - totalDeductions;
    deductionAmount = Math.min(deductionAmount, availableForDeduction);

    if (deductionAmount > 0) {
      totalDeductions += deductionAmount;

      deductionsBreakdown.push({
        deduction_id: deduction._id,
        deduction_name: deduction.deduction_type_id.name,
        amount: deductionAmount,
        remaining_balance: deduction.max_total_amount ? 
          deduction.max_total_amount - deduction.total_deducted - deductionAmount : null
      });

      // Update deduction totals
      deduction.total_deducted += deductionAmount;
      if (deduction.max_total_amount) {
        deduction.remaining_balance = deduction.max_total_amount - deduction.total_deducted;
        if (deduction.remaining_balance <= 0) {
          deduction.status = 'completed';
        }
      }
      await deduction.save();

      // Create deduction history record
      await PayrollDeductionHistory.create({
        employee_deduction_id: deduction._id,
        employee_id: employeeId,
        pay_period_start: payPeriod.start_date,
        pay_period_end: payPeriod.end_date,
        gross_pay_amount: grossPay,
        amount_deducted: deductionAmount,
        remaining_balance_after: deduction.remaining_balance,
        processed_by: calculatedBy,
        processed_at: new Date()
      });
    }
  }

  const netPay = grossPay - totalDeductions;

  // Create or update payroll calculation record
  const calculation = await PayrollCalculation.findOneAndUpdate(
    { employee_id: employeeId, pay_period_id: payPeriodId },
    {
      status: 'calculated',
      days_worked: daysWorked,
      total_hours: totalHours,
      overtime_hours: overtimeHours,
      daily_rate: dailyRate,
      base_pay: basePay,
      overtime_pay: overtimePay,
      gross_pay: grossPay,
      total_deductions: totalDeductions,
      net_pay: netPay,
      deductions_breakdown: deductionsBreakdown,
      attendance_summary: attendanceSummary,
      calculated_by: calculatedBy,
      calculated_at: new Date(),
      created_by: calculatedBy
    },
    { upsert: true, new: true }
  );

  return calculation;
}

module.exports = {
  calculatePayrollForPeriod,
  calculateEmployeePayroll
};
```

## Phase 4 Implementation: Reports & Paystubs

### 1. Reports Routes (`routes/payroll/reports.js`)

```javascript
const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const { generatePayrollReport } = require('../../utils/reportGenerator');

// POST /api/payroll/reports/generate
router.post('/generate', async (req, res) => {
  try {
    const { type, period_type, start_date, end_date, filters } = req.body;
    
    const reportData = await generatePayrollReport({
      type,
      period_type,
      start_date,
      end_date,
      filters,
      generated_by: req.user._id
    });

    res.json({
      success: true,
      report: reportData
    });
  } catch (error) {
    console.error('Error generating report:', error);
    res.status(500).json({ success: false, message: 'Failed to generate report' });
  }
});

// GET /api/payroll/reports/:id/download
router.get('/:id/download', async (req, res) => {
  try {
    // Implementation for downloading generated reports
    const filePath = `/path/to/reports/${req.params.id}.pdf`;
    res.download(filePath);
  } catch (error) {
    console.error('Error downloading report:', error);
    res.status(500).json({ success: false, message: 'Failed to download report' });
  }
});

module.exports = router;
```

### 2. Paystubs Routes (`routes/payroll/paystubs.js`)

```javascript
const express = require('express');
const router = express.Router();
const { generatePaystub } = require('../../utils/paystubGenerator');

// POST /api/payroll/paystubs/generate/:calculationId
router.post('/generate/:calculationId', async (req, res) => {
  try {
    const calculation = await PayrollCalculation.findById(req.params.calculationId)
      .populate('employee_id')
      .populate('pay_period_id');

    const paystub = await generatePaystub(calculation, req.user._id);

    res.json({
      success: true,
      paystub: paystub
    });
  } catch (error) {
    console.error('Error generating paystub:', error);
    res.status(500).json({ success: false, message: 'Failed to generate paystub' });
  }
});

module.exports = router;
```

## Phase 5 Implementation: Advanced Features

### 1. Alerts Routes (`routes/payroll/alerts.js`)

```javascript
const express = require('express');
const router = express.Router();
const PayrollAlert = require('../../models/payroll/PayrollAlert');

// GET /api/payroll/alerts
router.get('/', async (req, res) => {
  try {
    const { type, severity, resolved } = req.query;
    
    const filter = {};
    if (type) filter.type = type;
    if (severity) filter.severity = severity;
    if (resolved !== undefined) filter.resolved = resolved === 'true';

    const alerts = await PayrollAlert.find(filter)
      .sort({ created_at: -1 })
      .limit(100);

    res.json({ success: true, alerts });
  } catch (error) {
    console.error('Error fetching alerts:', error);
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

// POST /api/payroll/alerts/:id/acknowledge
router.post('/:id/acknowledge', async (req, res) => {
  try {
    const alert = await PayrollAlert.findById(req.params.id);
    if (!alert) {
      return res.status(404).json({ success: false, message: 'Alert not found' });
    }

    alert.acknowledged = true;
    alert.acknowledged_by = req.user._id;
    alert.acknowledged_at = new Date();
    await alert.save();

    res.json({ success: true, message: 'Alert acknowledged' });
  } catch (error) {
    console.error('Error acknowledging alert:', error);
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

module.exports = router;
```

## Required Utility Functions

### 1. Report Generator (`utils/reportGenerator.js`)

```javascript
const PDFDocument = require('pdfkit');
const fs = require('fs');
const path = require('path');

async function generatePayrollReport(options) {
  const { type, start_date, end_date, filters } = options;
  
  // Implementation varies by report type
  switch (type) {
    case 'payroll_summary':
      return await generatePayrollSummaryReport(start_date, end_date, filters);
    case 'employee_earnings':
      return await generateEmployeeEarningsReport(start_date, end_date, filters);
    case 'attendance_report':
      return await generateAttendanceReport(start_date, end_date, filters);
    default:
      throw new Error('Unknown report type');
  }
}

module.exports = { generatePayrollReport };
```

### 2. Paystub Generator (`utils/paystubGenerator.js`)

```javascript
const PDFDocument = require('pdfkit');
const PayStub = require('../models/payroll/PayStub');

async function generatePaystub(calculation, generatedBy) {
  const doc = new PDFDocument();
  
  // Generate PDF content
  doc.fontSize(20).text('Employee Paystub', 100, 100);
  // Add paystub details...
  
  // Save to file system
  const filename = `paystub_${calculation._id}.pdf`;
  const filePath = path.join(__dirname, '../public/paystubs', filename);
  doc.pipe(fs.createWriteStream(filePath));
  doc.end();

  // Create database record
  const paystub = new PayStub({
    employee_id: calculation.employee_id,
    pay_period_id: calculation.pay_period_id,
    calculation_id: calculation._id,
    gross_pay: calculation.gross_pay,
    total_deductions: calculation.total_deductions,
    net_pay: calculation.net_pay,
    earnings_breakdown: [
      { type: 'base_pay', description: 'Base Pay', amount: calculation.base_pay },
      { type: 'overtime_pay', description: 'Overtime Pay', amount: calculation.overtime_pay }
    ],
    deductions_breakdown: calculation.deductions_breakdown,
    status: 'generated',
    generated_at: new Date(),
    created_by: generatedBy
  });

  await paystub.save();
  return paystub;
}

module.exports = { generatePaystub };
```

## Integration Points

### 1. Update Main Routes File

Add all new routes to your main routes file:

```javascript
// In your main app.js or routes/index.js
app.use('/api/payroll/time-sheets', require('./routes/payroll/timeSheets'));
app.use('/api/payroll/pay-periods', require('./routes/payroll/payPeriods'));
app.use('/api/payroll/calculations', require('./routes/payroll/calculations'));
app.use('/api/payroll/reports', require('./routes/payroll/reports'));
app.use('/api/payroll/paystubs', require('./routes/payroll/paystubs'));
app.use('/api/payroll/alerts', require('./routes/payroll/alerts'));
```

### 2. Automated Alert Generation

Create a cron job for generating alerts:

```javascript
// utils/alertGenerator.js
const cron = require('node-cron');
const PayrollAlert = require('../models/payroll/PayrollAlert');

// Run every day at 9 AM
cron.schedule('0 9 * * *', async () => {
  await checkMissingTimesheets();
  await checkPaymentDues();
  await checkComplianceIssues();
});

async function checkMissingTimesheets() {
  // Logic to check for missing timesheets and create alerts
}
```

## Testing Strategy

### 1. Unit Tests
- Test each calculation function
- Test API endpoints with various scenarios
- Test permission validations

### 2. Integration Tests
- Test complete payroll calculation workflow
- Test deduction processing
- Test report generation

### 3. Performance Tests
- Test with large datasets
- Test concurrent calculations
- Test report generation performance

## Security Considerations

1. **Permission Validation**: Every endpoint must validate user permissions
2. **Audit Logging**: All payroll operations must be logged
3. **Data Encryption**: Sensitive payroll data should be encrypted
4. **Input Validation**: Validate all input data
5. **Rate Limiting**: Implement rate limiting for API endpoints

## Deployment Checklist

- [ ] All MongoDB collections created and indexed
- [ ] All permissions granted to appropriate roles
- [ ] Environment variables configured
- [ ] File upload directories created
- [ ] PDF generation libraries installed
- [ ] Email service configured for paystub distribution
- [ ] Backup strategy implemented
- [ ] Monitoring and logging configured

## Performance Optimization

1. **Database Indexing**: Ensure proper indexes on frequently queried fields
2. **Aggregation Pipelines**: Use MongoDB aggregation for complex calculations
3. **Caching**: Implement Redis caching for frequently accessed data
4. **Batch Processing**: Process large datasets in batches
5. **Background Jobs**: Use queue system for heavy operations

## Maintenance & Monitoring

1. **Regular Backups**: Implement automated database backups
2. **Performance Monitoring**: Monitor API response times
3. **Error Tracking**: Implement error tracking and alerting
4. **Data Integrity Checks**: Regular validation of payroll calculations
5. **Security Audits**: Regular security reviews and updates

This guide provides everything needed to implement the complete payroll system backend. The frontend is already implemented and ready to connect to these APIs once they are built.