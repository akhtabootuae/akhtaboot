// Admin Test Utility
// Run this in the browser console to manually set admin role for testing

function setAdminRole() {
  try {
    // Get current user from localStorage
    const userStr = localStorage.getItem('user');
    if (!userStr) {
      console.error('No user found in localStorage. Please login first.');
      return;
    }
    
    const user = JSON.parse(userStr);
    console.log('Current user:', user);
    
    // Update role to admin
    user.role_name = 'admin';
    
    // Save back to localStorage
    localStorage.setItem('user', JSON.stringify(user));
    
    console.log('User role updated to admin:', user);
    console.log('Please refresh the page to see changes.');
    
    // Optionally refresh the page
    window.location.reload();
  } catch (error) {
    console.error('Error setting admin role:', error);
  }
}

// Run the function
setAdminRole();
