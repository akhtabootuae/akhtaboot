# Backend Implementation - Payroll System Phase 1

## Overview
This document outlines the backend implementation requirements for Phase 1 of the payroll system. Phase 1 focuses on employee daily rate management, basic permissions, and audit logging.

## Prerequisites
1. Run the MongoDB setup script: `setup_payroll_phase1.js`
2. Verify all collections and indexes were created successfully
3. Ensure new permissions are added to the system

## Database Changes Made
The MongoDB script has created:
- `payroll_rates` collection with schema validation
- `payroll_audit_log` collection for tracking changes
- Updated `users` collection with `payroll_info` field
- New payroll permissions added to admin/supervisor users
- Proper indexes for performance

## API Endpoints to Implement

### 1. Employee Rate Management

#### GET `/api/payroll/employees`
**Purpose**: Get all payroll-eligible employees with their current rates

**Permissions Required**: `payroll_view`

**Response Format**:
```json
{
  "message": "Employees retrieved successfully",
  "data": [
    {
      "employee_id": "ObjectId",
      "first_name": "string",
      "last_name": "string",
      "email": "string",
      "employee_number": "string",
      "speciality": "string",
      "branch": {
        "branch_name": "string",
        "location": "string"
      },
      "payroll_info": {
        "current_daily_rate": 150,
        "hire_date": "2024-01-01T00:00:00.000Z",
        "payroll_eligible": true,
        "last_pay_date": "2024-05-01T00:00:00.000Z"
      },
      "rate_history_count": 3
    }
  ],
  "total_count": 15
}
```

**Implementation Notes**:
- Filter users where `payroll_info.payroll_eligible: true`
- Include current rate from `payroll_info.current_daily_rate`
- Add count of rate history entries
- Sort by `last_name` then `first_name`

#### GET `/api/payroll/employees/:id/rates`
**Purpose**: Get rate history for specific employee

**Permissions Required**: `payroll_view`

**Response Format**:
```json
{
  "message": "Rate history retrieved successfully",
  "data": {
    "employee": {
      "employee_id": "ObjectId",
      "first_name": "string",
      "last_name": "string",
      "current_daily_rate": 150
    },
    "rate_history": [
      {
        "_id": "ObjectId",
        "daily_rate": 150,
        "rate_type": "regular",
        "effective_date": "2024-06-01T00:00:00.000Z",
        "end_date": null,
        "created_by": {
          "user_id": "ObjectId",
          "first_name": "Admin",
          "last_name": "User"
        },
        "created_at": "2024-06-01T00:00:00.000Z",
        "notes": "Promotion to senior technician"
      }
    ]
  }
}
```

**Implementation Notes**:
- Join with `users` collection to get employee details
- Join with `users` collection again to get `created_by` details
- Sort by `effective_date` descending (newest first)

#### PUT `/api/payroll/employees/:id/rate`
**Purpose**: Update employee daily rate

**Permissions Required**: `payroll_manage_rates`

**Request Body**:
```json
{
  "daily_rate": 175,
  "rate_type": "regular",
  "effective_date": "2024-06-07T00:00:00.000Z",
  "notes": "Annual review increase"
}
```

**Implementation Steps**:
1. **Validation**:
   - Check employee exists and is payroll eligible
   - Validate `daily_rate` > 0
   - Validate `rate_type` is one of: "regular", "holiday", "premium"
   - Validate `effective_date` is not in the past (unless admin override)

2. **Close Previous Rate**:
   ```javascript
   // End the current active rate
   await db.payroll_rates.updateOne(
     { 
       employee_id: ObjectId(employeeId),
       end_date: null 
     },
     { 
       $set: { 
         end_date: new Date(effective_date),
         updated_at: new Date()
       } 
     }
   );
   ```

3. **Create New Rate**:
   ```javascript
   const newRate = {
     employee_id: ObjectId(employeeId),
     daily_rate: parseFloat(daily_rate),
     rate_type: rate_type,
     effective_date: new Date(effective_date),
     end_date: null,
     created_by: req.user.id,
     created_at: new Date(),
     notes: notes || ""
   };
   
   await db.payroll_rates.insertOne(newRate);
   ```

4. **Update User Record**:
   ```javascript
   await db.users.updateOne(
     { _id: ObjectId(employeeId) },
     { 
       $set: { 
         "payroll_info.current_daily_rate": parseFloat(daily_rate),
         updated_at: new Date()
       } 
     }
   );
   ```

5. **Create Audit Log**:
   ```javascript
   await db.payroll_audit_log.insertOne({
     log_id: generateUniqueId(),
     action: "rate_change",
     entity_type: "employee",
     entity_id: ObjectId(employeeId),
     user_id: req.user.id,
     old_data: { daily_rate: previousRate },
     new_data: { daily_rate: parseFloat(daily_rate) },
     timestamp: new Date(),
     ip_address: req.ip,
     notes: `Rate changed from $${previousRate} to $${daily_rate}`
   });
   ```

**Response Format**:
```json
{
  "message": "Employee rate updated successfully",
  "data": {
    "rate_id": "ObjectId",
    "employee_id": "ObjectId",
    "daily_rate": 175,
    "effective_date": "2024-06-07T00:00:00.000Z"
  }
}
```

#### GET `/api/payroll/employees/:id/current-rate`
**Purpose**: Get current active rate for employee

**Permissions Required**: `payroll_view`

**Response Format**:
```json
{
  "message": "Current rate retrieved successfully",
  "data": {
    "employee_id": "ObjectId",
    "daily_rate": 150,
    "rate_type": "regular",
    "effective_date": "2024-06-01T00:00:00.000Z",
    "created_by": {
      "user_id": "ObjectId",
      "first_name": "Admin",
      "last_name": "User"
    },
    "notes": "Promotion increase"
  }
}
```

### 2. Audit Logging

#### GET `/api/payroll/audit-log`
**Purpose**: Get audit log entries (admin only)

**Permissions Required**: `payroll_view` + Admin role

**Query Parameters**:
- `page` (default: 1)
- `limit` (default: 50, max: 100)
- `entity_type` (optional filter)
- `action` (optional filter)
- `start_date` (optional filter)
- `end_date` (optional filter)

**Response Format**:
```json
{
  "message": "Audit log retrieved successfully",
  "data": [
    {
      "log_id": "string",
      "action": "rate_change",
      "entity_type": "employee",
      "entity_id": "ObjectId",
      "user": {
        "user_id": "ObjectId",
        "first_name": "Admin",
        "last_name": "User"
      },
      "old_data": { "daily_rate": 125 },
      "new_data": { "daily_rate": 150 },
      "timestamp": "2024-06-07T00:00:00.000Z",
      "ip_address": "192.168.1.100",
      "notes": "Rate changed from $125 to $150"
    }
  ],
  "pagination": {
    "current_page": 1,
    "total_pages": 5,
    "total_count": 247,
    "has_next": true,
    "has_prev": false
  }
}
```

## Middleware Requirements

### 1. Permission Middleware Enhancement
Add payroll permission checking to existing `permissionAuth.js`:

```javascript
// Add to permissionAuth.js
const PAYROLL_PERMISSIONS = {
  PAYROLL_VIEW: 'payroll_view',
  PAYROLL_MANAGE_RATES: 'payroll_manage_rates',
  PAYROLL_MANAGE_DEDUCTIONS: 'payroll_manage_deductions',
  PAYROLL_PROCESS: 'payroll_process',
  PAYROLL_ATTENDANCE: 'payroll_attendance'
};

const checkPayrollPermission = (requiredPermission) => {
  return (req, res, next) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: 'Authentication required' });
      }

      const hasPermission = req.user.permissions?.some(p => 
        p.permission_id === requiredPermission && p.granted === true
      );

      if (!hasPermission) {
        return res.status(403).json({ 
          message: 'Insufficient permissions for payroll operations' 
        });
      }

      next();
    } catch (error) {
      res.status(500).json({ message: 'Permission check failed' });
    }
  };
};

module.exports = { ...existingExports, checkPayrollPermission, PAYROLL_PERMISSIONS };
```

### 2. Audit Logging Middleware
Create `middleware/payrollAudit.js`:

```javascript
const { ObjectId } = require('mongodb');

const logPayrollAction = (action, entityType) => {
  return async (req, res, next) => {
    // Store original response.json
    const originalJson = res.json;
    
    res.json = function(data) {
      // Log the action after successful response
      if (res.statusCode >= 200 && res.statusCode < 300) {
        logAuditEntry(req, action, entityType, data).catch(console.error);
      }
      
      // Call original json method
      return originalJson.call(this, data);
    };
    
    next();
  };
};

async function logAuditEntry(req, action, entityType, responseData) {
  try {
    const db = req.app.locals.db; // Assuming db is available here
    
    const auditEntry = {
      log_id: generateUniqueId(),
      action: action,
      entity_type: entityType,
      entity_id: new ObjectId(req.params.id || responseData.data?.employee_id),
      user_id: new ObjectId(req.user.id),
      old_data: req.body.old_data || {},
      new_data: req.body,
      timestamp: new Date(),
      ip_address: req.ip || req.connection.remoteAddress,
      notes: req.body.notes || `${action} performed via API`
    };
    
    await db.collection('payroll_audit_log').insertOne(auditEntry);
  } catch (error) {
    console.error('Audit logging failed:', error);
  }
}

function generateUniqueId() {
  return `audit_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

module.exports = { logPayrollAction };
```

## Route Implementation

Create `routes/payroll.js`:

```javascript
const express = require('express');
const router = express.Router();
const { ObjectId } = require('mongodb');
const auth = require('../middleware/auth');
const { checkPayrollPermission, PAYROLL_PERMISSIONS } = require('../middleware/permissionAuth');
const { logPayrollAction } = require('../middleware/payrollAudit');

// Apply authentication to all payroll routes
router.use(auth);

// GET /api/payroll/employees
router.get('/employees', 
  checkPayrollPermission(PAYROLL_PERMISSIONS.PAYROLL_VIEW),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      
      // Get all payroll-eligible employees
      const employees = await db.collection('users').aggregate([
        {
          $match: {
            'payroll_info.payroll_eligible': true,
            is_active: true
          }
        },
        {
          $lookup: {
            from: 'payroll_rates',
            let: { empId: '$_id' },
            pipeline: [
              { $match: { $expr: { $eq: ['$employee_id', '$$empId'] } } },
              { $sort: { effective_date: -1 } },
              { $limit: 1 }
            ],
            as: 'current_rate'
          }
        },
        {
          $addFields: {
            rate_history_count: {
              $size: {
                $ifNull: ['$current_rate', []]
              }
            }
          }
        },
        {
          $project: {
            password_hash: 0,
            permissions: 0,
            permission_logs: 0
          }
        },
        {
          $sort: { last_name: 1, first_name: 1 }
        }
      ]).toArray();
      
      res.json({
        message: 'Employees retrieved successfully',
        data: employees,
        total_count: employees.length
      });
      
    } catch (error) {
      console.error('Error fetching employees:', error);
      res.status(500).json({ message: 'Failed to fetch employees' });
    }
  }
);

// GET /api/payroll/employees/:id/rates
router.get('/employees/:id/rates',
  checkPayrollPermission(PAYROLL_PERMISSIONS.PAYROLL_VIEW),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const employeeId = req.params.id;
      
      // Get employee details
      const employee = await db.collection('users').findOne(
        { _id: new ObjectId(employeeId) },
        { projection: { first_name: 1, last_name: 1, 'payroll_info.current_daily_rate': 1 } }
      );
      
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }
      
      // Get rate history
      const rates = await db.collection('payroll_rates').aggregate([
        { $match: { employee_id: new ObjectId(employeeId) } },
        {
          $lookup: {
            from: 'users',
            localField: 'created_by',
            foreignField: '_id',
            as: 'created_by_user'
          }
        },
        {
          $addFields: {
            created_by: {
              $arrayElemAt: ['$created_by_user', 0]
            }
          }
        },
        {
          $project: {
            daily_rate: 1,
            rate_type: 1,
            effective_date: 1,
            end_date: 1,
            notes: 1,
            created_at: 1,
            'created_by._id': 1,
            'created_by.first_name': 1,
            'created_by.last_name': 1
          }
        },
        { $sort: { effective_date: -1 } }
      ]).toArray();
      
      res.json({
        message: 'Rate history retrieved successfully',
        data: {
          employee: {
            employee_id: employee._id,
            first_name: employee.first_name,
            last_name: employee.last_name,
            current_daily_rate: employee.payroll_info?.current_daily_rate || 0
          },
          rate_history: rates
        }
      });
      
    } catch (error) {
      console.error('Error fetching rate history:', error);
      res.status(500).json({ message: 'Failed to fetch rate history' });
    }
  }
);

// PUT /api/payroll/employees/:id/rate
router.put('/employees/:id/rate',
  checkPayrollPermission(PAYROLL_PERMISSIONS.PAYROLL_MANAGE_RATES),
  logPayrollAction('rate_change', 'employee'),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const employeeId = req.params.id;
      const { daily_rate, rate_type = 'regular', effective_date, notes = '' } = req.body;
      
      // Validation
      if (!daily_rate || daily_rate <= 0) {
        return res.status(400).json({ message: 'Daily rate must be greater than 0' });
      }
      
      const validRateTypes = ['regular', 'holiday', 'premium'];
      if (!validRateTypes.includes(rate_type)) {
        return res.status(400).json({ message: 'Invalid rate type' });
      }
      
      // Check if employee exists and is payroll eligible
      const employee = await db.collection('users').findOne({
        _id: new ObjectId(employeeId),
        'payroll_info.payroll_eligible': true
      });
      
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found or not eligible for payroll' });
      }
      
      const effectiveDate = new Date(effective_date || new Date());
      
      // Start transaction
      const session = db.client.startSession();
      await session.withTransaction(async () => {
        // Close previous rate
        await db.collection('payroll_rates').updateOne(
          { 
            employee_id: new ObjectId(employeeId),
            end_date: null 
          },
          { 
            $set: { 
              end_date: effectiveDate,
              updated_at: new Date()
            } 
          },
          { session }
        );
        
        // Create new rate
        const newRate = {
          employee_id: new ObjectId(employeeId),
          daily_rate: parseFloat(daily_rate),
          rate_type: rate_type,
          effective_date: effectiveDate,
          end_date: null,
          created_by: new ObjectId(req.user.id),
          created_at: new Date(),
          notes: notes
        };
        
        const result = await db.collection('payroll_rates').insertOne(newRate, { session });
        
        // Update user record
        await db.collection('users').updateOne(
          { _id: new ObjectId(employeeId) },
          { 
            $set: { 
              'payroll_info.current_daily_rate': parseFloat(daily_rate),
              updated_at: new Date()
            } 
          },
          { session }
        );
        
        res.json({
          message: 'Employee rate updated successfully',
          data: {
            rate_id: result.insertedId,
            employee_id: employeeId,
            daily_rate: parseFloat(daily_rate),
            effective_date: effectiveDate
          }
        });
      });
      
      await session.endSession();
      
    } catch (error) {
      console.error('Error updating rate:', error);
      res.status(500).json({ message: 'Failed to update employee rate' });
    }
  }
);

// GET /api/payroll/employees/:id/current-rate
router.get('/employees/:id/current-rate',
  checkPayrollPermission(PAYROLL_PERMISSIONS.PAYROLL_VIEW),
  async (req, res) => {
    try {
      const db = req.app.locals.db;
      const employeeId = req.params.id;
      
      const currentRate = await db.collection('payroll_rates').aggregate([
        { 
          $match: { 
            employee_id: new ObjectId(employeeId),
            end_date: null 
          } 
        },
        {
          $lookup: {
            from: 'users',
            localField: 'created_by',
            foreignField: '_id',
            as: 'created_by_user'
          }
        },
        {
          $addFields: {
            created_by: {
              $arrayElemAt: ['$created_by_user', 0]
            }
          }
        },
        {
          $project: {
            employee_id: 1,
            daily_rate: 1,
            rate_type: 1,
            effective_date: 1,
            notes: 1,
            'created_by._id': 1,
            'created_by.first_name': 1,
            'created_by.last_name': 1
          }
        }
      ]).toArray();
      
      if (currentRate.length === 0) {
        return res.status(404).json({ message: 'No current rate found for employee' });
      }
      
      res.json({
        message: 'Current rate retrieved successfully',
        data: currentRate[0]
      });
      
    } catch (error) {
      console.error('Error fetching current rate:', error);
      res.status(500).json({ message: 'Failed to fetch current rate' });
    }
  }
);

// GET /api/payroll/audit-log (Admin only)
router.get('/audit-log',
  checkPayrollPermission(PAYROLL_PERMISSIONS.PAYROLL_VIEW),
  async (req, res) => {
    try {
      // Check if user is admin
      if (req.user.role !== 'Admin') {
        return res.status(403).json({ message: 'Admin access required' });
      }
      
      const db = req.app.locals.db;
      const page = parseInt(req.query.page) || 1;
      const limit = Math.min(parseInt(req.query.limit) || 50, 100);
      const skip = (page - 1) * limit;
      
      // Build filter
      const filter = {};
      if (req.query.entity_type) filter.entity_type = req.query.entity_type;
      if (req.query.action) filter.action = req.query.action;
      if (req.query.start_date || req.query.end_date) {
        filter.timestamp = {};
        if (req.query.start_date) filter.timestamp.$gte = new Date(req.query.start_date);
        if (req.query.end_date) filter.timestamp.$lte = new Date(req.query.end_date);
      }
      
      // Get audit logs
      const auditLogs = await db.collection('payroll_audit_log').aggregate([
        { $match: filter },
        {
          $lookup: {
            from: 'users',
            localField: 'user_id',
            foreignField: '_id',
            as: 'user'
          }
        },
        {
          $addFields: {
            user: { $arrayElemAt: ['$user', 0] }
          }
        },
        {
          $project: {
            log_id: 1,
            action: 1,
            entity_type: 1,
            entity_id: 1,
            old_data: 1,
            new_data: 1,
            timestamp: 1,
            ip_address: 1,
            notes: 1,
            'user._id': 1,
            'user.first_name': 1,
            'user.last_name': 1
          }
        },
        { $sort: { timestamp: -1 } },
        { $skip: skip },
        { $limit: limit }
      ]).toArray();
      
      // Get total count
      const totalCount = await db.collection('payroll_audit_log').countDocuments(filter);
      const totalPages = Math.ceil(totalCount / limit);
      
      res.json({
        message: 'Audit log retrieved successfully',
        data: auditLogs,
        pagination: {
          current_page: page,
          total_pages: totalPages,
          total_count: totalCount,
          has_next: page < totalPages,
          has_prev: page > 1
        }
      });
      
    } catch (error) {
      console.error('Error fetching audit log:', error);
      res.status(500).json({ message: 'Failed to fetch audit log' });
    }
  }
);

module.exports = router;
```

## Integration with Main App

In your main `app.js` file, add the payroll routes:

```javascript
// Add after other route declarations
const payrollRoutes = require('./routes/payroll');
app.use('/api/payroll', payrollRoutes);
```

## Testing

### 1. Test Collections Creation
Run these commands in MongoDB shell after running the setup script:
```javascript
// Check collections exist
db.listCollectionNames().filter(name => name.includes('payroll'))

// Verify schema validation
db.payroll_rates.insertOne({invalid: "data"}) // Should fail

// Check sample data
db.payroll_rates.find().pretty()
db.users.findOne({"payroll_info": {$exists: true}})
```

### 2. Test API Endpoints
Use these curl commands or Postman:

```bash
# Get all employees (replace TOKEN with actual JWT)
curl -H "Authorization: Bearer TOKEN" \
     http://localhost:5000/api/payroll/employees

# Update employee rate
curl -X PUT \
     -H "Authorization: Bearer TOKEN" \
     -H "Content-Type: application/json" \
     -d '{"daily_rate": 200, "notes": "Performance increase"}' \
     http://localhost:5000/api/payroll/employees/EMPLOYEE_ID/rate

# Get rate history
curl -H "Authorization: Bearer TOKEN" \
     http://localhost:5000/api/payroll/employees/EMPLOYEE_ID/rates
```

## Error Handling
All endpoints should handle:
- Invalid employee IDs (404)
- Missing permissions (403)
- Invalid data (400)
- Database errors (500)
- Proper error logging

## Security Notes
- All payroll routes require authentication
- Payroll permissions are checked on every request
- Audit logging captures all changes
- Rate changes require `payroll_manage_rates` permission
- Audit log viewing requires admin access

## Next Steps
After Phase 1 is complete:
1. Test all endpoints thoroughly
2. Verify audit logging is working
3. Check permission system is functioning
4. Prepare for Phase 2 (Deductions System)