// Debug script to test attendance page API calls
console.log('=== ATTENDANCE PAGE DEBUG SCRIPT ===');

// Simulate the API call that the attendance page is making
const baseURL = 'http://localhost:3000';

async function debugAttendanceAPI() {
  try {
    console.log('1. Testing timesheets endpoint...');
    
    // Test the exact API call from the frontend
    const response = await fetch(`${baseURL}/api/payroll/timesheets`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        // You may need to add Authorization header if required
        // 'Authorization': 'Bearer YOUR_TOKEN_HERE'
      }
    });

    console.log('Response status:', response.status);
    console.log('Response status text:', response.statusText);
    console.log('Response headers:', [...response.headers.entries()]);

    const data = await response.text();
    console.log('Raw response:', data);

    try {
      const jsonData = JSON.parse(data);
      console.log('Parsed JSON response:', JSON.stringify(jsonData, null, 2));
      
      // Check the response structure
      if (jsonData.timesheets) {
        console.log('✅ Found timesheets array with', jsonData.timesheets.length, 'items');
      } else if (Array.isArray(jsonData)) {
        console.log('⚠️  Response is an array (not wrapped in object)');
      } else {
        console.log('❌ No timesheets property found in response');
        console.log('Available properties:', Object.keys(jsonData));
      }
    } catch (parseError) {
      console.error('❌ Failed to parse JSON response:', parseError.message);
    }

  } catch (error) {
    console.error('❌ API call failed:', error.message);
    
    // Check if the server is running
    try {
      const healthCheck = await fetch(`${baseURL}/health`);
      console.log('Health check status:', healthCheck.status);
    } catch (healthError) {
      console.log('❌ Server appears to be down or not accessible');
    }
  }

  // Test employees endpoint too
  try {
    console.log('\n2. Testing employees endpoint...');
    const employeesResponse = await fetch(`${baseURL}/api/payroll/employees/list`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      }
    });

    console.log('Employees response status:', employeesResponse.status);
    
    if (employeesResponse.ok) {
      const employeesData = await employeesResponse.json();
      console.log('Employees response structure:', Object.keys(employeesData));
      if (employeesData.employees) {
        console.log('✅ Found employees array with', employeesData.employees.length, 'items');
      }
    }
  } catch (employeesError) {
    console.error('❌ Employees API call failed:', employeesError.message);
  }
}

// Run the debug function
debugAttendanceAPI();