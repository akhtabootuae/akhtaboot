// Phase 3: Attendance & Pay Calculation MongoDB Setup Script
// Run this script in MongoDB shell or MongoDB Compass

use('new_garage_system');

console.log('=== Phase 3: Attendance & Pay Calculation MongoDB Setup ===');

// 1. Create payroll_time_sheets collection
console.log('Creating payroll_time_sheets collection...');
db.createCollection("payroll_time_sheets", {
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["employee_id", "date", "status", "created_by", "created_at"],
      properties: {
        employee_id: {
          bsonType: "objectId",
          description: "Reference to user (employee) ID - required"
        },
        date: {
          bsonType: "date",
          description: "Date of the time sheet entry - required"
        },
        status: {
          bsonType: "string",
          enum: ["present", "absent", "half_day", "sick_leave", "vacation", "unpaid_leave", "holiday"],
          description: "Attendance status for the day - required"
        },
        check_in_time: {
          bsonType: ["date", "null"],
          description: "Time employee checked in (if present)"
        },
        check_out_time: {
          bsonType: ["date", "null"],
          description: "Time employee checked out (if present)"
        },
        break_start_time: {
          bsonType: ["date", "null"],
          description: "Time break started"
        },
        break_end_time: {
          bsonType: ["date", "null"],
          description: "Time break ended"
        },
        total_hours_worked: {
          bsonType: ["double", "null"],
          minimum: 0,
          maximum: 24,
          description: "Total hours worked for the day"
        },
        overtime_hours: {
          bsonType: ["double", "null"],
          minimum: 0,
          description: "Overtime hours (if any)"
        },
        daily_pay_amount: {
          bsonType: ["double", "null"],
          minimum: 0,
          description: "Calculated daily pay amount"
        },
        overtime_pay_amount: {
          bsonType: ["double", "null"],
          minimum: 0,
          description: "Calculated overtime pay amount"
        },
        notes: {
          bsonType: ["string", "null"],
          description: "Additional notes about the day"
        },
        approved_by: {
          bsonType: ["objectId", "null"],
          description: "User ID who approved this time sheet entry"
        },
        approved_at: {
          bsonType: ["date", "null"],
          description: "Timestamp when approved"
        },
        created_by: {
          bsonType: "objectId",
          description: "User ID who created this entry - required"
        },
        created_at: {
          bsonType: "date",
          description: "Creation timestamp - required"
        },
        updated_at: {
          bsonType: ["date", "null"],
          description: "Last update timestamp"
        }
      }
    }
  }
});

// Create indexes for time sheets
db.payroll_time_sheets.createIndex({ "employee_id": 1, "date": 1 }, { unique: true });
db.payroll_time_sheets.createIndex({ "date": 1 });
db.payroll_time_sheets.createIndex({ "status": 1 });
db.payroll_time_sheets.createIndex({ "created_at": 1 });

console.log('✓ payroll_time_sheets collection created with indexes');

// 2. Create payroll_pay_periods collection
console.log('Creating payroll_pay_periods collection...');
db.createCollection("payroll_pay_periods", {
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["name", "start_date", "end_date", "status", "created_by", "created_at"],
      properties: {
        name: {
          bsonType: "string",
          description: "Pay period name (e.g., 'January 2024 - Week 1') - required"
        },
        description: {
          bsonType: ["string", "null"],
          description: "Additional description of the pay period"
        },
        start_date: {
          bsonType: "date",
          description: "Pay period start date - required"
        },
        end_date: {
          bsonType: "date",
          description: "Pay period end date - required"
        },
        status: {
          bsonType: "string",
          enum: ["open", "calculating", "calculated", "approved", "paid", "closed"],
          description: "Current status of the pay period - required"
        },
        pay_date: {
          bsonType: ["date", "null"],
          description: "Date when employees will be/were paid"
        },
        total_employees: {
          bsonType: ["int", "null"],
          minimum: 0,
          description: "Total number of employees in this pay period"
        },
        total_gross_pay: {
          bsonType: ["double", "null"],
          minimum: 0,
          description: "Total gross pay for all employees"
        },
        total_deductions: {
          bsonType: ["double", "null"],
          minimum: 0,
          description: "Total deductions for all employees"
        },
        total_net_pay: {
          bsonType: ["double", "null"],
          minimum: 0,
          description: "Total net pay for all employees"
        },
        calculated_by: {
          bsonType: ["objectId", "null"],
          description: "User ID who calculated the payroll"
        },
        calculated_at: {
          bsonType: ["date", "null"],
          description: "Timestamp when payroll was calculated"
        },
        approved_by: {
          bsonType: ["objectId", "null"],
          description: "User ID who approved the payroll"
        },
        approved_at: {
          bsonType: ["date", "null"],
          description: "Timestamp when payroll was approved"
        },
        created_by: {
          bsonType: "objectId",
          description: "User ID who created this pay period - required"
        },
        created_at: {
          bsonType: "date",
          description: "Creation timestamp - required"
        },
        updated_at: {
          bsonType: ["date", "null"],
          description: "Last update timestamp"
        }
      }
    }
  }
});

// Create indexes for pay periods
db.payroll_pay_periods.createIndex({ "start_date": 1, "end_date": 1 });
db.payroll_pay_periods.createIndex({ "status": 1 });
db.payroll_pay_periods.createIndex({ "created_at": 1 });

console.log('✓ payroll_pay_periods collection created with indexes');

// 3. Create payroll_calculations collection
console.log('Creating payroll_calculations collection...');
db.createCollection("payroll_calculations", {
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["employee_id", "pay_period_id", "status", "created_by", "created_at"],
      properties: {
        employee_id: {
          bsonType: "objectId",
          description: "Reference to user (employee) ID - required"
        },
        pay_period_id: {
          bsonType: "objectId",
          description: "Reference to pay period ID - required"
        },
        status: {
          bsonType: "string",
          enum: ["calculating", "calculated", "approved", "paid", "error"],
          description: "Calculation status - required"
        },
        days_worked: {
          bsonType: ["int", "null"],
          minimum: 0,
          description: "Total days worked in the pay period"
        },
        total_hours: {
          bsonType: ["double", "null"],
          minimum: 0,
          description: "Total hours worked in the pay period"
        },
        overtime_hours: {
          bsonType: ["double", "null"],
          minimum: 0,
          description: "Total overtime hours"
        },
        daily_rate: {
          bsonType: ["double", "null"],
          minimum: 0,
          description: "Daily rate used for calculation"
        },
        base_pay: {
          bsonType: ["double", "null"],
          minimum: 0,
          description: "Base pay (days_worked * daily_rate)"
        },
        overtime_pay: {
          bsonType: ["double", "null"],
          minimum: 0,
          description: "Overtime pay amount"
        },
        gross_pay: {
          bsonType: ["double", "null"],
          minimum: 0,
          description: "Total gross pay (base + overtime)"
        },
        total_deductions: {
          bsonType: ["double", "null"],
          minimum: 0,
          description: "Total deductions applied"
        },
        net_pay: {
          bsonType: ["double", "null"],
          minimum: 0,
          description: "Final net pay (gross - deductions)"
        },
        deductions_breakdown: {
          bsonType: ["array", "null"],
          description: "Array of individual deductions applied",
          items: {
            bsonType: "object",
            properties: {
              deduction_id: { bsonType: "objectId" },
              deduction_name: { bsonType: "string" },
              amount: { bsonType: "double", minimum: 0 },
              remaining_balance: { bsonType: ["double", "null"] }
            }
          }
        },
        attendance_summary: {
          bsonType: ["array", "null"],
          description: "Summary of attendance for the period",
          items: {
            bsonType: "object",
            properties: {
              date: { bsonType: "date" },
              status: { bsonType: "string" },
              hours_worked: { bsonType: ["double", "null"] },
              overtime_hours: { bsonType: ["double", "null"] }
            }
          }
        },
        calculation_notes: {
          bsonType: ["string", "null"],
          description: "Notes about the calculation"
        },
        error_message: {
          bsonType: ["string", "null"],
          description: "Error message if calculation failed"
        },
        calculated_by: {
          bsonType: ["objectId", "null"],
          description: "User ID who performed the calculation"
        },
        calculated_at: {
          bsonType: ["date", "null"],
          description: "Timestamp when calculation was performed"
        },
        approved_by: {
          bsonType: ["objectId", "null"],
          description: "User ID who approved the calculation"
        },
        approved_at: {
          bsonType: ["date", "null"],
          description: "Timestamp when calculation was approved"
        },
        created_by: {
          bsonType: "objectId",
          description: "User ID who created this record - required"
        },
        created_at: {
          bsonType: "date",
          description: "Creation timestamp - required"
        },
        updated_at: {
          bsonType: ["date", "null"],
          description: "Last update timestamp"
        }
      }
    }
  }
});

// Create indexes for calculations
db.payroll_calculations.createIndex({ "employee_id": 1, "pay_period_id": 1 }, { unique: true });
db.payroll_calculations.createIndex({ "pay_period_id": 1 });
db.payroll_calculations.createIndex({ "status": 1 });
db.payroll_calculations.createIndex({ "created_at": 1 });

console.log('✓ payroll_calculations collection created with indexes');

// 4. Add new permissions for Phase 3
console.log('Adding Phase 3 permissions...');

const phase3Permissions = [
  {
    permission_id: 'payroll_manage_attendance',
    permission_name: 'Manage Employee Attendance',
    description: 'Can view and manage employee time sheets and attendance records',
    category: 'payroll',
    created_at: new Date()
  },
  {
    permission_id: 'payroll_approve_attendance',
    permission_name: 'Approve Attendance Records',
    description: 'Can approve employee time sheets and attendance entries',
    category: 'payroll',
    created_at: new Date()
  },
  {
    permission_id: 'payroll_calculate_pay',
    permission_name: 'Calculate Payroll',
    description: 'Can calculate payroll for pay periods',
    category: 'payroll',
    created_at: new Date()
  },
  {
    permission_id: 'payroll_approve_calculations',
    permission_name: 'Approve Payroll Calculations',
    description: 'Can approve payroll calculations and authorize payments',
    category: 'payroll',
    created_at: new Date()
  },
  {
    permission_id: 'payroll_view_all_attendance',
    permission_name: 'View All Employee Attendance',
    description: 'Can view attendance records for all employees',
    category: 'payroll',
    created_at: new Date()
  }
];

// Insert permissions
phase3Permissions.forEach(permission => {
  const existing = db.permissions.findOne({ permission_id: permission.permission_id });
  if (!existing) {
    db.permissions.insertOne(permission);
    console.log(`✓ Added permission: ${permission.permission_name}`);
  } else {
    console.log(`- Permission already exists: ${permission.permission_name}`);
  }
});

// 5. Grant Phase 3 permissions to Admin role
console.log('Granting Phase 3 permissions to Admin role...');

const adminRole = db.roles.findOne({ role_name: 'Admin' });
if (adminRole) {
  phase3Permissions.forEach(permission => {
    const existingPermission = db.role_permissions.findOne({
      role_id: adminRole._id,
      permission_id: permission.permission_id
    });
    
    if (!existingPermission) {
      db.role_permissions.insertOne({
        role_id: adminRole._id,
        permission_id: permission.permission_id,
        granted: true,
        created_at: new Date()
      });
      console.log(`✓ Granted ${permission.permission_name} to Admin role`);
    } else {
      console.log(`- Admin already has ${permission.permission_name}`);
    }
  });
} else {
  console.log('! Admin role not found - permissions not granted');
}

// 6. Create default pay period settings (optional)
console.log('Creating default pay period configuration...');

const defaultPayPeriodConfig = {
  name: "Default Pay Period Configuration",
  frequency: "bi_weekly", // weekly, bi_weekly, monthly
  start_day_of_week: 1, // 1 = Monday, 0 = Sunday
  pay_delay_days: 3, // Number of days after period ends before pay date
  overtime_threshold_hours: 8, // Hours per day before overtime
  overtime_multiplier: 1.5, // Overtime pay multiplier
  created_at: new Date(),
  created_by: adminRole ? adminRole._id : null
};

const existingConfig = db.payroll_settings.findOne({ name: "Default Pay Period Configuration" });
if (!existingConfig) {
  db.payroll_settings.insertOne(defaultPayPeriodConfig);
  console.log('✓ Created default pay period configuration');
} else {
  console.log('- Default pay period configuration already exists');
}

console.log('\n=== Phase 3 MongoDB Setup Complete ===');
console.log('Collections created:');
console.log('- payroll_time_sheets (employee daily attendance/time tracking)');
console.log('- payroll_pay_periods (pay period management)');
console.log('- payroll_calculations (payroll calculation results)');
console.log('\nPermissions added:');
console.log('- payroll_manage_attendance');
console.log('- payroll_approve_attendance');
console.log('- payroll_calculate_pay');
console.log('- payroll_approve_calculations');
console.log('- payroll_view_all_attendance');
console.log('\nNext steps:');
console.log('1. Verify all collections were created successfully');
console.log('2. Test permission assignments');
console.log('3. Implement backend API endpoints');
console.log('4. Build frontend attendance management UI');