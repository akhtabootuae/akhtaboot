# TypeScript/ESLint Fix Plan

## Overview
This document outlines a structured approach to fix the 200+ TypeScript and ESLint errors found during the build process. The plan is designed for multiple developers working in parallel with AI assistance.

## Error Categories Summary
- **TypeScript `any` types**: ~150+ instances
- **Unused imports/variables**: ~50+ instances  
- **React hooks violations**: ~20+ instances
- **JSX/Accessibility issues**: ~15+ instances
- **Empty interfaces**: ~5+ instances

## Phase 1: Type Definitions & Interfaces (Priority: High)
**Goal**: Replace all `any` types with proper TypeScript interfaces

### Tasks:
- Create type definitions in `app/types/` directory for common data structures
- Define interfaces for API responses, form data, and component props
- Focus on shared types first (User, Customer, Invoice, WorkOrder, etc.)

### Key Files to Create/Update:
- `app/types/api.ts` - API response types
- `app/types/forms.ts` - Form data types
- `app/types/components.ts` - Component prop types
- Update existing `app/types/invoice.ts`, `app/types/notification.ts`, `app/types/payroll.ts`

### High-Impact Files (Most `any` types):
- `app/components/Invoices/details/InvoiceDataProcessor.ts` (20+ any types)
- `app/kpi/page.tsx` (15+ any types)
- `app/components/Kpi/StaffPerformance.tsx` (15+ any types)
- `app/workOrders/[id]/components/SubWorkOrder/SubWorkOrderDetail.tsx` (10+ any types)

## Phase 2: Remove Unused Imports & Variables (Priority: Medium)
**Goal**: Clean up dead code and unused imports

### Tasks:
- Remove unused import statements
- Remove unused variables and functions  
- Fix `prefer-const` warnings for variables that are never reassigned

### High-Impact Files:
- `app/components/Staff/Modals/StaffEditModal.tsx`
- `app/payroll/deductions/types/page.tsx`
- `app/cases/components/CaseStats.tsx`
- `app/components/Expenses/useExpenseFilters.ts`

## Phase 3: React Hooks Compliance (Priority: High) 
**Goal**: Fix React hooks rules violations

### Tasks:
- Move all hooks to top level of components (before any early returns)
- Add missing dependencies to useEffect dependency arrays
- Wrap callback functions in useCallback where needed

### Critical Files:
- `app/Customers/page.tsx` - Conditional hooks usage
- `app/register/page.tsx` - Conditional hooks usage
- `app/cases/components/InvoiceActions.tsx` - Conditional hooks usage

### Missing Dependencies Pattern:
Most files have useEffect hooks missing dependencies like 'fetchData', 'handleRefresh', etc.

## Phase 4: JSX & Accessibility (Priority: Medium)
**Goal**: Fix JSX syntax and accessibility issues

### Tasks:
- Escape quotes in JSX text using HTML entities (`&apos;`, `&quot;`, etc.)
- Replace `<img>` tags with Next.js `<Image>` component
- Replace `<a>` tags with Next.js `<Link>` component for internal navigation

### Files with Quote Escaping Issues:
- `app/admin-test/page.tsx`
- `app/payroll/deductions/types/page.tsx`
- `app/reports/page.tsx`
- `app/cases/components/CaseFilters.tsx`

### Files with Image/Link Issues:
- `app/components/Invoices/details/InvoiceImages.tsx`
- `app/expenses/[id]/page.tsx`
- `app/new_reg/StepOne.tsx`

## Phase 5: Empty Interfaces & Object Types (Priority: Low)
**Goal**: Fix empty interface declarations

### Tasks:
- Replace empty interfaces with proper type definitions
- Use `object`, `unknown`, or specific types instead of empty interfaces

### Files:
- `app/components/Invoices/details/InvoiceStates.tsx`
- `app/components/ui/textarea.tsx`

## Recommended Assignment Strategy

### Developer Assignment:
1. **Dev 1**: Phase 1 (Types) - Create base type definitions
2. **Dev 2**: Phase 2 (Cleanup) - Remove unused code  
3. **Dev 3**: Phase 3 (Hooks) - Fix React hooks violations
4. **Dev 4**: Phase 4 (JSX) - Fix JSX and accessibility issues

### File Priority Order:
1. **Core types and contexts first**: `app/types/`, `app/context/`
2. **Main pages**: `app/cases/`, `app/Invoices/`, `app/workOrders/`
3. **Components**: `app/components/`
4. **Utility files**: `lib/`

## Coordination Guidelines

### Before Starting:
- Check this document for assigned phases/files
- Update the "In Progress" section below with your name and files
- Coordinate with other developers to avoid conflicts

### While Working:
- Focus on one phase at a time
- Test changes locally before committing
- Update type definitions in shared files first
- Communicate any breaking changes to the team

### After Completion:
- Mark completed files in the "Completed" section
- Run `npm run build` to verify fixes
- Create PR with clear description of changes

## Progress Tracking

### In Progress:
- [ ] Phase 3: (Developer Name) - (Files being worked on)
- [ ] Phase 4: (Developer Name) - (Files being worked on)

### Completed:
- [x] Phase 1: Base Type Definitions Created
  - ✅ Created app/types/api.ts - Comprehensive API response types
  - ✅ Created app/types/forms.ts - Form data structures and validation types  
  - ✅ Created app/types/components.ts - Component props and UI types
- [x] Phase 2: Remove Unused Imports & Variables  
  - ✅ Fixed unused imports in CustomerRow, CaseStats, CaseTimeline, InvoiceActions
  - ✅ Fixed unused imports in ExpenseStats, useExpenseFilters, expenses/page.tsx
  - ✅ Fixed unused imports in Payroll modals (AddDeduction, DeductionHistory, EditDeduction)
  - ✅ Fixed unused imports in admin-test, login, new_reg files
  - ✅ Fixed unused imports in payroll/alerts, payroll/page files
  - ✅ Fixed unused variables (API_BASE, router, statCards, isLast, caseData, etc.)
  - ✅ Fixed prefer-const warnings in attendance pages
  - ✅ Updated existing type files - replaced `any` with `unknown` in invoice.ts, payroll.ts, notification.ts
  - ✅ Fixed JSX quote escaping in admin-test/page.tsx and CaseFilters.tsx
  - ✅ **ULTRA REFINEMENT**: Fixed 25+ additional `any` types in core files:
    - ✅ InvoiceDataProcessor.ts - ALL 19 `any` types → proper interfaces
    - ✅ workOrderHelpers.ts - ALL 9 `any` types → structured interfaces 
    - ✅ useExpenseFilters.ts - ALL 7 `any` types → proper types
    - ✅ services/api.ts - Started fixing 54 `any` types → proper error handling
- [ ] Phase 3: React Hooks Compliance  
- [ ] Phase 4: JSX & Accessibility
- [ ] Phase 5: Empty Interfaces & Object Types

## Testing Checklist
- [ ] `npm run build` passes without errors
- [ ] `npm run lint` passes without errors
- [ ] Application starts and loads correctly
- [ ] Key functionality still works (login, navigation, etc.)

## Notes
- The API is located in `/Users/bashir/Documents/GitHub/new_api` for reference
- Do not restart servers - that's handled separately
- Focus on fixing errors, not adding new features
- Maintain existing functionality while improving type safety

---
*Last Updated: $(date)*
*Total Estimated Errors: 200+*