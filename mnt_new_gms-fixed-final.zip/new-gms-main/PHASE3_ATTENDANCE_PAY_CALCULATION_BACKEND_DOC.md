# Phase 3: Attendance & Pay Calculation Backend Implementation Guide

## Overview
This document provides comprehensive implementation guidelines for Phase 3 of the payroll system: Attendance tracking and pay calculation functionality.

## Prerequisites
- Phase 1 (Rate Management) must be completed
- Phase 2 (Deductions System) must be completed
- MongoDB setup script `phase3_attendance_mongodb_setup.js` must be executed
- All required collections and permissions should be in place

## Database Collections

### 1. payroll_time_sheets
Stores daily attendance and time tracking data for employees.

**Schema:**
```javascript
{
  _id: ObjectId,
  employee_id: ObjectId, // Reference to users collection
  date: Date, // Date of the time sheet entry
  status: String, // "present", "absent", "half_day", "sick_leave", "vacation", "unpaid_leave", "holiday"
  check_in_time: Date, // Time employee checked in
  check_out_time: Date, // Time employee checked out
  break_start_time: Date, // Break start time
  break_end_time: Date, // Break end time
  total_hours_worked: Number, // Total hours worked for the day
  overtime_hours: Number, // Overtime hours (if any)
  daily_pay_amount: Number, // Calculated daily pay amount
  overtime_pay_amount: Number, // Calculated overtime pay amount
  notes: String, // Additional notes
  approved_by: ObjectId, // User who approved this entry
  approved_at: Date, // Approval timestamp
  created_by: ObjectId, // User who created this entry
  created_at: Date,
  updated_at: Date
}
```

### 2. payroll_pay_periods
Manages pay periods for payroll processing.

**Schema:**
```javascript
{
  _id: ObjectId,
  name: String, // "January 2024 - Week 1"
  description: String, // Additional description
  start_date: Date,
  end_date: Date,
  status: String, // "open", "calculating", "calculated", "approved", "paid", "closed"
  pay_date: Date, // When employees will be/were paid
  total_employees: Number,
  total_gross_pay: Number,
  total_deductions: Number,
  total_net_pay: Number,
  calculated_by: ObjectId,
  calculated_at: Date,
  approved_by: ObjectId,
  approved_at: Date,
  created_by: ObjectId,
  created_at: Date,
  updated_at: Date
}
```

### 3. payroll_calculations
Stores payroll calculation results for each employee per pay period.

**Schema:**
```javascript
{
  _id: ObjectId,
  employee_id: ObjectId,
  pay_period_id: ObjectId,
  status: String, // "calculating", "calculated", "approved", "paid", "error"
  days_worked: Number,
  total_hours: Number,
  overtime_hours: Number,
  daily_rate: Number, // Rate used for calculation
  base_pay: Number, // days_worked * daily_rate
  overtime_pay: Number,
  gross_pay: Number, // base + overtime
  total_deductions: Number,
  net_pay: Number, // gross - deductions
  deductions_breakdown: [
    {
      deduction_id: ObjectId,
      deduction_name: String,
      amount: Number,
      remaining_balance: Number
    }
  ],
  attendance_summary: [
    {
      date: Date,
      status: String,
      hours_worked: Number,
      overtime_hours: Number
    }
  ],
  calculation_notes: String,
  error_message: String,
  calculated_by: ObjectId,
  calculated_at: Date,
  approved_by: ObjectId,
  approved_at: Date,
  created_by: ObjectId,
  created_at: Date,
  updated_at: Date
}
```

## Required Models

### 1. TimeSheet Model (`models/payroll/TimeSheet.js`)
```javascript
const mongoose = require('mongoose');

const timeSheetSchema = new mongoose.Schema({
  employee_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  date: {
    type: Date,
    required: true
  },
  status: {
    type: String,
    enum: ['present', 'absent', 'half_day', 'sick_leave', 'vacation', 'unpaid_leave', 'holiday'],
    required: true
  },
  check_in_time: Date,
  check_out_time: Date,
  break_start_time: Date,
  break_end_time: Date,
  total_hours_worked: {
    type: Number,
    min: 0,
    max: 24
  },
  overtime_hours: {
    type: Number,
    min: 0
  },
  daily_pay_amount: {
    type: Number,
    min: 0
  },
  overtime_pay_amount: {
    type: Number,
    min: 0
  },
  notes: String,
  approved_by: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  approved_at: Date,
  created_by: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  }
}, {
  timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }
});

// Compound index for uniqueness
timeSheetSchema.index({ employee_id: 1, date: 1 }, { unique: true });

module.exports = mongoose.model('TimeSheet', timeSheetSchema);
```

### 2. PayPeriod Model (`models/payroll/PayPeriod.js`)
```javascript
const mongoose = require('mongoose');

const payPeriodSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  description: String,
  start_date: {
    type: Date,
    required: true
  },
  end_date: {
    type: Date,
    required: true
  },
  status: {
    type: String,
    enum: ['open', 'calculating', 'calculated', 'approved', 'paid', 'closed'],
    required: true,
    default: 'open'
  },
  pay_date: Date,
  total_employees: {
    type: Number,
    min: 0
  },
  total_gross_pay: {
    type: Number,
    min: 0
  },
  total_deductions: {
    type: Number,
    min: 0
  },
  total_net_pay: {
    type: Number,
    min: 0
  },
  calculated_by: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  calculated_at: Date,
  approved_by: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  approved_at: Date,
  created_by: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  }
}, {
  timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }
});

module.exports = mongoose.model('PayPeriod', payPeriodSchema);
```

### 3. PayrollCalculation Model (`models/payroll/PayrollCalculation.js`)
```javascript
const mongoose = require('mongoose');

const deductionBreakdownSchema = new mongoose.Schema({
  deduction_id: {
    type: mongoose.Schema.Types.ObjectId,
    required: true
  },
  deduction_name: {
    type: String,
    required: true
  },
  amount: {
    type: Number,
    required: true,
    min: 0
  },
  remaining_balance: Number
}, { _id: false });

const attendanceSummarySchema = new mongoose.Schema({
  date: {
    type: Date,
    required: true
  },
  status: {
    type: String,
    required: true
  },
  hours_worked: Number,
  overtime_hours: Number
}, { _id: false });

const payrollCalculationSchema = new mongoose.Schema({
  employee_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  pay_period_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'PayPeriod',
    required: true
  },
  status: {
    type: String,
    enum: ['calculating', 'calculated', 'approved', 'paid', 'error'],
    required: true,
    default: 'calculating'
  },
  days_worked: {
    type: Number,
    min: 0
  },
  total_hours: {
    type: Number,
    min: 0
  },
  overtime_hours: {
    type: Number,
    min: 0
  },
  daily_rate: {
    type: Number,
    min: 0
  },
  base_pay: {
    type: Number,
    min: 0
  },
  overtime_pay: {
    type: Number,
    min: 0
  },
  gross_pay: {
    type: Number,
    min: 0
  },
  total_deductions: {
    type: Number,
    min: 0
  },
  net_pay: {
    type: Number,
    min: 0
  },
  deductions_breakdown: [deductionBreakdownSchema],
  attendance_summary: [attendanceSummarySchema],
  calculation_notes: String,
  error_message: String,
  calculated_by: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  calculated_at: Date,
  approved_by: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  approved_at: Date,
  created_by: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  }
}, {
  timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }
});

// Compound index for uniqueness
payrollCalculationSchema.index({ employee_id: 1, pay_period_id: 1 }, { unique: true });

module.exports = mongoose.model('PayrollCalculation', payrollCalculationSchema);
```

## API Endpoints

### Time Sheet Management

#### 1. GET /api/payroll/time-sheets
Get time sheets with filtering options.

**Query Parameters:**
- `employee_id` (optional): Filter by employee
- `start_date` (optional): Filter from date
- `end_date` (optional): Filter to date
- `status` (optional): Filter by status
- `page` (optional): Page number (default: 1)
- `limit` (optional): Items per page (default: 50)

**Response:**
```javascript
{
  success: true,
  time_sheets: [
    {
      _id: "...",
      employee_id: "...",
      employee: { first_name: "John", last_name: "Doe" },
      date: "2024-01-15T00:00:00.000Z",
      status: "present",
      check_in_time: "2024-01-15T08:00:00.000Z",
      check_out_time: "2024-01-15T17:00:00.000Z",
      total_hours_worked: 8,
      overtime_hours: 0,
      daily_pay_amount: 200,
      notes: "Regular work day"
    }
  ],
  pagination: {
    page: 1,
    limit: 50,
    total: 100,
    pages: 2
  }
}
```

#### 2. GET /api/payroll/time-sheets/:id
Get a specific time sheet entry.

**Response:**
```javascript
{
  success: true,
  time_sheet: {
    _id: "...",
    employee_id: "...",
    employee: { first_name: "John", last_name: "Doe" },
    date: "2024-01-15T00:00:00.000Z",
    status: "present",
    // ... other fields
  }
}
```

#### 3. POST /api/payroll/time-sheets
Create a new time sheet entry.

**Required Permission:** `payroll_manage_attendance`

**Request Body:**
```javascript
{
  employee_id: "507f1f77bcf86cd799439011",
  date: "2024-01-15",
  status: "present",
  check_in_time: "2024-01-15T08:00:00.000Z", // optional
  check_out_time: "2024-01-15T17:00:00.000Z", // optional
  break_start_time: "2024-01-15T12:00:00.000Z", // optional
  break_end_time: "2024-01-15T13:00:00.000Z", // optional
  notes: "Regular work day" // optional
}
```

**Response:**
```javascript
{
  success: true,
  message: "Time sheet entry created successfully",
  time_sheet: {
    _id: "...",
    // ... created time sheet data
  }
}
```

#### 4. PUT /api/payroll/time-sheets/:id
Update an existing time sheet entry.

**Required Permission:** `payroll_manage_attendance`

**Request Body:** Same as POST, all fields optional

**Response:**
```javascript
{
  success: true,
  message: "Time sheet updated successfully",
  time_sheet: {
    // ... updated time sheet data
  }
}
```

#### 5. POST /api/payroll/time-sheets/:id/approve
Approve a time sheet entry.

**Required Permission:** `payroll_approve_attendance`

**Response:**
```javascript
{
  success: true,
  message: "Time sheet approved successfully"
}
```

#### 6. DELETE /api/payroll/time-sheets/:id
Delete a time sheet entry.

**Required Permission:** `payroll_manage_attendance`

**Response:**
```javascript
{
  success: true,
  message: "Time sheet deleted successfully"
}
```

#### 7. GET /api/payroll/employees/:employee_id/time-sheets
Get time sheets for a specific employee.

**Query Parameters:** Same as GET /api/payroll/time-sheets

#### 8. POST /api/payroll/time-sheets/bulk
Create multiple time sheet entries at once.

**Required Permission:** `payroll_manage_attendance`

**Request Body:**
```javascript
{
  entries: [
    {
      employee_id: "...",
      date: "2024-01-15",
      status: "present"
    },
    // ... more entries
  ]
}
```

### Pay Period Management

#### 9. GET /api/payroll/pay-periods
Get all pay periods.

**Query Parameters:**
- `status` (optional): Filter by status
- `page` (optional): Page number
- `limit` (optional): Items per page

**Response:**
```javascript
{
  success: true,
  pay_periods: [
    {
      _id: "...",
      name: "January 2024 - Week 1",
      start_date: "2024-01-01T00:00:00.000Z",
      end_date: "2024-01-07T23:59:59.000Z",
      status: "open",
      total_employees: 10,
      total_gross_pay: 14000
    }
  ]
}
```

#### 10. GET /api/payroll/pay-periods/:id
Get a specific pay period.

#### 11. POST /api/payroll/pay-periods
Create a new pay period.

**Required Permission:** `payroll_calculate_pay`

**Request Body:**
```javascript
{
  name: "January 2024 - Week 1",
  description: "First week of January", // optional
  start_date: "2024-01-01",
  end_date: "2024-01-07",
  pay_date: "2024-01-10" // optional
}
```

#### 12. PUT /api/payroll/pay-periods/:id
Update a pay period.

#### 13. POST /api/payroll/pay-periods/:id/calculate
Calculate payroll for a pay period.

**Required Permission:** `payroll_calculate_pay`

**Response:**
```javascript
{
  success: true,
  message: "Payroll calculation started",
  calculation_id: "...",
  summary: {
    total_employees: 10,
    employees_calculated: 8,
    employees_with_errors: 2,
    total_gross_pay: 14000,
    total_deductions: 2000,
    total_net_pay: 12000
  }
}
```

#### 14. POST /api/payroll/pay-periods/:id/approve
Approve a calculated pay period.

**Required Permission:** `payroll_approve_calculations`

#### 15. GET /api/payroll/pay-periods/:id/calculations
Get all calculations for a pay period.

### Payroll Calculation Management

#### 16. GET /api/payroll/calculations
Get payroll calculations with filtering.

**Query Parameters:**
- `pay_period_id` (optional)
- `employee_id` (optional)
- `status` (optional)

#### 17. GET /api/payroll/calculations/:id
Get a specific payroll calculation.

**Response:**
```javascript
{
  success: true,
  calculation: {
    _id: "...",
    employee: { first_name: "John", last_name: "Doe" },
    pay_period: { name: "January 2024 - Week 1" },
    days_worked: 5,
    total_hours: 40,
    overtime_hours: 0,
    daily_rate: 200,
    base_pay: 1000,
    overtime_pay: 0,
    gross_pay: 1000,
    total_deductions: 150,
    net_pay: 850,
    deductions_breakdown: [
      {
        deduction_name: "Employee Advance",
        amount: 150,
        remaining_balance: 350
      }
    ],
    attendance_summary: [
      {
        date: "2024-01-01T00:00:00.000Z",
        status: "present",
        hours_worked: 8
      }
    ]
  }
}
```

#### 18. POST /api/payroll/calculations/:id/recalculate
Recalculate a specific employee's payroll.

#### 19. POST /api/payroll/calculations/:id/approve
Approve a payroll calculation.

**Required Permission:** `payroll_approve_calculations`

### Attendance Analytics

#### 20. GET /api/payroll/attendance/summary
Get attendance summary for reporting.

**Query Parameters:**
- `start_date` (required)
- `end_date` (required)
- `employee_id` (optional)

**Response:**
```javascript
{
  success: true,
  summary: {
    total_days: 30,
    present_days: 28,
    absent_days: 2,
    sick_leave_days: 1,
    vacation_days: 1,
    attendance_rate: 93.33,
    total_hours: 224,
    overtime_hours: 8,
    by_employee: [
      {
        employee_id: "...",
        employee_name: "John Doe",
        present_days: 28,
        total_hours: 224
      }
    ]
  }
}
```

## Implementation Notes

### 1. Time Calculation Logic
```javascript
// Calculate total hours worked
function calculateHoursWorked(checkIn, checkOut, breakStart, breakEnd) {
  if (!checkIn || !checkOut) return 0;
  
  let totalMinutes = (checkOut - checkIn) / (1000 * 60);
  
  if (breakStart && breakEnd) {
    const breakMinutes = (breakEnd - breakStart) / (1000 * 60);
    totalMinutes -= breakMinutes;
  }
  
  return totalMinutes / 60; // Convert to hours
}

// Calculate overtime
function calculateOvertime(hoursWorked, overtimeThreshold = 8) {
  return Math.max(0, hoursWorked - overtimeThreshold);
}
```

### 2. Pay Calculation Logic
```javascript
// Calculate daily pay
function calculateDailyPay(status, dailyRate, hoursWorked, overtimeHours, overtimeMultiplier = 1.5) {
  if (status === 'absent' || status === 'unpaid_leave') {
    return { basePay: 0, overtimePay: 0 };
  }
  
  if (status === 'half_day') {
    return { basePay: dailyRate * 0.5, overtimePay: 0 };
  }
  
  const basePay = dailyRate;
  const overtimePay = overtimeHours * (dailyRate / 8) * overtimeMultiplier;
  
  return { basePay, overtimePay };
}
```

### 3. Deductions Integration
Integrate with Phase 2 deductions when calculating payroll:

```javascript
async function calculateEmployeePayroll(employeeId, payPeriodId) {
  // 1. Get employee's time sheets for the period
  // 2. Calculate base pay and overtime
  // 3. Get active deductions for the employee
  // 4. Apply deductions in priority order
  // 5. Calculate net pay
  // 6. Update deduction balances
  // 7. Create deduction history records
}
```

### 4. Error Handling
- Validate date ranges
- Check for duplicate time sheet entries
- Handle timezone conversions properly
- Validate permission requirements
- Implement proper audit logging

### 5. Performance Considerations
- Use aggregation pipelines for summary calculations
- Implement proper indexing
- Cache frequently accessed data
- Use bulk operations for large datasets

## Testing Requirements

1. **Unit Tests:** Test calculation logic, validation rules
2. **Integration Tests:** Test API endpoints, database operations
3. **Permission Tests:** Verify access control for all endpoints
4. **Data Integrity Tests:** Test uniqueness constraints, referential integrity

## Next Steps After Backend Implementation

1. **Frontend Development:** Create attendance management UI
2. **Mobile App Integration:** Consider mobile time tracking
3. **Reporting Dashboard:** Build payroll analytics interface
4. **Integration Testing:** Test with Phase 1 and Phase 2 systems
5. **User Training:** Prepare documentation for end users