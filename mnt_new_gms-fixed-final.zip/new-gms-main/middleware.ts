import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

// Define public paths that don't require authentication
const publicPaths = ['/login', '/admin-test']; // Admin test is public for debugging

// Basic JWT structure validation: must have 3 dot-separated parts
const isValidJwtStructure = (token: string): boolean => {
  const parts = token.split('.');
  return parts.length === 3 && parts.every(part => part.length > 0);
};

export function middleware(request: NextRequest) {
  const token = request.cookies.get('authToken')?.value;
  const { pathname } = request.nextUrl;

  // Allow access to public paths
  if (publicPaths.includes(pathname)) {
    // Redirect to homepage if already authenticated
    if (token && isValidJwtStructure(token)) {
      return NextResponse.redirect(new URL('/', request.url));
    }
    // Allow access to public path
    return NextResponse.next();
  }

  // Check if user is authenticated for protected routes
  if (!token || !isValidJwtStructure(token)) {
    // Redirect to login if trying to access protected route without auth or with invalid token
    const loginUrl = new URL('/login', request.url);
    loginUrl.searchParams.set('callbackUrl', pathname);
    return NextResponse.redirect(loginUrl);
  }

  return NextResponse.next();
}

// Configure which paths the middleware will run on
export const config = {
  matcher: [
    // Protected routes that require authentication
    '/',
    '/register',
    '/staff/:path*',
    '/workOrders/:path*',
    '/Customers/:path*',
    '/notifications/:path*',
    '/profile',
    '/new_reg',
    '/Invoices/:path*',
    '/expenses/:path*',
    '/payroll/:path*',
    '/finance/:path*',
    '/kpi/:path*',
    '/cases/:path*',
    '/Messaging/:path*',
    '/reports/:path*',
    '/settings/:path*',
    '/car_cards/:path*',
    // Public routes that should be accessible without authentication
    '/login',
    '/admin-test',
  ],
};
